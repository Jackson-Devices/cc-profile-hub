# Workflow Orchestration System - Quick Summary

## What Was Done

Fixed race conditions in GitHub Actions workflows by implementing a comprehensive orchestration system.

## Key Changes

### 1. Added Concurrency Controls

✅ All 24 workflows now have concurrency groups to prevent parallel execution

- Repository-scoped: Prevents same workflow from running simultaneously
- Branch-scoped: Allows parallel execution on different branches
- Issue-scoped: For issue-related workflows

### 2. Created Orchestration System

✅ Single configuration file to control workflow execution order

- **Config**: `.github/workflow-orchestration.yml`
- **Orchestrator**: `.github/workflows/orchestrator.yml`
- Easy to reorder by editing one file
- Supports multi-pass execution (run same workflow multiple times)

### 3. Race Condition Detection

✅ Automatic detection and reporting

- **Script**: `.github/scripts/race-condition-detector.sh`
- Detects concurrent workflows
- Identifies git operation conflicts
- Reports findings in workflow summaries

### 4. Git Lock Protection

✅ File-based locking for git operations

- **Script**: `.github/scripts/git-lock.sh`
- Prevents concurrent push/commit conflicts
- Auto-cleanup of stale locks
- Configurable timeouts

## Files Created

1. `.github/workflow-orchestration.yml` - Execution order configuration
2. `.github/workflows/orchestrator.yml` - Main orchestrator workflow
3. `.github/scripts/git-lock.sh` - Git operations lock utility
4. `.github/scripts/race-condition-detector.sh` - Race condition detection
5. `.github/WORKFLOW_ORCHESTRATION.md` - Full documentation
6. `.github/ORCHESTRATION_SUMMARY.md` - This file

## Files Modified

All 24 workflow files in `.github/workflows/` with added concurrency controls:

- apply_settings.yml (already had concurrency)
- auto-squash-commits.yml ✨ **ADDED**
- context-commands.yml (already had concurrency)
- decision_log_writer.yml ✨ **ADDED**
- docs-drift-gate.yml ✨ **ADDED**
- enforce_test_gate.yml (already had concurrency)
- eslint-apply.yml ✨ **ADDED**
- eslint-check.yml ✨ **ADDED**
- eslint-gate.yml ✨ **ADDED**
- format-apply.yml ✨ **ADDED**
- format-check.yml ✨ **ADDED**
- format-gate.yml ✨ **ADDED**
- issue-mirror-sync.yml ✨ **ADDED**
- lint-check.yml ✨ **ADDED**
- orchestrator.yml ✨ **NEW**
- pr-risk-check.yml ✨ **ADDED**
- pr-risk-gate.yml ✨ **ADDED**
- prevent-sequential-commits-gate.yml ✨ **ADDED**
- seed-test-runlist.yml (already had concurrency)
- validate-function.yml (already had concurrency)
- validate-issue.yml (already had concurrency)
- validate-sub-feature.yml (already had concurrency)
- validate-test-suite.yml (already had concurrency)
- workflow-lint-apply.yml ✨ **ADDED**
- workflow-lint-gate.yml ✨ **ADDED**

## Quick Start

### Run Orchestrated Workflows

```bash
# Run all workflows in order
gh workflow run orchestrator.yml

# Run specific phase only
gh workflow run orchestrator.yml -f phase=formatting

# Dry run (preview without executing)
gh workflow run orchestrator.yml -f dry_run=true
```

### Change Execution Order

Edit `.github/workflow-orchestration.yml`:

```yaml
orchestration:
  phases:
    linting:
      - workflow: 'eslint-apply.yml'
        description: 'Auto-fix ESLint'
      - workflow: 'workflow-lint-apply.yml'
        description: 'Auto-fix shellcheck'
```

### Test Individual Workflows

Workflows can still run independently:

```bash
# Manually trigger a workflow
gh workflow run format-apply.yml -f auto_commit=false

# Or via normal triggers (push, PR, etc.)
git push origin my-branch
```

### Check for Race Conditions

```bash
# Manual check
.github/scripts/race-condition-detector.sh \
  --workflow-name "My Workflow" \
  --check-git \
  --verbose

# List active locks
.github/scripts/git-lock.sh list

# Clean stale locks
.github/scripts/git-lock.sh cleanup
```

## Benefits

✅ **No More Race Conditions**

- Workflows execute sequentially when needed
- Git operations are protected with locks
- Automatic detection and reporting

✅ **Easy Configuration**

- Single file to modify execution order
- No need to edit individual workflows
- Supports conditional and optional workflows

✅ **Still Testable in Isolation**

- Each workflow can be triggered independently
- Normal triggers (push, PR) still work
- Concurrency controls prevent conflicts even in isolation

✅ **Multi-Pass Support**

- Run same workflow multiple times if needed
- Example: format → validate → format again

✅ **Comprehensive Monitoring**

- Race condition detection reports
- Lock status monitoring
- Workflow execution summaries

## How It Works

### Concurrency Control

```yaml
# Added to every workflow
concurrency:
  group: workflow-name-${{ github.repository }}-${{ github.ref }}
  cancel-in-progress: false
```

- Only one instance of each workflow runs at a time per branch
- Different branches can run workflows in parallel
- `cancel-in-progress: false` ensures completion rather than cancellation

### Orchestration Flow

1. Orchestrator reads `.github/workflow-orchestration.yml`
2. Executes workflows phase by phase
3. Acquires locks before each phase
4. Runs race condition detection
5. Releases locks after completion
6. Generates execution summary

### Git Lock Protection

```bash
# In workflows that perform git operations
source .github/scripts/git-lock.sh
with_git_lock "operation-name" git push origin HEAD
```

- Prevents concurrent git push/commit
- Automatic stale lock cleanup (10 min)
- Configurable timeout (5 min default)

## Configuration Options

Edit `.github/workflow-orchestration.yml`:

```yaml
orchestration:
  settings:
    enabled: true # Enable/disable orchestration
    lock_timeout: 300 # Lock timeout in seconds
    verbose: true # Verbose logging

  phases:
    phase_name:
      - workflow: 'file.yml'
        description: 'Human-readable description'
        optional: true # Continue if fails
        condition: '...' # GitHub Actions expression
        inputs: # Pass to workflow_call
          key: value
```

## Troubleshooting

### Workflows Stuck?

```bash
# Check for stale locks
.github/scripts/git-lock.sh list

# Clean them up
.github/scripts/git-lock.sh cleanup
```

### Race Conditions Still Occurring?

```bash
# Run detector manually
.github/scripts/race-condition-detector.sh \
  --check-git \
  --check-files "." \
  --verbose
```

### Configuration Invalid?

```bash
# Validate YAML syntax
npm install yaml
node -e "
  const YAML = require('yaml');
  const fs = require('fs');
  const config = YAML.parse(fs.readFileSync('.github/workflow-orchestration.yml', 'utf8'));
  console.log('Valid:', config);
"
```

## Next Steps

1. ✅ **Test the orchestrator** with dry-run mode

   ```bash
   gh workflow run orchestrator.yml -f dry_run=true
   ```

2. ✅ **Monitor for race conditions** in the next few runs
   - Check workflow logs for race condition reports
   - Review lock acquisition/release logs

3. ✅ **Adjust execution order** if needed
   - Edit `.github/workflow-orchestration.yml`
   - Test with dry-run before committing

4. ✅ **Customize for your workflow**
   - Mark optional workflows
   - Add conditional execution
   - Configure multi-pass workflows

## Full Documentation

See `.github/WORKFLOW_ORCHESTRATION.md` for:

- Detailed architecture
- Complete configuration reference
- Advanced usage examples
- Comprehensive troubleshooting
- FAQ

## Support

- **Documentation**: `.github/WORKFLOW_ORCHESTRATION.md`
- **Configuration**: `.github/workflow-orchestration.yml`
- **Troubleshooting**: Check Actions logs and run detector manually
- **Questions**: Review FAQ in full documentation
