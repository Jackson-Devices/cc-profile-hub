# Decision Log: Testing Strategy for Phase 1a Orchestration System

**Status**: Approved
**Date**: 2025-11-13
**Deciders**: Development Team
**Issue**: N/A (Internal Architecture)
**Session**: claude/test-suite-phase-1a-011CV57qZLfFHdq5Y4KkAo9Y

## Context and Problem Statement

The Phase 1a orchestration system includes several critical components (shellcheck-apply.sh, workflow automation, linting gates) that require comprehensive testing to ensure reliability. We need a testing strategy that:

1. Validates all Phase 1a components thoroughly
2. Uses appropriate test frameworks for each component type
3. Supports CI/CD integration
4. Enables rapid iteration and debugging
5. Provides clear test documentation

## Decision Drivers

- **Reliability**: Critical infrastructure must be well-tested
- **Developer Experience**: Tests should be easy to write, run, and debug
- **CI Integration**: Tests must run reliably in CI environments
- **Coverage**: Must test success paths, failure paths, and edge cases
- **Maintainability**: Test code should be clean and well-documented
- **Performance**: Tests should run quickly to enable fast feedback

## Considered Options

### Test Framework Options

1. **bats-core** (Bash Automated Testing System)
   - Pros: Native bash testing, designed for shell scripts
   - Cons: Limited ecosystem, less sophisticated tooling, bash-only

2. **Node.js Native Test Runner**
   - Pros: Built-in (no deps), great tooling, can test both .sh and .mjs
   - Cons: Requires Node 18+

3. **Jest/Mocha**
   - Pros: Mature, full-featured
   - Cons: External dependencies, heavier weight

## Decision Outcome

**Chosen option**: "Node.js Native Test Runner"

### Rationale

1. **Already in the stack**: Project uses Node.js for `.mjs` scripts
2. **No external dependencies**: Built-in since Node 18
3. **Superior tooling**:
   - Native snapshot testing
   - Better assertion libraries
   - Easy mocking/stubbing
   - Parallel test execution
   - Watch mode
4. **Versatile**: Can test both shell scripts (via child_process) and JavaScript
5. **Better DX**: TAP output, spec reporter, JSON output options
6. **Future-proof**: Can expand to test other components easily

### Consequences

**Positive**:

- Single test framework for all Phase 1a components
- Rich ecosystem of Node.js testing patterns
- Easy snapshot testing for output verification
- Great CI integration
- Familiar to most developers
- Built-in watch mode for TDD

**Negative**:

- Requires Node 18+ (acceptable, widely available)
- Slight learning curve for pure bash developers (mitigated by good docs)

**Neutral**:

- Shell scripts tested via spawning (standard practice)

## Testing Strategy by Component

### 1. shellcheck-apply.sh

**Component Type**: Shell script with complex logic
**Test Approach**: Integration + Unit tests

#### Test Categories

**Integration Tests** (Primary):

- **Conservative Strategy Tests**
  - Quote variables in test contexts only
  - Preserve intentional word splitting
  - Handle already-clean scripts
  - Backup creation and removal

- **Balanced Strategy Tests**
  - Fix SC2086 in common contexts (GitHub Actions variables)
  - Fix multiple SC code types (SC2006, SC2046, SC2164)
  - Report total fixes applied
  - Verify shellcheck passes after fixes

- **Aggressive Strategy Tests**
  - Fix all SC2086 violations
  - May break intentional word splitting (expected)
  - Handle complex mixed errors

- **Multi-pass Logic Tests**
  - Perform multiple passes when needed
  - Respect max-passes limit
  - Stop when no more fixes applied
  - Show progress for each pass

- **Failure Scenario Tests**
  - Exit with correct error codes (0, 1, 2, 3, 4)
  - Restore backup on failure
  - Handle file not found
  - Handle invalid arguments
  - Show remaining issues
  - Dry-run mode

- **Strategy Escalation Tests**
  - Escalate conservative → balanced
  - Escalate balanced → aggressive
  - Full escalation chain
  - No escalation when disabled
  - Reset passes on escalation

**Unit Tests** (Secondary, Future):

- Individual fix functions (fix_sc2086, fix_sc2046, etc.)
- Strategy selection logic
- Line parsing and replacement
- Backup/restore operations

**Snapshot Tests**:

- Output format verification
- Success messages
- Error messages
- Progress indicators

#### Test Fixtures

Create mock scripts with known violations:

- `broken_script_sc2086.sh` - Unquoted variables
- `broken_script_sc2046.sh` - Unquoted command substitution
- `broken_script_sc2006.sh` - Backticks
- `broken_script_sc2164.sh` - cd without error check
- `mixed_errors.sh` - Multiple SC codes
- `already_clean.sh` - Already passes shellcheck
- `intentional_word_splitting.sh` - Should preserve behavior

#### Test Structure

```
tests/
├── integration/
│   └── shellcheck-apply/
│       ├── conservative-strategy.test.js
│       ├── balanced-strategy.test.js
│       ├── aggressive-strategy.test.js
│       ├── multi-pass.test.js
│       ├── failure-scenarios.test.js
│       └── strategy-escalation.test.js
├── unit/
│   └── shellcheck-apply/
│       ├── fix-functions.test.js
│       ├── strategy-selection.test.js
│       ├── max-passes.test.js
│       └── backup-restore.test.js
├── fixtures/
│   └── mock_scripts/
├── snapshots/
│   └── shellcheck-apply/
└── helpers/
    ├── shell-runner.js
    ├── temp-fs.js
    └── snapshot-matcher.js
```

### 2. Future Phase 1a Components

**Workflow Linting**:

- Test YAML workflow file validation
- Test shellcheck integration
- Test auto-fix application

**GitHub Actions Integration**:

- Test workflow triggers
- Test permission handling
- Test commit creation

## Test Principles

### 1. Hermetic Tests

All tests must be hermetic (no side effects):

- Use temporary directories for file operations
- Clean up all resources in `afterEach` hooks
- Never modify files in the actual repository
- Mock external dependencies where appropriate

### 2. Given/When/Then Structure

All tests follow this pattern:

```javascript
test('descriptive test name', async () => {
  // Given: Setup and preconditions
  const workspace = await createTempWorkspace(fixture);

  // When: Execute the action being tested
  const result = await runShellcheckApply(args);

  // Then: Assert expected outcomes
  assert.strictEqual(result.exitCode, 0);
  assert.ok(await shellcheckPasses(workspace.filePath));

  // Cleanup handled by afterEach
});
```

### 3. Test Both Success and Failure

Every component must test:

- ✅ Success paths (happy path)
- ❌ Failure paths (error handling)
- 🔍 Edge cases (boundary conditions)

### 4. Descriptive Test Names

Test names should describe what they verify:

- ✅ Good: `should quote variables in test contexts only`
- ❌ Bad: `test conservative strategy`

### 5. Fast Feedback

- Tests should run quickly (< 30s total for shellcheck-apply)
- Use parallel execution where safe
- Provide clear, actionable error messages
- Support watch mode for TDD

## Test Infrastructure

### Helper Utilities

**shell-runner.js**:

- Run shellcheck-apply.sh with arguments
- Run shellcheck directly on files
- Check if file passes shellcheck
- Get violations for specific SC codes

**temp-fs.js**:

- Create temporary directories
- Copy fixtures to temp locations
- Create test files with content
- Read file content
- Clean up temporary files

**snapshot-matcher.js**:

- Match output against snapshots
- Update snapshots when needed
- Match output patterns
- Assert output doesn't contain patterns

### Test Runner

**run-shellcheck-tests.js**:

- Find and run all test files
- Check prerequisites (Node.js, shellcheck)
- Support command-line options:
  - `--verbose` - Detailed output
  - `--watch` - Watch mode
  - `--bail` - Stop on first failure
  - `--grep=PATTERN` - Filter tests
  - `--update-snapshots` - Update snapshot files
- Provide clear summary and exit codes

## CI Integration

Tests will integrate with GitHub Actions:

```yaml
- name: Run shellcheck-apply tests
  run: node tests/run-shellcheck-tests.js --verbose

- name: Verify test coverage
  run: node tests/run-shellcheck-tests.js --grep=integration
```

## Documentation Requirements

1. **tests/README.md**: Comprehensive test documentation
   - How to run tests
   - How to add new tests
   - Test fixture format
   - Snapshot update process
   - Troubleshooting guide

2. **Inline Comments**: All test helpers should have JSDoc comments

3. **Test Comments**: Complex test scenarios should have explanatory comments

## Success Criteria

Phase 1a testing is complete when:

1. ✅ All shellcheck-apply.sh strategies tested
2. ✅ Multi-pass logic tested
3. ✅ Failure scenarios tested
4. ✅ Strategy escalation tested
5. ✅ All tests passing
6. ✅ Test coverage > 80% for critical paths
7. ✅ Test documentation complete
8. ✅ CI integration working

## Future Enhancements

**Phase 1b+**:

- Add performance benchmarks
- Add mutation testing
- Add integration tests for full workflow automation
- Add E2E tests with actual GitHub Actions
- Add security testing (injection attacks, etc.)

## References

- Node.js Test Runner: https://nodejs.org/api/test.html
- Shellcheck: https://www.shellcheck.net/
- Testing Best Practices: https://testingjavascript.com/

## Decision Review

**Review Date**: 2025-12-13 (1 month)
**Reviewers**: Development Team

**Questions to Answer**:

1. Are tests providing adequate coverage?
2. Are tests catching real bugs?
3. Is test execution time acceptable?
4. Are tests easy to maintain?
5. Should we add additional test categories?

---

**Last Updated**: 2025-11-13
**Status**: ✅ Implemented for shellcheck-apply.sh
