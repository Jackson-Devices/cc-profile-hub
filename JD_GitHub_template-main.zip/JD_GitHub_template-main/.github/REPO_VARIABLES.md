# Repository Variables Configuration

This document describes all GitHub repository variables used by the workflows in this template.

## How to Set Repository Variables

1. Navigate to your repository on GitHub
2. Go to **Settings** → **Secrets and variables** → **Actions** → **Variables** tab
3. Click **New repository variable**
4. Enter the name and value
5. Click **Add variable**

## Required Variables

These variables should be configured for your repository. If not set, workflows will use the default values shown below.

---

### Security & Access Control

#### `OWNER_ALLOWLIST`

- **Description**: Comma-separated list of allowed repository owner names for label sync operations
- **Default**: `"Jackson-Devices"`
- **Example**: `"Jackson-Devices,AnotherOrg"`
- **Used by**: `apply_settings.yml`
- **Purpose**: Restricts which GitHub organizations can run the label sync workflow (security guardrail)

#### `ACTOR_ALLOWLIST`

- **Description**: Comma-separated list of allowed GitHub usernames that can trigger label sync
- **Default**: `"Jackson-Devices"`
- **Example**: `"username1,username2,username3"`
- **Used by**: `apply_settings.yml`
- **Purpose**: Restricts which users can run the label sync workflow (security guardrail)

#### `ON_GUARD_ACTION`

- **Description**: Action to take when a security guardrail is violated
- **Default**: `"fail"`
- **Allowed values**: `fail`, `warn`, `open_issue`, `skip`
- **Used by**: `apply_settings.yml`
- **Purpose**:
  - `fail` - Exit workflow with error code
  - `warn` - Log warning and exit gracefully
  - `open_issue` - Create GitHub issue documenting violation, then exit gracefully
  - `skip` - Log warning and continue workflow

---

### Label Sync Configuration

#### `STRICT_LABEL_SYNC`

- **Description**: Whether to delete labels not defined in settings.yml
- **Default**: `"true"`
- **Allowed values**: `"true"`, `"false"`
- **Used by**: `apply_settings.yml`
- **Purpose**: When true, any labels in the repository not listed in `.github/settings.yml` will be automatically deleted

---

### Test Validation Requirements

#### `IB_MIN_REQUIRED`

- **Description**: Minimum number of In-Bounds (IB) test cases required for validation gate
- **Default**: `"1"`
- **Example**: `"2"`
- **Used by**: `enforce_test_gate.yml`, `seed-test-runlist.yml`
- **Purpose**: Enforces minimum IB test case count before validation gate can be checked

#### `OOB_MIN_REQUIRED`

- **Description**: Minimum number of Out-of-Bounds (OOB) test cases required for validation gate
- **Default**: `"2"`
- **Example**: `"3"`
- **Used by**: `enforce_test_gate.yml`, `seed-test-runlist.yml`
- **Purpose**: Enforces minimum OOB test case count before validation gate can be checked

---

### Code Quality Gates

#### `AUTO_FIX_FORMAT`

- **Description**: Whether the format gate should auto-fix formatting issues
- **Default**: `"true"`
- **Allowed values**: `"true"`, `"false"`
- **Used by**: `format-gate.yml`
- **Purpose**: When true, format drift is automatically fixed and committed. When false, format issues will fail the gate with instructions to fix locally.

#### `AUTO_FIX_ESLINT`

- **Description**: Whether the ESLint gate should auto-fix linting issues
- **Default**: `"true"`
- **Allowed values**: `"true"`, `"false"`
- **Used by**: `eslint-gate.yml`
- **Purpose**: When true, ESLint issues are automatically fixed and committed. When false, lint issues will fail the gate with instructions to fix locally.

---

## Variable Usage Matrix

| Variable            | apply_settings.yml | context-commands.yml | enforce_test_gate.yml | seed-test-runlist.yml | format-gate.yml | eslint-gate.yml |
| ------------------- | ------------------ | -------------------- | --------------------- | --------------------- | --------------- | --------------- |
| `OWNER_ALLOWLIST`   | ✅                 | ❌                   | ❌                    | ❌                    | ❌              | ❌              |
| `ACTOR_ALLOWLIST`   | ✅                 | ❌                   | ❌                    | ❌                    | ❌              | ❌              |
| `ON_GUARD_ACTION`   | ✅                 | ❌                   | ❌                    | ❌                    | ❌              | ❌              |
| `STRICT_LABEL_SYNC` | ✅                 | ❌                   | ❌                    | ❌                    | ❌              | ❌              |
| `IB_MIN_REQUIRED`   | ❌                 | ❌                   | ✅                    | ✅                    | ❌              | ❌              |
| `OOB_MIN_REQUIRED`  | ❌                 | ❌                   | ✅                    | ✅                    | ❌              | ❌              |
| `AUTO_FIX_FORMAT`   | ❌                 | ❌                   | ❌                    | ❌                    | ✅              | ❌              |
| `AUTO_FIX_ESLINT`   | ❌                 | ❌                   | ❌                    | ❌                    | ❌              | ✅              |

---

## Default Behavior

**All workflows are designed to work with sensible defaults if no variables are set.**

If you don't configure any repository variables:

- Label sync will only allow `Jackson-Devices` organization and actor
- Strict label sync will be enabled (unlisted labels deleted)
- Test validation requires ≥1 IB and ≥2 OOB cases
- Security violations will fail the workflow
- Format gate will auto-fix formatting issues
- ESLint gate will auto-fix linting issues

---

## Testing Your Configuration

After setting variables, test them by:

1. **Label sync**: Run `apply_settings.yml` in dry_run mode first
2. **Test validation**: Create a test issue with `type: test` label and various IB/OOB counts
3. **Concurrency**: Try triggering workflows simultaneously on the same issue

---

**Last Updated**: 2025-11-07
**Template Version**: 1.3
