# Workflow Orchestration System

## Overview

This repository uses a sophisticated workflow orchestration system to prevent race conditions and ensure workflows execute in a controlled, sequential manner. The system provides:

- **Race condition prevention** through file-based locking and concurrency controls
- **Sequential workflow execution** with configurable ordering
- **Easy reordering** via a single configuration file
- **Individual workflow testing** capability
- **Multi-pass support** for running workflows multiple times
- **Comprehensive race condition detection**

## Table of Contents

- [Architecture](#architecture)
- [Key Components](#key-components)
- [Configuration](#configuration)
- [Usage](#usage)
- [Testing Individual Workflows](#testing-individual-workflows)
- [Troubleshooting](#troubleshooting)
- [FAQ](#faq)

## Architecture

The orchestration system consists of four main components:

1. **Configuration File** (`.github/workflow-orchestration.yml`)
   - Single source of truth for workflow execution order
   - Defines phases and workflow sequences
   - Easy to modify without touching workflow files

2. **Orchestrator Workflow** (`.github/workflows/orchestrator.yml`)
   - Reads the configuration file
   - Executes workflows in the defined order
   - Manages locks and prevents concurrent execution
   - Provides dry-run mode for testing

3. **Race Condition Detection** (`.github/scripts/race-condition-detector.sh`)
   - Detects concurrent workflow runs
   - Identifies potential race conditions
   - Reports findings in workflow summaries

4. **Git Lock Utility** (`.github/scripts/git-lock.sh`)
   - Provides file-based locking for git operations
   - Prevents concurrent git push/commit operations
   - Automatic stale lock detection and cleanup

## Key Components

### 1. Workflow Orchestration Configuration

**File:** `.github/workflow-orchestration.yml`

This YAML file defines the execution order and dependencies for all workflows. It's organized into phases:

```yaml
orchestration:
  phases:
    pre_checks:
      - workflow: 'format-check.yml'
        description: 'Check code formatting'
        optional: true

    linting:
      - workflow: 'eslint-apply.yml'
        description: 'Auto-fix ESLint issues'
        inputs:
          auto_commit: true
```

**Key Features:**

- **Phases**: Logical grouping of workflows (e.g., pre_checks, linting, formatting)
- **Workflow definitions**: Each workflow entry can specify inputs and conditions
- **Optional workflows**: Marked workflows won't fail the entire orchestration
- **Conditional execution**: Workflows can be conditionally executed based on context

### 2. Orchestrator Workflow

**File:** `.github/workflows/orchestrator.yml`

The main orchestrator that executes workflows in sequence.

**Triggers:**

- Manual (`workflow_dispatch`)
- Push to main or claude/\*\* branches
- Pull requests to main

**Key Features:**

- **Phase selection**: Run specific phases or all phases
- **Dry run mode**: Preview what would be executed without running
- **Lock management**: Acquires locks before execution
- **Race condition detection**: Automatically checks for conflicts

**Usage:**

```bash
# Run all workflows in orchestrated sequence
gh workflow run orchestrator.yml

# Run only formatting phase
gh workflow run orchestrator.yml -f phase=formatting

# Dry run to preview execution
gh workflow run orchestrator.yml -f dry_run=true

# Skip race detection
gh workflow run orchestrator.yml -f skip_race_detection=true
```

### 3. Concurrency Controls

Every workflow now includes a concurrency group to prevent parallel execution:

```yaml
concurrency:
  group: workflow-name-${{ github.repository }}-${{ github.ref }}
  cancel-in-progress: false
```

**Concurrency Groups:**

- **Repository-scoped**: Most workflows use `${{ github.repository }}`
- **Branch-scoped**: Many include `${{ github.ref }}` for per-branch locking
- **Issue-scoped**: Issue-related workflows use `${{ github.event.issue.number }}`

**Important:** `cancel-in-progress: false` ensures workflows complete before new ones start, rather than canceling ongoing work.

### 4. Race Condition Detection

**File:** `.github/scripts/race-condition-detector.sh`

Detects and reports race conditions across multiple dimensions:

- **Concurrent workflows**: Identifies other running workflows
- **Git operations**: Detects locked git operations
- **File access**: Checks for concurrent file modifications
- **Pattern matching**: Identifies common race condition patterns

**Usage:**

```bash
# Run race condition detection
.github/scripts/race-condition-detector.sh \
  --workflow-name "My Workflow" \
  --check-git \
  --check-files ".github/workflows,src"

# Report-only mode (won't fail on detection)
.github/scripts/race-condition-detector.sh --report-only
```

### 5. Git Lock Utility

**File:** `.github/scripts/git-lock.sh`

Provides file-based locking to prevent concurrent git operations.

**Usage in Shell:**

```bash
# Source the script
source .github/scripts/git-lock.sh

# Acquire lock, perform operation, release lock
git_lock_acquire "my-operation"
git push origin HEAD
git_lock_release "my-operation"

# Or use the wrapper function
with_git_lock "my-operation" git push origin HEAD
```

**Usage in Workflows:**

```yaml
- name: Push with lock protection
  run: |
    source .github/scripts/git-lock.sh
    with_git_lock "push-changes" git push origin HEAD
```

**Features:**

- Automatic stale lock detection (10 minutes default)
- Configurable timeout (5 minutes default)
- Lock ownership tracking
- Verbose logging mode

## Configuration

### Modifying Workflow Order

To change the execution order, edit `.github/workflow-orchestration.yml`:

**Example: Change phase order**

```yaml
orchestration:
  phases:
    # Phases execute in the order listed
    pre_checks:
      # ...
    linting:
      # ...
    formatting:
      # Workflows within a phase also execute in order
      - workflow: 'format-apply.yml'
        description: 'First format pass'
      - workflow: 'eslint-apply.yml'
        description: 'ESLint after formatting'
```

**Example: Add a new workflow**

```yaml
phases:
  validation:
    - workflow: 'my-new-validator.yml'
      description: 'Custom validation'
      optional: true # Won't fail orchestration if this fails
```

**Example: Multi-pass execution**

```yaml
phases:
  formatting:
    - workflow: 'format-apply.yml'
      description: 'First format pass'

  validation:
    # ... other workflows ...

  post_checks:
    - workflow: 'format-apply.yml'
      description: 'Second format pass after validation'
```

### Configuration Options

**Global Settings:**

```yaml
orchestration:
  settings:
    enabled: true # Enable/disable orchestration
    lock_timeout: 300 # Lock timeout in seconds
    verbose: true # Enable verbose logging
```

**Workflow Options:**

```yaml
- workflow: 'my-workflow.yml'
  description: 'Human-readable description'
  optional: true # Continue if this workflow fails
  condition: "github.ref == 'refs/heads/main'" # Conditional execution
  inputs: # Pass inputs to workflow_call workflows
    auto_commit: true
    commit_message: 'Custom message'
```

## Usage

### Running the Orchestrator

**Method 1: GitHub UI**

1. Go to "Actions" tab
2. Select "Workflow Orchestrator"
3. Click "Run workflow"
4. Select options:
   - Phase (default: all)
   - Dry run (default: false)
   - Skip race detection (default: false)

**Method 2: GitHub CLI**

```bash
# Run all workflows
gh workflow run orchestrator.yml

# Run specific phase
gh workflow run orchestrator.yml -f phase=formatting

# Dry run
gh workflow run orchestrator.yml -f dry_run=true

# Custom configuration
gh workflow run orchestrator.yml \
  -f phase=linting \
  -f dry_run=false \
  -f skip_race_detection=false
```

**Method 3: API**

```bash
curl -X POST \
  -H "Accept: application/vnd.github.v3+json" \
  -H "Authorization: token $GITHUB_TOKEN" \
  https://api.github.com/repos/OWNER/REPO/actions/workflows/orchestrator.yml/dispatches \
  -d '{"ref":"main","inputs":{"phase":"all","dry_run":"false"}}'
```

### Monitoring Execution

**View Orchestrator Logs:**

1. Go to Actions → Workflow Orchestrator → Latest run
2. Click on phase jobs to see execution details
3. Review step summaries for race condition reports

**Check Lock Status:**

```bash
# In a workflow or locally
.github/scripts/git-lock.sh list

# Clean up stale locks
.github/scripts/git-lock.sh cleanup
```

## Testing Individual Workflows

All workflows can still be run individually for testing, even when orchestration is enabled.

### Manual Trigger

Most workflows support `workflow_dispatch`:

```bash
# Run format-apply manually
gh workflow run format-apply.yml -f auto_commit=false

# Run with custom inputs
gh workflow run eslint-apply.yml \
  -f auto_commit=true \
  -f commit_message="fix: manual eslint fixes"
```

### Trigger by Event

Workflows also run on their normal triggers:

```bash
# Push to branch triggers format-gate, eslint-gate, etc.
git push origin feature-branch

# Opening PR triggers PR-related workflows
gh pr create --title "My Feature" --body "Description"
```

### Testing with Concurrency

When testing individually, concurrency controls still apply:

- Only one instance of each workflow runs at a time
- If orchestrator is running, individual workflows will wait
- Use unique branch names to test in parallel on different branches

**Example: Test on isolated branch**

```bash
# Create test branch
git checkout -b test/my-workflow-$(date +%s)

# Trigger workflow
git push origin HEAD

# Workflow runs independently of other branches
```

## Troubleshooting

### Common Issues

#### 1. Workflow Stuck Waiting for Lock

**Symptoms:**

- Workflow shows "Acquiring execution lock" for extended period
- No progress after several minutes

**Solutions:**

```bash
# Check for stale locks
.github/scripts/git-lock.sh list

# Clean up stale locks
.github/scripts/git-lock.sh cleanup

# Check concurrent workflows
# Go to Actions tab and look for other running workflows
```

#### 2. Race Conditions Still Occurring

**Symptoms:**

- Git push failures with "rejected" errors
- Conflicting file modifications
- Unexpected workflow behavior

**Diagnosis:**

```bash
# Run race condition detector manually
.github/scripts/race-condition-detector.sh \
  --workflow-name "Debug" \
  --check-git \
  --check-files "." \
  --verbose
```

**Solutions:**

- Verify all workflows have concurrency controls
- Check lock acquisition in workflow logs
- Ensure git operations use git-lock.sh wrapper

#### 3. Orchestrator Configuration Invalid

**Symptoms:**

- Orchestrator fails in "Initialize" step
- Configuration validation errors

**Solutions:**

```bash
# Validate YAML syntax locally
npm install yaml
node -e "
  const fs = require('fs');
  const YAML = require('yaml');
  const content = fs.readFileSync('.github/workflow-orchestration.yml', 'utf8');
  const config = YAML.parse(content);
  console.log('Configuration valid:', config);
"
```

#### 4. Workflows Not Running in Order

**Symptoms:**

- Workflows execute in unexpected order
- Dependencies not respected

**Causes:**

- Phases may run in parallel if misconfigured
- Check `max-parallel` setting in orchestrator
- Verify phase dependencies

**Solutions:**

- Review `.github/workflows/orchestrator.yml`
- Ensure `strategy.max-parallel: 1`
- Check workflow-orchestration.yml phase order

### Debug Mode

Enable verbose logging for troubleshooting:

**In Orchestrator:**

```yaml
# .github/workflow-orchestration.yml
orchestration:
  settings:
    verbose: true
```

**In Scripts:**

```bash
# Enable verbose logging
export GIT_LOCK_VERBOSE=true
export VERBOSE=true

.github/scripts/git-lock.sh list
.github/scripts/race-condition-detector.sh --verbose
```

## FAQ

### Q: Do I need to use the orchestrator for every change?

**A:** No. The orchestrator is optional. Individual workflows will still work normally on their own triggers (push, PR, etc.). The orchestrator is useful when you want to ensure a specific execution order or when debugging race conditions.

### Q: How do I disable orchestration temporarily?

**A:** Edit `.github/workflow-orchestration.yml`:

```yaml
orchestration:
  settings:
    enabled: false
```

### Q: Can workflows run in parallel on different branches?

**A:** Yes. Concurrency groups are scoped to `${{ github.ref }}` (the branch), so:

- `main` branch workflows won't conflict with `feature-branch` workflows
- Different PR branches can run workflows simultaneously
- Only workflows on the _same branch_ are serialized

### Q: What happens if a workflow fails during orchestration?

**A:** Depends on the `optional` flag:

- **optional: false** (default): Orchestration stops, subsequent workflows don't run
- **optional: true**: Failure is logged, orchestration continues

### Q: How do I add a new workflow to orchestration?

**A:**

1. Create your workflow file in `.github/workflows/`
2. Add concurrency control to the workflow
3. Add it to `.github/workflow-orchestration.yml` in the appropriate phase
4. Test with dry-run: `gh workflow run orchestrator.yml -f dry_run=true`

### Q: Can I run just one phase?

**A:** Yes:

```bash
gh workflow run orchestrator.yml -f phase=formatting
```

Available phases: `pre_checks`, `linting`, `formatting`, `validation`, `maintenance`, `post_checks`, or `all`

### Q: How long do locks last?

**A:**

- **Active locks**: Until released by the workflow
- **Stale locks**: Auto-cleaned after 10 minutes
- **Timeout**: Lock acquisition fails after 5 minutes of waiting
- Configure via environment variables:
  ```bash
  export GIT_LOCK_TIMEOUT=300       # 5 minutes
  export GIT_LOCK_STALE_AGE=600     # 10 minutes
  ```

### Q: What if I need workflows to run in parallel?

**A:** For specific workflows that don't conflict:

1. Remove them from orchestration (add to `unorchestrated` list)
2. Adjust their concurrency groups to allow parallel execution
3. Document why they're safe to run in parallel

### Q: How do I monitor race conditions in production?

**A:** Race condition detector runs automatically in orchestrator. To monitor manually:

```bash
# Add to any workflow
- name: Check for race conditions
  run: |
    .github/scripts/race-condition-detector.sh \
      --workflow-name "${{ github.workflow }}" \
      --check-git \
      --report-only
```

## Files Modified

This orchestration system modified or created the following files:

### New Files

- `.github/workflow-orchestration.yml` - Configuration file
- `.github/workflows/orchestrator.yml` - Main orchestrator workflow
- `.github/scripts/git-lock.sh` - Git lock utility
- `.github/scripts/race-condition-detector.sh` - Race condition detection
- `.github/WORKFLOW_ORCHESTRATION.md` - This documentation

### Modified Files (Added Concurrency Controls)

- `.github/workflows/apply_settings.yml`
- `.github/workflows/auto-squash-commits.yml`
- `.github/workflows/context-commands.yml`
- `.github/workflows/decision_log_writer.yml`
- `.github/workflows/docs-drift-gate.yml`
- `.github/workflows/enforce_test_gate.yml`
- `.github/workflows/eslint-apply.yml`
- `.github/workflows/eslint-check.yml`
- `.github/workflows/eslint-gate.yml`
- `.github/workflows/format-apply.yml`
- `.github/workflows/format-check.yml`
- `.github/workflows/format-gate.yml`
- `.github/workflows/issue-mirror-sync.yml`
- `.github/workflows/lint-check.yml`
- `.github/workflows/pr-risk-check.yml`
- `.github/workflows/pr-risk-gate.yml`
- `.github/workflows/prevent-sequential-commits-gate.yml`
- `.github/workflows/seed-test-runlist.yml`
- `.github/workflows/validate-function.yml`
- `.github/workflows/validate-issue.yml`
- `.github/workflows/validate-sub-feature.yml`
- `.github/workflows/validate-test-suite.yml`
- `.github/workflows/workflow-lint-apply.yml`
- `.github/workflows/workflow-lint-gate.yml`

All 24 workflows now have race condition protection!

## Support

For issues or questions:

1. Check the [Troubleshooting](#troubleshooting) section
2. Review workflow logs in the Actions tab
3. Run race condition detector manually
4. Check for stale locks with `git-lock.sh list`

## Best Practices

1. **Always test in dry-run mode first**

   ```bash
   gh workflow run orchestrator.yml -f dry_run=true
   ```

2. **Use descriptive workflow descriptions** in orchestration config

3. **Mark optional workflows appropriately**
   - Checks/lints: optional
   - Critical validations: required

4. **Monitor lock usage** regularly

   ```bash
   .github/scripts/git-lock.sh list
   ```

5. **Clean up stale locks** periodically (automated in orchestrator)

6. **Test individual workflows** before adding to orchestration

7. **Document workflow dependencies** in configuration comments

8. **Use phases logically**:
   - pre_checks: Fast validation
   - linting/formatting: Auto-fixes
   - validation: Comprehensive checks
   - maintenance: Housekeeping
   - post_checks: Final verification
