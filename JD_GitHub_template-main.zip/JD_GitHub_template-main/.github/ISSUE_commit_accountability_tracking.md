# FUNCTION: Commit Accountability Tracking Hook

## Overview

Pre-commit hook that tracks commits without issue links, warns users, and provides session-end reporting to help retroactively organize work.

**Problem**: AI tools (like claude.ai/code) may commit work without linking to issues, making it hard to track what was done and why.

**Solution**: Hook that:

1. Detects commits without issue links
2. Warns but allows commit (with random character confirmation)
3. Logs unlinked commits to session log
4. Provides session summary at end

---

## Technical Approach

### Hook Type: `commit-msg`

**File**: `scripts/commit-msg-issue-link-warning.sh`

**Trigger**: Every commit

**Detection Logic**:

```bash
# Detect any GitHub issue link format
# Matches: #123, fixes #123, closes #456, resolves #789, etc.
ISSUE_PATTERN='(#[0-9]+|[Ff]ixes #[0-9]+|[Cc]loses #[0-9]+|[Rr]esolves #[0-9]+)'

if ! grep -qE "$ISSUE_PATTERN" "$COMMIT_MSG_FILE"; then
  # No issue link found - warn and prompt
fi
```

**Random Override**:

```bash
# Generate single random character (alphanumeric)
OVERRIDE_CODE=$(LC_ALL=C tr -dc 'A-Za-z0-9' </dev/urandom | head -c 1)
echo "⚠️  No issue linked. Type '$OVERRIDE_CODE' to proceed anyway:"
read -r USER_INPUT

if [ "$USER_INPUT" != "$OVERRIDE_CODE" ]; then
  echo "❌ Commit cancelled"
  exit 1
fi
```

**Session Logging**:

```bash
# Log to .git/AI_SESSION_LOG.md
LOG_FILE=".git/AI_SESSION_LOG.md"

{
  echo "## Unlinked Commit: $(date -Iseconds)"
  echo "- **Branch**: $CURRENT_BRANCH"
  echo "- **Message**: $(head -1 $COMMIT_MSG_FILE)"
  echo "- **Author**: $(git config user.name)"
  echo ""
} >> "$LOG_FILE"
```

---

## Session End Reporting

**File**: `scripts/report-session-commits.sh`

**Usage**: `./scripts/report-session-commits.sh`

**Output**:

```markdown
# AI Session Commit Report

Generated: 2025-11-12 05:00:00

## Summary

- Total commits this session: 5
- Linked to issues: 3
- Unlinked commits: 2

## Linked Commits ✅

1. `abc1234` feat: add validation CLI (#26)
2. `def5678` fix: update schema (#27)
3. `ghi9012` docs: add examples (#28)

## Unlinked Commits ⚠️

1. `jkl3456` on branch `claude/ac5-ac6-validation-helpers-011CV2z...`
   - Message: "feat(docs): implement AC5 Validation CLI Tool"
   - Suggestion: Link to issue #26?

2. `mno7890` on branch `claude/fix-format-workflows-011CV4B...`
   - Message: "fix: workflow permissions"
   - Suggestion: Create new issue for workflow fixes?

## Actions

Would you like help:

1. Creating issues for unlinked commits?
2. Amending commit messages to add issue links?
3. Updating PR descriptions with issue references?
```

---

## Grouping Logic

Since we enforce **one commit per branch**, grouping is straightforward:

```bash
# One branch = one commit = should link to one issue
BRANCH_NAME=$(git rev-parse --abbrev-ref HEAD)
COMMIT_HASH=$(git rev-parse HEAD)
COMMIT_MSG=$(git log -1 --pretty=%s)

# Log with branch as primary key
echo "- Branch: $BRANCH_NAME → Commit: $COMMIT_HASH → Issue: NONE" >> .git/AI_SESSION_LOG.md
```

---

## Hook Behavior

### Scenario 1: Commit with issue link

```bash
git commit -m "feat: add validation (#26)"
```

**Output**: ✅ Silent success (issue linked)

---

### Scenario 2: Commit without issue link

```bash
git commit -m "feat: add validation"
```

**Output**:

```
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
⚠️  NO ISSUE LINK DETECTED
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

📋 Commit message: "feat: add validation"
🔗 No issue reference found (e.g., #123, fixes #456)

💡 This commit will be logged as UNLINKED for session review.

⚠️  Are you sure this isn't related to an issue?

To proceed, type this random character: K
> _
```

**If user types 'K'**: Commit proceeds, logged to session file
**If user types anything else**: Commit cancelled

---

### Scenario 3: Session end report

```bash
./scripts/report-session-commits.sh
```

**Output**: Markdown report with:

- All commits from current session
- Which ones have issue links
- Which ones don't
- Suggestions for linking based on branch names/commit messages
- Offers to help create issues or amend commits

---

## Installation

```bash
# Install hook
./scripts/install-issue-link-hook.sh

# View session report
./scripts/report-session-commits.sh

# Clear session log
rm .git/AI_SESSION_LOG.md
```

---

## Integration with Existing Hooks

**Chain with other commit-msg hooks**:

```bash
# .git/hooks/commit-msg
#!/bin/bash

# Run sequential commit warning (informational)
./scripts/commit-msg-sequential-warning.sh "$@"

# Run issue link check (blocking with override)
./scripts/commit-msg-issue-link-warning.sh "$@"

# All must pass
exit $?
```

---

## Acceptance Criteria

- [ ] Detects any GitHub issue link format (#123, fixes #456, etc.)
- [ ] Warns on commits without issue links
- [ ] Requires random single character to override
- [ ] Logs unlinked commits to `.git/AI_SESSION_LOG.md`
- [ ] Session report shows linked vs unlinked commits
- [ ] Offers suggestions for linking based on branch/message context
- [ ] Works with one-commit-per-branch policy
- [ ] Chains with sequential commit warning hook

---

🤖 Generated with [Claude Code](https://claude.com/claude-code)

Co-Authored-By: Claude <noreply@anthropic.com>
