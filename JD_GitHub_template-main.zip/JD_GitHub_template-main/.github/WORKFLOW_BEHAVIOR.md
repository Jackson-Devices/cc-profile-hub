# Workflow Behavior Guide

This document describes how each GitHub Actions workflow in this template behaves, including triggers, concurrency handling, commands, and failure modes.

## Table of Contents

- [Code Formatting](#code-formatting) - Automated code formatting with Prettier
- [apply_settings.yml](#apply_settingsyml) - Label sync workflow
- [context-commands.yml](#context-commandsyml) - Context variable management
- [enforce_test_gate.yml](#enforce_test_gateyml) - Validation gate enforcement
- [seed-test-runlist.yml](#seed-test-runlistyml) - Test checklist generation

---

## Code Formatting

**Purpose**: Ensure consistent code style across all files to prevent formatting errors (especially in YAML/Markdown) that can break workflows.

### Overview

This repository uses **Prettier** as the primary code formatter, integrated into workflows that generate or modify files. Automatic formatting prevents common errors like malformed YAML in GitHub Actions workflows.

### Reusable Workflows

#### format-check.yml (Reusable)

**Purpose**: Check if files are properly formatted without modifying them.

**Usage**:

```yaml
jobs:
  check-formatting:
    uses: ./.github/workflows/format-check.yml
    with:
      files: '.'
      fail_on_error: true
```

**Inputs**:

- `files` (string, default: '.'): Files or glob patterns to check (space-separated)
- `fail_on_error` (boolean, default: false): Whether to fail the workflow if formatting issues are found

**Outputs**:

- `has_issues` (boolean): Whether formatting issues were found
- `formatted_count` (number): Number of files needing formatting

**Behavior**:

1. Installs Prettier and dependencies
2. Runs `prettier --check` on specified files
3. Outputs detailed report with file counts
4. Uploads format check output as artifact (7-day retention)
5. Optionally fails workflow if `fail_on_error=true`

#### format-apply.yml (Reusable)

**Purpose**: Apply code formatting to files and optionally commit changes.

**Usage**:

```yaml
jobs:
  apply-formatting:
    uses: ./.github/workflows/format-apply.yml
    with:
      files: '.'
      auto_commit: true
      commit_message: 'style: apply code formatting'
```

**Inputs**:

- `files` (string, default: '.'): Files or glob patterns to format
- `commit_message` (string, default: 'style: apply code formatting'): Commit message if changes are made
- `auto_commit` (boolean, default: false): Automatically commit formatting changes
- `committer_name` (string, default: 'github-actions[bot]'): Git committer name
- `committer_email` (string, default: 'github-actions[bot]@users.noreply.github.com'): Git committer email

**Outputs**:

- `changes_made` (boolean): Whether formatting changes were applied
- `files_changed` (number): Number of files changed
- `commit_sha` (string): SHA of commit if auto_commit=true

**Behavior**:

1. Installs Prettier and dependencies
2. Runs `prettier --write` on specified files
3. Detects if any files were modified
4. Optionally commits and pushes changes if `auto_commit=true`
5. Uploads formatting diff as artifact (7-day retention)

### Workflow Integration

Formatting is integrated into workflows that generate files:

**apply_settings.yml**:

- Checks `.github/settings.yml` formatting before validation
- Provides warnings if formatting issues detected
- Does not block execution (warnings only)

**decision_log_writer.yml**:

- Formats generated decision log markdown files (`.ai_logs/issue_NNNN_decision_log.md`)
- Applies formatting before committing log entries
- Ensures consistent markdown formatting in decision logs

### House Style Rules

See [docs/formatters/HOUSE_STYLE.md](../docs/formatters/HOUSE_STYLE.md) for detailed formatting rules and rationale.

**Quick Reference**:

- **YAML**: 2 spaces, 100 char width, double quotes
- **Markdown**: 100 char width, asterisks for emphasis, preserve prose wrap
- **JSON**: 2 spaces, no trailing commas, strict JSON compliance
- **JavaScript/TS**: 2 spaces, semicolons, single quotes, ES5 trailing commas

### Manual Formatting

**Format all files**:

```bash
npm run format
```

**Check formatting without changes**:

```bash
npm run format:check
```

**Format staged files only**:

```bash
npm run format:staged
```

### Why This Matters

Formatting errors in YAML/Markdown can break GitHub Actions workflows:

- **Malformed YAML**: Incorrect indentation breaks workflow parsing (see commit 6369e47)
- **Inconsistent quotes**: Mixed quote styles cause YAML parse errors
- **Line endings**: CRLF vs LF differences create noisy diffs

Automated formatting prevents these issues before they reach the repository.

---

## apply_settings.yml

**Purpose**: Syncs repository labels from `.github/settings.yml` configuration file.

### Triggers

- **Manual only**: `workflow_dispatch` (Actions tab)
- Never runs automatically

### Inputs

- `mode` (dropdown): `dry_run` (default, preview only) or `apply` (makes changes)
- `override` (boolean): `false` (default) or `true` (allows apply from non-main branch)

### Behavior

1. **Validation Phase**
   - Checks `.github/settings.yml` exists
   - Validates YAML syntax
   - Ensures `labels` array is present

2. **Preview Phase** (always runs)
   - Fetches existing labels from repository
   - Compares with desired state in settings.yml
   - Shows what would be renamed/created/updated/deleted
   - Respects security guardrails (owner/actor allowlists)

3. **Apply Phase** (only when mode=apply)
   - Runs only on `main` branch (unless override=true)
   - Renames labels (preserves issue/PR attachments)
   - Creates new labels
   - Updates colors/descriptions
   - Deletes unlisted labels (if strict mode enabled)

### Concurrency

- **Group**: `label-sync-${{ github.repository }}`
- **Policy**: Queue (not cancel)
- **Scope**: Repository-level (only one label sync at a time)

### Configuration

All hardcoded values replaced with repository variables:

| Variable            | Default             | Purpose                    |
| ------------------- | ------------------- | -------------------------- |
| `OWNER_ALLOWLIST`   | `"Jackson-Devices"` | Allowed repo owners        |
| `ACTOR_ALLOWLIST`   | `"Jackson-Devices"` | Allowed workflow actors    |
| `ON_GUARD_ACTION`   | `"fail"`            | Guardrail violation action |
| `STRICT_LABEL_SYNC` | `"true"`            | Delete unlisted labels     |

See [REPO_VARIABLES.md](./REPO_VARIABLES.md) for details.

### Failure Modes

| Failure              | Behavior                                    |
| -------------------- | ------------------------------------------- |
| settings.yml missing | Validation fails with error message         |
| Invalid YAML syntax  | Validation fails with parse error           |
| Guardrail violation  | Action depends on `ON_GUARD_ACTION` setting |
| Network/API error    | Workflow fails, check logs for details      |

### Output

Workflow logs include:

- Summary table (renamed/created/updated/deleted/unchanged counts)
- Detailed list of each operation
- Configuration values used

---

## context-commands.yml

**Purpose**: Manages context variables in parent test suite issues via comment commands.

### Triggers

- Issue comments created or edited
- Only on issues with `type: test` label

### Commands

#### `/context set key="value"`

Sets a context variable in the parent issue's YAML block.

**Requirements**:

- Write permission or higher
- Parent issue reference in issue body
- Parent issue has a ` ```yaml` block

**Example**:

```
/context set commit_hash="abc123def"
```

**Result**:

- Updates parent issue YAML block
- Posts audit trail comment with timestamp
- Triggers `/context sync` automatically

#### `/context preview key="value"`

Shows what would change without applying.

**Example**:

```
/context preview commit_hash="abc123def"
```

**Result**:

- Posts comment showing old and new YAML blocks
- Does not modify anything

#### `/context show`

Displays current context from parent issue.

**Result**:

- Posts comment with parent issue YAML block

#### `/context sync`

Triggers re-seeding of Run checklist.

**Result**:

- Appends `<!-- resync -->` comment to issue body
- Triggers `seed-test-runlist.yml` workflow

### Concurrency

- **Group**: `context-commands-issue-${{ github.event.issue.number }}`
- **Policy**: Reject concurrent runs
- **Scope**: Per-issue

If another run is in progress on the same issue, the new run is rejected with a notification comment.

### Error Handling

| Error                   | Feedback                             |
| ----------------------- | ------------------------------------ |
| No write permission     | Comment explaining permission denied |
| Parent issue not found  | Comment with troubleshooting tips    |
| No YAML block in parent | Comment requesting YAML block        |
| Invalid key format      | Comment explaining allowed formats   |
| Network/API error       | Comment with error details           |

### Expected Issue Body Format

```
hier_parent: https://github.com/owner/repo/issues/123
```

or

```
Suite ... Issue URL: https://github.com/owner/repo/issues/123
```

Parent issue must contain:

````yaml
```yaml
key1: "value1"
key2: "value2"
```
````

---

## enforce_test_gate.yml

**Purpose**: Enforces validation gate requirements (minimum IB/OOB test cases).

### Triggers

- Issue opened or edited
- Only on issues with `type: test` label

### Behavior

1. **Extract Test Cases**
   - Scans issue body for `- IB-N` and `- OOB-N` patterns
   - Uses strict regex (no leading zeros)
   - Deduplicates and counts unique cases

2. **Check Validation Gate**
   - Finds `- [ ] ✅ test.validated = true` checkbox
   - Checks if it's checked (`[x]`)

3. **Enforce Requirements**
   - If gate checked but requirements not met:
     - Unchecks gate
     - Clears Run checklist (all checkboxes unchecked)
     - Posts detailed feedback comment
     - Updates labels: adds `workflow: blocked`, `validation: pending`
   - If gate checked and requirements met:
     - Posts success comment
     - Updates labels: adds `validation: passed`, removes `workflow: blocked`

### Configuration

| Variable           | Default | Purpose           |
| ------------------ | ------- | ----------------- |
| `IB_MIN_REQUIRED`  | `"1"`   | Minimum IB cases  |
| `OOB_MIN_REQUIRED` | `"2"`   | Minimum OOB cases |

### Concurrency

- **Group**: `enforce-gate-issue-${{ github.event.issue.number }}`
- **Policy**: Reject concurrent runs
- **Scope**: Per-issue

### Label Updates

Labels are updated in **batch** (single API call) for efficiency.

| Scenario       | Labels Added                               | Labels Removed                             |
| -------------- | ------------------------------------------ | ------------------------------------------ |
| Gate blocked   | `workflow: blocked`, `validation: pending` | `validation: passed`                       |
| Gate passed    | `validation: passed`                       | `workflow: blocked`, `validation: pending` |
| Gate unchecked | `validation: pending`                      | `validation: passed`                       |

### Error Handling

| Error                       | Feedback                                |
| --------------------------- | --------------------------------------- |
| Empty issue body            | Warning comment                         |
| No validation gate checkbox | Warning comment with expected format    |
| Insufficient test cases     | Detailed comment showing what's missing |

### Example Feedback

When gate is blocked:

```
❌ Validation gate blocked: requirements not met

**Requirements** (configurable via repository variables):
- IB cases: need ≥1, found **0**
- OOB cases: need ≥2, found **1**

**Found IB cases**: none
**Found OOB cases**: OOB-01

**Action taken**:
- ✅ Validation gate checkbox unchecked
- ✅ Run checklist auto-emptied
- ✅ Labels updated: `workflow: blocked`, `validation: pending`

**Next steps**:
1. Add missing test cases to meet requirements
2. If any case fails or code changes, re-run from the top
3. Check the validation gate when all cases pass

**Boundary order** (if applicable): OOB-01 → IB-01 → OOB-02
```

---

## seed-test-runlist.yml

**Purpose**: Automatically generates Run checklist for test issues with proper execution order.

### Triggers

#### Auto-seed

- Issue opened with `type: test` label
- Only runs once on creation

#### Manual /seed Commands

- Issue comments starting with `/seed`
- Allows conflict resolution

### Behavior

#### Auto-seed on Issue Open

1. **Extract Test Cases**
   - Scans for `- IB-N` and `- OOB-N` patterns
   - Uses strict regex (no leading zeros)

2. **Check Requirements**
   - Requires ≥1 IB and ≥2 OOB cases (configurable)
   - Posts warning if not met

3. **Generate Ordered Checklist**
   - **Ordering rule**: OOB-01 → IB-01 → OOB-02, then remaining OOBs and IBs ascending
   - Example: `OOB-01 → IB-01 → OOB-02 → OOB-03 → IB-02 → IB-03`

4. **Handle Existing Checklist**
   - If no checklist exists: creates it
   - If checklist exists: leaves it alone, suggests `/seed overwrite`

### Commands

#### `/seed overwrite`

Replaces existing Run checklist with freshly generated one.

**Use when**: You've added/removed test cases and want to regenerate the checklist.

**Example**:

```
/seed overwrite
```

**Result**:

- Replaces entire Run checklist
- All checkboxes reset to unchecked
- Posts audit comment with new order

#### `/seed keep`

Keeps existing checklist unchanged.

**Use when**: Workflow suggests overwrite but you want to preserve manual edits.

**Example**:

```
/seed keep
```

**Result**:

- No changes made
- Posts confirmation comment

#### `/seed merge`

Merges new test cases into existing checklist, preserving checked states.

**Use when**: You've added new test cases but want to keep progress on existing ones.

**Example**:

```
/seed merge
```

**Result**:

- Existing items keep their checked state
- New items added as unchecked
- Order updated to match current IB/OOB definitions
- Posts audit comment

### Concurrency

- **Group**: `seed-runlist-issue-${{ github.event.issue.number }}`
- **Policy**: Reject concurrent runs
- **Scope**: Per-issue

### Configuration

| Variable           | Default | Purpose                   |
| ------------------ | ------- | ------------------------- |
| `IB_MIN_REQUIRED`  | `"1"`   | Minimum IB cases to seed  |
| `OOB_MIN_REQUIRED` | `"2"`   | Minimum OOB cases to seed |

### Error Handling

| Error                   | Feedback                          |
| ----------------------- | --------------------------------- |
| Empty issue body        | Warning comment                   |
| Insufficient test cases | Warning with requirements         |
| No write permission     | Permission denied comment         |
| Unknown /seed command   | Help text with available commands |

### Example Output

```
✅ Run checklist seeded

**Order**: OOB-01 → IB-01 → OOB-02 → OOB-03 → IB-02
**Total cases**: 5
```

---

## Concurrency Model Summary

All workflows use **per-issue strict locking** to prevent race conditions:

| Workflow          | Group Pattern                          | Policy | Scope      |
| ----------------- | -------------------------------------- | ------ | ---------- |
| apply_settings    | `label-sync-${{ repo }}`               | Queue  | Repository |
| context-commands  | `context-commands-issue-${{ number }}` | Reject | Per-issue  |
| enforce_test_gate | `enforce-gate-issue-${{ number }}`     | Reject | Per-issue  |
| seed-test-runlist | `seed-runlist-issue-${{ number }}`     | Reject | Per-issue  |

**Policy Definitions**:

- **Queue**: Concurrent runs wait their turn, all eventually execute
- **Reject**: Concurrent runs are rejected immediately with notification comment

---

## Common Patterns

### Validation Flow

1. User creates test issue → `seed-test-runlist` auto-generates checklist
2. User edits issue (adds IB/OOB cases) → `enforce_test_gate` validates
3. User checks validation gate → `enforce_test_gate` enforces requirements
4. If requirements not met → Gate unchecked, checklist cleared, feedback posted
5. User fixes issues and re-checks gate → `enforce_test_gate` passes

### Context Management Flow

1. User needs to set context variable → Posts `/context set key="value"` comment
2. `context-commands` validates permission and parent reference
3. Context updated in parent issue YAML block
4. Audit trail comment posted with timestamp
5. `/context sync` triggered automatically to refresh checklist

### Conflict Resolution Flow

1. Workflow detects manual edits to Run checklist
2. Posts comment: "Detected manual edits. Reply with `/seed keep`, `/seed merge`, or `/seed overwrite`"
3. User chooses action via comment
4. Workflow applies chosen strategy
5. Audit comment posted with result

---

## Troubleshooting

### Workflow Not Triggering

1. Check issue has `type: test` label
2. Verify workflow file syntax is valid
3. Check Actions tab for errors

### Permission Denied Errors

1. Verify user has write access or higher
2. Check repository collaborator settings
3. Ensure GITHUB_TOKEN has `issues: write` permission

### Validation Gate Always Unchecks

1. Check IB/OOB counts meet requirements
2. Verify test case format: `- IB-N` (no leading zeros)
3. Check repository variables are set correctly

### Context Commands Not Working

1. Verify issue has `hier_parent` or "Suite ... Issue URL" reference
2. Check parent issue has ` ```yaml` block
3. Ensure parent issue URL format is correct

---

## Workflow YAML Syntax Best Practices

### If Conditions with Special Characters

When using `if:` conditions that contain special characters (like commas in string literals), **always use multiline format**:

✅ **CORRECT** (multiline format):

```yaml
if: |
  contains(join(github.event.issue.labels.*.name, ','), 'type: test')
```

❌ **INCORRECT** (single-line with comma causes YAML parser errors):

```yaml
if: contains(join(github.event.issue.labels.*.name, ','), 'type: test')
```

### Why Multiline Format?

- The `if: |` syntax uses YAML's literal block scalar
- Treats content as plain text, avoiding YAML parsing issues
- Prevents "mapping values are not allowed here" errors
- Consistent with GitHub Actions best practices

### Simple Expressions

For simple expressions without special characters, single-line format is fine:

```yaml
if: always()
if: failure()
if: github.ref == 'main'
```

---

## Workflow Inputs Best Practices

### Use Dropdowns Instead of Text Inputs

**Guideline**: For `workflow_dispatch` inputs, use dropdown menus (`type: choice`) or boolean inputs (`type: boolean`) instead of text inputs wherever possible.

**Why**:

- Prevents user input errors (typos, case sensitivity issues)
- Provides clear list of valid options
- Makes workflows more user-friendly and self-documenting
- Reduces need for input validation code

✅ **CORRECT** (dropdown for mode selection):

```yaml
on:
  workflow_dispatch:
    inputs:
      mode:
        description: 'Execution mode'
        required: true
        type: choice
        options:
          - dry_run
          - apply
        default: 'dry_run'
      override:
        description: 'Allow apply from non-main branch'
        required: false
        type: boolean
        default: false
```

❌ **INCORRECT** (text input prone to typos):

```yaml
on:
  workflow_dispatch:
    inputs:
      mode:
        description: 'dry_run (preview) | apply (make changes)'
        required: true
        default: 'dry_run'
      override:
        description: 'Set true to allow apply from non-main branch'
        required: false
        default: 'false'
```

### Input Type Guidelines

| Use Case                          | Input Type                              | Example                                 |
| --------------------------------- | --------------------------------------- | --------------------------------------- |
| Predefined options (2-10 choices) | `type: choice`                          | Mode selection, environment, log level  |
| Yes/No toggle                     | `type: boolean`                         | Enable/disable features, override flags |
| Version numbers                   | `type: choice` (if limited) or `string` | Node version, package version           |
| Arbitrary text                    | `string` (default)                      | Commit message, branch name             |

### Boolean Input Handling

When using `type: boolean`, remember that the value is a boolean, not a string:

✅ **CORRECT** (boolean comparison):

```yaml
if: |
  github.event.inputs.override == true
```

❌ **INCORRECT** (string comparison):

```yaml
if: |
  github.event.inputs.override == 'true'
```

---

## Error Handling and Robustness Best Practices

### Avoid `continue-on-error` Unless Explicitly Handled

**Guideline**: Never use `continue-on-error: true` unless you have explicit error handling in a subsequent step.

**Why**: `continue-on-error` silently suppresses failures, making debugging difficult and potentially hiding critical errors.

❌ **INCORRECT** (error is hidden):

```yaml
- name: Deploy application
  run: ./deploy.sh
  continue-on-error: true # Error is silently ignored!

- name: Send notification
  run: echo "Deployed successfully"
```

✅ **CORRECT** (error is handled):

```yaml
- name: Deploy application
  id: deploy
  run: ./deploy.sh
  # No continue-on-error - let it fail naturally

- name: Report status
  if: always() # Runs even if deploy fails
  run: |
    if [ "${{ steps.deploy.outcome }}" == "success" ]; then
      echo "✅ Deployed successfully"
    else
      echo "❌ Deployment failed"
      exit 1  # Re-fail the workflow
    fi
```

### Always Use Explicit Paths

**Guideline**: Use explicit paths relative to repository root, and validate paths before use.

✅ **CORRECT** (validates path exists):

```yaml
- name: Validate script exists
  run: |
    if [ ! -f ".github/scripts/my_script.sh" ]; then
      echo "❌ Error: .github/scripts/my_script.sh not found"
      exit 1
    fi

- name: Run script
  run: bash .github/scripts/my_script.sh
```

❌ **INCORRECT** (no validation, unclear path):

```yaml
- name: Run script
  run: bash my_script.sh # Where is this file?
```

### Validate Dependencies and Prerequisites

**Guideline**: Validate that required files, directories, and dependencies exist before using them.

✅ **CORRECT** (validates settings file):

```yaml
- name: Check settings.yml exists
  run: |
    if [ ! -f ".github/settings.yml" ]; then
      echo "❌ Error: .github/settings.yml not found"
      exit 1
    fi
    echo "✅ Found .github/settings.yml"

- name: Process settings
  run: node process_settings.js
```

### Use Descriptive Step Names

**Guideline**: Every step should have a clear, descriptive name that explains what it does.

✅ **CORRECT**:

```yaml
- name: Install YAML parser
  run: npm install yaml

- name: Validate script exists
  run: test -f .github/scripts/apply_settings.mjs
```

❌ **INCORRECT**:

```yaml
- run: npm install yaml
- run: test -f .github/scripts/apply_settings.mjs
```

### Handle Failures with `if: always()` or `if: failure()`

**Guideline**: Use conditional execution to handle failures gracefully without `continue-on-error`.

✅ **CORRECT** (proper failure handling):

```yaml
- name: Run tests
  id: test
  run: npm test

- name: Upload test results
  if: always() # Upload results even if tests fail
  uses: actions/upload-artifact@v3
  with:
    name: test-results
    path: test-results/

- name: Report failure
  if: failure() # Only runs if previous steps failed
  run: |
    echo "❌ Tests failed"
    exit 1
```

### Disable Caching When Not Needed

**Guideline**: Only use dependency caching when you have a lock file (package-lock.json, yarn.lock, etc.) and frequent rebuilds.

❌ **INCORRECT** (no lock file, one-time install):

```yaml
- uses: actions/setup-node@v4
  with:
    node-version: '20'
    cache: 'npm' # This will fail without package-lock.json
    cache-dependency-path: '.github/scripts/package-lock.json'

- run: npm install yaml # Just install directly
```

✅ **CORRECT** (no caching for one-time installs):

```yaml
- uses: actions/setup-node@v4
  with:
    node-version: '20'

- name: Install dependencies
  run: npm install yaml @octokit/core
```

**When to use caching**:

- You have a package-lock.json or similar lock file
- The same dependencies are installed multiple times in the workflow
- Build times are significant (> 1 minute for dependency installation)

### Summary of Best Practices

1. **No `continue-on-error`** unless you explicitly handle errors in the next step
2. **Validate all paths** before using them (files, scripts, directories)
3. **Use explicit paths** relative to repository root
4. **Name all steps** with clear, descriptive names
5. **Handle failures** with `if: always()` or `if: failure()` instead of `continue-on-error`
6. **Only cache dependencies** when you have lock files and frequent rebuilds
7. **Validate prerequisites** (files exist, dependencies installed, etc.) before use

---

## Workflow Timeout Strategy

All workflow jobs have timeout limits to prevent runaway jobs from consuming GitHub Actions minutes unnecessarily and to catch stuck or infinite-loop scenarios early.

### Timeout Values by Job Type

| Job Type                | Timeout   | Rationale                                                                                          |
| ----------------------- | --------- | -------------------------------------------------------------------------------------------------- |
| **Validation jobs**     | 3 minutes | File existence checks, YAML parsing - should complete in seconds                                   |
| **API-heavy jobs**      | 5 minutes | GitHub API calls (fetch/update issues, labels) - allows time for rate limiting and network retries |
| **Simple comment jobs** | 2 minutes | Only posts a comment to an issue - minimal operation                                               |

### Configured Timeouts by Workflow

#### apply_settings.yml

- **validate** job: 3 minutes (file checks + YAML validation)
- **preview** job: 5 minutes (API calls to fetch/compare labels)
- **apply** job: 5 minutes (API calls to create/update/delete labels)

#### context-commands.yml

- **handle** job: 5 minutes (fetch parent issue, parse YAML, update issue, post comments)

#### enforce_test_gate.yml

- **enforce** job: 3 minutes (parse issue body, batch label updates, post comments)
- **concurrency_rejected** job: 2 minutes (post single comment)

#### seed-test-runlist.yml

- **seed** job: 3 minutes (parse issue body, generate checklist, update issue)
- **handle_seed_command** job: 3 minutes (similar operations to seed)

### Why These Values?

1. **Conservative but Realistic**: GitHub-hosted runners are generally fast. Most jobs complete in under 30 seconds. Timeouts are set to 3-6x the expected runtime to account for:
   - Network latency
   - API rate limiting
   - Temporary GitHub API slowdowns

2. **Early Failure Detection**: If a job takes longer than expected, it's usually due to:
   - Infinite loops in scripts
   - API endpoint hangs
   - Unexpected workflow logic errors

   Catching these early saves debugging time.

3. **Cost Control**: Prevents accidental consumption of GitHub Actions minutes from stuck jobs.

### Adjusting Timeouts

If you find jobs consistently timing out:

1. **Check logs** to identify the slow step
2. **Optimize the slow operation** (batch API calls, reduce retries, etc.)
3. **Only increase timeout as last resort** - timeouts this low indicate a potential issue

Timeouts should rarely need adjustment unless:

- Repository has extremely large label sets (50+ labels)
- API calls are consistently rate-limited (unlikely for these operations)
- Custom modifications add compute-intensive operations

### Best Practice

Always include `timeout-minutes` on jobs to:

- Document expected runtime
- Catch runaway processes early
- Control costs
- Make workflow behavior predictable

---

**Last Updated**: 2025-11-08
**Template Version**: 1.4
