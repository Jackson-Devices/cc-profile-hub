#!/usr/bin/env bash
#
# Git Operations Lock Utility
#
# Prevents race conditions in concurrent git operations by using file-based locking.
# This script provides acquire, release, and wait operations for git locks.
#
# Usage:
#   source .github/scripts/git-lock.sh
#   git_lock_acquire "my-operation" || exit 1
#   # ... perform git operations ...
#   git_lock_release "my-operation"
#
# Or use the with_git_lock wrapper:
#   with_git_lock "my-operation" git push origin HEAD
#
# Features:
# - File-based locking for cross-process synchronization
# - Automatic stale lock detection and cleanup
# - Configurable timeout
# - Lock ownership tracking
# - Detailed logging

set -euo pipefail

# Configuration
GIT_LOCK_DIR="${GIT_LOCK_DIR:-.git/locks}"
GIT_LOCK_TIMEOUT="${GIT_LOCK_TIMEOUT:-300}"  # 5 minutes default
GIT_LOCK_STALE_AGE="${GIT_LOCK_STALE_AGE:-600}"  # 10 minutes
GIT_LOCK_VERBOSE="${GIT_LOCK_VERBOSE:-false}"

# Ensure lock directory exists
mkdir -p "$GIT_LOCK_DIR"

# Logging functions
log_verbose() {
    if [[ "$GIT_LOCK_VERBOSE" == "true" ]]; then
        echo "[git-lock] $*" >&2
    fi
}

log_info() {
    echo "[git-lock] $*" >&2
}

log_error() {
    echo "[git-lock] ERROR: $*" >&2
}

# Get current timestamp
get_timestamp() {
    date +%s
}

# Get lock file path for an operation
get_lock_file() {
    local operation="$1"
    echo "$GIT_LOCK_DIR/${operation}.lock"
}

# Check if a lock exists
git_lock_exists() {
    local operation="$1"
    local lock_file
    lock_file=$(get_lock_file "$operation")

    [[ -f "$lock_file" ]]
}

# Check if a lock is stale
git_lock_is_stale() {
    local operation="$1"
    local lock_file
    lock_file=$(get_lock_file "$operation")

    if [[ ! -f "$lock_file" ]]; then
        return 1  # Not stale if doesn't exist
    fi

    local lock_age
    local current_time
    local lock_time

    current_time=$(get_timestamp)
    lock_time=$(stat -c %Y "$lock_file" 2>/dev/null || stat -f %m "$lock_file" 2>/dev/null || echo "$current_time")
    lock_age=$((current_time - lock_time))

    [[ "$lock_age" -gt "$GIT_LOCK_STALE_AGE" ]]
}

# Remove a stale lock
git_lock_remove_stale() {
    local operation="$1"
    local lock_file
    lock_file=$(get_lock_file "$operation")

    if git_lock_is_stale "$operation"; then
        log_info "Removing stale lock for operation '$operation'"

        # Read lock info before removing
        if [[ -f "$lock_file" ]]; then
            log_verbose "Stale lock info: $(cat "$lock_file")"
            rm -f "$lock_file"
        fi

        return 0
    fi

    return 1
}

# Acquire a lock
git_lock_acquire() {
    local operation="$1"
    local lock_file
    lock_file=$(get_lock_file "$operation")

    local start_time
    start_time=$(get_timestamp)

    log_verbose "Attempting to acquire lock for operation '$operation'"

    # Try to acquire lock with timeout
    while true; do
        # Check for stale locks and remove them
        if git_lock_exists "$operation"; then
            if git_lock_is_stale "$operation"; then
                git_lock_remove_stale "$operation"
            fi
        fi

        # Try to create lock file atomically
        if mkdir "${lock_file}.tmp" 2>/dev/null; then
            # Write lock metadata
            cat > "${lock_file}.tmp/info" <<EOF
{
  "operation": "$operation",
  "owner": "${GITHUB_WORKFLOW:-unknown}",
  "run_id": "${GITHUB_RUN_ID:-unknown}",
  "run_number": "${GITHUB_RUN_NUMBER:-unknown}",
  "actor": "${GITHUB_ACTOR:-unknown}",
  "ref": "${GITHUB_REF:-unknown}",
  "sha": "${GITHUB_SHA:-unknown}",
  "timestamp": $(get_timestamp),
  "pid": $$
}
EOF

            # Atomically move temp dir to lock file
            if mv "${lock_file}.tmp/info" "$lock_file" 2>/dev/null; then
                rmdir "${lock_file}.tmp" 2>/dev/null || true
                log_info "Lock acquired for operation '$operation'"
                log_verbose "Lock metadata: $(cat "$lock_file")"
                return 0
            fi

            rmdir "${lock_file}.tmp" 2>/dev/null || true
        fi

        # Check timeout
        local current_time
        current_time=$(get_timestamp)
        local elapsed=$((current_time - start_time))

        if [[ "$elapsed" -gt "$GIT_LOCK_TIMEOUT" ]]; then
            log_error "Timeout waiting for lock on operation '$operation' after ${elapsed}s"

            if [[ -f "$lock_file" ]]; then
                log_error "Current lock holder info: $(cat "$lock_file")"
            fi

            return 1
        fi

        # Wait before retrying
        log_verbose "Lock busy, waiting... (${elapsed}s elapsed)"
        sleep 2
    done
}

# Release a lock
git_lock_release() {
    local operation="$1"
    local lock_file
    lock_file=$(get_lock_file "$operation")

    if [[ ! -f "$lock_file" ]]; then
        log_verbose "No lock to release for operation '$operation'"
        return 0
    fi

    log_verbose "Releasing lock for operation '$operation'"
    rm -f "$lock_file"
    log_info "Lock released for operation '$operation'"

    return 0
}

# Execute a command with a lock held
with_git_lock() {
    local operation="$1"
    shift

    local exit_code=0

    if git_lock_acquire "$operation"; then
        # Execute command with lock held
        if "$@"; then
            exit_code=0
        else
            exit_code=$?
            log_error "Command failed with exit code $exit_code: $*"
        fi

        # Always release lock
        git_lock_release "$operation"
    else
        log_error "Failed to acquire lock for operation '$operation'"
        return 1
    fi

    return $exit_code
}

# List all active locks
git_lock_list() {
    log_info "Active locks:"

    if [[ ! -d "$GIT_LOCK_DIR" ]] || [[ -z "$(ls -A "$GIT_LOCK_DIR" 2>/dev/null)" ]]; then
        echo "  (none)"
        return 0
    fi

    for lock_file in "$GIT_LOCK_DIR"/*.lock; do
        if [[ -f "$lock_file" ]]; then
            local operation
            operation=$(basename "$lock_file" .lock)

            echo "  - $operation"

            if [[ "$GIT_LOCK_VERBOSE" == "true" ]]; then
                echo "    $(cat "$lock_file")"
            fi

            if git_lock_is_stale "$operation"; then
                echo "    ⚠️  STALE (can be removed)"
            fi
        fi
    done
}

# Clean up all stale locks
git_lock_cleanup_stale() {
    log_info "Cleaning up stale locks..."

    local count=0

    for lock_file in "$GIT_LOCK_DIR"/*.lock; do
        if [[ -f "$lock_file" ]]; then
            local operation
            operation=$(basename "$lock_file" .lock)

            if git_lock_remove_stale "$operation"; then
                count=$((count + 1))
            fi
        fi
    done

    log_info "Cleaned up $count stale lock(s)"
}

# Race condition detection
detect_race_condition() {
    local operation="$1"

    log_info "🔍 Race Condition Detection for: $operation"

    # Check if multiple workflows are running
    local workflow_count=0

    if [[ -n "${GITHUB_RUN_ID:-}" ]]; then
        log_verbose "Current run ID: $GITHUB_RUN_ID"

        # Check lock directory for concurrent operations
        if [[ -d "$GIT_LOCK_DIR" ]]; then
            workflow_count=$(find "$GIT_LOCK_DIR" -name "*.lock" -type f 2>/dev/null | wc -l)
        fi
    fi

    if [[ $workflow_count -gt 0 ]]; then
        log_info "⚠️  Detected $workflow_count concurrent operation(s)"
        log_info "Lock protection is ACTIVE"
        git_lock_list
        return 0
    else
        log_info "✅ No concurrent operations detected"
        return 0
    fi
}

# Export functions if script is sourced
if [[ "${BASH_SOURCE[0]}" != "${0}" ]]; then
    export -f git_lock_acquire
    export -f git_lock_release
    export -f with_git_lock
    export -f git_lock_exists
    export -f git_lock_list
    export -f git_lock_cleanup_stale
    export -f detect_race_condition
    log_verbose "Git lock functions exported"
fi

# If run directly, provide CLI interface
if [[ "${BASH_SOURCE[0]}" == "${0}" ]]; then
    case "${1:-help}" in
        acquire)
            git_lock_acquire "${2:-default}"
            ;;
        release)
            git_lock_release "${2:-default}"
            ;;
        list)
            git_lock_list
            ;;
        cleanup)
            git_lock_cleanup_stale
            ;;
        detect)
            detect_race_condition "${2:-git-operations}"
            ;;
        help|*)
            cat <<EOF
Git Lock Utility - Prevent race conditions in git operations

Usage:
  $0 <command> [arguments]

Commands:
  acquire <operation>   Acquire a lock for the specified operation
  release <operation>   Release a lock for the specified operation
  list                  List all active locks
  cleanup               Clean up stale locks
  detect <operation>    Detect potential race conditions
  help                  Show this help message

Environment Variables:
  GIT_LOCK_DIR          Directory for lock files (default: .git/locks)
  GIT_LOCK_TIMEOUT      Timeout in seconds (default: 300)
  GIT_LOCK_STALE_AGE    Age in seconds after which locks are stale (default: 600)
  GIT_LOCK_VERBOSE      Enable verbose logging (default: false)

Example:
  # Acquire lock, perform operation, release lock
  $0 acquire my-operation
  git push origin HEAD
  $0 release my-operation

  # Or use in a script with sourcing:
  source $0
  with_git_lock "my-operation" git push origin HEAD
EOF
            ;;
    esac
fi
