#!/usr/bin/env bash
#
# Race Condition Detector for GitHub Actions
#
# This script detects and reports potential race conditions in GitHub Actions workflows
# by analyzing concurrent workflow runs, file access patterns, and git operations.
#
# Usage:
#   .github/scripts/race-condition-detector.sh [options]
#
# Options:
#   --workflow-name NAME    Name of the current workflow
#   --check-git             Check for concurrent git operations
#   --check-files PATHS     Check for concurrent file access (comma-separated)
#   --report-only           Only report findings, don't fail
#   --verbose               Enable verbose output

set -euo pipefail

# Configuration
WORKFLOW_NAME="${1:-${GITHUB_WORKFLOW:-unknown}}"
CHECK_GIT="${CHECK_GIT:-true}"
CHECK_FILES="${CHECK_FILES:-}"
REPORT_ONLY="${REPORT_ONLY:-false}"
VERBOSE="${VERBOSE:-false}"
GITHUB_API="${GITHUB_API_URL:-https://api.github.com}"

# Colors for output
RED='\033[0;31m'
YELLOW='\033[1;33m'
GREEN='\033[0;32m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

# Logging functions
log_verbose() {
    if [[ "$VERBOSE" == "true" ]]; then
        echo -e "${BLUE}[VERBOSE]${NC} $*" >&2
    fi
}

log_info() {
    echo -e "${GREEN}[INFO]${NC} $*" >&2
}

log_warning() {
    echo -e "${YELLOW}[WARNING]${NC} $*" >&2
}

log_error() {
    echo -e "${RED}[ERROR]${NC} $*" >&2
}

# Initialize results
RACE_CONDITIONS_FOUND=0
WARNINGS_FOUND=0

# Check for concurrent workflow runs
check_concurrent_workflows() {
    log_info "🔍 Checking for concurrent workflow runs..."

    if [[ -z "${GITHUB_TOKEN:-}" ]]; then
        log_warning "GITHUB_TOKEN not set, skipping API checks"
        return 0
    fi

    local repo="${GITHUB_REPOSITORY:-}"
    local run_id="${GITHUB_RUN_ID:-}"

    if [[ -z "$repo" ]] || [[ -z "$run_id" ]]; then
        log_warning "GitHub context not available, skipping concurrent workflow check"
        return 0
    fi

    log_verbose "Checking repository: $repo"
    log_verbose "Current run ID: $run_id"

    # Get all running workflows
    local response
    response=$(curl -s -H "Authorization: token $GITHUB_TOKEN" \
        -H "Accept: application/vnd.github.v3+json" \
        "$GITHUB_API/repos/$repo/actions/runs?status=in_progress" 2>/dev/null || echo '{"workflow_runs":[]}')

    local running_workflows
    running_workflows=$(echo "$response" | jq -r '.workflow_runs[] | select(.id != '"$run_id"') | .name' 2>/dev/null || echo "")

    if [[ -n "$running_workflows" ]]; then
        local count
        count=$(echo "$running_workflows" | wc -l)

        log_warning "⚠️  Found $count other workflow(s) running concurrently:"
        echo "$running_workflows" | while read -r wf; do
            log_warning "   - $wf"
        done

        WARNINGS_FOUND=$((WARNINGS_FOUND + 1))

        # Check if any of them might conflict
        local conflicting_patterns=(
            "format"
            "lint"
            "eslint"
            "squash"
            "mirror"
            "apply"
            "auto-fix"
        )

        for pattern in "${conflicting_patterns[@]}"; do
            if echo "$running_workflows" | grep -qi "$pattern"; then
                log_error "🔥 RACE CONDITION DETECTED: Concurrent '$pattern' workflows running!"
                log_error "   This may cause conflicts in git operations or file modifications"
                RACE_CONDITIONS_FOUND=$((RACE_CONDITIONS_FOUND + 1))
            fi
        done
    else
        log_info "✅ No concurrent workflows detected"
    fi
}

# Check for concurrent git operations
check_concurrent_git_operations() {
    if [[ "$CHECK_GIT" != "true" ]]; then
        return 0
    fi

    log_info "🔍 Checking for concurrent git operations..."

    # Check git lock directory
    local lock_dir=".git/locks"

    if [[ ! -d "$lock_dir" ]]; then
        log_verbose "No git lock directory found"
        return 0
    fi

    local lock_count
    lock_count=$(find "$lock_dir" -name "*.lock" -type f 2>/dev/null | wc -l)

    if [[ "$lock_count" -gt 0 ]]; then
        log_warning "⚠️  Found $lock_count active git lock(s)"

        find "$lock_dir" -name "*.lock" -type f | while read -r lock_file; do
            local lock_name
            lock_name=$(basename "$lock_file" .lock)
            log_warning "   - $lock_name"

            if [[ -f "$lock_file" ]]; then
                local lock_info
                lock_info=$(cat "$lock_file" 2>/dev/null || echo "{}")
                log_verbose "     Lock info: $lock_info"
            fi
        done

        WARNINGS_FOUND=$((WARNINGS_FOUND + 1))
    else
        log_info "✅ No concurrent git operations detected"
    fi

    # Check for git index lock (native git lock)
    if [[ -f ".git/index.lock" ]]; then
        log_error "🔥 RACE CONDITION DETECTED: Git index is locked!"
        log_error "   Another git operation is in progress"
        RACE_CONDITIONS_FOUND=$((RACE_CONDITIONS_FOUND + 1))
    fi

    # Check for git refs locks
    if find .git/refs -name "*.lock" 2>/dev/null | grep -q .; then
        log_error "🔥 RACE CONDITION DETECTED: Git refs are locked!"
        log_error "   Another process is modifying references"
        RACE_CONDITIONS_FOUND=$((RACE_CONDITIONS_FOUND + 1))
    fi
}

# Check for concurrent file access
check_concurrent_file_access() {
    if [[ -z "$CHECK_FILES" ]]; then
        return 0
    fi

    log_info "🔍 Checking for concurrent file access..."

    IFS=',' read -ra FILES <<< "$CHECK_FILES"

    for file_path in "${FILES[@]}"; do
        file_path=$(echo "$file_path" | xargs)  # Trim whitespace

        if [[ ! -e "$file_path" ]]; then
            log_verbose "File/directory not found: $file_path"
            continue
        fi

        log_verbose "Checking: $file_path"

        # Check if file is being modified (has flock)
        if command -v lsof >/dev/null 2>&1; then
            local locks
            locks=$(lsof "$file_path" 2>/dev/null | tail -n +2 || echo "")

            if [[ -n "$locks" ]]; then
                log_warning "⚠️  File '$file_path' is currently open:"
                echo "$locks" | while read -r line; do
                    log_warning "   $line"
                done
                WARNINGS_FOUND=$((WARNINGS_FOUND + 1))
            fi
        fi

        # Check git status for modifications
        if git ls-files --error-unmatch "$file_path" >/dev/null 2>&1; then
            if ! git diff --quiet "$file_path" 2>/dev/null; then
                log_warning "⚠️  File '$file_path' has uncommitted changes"
                WARNINGS_FOUND=$((WARNINGS_FOUND + 1))
            fi
        fi
    done

    if [[ "$WARNINGS_FOUND" -eq 0 ]]; then
        log_info "✅ No concurrent file access detected"
    fi
}

# Check for common race condition patterns
check_race_patterns() {
    log_info "🔍 Checking for common race condition patterns..."

    # Check if we're in a PR context with multiple checks
    if [[ "${GITHUB_EVENT_NAME:-}" == "pull_request" ]]; then
        log_verbose "Running in pull_request context"

        # Check for multiple check runs
        if [[ -n "${GITHUB_TOKEN:-}" ]] && [[ -n "${GITHUB_REPOSITORY:-}" ]]; then
            local pr_number
            pr_number=$(jq -r '.pull_request.number // empty' "$GITHUB_EVENT_PATH" 2>/dev/null || echo "")

            if [[ -n "$pr_number" ]]; then
                log_verbose "Checking PR #$pr_number for concurrent checks"

                local checks
                checks=$(curl -s -H "Authorization: token $GITHUB_TOKEN" \
                    -H "Accept: application/vnd.github.v3+json" \
                    "$GITHUB_API/repos/$GITHUB_REPOSITORY/commits/${GITHUB_SHA}/check-runs" 2>/dev/null | \
                    jq -r '.check_runs[] | select(.status == "in_progress") | .name' 2>/dev/null || echo "")

                if [[ -n "$checks" ]]; then
                    local check_count
                    check_count=$(echo "$checks" | wc -l)

                    if [[ "$check_count" -gt 1 ]]; then
                        log_warning "⚠️  Found $check_count check runs in progress on this PR"
                        WARNINGS_FOUND=$((WARNINGS_FOUND + 1))
                    fi
                fi
            fi
        fi
    fi

    # Check for rapid commit sequences (potential race in decision logs)
    if [[ -d ".ai_logs" ]]; then
        log_verbose "Checking .ai_logs for rapid updates"

        local recent_logs
        recent_logs=$(find .ai_logs -name "*.md" -mmin -5 2>/dev/null | wc -l)

        if [[ "$recent_logs" -gt 1 ]]; then
            log_warning "⚠️  Multiple decision logs modified in last 5 minutes"
            log_warning "   This may indicate concurrent AI operations"
            WARNINGS_FOUND=$((WARNINGS_FOUND + 1))
        fi
    fi

    # Check for concurrent issue mirror updates
    if [[ -d "docs/issues_mirror" ]]; then
        log_verbose "Checking issue mirrors for concurrent updates"

        local recent_mirrors
        recent_mirrors=$(find docs/issues_mirror -name "*.md" -mmin -5 2>/dev/null | wc -l)

        if [[ $recent_mirrors -gt 1 ]]; then
            log_warning "⚠️  Multiple issue mirrors modified in last 5 minutes"
            WARNINGS_FOUND=$((WARNINGS_FOUND + 1))
        fi
    fi
}

# Generate report
generate_report() {
    log_info ""
    log_info "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
    log_info "  Race Condition Detection Report"
    log_info "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
    log_info ""
    log_info "Workflow: $WORKFLOW_NAME"
    log_info "Run ID: ${GITHUB_RUN_ID:-N/A}"
    log_info "Timestamp: $(date -u +"%Y-%m-%d %H:%M:%S UTC")"
    log_info ""

    if [[ $RACE_CONDITIONS_FOUND -eq 0 ]] && [[ $WARNINGS_FOUND -eq 0 ]]; then
        log_info "✅ Status: SAFE"
        log_info "   No race conditions or warnings detected"
    elif [[ $RACE_CONDITIONS_FOUND -eq 0 ]]; then
        log_info "⚠️  Status: WARNINGS"
        log_info "   Warnings: $WARNINGS_FOUND"
        log_info "   Race Conditions: 0"
    else
        log_error "🔥 Status: RACE CONDITIONS DETECTED"
        log_error "   Race Conditions: $RACE_CONDITIONS_FOUND"
        log_error "   Warnings: $WARNINGS_FOUND"
    fi

    log_info ""
    log_info "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
    log_info ""

    # Write to GitHub step summary if available
    if [[ -n "${GITHUB_STEP_SUMMARY:-}" ]]; then
        {
            echo "## 🔍 Race Condition Detection Report"
            echo ""
            echo "**Workflow:** $WORKFLOW_NAME"
            echo "**Run ID:** ${GITHUB_RUN_ID:-N/A}"
            echo "**Timestamp:** $(date -u +"%Y-%m-%d %H:%M:%S UTC")"
            echo ""

            if [[ $RACE_CONDITIONS_FOUND -eq 0 ]] && [[ $WARNINGS_FOUND -eq 0 ]]; then
                echo "### ✅ Status: SAFE"
                echo "No race conditions or warnings detected"
            elif [[ $RACE_CONDITIONS_FOUND -eq 0 ]]; then
                echo "### ⚠️  Status: WARNINGS"
                echo "- **Warnings:** $WARNINGS_FOUND"
                echo "- **Race Conditions:** 0"
            else
                echo "### 🔥 Status: RACE CONDITIONS DETECTED"
                echo "- **Race Conditions:** $RACE_CONDITIONS_FOUND"
                echo "- **Warnings:** $WARNINGS_FOUND"
                echo ""
                echo "**Action Required:** Review workflow execution and resolve conflicts"
            fi
        } >> "$GITHUB_STEP_SUMMARY"
    fi
}

# Parse command line arguments
while [[ $# -gt 0 ]]; do
    case $1 in
        --workflow-name)
            WORKFLOW_NAME="$2"
            shift 2
            ;;
        --check-git)
            CHECK_GIT="true"
            shift
            ;;
        --check-files)
            CHECK_FILES="$2"
            shift 2
            ;;
        --report-only)
            REPORT_ONLY="true"
            shift
            ;;
        --verbose)
            VERBOSE="true"
            shift
            ;;
        --help)
            cat <<EOF
Race Condition Detector for GitHub Actions

Usage:
  $0 [options]

Options:
  --workflow-name NAME    Name of the current workflow
  --check-git             Check for concurrent git operations
  --check-files PATHS     Check for concurrent file access (comma-separated)
  --report-only           Only report findings, don't fail
  --verbose               Enable verbose output
  --help                  Show this help message

Environment Variables:
  CHECK_GIT               Enable git operation checking (default: true)
  CHECK_FILES             Comma-separated list of files to check
  REPORT_ONLY             Only report, don't fail (default: false)
  VERBOSE                 Enable verbose logging (default: false)

Exit Codes:
  0 - No race conditions detected (or report-only mode)
  1 - Race conditions detected

Example:
  $0 --workflow-name "Format Apply" --check-git --check-files ".github/workflows,src"
EOF
            exit 0
            ;;
        *)
            log_error "Unknown option: $1"
            echo "Use --help for usage information"
            exit 1
            ;;
    esac
done

# Main execution
main() {
    log_info "🚀 Starting race condition detection for workflow: $WORKFLOW_NAME"
    log_info ""

    check_concurrent_workflows
    check_concurrent_git_operations
    check_concurrent_file_access
    check_race_patterns

    generate_report

    # Determine exit code
    if [[ "$REPORT_ONLY" == "true" ]]; then
        log_info "Report-only mode: exiting with success"
        exit 0
    elif [[ $RACE_CONDITIONS_FOUND -gt 0 ]]; then
        log_error "Race conditions detected: exiting with failure"
        exit 1
    else
        log_info "No critical issues: exiting with success"
        exit 0
    fi
}

main
