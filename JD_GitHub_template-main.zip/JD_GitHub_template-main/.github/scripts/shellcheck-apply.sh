#!/usr/bin/env bash
#
# shellcheck-apply.sh - Intelligently apply shellcheck fixes with multiple strategies
#
# Usage:
#   shellcheck-apply.sh [OPTIONS] <file>
#
# Options:
#   --strategy=<conservative|balanced|aggressive>  Fix strategy (default: balanced)
#   --max-passes=<N>                               Maximum fix passes (default: 3)
#   --escalate                                     Try more aggressive strategies if current fails
#   --dry-run                                      Show what would be done without applying
#   --verbose                                      Show detailed output
#   --help                                         Show this help
#
# Strategies:
#   conservative - Only fix variables in safe contexts (tests, comparisons)
#   balanced     - Fix most common issues, preserve intentional word splitting
#   aggressive   - Fix all issues, may break intentional word splitting
#
# Exit codes:
#   0 - Success (file passes shellcheck)
#   1 - Failure (file still has issues after max passes)
#   2 - Invalid arguments
#   3 - File not found
#   4 - Shellcheck not available
#

set -euo pipefail

# Configuration
STRATEGY="${SHELLCHECK_STRATEGY:-balanced}"
MAX_PASSES="${SHELLCHECK_MAX_PASSES:-3}"
ESCALATE=false
DRY_RUN=false
VERBOSE=false
BACKUP_SUFFIX=".shellcheck-backup"

# Statistics
TOTAL_FIXES=0
CURRENT_PASS=0

# Colors (if terminal supports them)
if [[ -t 1 ]]; then
  RED='\033[0;31m'
  GREEN='\033[0;32m'
  YELLOW='\033[1;33m'
  BLUE='\033[0;34m'
  NC='\033[0m' # No Color
else
  RED=''
  GREEN=''
  YELLOW=''
  BLUE=''
  NC=''
fi

#######################################
# Print usage information
#######################################
usage() {
  grep '^#' "$0" | sed 's/^# \?//' | head -n -1
}

#######################################
# Log message with color
# Arguments:
#   $1 - Color code
#   $2 - Message
#######################################
log() {
  local color="$1"
  shift
  echo -e "${color}$*${NC}" >&2
}

#######################################
# Log verbose message
#######################################
log_verbose() {
  if [[ "$VERBOSE" == "true" ]]; then
    log "$BLUE" "$@"
  fi
}

#######################################
# Create backup of file
# Arguments:
#   $1 - File path
#######################################
backup_file() {
  local file="$1"
  cp "$file" "${file}${BACKUP_SUFFIX}"
  log_verbose "Created backup: ${file}${BACKUP_SUFFIX}"
}

#######################################
# Restore file from backup
# Arguments:
#   $1 - File path
#######################################
restore_backup() {
  local file="$1"
  if [[ -f "${file}${BACKUP_SUFFIX}" ]]; then
    mv "${file}${BACKUP_SUFFIX}" "$file"
    log "$YELLOW" "Restored from backup"
  fi
}

#######################################
# Remove backup file
# Arguments:
#   $1 - File path
#######################################
remove_backup() {
  local file="$1"
  if [[ -f "${file}${BACKUP_SUFFIX}" ]]; then
    rm "${file}${BACKUP_SUFFIX}"
    log_verbose "Removed backup"
  fi
}

#######################################
# Check if shellcheck passes
# Arguments:
#   $1 - File path
# Returns:
#   0 if passes, 1 if fails
#######################################
shellcheck_passes() {
  local file="$1"
  if shellcheck "$file" > /dev/null 2>&1; then
    return 0
  else
    return 1
  fi
}

#######################################
# Get shellcheck violations for specific SC code
# Arguments:
#   $1 - File path
#   $2 - SC code (e.g., SC2086)
# Outputs:
#   JSON array of violations
#######################################
get_violations() {
  local file="$1"
  local sc_code="$2"

  # Use xargs to strip all whitespace (including CRLF) from wc output
  local result
  result=$(shellcheck --format=json "$file" 2>/dev/null | \
    grep -o "\"code\":${sc_code}" | wc -l | xargs)

  # If empty or non-numeric, return 0
  if [[ -z "$result" ]] || ! [[ "$result" =~ ^[0-9]+$ ]]; then
    echo "0"
  else
    echo "$result"
  fi
}

#######################################
# Fix SC2086: Quote variables to prevent globbing/word splitting
# Arguments:
#   $1 - File path
#   $2 - Strategy
# Returns:
#   Number of fixes applied
#######################################
fix_sc2086() {
  local file="$1"
  local strategy="$2"
  local fixes=0

  case "$strategy" in
    conservative)
      # Only fix in test contexts and comparisons
      fixes=$((fixes + $(sed -i 's/\[ \$\([A-Za-z_][A-Za-z0-9_]*\) \]/[ "$\1" ]/g' "$file" && echo 1 || echo 0)))
      fixes=$((fixes + $(sed -i 's/\[\[ \$\([A-Za-z_][A-Za-z0-9_]*\) \]\]/[[ "$\1" ]]/g' "$file" && echo 1 || echo 0)))
      fixes=$((fixes + $(sed -i 's/if \[ \$\([A-Za-z_][A-Za-z0-9_]*\) \]/if [ "$\1" ]/g' "$file" && echo 1 || echo 0)))
      ;;

    balanced)
      # Fix common cases, preserve word splitting in for loops
      fixes=$((fixes + $(sed -i 's/>> \$GITHUB_OUTPUT$/>> "$GITHUB_OUTPUT"/g' "$file" && echo 1 || echo 0)))
      fixes=$((fixes + $(sed -i 's/>> \$GITHUB_STEP_SUMMARY$/>> "$GITHUB_STEP_SUMMARY"/g' "$file" && echo 1 || echo 0)))
      fixes=$((fixes + $(sed -i 's/>> \$GITHUB_ENV$/>> "$GITHUB_ENV"/g' "$file" && echo 1 || echo 0)))
      fixes=$((fixes + $(sed -i 's/>> \$GITHUB_PATH$/>> "$GITHUB_PATH"/g' "$file" && echo 1 || echo 0)))

      # Quote in test contexts
      fixes=$((fixes + $(sed -i 's/\[ \$\([A-Za-z_][A-Za-z0-9_]*\) \]/[ "$\1" ]/g' "$file" && echo 1 || echo 0)))
      fixes=$((fixes + $(sed -i 's/\[\[ \$\([A-Za-z_][A-Za-z0-9_]*\) \]\]/[[ "$\1" ]]/g' "$file" && echo 1 || echo 0)))

      # Quote in assignments
      fixes=$((fixes + $(sed -i 's/=\$(/="$(/g' "$file" && echo 1 || echo 0)))
      ;;

    aggressive)
      # Quote all unquoted variables (may break intentional word splitting)
      # This is a simplified version - real implementation would be more sophisticated
      fixes=$((fixes + $(sed -i 's/\$\([A-Za-z_][A-Za-z0-9_]*\)/"$\1"/g' "$file" && echo 1 || echo 0)))
      ;;
  esac

  echo "$fixes"
}

#######################################
# Fix SC2046: Quote command substitution to prevent word splitting
# Arguments:
#   $1 - File path
#   $2 - Strategy
# Returns:
#   Number of fixes applied
#######################################
fix_sc2046() {
  local file="$1"
  local strategy="$2"
  local fixes=0

  # Quote unquoted command substitutions
  fixes=$((fixes + $(sed -i 's/=\$(/="$(/g; s/)$/)"/g' "$file" && echo 1 || echo 0)))

  echo "$fixes"
}

#######################################
# Fix SC2006: Use $(...) instead of legacy backticked `...`
# Arguments:
#   $1 - File path
#   $2 - Strategy
# Returns:
#   Number of fixes applied
#######################################
fix_sc2006() {
  local file="$1"
  local strategy="$2"
  local fixes=0

  # Convert backticks to $()
  # Note: This is simplified - proper implementation would handle nested backticks
  if grep -q '`' "$file"; then
    sed -i 's/`\([^`]*\)`/$(\1)/g' "$file"
    fixes=1
  fi

  echo "$fixes"
}

#######################################
# Fix SC2164: Use cd ... || exit in case cd fails
# Arguments:
#   $1 - File path
#   $2 - Strategy
# Returns:
#   Number of fixes applied
#######################################
fix_sc2164() {
  local file="$1"
  local strategy="$2"
  local fixes=0

  # Add || exit to cd commands without error handling
  if grep -q '^[[:space:]]*cd ' "$file" && ! grep -q 'cd .* || ' "$file"; then
    sed -i 's/^\([[:space:]]*\)cd \(.*\)$/\1cd \2 || exit/g' "$file"
    fixes=1
  fi

  echo "$fixes"
}

#######################################
# Apply fixes for a specific SC code
# Arguments:
#   $1 - File path
#   $2 - SC code
#   $3 - Strategy
# Returns:
#   Number of fixes applied
#######################################
apply_fixes_for_code() {
  local file="$1"
  local sc_code="$2"
  local strategy="$3"
  local fixes=0

  case "$sc_code" in
    SC2086)
      fixes=$(fix_sc2086 "$file" "$strategy")
      ;;
    SC2046)
      fixes=$(fix_sc2046 "$file" "$strategy")
      ;;
    SC2006)
      fixes=$(fix_sc2006 "$file" "$strategy")
      ;;
    SC2164)
      fixes=$(fix_sc2164 "$file" "$strategy")
      ;;
    *)
      log_verbose "No fix function for $sc_code"
      ;;
  esac

  echo "$fixes"
}

#######################################
# Perform one pass of fixes
# Arguments:
#   $1 - File path
#   $2 - Strategy
# Returns:
#   Number of fixes applied
#######################################
perform_pass() {
  local file="$1"
  local strategy="$2"
  local pass_fixes=0

  CURRENT_PASS=$((CURRENT_PASS + 1))
  echo ""
  log "$BLUE" "=== Pass $CURRENT_PASS (strategy: $strategy) ==="

  # Get all SC codes that need fixing
  local sc_codes
  sc_codes=$(shellcheck --format=json "$file" 2>/dev/null | \
    grep -o '"code":[0-9]*' | \
    sed 's/"code"://' | \
    sort -u || echo "")

  if [[ -z "$sc_codes" ]]; then
    log "$GREEN" "✓ No issues found"
    return 0
  fi

  # Apply fixes for each SC code
  for sc_code in $sc_codes; do
    local count
    count=$(get_violations "$file" "$sc_code")

    if [[ "$count" -gt 0 ]]; then
      log "$YELLOW" "Attempting to fix SC$sc_code ($count violations)..."

      local fixes
      fixes=$(apply_fixes_for_code "$file" "SC$sc_code" "$strategy")

      if [[ "$fixes" -gt 0 ]]; then
        log "$GREEN" "  ✓ Applied $fixes fix(es) for SC$sc_code"
        pass_fixes=$((pass_fixes + fixes))
      else
        log_verbose "  - No fixes applied for SC$sc_code"
      fi
    fi
  done

  echo "$pass_fixes"
}

#######################################
# Main fix process
# Arguments:
#   $1 - File path
# Returns:
#   0 on success, 1 on failure
#######################################
fix_file() {
  local file="$1"
  local current_strategy="$STRATEGY"

  # Create backup
  backup_file "$file"

  # Check if already passing
  if shellcheck_passes "$file"; then
    log "$GREEN" "✓ File already passes shellcheck"
    remove_backup "$file"
    return 0
  fi

  # Try fixing with current strategy
  for ((pass=1; pass<=MAX_PASSES; pass++)); do
    local fixes
    fixes=$(perform_pass "$file" "$current_strategy")
    TOTAL_FIXES=$((TOTAL_FIXES + fixes))

    if shellcheck_passes "$file"; then
      echo ""
      log "$GREEN" "✓ Success! File passes shellcheck after $pass pass(es)"
      log "$GREEN" "Total fixes applied: $TOTAL_FIXES"
      remove_backup "$file"
      return 0
    fi

    if [[ "$fixes" -eq 0 ]]; then
      log "$YELLOW" "⚠ No more fixes applied in this pass"
      break
    fi
  done

  # If escalation is enabled, try more aggressive strategies
  if [[ "$ESCALATE" == "true" ]]; then
    if [[ "$current_strategy" == "conservative" ]]; then
      log "$YELLOW" "⚠ Conservative strategy failed, trying balanced..."
      current_strategy="balanced"
      CURRENT_PASS=0
      restore_backup "$file"
      backup_file "$file"

      for ((pass=1; pass<=MAX_PASSES; pass++)); do
        local fixes
        fixes=$(perform_pass "$file" "$current_strategy")
        TOTAL_FIXES=$((TOTAL_FIXES + fixes))

        if shellcheck_passes "$file"; then
          echo ""
          log "$GREEN" "✓ Success with balanced strategy!"
          log "$GREEN" "Total fixes applied: $TOTAL_FIXES"
          remove_backup "$file"
          return 0
        fi

        if [[ "$fixes" -eq 0 ]]; then
          break
        fi
      done
    fi

    if [[ "$current_strategy" == "balanced" ]] || [[ "$STRATEGY" == "conservative" ]]; then
      log "$YELLOW" "⚠ Balanced strategy failed, trying aggressive..."
      current_strategy="aggressive"
      CURRENT_PASS=0
      restore_backup "$file"
      backup_file "$file"

      for ((pass=1; pass<=MAX_PASSES; pass++)); do
        local fixes
        fixes=$(perform_pass "$file" "$current_strategy")
        TOTAL_FIXES=$((TOTAL_FIXES + fixes))

        if shellcheck_passes "$file"; then
          echo ""
          log "$GREEN" "✓ Success with aggressive strategy!"
          log "$GREEN" "Total fixes applied: $TOTAL_FIXES"
          remove_backup "$file"
          return 0
        fi

        if [[ "$fixes" -eq 0 ]]; then
          break
        fi
      done
    fi
  fi

  # Failed to fix
  echo ""
  log "$RED" "✗ Failed to fix all issues after $CURRENT_PASS pass(es)"
  log "$RED" "Remaining issues:"
  shellcheck "$file" 2>&1 | head -20

  restore_backup "$file"
  return 1
}

#######################################
# Parse command line arguments
#######################################
parse_args() {
  while [[ $# -gt 0 ]]; do
    case "$1" in
      --strategy=*)
        STRATEGY="${1#*=}"
        if [[ ! "$STRATEGY" =~ ^(conservative|balanced|aggressive)$ ]]; then
          log "$RED" "Error: Invalid strategy '$STRATEGY'"
          usage
          exit 2
        fi
        ;;
      --max-passes=*)
        MAX_PASSES="${1#*=}"
        if [[ ! "$MAX_PASSES" =~ ^[0-9]+$ ]]; then
          log "$RED" "Error: Invalid max-passes '$MAX_PASSES'"
          exit 2
        fi
        ;;
      --escalate)
        ESCALATE=true
        ;;
      --dry-run)
        DRY_RUN=true
        ;;
      --verbose)
        VERBOSE=true
        ;;
      --help|-h)
        usage
        exit 0
        ;;
      -*)
        log "$RED" "Error: Unknown option '$1'"
        usage
        exit 2
        ;;
      *)
        if [[ -z "${FILE:-}" ]]; then
          FILE="$1"
        else
          log "$RED" "Error: Multiple files not supported"
          exit 2
        fi
        ;;
    esac
    shift
  done
}

#######################################
# Main
#######################################
main() {
  parse_args "$@"

  # Validate file
  if [[ -z "${FILE:-}" ]]; then
    log "$RED" "Error: No file specified"
    usage
    exit 2
  fi

  if [[ ! -f "$FILE" ]]; then
    log "$RED" "Error: File not found: $FILE"
    exit 3
  fi

  # Check if shellcheck is available
  if ! command -v shellcheck &> /dev/null; then
    log "$RED" "Error: shellcheck is not installed"
    exit 4
  fi

  # Show configuration
  log "$BLUE" "Shellcheck Apply - Automatic Fix Tool"
  log "$BLUE" "File: $FILE"
  log "$BLUE" "Strategy: $STRATEGY"
  log "$BLUE" "Max passes: $MAX_PASSES"
  log "$BLUE" "Escalate: $ESCALATE"

  if [[ "$DRY_RUN" == "true" ]]; then
    log "$YELLOW" "DRY RUN MODE - No changes will be made"
    shellcheck "$FILE" || true
    exit 0
  fi

  # Fix the file
  if fix_file "$FILE"; then
    exit 0
  else
    exit 1
  fi
}

main "$@"
