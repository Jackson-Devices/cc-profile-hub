/**
 * Contextual Dependency System
 *
 * Implements "if A is present then so should B and C" requirements
 * Validates contextual dependencies across files and project structure
 */

import { readFile, readdir } from 'node:fs/promises';
import { existsSync } from 'node:fs';
import { join, sep } from 'node:path';
import yaml from 'yaml';

/**
 * Helper function to find files matching a glob pattern
 */
async function findMatchingFiles(pattern, basePath = process.cwd()) {
  const matches = [];

  // Simple glob pattern matching (supports **/*.ext patterns)
  const regex = globToRegex(pattern);

  async function scan(dir) {
    try {
      const entries = await readdir(dir, { withFileTypes: true });

      for (const entry of entries) {
        const fullPath = join(dir, entry.name);
        const relativePath = fullPath.replace(basePath + sep, '').replace(/\\/g, '/');

        if (entry.isDirectory()) {
          await scan(fullPath);
        } else if (entry.isFile()) {
          if (regex.test(relativePath)) {
            matches.push(fullPath);
          }
        }
      }
    } catch {
      // Ignore directories we can't read
    }
  }

  await scan(basePath);
  return matches;
}

/**
 * Convert simple glob pattern to regex
 */
function globToRegex(pattern) {
  // Escape special regex characters except * and ?
  let regexPattern = pattern.replace(/[.+^${}()|[\]\\]/g, '\\$&');

  // Replace glob wildcards with regex equivalents using placeholders
  // to avoid conflicts between ** and * replacements
  // **/ at start or middle should match zero or more path segments
  regexPattern = regexPattern.replace(/\*\*\//g, '§GLOBSTAR_SLASH§');
  // /** at end should match any remaining path
  regexPattern = regexPattern.replace(/\/\*\*/g, '§SLASH_GLOBSTAR§');
  // ** by itself matches anything
  regexPattern = regexPattern.replace(/\*\*/g, '§GLOBSTAR§');
  // * matches any characters except /
  regexPattern = regexPattern.replace(/\*/g, '[^/]*');
  // ? matches single character
  regexPattern = regexPattern.replace(/\?/g, '.');

  // Replace placeholders with actual regex patterns
  regexPattern = regexPattern.replace(/§GLOBSTAR_SLASH§/g, '(.*/)?');
  regexPattern = regexPattern.replace(/§SLASH_GLOBSTAR§/g, '/.*');
  regexPattern = regexPattern.replace(/§GLOBSTAR§/g, '.*');

  return new RegExp('^' + regexPattern + '$');
}

/**
 * Dependency Rule - Represents a single contextual dependency rule
 */
export class DependencyRule {
  constructor(config) {
    this.id = config.id;
    this.condition = config.condition;
    this.requires = config.requires || [];
    this.severity = config.severity || 'warning';
    this.message = config.message || '';
    this.autoFix = config.autoFix;
  }
}

/**
 * Dependency Validator - Validates files against dependency rules
 */
export class DependencyValidator {
  constructor() {
    this.rules = [];
  }

  /**
   * Add a rule to the validator
   */
  addRule(rule) {
    this.rules.push(rule);
  }

  /**
   * Get all rules
   */
  getRules() {
    return this.rules;
  }

  /**
   * Load rules from YAML file
   */
  async loadFromFile(configPath) {
    try {
      const content = await readFile(configPath, 'utf8');
      const config = yaml.parse(content);

      if (!config.rules) {
        throw new Error('No rules found in config');
      }

      for (const ruleConfig of config.rules) {
        const rule = new DependencyRule(ruleConfig);
        this.addRule(rule);
      }
    } catch (error) {
      throw new Error(`Failed to load rules from ${configPath}: ${error.message}`);
    }
  }

  /**
   * Validate files against all rules
   */
  async validate(rules) {
    const violations = [];

    for (const rule of rules) {
      try {
        // Check if condition is met
        const conditionMet = await this.evaluateCondition(rule.condition);

        if (!conditionMet) {
          // Condition not met, rule doesn't apply
          continue;
        }

        // Condition is met, check all requirements
        for (const requirement of rule.requires) {
          const requirementMet = await this.evaluateRequirement(requirement);

          if (!requirementMet) {
            violations.push({
              rule_id: rule.id,
              severity: rule.severity,
              message: this.formatViolationMessage(rule, requirement),
              requirement,
              autoFix: rule.autoFix
            });
          }
        }
      } catch {
        // Skip rules that error out
        continue;
      }
    }

    return {
      valid: violations.length === 0,
      violations
    };
  }

  /**
   * Evaluate a condition
   */
  async evaluateCondition(condition) {
    switch (condition.type) {
      case 'file_exists':
        return existsSync(condition.path);

      case 'file_pattern': {
        const matches = await findMatchingFiles(
          condition.pattern,
          condition.basePath || process.cwd()
        );
        return matches.length > 0;
      }

      case 'content_contains':
        try {
          if (!existsSync(condition.path)) {
            return false;
          }
          const content = await readFile(condition.path, 'utf8');
          return content.includes(condition.pattern);
        } catch {
          return false;
        }

      default:
        // Unknown condition type
        return false;
    }
  }

  /**
   * Evaluate a requirement
   */
  async evaluateRequirement(requirement) {
    switch (requirement.type) {
      case 'file_exists':
        return existsSync(requirement.path);

      case 'file_pattern': {
        const matches = await findMatchingFiles(
          requirement.pattern,
          requirement.basePath || process.cwd()
        );
        return matches.length > 0;
      }

      case 'content_contains':
        try {
          if (!existsSync(requirement.path)) {
            return false;
          }
          const content = await readFile(requirement.path, 'utf8');
          return content.includes(requirement.pattern);
        } catch {
          return false;
        }

      default:
        return false;
    }
  }

  /**
   * Format violation message
   */
  formatViolationMessage(rule, requirement) {
    let message = rule.message || 'Dependency violation';

    // Add specific requirement details
    if (requirement.type === 'file_exists') {
      message += `: Missing required file ${requirement.path}`;
    } else if (requirement.type === 'file_pattern') {
      message += `: Missing files matching pattern ${requirement.pattern}`;
    } else if (requirement.type === 'content_contains') {
      message += `: File ${requirement.path} should contain '${requirement.pattern}'`;
    }

    return message;
  }
}
