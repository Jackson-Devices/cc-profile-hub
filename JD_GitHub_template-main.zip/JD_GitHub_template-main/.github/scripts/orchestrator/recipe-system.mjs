/**
 * Recipe System
 *
 * Provides reusable templates and patterns for common file operations
 */

import { readFile, writeFile, mkdir } from 'node:fs/promises';
import { dirname } from 'node:path';
import { existsSync } from 'node:fs';
import yaml from 'yaml';

/**
 * Recipe - Represents a reusable template/pattern
 */
export class Recipe {
  constructor(config) {
    this.name = config.name;
    this.description = config.description || '';
    this.version = config.version || '1.0.0';
    this.inputs = config.inputs || [];
    this.actions = config.actions || [];
  }

  /**
   * Render template with variable substitution
   */
  renderTemplate(template, inputs) {
    if (!template) return '';

    let rendered = template;
    for (const [key, value] of Object.entries(inputs)) {
      const regex = new RegExp(`\\{\\{${key}\\}\\}`, 'g');
      rendered = rendered.replace(regex, value !== undefined ? value : `{{${key}}}`);
    }
    return rendered;
  }

  /**
   * Validate inputs against recipe requirements
   */
  validateInputs(inputs) {
    const validated = {};

    for (const inputDef of this.inputs) {
      // Check if required input is provided
      if (inputDef.required && !(inputDef.name in inputs)) {
        throw new Error(`Required input missing: ${inputDef.name}`);
      }

      // Use provided value or default
      validated[inputDef.name] = inputs[inputDef.name] !== undefined
        ? inputs[inputDef.name]
        : inputDef.default;
    }

    return validated;
  }

  /**
   * Execute recipe with provided inputs
   */
  async execute(inputs) {
    // Validate inputs
    const validatedInputs = this.validateInputs(inputs);

    // Execute actions
    const results = [];
    for (const action of this.actions) {
      try {
        const result = await this.executeAction(action, validatedInputs);
        results.push(result);
      } catch (error) {
        results.push({
          success: false,
          error: error.message,
          action: action.type
        });
      }
    }

    return {
      success: results.every(r => r.success),
      results
    };
  }

  /**
   * Execute a single action
   */
  async executeAction(action, inputs) {
    switch (action.type) {
      case 'create_file':
        return await this.createFile(action, inputs);
      case 'modify_file':
        return await this.modifyFile(action, inputs);
      case 'run_command':
        return await this.runCommand(action, inputs);
      default:
        throw new Error(`Unknown action type: ${action.type}`);
    }
  }

  /**
   * Create file action
   */
  async createFile(action, inputs) {
    try {
      // Render template
      const content = this.renderTemplate(action.template, inputs);

      // Ensure directory exists
      const dir = dirname(action.path);
      if (!existsSync(dir)) {
        await mkdir(dir, { recursive: true });
      }

      // Write file
      await writeFile(action.path, content, 'utf8');

      return {
        success: true,
        path: action.path,
        action: 'create_file'
      };
    } catch (error) {
      throw new Error(`Failed to create file ${action.path}: ${error.message}`);
    }
  }

  /**
   * Modify file action
   */
  async modifyFile(action, inputs) {
    try {
      if (action.operation === 'merge') {
        // Merge JSON data
        const existing = JSON.parse(await readFile(action.path, 'utf8'));
        const merged = this.deepMerge(existing, action.data);
        await writeFile(action.path, JSON.stringify(merged, null, 2), 'utf8');
      } else if (action.operation === 'append') {
        // Append text
        const existing = await readFile(action.path, 'utf8');
        const toAppend = this.renderTemplate(action.template, inputs);
        await writeFile(action.path, existing + toAppend, 'utf8');
      } else {
        throw new Error(`Unknown modify operation: ${action.operation}`);
      }

      return {
        success: true,
        path: action.path,
        action: 'modify_file',
        operation: action.operation
      };
    } catch (error) {
      throw new Error(`Failed to modify file ${action.path}: ${error.message}`);
    }
  }

  /**
   * Run command action (stub for now)
   */
  async runCommand(action, inputs) {
    // In production, this would execute the command
    // For now, we'll just return success
    return {
      success: true,
      command: action.command,
      action: 'run_command'
    };
  }

  /**
   * Deep merge two objects
   */
  deepMerge(target, source) {
    const output = { ...target };
    for (const key in source) {
      if (source[key] instanceof Object && key in target) {
        output[key] = this.deepMerge(target[key], source[key]);
      } else {
        output[key] = source[key];
      }
    }
    return output;
  }
}

/**
 * Recipe Registry - Manages collection of recipes
 */
export class RecipeRegistry {
  constructor() {
    this.recipes = new Map();
  }

  /**
   * Register a recipe
   */
  register(name, recipe) {
    this.recipes.set(name, recipe);
  }

  /**
   * Get a recipe by name
   */
  get(name) {
    return this.recipes.get(name);
  }

  /**
   * List all recipe names
   */
  list() {
    return Array.from(this.recipes.keys());
  }

  /**
   * Apply a recipe by name
   */
  async apply(recipeName, inputs = {}) {
    const recipe = this.get(recipeName);
    if (!recipe) {
      throw new Error(`Recipe not found: ${recipeName}`);
    }

    return await recipe.execute(inputs);
  }

  /**
   * Load recipes from YAML file
   */
  async loadFromFile(configPath) {
    try {
      const content = await readFile(configPath, 'utf8');
      const config = yaml.parse(content);

      if (!config.recipes) {
        throw new Error('No recipes found in config');
      }

      for (const [name, recipeConfig] of Object.entries(config.recipes)) {
        const recipe = new Recipe({
          name: recipeConfig.name || name,
          description: recipeConfig.description,
          version: recipeConfig.version,
          inputs: recipeConfig.inputs || [],
          actions: recipeConfig.actions || []
        });

        this.register(name, recipe);
      }
    } catch (error) {
      throw new Error(`Failed to load recipes from ${configPath}: ${error.message}`);
    }
  }
}
