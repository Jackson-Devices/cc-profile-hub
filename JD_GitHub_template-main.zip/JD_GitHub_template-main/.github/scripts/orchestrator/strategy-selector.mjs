/**
 * StrategySelector for Multi-Pass Fix Engine
 *
 * Selects the appropriate fix strategy based on attempt number.
 * Implements escalation: conservative → balanced → aggressive
 *
 * @class StrategySelector
 */
export default class StrategySelector {
  /**
   * Create a strategy selector
   * @param {string[]} strategies - Available strategies (ordered from conservative to aggressive)
   */
  constructor(strategies) {
    // Handle invalid input
    if (!Array.isArray(strategies)) {
      this.strategies = null;
    } else {
      this.strategies = strategies;
    }

    // If no argument provided, use defaults
    if (arguments.length === 0) {
      this.strategies = ['conservative', 'balanced', 'aggressive'];
    }
  }

  /**
   * Select strategy based on attempt number
   *
   * Strategy escalation schedule:
   * - Attempts 1-2: First strategy (conservative)
   * - Attempts 3-4: Second strategy (balanced)
   * - Attempts 5+: Third strategy (aggressive)
   *
   * @param {number} attempt - Current attempt number (1-based)
   * @returns {string|null} Selected strategy name, or null if no strategies available
   */
  selectStrategy(attempt) {
    // Handle invalid strategies
    if (!this.strategies || this.strategies.length === 0) {
      return null;
    }

    const index = this.getStrategyIndex(attempt);
    return this.strategies[index] || this.strategies[this.strategies.length - 1];
  }

  /**
   * Get the index of the strategy to use for a given attempt
   *
   * @param {number} attempt - Current attempt number (1-based)
   * @returns {number} Strategy index
   */
  getStrategyIndex(attempt) {
    // Handle edge cases
    if (attempt <= 0) {
      return 0; // Use first strategy as fallback
    }

    // Single strategy: always use it
    if (this.strategies.length === 1) {
      return 0;
    }

    // Two strategies: use first for 1-2, second for 3+
    if (this.strategies.length === 2) {
      return attempt <= 2 ? 0 : 1;
    }

    // Three or more strategies: escalate across 3 tiers
    if (attempt <= 2) {
      return 0; // First strategy (conservative)
    } else if (attempt <= 4) {
      return 1; // Second strategy (balanced)
    } else {
      return 2; // Third strategy (aggressive)
    }
  }

  /**
   * Check if more aggressive strategies are available
   *
   * @param {number} attempt - Current attempt number
   * @returns {boolean} True if more strategies available
   */
  hasMoreStrategies(attempt) {
    if (!this.strategies || this.strategies.length === 0) {
      return false;
    }

    const currentIndex = this.getStrategyIndex(attempt);
    const maxIndex = Math.min(2, this.strategies.length - 1);
    return currentIndex < maxIndex;
  }
}
