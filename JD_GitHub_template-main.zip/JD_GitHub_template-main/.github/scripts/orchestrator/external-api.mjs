/**
 * External Orchestration API
 *
 * Enables LLMs and external systems (Cloudflare Workers, etc.) to interact
 * with the orchestrator using JSON-RPC 2.0 protocol
 */

import { existsSync } from 'node:fs';
import { readFile } from 'node:fs/promises';

/**
 * JSON-RPC 2.0 Error Codes
 */
const ErrorCodes = {
  PARSE_ERROR: -32700,
  INVALID_REQUEST: -32600,
  METHOD_NOT_FOUND: -32601,
  INVALID_PARAMS: -32602,
  INTERNAL_ERROR: -32603
};

/**
 * Orchestrator API - Main API handler
 */
export class OrchestratorAPI {
  constructor(options = {}) {
    this.recipeRegistry = options.recipeRegistry;
    this.handlers = new Map();
    this.version = '2.0.0';
    this.registerHandlers();
  }

  /**
   * Register all API method handlers
   */
  registerHandlers() {
    this.handlers.set('ping', this.ping.bind(this));
    this.handlers.set('get_status', this.getStatus.bind(this));
    this.handlers.set('list_recipes', this.listRecipes.bind(this));
    this.handlers.set('get_recipe', this.getRecipe.bind(this));
    this.handlers.set('apply_recipe', this.applyRecipe.bind(this));
    this.handlers.set('suggest_fix', this.suggestFix.bind(this));
    this.handlers.set('get_project_context', this.getProjectContext.bind(this));
    this.handlers.set('validate_dependencies', this.validateDependencies.bind(this));
  }

  /**
   * Handle JSON-RPC 2.0 request
   */
  async handleRequest(request) {
    // Validate JSON-RPC version
    if (request.jsonrpc !== '2.0') {
      return this.createErrorResponse(
        request.id,
        ErrorCodes.INVALID_REQUEST,
        'Invalid Request: jsonrpc must be "2.0"'
      );
    }

    // Handle notification (no id) - return null (no response)
    if (request.id === undefined) {
      // Execute method but don't return response
      try {
        const handler = this.handlers.get(request.method);
        if (handler) {
          await handler(request.params || {});
        }
      } catch (error) {
        // Notifications don't get error responses
      }
      return null;
    }

    // Validate method exists
    if (!this.handlers.has(request.method)) {
      return this.createErrorResponse(
        request.id,
        ErrorCodes.METHOD_NOT_FOUND,
        `Method not found: ${request.method}`
      );
    }

    // Validate params (must be object or array if present)
    if (request.params !== undefined) {
      if (typeof request.params !== 'object') {
        return this.createErrorResponse(
          request.id,
          ErrorCodes.INVALID_PARAMS,
          'Invalid params: must be object or array'
        );
      }
    }

    // Execute method
    try {
      const handler = this.handlers.get(request.method);
      const result = await handler(request.params || {});
      return this.createSuccessResponse(request.id, result);
    } catch (error) {
      // Check if this is a validation error (invalid params)
      if (error.message.includes('Required input missing') ||
          error.message.includes('Recipe not found')) {
        return this.createErrorResponse(
          request.id,
          ErrorCodes.INVALID_PARAMS,
          error.message
        );
      }

      return this.createErrorResponse(
        request.id,
        ErrorCodes.INTERNAL_ERROR,
        `Internal error: ${error.message}`
      );
    }
  }

  /**
   * Create success response
   */
  createSuccessResponse(id, result) {
    return {
      jsonrpc: '2.0',
      result,
      id
    };
  }

  /**
   * Create error response
   */
  createErrorResponse(id, code, message) {
    return {
      jsonrpc: '2.0',
      error: {
        code,
        message
      },
      id
    };
  }

  /**
   * Ping - Simple health check
   */
  async ping() {
    return 'pong';
  }

  /**
   * Get orchestrator status
   */
  async getStatus() {
    return {
      status: 'running',
      version: this.version,
      modules: [
        'merge-conflict-analyzer',
        'consistency-checker',
        'recipe-system'
      ],
      recipeCount: this.recipeRegistry ? this.recipeRegistry.list().length : 0
    };
  }

  /**
   * List all available recipes
   */
  async listRecipes() {
    if (!this.recipeRegistry) {
      return { recipes: [] };
    }

    const recipeNames = this.recipeRegistry.list();
    const recipes = recipeNames.map(name => {
      const recipe = this.recipeRegistry.get(name);
      return {
        id: name,
        name: recipe.name,
        description: recipe.description || '',
        version: recipe.version || '1.0.0'
      };
    });

    return { recipes };
  }

  /**
   * Get detailed recipe information
   */
  async getRecipe(params) {
    if (!this.recipeRegistry) {
      throw new Error('Recipe registry not available');
    }

    const recipe = this.recipeRegistry.get(params.recipe_id);
    if (!recipe) {
      throw new Error(`Recipe not found: ${params.recipe_id}`);
    }

    return {
      id: params.recipe_id,
      name: recipe.name,
      description: recipe.description || '',
      version: recipe.version || '1.0.0',
      inputs: recipe.inputs,
      actions: recipe.actions
    };
  }

  /**
   * Apply a recipe
   */
  async applyRecipe(params) {
    if (!this.recipeRegistry) {
      throw new Error('Recipe registry not available');
    }

    const result = await this.recipeRegistry.apply(
      params.recipe_id,
      params.inputs || {}
    );

    return result;
  }

  /**
   * Suggest fix for common issues
   */
  async suggestFix(params) {
    const { issue_type, context } = params;

    // Knowledge base of common issues and their fixes
    const suggestions = {
      missing_readme: {
        suggestion: 'Create a README.md file to document your project',
        recipe_id: 'readme-template',
        inputs: {
          project_name: context.project_name || 'My Project',
          description: 'Project description'
        }
      },
      missing_gitignore: {
        suggestion: 'Add a .gitignore file to exclude unnecessary files from version control',
        recipe_id: 'gitignore-template',
        inputs: {
          project_type: context.project_type || 'nodejs'
        }
      },
      missing_package_json: {
        suggestion: 'Initialize a package.json for your Node.js project',
        recipe_id: 'package-json-template',
        inputs: {
          name: context.project_name || 'my-project'
        }
      },
      inconsistent_formatting: {
        suggestion: 'Apply consistent formatting using the consistency checker',
        recipe_id: null,
        action: 'run_consistency_check'
      }
    };

    const fix = suggestions[issue_type] || {
      suggestion: 'Please provide more details about the issue',
      recipe_id: null
    };

    return fix;
  }

  /**
   * Get project context information
   */
  async getProjectContext() {
    const context = {
      project_type: 'unknown',
      languages: [],
      has_package_json: existsSync('package.json'),
      has_readme: existsSync('README.md'),
      has_gitignore: existsSync('.gitignore'),
      has_git: existsSync('.git')
    };

    // Detect project type
    if (context.has_package_json) {
      context.project_type = 'nodejs';
      context.languages.push('javascript');

      // Try to read package.json for more details
      try {
        const pkg = JSON.parse(await readFile('package.json', 'utf8'));
        context.project_name = pkg.name;
        context.project_version = pkg.version;
        context.project_description = pkg.description;

        // Detect TypeScript
        if (pkg.devDependencies?.typescript || pkg.dependencies?.typescript) {
          context.languages.push('typescript');
        }
      } catch (error) {
        // Ignore errors reading package.json
      }
    }

    // Detect other files
    if (existsSync('Cargo.toml')) {
      context.project_type = 'rust';
      context.languages.push('rust');
    }

    if (existsSync('pyproject.toml') || existsSync('requirements.txt')) {
      context.project_type = 'python';
      context.languages.push('python');
    }

    if (existsSync('go.mod')) {
      context.project_type = 'go';
      context.languages.push('go');
    }

    return context;
  }

  /**
   * Validate contextual dependencies
   */
  async validateDependencies(params) {
    const { rules } = params;
    const violations = [];

    for (const rule of rules) {
      if (rule.condition === 'file_exists') {
        const fileExists = existsSync(rule.file);

        if (fileExists && rule.requires) {
          // Check if required files exist
          for (const requiredFile of rule.requires) {
            if (!existsSync(requiredFile)) {
              violations.push({
                rule: rule.file,
                violation: `File ${rule.file} exists but required file ${requiredFile} is missing`,
                severity: 'warning',
                fix_suggestion: `Create ${requiredFile}`
              });
            }
          }
        }
      }
    }

    return {
      valid: violations.length === 0,
      violations
    };
  }
}

/**
 * JSON-RPC Handler for stdin/stdout communication
 */
export class JSONRPCHandler {
  constructor(api) {
    this.api = api;
  }

  /**
   * Parse JSON-RPC request from string
   */
  parseRequest(input) {
    try {
      const trimmed = input.trim();
      return JSON.parse(trimmed);
    } catch (error) {
      throw new Error('Parse error: Invalid JSON');
    }
  }

  /**
   * Format response as JSON string
   */
  formatResponse(response) {
    return JSON.stringify(response) + '\n';
  }

  /**
   * Process request and return formatted response
   */
  async process(input) {
    try {
      const request = this.parseRequest(input);

      // Handle batch requests
      if (Array.isArray(request)) {
        const responses = await Promise.all(
          request.map(req => this.api.handleRequest(req))
        );
        // Filter out null responses (notifications)
        const filtered = responses.filter(r => r !== null);
        return this.formatResponse(filtered);
      }

      // Handle single request
      const response = await this.api.handleRequest(request);

      // Don't return anything for notifications
      if (response === null) {
        return '';
      }

      return this.formatResponse(response);
    } catch (error) {
      const errorResponse = {
        jsonrpc: '2.0',
        error: {
          code: ErrorCodes.PARSE_ERROR,
          message: error.message
        },
        id: null
      };
      return this.formatResponse(errorResponse);
    }
  }
}
