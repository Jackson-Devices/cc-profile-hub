/**
 * Orchestrator V2 Main Controller
 *
 * Coordinates all components to provide intelligent multi-pass
 * checking and fixing of code files.
 *
 * @class Orchestrator
 */

import FileDiscovery from './file-discovery.mjs';
import FileRouter from './file-router.mjs';
import MultiPassFixEngine from './fix-engine.mjs';
import { readFile } from 'node:fs/promises';
import { fileURLToPath } from 'node:url';
import { dirname, join } from 'node:path';

const __filename = fileURLToPath(import.meta.url);
const __dirname = dirname(__filename);

/**
 * Custom error for orchestrator failures
 */
export class OrchestratorError extends Error {
  constructor(message, details = {}) {
    super(message);
    this.name = 'OrchestratorError';
    this.details = details;
  }
}

export default class Orchestrator {
  /**
   * Create an orchestrator
   * @param {object} components - Optional dependency injection
   * @param {object} components.fileDiscovery - File discovery instance
   * @param {object} components.fileRouter - File router instance
   * @param {object} components.fixEngine - Fix engine instance
   */
  constructor(components = {}) {
    this.fileDiscovery = components.fileDiscovery || new FileDiscovery();
    this.fileRouter = components.fileRouter || null; // Will be initialized with config
    this.fixEngine = components.fixEngine || new MultiPassFixEngine();
  }

  /**
   * Run the orchestrator
   *
   * @param {object} context - Context for file discovery
   * @param {object} options - Orchestrator options
   * @param {number} options.maxAttempts - Max retry attempts per module
   * @param {number} options.timeout - Timeout per operation in ms
   * @returns {Promise<object>} Result with success and summary
   */
  async run(context, options = {}) {
    const {
      maxAttempts = 5,
      timeout = 60000,
    } = options;

    // Step 1: Discover files
    const files = await this.fileDiscovery.getChangedFiles(context);
    const classified = this.fileDiscovery.classifyFiles(files);

    // Step 2: Load module configuration and initialize router if needed
    if (!this.fileRouter) {
      const configPath = join(__dirname, '../../orchestrator-modules.yml');
      const moduleConfig = await this.loadModuleConfig(configPath);
      this.fileRouter = new FileRouter(moduleConfig);
    }

    // Step 3: Route files to modules
    const routedFiles = this.fileRouter.routeFiles(classified);

    // Step 4: Process each module's files
    const results = [];

    for (const [module, moduleFiles] of routedFiles) {
      const result = await this.fixEngine.fixWithRetries(module, moduleFiles, {
        maxAttempts,
        timeout,
      });

      results.push({
        module: module.name,
        files: moduleFiles,
        ...result,
      });
    }

    // Step 5: Generate summary
    const summary = this.generateSummary(results);

    // Step 6: Write GitHub summary if in CI
    if (process.env.GITHUB_STEP_SUMMARY) {
      await this.writeGitHubSummary(summary);
    }

    // Step 7: Determine overall success
    const allFixed = results.every((r) => r.success);

    if (!allFixed) {
      const failures = results.filter((r) => !r.success);
      throw new OrchestratorError(
        `Failed to fix all issues. Modules with failures: ${failures.map((f) => f.module).join(', ')}`,
        { failures, summary }
      );
    }

    return { success: true, summary };
  }

  /**
   * Load module configuration from YAML file
   * @param {string} configPath - Path to config file
   * @returns {Promise<object>} Module configuration
   */
  async loadModuleConfig(configPath) {
    try {
      const content = await readFile(configPath, 'utf8');
      // Simple YAML parsing (for production, use a proper YAML library)
      // For now, just return a mock structure since we're injecting in tests
      return {};
    } catch (error) {
      // If config doesn't exist, return empty config
      return {};
    }
  }

  /**
   * Generate summary from results
   * @param {Array} results - Results from all modules
   * @returns {object} Summary statistics
   */
  generateSummary(results) {
    const totalFiles = results.reduce((sum, r) => sum + r.files.length, 0);
    const successfulModules = results.filter((r) => r.success).length;
    const failedModules = results.filter((r) => !r.success).length;

    return {
      total_files: totalFiles,
      total_modules: results.length,
      successful_modules: successfulModules,
      failed_modules: failedModules,
      modules: results.map((r) => ({
        module: r.module,
        files: r.files,
        success: r.success,
        attempts: r.attempts,
        remaining_issues: r.remainingIssues || [],
        summary: r.summary,
      })),
    };
  }

  /**
   * Generate markdown summary
   * @param {object} summary - Summary object
   * @returns {string} Markdown formatted summary
   */
  generateMarkdownSummary(summary) {
    let md = '## 🔄 Orchestrator V2 Results\n\n';

    // Overall statistics
    md += '### Overall Statistics\n\n';
    md += `**Total Files:** ${summary.total_files}\n`;
    md += `**Total Modules:** ${summary.total_modules}\n`;
    md += `**Successful:** ✅ ${summary.successful_modules}\n`;
    md += `**Failed:** ❌ ${summary.failed_modules}\n\n`;

    // Module details
    if (summary.modules.length > 0) {
      md += '### Module Results\n\n';

      for (const module of summary.modules) {
        const icon = module.success ? '✅' : '❌';
        md += `#### ${icon} ${module.module}\n\n`;
        md += `- **Files:** ${module.files.length} (${module.files.join(', ')})\n`;
        md += `- **Attempts:** ${module.attempts}\n`;

        if (module.success) {
          md += `- **Status:** Success\n`;
        } else {
          md += `- **Status:** Failed\n`;
          if (module.remaining_issues && module.remaining_issues.length > 0) {
            md += `- **Remaining Issues:** ${module.remaining_issues.length}\n\n`;
            md += '**Details:**\n';
            for (const issue of module.remaining_issues.slice(0, 5)) {
              md += `  - ${issue.file}:${issue.line || '?'} - ${issue.message || 'Unknown error'}\n`;
            }
            if (module.remaining_issues.length > 5) {
              md += `  - ... and ${module.remaining_issues.length - 5} more\n`;
            }
          }
        }
        md += '\n';
      }
    }

    return md;
  }

  /**
   * Write summary to GitHub Step Summary
   * @param {object} summary - Summary object
   */
  async writeGitHubSummary(summary) {
    const markdown = this.generateMarkdownSummary(summary);

    // Write to GITHUB_STEP_SUMMARY file
    if (process.env.GITHUB_STEP_SUMMARY) {
      const fs = await import('node:fs/promises');
      await fs.appendFile(process.env.GITHUB_STEP_SUMMARY, markdown);
    }
  }
}
