/**
 * Module Registry for Orchestrator V2
 *
 * A singleton registry that stores references to module classes.
 * Modules can be registered and retrieved by name.
 *
 * @module ModuleRegistry
 */

/**
 * Module Registry
 *
 * @class ModuleRegistry
 */
class ModuleRegistry {
  constructor() {
    if (ModuleRegistry.instance) {
      return ModuleRegistry.instance;
    }

    this.modules = new Map();
    ModuleRegistry.instance = this;
  }

  /**
   * Register a module class
   *
   * @param {string} name - Module name (e.g., 'shell', 'javascript')
   * @param {class} moduleClass - Module class (must extend BaseModule)
   * @throws {Error} If name is empty or moduleClass is invalid
   *
   * @example
   * import registry from './module-registry.mjs';
   * import ShellModule from './modules/shell-module.mjs';
   *
   * registry.register('shell', ShellModule);
   */
  register(name, moduleClass) {
    if (!name || typeof name !== 'string') {
      throw new Error('Module name must be a non-empty string');
    }

    if (typeof moduleClass !== 'function') {
      throw new Error('Module class must be a constructor function');
    }

    this.modules.set(name, moduleClass);
  }

  /**
   * Get a module class by name
   *
   * @param {string} name - Module name
   * @returns {class|undefined} Module class or undefined if not found
   *
   * @example
   * const ShellModule = registry.get('shell');
   * if (ShellModule) {
   *   const instance = new ShellModule('shell', config);
   * }
   */
  get(name) {
    return this.modules.get(name);
  }

  /**
   * Check if a module is registered
   *
   * @param {string} name - Module name
   * @returns {boolean} True if module is registered
   *
   * @example
   * if (registry.has('shell')) {
   *   console.log('Shell module is available');
   * }
   */
  has(name) {
    return this.modules.has(name);
  }

  /**
   * Get list of all registered module names
   *
   * @returns {Array<string>} Array of module names
   *
   * @example
   * const moduleNames = registry.list();
   * console.log(`Available modules: ${moduleNames.join(', ')}`);
   */
  list() {
    return Array.from(this.modules.keys());
  }

  /**
   * Unregister a module
   *
   * @param {string} name - Module name
   * @returns {boolean} True if module was removed, false if it didn't exist
   *
   * @example
   * registry.unregister('shell');
   */
  unregister(name) {
    return this.modules.delete(name);
  }

  /**
   * Clear all registered modules
   *
   * Useful for testing.
   *
   * @example
   * registry.clear(); // Remove all modules
   */
  clear() {
    this.modules.clear();
  }

  /**
   * Get count of registered modules
   *
   * @returns {number} Number of registered modules
   */
  count() {
    return this.modules.size;
  }
}

// Create and export singleton instance
const registry = new ModuleRegistry();

export default registry;
