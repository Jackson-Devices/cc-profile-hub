/**
 * File Router for Orchestrator V2
 *
 * Routes files to appropriate modules based on configuration.
 * Reads module configuration and determines which module should handle each file.
 *
 * @module FileRouter
 */

import * as fs from 'node:fs/promises';
import YAML from 'yaml';

/**
 * Routing result for a single file
 * @typedef {Object} FileRoute
 * @property {string} file - File path
 * @property {string} module_name - Name of module that should handle this file
 * @property {Object} module_config - Configuration for the module
 */

/**
 * Routing result for multiple files
 * @typedef {Object} RoutingResult
 * @property {Object<string, Array<string>>} routes - Files grouped by module name
 * @property {Array<string>} unrouted - Files that couldn't be routed
 * @property {number} total - Total number of files processed
 */

/**
 * File Router
 *
 * @class FileRouter
 */
export default class FileRouter {
  /**
   * Create a file router
   *
   * @param {Object} options - Options
   * @param {string} [options.config_path] - Path to module configuration file
   * @param {Object} [options.config] - Pre-loaded configuration (overrides config_path)
   */
  constructor(options = {}) {
    this.configPath =
      options.config_path || '.github/orchestrator-modules.yml';
    this.config = options.config || null;
    this.modules = new Map();
    this.routingRules = null;
  }

  /**
   * Load configuration from file or use provided config
   *
   * @returns {Promise<void>}
   */
  async loadConfig() {
    if (this.config) {
      // Use provided config
      await this.parseConfig(this.config);
      return;
    }

    // Load from file
    try {
      const content = await fs.readFile(this.configPath, 'utf8');
      const config = YAML.parse(content);
      await this.parseConfig(config);
    } catch (error) {
      throw new Error(
        `Failed to load configuration from ${this.configPath}: ${error.message}`
      );
    }
  }

  /**
   * Parse and validate configuration
   *
   * @param {Object} config - Configuration object
   * @returns {Promise<void>}
   * @private
   */
  async parseConfig(config) {
    if (!config.modules) {
      throw new Error('Configuration must have "modules" section');
    }

    // Store module configurations
    for (const [name, moduleConfig] of Object.entries(config.modules)) {
      if (moduleConfig.enabled !== false) {
        // Only store enabled modules
        // Spread first, then override name with key to ensure key is used as identifier
        this.modules.set(name, {
          ...moduleConfig,
          name,  // Use key as the primary name identifier
        });
      }
    }

    // Store routing rules
    this.routingRules = config.routing || {};
  }

  /**
   * Get module configuration by name
   *
   * @param {string} name - Module name
   * @returns {Object|null} Module configuration or null if not found
   */
  getModuleConfig(name) {
    return this.modules.get(name) || null;
  }

  /**
   * Get all enabled modules
   *
   * @returns {Array<Object>} Array of module configurations
   */
  getEnabledModules() {
    return Array.from(this.modules.values());
  }

  /**
   * Find which module should handle a file
   *
   * @param {string} filename - File path
   * @returns {Object|null} Module configuration or null if no module found
   *
   * @example
   * const module = router.findModuleForFile('script.sh');
   * // Returns: { name: 'shell', extensions: ['.sh'], ... }
   */
  findModuleForFile(filename) {
    if (!filename) return null;

    const matches = [];

    // Find all modules that can handle this file
    for (const module of this.modules.values()) {
      // Check extension match
      if (module.extensions && module.extensions.some((ext) => filename.endsWith(ext))) {
        matches.push(module);
        continue;
      }

      // Check pattern match (if patterns defined)
      if (module.patterns && module.patterns.length > 0) {
        for (const pattern of module.patterns) {
          if (this.matchesPattern(filename, pattern)) {
            matches.push(module);
            break;
          }
        }
      }
    }

    if (matches.length === 0) {
      return null;
    }

    // If multiple matches, use priority (higher priority wins)
    matches.sort((a, b) => (b.priority || 0) - (a.priority || 0));

    return matches[0];
  }

  /**
   * Route multiple files to their appropriate modules
   *
   * @param {Array<string>} files - Files to route
   * @returns {RoutingResult} Routing result
   *
   * @example
   * const result = router.routeFiles([
   *   'script.sh',
   *   'index.js',
   *   'unknown.xyz'
   * ]);
   * // Returns:
   * // {
   * //   routes: {
   * //     shell: ['script.sh'],
   * //     javascript: ['index.js']
   * //   },
   * //   unrouted: ['unknown.xyz'],
   * //   total: 3
   * // }
   */
  routeFiles(files) {
    const routes = {};
    const unrouted = [];

    for (const file of files) {
      const module = this.findModuleForFile(file);

      if (module) {
        if (!routes[module.name]) {
          routes[module.name] = [];
        }
        routes[module.name].push(file);
      } else {
        unrouted.push(file);
      }
    }

    // Handle unrouted files according to policy
    if (unrouted.length > 0) {
      this.handleUnrouted(unrouted);
    }

    return {
      routes,
      unrouted,
      total: files.length,
    };
  }

  /**
   * Handle unrouted files according to policy
   *
   * @param {Array<string>} files - Unrouted files
   * @private
   */
  handleUnrouted(files) {
    const action = this.routingRules?.unknown_files?.action || 'warn';

    switch (action) {
      case 'ignore':
        // Do nothing
        break;

      case 'warn':
        console.warn(
          `Warning: ${files.length} file(s) could not be routed to any module:`
        );
        files.forEach((f) => console.warn(`  - ${f}`));
        break;

      case 'error':
        throw new Error(
          `Unknown file types detected: ${files.join(', ')}`
        );

      default:
        console.warn(`Unknown action for unrouted files: ${action}`);
    }
  }

  /**
   * Simple glob pattern matching
   *
   * Supports * and ** wildcards.
   *
   * @param {string} file - File path
   * @param {string} pattern - Glob pattern
   * @returns {boolean} True if file matches pattern
   * @private
   */
  matchesPattern(file, pattern) {
    // Escape special regex characters except * and /
    let regexPattern = pattern.replace(/[.+?^${}()|[\]\\]/g, '\\$&');

    // Replace ** with placeholder
    regexPattern = regexPattern.replace(/\*\*/g, '<<<DOUBLESTAR>>>');

    // Replace * with regex for anything except /
    regexPattern = regexPattern.replace(/\*/g, '[^/]*');

    // Replace ** with regex for anything including /
    regexPattern = regexPattern.replace(/<<<DOUBLESTAR>>>/g, '.*');

    const regex = new RegExp(`^${regexPattern}$`);
    return regex.test(file);
  }

  /**
   * Get routing statistics
   *
   * @param {RoutingResult} result - Routing result
   * @returns {Object} Statistics
   */
  getStatistics(result) {
    const stats = {
      total: result.total,
      routed: result.total - result.unrouted.length,
      unrouted: result.unrouted.length,
      by_module: {},
    };

    for (const [moduleName, files] of Object.entries(result.routes)) {
      stats.by_module[moduleName] = files.length;
    }

    return stats;
  }

  /**
   * Validate that router is ready
   *
   * @returns {Object} Validation result
   * @property {boolean} ready - Whether router is ready
   * @property {Array<string>} issues - Any issues found
   */
  validate() {
    const issues = [];

    if (this.modules.size === 0) {
      issues.push('No enabled modules found in configuration');
    }

    if (!this.routingRules) {
      issues.push('No routing rules found in configuration');
    }

    return {
      ready: issues.length === 0,
      issues,
    };
  }
}
