/**
 * File Discovery Service for Orchestrator V2
 *
 * Discovers and classifies files for processing by the orchestrator.
 * Supports multiple discovery modes:
 * - Git diff (changed files in working directory)
 * - PR files (files changed in a pull request)
 * - Manual file list
 *
 * @module FileDiscovery
 */

import { exec } from 'node:child_process';
import { promisify } from 'node:util';
import * as fs from 'node:fs/promises';
import * as path from 'node:path';

const execAsync = promisify(exec);

/**
 * Discovery context
 * @typedef {Object} DiscoveryContext
 * @property {string} mode - Discovery mode: 'git-diff', 'pr', 'manual'
 * @property {string} [base_ref] - Base reference for comparison (for git-diff mode)
 * @property {string} [head_ref] - Head reference for comparison (for git-diff mode)
 * @property {Array<string>} [files] - Manual file list (for manual mode)
 * @property {Object} [github_context] - GitHub Actions context (for PR mode)
 */

/**
 * File classification result
 * @typedef {Object} ClassificationResult
 * @property {Object<string, Array<string>>} classified - Files grouped by type
 * @property {Array<string>} unknown - Files that couldn't be classified
 * @property {number} total - Total number of files
 */

/**
 * File Discovery Service
 *
 * @class FileDiscovery
 */
export default class FileDiscovery {
  /**
   * Create a file discovery service
   *
   * @param {Object} options - Options
   * @param {string} [options.cwd] - Working directory (defaults to process.cwd())
   * @param {Array<string>} [options.exclude_patterns] - Patterns to exclude
   */
  constructor(options = {}) {
    this.cwd = options.cwd || process.cwd();
    this.excludePatterns = options.exclude_patterns || [
      'node_modules/**',
      '.git/**',
      'dist/**',
      'build/**',
      '*.min.js',
      '*.min.css',
    ];
  }

  /**
   * Discover changed files based on context
   *
   * @param {DiscoveryContext} context - Discovery context
   * @returns {Promise<Array<string>>} List of discovered files
   *
   * @example
   * // Git diff mode
   * const files = await discovery.discoverFiles({
   *   mode: 'git-diff',
   *   base_ref: 'main',
   *   head_ref: 'HEAD'
   * });
   *
   * // Manual mode
   * const files = await discovery.discoverFiles({
   *   mode: 'manual',
   *   files: ['file1.sh', 'file2.js']
   * });
   */
  async discoverFiles(context) {
    const { mode } = context;

    switch (mode) {
      case 'git-diff':
        return await this.discoverFromGitDiff(context);

      case 'pr':
        return await this.discoverFromPR(context);

      case 'manual':
        return this.discoverFromManualList(context);

      default:
        throw new Error(`Unknown discovery mode: ${mode}`);
    }
  }

  /**
   * Discover files from git diff
   *
   * @param {DiscoveryContext} context - Context with base_ref and head_ref
   * @returns {Promise<Array<string>>} List of changed files
   * @private
   */
  async discoverFromGitDiff(context) {
    const { base_ref = 'main', head_ref = 'HEAD' } = context;

    try {
      // Get list of changed files between base and head
      const { stdout } = await execAsync(
        `git diff --name-only --diff-filter=ACMRT ${base_ref}...${head_ref}`,
        {
          cwd: this.cwd,
          maxBuffer: 10 * 1024 * 1024, // 10MB buffer
        }
      );

      const files = stdout
        .trim()
        .split('\n')
        .filter((f) => f.length > 0);

      return this.filterFiles(files);
    } catch (error) {
      throw new Error(`Failed to discover files from git diff: ${error.message}`);
    }
  }

  /**
   * Discover files from GitHub PR
   *
   * Uses GitHub Actions context or Octokit API.
   *
   * @param {DiscoveryContext} context - Context with github_context
   * @returns {Promise<Array<string>>} List of files in PR
   * @private
   */
  async discoverFromPR(context) {
    const { github_context } = context;

    if (!github_context) {
      throw new Error('github_context is required for PR discovery mode');
    }

    // For now, fall back to git diff using PR base and head
    // In a real implementation, this would use the GitHub API
    return await this.discoverFromGitDiff({
      base_ref: github_context.base_ref || 'origin/main',
      head_ref: github_context.head_ref || 'HEAD',
    });
  }

  /**
   * Discover files from manual list
   *
   * @param {DiscoveryContext} context - Context with files array
   * @returns {Array<string>} List of files
   * @private
   */
  discoverFromManualList(context) {
    const { files } = context;

    if (!files || !Array.isArray(files)) {
      throw new Error('files array is required for manual discovery mode');
    }

    return this.filterFiles(files);
  }

  /**
   * Filter files based on exclude patterns
   *
   * @param {Array<string>} files - Files to filter
   * @returns {Array<string>} Filtered files
   * @private
   */
  filterFiles(files) {
    return files.filter((file) => {
      // Check if file matches any exclude pattern
      for (const pattern of this.excludePatterns) {
        if (this.matchesPattern(file, pattern)) {
          return false;
        }
      }
      return true;
    });
  }

  /**
   * Check if file matches a glob-like pattern
   *
   * Simple pattern matching (supports * and **)
   *
   * @param {string} file - File path
   * @param {string} pattern - Pattern to match
   * @returns {boolean} True if file matches pattern
   * @private
   */
  matchesPattern(file, pattern) {
    // Convert glob pattern to regex
    // ** matches any number of directories (including zero)
    // * matches anything except /

    // Escape special regex characters except * and /
    let regexPattern = pattern.replace(/[.+?^${}()|[\]\\]/g, '\\$&');

    // Replace ** with a placeholder first
    regexPattern = regexPattern.replace(/\*\*/g, '<<<DOUBLESTAR>>>');

    // Replace remaining * with regex for anything except /
    regexPattern = regexPattern.replace(/\*/g, '[^/]*');

    // Replace ** placeholder with regex for anything including /
    regexPattern = regexPattern.replace(/<<<DOUBLESTAR>>>/g, '.*');

    const regex = new RegExp(`^${regexPattern}$`);
    return regex.test(file);
  }

  /**
   * Classify files by extension
   *
   * @param {Array<string>} files - Files to classify
   * @returns {ClassificationResult} Classification result
   *
   * @example
   * const result = discovery.classifyFiles([
   *   'script.sh',
   *   'index.js',
   *   'config.yml',
   *   'unknown.xyz'
   * ]);
   * // Returns:
   * // {
   * //   classified: {
   * //     shell: ['script.sh'],
   * //     javascript: ['index.js'],
   * //     yaml: ['config.yml']
   * //   },
   * //   unknown: ['unknown.xyz'],
   * //   total: 4
   * // }
   */
  classifyFiles(files) {
    const classified = {};
    const unknown = [];

    // Define extension to type mapping
    const extensionMap = {
      shell: ['.sh', '.bash', '.zsh', '.ksh'],
      javascript: ['.js', '.mjs', '.cjs', '.ts', '.tsx', '.jsx'],
      yaml: ['.yml', '.yaml'],
      python: ['.py', '.pyw'],
      cpp: ['.cpp', '.hpp', '.h', '.c', '.cc', '.cxx', '.ino'],
      json: ['.json'],
      markdown: ['.md', '.markdown'],
      css: ['.css', '.scss', '.sass', '.less'],
      html: ['.html', '.htm'],
    };

    for (const file of files) {
      let fileType = null;

      // Find matching type
      for (const [type, extensions] of Object.entries(extensionMap)) {
        if (extensions.some((ext) => file.endsWith(ext))) {
          fileType = type;
          break;
        }
      }

      if (fileType) {
        if (!classified[fileType]) {
          classified[fileType] = [];
        }
        classified[fileType].push(file);
      } else {
        unknown.push(file);
      }
    }

    return {
      classified,
      unknown,
      total: files.length,
    };
  }

  /**
   * Get statistics about discovered files
   *
   * @param {ClassificationResult} classification - Classification result
   * @returns {Object} Statistics
   *
   * @example
   * const stats = discovery.getStatistics(classification);
   * // Returns:
   * // {
   * //   total: 4,
   * //   by_type: {
   * //     shell: 1,
   * //     javascript: 1,
   * //     yaml: 1
   * //   },
   * //   unknown: 1
   * // }
   */
  getStatistics(classification) {
    const stats = {
      total: classification.total,
      by_type: {},
      unknown: classification.unknown.length,
    };

    for (const [type, files] of Object.entries(classification.classified)) {
      stats.by_type[type] = files.length;
    }

    return stats;
  }

  /**
   * Verify files exist on disk
   *
   * @param {Array<string>} files - Files to verify
   * @returns {Promise<Object>} Verification result
   * @property {Array<string>} existing - Files that exist
   * @property {Array<string>} missing - Files that don't exist
   *
   * @example
   * const result = await discovery.verifyFilesExist(files);
   * if (result.missing.length > 0) {
   *   console.warn(`Missing files: ${result.missing.join(', ')}`);
   * }
   */
  async verifyFilesExist(files) {
    const existing = [];
    const missing = [];

    for (const file of files) {
      const fullPath = path.isAbsolute(file) ? file : path.join(this.cwd, file);

      try {
        await fs.access(fullPath);
        existing.push(file);
      } catch {
        missing.push(file);
      }
    }

    return { existing, missing };
  }
}
