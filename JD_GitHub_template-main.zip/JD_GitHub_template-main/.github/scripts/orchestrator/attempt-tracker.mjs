/**
 * AttemptTracker for Multi-Pass Fix Engine
 *
 * Records each check and fix attempt during execution.
 * Tracks progress and provides diagnostic information.
 *
 * @class AttemptTracker
 */
export default class AttemptTracker {
  constructor() {
    this.log = [];
  }

  /**
   * Record a check attempt
   * @param {number} attempt - Attempt number
   * @param {object} result - Check result
   */
  recordCheck(attempt, result) {
    this.log.push({
      attempt,
      phase: 'check',
      result,
      timestamp: Date.now(),
    });
  }

  /**
   * Record a fix attempt
   * @param {number} attempt - Attempt number
   * @param {string} strategy - Strategy used
   * @param {object} result - Fix result
   */
  recordFix(attempt, strategy, result) {
    this.log.push({
      attempt,
      phase: 'fix',
      strategy,
      result,
      timestamp: Date.now(),
    });
  }

  /**
   * Get the full log
   * @returns {Array} Copy of the log
   */
  getLog() {
    return [...this.log];
  }

  /**
   * Get the count of recorded attempts
   * @returns {number} Number of attempts (checks + fixes)
   */
  getAttemptCount() {
    return this.log.length;
  }

  /**
   * Get the last check result
   * @returns {object|null} Last check entry, or null if none
   */
  getLastCheck() {
    for (let i = this.log.length - 1; i >= 0; i--) {
      if (this.log[i].phase === 'check') {
        return this.log[i];
      }
    }
    return null;
  }

  /**
   * Get the last fix result
   * @returns {object|null} Last fix entry, or null if none
   */
  getLastFix() {
    for (let i = this.log.length - 1; i >= 0; i--) {
      if (this.log[i].phase === 'fix') {
        return this.log[i];
      }
    }
    return null;
  }

  /**
   * Get the issue count from the last check
   * @returns {number} Number of issues, or 0 if no checks
   */
  getIssueCount() {
    const lastCheck = this.getLastCheck();
    if (!lastCheck) {
      return 0;
    }
    return lastCheck.result?.issues?.length || 0;
  }

  /**
   * Check if progress was made (issues decreased)
   * @returns {boolean} True if issues decreased between checks
   */
  hasProgress() {
    const checks = this.log.filter((entry) => entry.phase === 'check');

    if (checks.length < 2) {
      return false;
    }

    const previousCheck = checks[checks.length - 2];
    const lastCheck = checks[checks.length - 1];

    const previousIssues = previousCheck.result?.issues?.length || 0;
    const currentIssues = lastCheck.result?.issues?.length || 0;

    return currentIssues < previousIssues;
  }

  /**
   * Get a summary of all attempts
   * @returns {object} Summary statistics
   */
  getSummary() {
    const checks = this.log.filter((entry) => entry.phase === 'check');
    const fixes = this.log.filter((entry) => entry.phase === 'fix');

    const firstCheck = checks[0];
    const lastCheck = checks[checks.length - 1];

    return {
      total_attempts: this.log.length,
      total_checks: checks.length,
      total_fixes: fixes.length,
      initial_issue_count: firstCheck?.result?.issues?.length || 0,
      final_issue_count: lastCheck?.result?.issues?.length || 0,
      final_success: lastCheck?.result?.success || false,
    };
  }
}
