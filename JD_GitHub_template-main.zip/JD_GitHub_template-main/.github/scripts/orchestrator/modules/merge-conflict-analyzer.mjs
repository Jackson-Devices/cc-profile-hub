/**
 * Merge Conflict Analyzer Module
 *
 * Intelligently analyzes and resolves merge conflicts between branches
 * by performing semantic diff analysis instead of just line-based diffs.
 */

import { exec } from 'node:child_process';
import { promisify } from 'node:util';

const execAsync = promisify(exec);

/**
 * Base module interface (simplified for now)
 */
class BaseModule {
  constructor(name, config = {}) {
    this.name = name;
    this.config = config;
  }
}

export default class MergeConflictAnalyzer extends BaseModule {
  constructor(config = {}) {
    super('merge-conflict-analyzer', {
      ...config,
      type: 'domain',
      capabilities: ['semantic_analysis', 'cross_file', 'auto_resolution'],
      enabled: true,
      priority: 200
    });

    // Language-specific parsers
    this.parsers = {
      '.md': new MarkdownParser(),
      '.json': new JSONParser(),
      '.yml': new YAMLParser(),
      '.yaml': new YAMLParser(),
      '.js': new JavaScriptParser(),
      '.mjs': new JavaScriptParser()
    };
  }

  /**
   * Analyze potential merge conflicts between two branches
   */
  async analyzeMerge(branchA, branchB, baseBranch = 'main') {
    // Step 1: Find overlapping files
    const overlap = await this.findOverlappingFiles(branchA, branchB, baseBranch);

    if (overlap.files.length === 0) {
      return {
        canAutoMerge: true,
        conflicts: [],
        message: 'No overlapping files - clean merge possible',
        totalFiles: 0,
        autoResolvable: 0,
        needsManualReview: 0,
        analyses: [],
        breakdown: {}
      };
    }

    // Step 2: Analyze each overlapping file
    const analyses = [];
    for (const file of overlap.files) {
      const analysis = await this.analyzeFile(file, branchA, branchB, baseBranch);
      analyses.push(analysis);
    }

    // Step 3: Categorize and summarize
    const summary = this.summarizeAnalyses(analyses);

    return summary;
  }

  /**
   * Find files that were modified in both branches
   */
  async findOverlappingFiles(branchA, branchB, baseBranch) {
    try {
      // Get files changed in branch A
      const { stdout: filesA } = await execAsync(
        `git diff --name-only ${baseBranch}...${branchA}`
      );

      // Get files changed in branch B
      const { stdout: filesB } = await execAsync(
        `git diff --name-only ${baseBranch}...${branchB}`
      );

      const setA = new Set(filesA.trim().split('\n').filter(Boolean));
      const setB = new Set(filesB.trim().split('\n').filter(Boolean));

      const overlapping = [...setA].filter(f => setB.has(f));

      return {
        files: overlapping,
        totalA: setA.size,
        totalB: setB.size
      };
    } catch (error) {
      console.error('Error finding overlapping files:', error.message);
      return {
        files: [],
        totalA: 0,
        totalB: 0
      };
    }
  }

  /**
   * Analyze a single file for merge conflicts
   */
  async analyzeFile(file, branchA, branchB, baseBranch) {
    try {
      // Get three versions
      const base = await this.getFileVersion(file, baseBranch);
      const versionA = await this.getFileVersion(file, branchA);
      const versionB = await this.getFileVersion(file, branchB);

      // Check if one or both are deletions
      if (!versionA && !versionB) {
        return {
          file,
          type: 'both-deleted',
          canAutoResolve: true,
          resolution: 'delete',
          confidence: 1.0,
          needsManualReview: false
        };
      }

      if (!versionA || !versionB) {
        return {
          file,
          type: 'one-deleted',
          canAutoResolve: false,
          reason: 'One branch deleted file, other modified it',
          needsManualReview: true
        };
      }

      // Check for identical changes first (simple string comparison)
      if (versionA === versionB) {
        return {
          file,
          type: 'identical-changes',
          canAutoResolve: true,
          resolution: 'use-either',
          confidence: 1.0,
          needsManualReview: false
        };
      }

      // Get parser for file type
      const parser = this.getParser(file);

      if (parser) {
        // Semantic analysis
        return await this.semanticAnalysis(file, base, versionA, versionB, parser);
      } else {
        // Line-based analysis (fallback)
        return await this.lineBasedAnalysis(file, base, versionA, versionB);
      }

    } catch (error) {
      return {
        file,
        type: 'error',
        error: error.message,
        needsManualReview: true,
        canAutoResolve: false
      };
    }
  }

  /**
   * Semantic analysis using language-specific parser
   */
  async semanticAnalysis(file, base, versionA, versionB, parser) {
    try {
      // First check for formatting-only differences
      const normalizedA = this.normalizeWhitespace(versionA);
      const normalizedB = this.normalizeWhitespace(versionB);

      if (normalizedA === normalizedB && versionA !== versionB) {
        return {
          file,
          type: 'formatting-only-difference',
          canAutoResolve: true,
          resolution: 'use-either-and-reformat',
          confidence: 1.0,
          needsManualReview: false,
          details: 'Content identical after formatting normalization'
        };
      }

      // Parse all three versions
      const baseAST = parser.parse(base);
      const astA = parser.parse(versionA);
      const astB = parser.parse(versionB);

      // Generate semantic diffs
      const diffA = parser.diff(baseAST, astA);
      const diffB = parser.diff(baseAST, astB);

      // Check for identical changes
      if (this.diffsAreIdentical(diffA, diffB)) {
        return {
          file,
          type: 'identical-changes',
          canAutoResolve: true,
          resolution: 'use-either',
          confidence: 1.0,
          needsManualReview: false,
          details: 'Both branches made identical changes'
        };
      }

      // Check for compatible structural changes first (semantic check)
      // This is important for structured formats like JSON where changes to
      // different keys should be considered compatible even if they overlap at line level
      if (parser.changesAreCompatible(diffA, diffB)) {
        return {
          file,
          type: 'compatible-structural',
          canAutoResolve: true,
          resolution: 'merge-both',
          confidence: 0.9,
          needsManualReview: false,
          details: parser.getCompatibilityExplanation(diffA, diffB)
        };
      }

      // Check for non-overlapping changes (fallback for simpler cases)
      if (!this.diffsOverlap(diffA, diffB)) {
        return {
          file,
          type: 'non-overlapping',
          canAutoResolve: true,
          resolution: 'merge-both',
          confidence: 0.95,
          needsManualReview: false,
          details: 'Changes affect different parts of the file'
        };
      }

      // Semantic conflict
      return {
        file,
        type: 'semantic-conflict',
        canAutoResolve: false,
        needsManualReview: true,
        details: {
          branchA: diffA,
          branchB: diffB,
          conflictingElements: parser.findConflictingElements(diffA, diffB)
        }
      };

    } catch (error) {
      // Fall back to line-based analysis
      return await this.lineBasedAnalysis(file, base, versionA, versionB);
    }
  }

  /**
   * Line-based analysis (fallback)
   */
  async lineBasedAnalysis(file, base, versionA, versionB) {
    // Normalize formatting
    const normalizedBase = this.normalizeWhitespace(base);
    const normalizedA = this.normalizeWhitespace(versionA);
    const normalizedB = this.normalizeWhitespace(versionB);

    // Check if identical after normalization
    if (normalizedA === normalizedB) {
      return {
        file,
        type: 'formatting-only-difference',
        canAutoResolve: true,
        resolution: 'use-either-and-reformat',
        confidence: 1.0,
        needsManualReview: false,
        details: 'Content identical after formatting normalization'
      };
    }

    // Line-by-line diff
    const linesBase = normalizedBase.split('\n');
    const linesA = normalizedA.split('\n');
    const linesB = normalizedB.split('\n');

    // Find changed line ranges
    const changedA = this.findChangedLines(linesBase, linesA);
    const changedB = this.findChangedLines(linesBase, linesB);

    // Check for overlap
    if (!this.rangesOverlap(changedA, changedB)) {
      return {
        file,
        type: 'non-overlapping-lines',
        canAutoResolve: true,
        resolution: 'merge-both',
        confidence: 0.85,
        needsManualReview: false,
        details: `Branch A changed lines ${this.formatRanges(changedA)}, Branch B changed lines ${this.formatRanges(changedB)}`
      };
    }

    // Line-level conflict
    return {
      file,
      type: 'line-conflict',
      canAutoResolve: false,
      needsManualReview: true,
      details: {
        overlappingRanges: this.findOverlappingRanges(changedA, changedB)
      }
    };
  }

  /**
   * Get file content at specific branch/commit
   */
  async getFileVersion(file, ref) {
    try {
      const { stdout } = await execAsync(`git show ${ref}:${file}`);
      return stdout;
    } catch (error) {
      return null;
    }
  }

  /**
   * Get appropriate parser for file type
   */
  getParser(file) {
    const ext = file.substring(file.lastIndexOf('.'));
    return this.parsers[ext] || null;
  }

  /**
   * Normalize whitespace for comparison
   */
  normalizeWhitespace(content) {
    if (!content) return '';

    return content
      .replace(/[ \t]+$/gm, '')     // Remove trailing spaces
      .replace(/\r\n/g, '\n')       // Normalize line endings
      .replace(/\n{3,}/g, '\n\n')   // Collapse multiple blank lines
      .trim() + '\n';               // Ensure single final newline
  }

  /**
   * Find changed lines between two versions
   */
  findChangedLines(baseLines, newLines) {
    const ranges = [];
    let currentRange = null;

    for (let i = 0; i < Math.max(baseLines.length, newLines.length); i++) {
      const baseLine = baseLines[i] || '';
      const newLine = newLines[i] || '';

      if (baseLine !== newLine) {
        if (!currentRange) {
          currentRange = { start: i + 1, end: i + 1 };
        } else {
          currentRange.end = i + 1;
        }
      } else if (currentRange) {
        ranges.push(currentRange);
        currentRange = null;
      }
    }

    if (currentRange) {
      ranges.push(currentRange);
    }

    return ranges;
  }

  /**
   * Check if two ranges overlap
   */
  rangesOverlap(rangesA, rangesB) {
    for (const rangeA of rangesA) {
      for (const rangeB of rangesB) {
        if (this.rangeOverlap(rangeA, rangeB)) {
          return true;
        }
      }
    }
    return false;
  }

  /**
   * Check if two individual ranges overlap
   */
  rangeOverlap(range1, range2) {
    return range1.start <= range2.end && range2.start <= range1.end;
  }

  /**
   * Find overlapping ranges
   */
  findOverlappingRanges(rangesA, rangesB) {
    const overlapping = [];

    for (const rangeA of rangesA) {
      for (const rangeB of rangesB) {
        if (this.rangeOverlap(rangeA, rangeB)) {
          overlapping.push({
            rangeA,
            rangeB,
            overlap: {
              start: Math.max(rangeA.start, rangeB.start),
              end: Math.min(rangeA.end, rangeB.end)
            }
          });
        }
      }
    }

    return overlapping;
  }

  /**
   * Format ranges for display
   */
  formatRanges(ranges) {
    return ranges.map(r =>
      r.start === r.end ? `${r.start}` : `${r.start}-${r.end}`
    ).join(', ');
  }

  /**
   * Check if two diffs are identical
   */
  diffsAreIdentical(diffA, diffB) {
    return JSON.stringify(diffA) === JSON.stringify(diffB);
  }

  /**
   * Check if two diffs overlap
   */
  diffsOverlap(diffA, diffB) {
    const changedA = new Set(diffA.map(d => d.path || d.line || d.section));
    const changedB = new Set(diffB.map(d => d.path || d.line || d.section));

    for (const item of changedA) {
      if (changedB.has(item)) {
        return true;
      }
    }

    return false;
  }

  /**
   * Summarize all file analyses
   */
  summarizeAnalyses(analyses) {
    const autoResolvable = analyses.filter(a => a.canAutoResolve);
    const needsReview = analyses.filter(a => a.needsManualReview);

    const breakdown = {};
    for (const analysis of analyses) {
      breakdown[analysis.type] = (breakdown[analysis.type] || 0) + 1;
    }

    return {
      totalFiles: analyses.length,
      canAutoMerge: needsReview.length === 0,
      autoResolvable: autoResolvable.length,
      needsManualReview: needsReview.length,
      analyses,
      breakdown
    };
  }
}

/**
 * Markdown Parser
 */
class MarkdownParser {
  parse(content) {
    const lines = content.split('\n');
    const ast = {
      type: 'document',
      headings: [],
      sections: []
    };

    let currentSection = null;

    for (let i = 0; i < lines.length; i++) {
      const line = lines[i];

      if (line.match(/^#+\s/)) {
        const level = line.match(/^#+/)[0].length;
        const heading = {
          level,
          text: line.replace(/^#+\s+/, ''),
          line: i + 1
        };
        ast.headings.push(heading);

        currentSection = {
          heading,
          content: [],
          startLine: i + 1
        };
        ast.sections.push(currentSection);
      } else if (currentSection) {
        currentSection.content.push({ line: i + 1, text: line });
      }
    }

    return ast;
  }

  diff(baseAST, newAST) {
    const changes = [];

    // Compare sections
    const baseSections = new Map(baseAST.sections.map(s => [s.heading.text, s]));
    const newSections = new Map(newAST.sections.map(s => [s.heading.text, s]));

    // Find modified sections
    for (const [text, newSection] of newSections) {
      const baseSection = baseSections.get(text);

      if (!baseSection) {
        changes.push({
          type: 'section-added',
          section: text,
          line: newSection.startLine
        });
      } else {
        const baseContent = JSON.stringify(baseSection.content);
        const newContent = JSON.stringify(newSection.content);

        if (baseContent !== newContent) {
          changes.push({
            type: 'section-modified',
            section: text,
            line: newSection.startLine
          });
        }
      }
    }

    return changes;
  }

  changesAreCompatible(diffA, diffB) {
    const sectionsA = new Set(
      diffA.filter(d => d.type === 'section-modified' || d.type === 'section-added')
           .map(d => d.section)
    );
    const sectionsB = new Set(
      diffB.filter(d => d.type === 'section-modified' || d.type === 'section-added')
           .map(d => d.section)
    );

    for (const section of sectionsA) {
      if (sectionsB.has(section)) {
        return false;
      }
    }

    return true;
  }

  getCompatibilityExplanation() {
    return 'Changes are to different sections of the document and can be merged';
  }

  findConflictingElements(diffA, diffB) {
    const conflicts = [];
    const sectionsA = diffA.filter(d => d.type === 'section-modified');
    const sectionsB = diffB.filter(d => d.type === 'section-modified');

    for (const a of sectionsA) {
      for (const b of sectionsB) {
        if (a.section === b.section) {
          conflicts.push({
            type: 'section',
            name: a.section
          });
        }
      }
    }

    return conflicts;
  }
}

/**
 * JSON Parser
 */
class JSONParser {
  parse(content) {
    return JSON.parse(content);
  }

  diff(baseObj, newObj) {
    const changes = [];
    this.findDifferences(baseObj, newObj, '', changes);
    return changes;
  }

  findDifferences(base, current, path, changes) {
    // Added/modified keys
    for (const key in current) {
      const currentPath = path ? `${path}.${key}` : key;

      if (!(key in base)) {
        changes.push({
          type: 'key-added',
          path: currentPath,
          value: current[key]
        });
      } else if (typeof current[key] === 'object' && current[key] !== null &&
                 typeof base[key] === 'object' && base[key] !== null) {
        this.findDifferences(base[key], current[key], currentPath, changes);
      } else if (current[key] !== base[key]) {
        changes.push({
          type: 'value-changed',
          path: currentPath,
          oldValue: base[key],
          newValue: current[key]
        });
      }
    }

    // Removed keys
    for (const key in base) {
      if (!(key in current)) {
        const currentPath = path ? `${path}.${key}` : key;
        changes.push({
          type: 'key-removed',
          path: currentPath,
          value: base[key]
        });
      }
    }
  }

  changesAreCompatible(diffA, diffB) {
    const pathsA = new Set(diffA.map(d => d.path));
    const pathsB = new Set(diffB.map(d => d.path));

    for (const path of pathsA) {
      if (pathsB.has(path)) {
        const changeA = diffA.find(d => d.path === path);
        const changeB = diffB.find(d => d.path === path);

        // If both are adding the same key with same value, compatible
        if (changeA.type === 'key-added' && changeB.type === 'key-added' &&
            JSON.stringify(changeA.value) === JSON.stringify(changeB.value)) {
          continue;
        }

        return false;
      }
    }

    return true;
  }

  getCompatibilityExplanation() {
    return 'Changes are to different JSON keys and can be merged';
  }

  findConflictingElements(diffA, diffB) {
    const conflicts = [];
    const pathsA = new Map(diffA.map(d => [d.path, d]));

    for (const changeB of diffB) {
      if (pathsA.has(changeB.path)) {
        conflicts.push({
          path: changeB.path,
          changeA: pathsA.get(changeB.path),
          changeB
        });
      }
    }

    return conflicts;
  }
}

/**
 * YAML Parser (extends JSON parser)
 */
class YAMLParser extends JSONParser {
  // YAML parsing would use a proper library in production
  // For now, simplified implementation
}

/**
 * JavaScript Parser (stub)
 */
class JavaScriptParser {
  parse(content) {
    return { type: 'unparsed', content };
  }

  diff() {
    return [{ type: 'content-changed' }];
  }

  changesAreCompatible() {
    return false;
  }

  getCompatibilityExplanation() {
    return 'JavaScript changes require manual review';
  }

  findConflictingElements() {
    return [];
  }
}

// Export parsers for testing
export { MarkdownParser, JSONParser, YAMLParser, JavaScriptParser };
