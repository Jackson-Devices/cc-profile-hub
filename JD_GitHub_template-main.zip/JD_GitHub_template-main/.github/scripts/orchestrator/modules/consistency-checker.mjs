/**
 * Consistency Checker Module
 *
 * Enforces consistent formatting across all files to prevent merge conflicts
 */

import { readFile, writeFile } from 'node:fs/promises';

/**
 * Base module interface (simplified for now)
 */
class BaseModule {
  constructor(name, config = {}) {
    this.name = name;
    this.config = config;
  }

  formatCheckResult(passed, issues, metadata = {}) {
    return {
      passed,
      issues,
      metadata: {
        tool_version: '1.0.0',
        ...metadata
      }
    };
  }

  formatFixResult(success, filesModified, fixesApplied, strategy, metadata = {}) {
    return {
      success,
      filesModified,
      fixesApplied,
      strategy,
      metadata: {
        ...metadata
      }
    };
  }
}

export default class ConsistencyChecker extends BaseModule {
  constructor(config = {}) {
    super('consistency', {
      ...config,
      extensions: ['*'], // Runs on all files
      type: 'syntax',
      capabilities: ['can_auto_fix', 'cross_file'],
      enabled: true,
      priority: 100 // Highest priority - runs first
    });

    // Formatting rules per file type
    this.rules = {
      markdown: [
        {
          id: 'blank-line-after-heading',
          pattern: /^(#{1,6}\s+.+)\n([^#\n])/gm,
          replacement: '$1\n\n$2'
        },
        {
          id: 'blank-line-before-list',
          pattern: /([^\n])\n([-*+]\s)/g,
          replacement: '$1\n\n$2'
        },
        {
          id: 'no-multiple-blank-lines',
          pattern: /\n{3,}/g,
          replacement: '\n\n'
        },
        {
          id: 'trim-trailing-spaces',
          pattern: /[ \t]+$/gm,
          replacement: ''
        },
        {
          id: 'single-final-newline',
          pattern: /\n*$/,
          replacement: '\n'
        }
      ],
      javascript: [
        {
          id: 'no-multiple-blank-lines',
          pattern: /\n{3,}/g,
          replacement: '\n\n'
        },
        {
          id: 'trim-trailing-spaces',
          pattern: /[ \t]+$/gm,
          replacement: ''
        },
        {
          id: 'single-final-newline',
          pattern: /\n*$/,
          replacement: '\n'
        }
      ],
      yaml: [
        {
          id: 'no-multiple-blank-lines',
          pattern: /\n{3,}/g,
          replacement: '\n\n'
        },
        {
          id: 'trim-trailing-spaces',
          pattern: /[ \t]+$/gm,
          replacement: ''
        },
        {
          id: 'single-final-newline',
          pattern: /\n*$/,
          replacement: '\n'
        }
      ],
      shell: [
        {
          id: 'no-multiple-blank-lines',
          pattern: /\n{3,}/g,
          replacement: '\n\n'
        },
        {
          id: 'trim-trailing-spaces',
          pattern: /[ \t]+$/gm,
          replacement: ''
        },
        {
          id: 'single-final-newline',
          pattern: /\n*$/,
          replacement: '\n'
        }
      ],
      // Universal rules applied to all files
      universal: [
        {
          id: 'trim-trailing-spaces',
          pattern: /[ \t]+$/gm,
          replacement: ''
        },
        {
          id: 'single-final-newline',
          pattern: /\n*$/,
          replacement: '\n'
        }
      ]
    };
  }

  /**
   * Check files for consistency issues
   */
  async check(files, options = {}) {
    const startTime = Date.now();
    const issues = [];

    for (const file of files) {
      const fileIssues = await this.checkFile(file);
      issues.push(...fileIssues);
    }

    return this.formatCheckResult(
      issues.length === 0,
      issues,
      {
        duration_ms: Date.now() - startTime,
        tool_version: '1.0.0'
      }
    );
  }

  /**
   * Check a single file
   */
  async checkFile(file) {
    const content = await readFile(file, 'utf8');
    const rules = this.getRulesForFile(file);
    const issues = [];

    // Track which rules have already flagged issues to avoid duplicates
    const flaggedRules = new Set();

    for (const rule of rules) {
      if (rule.enabled === false) continue;
      if (flaggedRules.has(rule.id)) continue; // Skip duplicate rules

      // Check if applying the rule would actually change the content
      const newContent = content.replace(rule.pattern, rule.replacement);
      if (newContent !== content) {
        // Only report as issue if it would actually require a fix
        const matches = this.findMatches(content, rule.pattern);
        issues.push({
          file,
          line: matches.length > 0 ? matches[0].line : 1,
          code: rule.id,
          severity: 'warning',
          message: `Inconsistent formatting: ${rule.id}`,
          suggestion: `Apply standard formatting`
        });
        flaggedRules.add(rule.id);
      }
    }

    return issues;
  }

  /**
   * Fix files by applying consistency rules
   */
  async fix(files, strategy = 'balanced', options = {}) {
    const startTime = Date.now();
    const filesModified = [];
    let fixesApplied = 0;

    for (const file of files) {
      const result = await this.fixFile(file, strategy);
      if (result.modified) {
        filesModified.push(file);
        fixesApplied += result.fixCount;
      }
    }

    return this.formatFixResult(
      true,
      filesModified,
      fixesApplied,
      strategy,
      {
        duration_ms: Date.now() - startTime
      }
    );
  }

  /**
   * Fix a single file
   */
  async fixFile(file, strategy = 'balanced') {
    let content = await readFile(file, 'utf8');
    const originalContent = content;
    const rules = this.getRulesForFile(file);
    let fixCount = 0;

    // Track which rules have been applied to avoid duplicate applications
    const appliedRules = new Set();

    for (const rule of rules) {
      if (rule.enabled === false) continue;
      if (appliedRules.has(rule.id)) continue; // Skip duplicate rules

      // Apply rule based on strategy
      if (this.shouldApplyRule(rule, strategy)) {
        const newContent = content.replace(rule.pattern, rule.replacement);
        if (newContent !== content) {
          content = newContent;
          fixCount++;
          appliedRules.add(rule.id);
        }
      }
    }

    const modified = content !== originalContent;
    if (modified) {
      await writeFile(file, content, 'utf8');
    }

    return { modified, fixCount };
  }

  /**
   * Get rules for a specific file
   */
  getRulesForFile(file) {
    // Get file-type-specific rules
    let rules = [];
    if (file.endsWith('.md')) {
      rules = [...this.rules.markdown];
    } else if (file.match(/\.(js|mjs|cjs|ts|tsx)$/)) {
      rules = [...this.rules.javascript];
    } else if (file.match(/\.(yml|yaml)$/)) {
      rules = [...this.rules.yaml];
    } else if (file.match(/\.(sh|bash)$/)) {
      rules = [...this.rules.shell];
    }

    // Add universal rules if we don't already have file-specific rules
    // This prevents duplicates when file-specific rules include the same rules
    if (rules.length === 0) {
      rules.push(...this.rules.universal);
    } else {
      // Add only universal rules that aren't already in file-specific rules
      const existingIds = new Set(rules.map(r => r.id));
      for (const universalRule of this.rules.universal) {
        if (!existingIds.has(universalRule.id)) {
          rules.push(universalRule);
        }
      }
    }

    return rules;
  }

  /**
   * Determine if rule should be applied based on strategy
   */
  shouldApplyRule(rule, strategy) {
    // Conservative: Only apply safe rules (trailing spaces, final newline)
    const safeRules = ['trim-trailing-spaces', 'single-final-newline', 'no-multiple-blank-lines'];

    if (strategy === 'conservative') {
      return safeRules.includes(rule.id);
    }

    // Balanced: Apply most rules (default)
    if (strategy === 'balanced') {
      return !rule.aggressive;
    }

    // Aggressive: Apply all rules
    return true;
  }

  /**
   * Find pattern matches with line numbers
   */
  findMatches(content, pattern) {
    const matches = [];

    if (pattern.global) {
      // Global regex - need to create new instance to reset lastIndex
      const regex = new RegExp(pattern.source, pattern.flags);
      let match;
      while ((match = regex.exec(content)) !== null) {
        const line = content.substring(0, match.index).split('\n').length;
        matches.push({ line, match: match[0] });
      }
    } else {
      // Non-global: check whole content
      const match = pattern.exec(content);
      if (match) {
        const line = content.substring(0, match.index).split('\n').length;
        matches.push({ line, match: match[0] });
      }
    }

    return matches;
  }
}
