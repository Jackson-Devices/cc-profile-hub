/**
 * Mermaid Module - Diagram validation
 */

import BaseModule from './base-module.mjs';
import { readFile } from 'node:fs/promises';
import { existsSync } from 'node:fs';

export default class MermaidModule extends BaseModule {
  constructor(config = {}) {
    super(config);
    this.name = 'mermaid';
  }

  canHandle(filePath) {
    return filePath.endsWith('.mmd') || filePath.endsWith('.mermaid');
  }

  async check(files, _options = {}) {
    const issues = [];
    let filesChecked = 0;

    for (const file of files) {
      if (!existsSync(file)) {
        issues.push({
          file,
          line: 0,
          message: 'File not found',
          severity: 'error',
          rule: 'file-existence'
        });
        continue;
      }

      try {
        const content = await readFile(file, 'utf8');

        // Basic Mermaid validation - check for valid diagram types
        const validTypes = [
          'flowchart', 'sequenceDiagram', 'classDiagram',
          'stateDiagram', 'erDiagram', 'gantt', 'pie',
          'journey', 'gitGraph'
        ];

        const hasValidType = validTypes.some(type =>
          content.trim().startsWith(type)
        );

        if (!hasValidType && content.trim().length > 0) {
          issues.push({
            file,
            line: 1,
            message: 'Unknown Mermaid diagram type',
            severity: 'warning',
            rule: 'diagram-type'
          });
        }

        filesChecked++;
      } catch (error) {
        issues.push({
          file,
          line: 0,
          message: error.message,
          severity: 'error',
          rule: 'check-error'
        });
      }
    }

    return { valid: issues.length === 0, issues, filesChecked };
  }

  async fix(files, _strategy = 'default') {
    return { valid: true, fixes: [], filesFixed: 0 };
  }

  getSupportedStrategies() {
    return ['default'];
  }

  getInfo() {
    return {
      name: 'mermaid',
      description: 'Mermaid diagram validation',
      supportedExtensions: ['.mmd', '.mermaid'],
      capabilities: ['Syntax validation', 'Diagram type checking'],
      requiredTools: [],
      optionalTools: ['mmdc']
    };
  }
}
