/**
 * Python Module
 *
 * Handles Python file validation, formatting, and linting
 * Supports: black, isort, pylint, flake8, mypy, bandit
 */

import BaseModule from './base-module.mjs';
import { exec } from 'node:child_process';
import { promisify } from 'node:util';
import { readFile } from 'node:fs/promises';
import { existsSync } from 'node:fs';

const execAsync = promisify(exec);

export default class PythonModule extends BaseModule {
  constructor(config = {}) {
    super(config);
    this.name = 'python';
    this.config = {
      enableBlack: config.enableBlack !== false, // Default true
      enableIsort: config.enableIsort !== false, // Default true
      enablePylint: config.enablePylint !== false, // Default true
      enableFlake8: config.enableFlake8 !== false, // Default true
      enableMypy: config.enableMypy || false, // Default false (can be slow)
      enableBandit: config.enableBandit || false, // Default false (security)
      requireDocstrings: config.requireDocstrings || false,
      maxLineLength: config.maxLineLength || 88, // Black's default
      ...config
    };
  }

  /**
   * Check if this module can handle the given file
   */
  canHandle(filePath) {
    return filePath.endsWith('.py');
  }

  /**
   * Check Python files for issues
   */
  async check(files, _options = {}) {
    const issues = [];
    let filesChecked = 0;

    for (const file of files) {
      if (!existsSync(file)) {
        issues.push({
          file,
          line: 0,
          column: 0,
          message: 'File not found',
          severity: 'error',
          rule: 'file-existence'
        });
        continue;
      }

      try {
        // First check: Python syntax
        await this.checkSyntax(file, issues);

        // Second check: Linting with available tools
        if (this.config.enablePylint) {
          await this.checkWithPylint(file, issues);
        }

        if (this.config.enableFlake8) {
          await this.checkWithFlake8(file, issues);
        }

        if (this.config.enableMypy) {
          await this.checkWithMypy(file, issues);
        }

        if (this.config.enableBandit) {
          await this.checkWithBandit(file, issues);
        }

        filesChecked++;
      } catch (error) {
        issues.push({
          file,
          line: 0,
          column: 0,
          message: `Error checking file: ${error.message}`,
          severity: 'error',
          rule: 'check-error'
        });
      }
    }

    return {
      valid: issues.length === 0,
      issues,
      filesChecked
    };
  }

  /**
   * Check Python syntax using python -m py_compile
   */
  async checkSyntax(file, issues) {
    try {
      await execAsync(`python3 -m py_compile "${file}"`, {
        timeout: 10000
      });
    } catch (error) {
      // Parse syntax error
      const errorOutput = error.stderr || error.stdout || '';
      const match = errorOutput.match(/File ".*", line (\d+)/);
      const line = match ? parseInt(match[1]) : 0;

      issues.push({
        file,
        line,
        column: 0,
        message: errorOutput.split('\n')[0] || 'Syntax error',
        severity: 'error',
        rule: 'syntax'
      });
    }
  }

  /**
   * Check with pylint
   */
  async checkWithPylint(file, issues) {
    try {
      const { stdout } = await execAsync(`pylint --output-format=json "${file}"`, {
        timeout: 30000
      });

      const results = JSON.parse(stdout || '[]');
      for (const result of results) {
        issues.push({
          file,
          line: result.line || 0,
          column: result.column || 0,
          message: result.message,
          severity: this.mapPylintSeverity(result.type),
          rule: result['message-id'] || result.symbol
        });
      }
    } catch (error) {
      // Pylint not available or other error
      if (error.code === 'ENOENT' || error.message.includes('command not found')) {
        // Tool not installed, skip silently
        return;
      }
      // Parse error output if available
      if (error.stdout) {
        try {
          const results = JSON.parse(error.stdout);
          for (const result of results) {
            issues.push({
              file,
              line: result.line || 0,
              column: result.column || 0,
              message: result.message,
              severity: this.mapPylintSeverity(result.type),
              rule: result['message-id'] || result.symbol
            });
          }
        } catch {
          // Ignore parse errors
        }
      }
    }
  }

  /**
   * Check with flake8
   */
  async checkWithFlake8(file, issues) {
    try {
      await execAsync(`flake8 --max-line-length=${this.config.maxLineLength} "${file}"`, {
        timeout: 30000
      });
    } catch (error) {
      if (error.code === 'ENOENT' || error.message.includes('command not found')) {
        return;
      }

      // Parse flake8 output: file.py:line:col: code message
      const output = error.stdout || '';
      const lines = output.split('\n').filter(l => l.trim());

      for (const line of lines) {
        const match = line.match(/^(.+?):(\d+):(\d+): (\w+) (.+)$/);
        if (match) {
          issues.push({
            file,
            line: parseInt(match[2]),
            column: parseInt(match[3]),
            message: match[5],
            severity: match[4].startsWith('E') ? 'error' : 'warning',
            rule: match[4]
          });
        }
      }
    }
  }

  /**
   * Check with mypy for type issues
   */
  async checkWithMypy(file, issues) {
    try {
      await execAsync(`mypy "${file}"`, {
        timeout: 30000
      });
    } catch (error) {
      if (error.code === 'ENOENT' || error.message.includes('command not found')) {
        return;
      }

      // Parse mypy output: file.py:line: error: message
      const output = error.stdout || '';
      const lines = output.split('\n').filter(l => l.trim());

      for (const line of lines) {
        const match = line.match(/^(.+?):(\d+): (error|warning|note): (.+)$/);
        if (match) {
          issues.push({
            file,
            line: parseInt(match[2]),
            column: 0,
            message: match[4],
            severity: match[3] === 'error' ? 'error' : 'warning',
            rule: 'type-check'
          });
        }
      }
    }
  }

  /**
   * Check for security issues with bandit
   */
  async checkWithBandit(file, issues) {
    try {
      await execAsync(`bandit -f json "${file}"`, {
        timeout: 30000
      });
    } catch (error) {
      if (error.code === 'ENOENT' || error.message.includes('command not found')) {
        return;
      }

      try {
        const output = error.stdout || '{}';
        const results = JSON.parse(output);

        if (results.results) {
          for (const result of results.results) {
            issues.push({
              file,
              line: result.line_number || 0,
              column: 0,
              message: result.issue_text,
              severity: result.issue_severity.toLowerCase(),
              rule: `security-${result.test_id}`
            });
          }
        }
      } catch {
        // Ignore parse errors
      }
    }
  }

  /**
   * Fix Python files using available formatters
   */
  async fix(files, strategy = 'default') {
    const fixes = [];
    let filesFixed = 0;

    for (const file of files) {
      if (!existsSync(file)) {
        continue;
      }

      try {
        let fixed = false;

        // Apply formatters based on strategy
        if (this.shouldApplyFormatter(strategy, 'isort')) {
          const isortResult = await this.applyIsort(file);
          if (isortResult) fixed = true;
        }

        if (this.shouldApplyFormatter(strategy, 'black')) {
          const blackResult = await this.applyBlack(file);
          if (blackResult) fixed = true;
        }

        if (fixed) {
          filesFixed++;
          fixes.push({
            file,
            applied: true,
            message: 'Applied formatting'
          });
        }
      } catch (error) {
        fixes.push({
          file,
          applied: false,
          message: `Error fixing file: ${error.message}`
        });
      }
    }

    return {
      valid: true,
      fixes,
      filesFixed
    };
  }

  /**
   * Apply isort for import sorting
   */
  async applyIsort(file) {
    if (!this.config.enableIsort) return false;

    try {
      await execAsync(`isort "${file}"`, {
        timeout: 10000
      });
      return true;
    } catch (error) {
      // Tool not available
      return false;
    }
  }

  /**
   * Apply black for code formatting
   */
  async applyBlack(file) {
    if (!this.config.enableBlack) return false;

    try {
      await execAsync(`black --line-length ${this.config.maxLineLength} "${file}"`, {
        timeout: 10000
      });
      return true;
    } catch (error) {
      // Tool not available
      return false;
    }
  }

  /**
   * Determine if formatter should be applied based on strategy
   */
  shouldApplyFormatter(strategy, formatter) {
    switch (strategy) {
      case 'conservative':
        // Conservative: only apply black (safe formatter)
        return formatter === 'black';

      case 'aggressive':
        // Aggressive: apply all formatters
        return true;

      case 'default':
      default:
        // Default: apply isort and black
        return formatter === 'isort' || formatter === 'black';
    }
  }

  /**
   * Validate Python environment and tools
   */
  async validate() {
    const result = {
      pythonAvailable: false,
      pythonVersion: null,
      blackAvailable: false,
      isortAvailable: false,
      pylintAvailable: false,
      flake8Available: false,
      mypyAvailable: false,
      banditAvailable: false
    };

    // Check Python
    try {
      const { stdout } = await execAsync('python3 --version', {
        timeout: 5000
      });
      result.pythonAvailable = true;
      result.pythonVersion = stdout.trim();
    } catch {
      // Python not available
    }

    // Check black
    try {
      await execAsync('black --version', { timeout: 5000 });
      result.blackAvailable = true;
    } catch {
      // Not available
    }

    // Check isort
    try {
      await execAsync('isort --version', { timeout: 5000 });
      result.isortAvailable = true;
    } catch {
      // Not available
    }

    // Check pylint
    try {
      await execAsync('pylint --version', { timeout: 5000 });
      result.pylintAvailable = true;
    } catch {
      // Not available
    }

    // Check flake8
    try {
      await execAsync('flake8 --version', { timeout: 5000 });
      result.flake8Available = true;
    } catch {
      // Not available
    }

    // Check mypy
    try {
      await execAsync('mypy --version', { timeout: 5000 });
      result.mypyAvailable = true;
    } catch {
      // Not available
    }

    // Check bandit
    try {
      await execAsync('bandit --version', { timeout: 5000 });
      result.banditAvailable = true;
    } catch {
      // Not available
    }

    return result;
  }

  /**
   * Get supported fix strategies
   */
  getSupportedStrategies() {
    return ['default', 'conservative', 'aggressive'];
  }

  /**
   * Get module information
   */
  getInfo() {
    return {
      name: 'python',
      description: 'Python syntax validation, linting, and formatting',
      supportedExtensions: ['.py'],
      capabilities: [
        'Syntax validation',
        'Code formatting (black)',
        'Import sorting (isort)',
        'Linting (pylint, flake8)',
        'Type checking (mypy)',
        'Security analysis (bandit)'
      ],
      requiredTools: ['python3'],
      optionalTools: ['black', 'isort', 'pylint', 'flake8', 'mypy', 'bandit']
    };
  }

  /**
   * Map pylint severity to standard severity
   */
  mapPylintSeverity(pylintType) {
    switch (pylintType) {
      case 'error':
      case 'fatal':
        return 'error';
      case 'warning':
        return 'warning';
      case 'convention':
      case 'refactor':
        return 'info';
      default:
        return 'warning';
    }
  }
}
