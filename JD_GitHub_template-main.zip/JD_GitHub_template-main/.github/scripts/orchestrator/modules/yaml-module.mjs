/**
 * YAML Module for Orchestrator V2
 *
 * Formats YAML files using Prettier
 *
 * @module YAMLModule
 */

import BaseModule from './base-module.mjs';
import { exec } from 'node:child_process';
import { promisify } from 'node:util';

const execAsync = promisify(exec);

/**
 * YAML Module
 *
 * Uses Prettier for checking and formatting.
 *
 * @class YAMLModule
 * @extends BaseModule
 */
export default class YAMLModule extends BaseModule {
  constructor(name = 'yaml', config = {}) {
    super(name, {
      extensions: ['.yml', '.yaml'],
      ...config,
    });

    this.prettierPath = config.checker?.command || 'prettier';
  }

  async check(files, options = {}) {
    const startTime = Date.now();

    try {
      await this.withTimeout(
        () => execAsync(`${this.prettierPath} --check ${files.join(' ')}`),
        options.timeout || 30000
      );

      return this.formatCheckResult(true, [], {
        tool_version: await this.getPrettierVersion(),
        duration_ms: Date.now() - startTime,
      });
    } catch (error) {
      const issues = files.map((f) => ({
        file: f,
        line: 0,
        code: 'format',
        severity: 'warning',
        message: 'File needs formatting',
      }));

      return this.formatCheckResult(false, issues, {
        tool_version: await this.getPrettierVersion(),
        duration_ms: Date.now() - startTime,
      });
    }
  }

  async fix(files, strategy = 'default', options = {}) {
    const startTime = Date.now();

    try {
      if (!options.dry_run) {
        await this.withTimeout(
          () => execAsync(`${this.prettierPath} --write ${files.join(' ')}`),
          options.timeout || 60000
        );
      }

      return this.formatFixResult(true, options.dry_run ? [] : files, files.length, strategy, {
        duration_ms: Date.now() - startTime,
      });
    } catch (error) {
      return this.formatFixResult(false, [], 0, strategy, {
        duration_ms: Date.now() - startTime,
        error: error.message,
      });
    }
  }

  async getPrettierVersion() {
    try {
      const { stdout } = await execAsync(`${this.prettierPath} --version`);
      return stdout.trim();
    } catch {
      return 'unknown';
    }
  }

  async validate() {
    try {
      await execAsync(`which ${this.prettierPath}`);
      return { ready: true, missing_dependencies: [] };
    } catch {
      return {
        ready: false,
        missing_dependencies: ['prettier'],
        error: 'Missing: prettier',
      };
    }
  }

  getSupportedStrategies() {
    return ['default'];
  }
}
