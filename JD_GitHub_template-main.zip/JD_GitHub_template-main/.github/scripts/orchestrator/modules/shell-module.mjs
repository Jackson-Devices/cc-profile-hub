/**
 * Shell Module for Orchestrator V2
 *
 * Checks and fixes shell scripts using shellcheck and shellcheck-apply.sh
 *
 * @module ShellModule
 */

import BaseModule from './base-module.mjs';
import { exec } from 'node:child_process';
import { promisify } from 'node:util';
import * as path from 'node:path';

const execAsync = promisify(exec);

/**
 * Shell Module
 *
 * Uses shellcheck for checking and shellcheck-apply.sh for fixing.
 *
 * @class ShellModule
 * @extends BaseModule
 */
export default class ShellModule extends BaseModule {
  /**
   * Create a shell module instance
   *
   * @param {string} name - Module name
   * @param {Object} config - Module configuration
   */
  constructor(name = 'shell', config = {}) {
    super(name, {
      extensions: ['.sh', '.bash', '.zsh', '.ksh'],
      ...config,
    });

    this.shellcheckPath = config.checker?.command || 'shellcheck';
    this.fixerScript = config.fixer?.script || '.github/scripts/shellcheck-apply.sh';
  }

  /**
   * Check shell files using shellcheck
   *
   * @param {Array<string>} files - Files to check
   * @param {Object} options - Check options
   * @returns {Promise<CheckResult>} Check result
   */
  async check(files, options = {}) {
    const startTime = Date.now();

    try {
      // Run shellcheck with JSON output
      const { stdout } = await this.withTimeout(
        () =>
          execAsync(`${this.shellcheckPath} --format=json ${files.join(' ')}`, {
            maxBuffer: 10 * 1024 * 1024,
          }),
        options.timeout || 30000
      );

      const issues = this.parseShellcheckOutput(stdout);
      const duration = Date.now() - startTime;

      return this.formatCheckResult(issues.length === 0, issues, {
        tool_version: await this.getShellcheckVersion(),
        duration_ms: duration,
      });
    } catch (error) {
      // Shellcheck returns non-zero exit code when issues found
      if (error.stdout) {
        const issues = this.parseShellcheckOutput(error.stdout);
        const duration = Date.now() - startTime;

        return this.formatCheckResult(false, issues, {
          tool_version: await this.getShellcheckVersion(),
          duration_ms: duration,
        });
      }

      throw new Error(`Shellcheck failed: ${error.message}`);
    }
  }

  /**
   * Fix shell files using shellcheck-apply.sh
   *
   * @param {Array<string>} files - Files to fix
   * @param {string} strategy - Fix strategy (conservative, balanced, aggressive)
   * @param {Object} options - Fix options
   * @returns {Promise<FixResult>} Fix result
   */
  async fix(files, strategy = 'balanced', options = {}) {
    const startTime = Date.now();
    const filesModified = [];
    let totalFixes = 0;

    try {
      for (const file of files) {
        const dryRunFlag = options.dry_run ? '--dry-run' : '';
        const verboseFlag = options.verbose ? '--verbose' : '';

        const command = `${this.fixerScript} --strategy ${strategy} ${dryRunFlag} ${verboseFlag} ${file}`;

        const { stdout, stderr } = await this.withTimeout(
          () => execAsync(command, { maxBuffer: 10 * 1024 * 1024 }),
          options.timeout || 60000
        );

        // Parse output to determine if file was modified
        if (!options.dry_run && (stdout.includes('Applied') || stdout.includes('Fixed'))) {
          filesModified.push(file);
        }

        // Count fixes from output
        const fixCount = this.countFixesFromOutput(stdout);
        totalFixes += fixCount;
      }

      const duration = Date.now() - startTime;

      return this.formatFixResult(true, filesModified, totalFixes, strategy, {
        duration_ms: duration,
      });
    } catch (error) {
      const duration = Date.now() - startTime;

      return this.formatFixResult(false, filesModified, totalFixes, strategy, {
        duration_ms: duration,
        error: error.message,
      });
    }
  }

  /**
   * Parse shellcheck JSON output into issues
   *
   * @param {string} output - Shellcheck JSON output
   * @returns {Array<Issue>} Parsed issues
   * @private
   */
  parseShellcheckOutput(output) {
    if (!output || output.trim() === '') {
      return [];
    }

    try {
      const data = JSON.parse(output);
      const issues = [];

      for (const item of data) {
        issues.push({
          file: item.file || 'unknown',
          line: item.line || 0,
          column: item.column || 0,
          code: item.code ? `SC${item.code}` : 'unknown',
          severity: this.mapSeverity(item.level),
          message: item.message || 'No message',
        });
      }

      return issues;
    } catch (error) {
      // If parsing fails, return empty array
      return [];
    }
  }

  /**
   * Map shellcheck severity level to standard severity
   *
   * @param {string} level - Shellcheck level (error, warning, info, style)
   * @returns {string} Standard severity (error, warning, info)
   * @private
   */
  mapSeverity(level) {
    const map = {
      error: 'error',
      warning: 'warning',
      info: 'info',
      style: 'info',
    };

    return map[level] || 'warning';
  }

  /**
   * Count fixes from shellcheck-apply.sh output
   *
   * @param {string} output - Script output
   * @returns {number} Number of fixes
   * @private
   */
  countFixesFromOutput(output) {
    // Look for patterns like "Applied 5 fixes" or "Fixed 3 issues"
    const match = output.match(/(?:Applied|Fixed)\s+(\d+)/i);
    return match ? parseInt(match[1], 10) : 0;
  }

  /**
   * Get shellcheck version
   *
   * @returns {Promise<string>} Version string
   * @private
   */
  async getShellcheckVersion() {
    try {
      const { stdout } = await execAsync(`${this.shellcheckPath} --version`);
      const match = stdout.match(/version:\s+([\d.]+)/);
      return match ? match[1] : 'unknown';
    } catch {
      return 'unknown';
    }
  }

  /**
   * Validate that shellcheck is available
   *
   * @returns {Promise<ValidationResult>} Validation result
   */
  async validate() {
    const missingDeps = [];

    try {
      await execAsync(`which ${this.shellcheckPath}`);
    } catch {
      missingDeps.push('shellcheck');
    }

    try {
      await execAsync(`test -f ${this.fixerScript}`);
    } catch {
      missingDeps.push('shellcheck-apply.sh');
    }

    return {
      ready: missingDeps.length === 0,
      missing_dependencies: missingDeps,
      error: missingDeps.length > 0 ? `Missing: ${missingDeps.join(', ')}` : undefined,
    };
  }

  /**
   * Get supported fix strategies
   *
   * @returns {Array<string>} Strategy names
   */
  getSupportedStrategies() {
    return ['conservative', 'balanced', 'aggressive'];
  }
}
