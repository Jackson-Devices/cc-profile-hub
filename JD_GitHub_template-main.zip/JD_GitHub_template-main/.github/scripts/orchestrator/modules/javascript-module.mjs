/**
 * JavaScript Module for Orchestrator V2
 *
 * Checks and fixes JavaScript/TypeScript using ESLint
 *
 * @module JavaScriptModule
 */

import BaseModule from './base-module.mjs';
import { exec } from 'node:child_process';
import { promisify } from 'node:util';

const execAsync = promisify(exec);

/**
 * JavaScript Module
 *
 * Uses ESLint for checking and fixing.
 *
 * @class JavaScriptModule
 * @extends BaseModule
 */
export default class JavaScriptModule extends BaseModule {
  /**
   * Create a JavaScript module instance
   *
   * @param {string} name - Module name
   * @param {Object} config - Module configuration
   */
  constructor(name = 'javascript', config = {}) {
    super(name, {
      extensions: ['.js', '.mjs', '.cjs', '.ts', '.tsx', '.jsx'],
      ...config,
    });

    this.eslintPath = config.checker?.command || 'eslint';
  }

  /**
   * Check JavaScript files using ESLint
   *
   * @param {Array<string>} files - Files to check
   * @param {Object} options - Check options
   * @returns {Promise<CheckResult>} Check result
   */
  async check(files, options = {}) {
    const startTime = Date.now();

    try {
      const { stdout } = await this.withTimeout(
        () =>
          execAsync(`${this.eslintPath} --format=json ${files.join(' ')}`, {
            maxBuffer: 10 * 1024 * 1024,
          }),
        options.timeout || 30000
      );

      const issues = this.parseESLintOutput(stdout);
      const duration = Date.now() - startTime;

      return this.formatCheckResult(issues.length === 0, issues, {
        tool_version: await this.getESLintVersion(),
        duration_ms: duration,
      });
    } catch (error) {
      // ESLint returns non-zero exit code when issues found
      if (error.stdout) {
        const issues = this.parseESLintOutput(error.stdout);
        const duration = Date.now() - startTime;

        return this.formatCheckResult(false, issues, {
          tool_version: await this.getESLintVersion(),
          duration_ms: duration,
        });
      }

      throw new Error(`ESLint failed: ${error.message}`);
    }
  }

  /**
   * Fix JavaScript files using ESLint --fix
   *
   * @param {Array<string>} files - Files to fix
   * @param {string} strategy - Fix strategy (only 'default' supported)
   * @param {Object} options - Fix options
   * @returns {Promise<FixResult>} Fix result
   */
  async fix(files, strategy = 'default', options = {}) {
    const startTime = Date.now();

    try {
      const dryRunFlag = options.dry_run ? '--fix-dry-run' : '--fix';

      const { stdout, stderr } = await this.withTimeout(
        () =>
          execAsync(`${this.eslintPath} ${dryRunFlag} --format=json ${files.join(' ')}`, {
            maxBuffer: 10 * 1024 * 1024,
          }),
        options.timeout || 60000
      );

      // Parse to see which files had fixes applied
      const results = this.parseESLintFixOutput(stdout);
      const filesModified = options.dry_run ? [] : results.filesModified;
      const totalFixes = results.totalFixes;

      const duration = Date.now() - startTime;

      return this.formatFixResult(true, filesModified, totalFixes, strategy, {
        duration_ms: duration,
      });
    } catch (error) {
      // ESLint may exit with error even after successful fixes
      if (error.stdout) {
        const results = this.parseESLintFixOutput(error.stdout);
        const filesModified = options.dry_run ? [] : results.filesModified;
        const totalFixes = results.totalFixes;
        const duration = Date.now() - startTime;

        return this.formatFixResult(true, filesModified, totalFixes, strategy, {
          duration_ms: duration,
        });
      }

      const duration = Date.now() - startTime;
      return this.formatFixResult(false, [], 0, strategy, {
        duration_ms: duration,
        error: error.message,
      });
    }
  }

  /**
   * Parse ESLint JSON output into issues
   *
   * @param {string} output - ESLint JSON output
   * @returns {Array<Issue>} Parsed issues
   * @private
   */
  parseESLintOutput(output) {
    if (!output || output.trim() === '') {
      return [];
    }

    try {
      const data = JSON.parse(output);
      const issues = [];

      for (const fileResult of data) {
        for (const message of fileResult.messages || []) {
          issues.push({
            file: fileResult.filePath || 'unknown',
            line: message.line || 0,
            column: message.column || 0,
            code: message.ruleId || 'unknown',
            severity: this.mapSeverity(message.severity),
            message: message.message || 'No message',
          });
        }
      }

      return issues;
    } catch (error) {
      return [];
    }
  }

  /**
   * Parse ESLint fix output
   *
   * @param {string} output - ESLint JSON output
   * @returns {Object} Fix results
   * @private
   */
  parseESLintFixOutput(output) {
    if (!output || output.trim() === '') {
      return { filesModified: [], totalFixes: 0 };
    }

    try {
      const data = JSON.parse(output);
      const filesModified = [];
      let totalFixes = 0;

      for (const fileResult of data) {
        const fixCount = fileResult.output ? 1 : (fileResult.fixableErrorCount || 0) + (fileResult.fixableWarningCount || 0);

        if (fixCount > 0) {
          filesModified.push(fileResult.filePath);
          totalFixes += fixCount;
        }
      }

      return { filesModified, totalFixes };
    } catch (error) {
      return { filesModified: [], totalFixes: 0 };
    }
  }

  /**
   * Map ESLint severity to standard severity
   *
   * @param {number} severity - ESLint severity (1=warning, 2=error)
   * @returns {string} Standard severity
   * @private
   */
  mapSeverity(severity) {
    return severity === 2 ? 'error' : 'warning';
  }

  /**
   * Get ESLint version
   *
   * @returns {Promise<string>} Version string
   * @private
   */
  async getESLintVersion() {
    try {
      const { stdout } = await execAsync(`${this.eslintPath} --version`);
      return stdout.trim().replace(/^v/, '');
    } catch {
      return 'unknown';
    }
  }

  /**
   * Validate that ESLint is available
   *
   * @returns {Promise<ValidationResult>} Validation result
   */
  async validate() {
    const missingDeps = [];

    try {
      await execAsync(`which ${this.eslintPath}`);
    } catch {
      missingDeps.push('eslint');
    }

    return {
      ready: missingDeps.length === 0,
      missing_dependencies: missingDeps,
      error: missingDeps.length > 0 ? `Missing: ${missingDeps.join(', ')}` : undefined,
    };
  }

  /**
   * Get supported fix strategies
   *
   * ESLint only has one fix mode, so only 'default' is supported.
   *
   * @returns {Array<string>} Strategy names
   */
  getSupportedStrategies() {
    return ['default'];
  }
}
