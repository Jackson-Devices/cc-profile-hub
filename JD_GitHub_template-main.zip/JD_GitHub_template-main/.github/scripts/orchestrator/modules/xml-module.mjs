/**
 * XML Module
 *
 * Handles XML file validation and formatting
 */

import BaseModule from './base-module.mjs';
import { DOMParser } from '@xmldom/xmldom';
import { readFile, writeFile } from 'node:fs/promises';
import { existsSync } from 'node:fs';

export default class XMLModule extends BaseModule {
  constructor(config = {}) {
    super(config);
    this.name = 'xml';
    this.config = config;
  }

  canHandle(filePath) {
    return filePath.endsWith('.xml');
  }

  async check(files, _options = {}) {
    const issues = [];
    let filesChecked = 0;

    for (const file of files) {
      if (!existsSync(file)) {
        issues.push({
          file,
          line: 0,
          column: 0,
          message: 'File not found',
          severity: 'error',
          rule: 'file-existence'
        });
        continue;
      }

      try {
        const content = await readFile(file, 'utf8');

        // Parse XML with error handler
        const errors = [];
        const parser = new DOMParser({
          errorHandler: {
            warning: (msg) => errors.push({ severity: 'warning', message: msg }),
            error: (msg) => errors.push({ severity: 'error', message: msg }),
            fatalError: (msg) => errors.push({ severity: 'error', message: msg })
          }
        });

        parser.parseFromString(content, 'text/xml');

        // Add any parsing errors to issues
        for (const error of errors) {
          issues.push({
            file,
            line: 0,
            column: 0,
            message: error.message,
            severity: error.severity,
            rule: 'xml-parse'
          });
        }

        filesChecked++;
      } catch (error) {
        issues.push({
          file,
          line: 0,
          column: 0,
          message: `Error checking file: ${error.message}`,
          severity: 'error',
          rule: 'check-error'
        });
      }
    }

    return {
      valid: issues.length === 0,
      issues,
      filesChecked
    };
  }

  async fix(files, _strategy = 'default') {
    const fixes = [];
    let filesFixed = 0;

    for (const file of files) {
      if (!existsSync(file)) continue;

      try {
        const content = await readFile(file, 'utf8');
        const parser = new DOMParser();
        const doc = parser.parseFromString(content, 'text/xml');

        // Format XML with indentation
        const formatted = this.formatXML(content);
        await writeFile(file, formatted, 'utf8');

        filesFixed++;
        fixes.push({
          file,
          applied: true,
          message: 'Formatted XML'
        });
      } catch (error) {
        fixes.push({
          file,
          applied: false,
          message: error.message
        });
      }
    }

    return {
      valid: true,
      fixes,
      filesFixed
    };
  }

  formatXML(xmlString) {
    // Simple XML formatting
    let formatted = '';
    let indent = 0;
    const lines = xmlString.split('>');

    for (const line of lines) {
      if (!line.trim()) continue;

      if (line.includes('</')) indent--;

      formatted += '  '.repeat(Math.max(0, indent)) + line.trim() + '>\n';

      if (line.includes('<') && !line.includes('</') && !line.includes('/>')) {
        indent++;
      }
    }

    return formatted.trim() + '\n';
  }

  getSupportedStrategies() {
    return ['default'];
  }

  getInfo() {
    return {
      name: 'xml',
      description: 'XML validation and formatting',
      supportedExtensions: ['.xml'],
      capabilities: ['Syntax validation', 'Formatting'],
      requiredTools: [],
      optionalTools: []
    };
  }
}
