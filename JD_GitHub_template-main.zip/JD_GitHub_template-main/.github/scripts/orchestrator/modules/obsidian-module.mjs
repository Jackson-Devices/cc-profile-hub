/**
 * Obsidian Module - Obsidian note validation
 */

import BaseModule from './base-module.mjs';
import { readFile } from 'node:fs/promises';
import { existsSync } from 'node:fs';

export default class ObsidianModule extends BaseModule {
  constructor(config = {}) {
    super(config);
    this.name = 'obsidian';
    this.config = {
      vaultPath: config.vaultPath || null,
      ...config
    };
  }

  canHandle(filePath) {
    // Only handle .md files in Obsidian vault if specified
    if (this.config.vaultPath) {
      return filePath.startsWith(this.config.vaultPath) && filePath.endsWith('.md');
    }
    return filePath.endsWith('.md');
  }

  async check(files, _options = {}) {
    const issues = [];
    let filesChecked = 0;

    for (const file of files) {
      if (!existsSync(file)) {
        issues.push({
          file,
          line: 0,
          message: 'File not found',
          severity: 'error',
          rule: 'file-existence'
        });
        continue;
      }

      try {
        const content = await readFile(file, 'utf8');

        // Check frontmatter
        if (content.startsWith('---')) {
          const frontmatterEnd = content.indexOf('---', 3);
          if (frontmatterEnd === -1) {
            issues.push({
              file,
              line: 1,
              message: 'Unclosed frontmatter',
              severity: 'error',
              rule: 'frontmatter'
            });
          }
        }

        // Check for wikilinks with extra spaces
        const wikilinkPattern = /\[\[([^\]]+)\]\]/g;
        let match;
        while ((match = wikilinkPattern.exec(content)) !== null) {
          const linkText = match[1];
          if (linkText.includes('  ')) {
            issues.push({
              file,
              line: 0,
              message: `Wikilink contains extra spaces: [[${linkText}]]`,
              severity: 'warning',
              rule: 'wikilink-spacing'
            });
          }
        }

        filesChecked++;
      } catch (error) {
        issues.push({
          file,
          line: 0,
          message: error.message,
          severity: 'error',
          rule: 'check-error'
        });
      }
    }

    return { valid: issues.length === 0, issues, filesChecked };
  }

  async fix(files, _strategy = 'default') {
    return { valid: true, fixes: [], filesFixed: 0 };
  }

  getSupportedStrategies() {
    return ['default'];
  }

  getInfo() {
    return {
      name: 'obsidian',
      description: 'Obsidian note validation',
      supportedExtensions: ['.md'],
      capabilities: ['Frontmatter validation', 'Wikilink checking'],
      requiredTools: [],
      optionalTools: []
    };
  }
}
