/**
 * Base Module Interface for Orchestrator V2
 *
 * All checker/fixer modules must inherit from this base class and implement
 * the required methods.
 *
 * @module BaseModule
 */

/**
 * Result from a check operation
 * @typedef {Object} CheckResult
 * @property {boolean} success - Whether the check passed (no issues found)
 * @property {Array<Issue>} issues - List of issues found
 * @property {Object} metadata - Additional metadata about the check
 * @property {string} metadata.tool_version - Version of the tool used
 * @property {number} metadata.duration_ms - Duration in milliseconds
 */

/**
 * Issue found during check
 * @typedef {Object} Issue
 * @property {string} file - File path where issue was found
 * @property {number} line - Line number (1-indexed)
 * @property {number} [column] - Column number (1-indexed, optional)
 * @property {string} code - Error/warning code (e.g., 'SC2086', 'no-unused-vars')
 * @property {string} severity - Severity level: 'error', 'warning', 'info'
 * @property {string} message - Human-readable message
 * @property {string} [suggestion] - Optional suggestion for fix
 */

/**
 * Result from a fix operation
 * @typedef {Object} FixResult
 * @property {boolean} success - Whether the fix operation succeeded
 * @property {Array<string>} files_modified - List of files that were modified
 * @property {number} fixes_applied - Number of fixes applied
 * @property {Object} metadata - Additional metadata about the fix
 * @property {string} metadata.strategy - Strategy used for fixing
 * @property {number} metadata.duration_ms - Duration in milliseconds
 * @property {string} [error] - Error message if fix failed
 */

/**
 * Validation result for module readiness
 * @typedef {Object} ValidationResult
 * @property {boolean} ready - Whether the module is ready to use
 * @property {Array<string>} [missing_dependencies] - Missing dependencies if not ready
 * @property {string} [error] - Error message if not ready
 */

/**
 * Base class for all checker/fixer modules
 *
 * @class BaseModule
 */
export default class BaseModule {
  /**
   * Create a module instance
   *
   * @param {string} name - Module name (e.g., 'shell', 'javascript')
   * @param {Object} config - Module configuration
   * @param {Array<string>} config.extensions - File extensions this module handles
   * @param {Object} config.checker - Checker configuration
   * @param {Object} config.fixer - Fixer configuration
   * @param {boolean} config.enabled - Whether module is enabled
   */
  constructor(name, config = {}) {
    if (!name) {
      throw new Error('Module name is required');
    }

    this.name = name;
    this.config = config;
    this.extensions = config.extensions || [];
    this.enabled = config.enabled !== false; // Default to enabled
  }

  /**
   * Check files for issues (MUST BE IMPLEMENTED BY SUBCLASS)
   *
   * @param {Array<string>} files - List of file paths to check
   * @param {Object} [options={}] - Check options
   * @param {number} [options.timeout] - Timeout in milliseconds
   * @param {boolean} [options.verbose] - Verbose output
   * @returns {Promise<CheckResult>} Check result
   * @throws {Error} If not implemented by subclass
   *
   * @example
   * const result = await module.check(['script.sh'], { verbose: true });
   * if (!result.success) {
   *   console.log(`Found ${result.issues.length} issues`);
   * }
   */
  async check(files, options = {}) {
    throw new Error(
      `check() must be implemented by ${this.constructor.name}. ` +
        `This method should run the checker tool and return a CheckResult object.`
    );
  }

  /**
   * Fix issues in files (MUST BE IMPLEMENTED BY SUBCLASS)
   *
   * @param {Array<string>} files - List of file paths to fix
   * @param {string} [strategy='balanced'] - Fix strategy (conservative, balanced, aggressive)
   * @param {Object} [options={}] - Fix options
   * @param {number} [options.timeout] - Timeout in milliseconds
   * @param {boolean} [options.verbose] - Verbose output
   * @param {boolean} [options.dry_run] - Dry run mode (don't modify files)
   * @returns {Promise<FixResult>} Fix result
   * @throws {Error} If not implemented by subclass
   *
   * @example
   * const result = await module.fix(['script.sh'], 'conservative');
   * console.log(`Modified ${result.files_modified.length} files`);
   */
  async fix(files, strategy = 'balanced', options = {}) {
    throw new Error(
      `fix() must be implemented by ${this.constructor.name}. ` +
        `This method should run the fixer tool and return a FixResult object.`
    );
  }

  /**
   * Validate that the module is ready to use (OPTIONAL)
   *
   * Checks for required dependencies, tools, configuration, etc.
   *
   * @returns {Promise<ValidationResult>} Validation result
   *
   * @example
   * const validation = await module.validate();
   * if (!validation.ready) {
   *   console.error('Module not ready:', validation.error);
   * }
   */
  async validate() {
    return {
      ready: true,
      missing_dependencies: [],
    };
  }

  /**
   * Get list of supported fix strategies (OPTIONAL)
   *
   * Default implementation returns standard strategies.
   * Override this method to provide module-specific strategies.
   *
   * @returns {Array<string>} List of strategy names
   *
   * @example
   * const strategies = module.getSupportedStrategies();
   * // Returns: ['conservative', 'balanced', 'aggressive']
   */
  getSupportedStrategies() {
    return ['conservative', 'balanced', 'aggressive'];
  }

  /**
   * Check if this module can handle a given file
   *
   * @param {string} filename - File path to check
   * @returns {boolean} True if this module can handle the file
   *
   * @example
   * if (module.canHandle('script.sh')) {
   *   await module.check(['script.sh']);
   * }
   */
  canHandle(filename) {
    if (!filename) return false;

    // Check if filename ends with any of the configured extensions
    // This handles both simple extensions (.sh) and compound extensions (.test.js)
    return this.extensions.some((ext) => filename.endsWith(ext));
  }

  /**
   * Get module information
   *
   * @returns {Object} Module info
   * @property {string} name - Module name
   * @property {boolean} enabled - Whether module is enabled
   * @property {Array<string>} extensions - Supported file extensions
   * @property {Array<string>} strategies - Supported fix strategies
   */
  getInfo() {
    return {
      name: this.name,
      enabled: this.enabled,
      extensions: this.extensions,
      strategies: this.getSupportedStrategies(),
    };
  }

  /**
   * Execute a command with timeout
   *
   * Utility method for subclasses to run commands with timeout protection.
   *
   * @protected
   * @param {Function} fn - Async function to execute
   * @param {number} timeout - Timeout in milliseconds
   * @returns {Promise<*>} Result of the function
   * @throws {Error} If timeout is reached
   *
   * @example
   * const result = await this.withTimeout(
   *   () => someAsyncOperation(),
   *   5000
   * );
   */
  async withTimeout(fn, timeout) {
    if (!timeout || timeout <= 0) {
      return await fn();
    }

    return Promise.race([
      fn(),
      new Promise((_, reject) =>
        setTimeout(() => reject(new Error(`Operation timed out after ${timeout}ms`)), timeout)
      ),
    ]);
  }

  /**
   * Format a check result
   *
   * Utility method to ensure check results have the correct structure.
   *
   * @protected
   * @param {boolean} success - Whether check passed
   * @param {Array<Issue>} issues - Issues found
   * @param {Object} metadata - Additional metadata
   * @returns {CheckResult} Formatted check result
   */
  formatCheckResult(success, issues = [], metadata = {}) {
    return {
      success,
      issues: issues || [],
      metadata: {
        tool_version: metadata.tool_version || 'unknown',
        duration_ms: metadata.duration_ms || 0,
        ...metadata,
      },
    };
  }

  /**
   * Format a fix result
   *
   * Utility method to ensure fix results have the correct structure.
   *
   * @protected
   * @param {boolean} success - Whether fix succeeded
   * @param {Array<string>} files_modified - Files that were modified
   * @param {number} fixes_applied - Number of fixes applied
   * @param {string} strategy - Strategy used
   * @param {Object} metadata - Additional metadata
   * @returns {FixResult} Formatted fix result
   */
  formatFixResult(success, files_modified = [], fixes_applied = 0, strategy = 'balanced', metadata = {}) {
    return {
      success,
      files_modified: files_modified || [],
      fixes_applied: fixes_applied || 0,
      metadata: {
        strategy,
        duration_ms: metadata.duration_ms || 0,
        ...metadata,
      },
    };
  }
}
