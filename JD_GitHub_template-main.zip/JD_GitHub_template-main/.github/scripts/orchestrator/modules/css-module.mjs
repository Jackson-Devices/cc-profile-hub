/**
 * CSS Module
 *
 * Handles CSS file validation, formatting, and linting
 * Supports: stylelint, prettier, csslint
 */

import BaseModule from './base-module.mjs';
import { exec } from 'node:child_process';
import { promisify } from 'node:util';
import { readFile } from 'node:fs/promises';
import { existsSync } from 'node:fs';

const execAsync = promisify(exec);

export default class CSSModule extends BaseModule {
  constructor(config = {}) {
    super(config);
    this.name = 'css';
    this.config = {
      enableStylelint: config.enableStylelint !== false, // Default true
      enablePrettier: config.enablePrettier !== false, // Default true
      enableCssLint: config.enableCssLint || false, // Default false (deprecated)
      ...config
    };
  }

  /**
   * Check if this module can handle the given file
   */
  canHandle(filePath) {
    return filePath.endsWith('.css');
  }

  /**
   * Check CSS files for issues
   */
  async check(files, _options = {}) {
    const issues = [];
    let filesChecked = 0;

    for (const file of files) {
      if (!existsSync(file)) {
        issues.push({
          file,
          line: 0,
          column: 0,
          message: 'File not found',
          severity: 'error',
          rule: 'file-existence'
        });
        continue;
      }

      try {
        // Check CSS syntax
        await this.checkSyntax(file, issues);

        // Lint with stylelint if available and enabled
        if (this.config.enableStylelint) {
          await this.checkWithStylelint(file, issues);
        }

        filesChecked++;
      } catch (error) {
        issues.push({
          file,
          line: 0,
          column: 0,
          message: `Error checking file: ${error.message}`,
          severity: 'error',
          rule: 'check-error'
        });
      }
    }

    return {
      valid: issues.length === 0,
      issues,
      filesChecked
    };
  }

  /**
   * Check CSS syntax using basic parsing
   */
  async checkSyntax(file, issues) {
    try {
      const content = await readFile(file, 'utf8');

      // Basic syntax checks
      const braceStack = [];
      const lines = content.split('\n');

      for (let i = 0; i < lines.length; i++) {
        const line = lines[i];
        const lineNum = i + 1;

        // Count braces
        for (let j = 0; j < line.length; j++) {
          if (line[j] === '{') {
            braceStack.push({ line: lineNum, col: j + 1 });
          } else if (line[j] === '}') {
            if (braceStack.length === 0) {
              issues.push({
                file,
                line: lineNum,
                column: j + 1,
                message: 'Unexpected closing brace',
                severity: 'error',
                rule: 'syntax'
              });
            } else {
              braceStack.pop();
            }
          }
        }
      }

      // Check for unclosed braces
      if (braceStack.length > 0) {
        const unclosed = braceStack[0];
        issues.push({
          file,
          line: unclosed.line,
          column: unclosed.col,
          message: 'Unclosed brace',
          severity: 'error',
          rule: 'syntax'
        });
      }
    } catch (error) {
      issues.push({
        file,
        line: 0,
        column: 0,
        message: `Failed to read file: ${error.message}`,
        severity: 'error',
        rule: 'file-read'
      });
    }
  }

  /**
   * Check with stylelint
   */
  async checkWithStylelint(file, issues) {
    try {
      const { stdout } = await execAsync(`stylelint --formatter json "${file}"`, {
        timeout: 30000
      });

      const results = JSON.parse(stdout || '[]');
      for (const result of results) {
        if (result.warnings) {
          for (const warning of result.warnings) {
            issues.push({
              file,
              line: warning.line || 0,
              column: warning.column || 0,
              message: warning.text,
              severity: warning.severity || 'warning',
              rule: warning.rule || 'stylelint'
            });
          }
        }
      }
    } catch (error) {
      // Stylelint not available or returned errors
      if (error.code === 'ENOENT' || error.message.includes('command not found')) {
        // Tool not installed, skip silently
        return;
      }

      // Try to parse error output
      if (error.stdout) {
        try {
          const results = JSON.parse(error.stdout);
          for (const result of results) {
            if (result.warnings) {
              for (const warning of result.warnings) {
                issues.push({
                  file,
                  line: warning.line || 0,
                  column: warning.column || 0,
                  message: warning.text,
                  severity: warning.severity || 'warning',
                  rule: warning.rule || 'stylelint'
                });
              }
            }
          }
        } catch {
          // Ignore parse errors
        }
      }
    }
  }

  /**
   * Fix CSS files using available formatters
   */
  async fix(files, strategy = 'default') {
    const fixes = [];
    let filesFixed = 0;

    for (const file of files) {
      if (!existsSync(file)) {
        continue;
      }

      try {
        let fixed = false;

        // Apply formatters based on strategy
        if (this.shouldApplyFormatter(strategy, 'stylelint')) {
          const stylelintResult = await this.applyStylelintFix(file);
          if (stylelintResult) fixed = true;
        }

        if (this.shouldApplyFormatter(strategy, 'prettier')) {
          const prettierResult = await this.applyPrettier(file);
          if (prettierResult) fixed = true;
        }

        if (fixed) {
          filesFixed++;
          fixes.push({
            file,
            applied: true,
            message: 'Applied formatting'
          });
        }
      } catch (error) {
        fixes.push({
          file,
          applied: false,
          message: `Error fixing file: ${error.message}`
        });
      }
    }

    return {
      valid: true,
      fixes,
      filesFixed
    };
  }

  /**
   * Apply stylelint auto-fix
   */
  async applyStylelintFix(file) {
    if (!this.config.enableStylelint) return false;

    try {
      await execAsync(`stylelint --fix "${file}"`, {
        timeout: 10000
      });
      return true;
    } catch (error) {
      // Tool not available or no fixes applied
      return false;
    }
  }

  /**
   * Apply prettier for CSS formatting
   */
  async applyPrettier(file) {
    if (!this.config.enablePrettier) return false;

    try {
      await execAsync(`prettier --write "${file}"`, {
        timeout: 10000
      });
      return true;
    } catch (error) {
      // Tool not available
      return false;
    }
  }

  /**
   * Determine if formatter should be applied based on strategy
   */
  shouldApplyFormatter(strategy, formatter) {
    switch (strategy) {
      case 'conservative':
        // Conservative: only prettier (safe formatter)
        return formatter === 'prettier';

      case 'aggressive':
        // Aggressive: apply all formatters
        return true;

      case 'default':
      default:
        // Default: apply both stylelint and prettier
        return formatter === 'stylelint' || formatter === 'prettier';
    }
  }

  /**
   * Validate CSS tooling environment
   */
  async validate() {
    const result = {
      stylelintAvailable: false,
      prettierAvailable: false
    };

    // Check stylelint
    try {
      await execAsync('stylelint --version', { timeout: 5000 });
      result.stylelintAvailable = true;
    } catch {
      // Not available
    }

    // Check prettier
    try {
      await execAsync('prettier --version', { timeout: 5000 });
      result.prettierAvailable = true;
    } catch {
      // Not available
    }

    return result;
  }

  /**
   * Get supported fix strategies
   */
  getSupportedStrategies() {
    return ['default', 'conservative', 'aggressive'];
  }

  /**
   * Get module information
   */
  getInfo() {
    return {
      name: 'css',
      description: 'CSS validation, formatting, and linting',
      supportedExtensions: ['.css'],
      capabilities: [
        'Syntax validation',
        'Code formatting (prettier)',
        'Linting (stylelint)',
        'Auto-fixing',
        'Best practices enforcement'
      ],
      requiredTools: [],
      optionalTools: ['stylelint', 'prettier']
    };
  }
}
