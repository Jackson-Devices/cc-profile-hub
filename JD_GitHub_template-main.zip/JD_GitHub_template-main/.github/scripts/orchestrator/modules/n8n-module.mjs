/**
 * n8n Module - n8n workflow validation
 */

import BaseModule from './base-module.mjs';
import { readFile } from 'node:fs/promises';
import { existsSync } from 'node:fs';

export default class N8nModule extends BaseModule {
  constructor(config = {}) {
    super(config);
    this.name = 'n8n';
  }

  canHandle(filePath) {
    // n8n workflows are JSON files, but we need a way to identify them
    // For now, accept all .json files (could be improved with config)
    return filePath.endsWith('.json');
  }

  async check(files, _options = {}) {
    const issues = [];
    let filesChecked = 0;

    for (const file of files) {
      if (!existsSync(file)) {
        issues.push({
          file,
          line: 0,
          message: 'File not found',
          severity: 'error',
          rule: 'file-existence'
        });
        continue;
      }

      try {
        const content = await readFile(file, 'utf8');
        const workflow = JSON.parse(content);

        // Check for n8n workflow structure
        if (!workflow.name && !workflow.nodes) {
          // Might not be an n8n workflow, skip validation
          filesChecked++;
          continue;
        }

        // Validate n8n workflow structure
        if (workflow.nodes && !Array.isArray(workflow.nodes)) {
          issues.push({
            file,
            line: 0,
            message: 'nodes must be an array',
            severity: 'error',
            rule: 'workflow-structure'
          });
        }

        if (workflow.connections && typeof workflow.connections !== 'object') {
          issues.push({
            file,
            line: 0,
            message: 'connections must be an object',
            severity: 'error',
            rule: 'workflow-structure'
          });
        }

        filesChecked++;
      } catch (error) {
        if (error instanceof SyntaxError) {
          issues.push({
            file,
            line: 0,
            message: 'Invalid JSON',
            severity: 'error',
            rule: 'json-syntax'
          });
        } else {
          issues.push({
            file,
            line: 0,
            message: error.message,
            severity: 'error',
            rule: 'check-error'
          });
        }
      }
    }

    return { valid: issues.length === 0, issues, filesChecked };
  }

  async fix(files, _strategy = 'default') {
    return { valid: true, fixes: [], filesFixed: 0 };
  }

  getSupportedStrategies() {
    return ['default'];
  }

  getInfo() {
    return {
      name: 'n8n',
      description: 'n8n workflow validation',
      supportedExtensions: ['.json'],
      capabilities: ['Workflow structure validation', 'JSON syntax validation'],
      requiredTools: [],
      optionalTools: []
    };
  }
}
