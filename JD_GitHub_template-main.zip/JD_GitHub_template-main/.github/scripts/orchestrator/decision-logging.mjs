/**
 * Decision Logging System
 *
 * Implements BMAD (Build-Measure-Analyze-Decide) methodology
 * Tracks all orchestrator decisions with context and metrics
 */

import { appendFile, readFile, stat, mkdir } from 'node:fs/promises';
import { existsSync } from 'node:fs';
import { join, dirname } from 'node:path';
import { randomUUID } from 'node:crypto';

/**
 * Decision - Represents a single decision made by the orchestrator
 */
export class Decision {
  constructor(config) {
    // Validate required fields
    if (!config.type) {
      throw new Error('Missing required field: type');
    }
    if (!config.context) {
      throw new Error('Missing required field: context');
    }
    if (!config.action) {
      throw new Error('Missing required field: action');
    }
    if (!config.outcome) {
      throw new Error('Missing required field: outcome');
    }

    this.id = config.id || randomUUID();
    this.type = config.type;
    this.context = config.context;
    this.action = config.action;
    this.outcome = config.outcome;
    this.timestamp = config.timestamp || new Date();
    this.level = config.level || 'info';
    this.metrics = config.metrics || {};
    this.relatedDecisions = config.relatedDecisions || [];
    this.sessionId = config.sessionId;
  }

  /**
   * Serialize to JSON
   */
  toJSON() {
    return {
      id: this.id,
      type: this.type,
      context: this.context,
      action: this.action,
      outcome: this.outcome,
      timestamp: this.timestamp,
      level: this.level,
      metrics: this.metrics,
      relatedDecisions: this.relatedDecisions,
      sessionId: this.sessionId
    };
  }

  /**
   * Deserialize from JSON
   */
  static fromJSON(json) {
    return new Decision({
      ...json,
      timestamp: new Date(json.timestamp)
    });
  }
}

/**
 * DecisionQuery - Advanced query capabilities
 */
export class DecisionQuery {
  constructor(config = {}) {
    this.type = config.type;
    this.outcome = config.outcome;
    this.id = config.id;
    this.sessionId = config.sessionId;
    this.afterTimestamp = config.afterTimestamp;
    this.beforeTimestamp = config.beforeTimestamp;
    this.customFilter = config.customFilter;
  }

  /**
   * Check if a decision matches this query
   */
  matches(decision) {
    // Apply custom filter first if provided
    if (this.customFilter) {
      if (!this.customFilter(decision)) {
        return false;
      }
    }

    // Apply standard filters
    if (this.type && decision.type !== this.type) {
      return false;
    }

    if (this.outcome && decision.outcome !== this.outcome) {
      return false;
    }

    if (this.id && decision.id !== this.id) {
      return false;
    }

    if (this.sessionId && decision.sessionId !== this.sessionId) {
      return false;
    }

    if (this.afterTimestamp) {
      const decisionTime = decision.timestamp instanceof Date
        ? decision.timestamp
        : new Date(decision.timestamp);

      if (decisionTime <= this.afterTimestamp) {
        return false;
      }
    }

    if (this.beforeTimestamp) {
      const decisionTime = decision.timestamp instanceof Date
        ? decision.timestamp
        : new Date(decision.timestamp);

      if (decisionTime >= this.beforeTimestamp) {
        return false;
      }
    }

    return true;
  }
}

/**
 * DecisionLogger - Logs and queries decisions
 */
export class DecisionLogger {
  constructor(config = {}) {
    this.logDir = config.logDir || '.orchestrator/logs';
    this.logFile = join(this.logDir, 'decisions.jsonl');
    this.maxLogSize = config.maxLogSize || 10 * 1024 * 1024; // 10MB default
    this.sessionId = config.sessionId;
  }

  /**
   * Ensure log directory exists
   */
  async ensureLogDir() {
    const dir = dirname(this.logFile);
    if (!existsSync(dir)) {
      await mkdir(dir, { recursive: true });
    }
  }

  /**
   * Log a decision
   */
  async log(decision) {
    try {
      // Add session ID if configured
      if (this.sessionId && !decision.sessionId) {
        decision.sessionId = this.sessionId;
      }

      await this.ensureLogDir();

      // Check if rotation is needed
      await this.rotateIfNeeded();

      // Append to log file (JSONL format)
      const line = JSON.stringify(decision.toJSON()) + '\n';
      await appendFile(this.logFile, line, 'utf8');

      return {
        success: true,
        id: decision.id
      };
    } catch (error) {
      return {
        success: false,
        error: error.message
      };
    }
  }

  /**
   * Rotate log file if it exceeds max size
   */
  async rotateIfNeeded() {
    if (!existsSync(this.logFile)) {
      return;
    }

    try {
      const stats = await stat(this.logFile);

      if (stats.size > this.maxLogSize) {
        // Simple rotation: rename current file with timestamp
        const timestamp = new Date().toISOString().replace(/[:.]/g, '-');
        const rotatedFile = join(
          this.logDir,
          `decisions.${timestamp}.jsonl`
        );

        // Read current file
        const content = await readFile(this.logFile, 'utf8');

        // Write to rotated file
        const { writeFile: writeFilePromise } = await import('node:fs/promises');
        await writeFilePromise(rotatedFile, content, 'utf8');

        // Clear current file and write only recent entries
        const lines = content.trim().split('\n');
        const recentLines = lines.slice(-5); // Keep last 5 entries

        await writeFilePromise(
          this.logFile,
          recentLines.join('\n') + '\n',
          'utf8'
        );
      }
    } catch {
      // If rotation fails, continue - not critical
    }
  }

  /**
   * Query decisions
   */
  async query(queryOrFilters = {}) {
    // Create query object
    const query = queryOrFilters instanceof DecisionQuery
      ? queryOrFilters
      : new DecisionQuery(queryOrFilters);

    // Read log file
    if (!existsSync(this.logFile)) {
      return [];
    }

    const content = await readFile(this.logFile, 'utf8');
    const lines = content.trim().split('\n').filter(line => line.length > 0);

    // Parse and filter decisions
    const decisions = [];

    for (const line of lines) {
      try {
        const json = JSON.parse(line);

        // Try to create Decision - will skip if missing required fields
        try {
          const decision = Decision.fromJSON(json);

          // Apply query filter - custom filter errors should propagate
          if (query.matches(decision)) {
            decisions.push(decision);
          }
        } catch (error) {
          // If error is from custom filter, re-throw it
          if (error.message === 'Filter error') {
            throw error;
          }
          // Otherwise skip invalid decisions (missing required fields)
          continue;
        }
      } catch (error) {
        // If error is from custom filter, propagate it up
        if (error.message === 'Filter error') {
          throw error;
        }
        // Otherwise skip invalid JSON lines
        continue;
      }
    }

    return decisions;
  }

  /**
   * Get statistics about logged decisions
   */
  async getStatistics() {
    const decisions = await this.query();

    const stats = {
      totalDecisions: decisions.length,
      byType: {},
      byOutcome: {},
      successRate: 0
    };

    let successCount = 0;

    for (const decision of decisions) {
      // Count by type
      stats.byType[decision.type] = (stats.byType[decision.type] || 0) + 1;

      // Count by outcome
      stats.byOutcome[decision.outcome] =
        (stats.byOutcome[decision.outcome] || 0) + 1;

      // Count successes
      if (decision.outcome === 'success') {
        successCount++;
      }
    }

    // Calculate success rate
    if (decisions.length > 0) {
      stats.successRate = successCount / decisions.length;
    }

    return stats;
  }
}
