/**
 * Multi-Pass Fix Engine for Orchestrator V2
 *
 * Executes check → fix → check loop with intelligent retry logic
 * and strategy escalation.
 *
 * @class MultiPassFixEngine
 */

import AttemptTracker from './attempt-tracker.mjs';
import StrategySelector from './strategy-selector.mjs';

export default class MultiPassFixEngine {
  /**
   * Fix files with automatic retry and strategy escalation
   *
   * @param {object} module - Module instance with check() and fix() methods
   * @param {string[]} files - Files to fix
   * @param {object} options - Options
   * @param {number} options.maxAttempts - Maximum fix attempts (default: 5)
   * @param {number} options.timeout - Timeout per operation in ms (default: 60000)
   * @returns {Promise<object>} Result with success, attempts, and log
   */
  async fixWithRetries(module, files, options = {}) {
    const {
      maxAttempts = 5,
      timeout = 60000,
    } = options;

    // Handle edge cases
    const normalizedFiles = Array.isArray(files) ? files : (files ? [files] : []);
    const normalizedMaxAttempts = maxAttempts > 0 ? maxAttempts : 5; // Use default for invalid values

    const tracker = new AttemptTracker();
    const strategies = module.getSupportedStrategies ? module.getSupportedStrategies() : ['default'];
    const strategySelector = new StrategySelector(strategies);

    let currentFiles = normalizedFiles;
    let attemptNumber = 0;

    // Main retry loop
    while (attemptNumber < normalizedMaxAttempts) {
      attemptNumber++;

      // Step 1: Check current state
      let checkResult;
      try {
        checkResult = await this.runWithTimeout(
          () => module.check(currentFiles),
          timeout
        );
      } catch (error) {
        // Timeout or check error
        throw new Error(`Check failed: ${error.message}`);
      }

      tracker.recordCheck(attemptNumber, checkResult);

      // Step 2: If no issues, SUCCESS
      if (checkResult.success && (!checkResult.issues || checkResult.issues.length === 0)) {
        return {
          success: true,
          attempts: tracker.getAttemptCount(),
          log: tracker.getLog(),
          summary: tracker.getSummary(),
        };
      }

      // Step 3: If last attempt, FAIL
      if (attemptNumber >= normalizedMaxAttempts) {
        return {
          success: false,
          attempts: tracker.getAttemptCount(),
          log: tracker.getLog(),
          summary: tracker.getSummary(),
          remainingIssues: checkResult.issues || [],
          message: `Failed after ${normalizedMaxAttempts} attempts`,
        };
      }

      // Step 4: Apply fix with escalating strategy
      const strategy = strategySelector.selectStrategy(attemptNumber);
      let fixResult;

      try {
        fixResult = await this.runWithTimeout(
          () => module.fix(currentFiles, strategy),
          timeout
        );
      } catch (error) {
        // Timeout or fix error - record and continue to next attempt
        tracker.recordFix(attemptNumber, strategy, {
          success: false,
          error: error.message,
        });
        continue;
      }

      tracker.recordFix(attemptNumber, strategy, fixResult);

      // Step 5: If fix failed, try next strategy/attempt
      if (!fixResult.success) {
        continue;
      }

      // Step 6: Update file list with modifications (if provided)
      if (fixResult.files_modified && fixResult.files_modified.length > 0) {
        currentFiles = fixResult.files_modified;
      }
    }

    // Fallback - should not reach here normally
    return {
      success: false,
      attempts: tracker.getAttemptCount(),
      log: tracker.getLog(),
      summary: tracker.getSummary(),
      message: `Max attempts (${normalizedMaxAttempts}) reached`,
    };
  }

  /**
   * Run a function with timeout
   *
   * @param {Function} fn - Async function to run
   * @param {number} timeoutMs - Timeout in milliseconds
   * @returns {Promise<any>} Result of the function
   * @throws {Error} If timeout is exceeded
   */
  async runWithTimeout(fn, timeoutMs) {
    return Promise.race([
      fn(),
      new Promise((_, reject) =>
        setTimeout(() => reject(new Error(`Operation timed out after ${timeoutMs}ms`)), timeoutMs)
      ),
    ]);
  }
}
