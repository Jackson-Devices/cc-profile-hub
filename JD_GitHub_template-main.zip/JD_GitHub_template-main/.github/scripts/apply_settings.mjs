// Sync repository labels from .github/settings.yml
//
// Features:
// - Strict mode: delete labels not listed in settings.yml
// - Hard reset mode: skip renames and delete all extras immediately
// - Rename support: use from_name to preserve issue/PR attachments during transition
// - Dry-run mode: preview changes without applying them
// - Guardrails: owner/actor allowlists with configurable violation actions
//   (fail|warn|open_issue|skip)

import { readFileSync } from 'node:fs';
import { resolve } from 'node:path';
import YAML from 'yaml';
import { Octokit } from '@octokit/core';
import { paginateRest } from '@octokit/plugin-paginate-rest';

const Octo = Octokit.plugin(paginateRest);

// ========== Helper Functions ==========

// Normalize color hex codes: strip #, pad to 6 chars, lowercase
function norm_color(s) {
  if (!s) return 'cccccc';
  const hex = s.replace(/^#/, '').toLowerCase();
  return hex.padStart(6, '0').slice(0, 6);
}

// Validate color format (must be valid hex: 3 or 6 chars)
function is_valid_color(s) {
  if (!s) return true; // Optional field, empty is ok (will use default)
  const hex = s.replace(/^#/, '');
  // Must be 3 or 6 hex characters
  return /^[0-9a-fA-F]{3}$|^[0-9a-fA-F]{6}$/.test(hex);
}

// Parse comma-separated environment variable into array
function str_list_env(name, dflt = '') {
  return (process.env[name] || dflt)
    .split(',')
    .map((s) => s.trim())
    .filter(Boolean);
}

// Prefix log message with "(dry_run)" when in dry-run mode
function desc(s, is_dry_run) {
  return is_dry_run ? `(dry_run) ${s}` : s;
}

// ANSI color codes for terminal output
const colors = {
  reset: '\x1b[0m',
  green: '\x1b[32m', // Creates
  blue: '\x1b[34m', // Renames
  yellow: '\x1b[33m', // Updates
  red: '\x1b[31m', // Deletes
  gray: '\x1b[90m', // Unchanged/debug
  cyan: '\x1b[36m', // Info
};

// Colorize output based on operation type
function colorize(text, color) {
  // Disable colors if NO_COLOR env var is set or not in TTY
  if (process.env.NO_COLOR || !process.stdout.isTTY) {
    return text;
  }
  return `${color}${text}${colors.reset}`;
}

// Debug logging (only when DEBUG=true)
function debug(...args) {
  if (process.env.DEBUG === 'true') {
    console.log(colorize('[DEBUG]', colors.gray), ...args);
  }
}

// Validate settings.yml structure and content
function validate_settings(doc) {
  const errors = [];
  const warnings = [];

  // 1. Check document structure
  if (!doc || typeof doc !== 'object') {
    errors.push('settings.yml must contain a valid YAML object');
    return { valid: false, errors, warnings };
  }

  if (!doc.labels) {
    errors.push("settings.yml must contain a 'labels' key");
    return { valid: false, errors, warnings };
  }

  if (!Array.isArray(doc.labels)) {
    errors.push("'labels' must be an array");
    return { valid: false, errors, warnings };
  }

  if (doc.labels.length === 0) {
    warnings.push('labels array is empty - no labels will be created');
  }

  // 2. Validate each label entry
  const seen_names = new Map(); // Track duplicates and their line numbers

  doc.labels.forEach((entry, idx) => {
    const position = `labels[${idx}]`;

    // Check entry is an object
    if (!entry || typeof entry !== 'object') {
      errors.push(`${position}: must be an object`);
      return;
    }

    // Check required field: name
    if (!entry.name) {
      errors.push(`${position}: missing required field 'name'`);
      return;
    }

    if (typeof entry.name !== 'string') {
      errors.push(`${position}: 'name' must be a string`);
      return;
    }

    if (entry.name.trim().length === 0) {
      errors.push(`${position}: 'name' cannot be empty`);
      return;
    }

    // Check for duplicate names
    if (seen_names.has(entry.name)) {
      errors.push(
        `${position}: duplicate label name '${entry.name}' (first seen at labels[${seen_names.get(entry.name)}])`
      );
    } else {
      seen_names.set(entry.name, idx);
    }

    // Validate optional field: color
    if (entry.color !== undefined) {
      if (typeof entry.color !== 'string') {
        errors.push(`${position} ('${entry.name}'): 'color' must be a string`);
      } else if (!is_valid_color(entry.color)) {
        errors.push(
          `${position} ('${entry.name}'): invalid color format '${entry.color}' (must be 3 or 6 hex digits, optionally prefixed with #)`
        );
      }
    }

    // Validate optional field: description
    if (entry.description !== undefined && typeof entry.description !== 'string') {
      errors.push(`${position} ('${entry.name}'): 'description' must be a string`);
    }

    // Validate optional field: from_name
    if (entry.from_name !== undefined) {
      if (typeof entry.from_name !== 'string') {
        errors.push(`${position} ('${entry.name}'): 'from_name' must be a string`);
      } else if (entry.from_name.trim().length === 0) {
        errors.push(`${position} ('${entry.name}'): 'from_name' cannot be empty`);
      }
    }

    // Warn about unknown fields
    const known_fields = ['name', 'color', 'description', 'from_name'];
    const unknown_fields = Object.keys(entry).filter((k) => !known_fields.includes(k));
    if (unknown_fields.length > 0) {
      warnings.push(
        `${position} ('${entry.name}'): unknown fields will be ignored: ${unknown_fields.join(', ')}`
      );
    }
  });

  // 3. Validate from_name references
  const all_names = new Set(doc.labels.map((l) => l.name).filter(Boolean));
  doc.labels.forEach((entry, idx) => {
    if (entry.from_name && !all_names.has(entry.from_name)) {
      // This is a warning, not an error - from_name might reference an existing GitHub label
      warnings.push(
        `labels[${idx}] ('${entry.name}'): from_name '${entry.from_name}' not found in settings.yml (will attempt to rename from existing GitHub label)`
      );
    }
  });

  return {
    valid: errors.length === 0,
    errors,
    warnings,
  };
}

// API call statistics and caching
const api_stats = {
  calls: 0,
  cached: 0,
  rate_limit_remaining: null,
  rate_limit_reset: null,
};
const api_cache = new Map();

// Sleep for milliseconds
const sleep = (ms) =>
  new Promise((resolve) => {
    setTimeout(resolve, ms);
  });

// Retry wrapper with exponential backoff and rate limit handling
async function api_retry(fn, description, max_retries = 3) {
  let last_error = null;

  for (let attempt = 1; attempt <= max_retries; attempt++) {
    try {
      const result = await fn();
      api_stats.calls++;

      // Extract rate limit info from response headers if available
      if (result && result.headers) {
        const remaining = result.headers['x-ratelimit-remaining'];
        const reset = result.headers['x-ratelimit-reset'];
        if (remaining !== undefined) api_stats.rate_limit_remaining = parseInt(remaining);
        if (reset !== undefined) api_stats.rate_limit_reset = parseInt(reset);
      }

      return result;
    } catch (err) {
      last_error = err;

      // Check if this is a rate limit error (403 + rate limit headers)
      if (err.status === 403 && err.response?.headers?.['x-ratelimit-remaining'] === '0') {
        const reset_timestamp = parseInt(err.response.headers['x-ratelimit-reset'] || '0');
        const now = Math.floor(Date.now() / 1000);
        const wait_seconds = reset_timestamp - now;

        console.error(`\n❌ GitHub API rate limit exceeded for ${description}!`);
        console.error(
          `   Rate limit resets in ${Math.max(0, wait_seconds)} seconds (${new Date(reset_timestamp * 1000).toISOString()})`
        );
        console.error(`   Please wait and try again later.\n`);
        process.exit(1);
      }

      // Check if this is a retryable error (network or 5xx)
      const is_retryable =
        err.status >= 500 || // Server errors
        err.code === 'ECONNRESET' ||
        err.code === 'ETIMEDOUT' ||
        err.code === 'ENOTFOUND';

      if (!is_retryable || attempt === max_retries) {
        throw err; // Not retryable or max retries reached
      }

      // Exponential backoff: 2^attempt seconds
      const backoff_ms = Math.pow(2, attempt) * 1000;
      console.warn(
        `⚠️  ${description} failed (attempt ${attempt}/${max_retries}): ${err.status || err.code || err.message}`
      );
      console.warn(`   Retrying in ${backoff_ms / 1000}s...`);
      await sleep(backoff_ms);
    }
  }

  throw last_error;
}

// Cached API wrapper for GET requests (unused, kept for future use)
async function _cached_get(octo, route, params, description) {
  const cache_key = `${route}:${JSON.stringify(params)}`;

  if (api_cache.has(cache_key)) {
    api_stats.cached++;
    return api_cache.get(cache_key);
  }

  const result = await api_retry(() => octo.request(route, params), description);

  api_cache.set(cache_key, result);
  return result;
}
// ======================================

(async () => {
  // Start timing
  const start_time = Date.now();

  // ========== Environment & Configuration ==========

  // Repository context from GitHub Actions environment
  const repo_env = process.env.GITHUB_REPOSITORY;
  if (!repo_env) throw new Error('GITHUB_REPOSITORY not set');
  const [owner, repo] = repo_env.split('/');

  const token = process.env.GITHUB_TOKEN;
  if (!token) throw new Error('GITHUB_TOKEN not set');

  const actor = process.env.GITHUB_ACTOR || '';

  // Operation mode: "dry_run" (preview only) or "apply" (make changes)
  const mode = (process.env.mode || 'apply').toLowerCase();
  const is_dry_run = mode === 'dry_run';

  // Label sync behavior
  const strict = (process.env.strict_label_sync || 'true').toLowerCase() === 'true';
  const hard_reset = (process.env.hard_reset_labels || 'false').toLowerCase() === 'true';

  // Security guardrails
  const on_guard_action = (process.env.on_guard_action || 'fail').toLowerCase();
  const owner_allowlist = str_list_env('owner_allowlist', '');
  const actor_allowlist = str_list_env('actor_allowlist', '');

  const octo = new Octo({ auth: token });

  // ========== Guardrail Violation Handler ==========
  // Handle security guardrail violations based on configured action
  async function guard_violation(msg) {
    console.warn(`[guard] ${msg}`);

    // Optionally create a GitHub issue to document the violation
    if (on_guard_action === 'open_issue') {
      try {
        await octo.request('POST /repos/{owner}/{repo}/issues', {
          owner,
          repo,
          title: 'Label sync blocked by guardrail',
          body: `${msg}\n\n- owner: \`${owner}\`\n- repo: \`${repo}\`\n- actor: \`${actor}\`\n- mode: \`${mode}\`\n- strict: \`${strict}\`\n- hard_reset: \`${hard_reset}\``,
        });
      } catch (e) {
        console.warn(`[guard] failed to open issue: ${e.status || ''} ${e.message}`);
      }
    }

    // Exit gracefully for non-fatal actions (warn, open_issue, skip)
    if (['warn', 'open_issue', 'skip'].includes(on_guard_action)) process.exit(0);

    // Default: fail hard (exit with error code)
    process.exit(1);
  }

  // ========== Security Checks ==========
  // Verify repository owner and workflow actor against allowlists
  if (owner_allowlist.length && !owner_allowlist.includes(owner)) {
    await guard_violation(
      `repository owner '${owner}' is not in allowlist [${owner_allowlist.join(', ')}]`
    );
  }
  if (actor_allowlist.length && !actor_allowlist.includes(actor)) {
    await guard_violation(`actor '${actor}' is not in allowlist [${actor_allowlist.join(', ')}]`);
  }

  // ========== Load Label Configuration ==========
  // Parse settings.yml and extract label definitions
  const settings_path = resolve(process.cwd(), '.github/settings.yml');
  const raw_yaml = readFileSync(settings_path, 'utf8');
  const doc = YAML.parse(raw_yaml) || {};

  // Validate settings.yml structure and content
  const validation = validate_settings(doc);

  // Show validation warnings
  if (validation.warnings.length > 0) {
    console.warn('\n⚠️  Validation Warnings:');
    validation.warnings.forEach((w) => console.warn(`  - ${w}`));
    console.warn('');
  }

  // Exit if validation errors found
  if (!validation.valid) {
    console.error('\n❌ Validation Errors in settings.yml:');
    validation.errors.forEach((e) => console.error(`  - ${e}`));
    console.error('\nPlease fix these errors and try again.\n');
    process.exit(1);
  }

  const desired = Array.isArray(doc.labels) ? doc.labels : [];

  // Normalize desired labels into a lookup map
  const desired_by_name = new Map();
  for (const entry of desired) {
    if (!entry || !entry.name) continue;
    desired_by_name.set(entry.name, {
      name: entry.name,
      color: norm_color(entry.color),
      description: entry.description ?? '',
      from_name: entry.from_name || null, // For renaming existing labels
    });
  }

  // ========== Fetch Existing Repository Labels ==========
  console.log(`Fetching existing labels from ${owner}/${repo}...`);
  const existing = await octo.paginate('GET /repos/{owner}/{repo}/labels', {
    owner,
    repo,
    per_page: 100,
  });
  const existing_by_name = new Map(existing.map((l) => [l.name, l]));
  console.log(`Found ${existing.length} existing labels`);

  // ========== Operation Tracking ==========
  const stats = {
    renamed: 0,
    created: 0,
    updated: 0,
    deleted: 0,
    unchanged: 0,
  };

  // Detailed operation log for grouping and before/after display
  const operations = {
    renames: [],
    creates: [],
    updates: [],
    deletes: [],
  };

  // ========== STEP 1: Rename Labels ==========
  // Preserve issue/PR attachments by renaming instead of delete+create
  // Skipped when hard_reset mode is enabled
  if (!hard_reset) {
    for (const desired_label of desired_by_name.values()) {
      // Skip labels without a from_name (no rename needed)
      if (!desired_label.from_name) continue;

      const old_label = existing_by_name.get(desired_label.from_name);
      const new_label = existing_by_name.get(desired_label.name);

      // Only rename if old label exists and new label doesn't
      if (old_label && !new_label) {
        const msg = `rename '${desired_label.from_name}' → '${desired_label.name}'`;
        console.log(colorize(desc(msg, is_dry_run), colors.blue));

        operations.renames.push({
          from: desired_label.from_name,
          to: desired_label.name,
        });

        if (!is_dry_run) {
          await api_retry(
            () =>
              octo.request('PATCH /repos/{owner}/{repo}/labels/{name}', {
                owner,
                repo,
                name: desired_label.from_name,
                new_name: desired_label.name,
                color: desired_label.color,
                description: desired_label.description,
              }),
            `rename '${desired_label.from_name}'`
          );
        }
        stats.renamed++;

        // Update our tracking maps to reflect the rename
        existing_by_name.delete(desired_label.from_name);
        existing_by_name.set(desired_label.name, {
          name: desired_label.name,
          color: desired_label.color,
          description: desired_label.description,
        });
      }
    }
  }

  // ========== STEP 2: Create/Update Labels ==========
  // Create new labels or update existing ones with changed colors/descriptions
  for (const desired_label of desired_by_name.values()) {
    const current_label = existing_by_name.get(desired_label.name);

    // Label doesn't exist - create it
    if (!current_label) {
      console.log(colorize(desc(`create '${desired_label.name}'`, is_dry_run), colors.green));

      operations.creates.push({
        name: desired_label.name,
        color: desired_label.color,
        description: desired_label.description,
      });

      if (!is_dry_run) {
        await api_retry(
          () =>
            octo.request('POST /repos/{owner}/{repo}/labels', {
              owner,
              repo,
              name: desired_label.name,
              color: desired_label.color,
              description: desired_label.description,
            }),
          `create '${desired_label.name}'`
        );
      }
      stats.created++;
      continue;
    }

    // Label exists - check if color or description needs updating
    const current_color = norm_color(current_label.color);
    const current_desc = current_label.description ?? '';
    const needs_update =
      current_color !== desired_label.color || current_desc !== desired_label.description;

    if (needs_update) {
      let msg = `update '${desired_label.name}'`;
      const changes = [];

      if (current_color !== desired_label.color) {
        changes.push(`color: #${current_color} → #${desired_label.color}`);
      }
      if (current_desc !== desired_label.description) {
        const old_desc = current_desc || '(none)';
        const new_desc = desired_label.description || '(none)';
        changes.push(`description: "${old_desc}" → "${new_desc}"`);
      }

      if (changes.length > 0) {
        msg += ` (${changes.join(', ')})`;
      }

      console.log(colorize(desc(msg, is_dry_run), colors.yellow));

      operations.updates.push({
        name: desired_label.name,
        before: { color: current_color, description: current_desc },
        after: { color: desired_label.color, description: desired_label.description },
      });

      if (!is_dry_run) {
        await api_retry(
          () =>
            octo.request('PATCH /repos/{owner}/{repo}/labels/{name}', {
              owner,
              repo,
              name: desired_label.name,
              new_name: desired_label.name,
              color: desired_label.color,
              description: desired_label.description,
            }),
          `update '${desired_label.name}'`
        );
      }
      stats.updated++;
    } else {
      debug(`unchanged '${desired_label.name}'`);
      stats.unchanged++;
    }
  }

  // ========== STEP 3: Delete Unlisted Labels ==========
  // Remove labels not in settings.yml (only when strict mode is enabled)
  if (strict) {
    const desired_names = new Set([...desired_by_name.keys()]);
    for (const cur of existing) {
      if (!desired_names.has(cur.name)) {
        console.log(colorize(desc(`delete '${cur.name}'`, is_dry_run), colors.red));

        operations.deletes.push({
          name: cur.name,
        });

        if (!is_dry_run) {
          try {
            await api_retry(
              () =>
                octo.request('DELETE /repos/{owner}/{repo}/labels/{name}', {
                  owner,
                  repo,
                  name: cur.name,
                }),
              `delete '${cur.name}'`
            );
            stats.deleted++;
          } catch (err) {
            // Log but don't fail if delete fails (e.g., label in use)
            console.warn(`skip_delete '${cur.name}': ${err.status || ''} ${err.message}`);
          }
        } else {
          stats.deleted++;
        }
      }
    }
  }

  // ========== Summary ==========
  const elapsed_ms = Date.now() - start_time;
  const elapsed_sec = (elapsed_ms / 1000).toFixed(2);

  console.log('\n' + '='.repeat(60));
  console.log('LABEL SYNC SUMMARY');
  console.log('='.repeat(60));
  console.log(`Mode:        ${mode}`);
  console.log(`Repository:  ${owner}/${repo}`);
  console.log(`Actor:       ${actor}`);
  console.log(`Strict:      ${strict}`);
  console.log(`Hard Reset:  ${hard_reset}`);
  console.log('-'.repeat(60));
  console.log('LABEL OPERATIONS:');
  console.log(`  Renamed:     ${stats.renamed}`);
  console.log(`  Created:     ${stats.created}`);
  console.log(`  Updated:     ${stats.updated}`);
  console.log(`  Deleted:     ${stats.deleted}`);
  console.log(`  Unchanged:   ${stats.unchanged}`);

  // Show grouped operations details if DEBUG mode enabled
  if (process.env.DEBUG === 'true') {
    console.log('-'.repeat(60));
    console.log('OPERATION DETAILS:');

    if (operations.renames.length > 0) {
      console.log(colorize('\n  Renames:', colors.blue));
      operations.renames.forEach((op) => {
        console.log(`    - ${op.from} → ${op.to}`);
      });
    }

    if (operations.creates.length > 0) {
      console.log(colorize('\n  Creates:', colors.green));
      operations.creates.forEach((op) => {
        console.log(`    - ${op.name} (#${op.color})`);
      });
    }

    if (operations.updates.length > 0) {
      console.log(colorize('\n  Updates:', colors.yellow));
      operations.updates.forEach((op) => {
        console.log(`    - ${op.name}`);
        if (op.before.color !== op.after.color) {
          console.log(`      Color: #${op.before.color} → #${op.after.color}`);
        }
        if (op.before.description !== op.after.description) {
          console.log(`      Desc:  "${op.before.description}" → "${op.after.description}"`);
        }
      });
    }

    if (operations.deletes.length > 0) {
      console.log(colorize('\n  Deletes:', colors.red));
      operations.deletes.forEach((op) => {
        console.log(`    - ${op.name}`);
      });
    }
  }

  console.log('-'.repeat(60));
  const total_changes = stats.renamed + stats.created + stats.updated + stats.deleted;
  console.log(`Total changes: ${total_changes}`);
  console.log('-'.repeat(60));
  console.log('PERFORMANCE:');
  console.log(`  Time taken:       ${elapsed_sec}s`);
  console.log(`  API calls made:   ${api_stats.calls}`);
  console.log(`  Cached responses: ${api_stats.cached}`);
  if (api_stats.rate_limit_remaining !== null) {
    console.log(`  Rate limit:       ${api_stats.rate_limit_remaining} requests remaining`);
    if (api_stats.rate_limit_reset !== null) {
      const reset_date = new Date(api_stats.rate_limit_reset * 1000);
      console.log(`  Rate limit reset: ${reset_date.toISOString()}`);
    }
  }
  console.log('='.repeat(60));

  // Helpful tips
  if (process.env.DEBUG !== 'true') {
    console.log(
      colorize('\n💡 Tip: Set DEBUG=true to see detailed operation breakdown', colors.cyan)
    );
  }
  if (process.env.NO_COLOR) {
    console.log(colorize('💡 Tip: Unset NO_COLOR to enable colored output', colors.cyan));
  }
  console.log('');
})().catch((err) => {
  console.error(err);
  process.exit(1);
});
