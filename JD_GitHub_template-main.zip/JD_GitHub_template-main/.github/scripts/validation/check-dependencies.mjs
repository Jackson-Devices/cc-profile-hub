#!/usr/bin/env node
/**
 * @file check-dependencies.mjs
 * @description Centralized dependency validation for GitHub Actions workflows
 *
 * Purpose:
 * - Validates npm package compatibility across workflows
 * - Detects peer dependency conflicts
 * - Ensures consistent Node.js versions
 * - Checks for unused dependencies
 *
 * Usage:
 *   node .github/scripts/validation/check-dependencies.mjs [workflow-file]
 *   node .github/scripts/validation/check-dependencies.mjs --all
 *
 * Exit codes:
 *   0 - All checks passed
 *   1 - Validation errors found
 *   2 - Script error (missing files, parse errors)
 */

import { readFile, readdir } from 'node:fs/promises';
import { join, basename } from 'node:path';
import YAML from 'yaml';

const REPO_STANDARD_NODE_VERSION = '20';
const ALLOWED_PACKAGES = [
  'yaml',
  'prettier',
  'eslint',
  '@octokit/core',
  '@octokit/plugin-paginate-rest',
  'octokit/core', // Handle @scope/package extraction
  'octokit/plugin-paginate-rest',
  'js-yaml',
  'ajv',
  'execa',
];

// Known conflicting package combinations
// Note: These check if the problematic package is installed
// (The validation is simplified - checks if the bad package is present)
const CONFLICTING_PACKAGES = [
  {
    // Check if @octokit/plugin-retry is being installed
    // (it conflicts with @octokit/core@6.x in package.json)
    packages: ['@octokit/plugin-retry'],
    reason: '@octokit/plugin-retry@8.x requires @octokit/core >= 7 (package.json has 6.x)',
    fix: 'Remove @octokit/plugin-retry from the install command',
  },
];

class DependencyValidator {
  constructor() {
    this.errors = [];
    this.warnings = [];
    this.workflowsChecked = 0;
  }

  /**
   * Validate a single workflow file
   */
  async validateWorkflow(workflowPath) {
    try {
      const content = await readFile(workflowPath, 'utf8');
      const workflow = YAML.parse(content);
      const workflowName = basename(workflowPath);

      console.log(`\n🔍 Checking ${workflowName}...`);

      // Check 1: Node.js version consistency
      this.checkNodeVersion(workflow, workflowName);

      // Check 2: Dependency conflicts
      this.checkDependencyConflicts(workflow, workflowName, content);

      // Check 3: Unused dependencies
      this.checkUnusedDependencies(workflow, workflowName, content);

      // Check 4: Package.json compatibility
      await this.checkPackageJsonCompatibility(workflow, workflowName);

      this.workflowsChecked++;
    } catch (error) {
      this.errors.push(`Failed to validate ${workflowPath}: ${error.message}`);
    }
  }

  /**
   * Check Node.js version consistency
   */
  checkNodeVersion(workflow, workflowName) {
    if (!workflow.jobs) return;

    for (const [jobName, job] of Object.entries(workflow.jobs)) {
      if (!job.steps) continue;

      for (const step of job.steps) {
        if (step.uses && step.uses.includes('actions/setup-node')) {
          const version = step.with?.['node-version'];
          if (version !== REPO_STANDARD_NODE_VERSION) {
            this.errors.push(
              `${workflowName} -> ${jobName}: Node.js version ${version} does not match repo standard (${REPO_STANDARD_NODE_VERSION})`
            );
          }
        }
      }
    }
  }

  /**
   * Check for dependency conflicts
   */
  checkDependencyConflicts(workflow, workflowName, content) {
    // Extract all npm install commands
    const npmInstalls = content.match(/npm install ([^\n]+)/g) || [];

    for (const installCmd of npmInstalls) {
      // Check for known conflicts
      for (const conflict of CONFLICTING_PACKAGES) {
        // Check if any of the conflicting packages are in this install command
        const hasConflictingPackage = conflict.packages.some((pkg) => {
          // Extract base package name (handle @scope/package format)
          const pkgName = pkg.split('@').filter(Boolean).join('/');
          return installCmd.includes(pkgName);
        });

        if (hasConflictingPackage) {
          this.errors.push(
            `${workflowName}: Dependency conflict detected in "${installCmd}"\n` +
              `  Reason: ${conflict.reason}\n` +
              `  Fix: ${conflict.fix}`
          );
        }
      }

      // Check for disallowed packages
      const packages = installCmd.replace('npm install', '').trim().split(/\s+/);
      for (const pkg of packages) {
        if (pkg && !pkg.startsWith('-')) {
          // Extract base package name (handle @scope/package format)
          const basePkgName = pkg.split('@').filter(Boolean)[0];
          if (!ALLOWED_PACKAGES.includes(basePkgName)) {
            this.warnings.push(
              `${workflowName}: Package "${pkg}" is not in the allowed list. Verify it's necessary.`
            );
          }
        }
      }
    }
  }

  /**
   * Check for unused dependencies
   */
  checkUnusedDependencies(workflow, workflowName, content) {
    const npmInstalls = content.match(/npm install ([^\n]+)/g) || [];

    for (const installCmd of npmInstalls) {
      const packages = installCmd.replace('npm install', '').trim().split(/\s+/);

      for (const pkg of packages) {
        if (!pkg || pkg.startsWith('-')) continue;

        const pkgName = pkg.split('@')[0];

        // Check if package is used in the workflow
        const usagePatterns = [
          new RegExp(`require\\(['"]${pkgName}['"]\\)`, 'g'),
          new RegExp(`from ['"]${pkgName}['"]`, 'g'),
          new RegExp(`import.*${pkgName}`, 'g'),
        ];

        const isUsed = usagePatterns.some((pattern) => pattern.test(content));

        if (!isUsed) {
          this.warnings.push(
            `${workflowName}: Package "${pkg}" is installed but may not be used in the workflow`
          );
        }
      }
    }
  }

  /**
   * Check package.json compatibility
   */
  async checkPackageJsonCompatibility(_workflow, _workflowName) {
    try {
      const pkgContent = await readFile('package.json', 'utf8');
      const pkg = JSON.parse(pkgContent);

      // Check for version mismatches between workflow and package.json
      // This is a placeholder for more complex checks
      if (pkg.engines && pkg.engines.node) {
        const requiredVersion = pkg.engines.node.replace(/[^\d.]/g, '').split('.')[0];
        if (requiredVersion !== REPO_STANDARD_NODE_VERSION) {
          this.warnings.push(
            `package.json requires Node.js ${requiredVersion}, but workflows use ${REPO_STANDARD_NODE_VERSION}`
          );
        }
      }
    } catch {
      // package.json check is optional
    }
  }

  /**
   * Print validation results
   */
  printResults() {
    console.log('\n' + '='.repeat(60));
    console.log('📊 DEPENDENCY VALIDATION RESULTS');
    console.log('='.repeat(60));

    console.log(`\n✅ Workflows checked: ${this.workflowsChecked}`);

    if (this.warnings.length > 0) {
      console.log(`\n⚠️  Warnings (${this.warnings.length}):`);
      this.warnings.forEach((warning) => console.log(`  - ${warning}`));
    }

    if (this.errors.length > 0) {
      console.log(`\n❌ Errors (${this.errors.length}):`);
      this.errors.forEach((error) => console.log(`  - ${error}`));
      console.log('\n');
      return false;
    }

    if (this.warnings.length === 0 && this.errors.length === 0) {
      console.log('\n✨ All dependency checks passed!');
    }

    console.log('');
    return true;
  }
}

/**
 * Main execution
 */
async function main() {
  const args = process.argv.slice(2);
  const validator = new DependencyValidator();

  try {
    if (args.includes('--all')) {
      // Check all workflow files
      const workflowDir = '.github/workflows';
      const files = await readdir(workflowDir);

      for (const file of files) {
        if (file.endsWith('.yml') || file.endsWith('.yaml')) {
          await validator.validateWorkflow(join(workflowDir, file));
        }
      }
    } else if (args.length > 0) {
      // Check specific workflow file
      await validator.validateWorkflow(args[0]);
    } else {
      console.error('Usage: check-dependencies.mjs [workflow-file] | --all');
      process.exit(2);
    }

    const success = validator.printResults();
    process.exit(success ? 0 : 1);
  } catch (error) {
    console.error(`\n❌ Script error: ${error.message}`);
    console.error(error.stack);
    process.exit(2);
  }
}

main();
