#!/usr/bin/env node
/**
 * @file check-permissions.mjs
 * @description Centralized permission validation for GitHub Actions workflows
 *
 * Purpose:
 * - Validates workflow permissions follow least-privilege principle
 * - Detects overly-permissive workflows
 * - Ensures consistent permission patterns
 * - Checks for missing required permissions
 *
 * Usage:
 *   node .github/scripts/validation/check-permissions.mjs [workflow-file]
 *   node .github/scripts/validation/check-permissions.mjs --all
 *
 * Exit codes:
 *   0 - All checks passed
 *   1 - Validation errors found
 *   2 - Script error (missing files, parse errors)
 */

import { readFile, readdir } from 'node:fs/promises';
import { join, basename } from 'node:path';
import YAML from 'yaml';

// Standard permission categories
const _PERMISSION_CATEGORIES = {
  'read-only': {
    contents: 'read',
    permissions: ['contents: read', 'pull-requests: read', 'issues: read'],
  },
  'content-writer': {
    contents: 'write',
    permissions: ['contents: write'],
  },
  'issue-manager': {
    issues: 'write',
    permissions: ['issues: write', 'contents: read'],
  },
  'pr-manager': {
    'pull-requests': 'write',
    permissions: ['pull-requests: write', 'contents: read'],
  },
  orchestrator: {
    comprehensive: true,
    permissions: ['contents: write', 'issues: write', 'pull-requests: write', 'actions: read'],
  },
};

// Workflows and their required permissions
const WORKFLOW_PERMISSION_REQUIREMENTS = {
  // Read-only workflows
  'pr-risk-check.yml': ['contents: read', 'pull-requests: read'],
  'eslint-check.yml': ['contents: read'],
  'format-check.yml': ['contents: read'],
  'lint-check.yml': ['contents: read'],

  // Content writers (commit changes)
  'eslint-apply.yml': ['contents: write'],
  'format-apply.yml': ['contents: write'],
  'workflow-lint-apply.yml': ['contents: write'],
  'workflow-yaml-format-apply.yml': ['contents: write'],

  // Issue managers
  'validate-issue.yml': ['issues: write', 'contents: write'],
  'validate-function.yml': ['issues: write', 'contents: write'],
  'validate-test-suite.yml': ['issues: write', 'contents: write'],
  'validate-sub-feature.yml': ['issues: write', 'contents: write'],
  'enforce_test_gate.yml': ['issues: write', 'contents: write'],

  // Orchestrators
  'orchestrator.yml': ['contents: write', 'issues: write', 'pull-requests: write', 'actions: read'],
};

// Dangerous permission combinations
const DANGEROUS_PERMISSIONS = [
  {
    permissions: ['contents: write', 'actions: write'],
    reason: 'Can modify workflows and potentially escalate privileges',
    severity: 'critical',
  },
  {
    permissions: ['contents: write', 'packages: write'],
    reason: 'Can publish malicious packages',
    severity: 'high',
  },
];

class PermissionValidator {
  constructor() {
    this.errors = [];
    this.warnings = [];
    this.workflowsChecked = 0;
    this.permissionStats = {};
  }

  /**
   * Validate a single workflow file
   */
  async validateWorkflow(workflowPath) {
    try {
      const content = await readFile(workflowPath, 'utf8');
      const workflow = YAML.parse(content);
      const workflowName = basename(workflowPath);

      console.log(`\n🔍 Checking ${workflowName}...`);

      // Check 1: Permissions defined at workflow level
      this.checkWorkflowPermissions(workflow, workflowName);

      // Check 2: Job-level permissions
      this.checkJobPermissions(workflow, workflowName);

      // Check 3: Dangerous permission combinations
      this.checkDangerousPermissions(workflow, workflowName);

      // Check 4: Required permissions for workflow type
      this.checkRequiredPermissions(workflow, workflowName);

      // Check 5: Least-privilege principle
      this.checkLeastPrivilege(workflow, workflowName);

      this.workflowsChecked++;
    } catch (error) {
      this.errors.push(`Failed to validate ${workflowPath}: ${error.message}`);
    }
  }

  /**
   * Check workflow-level permissions
   */
  checkWorkflowPermissions(workflow, workflowName) {
    if (!workflow.permissions) {
      this.warnings.push(
        `${workflowName}: No workflow-level permissions defined. Consider explicitly setting permissions for security.`
      );
      return;
    }

    const perms = workflow.permissions;

    // Track permission usage
    for (const [perm, level] of Object.entries(perms)) {
      const key = `${perm}: ${level}`;
      this.permissionStats[key] = (this.permissionStats[key] || 0) + 1;
    }
  }

  /**
   * Check job-level permissions
   */
  checkJobPermissions(workflow, _workflowName) {
    if (!workflow.jobs) return;

    for (const [jobName, job] of Object.entries(workflow.jobs)) {
      if (job.permissions) {
        // Job-level permissions override workflow-level
        console.log(`  ℹ️  ${jobName} has custom job-level permissions`);

        for (const [perm, level] of Object.entries(job.permissions)) {
          const key = `${perm}: ${level}`;
          this.permissionStats[key] = (this.permissionStats[key] || 0) + 1;
        }
      }
    }
  }

  /**
   * Check for dangerous permission combinations
   */
  checkDangerousPermissions(workflow, workflowName) {
    const allPerms = this.extractAllPermissions(workflow);

    for (const dangerous of DANGEROUS_PERMISSIONS) {
      const hasDangerous = dangerous.permissions.every((perm) => allPerms.includes(perm));

      if (hasDangerous) {
        const msg =
          `${workflowName}: ⚠️  DANGEROUS permission combination detected: ${dangerous.permissions.join(', ')}\n` +
          `  Reason: ${dangerous.reason}\n` +
          `  Severity: ${dangerous.severity.toUpperCase()}`;

        if (dangerous.severity === 'critical') {
          this.errors.push(msg);
        } else {
          this.warnings.push(msg);
        }
      }
    }
  }

  /**
   * Check required permissions for workflow type
   */
  checkRequiredPermissions(workflow, workflowName) {
    const required = WORKFLOW_PERMISSION_REQUIREMENTS[workflowName];
    if (!required) return;

    const actualPerms = this.extractAllPermissions(workflow);

    for (const requiredPerm of required) {
      if (!actualPerms.includes(requiredPerm)) {
        this.errors.push(`${workflowName}: Missing required permission "${requiredPerm}"`);
      }
    }
  }

  /**
   * Check least-privilege principle
   */
  checkLeastPrivilege(workflow, workflowName) {
    const allPerms = this.extractAllPermissions(workflow);

    // Check for overly broad 'write' permissions
    const writePerms = allPerms.filter((p) => p.includes('write'));

    if (writePerms.length > 3) {
      this.warnings.push(
        `${workflowName}: Has ${writePerms.length} write permissions. Consider if all are necessary: ${writePerms.join(', ')}`
      );
    }

    // Check for workflows with actions: write (rarely needed)
    if (allPerms.includes('actions: write')) {
      this.warnings.push(
        `${workflowName}: Has 'actions: write' permission. This is rarely needed and potentially dangerous.`
      );
    }

    // Check for workflows with packages: write (should be limited)
    if (allPerms.includes('packages: write')) {
      this.warnings.push(
        `${workflowName}: Has 'packages: write' permission. Ensure this is necessary for package publishing.`
      );
    }
  }

  /**
   * Extract all permissions from workflow (workflow-level and job-level)
   */
  extractAllPermissions(workflow) {
    const perms = new Set();

    // Workflow-level permissions
    if (workflow.permissions) {
      for (const [perm, level] of Object.entries(workflow.permissions)) {
        perms.add(`${perm}: ${level}`);
      }
    }

    // Job-level permissions
    if (workflow.jobs) {
      for (const job of Object.values(workflow.jobs)) {
        if (job.permissions) {
          for (const [perm, level] of Object.entries(job.permissions)) {
            perms.add(`${perm}: ${level}`);
          }
        }
      }
    }

    return Array.from(perms);
  }

  /**
   * Print validation results
   */
  printResults() {
    console.log('\n' + '='.repeat(60));
    console.log('🔒 PERMISSION VALIDATION RESULTS');
    console.log('='.repeat(60));

    console.log(`\n✅ Workflows checked: ${this.workflowsChecked}`);

    // Print permission usage statistics
    if (Object.keys(this.permissionStats).length > 0) {
      console.log('\n📊 Permission Usage Statistics:');
      const sorted = Object.entries(this.permissionStats).sort((a, b) => b[1] - a[1]);
      for (const [perm, count] of sorted) {
        console.log(`  ${perm.padEnd(30)} → ${count} workflow(s)`);
      }
    }

    if (this.warnings.length > 0) {
      console.log(`\n⚠️  Warnings (${this.warnings.length}):`);
      this.warnings.forEach((warning) => console.log(`  - ${warning}`));
    }

    if (this.errors.length > 0) {
      console.log(`\n❌ Errors (${this.errors.length}):`);
      this.errors.forEach((error) => console.log(`  - ${error}`));
      console.log('\n');
      return false;
    }

    if (this.warnings.length === 0 && this.errors.length === 0) {
      console.log('\n✨ All permission checks passed!');
    }

    console.log('');
    return true;
  }
}

/**
 * Main execution
 */
async function main() {
  const args = process.argv.slice(2);
  const validator = new PermissionValidator();

  try {
    if (args.includes('--all')) {
      // Check all workflow files
      const workflowDir = '.github/workflows';
      const files = await readdir(workflowDir);

      for (const file of files) {
        if (file.endsWith('.yml') || file.endsWith('.yaml')) {
          await validator.validateWorkflow(join(workflowDir, file));
        }
      }
    } else if (args.length > 0) {
      // Check specific workflow file
      await validator.validateWorkflow(args[0]);
    } else {
      console.error('Usage: check-permissions.mjs [workflow-file] | --all');
      process.exit(2);
    }

    const success = validator.printResults();
    process.exit(success ? 0 : 1);
  } catch (error) {
    console.error(`\n❌ Script error: ${error.message}`);
    console.error(error.stack);
    process.exit(2);
  }
}

main();
