/**
 * String Utility Functions
 * Handles URL parsing, markdown extraction, text manipulation
 *
 * Part of P2.1 validation logic extraction from workflows.
 * Provides reusable string operations for workflow scripts.
 */

/**
 * Parses a GitHub URL into its components
 *
 * @param {string} url - GitHub URL to parse
 * @returns {object} Parsed URL components with validation status
 *
 * @example
 * parseGitHubURL('https://github.com/owner/repo/issues/123')
 * // { owner: 'owner', repo: 'repo', type: 'issue', number: 123, valid: true }
 */
export function parseGitHubURL(url) {
  if (!url || typeof url !== 'string') {
    return { valid: false };
  }

  try {
    const urlObj = new URL(url);

    if (urlObj.hostname !== 'github.com') {
      return { valid: false };
    }

    // Match repository URL: /owner/repo
    const repoPattern = /^\/([^/]+)\/([^/]+)\/?$/;
    const repoMatch = urlObj.pathname.match(repoPattern);

    if (repoMatch) {
      return {
        owner: repoMatch[1],
        repo: repoMatch[2],
        type: 'repo',
        valid: true
      };
    }

    // Match issue/pull URL: /owner/repo/issues|pull/number
    const issuePattern = /^\/([^/]+)\/([^/]+)\/(issues|pull)\/(\d+)/;
    const issueMatch = urlObj.pathname.match(issuePattern);

    if (issueMatch) {
      return {
        owner: issueMatch[1],
        repo: issueMatch[2],
        type: issueMatch[3] === 'issues' ? 'issue' : 'pull',
        number: parseInt(issueMatch[4], 10),
        valid: true
      };
    }

    return { valid: false };
  } catch (error) {
    return { valid: false };
  }
}

/**
 * Extracts a markdown section by heading name
 * Returns content from heading until next same-level heading
 *
 * @param {string} markdown - Markdown text
 * @param {string} sectionName - Heading name to find
 * @returns {string|null} Section content or null if not found
 *
 * @example
 * extractMarkdownSection('## Title\nContent\n## Next', 'Title')
 * // 'Content\n'
 */
export function extractMarkdownSection(markdown, sectionName) {
  if (!markdown || !sectionName) {
    return null;
  }

  // Find the section heading (case-insensitive, flexible heading level)
  // Allow markdown formatting in heading (**, *, etc.)
  const escapedName = escapeRegex(sectionName);
  const headingPattern = new RegExp(`^(#{1,6})\\s+(?:\\*\\*)?${escapedName}(?:\\*\\*)?\\s*$`, 'im');
  const match = markdown.match(headingPattern);

  if (!match) {
    return null;
  }

  const headingLevel = match[1].length;
  const startIndex = match.index + match[0].length;

  // Find the next heading of same or higher level
  const nextHeadingPattern = new RegExp(`^#{1,${headingLevel}}\\s+`, 'm');
  const remainingText = markdown.substring(startIndex);
  const nextHeadingMatch = remainingText.match(nextHeadingPattern);

  if (nextHeadingMatch) {
    return remainingText.substring(0, nextHeadingMatch.index).trim();
  } else {
    return remainingText.trim();
  }
}

/**
 * Truncates text to specified length with suffix
 *
 * @param {string} text - Text to truncate
 * @param {number} maxLength - Maximum length (excluding suffix)
 * @param {string} suffix - Suffix to add (default: '...')
 * @returns {string} Truncated text
 *
 * @example
 * truncateText('Long text here', 8) // 'Long tex...'
 */
export function truncateText(text, maxLength, suffix = '...') {
  if (!text) {
    return '';
  }

  if (text.length <= maxLength) {
    return text;
  }

  return text.substring(0, maxLength) + suffix;
}

/**
 * Counts lines in text
 *
 * @param {string} text - Text to count lines in
 * @returns {number} Number of lines
 *
 * @example
 * countLines('Line 1\nLine 2\nLine 3') // 3
 */
export function countLines(text) {
  if (!text || text === '') {
    return 0;
  }

  // Handle different line endings: \n, \r\n, \r
  const lines = text.split(/\r\n|\r|\n/);

  return lines.length;
}

/**
 * Sanitizes filename by removing invalid characters
 *
 * @param {string} filename - Filename to sanitize
 * @returns {string} Sanitized filename
 *
 * @example
 * sanitizeFilename('file<name>.txt') // 'filename.txt'
 */
export function sanitizeFilename(filename) {
  if (!filename || filename.trim() === '') {
    return 'file';
  }

  // Remove invalid characters: < > : " / \ | ? *
  let sanitized = filename.replace(/[<>:"/\\|?*]/g, '');

  // Replace spaces with underscores
  sanitized = sanitized.replace(/\s+/g, '_');

  // Ensure it's not empty after sanitization
  if (sanitized.trim() === '') {
    return 'file';
  }

  return sanitized;
}

/**
 * Normalizes whitespace in text
 * Collapses multiple spaces, trims, converts tabs/newlines to spaces
 *
 * @param {string} text - Text to normalize
 * @returns {string} Normalized text
 *
 * @example
 * normalizeWhitespace('Text  with    spaces') // 'Text with spaces'
 */
export function normalizeWhitespace(text) {
  if (!text) {
    return '';
  }

  // Replace tabs and newlines with spaces
  let normalized = text.replace(/[\t\n\r]+/g, ' ');

  // Collapse multiple spaces
  normalized = normalized.replace(/\s+/g, ' ');

  // Trim leading/trailing whitespace
  return normalized.trim();
}

/**
 * Removes markdown formatting from text
 *
 * @param {string} text - Text with markdown formatting
 * @returns {string} Plain text
 *
 * @example
 * removeMarkdownFormatting('**bold** text') // 'bold text'
 */
export function removeMarkdownFormatting(text) {
  if (!text) {
    return '';
  }

  let result = text;

  // Remove headings (# ## ###)
  result = result.replace(/^#{1,6}\s+/gm, '');

  // Remove bold (**text** or __text__)
  result = result.replace(/(\*\*|__)(.*?)\1/g, '$2');

  // Remove italic (*text* or _text_)
  result = result.replace(/(\*|_)(.*?)\1/g, '$2');

  // Remove links [text](url)
  result = result.replace(/\[([^\]]+)\]\([^)]+\)/g, '$1');

  // Remove inline code (`code`)
  result = result.replace(/`([^`]+)`/g, '$1');

  // Remove code blocks (```code```)
  result = result.replace(/```[\s\S]*?```/g, '');

  return result;
}

/**
 * Extracts all URLs from text
 *
 * @param {string} text - Text containing URLs
 * @returns {string[]} Array of URLs
 *
 * @example
 * extractUrls('Visit https://example.com and http://test.org')
 * // ['https://example.com', 'http://test.org']
 */
export function extractUrls(text) {
  if (!text) {
    return [];
  }

  // Match http:// and https:// URLs
  const urlPattern = /https?:\/\/[^\s]+/g;
  const matches = text.match(urlPattern);

  return matches || [];
}

/**
 * Checks if string is a valid URL
 *
 * @param {string} str - String to check
 * @returns {boolean} True if valid URL
 *
 * @example
 * isValidUrl('https://example.com') // true
 * isValidUrl('not a url') // false
 */
export function isValidUrl(str) {
  if (!str || typeof str !== 'string' || str === '') {
    return false;
  }

  try {
    const url = new URL(str);
    return url.protocol === 'http:' || url.protocol === 'https:';
  } catch {
    return false;
  }
}

/**
 * Joins path segments with forward slashes
 * Handles leading/trailing slashes properly
 *
 * @param {...string} segments - Path segments to join
 * @returns {string} Joined path
 *
 * @example
 * joinPaths('path', 'to', 'file.txt') // 'path/to/file.txt'
 * joinPaths('/root', 'sub', 'file.txt') // '/root/sub/file.txt'
 */
export function joinPaths(...segments) {
  if (segments.length === 0) {
    return '';
  }

  // Filter out empty segments
  const filtered = segments.filter(s => s && s !== '');

  if (filtered.length === 0) {
    return '';
  }

  // Check if first segment starts with /
  const isAbsolute = filtered[0].startsWith('/');

  // Remove leading/trailing slashes from all segments
  const cleaned = filtered.map(s => s.replace(/^\/+|\/+$/g, ''));

  // Join with /
  const joined = cleaned.join('/');

  // Add leading / if original was absolute
  return isAbsolute ? '/' + joined : joined;
}

/**
 * Gets file extension from filename or path
 *
 * @param {string} filename - Filename or path
 * @returns {string} File extension (including dot) or empty string
 *
 * @example
 * getFileExtension('file.txt') // '.txt'
 * getFileExtension('README') // ''
 */
export function getFileExtension(filename) {
  if (!filename) {
    return '';
  }

  // Get basename (last part of path)
  const basename = filename.split('/').pop();

  // Hidden files like .gitignore have no extension
  if (basename.startsWith('.') && basename.indexOf('.', 1) === -1) {
    return '';
  }

  const lastDot = basename.lastIndexOf('.');

  if (lastDot === -1 || lastDot === 0) {
    return '';
  }

  return basename.substring(lastDot);
}

/**
 * Removes file extension from filename or path
 *
 * @param {string} filename - Filename or path
 * @returns {string} Filename without extension
 *
 * @example
 * removeFileExtension('file.txt') // 'file'
 * removeFileExtension('/path/to/file.mjs') // '/path/to/file'
 */
export function removeFileExtension(filename) {
  if (!filename) {
    return '';
  }

  const ext = getFileExtension(filename);

  if (!ext) {
    return filename;
  }

  return filename.substring(0, filename.length - ext.length);
}

/**
 * Converts string to kebab-case
 *
 * @param {string} str - String to convert
 * @returns {string} kebab-case string
 *
 * @example
 * toKebabCase('HelloWorld') // 'hello-world'
 * toKebabCase('hello_world') // 'hello-world'
 */
export function toKebabCase(str) {
  if (!str) {
    return '';
  }

  return str
    // Insert hyphen before uppercase letters
    .replace(/([a-z])([A-Z])/g, '$1-$2')
    // Replace spaces and underscores with hyphens
    .replace(/[\s_]+/g, '-')
    // Convert to lowercase
    .toLowerCase()
    // Remove multiple consecutive hyphens
    .replace(/-+/g, '-')
    // Remove leading/trailing hyphens
    .replace(/^-+|-+$/g, '');
}

/**
 * Converts string to camelCase
 *
 * @param {string} str - String to convert
 * @returns {string} camelCase string
 *
 * @example
 * toCamelCase('hello-world') // 'helloWorld'
 * toCamelCase('hello_world') // 'helloWorld'
 */
export function toCamelCase(str) {
  if (!str) {
    return '';
  }

  // Check if already camelCase (no delimiters and has uppercase letters)
  if (!/[-_\s]/.test(str) && /[a-z]/.test(str) && /[A-Z]/.test(str)) {
    return str;
  }

  return str
    // Split on hyphens, underscores, or spaces
    .split(/[-_\s]+/)
    // Capitalize first letter of each word except first
    .map((word, index) => {
      if (index === 0) {
        return word.toLowerCase();
      }
      return word.charAt(0).toUpperCase() + word.slice(1).toLowerCase();
    })
    .join('');
}

/**
 * Capitalizes first letter of string
 *
 * @param {string} str - String to capitalize
 * @returns {string} Capitalized string
 *
 * @example
 * capitalize('hello') // 'Hello'
 */
export function capitalize(str) {
  if (!str || str.length === 0) {
    return str;
  }

  return str.charAt(0).toUpperCase() + str.slice(1);
}

/**
 * Helper: Escapes special regex characters in a string
 *
 * @param {string} str - String to escape
 * @returns {string} Escaped string
 * @private
 */
function escapeRegex(str) {
  return str.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
}
