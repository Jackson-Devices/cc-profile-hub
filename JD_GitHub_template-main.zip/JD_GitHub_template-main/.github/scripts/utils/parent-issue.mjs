/**
 * Parent Issue Fetching and Validation Functions
 * Handles parent issue URL parsing, validation, and relationship checking
 *
 * Part of P2.1 validation logic extraction from workflows.
 * Enables testable, reusable parent issue operations.
 */

import { extractYAMLFromIssue } from './yaml-parser.mjs';

/**
 * Parses a GitHub issue URL into its components
 *
 * @param {string} url - GitHub issue URL to parse
 * @returns {Object} Parsed components with validation status
 * @returns {string} returns.owner - Repository owner
 * @returns {string} returns.repo - Repository name
 * @returns {number} returns.issue_number - Issue number
 * @returns {boolean} returns.valid - Whether URL is valid
 *
 * @example
 * parseParentIssueURL('https://github.com/owner/repo/issues/123')
 * // Returns: { owner: 'owner', repo: 'repo', issue_number: 123, valid: true }
 */
export function parseParentIssueURL(url) {
  if (!url || typeof url !== 'string') {
    return { valid: false };
  }

  try {
    // Parse URL and check it's github.com
    const urlObj = new URL(url);

    if (urlObj.hostname !== 'github.com') {
      return { valid: false };
    }

    // Extract path components: /owner/repo/issues/number
    const pathPattern = /^\/([^/]+)\/([^/]+)\/issues\/(\d+)/;
    const match = urlObj.pathname.match(pathPattern);

    if (!match) {
      return { valid: false };
    }

    const [, owner, repo, issueNumberStr] = match;
    const issue_number = parseInt(issueNumberStr, 10);

    if (isNaN(issue_number) || issue_number <= 0) {
      return { valid: false };
    }

    return {
      owner,
      repo,
      issue_number,
      valid: true
    };
  } catch (error) {
    // Invalid URL format
    return { valid: false };
  }
}

/**
 * Validates that a string is a valid GitHub issue URL
 *
 * @param {string} url - URL to validate
 * @returns {boolean} True if valid GitHub issue URL
 *
 * @example
 * validateParentIssueURL('https://github.com/owner/repo/issues/123') // true
 * validateParentIssueURL('https://github.com/owner/repo/pull/123')   // false
 */
export function validateParentIssueURL(url) {
  const parsed = parseParentIssueURL(url);
  return parsed.valid === true;
}

/**
 * Extracts parent_issue URL from issue body YAML frontmatter
 *
 * @param {string} issueBody - Issue body text with YAML frontmatter
 * @returns {string|null} Parent issue URL or null if not present
 *
 * @example
 * const body = `---
 * parent_issue: https://github.com/org/repo/issues/1
 * ---
 * Content`;
 * extractParentIssueURL(body) // 'https://github.com/org/repo/issues/1'
 */
export function extractParentIssueURL(issueBody) {
  if (!issueBody || typeof issueBody !== 'string') {
    return null;
  }

  const yaml = extractYAMLFromIssue(issueBody);

  if (!yaml || !yaml.parent_issue) {
    return null;
  }

  const parentIssue = yaml.parent_issue;

  // Handle empty or whitespace-only values
  if (typeof parentIssue !== 'string' || parentIssue.trim() === '') {
    return null;
  }

  return parentIssue.trim();
}

/**
 * Validates parent-child relationship for max pass enforcement
 * Checks that combined AI passes don't exceed parent's max_ai_passes
 *
 * @param {Object} parentYAML - Parent issue YAML data
 * @param {Object} childYAML - Child issue YAML data
 * @returns {Object} Validation result
 * @returns {boolean} returns.valid - Whether relationship is valid
 * @returns {string[]} returns.errors - Array of error messages
 * @returns {number} returns.total_passes - Combined pass count
 *
 * @example
 * validateParentChildRelationship(
 *   { ai_pass_count: 2, max_ai_passes: 5 },
 *   { ai_pass_count: 1 }
 * ) // { valid: true, errors: [], total_passes: 3 }
 */
export function validateParentChildRelationship(parentYAML, childYAML) {
  const errors = [];

  // Validate parent has max_ai_passes
  if (!parentYAML || typeof parentYAML.max_ai_passes !== 'number') {
    errors.push('Parent issue must have max_ai_passes defined');
    return { valid: false, errors, total_passes: 0 };
  }

  // Get pass counts (default to 0 if missing)
  const parentPasses = typeof parentYAML.ai_pass_count === 'number'
    ? parentYAML.ai_pass_count
    : 0;

  const childPasses = typeof childYAML.ai_pass_count === 'number'
    ? childYAML.ai_pass_count
    : 0;

  const totalPasses = parentPasses + childPasses;
  const maxPasses = parentYAML.max_ai_passes;

  // Check if parent has already reached max
  if (parentPasses >= maxPasses) {
    errors.push(
      `Parent issue has reached max_ai_passes (${parentPasses}/${maxPasses}). ` +
      'Cannot create or update child issue.'
    );
  }

  // Check if combined passes exceed max
  if (totalPasses > maxPasses) {
    errors.push(
      `Combined AI passes (${totalPasses}) exceeds parent max_ai_passes (${maxPasses}). ` +
      `Parent: ${parentPasses}, Child: ${childPasses}.`
    );
  }

  return {
    valid: errors.length === 0,
    errors,
    total_passes: totalPasses
  };
}

/**
 * Checks if a value is a valid GitHub issue URL
 * More strict than validateParentIssueURL - checks type and format
 *
 * @param {*} value - Value to check
 * @returns {boolean} True if valid GitHub issue URL
 *
 * @example
 * isValidGitHubIssueURL('https://github.com/owner/repo/issues/123') // true
 * isValidGitHubIssueURL(null) // false
 * isValidGitHubIssueURL(123) // false
 */
export function isValidGitHubIssueURL(value) {
  if (typeof value !== 'string') {
    return false;
  }

  // Must start with http:// or https://
  if (!value.startsWith('http://') && !value.startsWith('https://')) {
    return false;
  }

  // Parse and validate
  const parsed = parseParentIssueURL(value);
  return parsed.valid === true;
}

/**
 * Formats a GitHub issue URL from components
 *
 * @param {string} owner - Repository owner
 * @param {string} repo - Repository name
 * @param {number|string} issueNumber - Issue number
 * @returns {string} Formatted GitHub issue URL
 * @throws {Error} If any parameter is invalid
 *
 * @example
 * formatParentIssueURL('owner', 'repo', 123)
 * // 'https://github.com/owner/repo/issues/123'
 */
export function formatParentIssueURL(owner, repo, issueNumber) {
  // Validate owner
  if (!owner || typeof owner !== 'string' || owner.trim() === '') {
    throw new Error('Owner is required and must be a non-empty string');
  }

  // Validate repo
  if (!repo || typeof repo !== 'string' || repo.trim() === '') {
    throw new Error('Repo is required and must be a non-empty string');
  }

  // Validate and parse issue number
  const issueNum = typeof issueNumber === 'string'
    ? parseInt(issueNumber, 10)
    : issueNumber;

  if (typeof issueNum !== 'number' || isNaN(issueNum) || issueNum <= 0) {
    throw new Error(
      'Invalid issue number: must be a positive integer'
    );
  }

  return `https://github.com/${owner.trim()}/${repo.trim()}/issues/${issueNum}`;
}
