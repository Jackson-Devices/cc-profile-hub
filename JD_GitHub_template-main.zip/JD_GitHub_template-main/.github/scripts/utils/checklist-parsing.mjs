/**
 * Test Case Checklist Parsing Functions
 * Handles Run checklist extraction, parsing, ordering, and manipulation
 *
 * Part of P2.1 validation logic extraction from workflows.
 * Provides pure functions for checklist operations.
 */

/**
 * Checks if issue body contains a Run checklist section
 *
 * @param {string} body - Issue body text
 * @returns {boolean} True if Run checklist exists
 *
 * @example
 * hasRunChecklist('### Run checklist\n- [ ] OOB-01') // true
 */
export function hasRunChecklist(body) {
  if (!body || typeof body !== 'string') {
    return false;
  }

  const pattern = /#{2,3}\s*run\s+checklist\b/i;
  return pattern.test(body);
}

/**
 * Parses Run checklist from issue body
 * Returns structured data with checked status
 *
 * @param {string} body - Issue body text
 * @returns {Array<{id: string, checked: boolean}>} Checklist items
 *
 * @example
 * parseRunChecklist('### Run checklist\n- [x] OOB-01\n- [ ] IB-01')
 * // [{ id: 'OOB-01', checked: true }, { id: 'IB-01', checked: false }]
 */
export function parseRunChecklist(body) {
  if (!body || typeof body !== 'string') {
    return [];
  }

  if (!hasRunChecklist(body)) {
    return [];
  }

  // Find the Run checklist section
  const checklistPattern = /#{2,3}\s*run\s+checklist\b/i;
  const match = body.match(checklistPattern);

  if (!match) {
    return [];
  }

  // Get text after "Run checklist" heading
  const startIndex = match.index + match[0].length;
  let checklistText = body.substring(startIndex);

  // Stop at next heading (##, ###, etc.)
  const nextHeadingMatch = checklistText.match(/\n#{2,}/);
  if (nextHeadingMatch) {
    checklistText = checklistText.substring(0, nextHeadingMatch.index);
  }

  // Extract checklist items
  const items = extractChecklistItems(checklistText);

  // Filter to only test case items (IB-NN or OOB-NN)
  const testCasePattern = /\b(IB|OOB)-(\d{2})\b/i;

  return items
    .filter(item => testCasePattern.test(item.text))
    .map(item => {
      const match = item.text.match(testCasePattern);
      return {
        id: match[0].toUpperCase(),
        checked: item.checked
      };
    });
}

/**
 * Extracts all checkbox items from markdown text
 *
 * @param {string} text - Markdown text with checkboxes
 * @returns {Array<{checked: boolean, text: string}>} Checkbox items
 *
 * @example
 * extractChecklistItems('- [ ] Item 1\n- [x] Item 2')
 * // [{ checked: false, text: 'Item 1' }, { checked: true, text: 'Item 2' }]
 */
export function extractChecklistItems(text) {
  if (!text || typeof text !== 'string') {
    return [];
  }

  const items = [];
  const pattern = /^[\s]*-\s*\[([x ])\]\s*(.+)$/gim;
  let match;

  while ((match = pattern.exec(text)) !== null) {
    items.push({
      checked: match[1].toLowerCase() === 'x',
      text: match[2].trim()
    });
  }

  return items;
}

/**
 * Counts checklist progress (completed vs total)
 *
 * @param {Array<{checked: boolean}>} items - Checklist items
 * @returns {{completed: number, total: number, percentage: number}}
 *
 * @example
 * countChecklistProgress([{ checked: true }, { checked: false }])
 * // { completed: 1, total: 2, percentage: 50 }
 */
export function countChecklistProgress(items) {
  if (!Array.isArray(items) || items.length === 0) {
    return {
      completed: 0,
      total: 0,
      percentage: 0
    };
  }

  const total = items.length;
  const completed = items.filter(item => item.checked).length;
  const percentage = Math.round((completed / total) * 100);

  return {
    completed,
    total,
    percentage
  };
}

/**
 * Orders test cases according to seed-test-runlist rules:
 * OOB-01 → IB-01 → OOB-02 → [remaining OOBs ascending] → [remaining IBs ascending]
 *
 * @param {string[]} testCases - Array of test case IDs (e.g., ['IB-01', 'OOB-01'])
 * @returns {string[]} Ordered test case IDs
 *
 * @example
 * orderTestCases(['IB-01', 'IB-02', 'OOB-01', 'OOB-02', 'OOB-03'])
 * // ['OOB-01', 'IB-01', 'OOB-02', 'OOB-03', 'IB-02']
 */
export function orderTestCases(testCases) {
  if (!Array.isArray(testCases) || testCases.length === 0) {
    return [];
  }

  // Separate IB and OOB cases
  const ibCases = testCases.filter(id => id.startsWith('IB-')).sort((a, b) => {
    const numA = parseInt(a.split('-')[1], 10);
    const numB = parseInt(b.split('-')[1], 10);
    return numA - numB;
  });

  const oobCases = testCases.filter(id => id.startsWith('OOB-')).sort((a, b) => {
    const numA = parseInt(a.split('-')[1], 10);
    const numB = parseInt(b.split('-')[1], 10);
    return numA - numB;
  });

  // Check if we have enough for the special ordering rule
  if (oobCases.length >= 2 && ibCases.length >= 1) {
    // OOB-01 → IB-01 → OOB-02 → [remaining OOBs] → [remaining IBs]
    return [
      oobCases[0],
      ibCases[0],
      oobCases[1],
      ...oobCases.slice(2),
      ...ibCases.slice(1)
    ];
  } else {
    // Fallback: all OOBs then all IBs, ascending
    return [...oobCases, ...ibCases];
  }
}

/**
 * Builds markdown Run checklist from ordered test cases
 *
 * @param {string[]} orderedCases - Ordered test case IDs
 * @returns {string} Markdown checklist
 *
 * @example
 * buildRunChecklist(['OOB-01', 'IB-01'])
 * // '### Run checklist\n- [ ] OOB-01\n- [ ] IB-01\n'
 */
export function buildRunChecklist(orderedCases) {
  if (!Array.isArray(orderedCases)) {
    orderedCases = [];
  }

  const heading = '### Run checklist\n';
  const items = orderedCases.map(id => `- [ ] ${id}`).join('\n');

  if (items) {
    return `${heading}${items}\n`;
  } else {
    return heading;
  }
}

/**
 * Updates a checklist item's checked status
 * Returns new body text with updated checkbox
 *
 * @param {string} body - Issue body text
 * @param {string} testCaseId - Test case ID to update (e.g., 'OOB-01')
 * @param {boolean} checked - Whether to check or uncheck
 * @returns {string} Updated body text
 *
 * @example
 * updateChecklistItem(body, 'OOB-01', true)
 * // Changes '- [ ] OOB-01' to '- [x] OOB-01'
 */
export function updateChecklistItem(body, testCaseId, checked) {
  if (!body || typeof body !== 'string') {
    return body;
  }

  const checkbox = checked ? 'x' : ' ';

  // Match checkbox item with the specific test case ID
  // Must handle: - [ ] OOB-01 or - [x] OOB-01 or - [X] OOB-01
  // And preserve any description after the ID
  const pattern = new RegExp(
    `^(\\s*-\\s*)\\[[xX ]\\](\\s*${testCaseId}\\b.*)$`,
    'gm'
  );

  const updatedBody = body.replace(pattern, `$1[${checkbox}]$2`);

  return updatedBody;
}

/**
 * Extracts IDs of completed (checked) test cases from checklist
 *
 * @param {string} body - Issue body text
 * @returns {string[]} Array of completed test case IDs
 *
 * @example
 * extractCompletedTestCases('- [x] OOB-01\n- [ ] IB-01')
 * // ['OOB-01']
 */
export function extractCompletedTestCases(body) {
  if (!body || typeof body !== 'string') {
    return [];
  }

  const items = parseRunChecklist(body);
  return items
    .filter(item => item.checked)
    .map(item => item.id);
}

/**
 * Validates checklist format
 * Checks for proper heading, test case IDs, duplicates
 *
 * @param {string} body - Issue body text
 * @returns {{valid: boolean, errors: string[]}}
 *
 * @example
 * validateChecklistFormat('### Run checklist\n- [ ] OOB-01')
 * // { valid: true, errors: [] }
 */
export function validateChecklistFormat(body) {
  const errors = [];

  if (!body || typeof body !== 'string') {
    return { valid: true, errors: [] }; // No body is valid
  }

  // Check if there are checkbox items that look like test cases
  const testCasePattern = /\b(IB|OOB)-(\d{2})\b/i;
  const checkboxPattern = /^[\s]*-\s*\[([x ])\]\s*(.+)$/gim;
  const checkboxItems = [...body.matchAll(checkboxPattern)];

  const hasTestCaseCheckboxes = checkboxItems.some(match =>
    testCasePattern.test(match[2])
  );

  // If there are test case checkboxes but no Run checklist heading, error
  if (hasTestCaseCheckboxes && !hasRunChecklist(body)) {
    errors.push('Found test case checkboxes but missing "Run checklist" heading');
    return { valid: false, errors };
  }

  // If no checklist heading, that's valid (optional)
  if (!hasRunChecklist(body)) {
    return { valid: true, errors: [] };
  }

  // Get all checkbox items in the Run checklist section
  const checklistPattern = /#{2,3}\s*run\s+checklist\b/i;
  const match = body.match(checklistPattern);

  if (match) {
    const startIndex = match.index + match[0].length;
    let checklistText = body.substring(startIndex);

    // Stop at next heading
    const nextHeadingMatch = checklistText.match(/\n#{2,}/);
    if (nextHeadingMatch) {
      checklistText = checklistText.substring(0, nextHeadingMatch.index);
    }

    // Extract all checkbox items (not just valid ones)
    const allItems = extractChecklistItems(checklistText);

    // Check if checklist is empty
    if (allItems.length === 0) {
      errors.push('Run checklist is empty or contains no valid test cases');
    }

    // Validate each item
    const validPattern = /^(IB|OOB)-\d{2}$/;
    const seenIds = new Set();

    // Pattern to catch anything that looks like it might be a test case ID
    const likelyTestCasePattern = /\b([A-Z]+)-(\d+)\b/i;

    for (const item of allItems) {
      // First check for valid test case pattern
      const validMatch = item.text.match(testCasePattern);

      if (validMatch) {
        const testCaseId = validMatch[0].toUpperCase();

        // Check format
        if (!validPattern.test(testCaseId)) {
          errors.push(`Invalid test case ID format: ${testCaseId}`);
        }

        // Check for duplicates
        if (seenIds.has(testCaseId)) {
          errors.push(`duplicate test case in checklist: ${testCaseId}`);
        }
        seenIds.add(testCaseId);
      } else {
        // Check if it looks like a test case but isn't valid IB/OOB
        const likelyMatch = item.text.match(likelyTestCasePattern);
        if (likelyMatch) {
          const likelyId = likelyMatch[0];
          // Only flag if it looks intentional (starts with uppercase letter)
          if (/^[A-Z]+-\d+$/.test(likelyId)) {
            errors.push(`Invalid test case ID format: ${likelyId}`);
          }
        }
      }
    }
  }

  return {
    valid: errors.length === 0,
    errors
  };
}
