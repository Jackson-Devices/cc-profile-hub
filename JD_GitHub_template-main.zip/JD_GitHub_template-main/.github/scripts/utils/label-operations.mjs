/**
 * Label Operations Functions
 * Handles label manipulation, validation, and calculation
 *
 * Part of P2.1 validation logic extraction from workflows.
 * Provides pure functions for label operations (no side effects).
 * Actual GitHub API calls remain in workflows.
 */

/**
 * Calculates new label set after adding and removing labels
 * Pure function - no side effects
 *
 * @param {string[]} currentLabels - Current labels on issue
 * @param {string[]} labelsToAdd - Labels to add
 * @param {string[]} labelsToRemove - Labels to remove
 * @returns {string[]} New label set
 *
 * @example
 * calculateLabelChanges(
 *   ['bug', 'pending'],
 *   ['approved'],
 *   ['pending']
 * ) // ['bug', 'approved']
 */
export function calculateLabelChanges(currentLabels, labelsToAdd = [], labelsToRemove = []) {
  // Remove labels first
  const afterRemoval = currentLabels.filter(label => !labelsToRemove.includes(label));

  // Then add new labels (avoiding duplicates)
  const newLabels = labelsToAdd.filter(label => !afterRemoval.includes(label));

  return [...afterRemoval, ...newLabels];
}

/**
 * Validates a label name
 *
 * GitHub label rules:
 * - Must be non-empty string
 * - Max 50 characters
 * - Cannot be only whitespace
 *
 * @param {*} labelName - Label name to validate
 * @returns {boolean} True if valid
 *
 * @example
 * validateLabelName('bug') // true
 * validateLabelName('') // false
 */
export function validateLabelName(labelName) {
  if (typeof labelName !== 'string') {
    return false;
  }

  const trimmed = labelName.trim();

  if (trimmed === '') {
    return false;
  }

  // GitHub label max length is 50 characters
  if (trimmed.length > 50) {
    return false;
  }

  return true;
}

/**
 * Checks if a label exists in label array
 * Case-sensitive comparison
 *
 * @param {string[]} labels - Array of labels
 * @param {string} labelName - Label to check for
 * @returns {boolean} True if label exists
 *
 * @example
 * hasLabel(['bug', 'priority: high'], 'bug') // true
 * hasLabel(['Bug'], 'bug') // false (case-sensitive)
 */
export function hasLabel(labels, labelName) {
  return labels.includes(labelName);
}

/**
 * Adds labels to label array (avoiding duplicates)
 * Returns new array - does not mutate original
 *
 * @param {string[]} currentLabels - Current labels
 * @param {string[]} labelsToAdd - Labels to add
 * @returns {string[]} New label array with added labels
 *
 * @example
 * addLabels(['bug'], ['enhancement']) // ['bug', 'enhancement']
 * addLabels(['bug'], ['bug']) // ['bug'] (no duplicate)
 */
export function addLabels(currentLabels, labelsToAdd) {
  const newLabels = labelsToAdd.filter(label => !currentLabels.includes(label));
  return [...currentLabels, ...newLabels];
}

/**
 * Removes labels from label array
 * Returns new array - does not mutate original
 *
 * @param {string[]} currentLabels - Current labels
 * @param {string[]} labelsToRemove - Labels to remove
 * @returns {string[]} New label array with labels removed
 *
 * @example
 * removeLabels(['bug', 'enhancement'], ['bug']) // ['enhancement']
 * removeLabels(['bug'], ['enhancement']) // ['bug'] (no error)
 */
export function removeLabels(currentLabels, labelsToRemove) {
  return currentLabels.filter(label => !labelsToRemove.includes(label));
}

/**
 * Toggles a label (add if absent, remove if present)
 * Returns new array - does not mutate original
 *
 * @param {string[]} currentLabels - Current labels
 * @param {string} labelName - Label to toggle
 * @returns {string[]} New label array with label toggled
 *
 * @example
 * toggleLabel(['bug'], 'enhancement') // ['bug', 'enhancement']
 * toggleLabel(['bug', 'enhancement'], 'enhancement') // ['bug']
 */
export function toggleLabel(currentLabels, labelName) {
  if (currentLabels.includes(labelName)) {
    return currentLabels.filter(label => label !== labelName);
  } else {
    return [...currentLabels, labelName];
  }
}

/**
 * Normalizes a label name (trims whitespace)
 * Preserves case and internal whitespace
 *
 * @param {string} labelName - Label name to normalize
 * @returns {string} Normalized label name
 *
 * @example
 * normalizeLabelName('  bug  ') // 'bug'
 * normalizeLabelName('needs review') // 'needs review'
 */
export function normalizeLabelName(labelName) {
  return labelName.trim();
}

/**
 * Gets all labels matching a prefix
 * Case-sensitive comparison
 *
 * @param {string[]} labels - Array of labels
 * @param {string} prefix - Prefix to match
 * @returns {string[]} Labels matching prefix
 *
 * @example
 * getLabelsByPrefix(['Validation: Passed', 'bug'], 'Validation:')
 * // ['Validation: Passed']
 */
export function getLabelsByPrefix(labels, prefix) {
  return labels.filter(label => label.startsWith(prefix));
}

/**
 * Validates an array of labels
 * Checks for:
 * - Invalid label names
 * - Duplicates
 * - Non-string values
 * - Labels with leading/trailing whitespace
 *
 * @param {*[]} labels - Array to validate
 * @returns {Object} Validation result
 * @returns {boolean} returns.valid - Whether array is valid
 * @returns {string[]} returns.errors - Array of error messages
 *
 * @example
 * validateLabelArray(['bug', 'enhancement']) // { valid: true, errors: [] }
 * validateLabelArray(['bug', '']) // { valid: false, errors: [...] }
 */
export function validateLabelArray(labels) {
  const errors = [];

  // Check if it's an array
  if (!Array.isArray(labels)) {
    errors.push('Labels must be an array');
    return { valid: false, errors };
  }

  // Track seen labels for duplicate detection
  const seenLabels = new Set();

  for (let i = 0; i < labels.length; i++) {
    const label = labels[i];

    // Check if label is a string
    if (typeof label !== 'string') {
      errors.push(`Label at index ${i} must be a string, got ${typeof label}`);
      continue;
    }

    // Check for empty labels
    if (label.trim() === '') {
      errors.push(`Label at index ${i} is empty or whitespace-only`);
      continue;
    }

    // Check for leading/trailing whitespace
    if (label !== label.trim()) {
      errors.push(`Label at index ${i} has leading or trailing whitespace: "${label}"`);
    }

    // Check max length
    if (label.trim().length > 50) {
      errors.push(`Label at index ${i} exceeds 50 characters: "${label.trim().substring(0, 20)}..."`);
    }

    // Check for duplicates
    if (seenLabels.has(label)) {
      errors.push(`duplicate label found: "${label}"`);
    }
    seenLabels.add(label);
  }

  return {
    valid: errors.length === 0,
    errors
  };
}
