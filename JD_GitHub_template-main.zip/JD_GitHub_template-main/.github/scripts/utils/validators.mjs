/**
 * IB/OOB Validation Functions
 * Extracted from inline GitHub Actions workflow logic for testability
 *
 * Implements validation for test case format:
 * - IB (In-Bounds): IB-NN: Description
 * - OOB (Out-of-Bounds): OOB-NN: Description
 *
 * Where NN is exactly 2 digits (01-99)
 */

/**
 * Validates IB (In-Bounds) test case format
 *
 * Valid format: IB-NN: Description
 * - NN must be exactly 2 digits (01-99)
 * - Colon and space required
 * - Description must be non-empty
 *
 * @param {string} text - Text to validate
 * @returns {boolean} - True if valid IB format
 *
 * @example
 * validateIBFormat('IB-01: Valid test') // true
 * validateIBFormat('IB-1: Invalid') // false
 * validateIBFormat('IB-001: Invalid') // false
 */
export function validateIBFormat(text) {
  if (typeof text !== 'string') {
    return false;
  }

  // Pattern: IB-<exactly 2 digits>: <non-empty description>
  const pattern = /^IB-\d{2}:\s+\S.*/;
  return pattern.test(text);
}

/**
 * Validates OOB (Out-of-Bounds) test case format
 *
 * Valid format: OOB-NN: Description
 * - NN must be exactly 2 digits (01-99)
 * - Colon and space required
 * - Description must be non-empty
 *
 * @param {string} text - Text to validate
 * @returns {boolean} - True if valid OOB format
 */
export function validateOOBFormat(text) {
  if (typeof text !== 'string') {
    return false;
  }

  // Pattern: OOB-<exactly 2 digits>: <non-empty description>
  const pattern = /^OOB-\d{2}:\s+\S.*/;
  return pattern.test(text);
}

/**
 * Counts valid IB test cases in issue body
 *
 * Only counts unique IB numbers (no duplicates)
 *
 * @param {string} body - Issue body text
 * @returns {number} - Count of unique valid IB cases
 */
export function countIBCases(body) {
  if (!body || typeof body !== 'string') {
    return 0;
  }

  // Match IB cases anywhere in the line (handle indentation)
  const pattern = /^\s*IB-(\d{2}):\s+\S.*/gm;
  const matches = body.matchAll(pattern);

  // Track unique IB numbers to avoid counting duplicates
  const uniqueNumbers = new Set();

  for (const match of matches) {
    uniqueNumbers.add(match[1]); // Add the 2-digit number
  }

  return uniqueNumbers.size;
}

/**
 * Counts valid OOB test cases in issue body
 *
 * Only counts unique OOB numbers (no duplicates)
 *
 * @param {string} body - Issue body text
 * @returns {number} - Count of unique valid OOB cases
 */
export function countOOBCases(body) {
  if (!body || typeof body !== 'string') {
    return 0;
  }

  // Match OOB cases anywhere in the line (handle indentation)
  const pattern = /^\s*OOB-(\d{2}):\s+\S.*/gm;
  const matches = body.matchAll(pattern);

  // Track unique OOB numbers
  const uniqueNumbers = new Set();

  for (const match of matches) {
    uniqueNumbers.add(match[1]);
  }

  return uniqueNumbers.size;
}

/**
 * Checks if minimum test case requirements are met
 *
 * Requirements:
 * - At least 1 IB (In-Bounds) test case
 * - At least 1 OOB (Out-of-Bounds) test case
 *
 * @param {number} ibCount - Count of IB cases
 * @param {number} oobCount - Count of OOB cases
 * @returns {Object} - { valid: boolean, errors: string[] }
 */
export function checkMinimumRequirements(ibCount, oobCount) {
  const errors = [];

  if (ibCount < 1) {
    errors.push(`Insufficient IB (In-Bounds) test cases. Found: ${ibCount}, Required: at least 1`);
  }

  if (oobCount < 1) {
    errors.push(`Insufficient OOB (Out-of-Bounds) test cases. Found: ${oobCount}, Required: at least 1`);
  }

  return {
    valid: errors.length === 0,
    errors
  };
}

/**
 * Extracts all test cases from issue body
 *
 * Returns structured data for both IB and OOB cases
 *
 * @param {string} body - Issue body text
 * @returns {Object} - { ib: Array, oob: Array }
 */
export function extractTestCases(body) {
  if (!body || typeof body !== 'string') {
    return { ib: [], oob: [] };
  }

  const ib = [];
  const oob = [];

  // Extract IB cases (handle indentation)
  const ibPattern = /^\s*(IB-\d{2}):\s+(.+)$/gm;
  let match;

  while ((match = ibPattern.exec(body)) !== null) {
    ib.push({
      id: match[1],
      description: match[2],
      fullText: match[0].trim(),
      type: 'IB'
    });
  }

  // Extract OOB cases (handle indentation)
  const oobPattern = /^\s*(OOB-\d{2}):\s+(.+)$/gm;

  while ((match = oobPattern.exec(body)) !== null) {
    oob.push({
      id: match[1],
      description: match[2],
      fullText: match[0].trim(),
      type: 'OOB'
    });
  }

  return { ib, oob };
}

/**
 * Parses a single test case string
 *
 * Extracts structured information from IB or OOB case
 *
 * @param {string} text - Test case text (e.g., "IB-01: Description")
 * @returns {Object|null} - Parsed test case or null if invalid
 */
export function parseTestCase(text) {
  if (!text || typeof text !== 'string') {
    return null;
  }

  // Try IB format
  const ibMatch = text.match(/^(IB)-(\d{2}):\s+(.+)$/s);
  if (ibMatch) {
    return {
      type: 'IB',
      number: ibMatch[2],
      id: `IB-${ibMatch[2]}`,
      description: ibMatch[3],
      fullText: text
    };
  }

  // Try OOB format
  const oobMatch = text.match(/^(OOB)-(\d{2}):\s+(.+)$/s);
  if (oobMatch) {
    return {
      type: 'OOB',
      number: oobMatch[2],
      id: `OOB-${oobMatch[2]}`,
      description: oobMatch[3],
      fullText: text
    };
  }

  return null;
}
