/**
 * YAML Parsing Functions
 * Extracted from inline GitHub Actions workflow logic for testability
 *
 * Handles YAML frontmatter in GitHub issue bodies:
 * ---
 * key: value
 * ---
 * Issue content
 *
 * Uses js-yaml library for parsing/stringifying
 */

import yaml from 'js-yaml';

/**
 * Extracts YAML frontmatter from issue body
 *
 * Parses YAML between --- markers at the start of the issue body
 *
 * @param {string} issueBody - Full issue body text
 * @returns {Object} - Parsed YAML object, or empty object if no YAML
 * @throws {Error} - If YAML is malformed
 *
 * @example
 * const body = `---
 * ai_pass_count: 3
 * ---
 * Content`;
 * const yaml = extractYAMLFromIssue(body);
 * // { ai_pass_count: 3 }
 */
export function extractYAMLFromIssue(issueBody) {
  if (!issueBody || typeof issueBody !== 'string') {
    return {};
  }

  // Match YAML frontmatter: --- at start, content, closing ---
  const yamlPattern = /^---\s*\n([\s\S]*?)\n---\s*\n/;
  const match = issueBody.match(yamlPattern);

  if (!match) {
    return {};
  }

  const yamlContent = match[1].trim();

  if (!yamlContent) {
    return {};
  }

  try {
    const parsed = yaml.load(yamlContent);
    return parsed || {};
  } catch (error) {
    throw new Error(`Invalid YAML frontmatter: ${error.message}`);
  }
}

/**
 * Validates YAML object against a schema
 *
 * Checks required fields, types, allowed values, and formats
 *
 * @param {Object} yamlObj - Parsed YAML object to validate
 * @param {Object} schema - Validation schema
 * @param {string[]} schema.required - Required field names
 * @param {Object} schema.types - Field type requirements (e.g., { field: 'number' })
 * @param {Object} schema.allowed - Allowed values (e.g., { status: ['open', 'closed'] })
 * @param {Object} schema.formats - Format requirements (e.g., { url: 'url' })
 * @param {string[]} schema.optional - Optional field names (for documentation)
 * @returns {Object} - { valid: boolean, errors: string[] }
 *
 * @example
 * const yaml = { ai_pass_count: 3, max_ai_passes: 5 };
 * const schema = {
 *   required: ['ai_pass_count', 'max_ai_passes'],
 *   types: { ai_pass_count: 'number', max_ai_passes: 'number' }
 * };
 * const result = validateYAMLSchema(yaml, schema);
 * // { valid: true, errors: [] }
 */
export function validateYAMLSchema(yamlObj, schema) {
  const errors = [];

  // Check required fields
  if (schema.required) {
    for (const field of schema.required) {
      if (!(field in yamlObj)) {
        errors.push(`Missing required field: ${field}`);
      }
    }
  }

  // Check field types
  if (schema.types) {
    for (const [field, expectedType] of Object.entries(schema.types)) {
      if (field in yamlObj) {
        const actualType = typeof yamlObj[field];
        if (actualType !== expectedType && yamlObj[field] !== null) {
          errors.push(`Field '${field}' should be type '${expectedType}', got '${actualType}'`);
        }
      }
    }
  }

  // Check allowed values
  if (schema.allowed) {
    for (const [field, allowedValues] of Object.entries(schema.allowed)) {
      if (field in yamlObj) {
        if (!allowedValues.includes(yamlObj[field])) {
          errors.push(`Field '${field}' has invalid value '${yamlObj[field]}'. Allowed: ${allowedValues.join(', ')}`);
        }
      }
    }
  }

  // Check formats
  if (schema.formats) {
    for (const [field, format] of Object.entries(schema.formats)) {
      if (field in yamlObj) {
        const value = yamlObj[field];

        if (format === 'url') {
          try {
            new URL(value);
          } catch {
            errors.push(`Field '${field}' must be a valid URL, got '${value}'`);
          }
        }
      }
    }
  }

  return {
    valid: errors.length === 0,
    errors
  };
}

/**
 * Updates YAML frontmatter in issue body
 *
 * Updates or adds fields to existing YAML frontmatter,
 * or creates new frontmatter if missing
 *
 * @param {string} issueBody - Original issue body
 * @param {Object} updates - Fields to update/add { field: value }
 * @returns {string} - Updated issue body with modified YAML
 *
 * @example
 * const body = `---
 * ai_pass_count: 3
 * ---
 * Content`;
 * const updated = updateYAMLInIssue(body, { ai_pass_count: 4 });
 * // Updated body with ai_pass_count: 4
 */
export function updateYAMLInIssue(issueBody, updates) {
  if (!updates || typeof updates !== 'object') {
    return issueBody;
  }

  // Check if YAML frontmatter exists
  const hasYAML = hasYAMLFrontmatter(issueBody);

  if (hasYAML) {
    // Extract existing YAML
    const existingYAML = extractYAMLFromIssue(issueBody);

    // Merge updates
    const mergedYAML = { ...existingYAML, ...updates };

    // Convert back to YAML string
    const yamlString = stringifyYAML(mergedYAML);

    // Replace YAML section
    const yamlPattern = /^---\s*\n[\s\S]*?\n---\s*\n/;
    const newYAMLSection = `---\n${yamlString}---\n`;

    return issueBody.replace(yamlPattern, newYAMLSection);
  } else {
    // Create new YAML frontmatter
    const yamlString = stringifyYAML(updates);
    const newYAMLSection = `---\n${yamlString}---\n\n`;

    return newYAMLSection + issueBody;
  }
}

/**
 * Checks if issue body has YAML frontmatter
 *
 * YAML must be at the very start of the document
 *
 * @param {string} issueBody - Issue body to check
 * @returns {boolean} - True if YAML frontmatter exists
 *
 * @example
 * hasYAMLFrontmatter('---\nkey: value\n---\nContent') // true
 * hasYAMLFrontmatter('No YAML here') // false
 */
export function hasYAMLFrontmatter(issueBody) {
  if (!issueBody || typeof issueBody !== 'string') {
    return false;
  }

  // Must start with ---, have content, and have closing ---
  const yamlPattern = /^---\s*\n[\s\S]*?\n---\s*\n/;
  return yamlPattern.test(issueBody);
}

/**
 * Parses YAML string into JavaScript object
 *
 * Thin wrapper around js-yaml for consistent error handling
 *
 * @param {string} yamlString - YAML string to parse
 * @returns {Object} - Parsed object
 * @throws {Error} - If YAML is invalid
 *
 * @example
 * const obj = parseYAML('key: value\ncount: 42');
 * // { key: 'value', count: 42 }
 */
export function parseYAML(yamlString) {
  if (!yamlString || typeof yamlString !== 'string') {
    return {};
  }

  const trimmed = yamlString.trim();
  if (!trimmed) {
    return {};
  }

  try {
    const parsed = yaml.load(trimmed);
    return parsed || {};
  } catch (error) {
    throw new Error(`Invalid YAML: ${error.message}`);
  }
}

/**
 * Converts JavaScript object to YAML string
 *
 * Thin wrapper around js-yaml for consistent formatting
 *
 * @param {Object} obj - Object to convert
 * @returns {string} - YAML string
 *
 * @example
 * const yaml = stringifyYAML({ key: 'value', count: 42 });
 * // "key: value\ncount: 42\n"
 */
export function stringifyYAML(obj) {
  if (!obj || typeof obj !== 'object') {
    return '{}';
  }

  try {
    return yaml.dump(obj, {
      indent: 2,
      lineWidth: -1, // No line wrapping
      noRefs: true,  // No references
      sortKeys: false // Preserve key order
    });
  } catch (error) {
    throw new Error(`Failed to stringify YAML: ${error.message}`);
  }
}
