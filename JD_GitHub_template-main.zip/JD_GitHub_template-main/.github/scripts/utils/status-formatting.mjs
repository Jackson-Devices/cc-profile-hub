/**
 * Status Message Formatting Functions
 * Handles creation of formatted status messages, errors, warnings, and summaries
 *
 * Part of P2.1 validation logic extraction from workflows.
 * Provides consistent formatting across all workflow outputs.
 */

/**
 * Formats a success message with checkmark emoji
 *
 * @param {string} message - Success message
 * @returns {string} Formatted success message
 *
 * @example
 * formatSuccess('Operation completed') // '✅ Operation completed'
 */
export function formatSuccess(message) {
  return `✅ ${message}`;
}

/**
 * Formats an error message with cross mark emoji
 *
 * @param {string} message - Error message
 * @param {Error|object|null} error - Optional error object
 * @returns {string} Formatted error message
 *
 * @example
 * formatError('Operation failed') // '❌ Operation failed'
 * formatError('Failed', new Error('Details')) // '❌ Failed\nDetails'
 */
export function formatError(message, error = null) {
  let result = `❌ ${message}`;

  if (error) {
    const errorMessage = error.message || String(error);
    result += `\n${errorMessage}`;
  }

  return result;
}

/**
 * Formats a warning message with warning emoji
 *
 * @param {string} message - Warning message
 * @param {string} details - Optional additional details
 * @returns {string} Formatted warning message
 *
 * @example
 * formatWarning('Potential issue') // '⚠️  Potential issue'
 */
export function formatWarning(message, details = '') {
  let result = `⚠️  ${message}`;

  if (details) {
    result += `\n${details}`;
  }

  return result;
}

/**
 * Formats an informational message with info emoji
 *
 * @param {string} message - Info message
 * @param {string} details - Optional additional details
 * @returns {string} Formatted info message
 *
 * @example
 * formatInfo('Note', 'Details here') // 'ℹ️  Note\nDetails here'
 */
export function formatInfo(message, details = '') {
  let result = `ℹ️  ${message}`;

  if (details) {
    result += `\n${details}`;
  }

  return result;
}

/**
 * Formats a summary with title and key-value sections
 *
 * @param {string} title - Summary title
 * @param {object} sections - Key-value pairs for summary sections
 * @returns {string} Formatted summary
 *
 * @example
 * formatSummary('Results', { Tests: '10 passed', Coverage: '95%' })
 * // ## Results
 * // - **Tests**: 10 passed
 * // - **Coverage**: 95%
 */
export function formatSummary(title, sections) {
  let result = `## ${title}\n`;

  if (Object.keys(sections).length === 0) {
    return result;
  }

  for (const [key, value] of Object.entries(sections)) {
    result += `- **${key}**: ${value}\n`;
  }

  return result;
}

/**
 * Formats an array of errors as a numbered list
 *
 * @param {string[]} errors - Array of error messages
 * @returns {string} Formatted error list
 *
 * @example
 * formatErrorList(['Error 1', 'Error 2'])
 * // 1. Error 1
 * // 2. Error 2
 */
export function formatErrorList(errors) {
  if (!errors || errors.length === 0) {
    return 'No errors';
  }

  return errors.map((error, index) => `${index + 1}. ${error}`).join('\n');
}

/**
 * Formats validation results with passed and failed checks
 *
 * @param {string[]} passed - Array of passed checks
 * @param {string[]} failed - Array of failed checks
 * @returns {string} Formatted validation results
 *
 * @example
 * formatValidationResults(['Check 1', 'Check 2'], ['Check 3'])
 * // ## Validation Results
 * // Passed: 2, Failed: 1
 * //
 * // ### ✅ Passed (2)
 * // - Check 1
 * // - Check 2
 * //
 * // ### ❌ Failed (1)
 * // - Check 3
 */
export function formatValidationResults(passed, failed) {
  const passedCount = passed.length;
  const failedCount = failed.length;
  const totalCount = passedCount + failedCount;

  let result = '## Validation Results\n';
  result += `Passed: ${passedCount}, Failed: ${failedCount}\n\n`;

  if (passedCount > 0) {
    result += `### ✅ Passed (${passedCount})\n`;
    result += formatBulletList(passed) + '\n\n';
  }

  if (failedCount > 0) {
    result += `### ❌ Failed (${failedCount})\n`;
    result += formatBulletList(failed) + '\n';
  }

  return result;
}

/**
 * Formats progress as a percentage with visual indicator
 *
 * @param {number} completed - Number of completed items
 * @param {number} total - Total number of items
 * @returns {string} Formatted progress string
 *
 * @example
 * formatProgress(7, 10) // '[███████░░░] 70% (7/10)'
 */
export function formatProgress(completed, total) {
  if (total === 0) {
    return 'No items to process';
  }

  const percentage = Math.round((completed / total) * 100);
  const barLength = 10;
  const filledLength = Math.round((completed / total) * barLength);
  const emptyLength = barLength - filledLength;

  const bar = '█'.repeat(filledLength) + '░'.repeat(emptyLength);
  const status = percentage === 100 ? ' ✅' : '';

  return `[${bar}] ${percentage}% (${completed}/${total})${status}`;
}

/**
 * Returns checkmark or cross mark based on condition
 *
 * @param {boolean} condition - Condition to check
 * @param {string} successSymbol - Symbol for success (default: ✅)
 * @param {string} failureSymbol - Symbol for failure (default: ❌)
 * @returns {string} Success or failure symbol
 *
 * @example
 * formatCheckmark(true) // '✅'
 * formatCheckmark(false) // '❌'
 * formatCheckmark(true, '✓', '✗') // '✓'
 */
export function formatCheckmark(condition, successSymbol = '✅', failureSymbol = '❌') {
  return condition ? successSymbol : failureSymbol;
}

/**
 * Formats an array as a markdown bullet list
 * Supports nested arrays for indentation
 *
 * @param {Array} items - Array of items (strings or nested arrays)
 * @returns {string} Formatted bullet list
 *
 * @example
 * formatBulletList(['Item 1', 'Item 2'])
 * // - Item 1
 * // - Item 2
 *
 * formatBulletList(['Parent', ['Child 1', 'Child 2']])
 * // - Parent
 * //   - Child 1
 * //   - Child 2
 */
export function formatBulletList(items, indent = 0) {
  if (!items || items.length === 0) {
    return '';
  }

  const indentStr = '  '.repeat(indent);
  const lines = [];

  for (const item of items) {
    if (Array.isArray(item)) {
      // Nested list
      lines.push(formatBulletList(item, indent + 1));
    } else {
      lines.push(`${indentStr}- ${item}`);
    }
  }

  return lines.join('\n');
}

/**
 * Wraps code in markdown code block
 *
 * @param {string} code - Code to format
 * @param {string} language - Optional language for syntax highlighting
 * @returns {string} Formatted code block
 *
 * @example
 * formatCodeBlock('const x = 5;', 'javascript')
 * // ```javascript
 * // const x = 5;
 * // ```
 */
export function formatCodeBlock(code, language = '') {
  return `\`\`\`${language}\n${code}\n\`\`\``;
}

/**
 * Formats a badge (shields.io style or simple text badge)
 *
 * @param {string} label - Badge label
 * @param {string} value - Badge value
 * @param {string} color - Badge color (optional)
 * @returns {string} Formatted badge
 *
 * @example
 * formatBadge('Status', 'Passing', 'green')
 * // ![Status](https://img.shields.io/badge/Status-Passing-green)
 */
export function formatBadge(label, value, color = 'blue') {
  // Encode for URL
  const encodedLabel = encodeURIComponent(label);
  const encodedValue = encodeURIComponent(value);
  const encodedColor = encodeURIComponent(color);

  // shields.io badge format
  const url = `https://img.shields.io/badge/${encodedLabel}-${encodedValue}-${encodedColor}`;

  return `![${label}](${url})`;
}

/**
 * Escapes special markdown characters
 *
 * @param {string} text - Text to escape
 * @returns {string} Escaped text
 *
 * @example
 * escapeMarkdown('Text with *asterisks*')
 * // 'Text with \\*asterisks\\*'
 */
export function escapeMarkdown(text) {
  if (!text) {
    return text;
  }

  // Characters that need escaping in markdown
  const escapeChars = ['\\', '*', '_', '[', ']', '(', ')', '#', '+', '-', '.', '!'];

  let result = text;

  // Don't double-escape already escaped characters
  for (const char of escapeChars) {
    // Only escape if not already escaped
    result = result.replace(new RegExp(`(?<!\\\\)\\${char}`, 'g'), `\\${char}`);
  }

  return result;
}
