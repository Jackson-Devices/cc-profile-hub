# Orchestration System Development Roadmap

**Status**: Phase 1 (Basic Multi-Tier Retry) - IN PROGRESS
**Last Updated**: 2025-11-13
**Tracking Document**: This is the master roadmap for the intelligent orchestration system

---

## Table of Contents

1. [Vision & Architecture](#vision--architecture)
2. [Current State](#current-state)
3. [Phase Breakdown](#phase-breakdown)
4. [Branch Strategy](#branch-strategy)
5. [Testing Strategy](#testing-strategy)
6. [Implementation Tracking](#implementation-tracking)

---

## Vision & Architecture

### The Goal

Build a self-evolving, intelligent orchestration system that:

- Automatically fixes issues with multi-tier retry logic
- Learns from failures and improves over time
- Provides complete automation from commit → PR → merge
- Decomposes complex problems into solvable sub-problems
- Maintains comprehensive audit trails
- Escalates to humans only when truly necessary

### Key Principles

1. **Test Everything** - Unit, integration, snapshot, and edge case tests for ALL components
2. **Atomic Work** - Each phase is independently testable and deployable
3. **Branch Per Phase** - Major features get their own branch for parallel development
4. **Documentation First** - Design docs before implementation
5. **Compound Learning** - Each run makes the system smarter

---

## Current State

### ✅ Completed (Phase 1a - Basic Infrastructure)

**Branch**: `claude/fix-broken-workflows-011CV4ytHzLBXMePN9FLatGT`
**Commit**: `5851edb`

| Component                                    | Status              | Tests       | Notes                                    |
| -------------------------------------------- | ------------------- | ----------- | ---------------------------------------- |
| `.github/workflow-orchestration.yml`         | ✅ Implemented      | ❌ No tests | Configuration file for phase ordering    |
| `.github/workflows/orchestrator.yml`         | ✅ Implemented      | ❌ No tests | Main orchestrator workflow               |
| `.github/scripts/git-lock.sh`                | ✅ Implemented      | ❌ No tests | File-based locking for git ops           |
| `.github/scripts/race-condition-detector.sh` | ✅ Implemented      | ❌ No tests | Race condition detection                 |
| `.github/scripts/shellcheck-apply.sh`        | ✅ Implemented      | ❌ No tests | Multi-strategy shellcheck auto-fix       |
| `.github/workflows/workflow-lint-apply.yml`  | ✅ Implemented      | ❌ No tests | Orchestrates shellcheck fixes            |
| `scripts/check-sequential-commits.mjs`       | ✅ Fixed bug        | ❌ No tests | Commit validation (multi-line bug fixed) |
| Concurrency controls                         | ✅ All 16 workflows | ❌ No tests | Prevents parallel execution              |
| README documentation                         | ✅ Complete         | N/A         | Mermaid diagram + full docs              |

### 🚧 In Progress (Phase 1b - Testing Infrastructure)

**Critical Gap Identified**: No tests for any orchestration components!

### ❌ Not Started

- Auto-PR creation
- Auto-merge logic
- Comprehensive logging system
- Pattern learning database
- Decomposition engine
- Self-improvement capabilities

---

## Phase Breakdown

### Phase 1: Basic Multi-Tier Retry (CURRENT)

**Goal**: Working orchestration with multi-tier retry strategies

#### Phase 1a: Basic Infrastructure ✅

- [x] Orchestrator workflow
- [x] Configuration file
- [x] Git lock utility
- [x] Race condition detector
- [x] Shellcheck auto-fix with strategies
- [x] Concurrency controls
- [x] Documentation

#### Phase 1b: Testing Infrastructure 🚧

**Branch**: `claude/orchestration-tests-<session-id>` (TO BE CREATED)
**Depends on**: Phase 1a completion
**Estimated**: 2-3 sessions

- [ ] Unit tests for shellcheck-apply.sh
  - [ ] Test conservative strategy
  - [ ] Test balanced strategy
  - [ ] Test aggressive strategy
  - [ ] Test max-passes logic
  - [ ] Test backup/restore on failure
- [ ] Integration tests for shellcheck-apply.sh
  - [ ] Mock file system with known SC codes
  - [ ] Verify fixes applied correctly
  - [ ] Verify backup created
  - [ ] Test failure scenarios
- [ ] Snapshot tests for shellcheck-apply.sh
  - [ ] Capture stdout for each scenario
  - [ ] Verify error messages
- [ ] Unit tests for git-lock.sh
  - [ ] Test lock acquisition
  - [ ] Test lock release
  - [ ] Test stale lock detection
  - [ ] Test timeout logic
- [ ] Integration tests for git-lock.sh
  - [ ] Mock file system
  - [ ] Test concurrent lock attempts
  - [ ] Test cleanup
- [ ] Unit tests for race-condition-detector.sh
  - [ ] Test workflow detection logic
  - [ ] Test git lock detection
  - [ ] Test file access detection
- [ ] Integration tests for race-condition-detector.sh
  - [ ] Mock GitHub API responses
  - [ ] Mock file system
  - [ ] Verify detection accuracy
- [ ] Unit tests for check-sequential-commits.mjs
  - [ ] Test getCommitMessages parser
  - [ ] Test isFixCommit patterns
  - [ ] Test with single-line commits
  - [ ] Test with multi-line commits (regression)
  - [ ] Test with special characters
- [ ] Integration tests for check-sequential-commits.mjs
  - [ ] Mock execSync (git log outputs)
  - [ ] Mock fetch (GitHub API)
  - [ ] Scenario: 2 feat commits (should fail)
  - [ ] Scenario: feat + fix with failure (should pass)
  - [ ] Scenario: single commit (should pass)
- [ ] Integration tests for orchestrator.yml
  - [ ] Mock GitHub context
  - [ ] Test phase execution order
  - [ ] Test dry-run mode
  - [ ] Test phase selection
  - [ ] Test lock coordination
- [ ] Integration tests for workflow-lint-apply.yml
  - [ ] Mock file system with shell scripts
  - [ ] Test Tier 1 YAML fixes
  - [ ] Test Tier 2-4 multi-strategy
  - [ ] Test Tier 5 escalation
  - [ ] Verify Fix Details output
- [ ] Snapshot tests for all workflows
  - [ ] Capture stdout/summary for each scenario
  - [ ] Verify error message format

**BRANCH POINT**: Create `claude/orchestration-tests-<session-id>` branch before starting this work

#### Phase 1c: Auto-PR + Auto-Merge

**Branch**: `claude/auto-pr-merge-<session-id>` (TO BE CREATED)
**Depends on**: Phase 1b completion
**Estimated**: 1-2 sessions

- [ ] Design auto-PR workflow
- [ ] Implement auto-PR creation
  - [ ] Extract commit description
  - [ ] Validate PR description not blank
  - [ ] Link to parent issue
  - [ ] Issue linking warning (Tier 1)
- [ ] Implement auto-merge logic
  - [ ] Wait for all checks
  - [ ] Verify all checks passed
  - [ ] Merge if clean
  - [ ] Escalate if failures (Tier 5)
- [ ] Tests for auto-PR
  - [ ] Unit tests for description extraction
  - [ ] Integration tests with mock API
  - [ ] Snapshot tests for PR body format
- [ ] Tests for auto-merge
  - [ ] Integration tests with mock check runs
  - [ ] Test all-pass scenario
  - [ ] Test failure scenario
  - [ ] Verify escalation report

**BRANCH POINT**: Create `claude/auto-pr-merge-<session-id>` branch before starting this work

#### Phase 1d: Auto-Delete-Branch

**Branch**: `claude/auto-delete-branch-<session-id>` (TO BE CREATED)
**Depends on**: Phase 1c completion
**Estimated**: 1 session

- [ ] Design auto-delete-branch workflow
- [ ] Implement auto-delete trigger
  - [ ] Trigger on: `pull_request` types `[closed]`
  - [ ] Condition: PR was merged (`github.event.pull_request.merged == true`)
  - [ ] Condition: All required checks passed
  - [ ] Condition: Not a protected branch (main, master)
- [ ] Implement branch deletion logic
  - [ ] Delete source branch via GitHub API
  - [ ] Handle deletion failures gracefully
  - [ ] Log deletion success/failure
  - [ ] Skip deletion for fork PRs (security)
- [ ] Add safety guards
  - [ ] Never delete base branch
  - [ ] Never delete branches matching `main`, `master`, `develop`
  - [ ] Never delete branches with open PRs
  - [ ] Require `delete-branch: true` label or auto-delete enabled in repo settings
- [ ] Tests for auto-delete-branch
  - [ ] Unit tests for branch name validation
  - [ ] Integration tests with mock PR events
  - [ ] Test merged PR with passing checks → branch deleted
  - [ ] Test merged PR with failing checks → branch NOT deleted
  - [ ] Test closed (not merged) PR → branch NOT deleted
  - [ ] Test protected branch patterns → branch NOT deleted
  - [ ] Test fork PR → branch NOT deleted
  - [ ] Snapshot tests for deletion API calls

**BRANCH POINT**: Create `claude/auto-delete-branch-<session-id>` branch before starting this work

#### Phase 1e: Human Authorization Gate System

**Branch**: `claude/human-auth-gate-<session-id>` (TO BE CREATED)
**Depends on**: Phase 1d completion
**Estimated**: 2 sessions
**Priority**: HIGH - Security critical

- [ ] Design password-protected authorization system
  - [ ] Store secret in GitHub Secrets (never visible to AI or logs)
  - [ ] AI proposes changes to protected files
  - [ ] Human provides password in PR body to authorize
  - [ ] Workflow validates password hash before allowing merge
- [ ] Implement protected files list
  - [ ] scripts/check-pr-risks.mjs (whitelist definitions)
  - [ ] .github/gate-overrides.yml (gate bypass rules)
  - [ ] .github/protected-files.yml (this list itself)
- [ ] Create human-auth-gate.yml workflow
  - [ ] Extract auth token from PR body
  - [ ] Compare hashed values (never log plaintext)
  - [ ] Block merge if unauthorized
  - [ ] Audit trail of all authorizations
- [ ] Define protected operations requiring human approval
  - [ ] Adding to PR Risk whitelist
  - [ ] Modifying gate bypass rules
  - [ ] Changing security policies
  - [ ] Disabling required checks
- [ ] Documentation
  - [ ] How to use auth system
  - [ ] How to rotate password
  - [ ] Security best practices
- [ ] Tests for auth gate
  - [ ] Valid password hash matches
  - [ ] Invalid password rejected
  - [ ] Missing password blocks merge
  - [ ] Audit log verification

**BRANCH POINT**: Create `claude/human-auth-gate-<session-id>` branch before starting this work

#### Phase 1f: Shellcheck Cleanup (URGENT)

**Branch**: `claude/shellcheck-cleanup-<session-id>` (TO BE CREATED)
**Depends on**: Phase 1 completion
**Estimated**: 1 session
**Priority**: HIGH - Unblocking technical debt

**Context**: Temporarily ignoring shellcheck warnings SC2086, SC2034, SC2129, SC2016 in workflow-lint-gate.yml to unblock MVP. MUST fix properly.

- [ ] Audit all workflow inline bash scripts
- [ ] Fix SC2086 - Quote variables to prevent word splitting
  - [ ] auto-squash-commits.yml (multiple instances)
  - [ ] docs-drift-gate.yml
  - [ ] eslint-apply.yml
  - [ ] format-apply.yml (multiple instances)
- [ ] Fix SC2034 - Remove unused variables or mark as intentional
  - [ ] auto-squash-commits.yml (COMMIT_MESSAGES, HAS_FAILURES)
- [ ] Fix SC2129 - Use command grouping for redirects
  - [ ] auto-squash-commits.yml (multiple instances)
- [ ] Fix SC2016 - Fix single quote expansion issues
  - [ ] workflow-lint-apply.yml (multiple instances)
- [ ] Remove temporary ignore flags from workflow-lint-gate.yml
- [ ] Verify all workflows pass actionlint with no warnings
- [ ] Document bash best practices for workflow scripts

**BRANCH POINT**: Create `claude/shellcheck-cleanup-<session-id>` branch before starting this work

### Phase 2: Comprehensive Logging (FUTURE)

**Goal**: Structured logging of all orchestration decisions

**Branch**: `claude/orchestration-logging-<session-id>` (TO BE CREATED)
**Depends on**: Phase 1 completion
**Estimated**: 2-3 sessions

- [ ] Design logging schema (JSON structure)
- [ ] Implement orchestration logger
  - [ ] Log every workflow execution
  - [ ] Log every fix attempt
  - [ ] Log strategy selection
  - [ ] Log success/failure reasons
  - [ ] Log timing data
- [ ] Create `.github/orchestration-logs/` storage
- [ ] Implement log rotation
- [ ] Implement log querying utility
- [ ] Tests for logger
  - [ ] Unit tests for log formatting
  - [ ] Integration tests for log writes
  - [ ] Snapshot tests for log format
- [ ] Documentation

**BRANCH POINT**: Create `claude/orchestration-logging-<session-id>` branch before starting this work

### Phase 3: Pattern Learning Database (FUTURE)

**Goal**: System learns which strategies work best for which errors

**Branch**: `claude/pattern-learning-<session-id>` (TO BE CREATED)
**Depends on**: Phase 2 completion
**Estimated**: 3-4 sessions

- [ ] Design pattern database schema
- [ ] Implement pattern analyzer
  - [ ] Parse orchestration logs
  - [ ] Extract error patterns
  - [ ] Build success matrix
  - [ ] Calculate strategy effectiveness
- [ ] Implement pattern-based strategy selection
  - [ ] Query database for similar errors
  - [ ] Select optimal strategy
  - [ ] Fall back to default if unknown
- [ ] Implement pattern update mechanism
  - [ ] Record new patterns
  - [ ] Update success rates
  - [ ] Deprecate ineffective strategies
- [ ] Tests for pattern learning
  - [ ] Unit tests for pattern extraction
  - [ ] Unit tests for success calculation
  - [ ] Integration tests for database
  - [ ] Property-based tests for strategy selection
- [ ] Documentation

**BRANCH POINT**: Create `claude/pattern-learning-<session-id>` branch before starting this work

### Phase 4: Decomposition Engine (FUTURE)

**Goal**: Break complex problems into solvable sub-problems

**Branch**: `claude/decomposition-engine-<session-id>` (TO BE CREATED)
**Depends on**: Phase 3 completion
**Estimated**: 4-5 sessions

- [ ] Design decomposition framework
- [ ] Implement complexity analyzer
  - [ ] Detect when problem is too complex
  - [ ] Identify decomposition opportunities
  - [ ] Generate sub-problem tree
- [ ] Implement sub-problem solver
  - [ ] Solve atomic sub-problems
  - [ ] Compose solutions
  - [ ] Verify integration
- [ ] Implement behavioral verification
  - [ ] Pre-decomposition snapshot
  - [ ] Post-composition verification
  - [ ] Rollback if behavior changed
- [ ] Tests for decomposition
  - [ ] Unit tests for complexity detection
  - [ ] Unit tests for decomposition logic
  - [ ] Integration tests for full pipeline
  - [ ] Snapshot tests for outputs
- [ ] Documentation

**BRANCH POINT**: Create `claude/decomposition-engine-<session-id>` branch before starting this work

### Phase 5: Self-Improvement (FUTURE)

**Goal**: Orchestrator improves itself based on historical data

**Branch**: `claude/self-improvement-<session-id>` (TO BE CREATED)
**Depends on**: Phase 4 completion
**Estimated**: 5-6 sessions

- [ ] Design self-improvement framework
- [ ] Implement log analyzer
  - [ ] Identify recurring failures
  - [ ] Generate improvement hypotheses
  - [ ] Prioritize improvements
- [ ] Implement strategy generator
  - [ ] Generate new fix strategies
  - [ ] Test in sandbox
  - [ ] Validate effectiveness
- [ ] Implement strategy deployment
  - [ ] Promote successful strategies
  - [ ] Deprecate ineffective strategies
  - [ ] Version control for strategies
- [ ] Tests for self-improvement
  - [ ] Unit tests for hypothesis generation
  - [ ] Integration tests for sandbox
  - [ ] Regression tests for deployments
- [ ] Documentation

**BRANCH POINT**: Create `claude/self-improvement-<session-id>` branch before starting this work

### Phase 6: Full Autonomous Operation (FUTURE)

**Goal**: Complete automation with minimal human oversight

**Branch**: `claude/full-automation-<session-id>` (TO BE CREATED)
**Depends on**: Phase 5 completion
**Estimated**: 3-4 sessions

- [ ] Implement confidence scoring
- [ ] Implement human-in-loop triggers
- [ ] Implement escalation routing
- [ ] Implement teach-back mechanism
- [ ] Tests for automation
- [ ] Documentation

---

## Branch Strategy

### When to Create a New Branch

Create a new branch when:

1. **Major Phase Begins** - Each numbered phase gets its own branch
2. **Parallel Work Streams** - If work can happen concurrently
3. **Experimental Features** - High-risk features that might fail
4. **Breaking Changes** - Changes that could break existing functionality

### Branch Naming Convention

```
claude/<feature>-<session-id>
```

Examples:

- `claude/orchestration-tests-ABC123XYZ`
- `claude/auto-pr-merge-DEF456UVW`
- `claude/pattern-learning-GHI789RST`

### Branch Lifecycle

1. **Create** - Branch from main when starting a phase
2. **Develop** - All work happens on the feature branch
3. **Test** - Comprehensive test suite must pass
4. **PR** - Create PR when phase is complete
5. **Merge** - Squash merge to main after review
6. **Delete** - Delete branch after merge

### Current Branch State

| Branch                                                 | Phase | Status   | Tests | Ready for PR?        |
| ------------------------------------------------------ | ----- | -------- | ----- | -------------------- |
| `claude/fix-broken-workflows-011CV4ytHzLBXMePN9FLatGT` | 1a    | Complete | ❌ No | ⚠️ Waiting for tests |

**NEXT STEP**: Create `claude/orchestration-tests-<session-id>` for Phase 1b

---

## Testing Strategy

### Testing Pyramid

```
          /\
         /  \  E2E (Minimal)
        /----\
       /      \  Integration (Primary)
      /--------\
     /          \  Unit (Foundation)
    /------------\
   /  Snapshot    \  (User-Facing Output)
  /----------------\
```

### Test Coverage Requirements

| Component Type     | Unit           | Integration | Snapshot    | E2E   | Fuzz        | Property    |
| ------------------ | -------------- | ----------- | ----------- | ----- | ----------- | ----------- |
| Shell Scripts      | ✅ Required    | ✅ Required | ✅ Required | ❌ No | ⚠️ Consider | ❌ No       |
| Workflows          | ⚠️ If possible | ✅ Required | ✅ Required | ❌ No | ❌ No       | ❌ No       |
| Node Scripts       | ✅ Required    | ✅ Required | ✅ Required | ❌ No | ⚠️ Consider | ⚠️ Consider |
| Orchestrator Logic | ✅ Required    | ✅ Required | ✅ Required | ❌ No | ❌ No       | ✅ Required |

### Test Patterns (From Testing Strategy Document)

#### For Shell Scripts (.sh files)

**Example**: `shellcheck-apply.sh`, `git-lock.sh`, `race-condition-detector.sh`

**Unit Tests**:

- Extract pure functions where possible
- Test individual validation rules
- Test pattern matching logic
- Test parsing functions

**Integration Tests** (PRIMARY):

- Mock file system
- Mock external commands (`shellcheck`, `jq`, `git`, `find`)
- Test scenarios:
  - Clean install
  - Existing files
  - Missing dependencies
  - Edge cases (empty input, malformed input)

**Snapshot Tests**:

- Capture stdout for each scenario
- Verify error messages
- Ensure consistent user feedback

#### For Node.js Scripts (.mjs files)

**Example**: `check-sequential-commits.mjs`

**Unit Tests**:

- Test pure functions in isolation
- `getCommitMessages` with various inputs
- `isFixCommit` with various patterns
- Parser edge cases (single-line, multi-line, special chars)

**Integration Tests**:

- Mock `execSync` for git commands
- Mock `fetch` for GitHub API
- Test decision tree:
  - Multiple feature commits (fail)
  - Feature + fix with failure (pass)
  - Single commit (pass)

**Snapshot Tests**:

- Capture console output
- Verify report format

#### For Workflows (.yml files)

**Example**: `orchestrator.yml`, `workflow-lint-apply.yml`

**Integration Tests** (PRIMARY):

- Mock `github` context
- Mock `github.rest` API calls
- Test workflow logic:
  - Trigger conditions
  - Job orchestration
  - API call sequences
  - Error handling

**Snapshot Tests**:

- Capture workflow summary output
- Verify error/success messages

**No E2E Tests**: Too slow, too fragile, mocked integration tests provide better coverage

### Mock Strategy

**Always Mock**:

- GitHub API (`github.rest.*` calls)
- External CLIs (`gh`, `git`, `shellcheck`, `jq`)
- File system (for destructive operations)

**Never Mock**:

- Pure logic functions
- Simple data transformations

**Sometimes Mock**:

- File system (for read-only operations - use temp dirs instead)

### Test Organization

```
tests/
  unit/
    shellcheck-apply/
      test_conservative_strategy.sh
      test_balanced_strategy.sh
      test_aggressive_strategy.sh
    git-lock/
      test_lock_acquisition.sh
      test_lock_release.sh
      test_stale_detection.sh
    check-sequential-commits/
      test_parser.test.mjs
      test_fix_detection.test.mjs
  integration/
    shellcheck-apply/
      test_full_workflow.sh
    workflows/
      test_orchestrator.test.mjs
      test_workflow_lint_apply.test.mjs
  snapshots/
    shellcheck-apply/
      conservative_output.txt
      balanced_output.txt
      error_report.txt
    workflows/
      orchestrator_summary.md
      lint_apply_summary.md
  fixtures/
    mock_scripts/
      broken_script_sc2086.sh
      broken_script_sc2046.sh
    mock_repos/
      single_commit/
      multiple_commits/
    mock_api_responses/
      issue_123.json
      pr_456.json
```

---

## Implementation Tracking

### Phase 1a: Basic Infrastructure ✅

| Task                         | Component                                    | Status | Commit  | Branch                                                 |
| ---------------------------- | -------------------------------------------- | ------ | ------- | ------------------------------------------------------ |
| Create orchestrator workflow | `.github/workflows/orchestrator.yml`         | ✅     | 5851edb | `claude/fix-broken-workflows-011CV4ytHzLBXMePN9FLatGT` |
| Create configuration         | `.github/workflow-orchestration.yml`         | ✅     | 5851edb | `claude/fix-broken-workflows-011CV4ytHzLBXMePN9FLatGT` |
| Create git lock utility      | `.github/scripts/git-lock.sh`                | ✅     | 5851edb | `claude/fix-broken-workflows-011CV4ytHzLBXMePN9FLatGT` |
| Create race detector         | `.github/scripts/race-condition-detector.sh` | ✅     | 5851edb | `claude/fix-broken-workflows-011CV4ytHzLBXMePN9FLatGT` |
| Create shellcheck auto-fix   | `.github/scripts/shellcheck-apply.sh`        | ✅     | 5851edb | `claude/fix-broken-workflows-011CV4ytHzLBXMePN9FLatGT` |
| Update workflow lint apply   | `.github/workflows/workflow-lint-apply.yml`  | ✅     | 5851edb | `claude/fix-broken-workflows-011CV4ytHzLBXMePN9FLatGT` |
| Fix commit parser bug        | `scripts/check-sequential-commits.mjs`       | ✅     | 5851edb | `claude/fix-broken-workflows-011CV4ytHzLBXMePN9FLatGT` |
| Add concurrency controls     | 16 workflow files                            | ✅     | 5851edb | `claude/fix-broken-workflows-011CV4ytHzLBXMePN9FLatGT` |
| Documentation                | `README.md`, `WORKFLOW_ORCHESTRATION.md`     | ✅     | 5851edb | `claude/fix-broken-workflows-011CV4ytHzLBXMePN9FLatGT` |

### Phase 1b: Testing Infrastructure 🚧

**Status**: NOT STARTED
**Next Action**: Create branch `claude/orchestration-tests-<session-id>`

| Task                                            | Component                                   | Status | Commit | Branch |
| ----------------------------------------------- | ------------------------------------------- | ------ | ------ | ------ |
| Unit tests: shellcheck-apply.sh                 | `tests/unit/shellcheck-apply/`              | ❌     | -      | TBD    |
| Integration tests: shellcheck-apply.sh          | `tests/integration/shellcheck-apply/`       | ❌     | -      | TBD    |
| Snapshot tests: shellcheck-apply.sh             | `tests/snapshots/shellcheck-apply/`         | ❌     | -      | TBD    |
| Unit tests: git-lock.sh                         | `tests/unit/git-lock/`                      | ❌     | -      | TBD    |
| Integration tests: git-lock.sh                  | `tests/integration/git-lock/`               | ❌     | -      | TBD    |
| Unit tests: race-condition-detector.sh          | `tests/unit/race-detector/`                 | ❌     | -      | TBD    |
| Integration tests: race-condition-detector.sh   | `tests/integration/race-detector/`          | ❌     | -      | TBD    |
| Unit tests: check-sequential-commits.mjs        | `tests/unit/sequential-commits/`            | ❌     | -      | TBD    |
| Integration tests: check-sequential-commits.mjs | `tests/integration/sequential-commits/`     | ❌     | -      | TBD    |
| Integration tests: orchestrator.yml             | `tests/integration/workflows/orchestrator/` | ❌     | -      | TBD    |
| Integration tests: workflow-lint-apply.yml      | `tests/integration/workflows/lint-apply/`   | ❌     | -      | TBD    |
| Snapshot tests: all components                  | `tests/snapshots/`                          | ❌     | -      | TBD    |

---

## Critical Decisions & Notes

### Testing Infrastructure Gap

**Date**: 2025-11-13
**Decision**: Pause new feature development to build comprehensive test suite
**Rationale**: The user provided a detailed testing strategy document showing we've been building without tests. This is a critical gap that must be addressed before continuing.

### Branch Strategy

**Date**: 2025-11-13
**Decision**: Use separate branches for each major phase
**Rationale**: Allows parallel development, cleaner PR reviews, and easier rollback if a phase fails.

### Testing Priority

**Date**: 2025-11-13
**Decision**: Integration tests are PRIMARY, not secondary
**Rationale**: For shell scripts and workflows, integration tests with mocks provide the most value. Unit tests are still required but integration is the main verification.

---

## Next Steps

1. **Immediate** (Current Session):
   - Finish current commit on `claude/fix-broken-workflows-011CV4ytHzLBXMePN9FLatGT`
   - Push changes
   - Verify workflows pass

2. **Next Session**:
   - Create new branch: `claude/orchestration-tests-<session-id>`
   - Start Phase 1b: Testing Infrastructure
   - Begin with shellcheck-apply.sh tests (most critical)

3. **After Phase 1b Complete**:
   - Merge testing branch to main
   - Create new branch: `claude/auto-pr-merge-<session-id>`
   - Start Phase 1c: Auto-PR + Auto-Merge

---

## Resources

- **Testing Strategy Document**: `docs/TESTING_STRATEGY_DECISION_LOG.md` (provided by user)
- **GitHub Actions Testing Guide**: https://docs.github.com/en/actions/creating-actions/testing-your-action
- **Mocking GitHub Context**: https://github.com/actions/toolkit/tree/main/packages/github
- **Shellcheck Wiki**: https://www.shellcheck.net/wiki/

---

**Maintained By**: Claude (Orchestration Development)
**Review Frequency**: Updated at end of each phase
**Last Review**: 2025-11-13
