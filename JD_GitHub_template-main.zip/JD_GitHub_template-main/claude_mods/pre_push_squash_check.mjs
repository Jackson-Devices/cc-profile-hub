#!/usr/bin/env node

/**
 * Enhanced Pre-Push Commit Squashing Hook for Claude Code
 *
 * This hook intercepts git push operations and prompts the user to squash
 * commits when multiple commits are detected ahead of the upstream branch.
 *
 * ENHANCEMENTS:
 * - Asynchronous git command execution for better performance
 * - Configuration file support (~/.claude/squash_hook_config.json)
 * - Semantic commit message parsing (Conventional Commits)
 * - Advanced commit analysis (diff size, file changes)
 * - User input validation
 * - Force push warnings with team collaboration checks
 * - File-based logging for debugging
 * - Customizable WIP keywords and time thresholds
 *
 * Features:
 * - Detects commits ahead of upstream
 * - Displays commit details (SHA, message, author, date, stats)
 * - Recommends squashing strategy based on sophisticated analysis
 * - Provides interactive options (squash all, interactive, keep, cancel)
 * - Executes squash with verbose output
 * - Handles edge cases (no upstream, first push, single commit, etc.)
 *
 * Requirements:
 * - Node.js installed on local machine
 * - Git repository with commits
 * - Called from Claude Code hooks system
 *
 * Exit codes:
 * - 0: Success (push can proceed)
 * - 1: Blocked (push cancelled or squashing needed)
 * - 2: Error (configuration or git error)
 */

import { exec, execSync } from 'child_process';
import { promisify } from 'util';
import readline from 'readline';
import fs from 'fs';
import path from 'path';
import os from 'os';

const execAsync = promisify(exec);

// ANSI color codes for terminal output
const colors = {
  reset: '\x1b[0m',
  bright: '\x1b[1m',
  dim: '\x1b[2m',
  red: '\x1b[31m',
  green: '\x1b[32m',
  yellow: '\x1b[33m',
  blue: '\x1b[34m',
  magenta: '\x1b[35m',
  cyan: '\x1b[36m',
  white: '\x1b[37m',
};

// Default configuration
const DEFAULT_CONFIG = {
  // WIP keywords to detect incremental work
  wipKeywords: ['wip', 'fix', 'update', 'temp', 'tmp', 'debug', 'test', 'merge', 'typo', 'cleanup'],

  // Time threshold in seconds (default: 1 hour)
  timeThreshold: 3600,

  // Conventional commit types that should be kept separate
  conventionalTypes: [
    'feat',
    'fix',
    'docs',
    'style',
    'refactor',
    'perf',
    'test',
    'build',
    'ci',
    'chore',
    'revert',
  ],

  // Enable/disable semantic commit parsing
  semanticParsing: true,

  // Enable/disable diff analysis
  diffAnalysis: true,

  // Enable/disable logging
  logging: true,

  // Log file path
  logFile: path.join(os.homedir(), '.claude', 'squash_hook.log'),

  // Force push warning settings
  forcePushWarning: {
    enabled: true,
    requireConfirmation: true,
    checkRemoteChanges: true,
  },

  // Input validation settings
  inputValidation: {
    maxCommitMessageLength: 5000,
    minCommitMessageLength: 3,
    forbiddenCharacters: ['\0', '\x1b'], // Null and escape characters
  },
};

/**
 * Logger class for file-based logging
 */
class Logger {
  constructor(config) {
    this.enabled = config.logging;
    this.logFile = config.logFile;

    if (this.enabled) {
      this.ensureLogDirectory();
    }
  }

  ensureLogDirectory() {
    const dir = path.dirname(this.logFile);
    if (!fs.existsSync(dir)) {
      fs.mkdirSync(dir, { recursive: true });
    }
  }

  log(level, message, data = null) {
    if (!this.enabled) return;

    const timestamp = new Date().toISOString();
    const logEntry = {
      timestamp,
      level,
      message,
      data,
    };

    try {
      const logLine = JSON.stringify(logEntry) + '\n';
      fs.appendFileSync(this.logFile, logLine);
    } catch (error) {
      // Silently fail if logging doesn't work
      console.error(`Failed to write to log file: ${error.message}`);
    }
  }

  info(message, data) {
    this.log('INFO', message, data);
  }
  warn(message, data) {
    this.log('WARN', message, data);
  }
  error(message, data) {
    this.log('ERROR', message, data);
  }
  debug(message, data) {
    this.log('DEBUG', message, data);
  }
}

/**
 * Configuration manager
 */
class ConfigManager {
  constructor() {
    this.configPath = path.join(os.homedir(), '.claude', 'squash_hook_config.json');
    this.config = this.loadConfig();
  }

  loadConfig() {
    try {
      if (fs.existsSync(this.configPath)) {
        const userConfig = JSON.parse(fs.readFileSync(this.configPath, 'utf-8'));
        return { ...DEFAULT_CONFIG, ...userConfig };
      }
    } catch (error) {
      console.error(`Warning: Failed to load config from ${this.configPath}: ${error.message}`);
    }

    return DEFAULT_CONFIG;
  }

  saveDefaultConfig() {
    try {
      const dir = path.dirname(this.configPath);
      if (!fs.existsSync(dir)) {
        fs.mkdirSync(dir, { recursive: true });
      }

      fs.writeFileSync(this.configPath, JSON.stringify(DEFAULT_CONFIG, null, 2), 'utf-8');

      return true;
    } catch (error) {
      console.error(`Failed to save config: ${error.message}`);
      return false;
    }
  }

  get() {
    return this.config;
  }
}

// Global instances
const configManager = new ConfigManager();
const config = configManager.get();
const logger = new Logger(config);

/**
 * Execute git command asynchronously
 * @param {string} command - Git command to execute
 * @param {boolean} throwOnError - Whether to throw on error
 * @returns {Promise<string|null>} Command output or null on error
 */
async function gitAsync(command, throwOnError = true) {
  try {
    logger.debug(`Executing git command: ${command}`);
    const { stdout, stderr } = await execAsync(`git ${command}`);

    if (stderr && throwOnError) {
      logger.warn(`Git command warning: ${stderr}`);
    }

    return stdout.trim();
  } catch (error) {
    logger.error(`Git command failed: ${command}`, { error: error.message });

    if (throwOnError) {
      throw error;
    }
    return null;
  }
}

/**
 * Execute git command synchronously (for cases where async isn't possible)
 * @param {string} command - Git command to execute
 * @param {boolean} throwOnError - Whether to throw on error
 * @returns {string|null} Command output or null on error
 */
function _gitSync(command, throwOnError = true) {
  try {
    return execSync(`git ${command}`, { encoding: 'utf-8' }).trim();
  } catch (error) {
    if (throwOnError) {
      throw error;
    }
    return null;
  }
}

/**
 * Print colored output to console
 * @param {string} message - Message to print
 * @param {string} color - Color name from colors object
 */
function print(message, color = 'reset') {
  console.log(`${colors[color]}${message}${colors.reset}`);
}

/**
 * Print section header
 * @param {string} title - Section title
 */
function printHeader(title) {
  console.log();
  print(`${'='.repeat(80)}`, 'cyan');
  print(`  ${title}`, 'bright');
  print(`${'='.repeat(80)}`, 'cyan');
  console.log();
}

/**
 * Validate user input
 * @param {string} input - User input to validate
 * @param {Object} options - Validation options
 * @returns {Object} Validation result { valid: boolean, error: string }
 */
function validateInput(input, options = {}) {
  const {
    minLength = 0,
    maxLength = Infinity,
    pattern = null,
    forbiddenChars = [],
    allowEmpty = false,
  } = options;

  // Check if empty
  if (!input || input.trim() === '') {
    if (allowEmpty) {
      return { valid: true };
    }
    return { valid: false, error: 'Input cannot be empty' };
  }

  // Check length
  if (input.length < minLength) {
    return { valid: false, error: `Input must be at least ${minLength} characters` };
  }

  if (input.length > maxLength) {
    return { valid: false, error: `Input must be at most ${maxLength} characters` };
  }

  // Check forbidden characters
  for (const char of forbiddenChars) {
    if (input.includes(char)) {
      return { valid: false, error: `Input contains forbidden character: ${JSON.stringify(char)}` };
    }
  }

  // Check pattern
  if (pattern && !pattern.test(input)) {
    return { valid: false, error: 'Input does not match required pattern' };
  }

  return { valid: true };
}

/**
 * Get user input from readline with validation
 * @param {string} question - Question to ask
 * @param {Object} validationOptions - Validation options
 * @returns {Promise<string>} User input
 */
function askQuestion(question, validationOptions = {}) {
  const rl = readline.createInterface({
    input: process.stdin,
    output: process.stdout,
  });

  return new Promise((resolve) => {
    const askWithValidation = () => {
      rl.question(question, (answer) => {
        const trimmed = answer.trim();

        if (validationOptions) {
          const validation = validateInput(trimmed, validationOptions);

          if (!validation.valid) {
            print(`✗ ${validation.error}`, 'red');
            askWithValidation(); // Ask again
            return;
          }
        }

        rl.close();
        resolve(trimmed);
      });
    };

    askWithValidation();
  });
}

/**
 * Parse semantic commit message (Conventional Commits)
 * @param {string} message - Commit message
 * @returns {Object} Parsed commit { type, scope, breaking, subject }
 */
function parseConventionalCommit(message) {
  // Pattern: type(scope)!: subject
  const pattern = /^(\w+)(?:\(([^)]+)\))?(!)?: (.+)$/;
  const match = message.match(pattern);

  if (!match) {
    return {
      type: null,
      scope: null,
      breaking: false,
      subject: message,
      conventional: false,
    };
  }

  return {
    type: match[1],
    scope: match[2] || null,
    breaking: match[3] === '!',
    subject: match[4],
    conventional: true,
  };
}

/**
 * Get detailed commit information with async git calls
 * @param {string} commitRange - Git commit range (e.g., "origin/main..HEAD")
 * @returns {Promise<Array<Object>>} Array of commit objects
 */
async function getCommits(commitRange) {
  const format = '%H%n%h%n%an%n%ae%n%at%n%s%n%b%n---COMMIT-END---';
  const output = await gitAsync(`log ${commitRange} --format="${format}"`, false);

  if (!output) {
    return [];
  }

  const commits = [];
  const commitBlocks = output.split('---COMMIT-END---').filter((b) => b.trim());

  for (const block of commitBlocks) {
    const lines = block.trim().split('\n');
    if (lines.length < 6) continue;

    const commit = {
      hash: lines[0],
      shortHash: lines[1],
      author: lines[2],
      email: lines[3],
      timestamp: parseInt(lines[4]),
      subject: lines[5],
      body: lines.slice(6).join('\n').trim(),
    };

    // Add semantic parsing
    if (config.semanticParsing) {
      commit.semantic = parseConventionalCommit(commit.subject);
    }

    // Add diff stats if enabled
    if (config.diffAnalysis) {
      try {
        const stats = await gitAsync(`show ${commit.hash} --stat --format=""`, false);
        if (stats) {
          const lines = stats.trim().split('\n');
          const summary = lines[lines.length - 1] || '';

          // Parse: "3 files changed, 45 insertions(+), 12 deletions(-)"
          const filesMatch = summary.match(/(\d+) files? changed/);
          const insertMatch = summary.match(/(\d+) insertions?/);
          const deleteMatch = summary.match(/(\d+) deletions?/);

          commit.stats = {
            filesChanged: filesMatch ? parseInt(filesMatch[1]) : 0,
            insertions: insertMatch ? parseInt(insertMatch[1]) : 0,
            deletions: deleteMatch ? parseInt(deleteMatch[1]) : 0,
          };
        }
      } catch {
        logger.warn(`Failed to get stats for commit ${commit.shortHash}`);
        commit.stats = null;
      }
    }

    commits.push(commit);
  }

  logger.info(`Retrieved ${commits.length} commits`, { count: commits.length });
  return commits;
}

/**
 * Display commits in a formatted table
 * @param {Array<Object>} commits - Array of commit objects
 */
function displayCommits(commits) {
  printHeader('Commits Ahead of Upstream');

  for (let i = 0; i < commits.length; i++) {
    const commit = commits[i];
    const date = new Date(commit.timestamp * 1000).toLocaleString();

    print(`Commit ${i + 1}/${commits.length}:`, 'bright');
    print(`  SHA:     ${commit.shortHash}`, 'yellow');
    print(`  Author:  ${commit.author} <${commit.email}>`, 'dim');
    print(`  Date:    ${date}`, 'dim');

    // Show semantic info if available
    if (commit.semantic && commit.semantic.conventional) {
      const { type, scope, breaking } = commit.semantic;
      const typeStr = scope ? `${type}(${scope})` : type;
      const breakingStr = breaking ? ' [BREAKING]' : '';
      print(`  Type:    ${typeStr}${breakingStr}`, 'magenta');
    }

    print(`  Subject: ${commit.subject}`, 'green');

    if (commit.body) {
      print(`  Body:`, 'dim');
      commit.body.split('\n').forEach((line) => {
        print(`    ${line}`, 'dim');
      });
    }

    // Show stats if available
    if (commit.stats) {
      const { filesChanged, insertions, deletions } = commit.stats;
      print(`  Changes: ${filesChanged} files, +${insertions} -${deletions}`, 'cyan');
    }

    console.log();
  }
}

/**
 * Analyze commits and generate recommendation with advanced heuristics
 * @param {Array<Object>} commits - Array of commit objects
 * @returns {Object} Recommendation object with strategy and reason
 */
function analyzeCommits(commits) {
  logger.info('Analyzing commits for squashing recommendation');

  // Check if all commits are from the same author
  const authors = new Set(commits.map((c) => c.email));
  const singleAuthor = authors.size === 1;

  // Check if commits look like incremental work (WIP, fix, update, etc.)
  const wipKeywords = config.wipKeywords;
  const wipCommits = commits.filter((c) =>
    wipKeywords.some((kw) => c.subject.toLowerCase().includes(kw))
  );

  // Check if commits are closely spaced
  let closelySpaced = true;
  if (commits.length > 1) {
    const timestamps = commits.map((c) => c.timestamp);
    const maxGap = Math.max(...timestamps) - Math.min(...timestamps);
    closelySpaced = maxGap < config.timeThreshold;
  }

  // Semantic commit analysis
  let semanticInfo = null;
  if (config.semanticParsing) {
    const conventionalCommits = commits.filter((c) => c.semantic && c.semantic.conventional);
    const uniqueTypes = new Set(conventionalCommits.map((c) => c.semantic.type));
    const hasBreaking = commits.some((c) => c.semantic && c.semantic.breaking);

    semanticInfo = {
      conventionalCount: conventionalCommits.length,
      uniqueTypes: Array.from(uniqueTypes),
      hasBreaking,
      allConventional: conventionalCommits.length === commits.length,
    };
  }

  // Diff size analysis
  let diffInfo = null;
  if (config.diffAnalysis) {
    const totalFiles = commits.reduce((sum, c) => sum + (c.stats?.filesChanged || 0), 0);
    const totalInsertions = commits.reduce((sum, c) => sum + (c.stats?.insertions || 0), 0);
    const totalDeletions = commits.reduce((sum, c) => sum + (c.stats?.deletions || 0), 0);
    const avgSize = (totalInsertions + totalDeletions) / commits.length;

    diffInfo = {
      totalFiles,
      totalInsertions,
      totalDeletions,
      avgSize,
      largeChanges: avgSize > 100, // Large if avg > 100 lines changed
    };
  }

  // Generate recommendation with enhanced logic
  if (commits.length === 1) {
    return {
      strategy: 'keep',
      reason: 'Only one commit - no squashing needed',
      confidence: 'high',
      details: null,
    };
  }

  // If all commits are conventional with different types, recommend keeping separate
  if (semanticInfo && semanticInfo.allConventional && semanticInfo.uniqueTypes.length > 1) {
    return {
      strategy: 'keep',
      reason: `All commits follow Conventional Commits with ${semanticInfo.uniqueTypes.length} different types (${semanticInfo.uniqueTypes.join(', ')}). Recommend keeping for semantic history.`,
      confidence: 'high',
      details: semanticInfo,
    };
  }

  // If there's a breaking change, recommend interactive review
  if (semanticInfo && semanticInfo.hasBreaking) {
    return {
      strategy: 'interactive',
      reason:
        'Breaking change detected. Review commits interactively to preserve important markers.',
      confidence: 'high',
      details: semanticInfo,
    };
  }

  // If majority are WIP commits from single author, recommend squashing
  if (singleAuthor && wipCommits.length > commits.length / 2) {
    return {
      strategy: 'squash-all',
      reason: `${wipCommits.length}/${commits.length} commits appear to be incremental work (WIP/fix/update). Squashing recommended for clean history.`,
      confidence: 'high',
      details: { wipCommits: wipCommits.length, totalCommits: commits.length },
    };
  }

  // If single author and closely spaced, recommend squashing
  if (singleAuthor && closelySpaced) {
    const timeSpan =
      Math.max(...commits.map((c) => c.timestamp)) - Math.min(...commits.map((c) => c.timestamp));
    const hours = Math.floor(timeSpan / 3600);
    const minutes = Math.floor((timeSpan % 3600) / 60);

    return {
      strategy: 'squash-all',
      reason: `All commits from same author within ${hours}h ${minutes}m - likely single feature/fix.`,
      confidence: 'medium',
      details: { timeSpan, singleAuthor },
    };
  }

  // If multiple authors, recommend keeping separate
  if (!singleAuthor) {
    return {
      strategy: 'keep',
      reason: `Multiple authors detected (${authors.size}). Consider keeping separate commits for attribution.`,
      confidence: 'medium',
      details: { authorCount: authors.size },
    };
  }

  // If large changes spread across commits, recommend interactive
  if (diffInfo && diffInfo.largeChanges) {
    return {
      strategy: 'interactive',
      reason: `Large changes detected (${diffInfo.totalFiles} files, ±${diffInfo.totalInsertions + diffInfo.totalDeletions} lines). Interactive review recommended.`,
      confidence: 'medium',
      details: diffInfo,
    };
  }

  // Default to interactive for mixed scenarios
  return {
    strategy: 'interactive',
    reason: 'Mixed commit types detected. Interactive squash recommended to review each commit.',
    confidence: 'low',
    details: null,
  };
}

/**
 * Display recommendation to user
 * @param {Object} recommendation - Recommendation object
 */
function displayRecommendation(recommendation) {
  printHeader('Recommendation');

  const strategyNames = {
    'squash-all': 'Squash all commits into one',
    interactive: 'Use interactive squash (review each commit)',
    keep: 'Keep commits separate',
  };

  print(`Strategy: ${strategyNames[recommendation.strategy]}`, 'bright');
  print(`Reason:   ${recommendation.reason}`, 'white');
  print(
    `Confidence: ${recommendation.confidence.toUpperCase()}`,
    recommendation.confidence === 'high'
      ? 'green'
      : recommendation.confidence === 'medium'
        ? 'yellow'
        : 'red'
  );

  if (recommendation.details) {
    print(`Details:  ${JSON.stringify(recommendation.details, null, 2)}`, 'dim');
  }

  console.log();

  logger.info('Recommendation generated', recommendation);
}

/**
 * Check if branch is shared with remote
 * @param {string} branch - Branch name
 * @returns {Promise<boolean>} True if branch exists on remote
 */
async function isBranchShared(branch) {
  try {
    const remoteBranch = await gitAsync(`rev-parse --verify origin/${branch}`, false);
    return remoteBranch !== null;
  } catch {
    return false;
  }
}

/**
 * Show force push warning
 * @param {string} branch - Branch name
 * @returns {Promise<boolean>} True if user confirms, false otherwise
 */
async function showForcePushWarning(branch) {
  if (!config.forcePushWarning.enabled) {
    return true;
  }

  printHeader('⚠️  Force Push Warning');

  print('After interactive rebase, you will need to force push.', 'yellow');
  print('', 'reset');
  print('IMPORTANT CONSIDERATIONS:', 'bright');
  print('  • Force pushing rewrites history on the remote branch', 'red');
  print('  • This can cause problems for collaborators who have pulled your branch', 'red');
  print('  • Always use --force-with-lease instead of --force for safety', 'yellow');
  print('', 'reset');

  // Check if branch is shared
  if (config.forcePushWarning.checkRemoteChanges) {
    const isShared = await isBranchShared(branch);

    if (isShared) {
      print('⚠️  This branch exists on the remote and may be shared!', 'red');
      print('', 'reset');
      print('BEFORE FORCE PUSHING:', 'bright');
      print('  1. Communicate with your team about the rebase', 'white');
      print('  2. Ensure no one else is working on this branch', 'white');
      print('  3. Use: git push --force-with-lease origin ' + branch, 'cyan');
      print('', 'reset');
    } else {
      print('✓ This appears to be a local-only branch', 'green');
      print('  Safe to force push after rebase', 'white');
      print('', 'reset');
    }
  }

  if (config.forcePushWarning.requireConfirmation) {
    const confirmation = await askQuestion(
      'Do you understand the risks of force pushing? [yes/no]: ',
      {
        pattern: /^(yes|no)$/i,
        allowEmpty: false,
      }
    );

    if (confirmation.toLowerCase() !== 'yes') {
      print('✗ Force push not confirmed. Aborting.', 'red');
      return false;
    }
  }

  console.log();
  return true;
}

/**
 * Get user choice for squashing
 * @param {string} recommendedStrategy - Recommended strategy
 * @returns {Promise<string>} User's choice
 */
async function getUserChoice(recommendedStrategy) {
  printHeader('Squashing Options');

  print('1. Squash all commits into one (clean history)', 'green');
  print('2. Interactive squash (review and choose what to squash)', 'yellow');
  print('3. Keep commits separate (proceed with push)', 'blue');
  print('4. Cancel push (abort operation)', 'red');
  console.log();

  const defaultChoice =
    recommendedStrategy === 'squash-all'
      ? '1'
      : recommendedStrategy === 'interactive'
        ? '2'
        : recommendedStrategy === 'keep'
          ? '3'
          : '1';

  print(`Recommended: Option ${defaultChoice}`, 'bright');
  console.log();

  const choice = await askQuestion(`Enter choice [1-4] (default: ${defaultChoice}): `, {
    pattern: /^[1-4]?$/,
    allowEmpty: true,
  });

  return choice || defaultChoice;
}

/**
 * Squash all commits into one
 * @param {string} upstreamBranch - Upstream branch name
 * @param {Array<Object>} commits - Array of commits to squash
 */
async function squashAll(upstreamBranch, commits) {
  printHeader('Squashing All Commits');

  try {
    // Get the base commit
    const baseCommit = await gitAsync(`rev-parse ${upstreamBranch}`);

    print(`Step 1: Soft reset to ${upstreamBranch}...`, 'yellow');
    await gitAsync(`reset --soft ${baseCommit}`);
    print('✓ Reset complete', 'green');
    console.log();

    print('Step 2: Create new squashed commit...', 'yellow');

    // Generate commit message from all commits
    const messages = commits
      .reverse()
      .map((c, i) => {
        return `${i + 1}. ${c.subject}`;
      })
      .join('\n');

    const newMessage = `Squashed ${commits.length} commits:\n\n${messages}`;

    print('New commit message:', 'dim');
    print(newMessage, 'white');
    console.log();

    // Prompt for custom message with validation
    const useCustom = await askQuestion('Use custom commit message? [y/N]: ', {
      pattern: /^[ynYN]?$/,
      allowEmpty: true,
    });

    let finalMessage = newMessage;
    if (useCustom.toLowerCase() === 'y' || useCustom.toLowerCase() === 'yes') {
      print('Enter commit message:', 'yellow');
      const customMessage = await askQuestion('> ', {
        minLength: config.inputValidation.minCommitMessageLength,
        maxLength: config.inputValidation.maxCommitMessageLength,
        forbiddenChars: config.inputValidation.forbiddenCharacters,
        allowEmpty: false,
      });

      if (customMessage) {
        finalMessage = customMessage;
      }
    }

    // Create the squashed commit
    const escapedMessage = finalMessage.replace(/"/g, '\\"').replace(/\$/g, '\\$');
    await gitAsync(`commit -m "${escapedMessage}"`);
    print('✓ Squashed commit created', 'green');
    console.log();

    // Show the new commit
    print('New commit:', 'bright');
    const newCommit = await gitAsync('log -1 --oneline');
    print(newCommit, 'green');
    console.log();

    printHeader('✓ Squash Complete');
    print('All commits have been squashed into one.', 'green');
    print('You can now push with: git push', 'white');

    logger.info('Squash all completed successfully');
  } catch (error) {
    print('✗ Error during squashing:', 'red');
    print(error.message, 'red');
    print('Your repository state has been preserved.', 'yellow');
    logger.error('Squash all failed', { error: error.message });
    throw error;
  }
}

/**
 * Interactive squash using git rebase -i
 * @param {string} upstreamBranch - Upstream branch name
 * @param {string} currentBranch - Current branch name
 */
async function interactiveSquash(upstreamBranch, currentBranch) {
  printHeader('Interactive Squash');

  // Show force push warning
  const confirmed = await showForcePushWarning(currentBranch);
  if (!confirmed) {
    throw new Error('Force push not confirmed');
  }

  print('Opening interactive rebase...', 'yellow');
  print('Instructions:', 'bright');
  print('  - pick = keep commit as-is', 'white');
  print('  - squash (s) = merge with previous commit', 'white');
  print('  - fixup (f) = merge with previous, discard message', 'white');
  print('  - drop (d) = remove commit', 'white');
  console.log();

  try {
    // Run interactive rebase (must be sync for stdio: 'inherit')
    execSync(`git rebase -i ${upstreamBranch}`, { stdio: 'inherit' });

    printHeader('✓ Interactive Squash Complete');
    print('Commits have been rebased.', 'green');
    print('You can now push with: git push --force-with-lease', 'white');

    logger.info('Interactive squash completed successfully');
  } catch (error) {
    print('✗ Interactive rebase cancelled or failed', 'red');
    print('Your repository state has been preserved.', 'yellow');
    logger.error('Interactive squash failed', { error: error.message });
    throw error;
  }
}

/**
 * Main hook execution
 */
async function main() {
  try {
    logger.info('=== Pre-push hook started ===');
    printHeader('Pre-Push Commit Squashing Hook (Enhanced)');

    // Check if we're in a git repository
    const isRepo = await gitAsync('rev-parse --is-inside-work-tree', false);
    if (!isRepo) {
      print('✗ Not in a git repository', 'red');
      logger.error('Not in a git repository');
      process.exit(2);
    }

    // Get current branch
    const currentBranch = await gitAsync('rev-parse --abbrev-ref HEAD', false);
    if (!currentBranch || currentBranch === 'HEAD') {
      print('✗ Detached HEAD state detected', 'red');
      print('Please checkout a branch before pushing.', 'yellow');
      logger.error('Detached HEAD state');
      process.exit(2);
    }

    print(`Current branch: ${currentBranch}`, 'cyan');
    logger.info(`Current branch: ${currentBranch}`);

    // Get upstream branch
    const upstreamBranch = await gitAsync(
      `rev-parse --abbrev-ref ${currentBranch}@{upstream}`,
      false
    );
    if (!upstreamBranch) {
      print('✗ No upstream branch configured', 'yellow');
      print('This appears to be the first push. Proceeding...', 'green');
      logger.info('No upstream branch - first push');
      process.exit(0); // Allow first push
    }

    print(`Upstream branch: ${upstreamBranch}`, 'cyan');
    logger.info(`Upstream branch: ${upstreamBranch}`);
    console.log();

    // Get commits ahead of upstream
    const commits = await getCommits(`${upstreamBranch}..HEAD`);

    if (commits.length === 0) {
      print('✓ No commits ahead of upstream', 'green');
      print('Nothing to push.', 'dim');
      logger.info('No commits to push');
      process.exit(0);
    }

    if (commits.length === 1) {
      print('✓ Only one commit ahead of upstream', 'green');
      print('No squashing needed. Proceeding with push...', 'dim');
      logger.info('Single commit - no squashing needed');
      process.exit(0);
    }

    // Multiple commits detected - show them
    displayCommits(commits);

    // Analyze and recommend
    const recommendation = analyzeCommits(commits);
    displayRecommendation(recommendation);

    // Get user choice
    const choice = await getUserChoice(recommendation.strategy);

    console.log();
    logger.info(`User chose option: ${choice}`);

    switch (choice) {
      case '1': // Squash all
        await squashAll(upstreamBranch, commits);
        print('Push cancelled - please run push again after squashing.', 'yellow');
        logger.info('Squash all completed - push blocked');
        process.exit(1); // Block this push, user needs to push again
        break;

      case '2': // Interactive squash
        await interactiveSquash(upstreamBranch, currentBranch);
        print('Push cancelled - please run push again after rebasing.', 'yellow');
        logger.info('Interactive squash completed - push blocked');
        process.exit(1); // Block this push, user needs to push again
        break;

      case '3': // Keep separate
        print('✓ Keeping commits separate', 'green');
        print('Proceeding with push...', 'dim');
        logger.info('User chose to keep commits separate');
        process.exit(0); // Allow push
        break;

      case '4': // Cancel
        print('✗ Push cancelled by user', 'red');
        logger.info('Push cancelled by user');
        process.exit(1); // Block push
        break;

      default:
        print('✗ Invalid choice', 'red');
        logger.error('Invalid choice selected');
        process.exit(1);
    }
  } catch (error) {
    console.error();
    print('✗ Error executing pre-push hook:', 'red');
    print(error.message, 'red');
    if (error.stack) {
      print(error.stack, 'dim');
    }
    logger.error('Hook execution failed', {
      error: error.message,
      stack: error.stack,
    });
    process.exit(2);
  }
}

// Run main function
main();
