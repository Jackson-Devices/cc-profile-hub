#!/usr/bin/env node

/**
 * Claude Code Comprehensive Logging Hook
 *
 * Captures all Claude Code activity for performance analysis, debugging,
 * and optimization. Tracks messages, tool usage, tokens, thinking, and more.
 *
 * Features:
 * - All 7 hook events (beforeMessage, afterMessage, beforeToolUse, afterToolUse,
 *   onTokenUsage, onThinking, onStreamChunk)
 * - Comprehensive token tracking with detailed breakdowns
 * - Privacy-first design with secret redaction
 * - Configurable verbosity levels
 * - Zero-overhead JSON Lines logging
 *
 * Installation: See LOGGING_INSTALLATION.md
 * Usage Guide: See LOGGING_GUIDE.md
 */

import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';
import os from 'os';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

// ═══════════════════════════════════════════════════════════════════════════
// Configuration
// ═══════════════════════════════════════════════════════════════════════════

const CONFIG_PATH = path.join(os.homedir(), '.claude', 'logging_config.json');
const DEFAULT_CONFIG = {
  // Verbosity: minimal (errors only), normal (key events), verbose (everything)
  verbosity: 'normal',

  // Privacy: redact sensitive data by default
  privacy: {
    enabled: true,
    redactSecrets: true,
    redactPaths: true, // Redact full file paths, keep only filenames
    redactEnvVars: true,
    allowList: [], // Patterns that should NOT be redacted (e.g., "MY_PUBLIC_VAR")
  },

  // Token tracking
  tokens: {
    trackPerTool: true,
    trackPerMessage: true,
    trackCumulative: true,
    estimateCost: true, // Estimate cost based on model pricing
    warnThreshold: 50000, // Warn if single message uses this many tokens
  },

  // Log file settings
  logFile: {
    directory: '.ai_logs',
    filenamePattern: 'session_{timestamp}.jsonl',
    rotateSize: 10 * 1024 * 1024, // 10MB - start new file
    keepLast: 10, // Keep last 10 session files
  },

  // Performance tracking
  performance: {
    trackDuration: true,
    trackMemory: false, // Track memory usage (can be noisy)
    slowToolThreshold: 5000, // Warn if tool takes longer than 5s
  },
};

// ═══════════════════════════════════════════════════════════════════════════
// Global State
// ═══════════════════════════════════════════════════════════════════════════

let config = DEFAULT_CONFIG;
let sessionId = null;
let logFilePath = null;
let sessionStartTime = null;
let cumulativeTokens = {
  prompt: 0,
  completion: 0,
  total: 0,
  byTool: {},
  byMessage: [],
};
let messageCounter = 0;
let toolCallStack = {}; // Track tool calls in progress

// ═══════════════════════════════════════════════════════════════════════════
// Configuration Loading
// ═══════════════════════════════════════════════════════════════════════════

function loadConfig() {
  try {
    if (fs.existsSync(CONFIG_PATH)) {
      const userConfig = JSON.parse(fs.readFileSync(CONFIG_PATH, 'utf8'));
      config = deepMerge(DEFAULT_CONFIG, userConfig);
    } else {
      // Create default config file
      const configDir = path.dirname(CONFIG_PATH);
      if (!fs.existsSync(configDir)) {
        fs.mkdirSync(configDir, { recursive: true });
      }
      fs.writeFileSync(CONFIG_PATH, JSON.stringify(DEFAULT_CONFIG, null, 2));
      config = DEFAULT_CONFIG;
    }
  } catch {
    // Fail silently, use defaults
    config = DEFAULT_CONFIG;
  }
}

function deepMerge(target, source) {
  const output = { ...target };
  for (const key in source) {
    if (source[key] && typeof source[key] === 'object' && !Array.isArray(source[key])) {
      output[key] = deepMerge(target[key] || {}, source[key]);
    } else {
      output[key] = source[key];
    }
  }
  return output;
}

// ═══════════════════════════════════════════════════════════════════════════
// Session Management
// ═══════════════════════════════════════════════════════════════════════════

function initializeSession() {
  if (sessionId) return; // Already initialized

  sessionId = generateSessionId();
  sessionStartTime = Date.now();

  // Determine log file path
  const timestamp = new Date().toISOString().replace(/:/g, '-').replace(/\..+/, '');
  const filename = config.logFile.filenamePattern.replace('{timestamp}', timestamp);

  // Find repository root (look for .git directory)
  const repoRoot = findRepoRoot(process.cwd());
  const logDir = repoRoot
    ? path.join(repoRoot, config.logFile.directory)
    : path.join(process.cwd(), config.logFile.directory);

  if (!fs.existsSync(logDir)) {
    fs.mkdirSync(logDir, { recursive: true });
  }

  logFilePath = path.join(logDir, filename);

  // Write session start marker
  writeLog({
    event: 'session_start',
    sessionId,
    timestamp: new Date().toISOString(),
    config: sanitizeConfig(config),
    environment: {
      node: process.version,
      platform: process.platform,
      arch: process.arch,
      cwd: config.privacy.redactPaths ? path.basename(process.cwd()) : process.cwd(),
    },
  });

  // Cleanup old log files
  cleanupOldLogs(logDir);
}

function generateSessionId() {
  return `sess_${Date.now()}_${Math.random().toString(36).substring(2, 9)}`;
}

function findRepoRoot(startPath) {
  let currentPath = startPath;
  while (currentPath !== path.dirname(currentPath)) {
    if (fs.existsSync(path.join(currentPath, '.git'))) {
      return currentPath;
    }
    currentPath = path.dirname(currentPath);
  }
  return null;
}

function sanitizeConfig(cfg) {
  // Remove sensitive data from config before logging
  const sanitized = JSON.parse(JSON.stringify(cfg));
  if (sanitized.privacy && sanitized.privacy.allowList) {
    sanitized.privacy.allowList = ['<redacted>'];
  }
  return sanitized;
}

function cleanupOldLogs(logDir) {
  try {
    const files = fs
      .readdirSync(logDir)
      .filter((f) => f.startsWith('session_') && f.endsWith('.jsonl'))
      .map((f) => ({
        name: f,
        path: path.join(logDir, f),
        mtime: fs.statSync(path.join(logDir, f)).mtime,
      }))
      .sort((a, b) => b.mtime - a.mtime);

    // Keep only the last N files
    const filesToDelete = files.slice(config.logFile.keepLast);
    filesToDelete.forEach((file) => {
      fs.unlinkSync(file.path);
    });
  } catch {
    // Fail silently
  }
}

// ═══════════════════════════════════════════════════════════════════════════
// Privacy & Redaction
// ═══════════════════════════════════════════════════════════════════════════

const SECRET_PATTERNS = [
  // API Keys and tokens
  /\b(sk|pk)_[a-zA-Z0-9]{32,}\b/gi,
  /\bghp_[a-zA-Z0-9]{36,}\b/gi,
  /\bgho_[a-zA-Z0-9]{36,}\b/gi,
  /\bAKIA[0-9A-Z]{16}\b/gi,
  /\b[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}\b/gi, // UUIDs that might be tokens

  // Common secret environment variables
  /\b(API_KEY|SECRET|PASSWORD|TOKEN|PRIVATE_KEY|AUTH)\s*[:=]\s*[^\s,}]+/gi,

  // AWS secrets
  /aws_secret_access_key\s*[:=]\s*[^\s,}]+/gi,

  // SSH private keys
  /-----BEGIN[A-Z\s]+PRIVATE KEY-----[\s\S]+?-----END[A-Z\s]+PRIVATE KEY-----/gi,

  // JWT tokens
  /eyJ[a-zA-Z0-9_-]+\.eyJ[a-zA-Z0-9_-]+\.[a-zA-Z0-9_-]+/gi,
];

function redactSecrets(text) {
  if (!config.privacy.enabled || !config.privacy.redactSecrets) {
    return text;
  }

  if (typeof text !== 'string') {
    return text;
  }

  let redacted = text;

  // Apply secret patterns
  SECRET_PATTERNS.forEach((pattern) => {
    redacted = redacted.replace(pattern, '[REDACTED]');
  });

  return redacted;
}

function redactPaths(text) {
  if (!config.privacy.enabled || !config.privacy.redactPaths) {
    return text;
  }

  if (typeof text !== 'string') {
    return text;
  }

  // Redact full paths, keep only filename
  // Handles both Unix and Windows paths
  return text.replace(/([/\\][\w\-. ]+)+([/\\][\w\-.]+)/g, (match) => {
    const parts = match.split(/[/\\]/);
    return parts[parts.length - 1] || match;
  });
}

function sanitizeData(data) {
  if (!config.privacy.enabled) {
    return data;
  }

  // Deep clone to avoid mutating original
  let sanitized = JSON.parse(JSON.stringify(data));

  // Recursively sanitize
  function sanitizeRecursive(obj) {
    if (typeof obj === 'string') {
      let result = obj;
      result = redactSecrets(result);
      result = redactPaths(result);
      return result;
    }

    if (Array.isArray(obj)) {
      return obj.map(sanitizeRecursive);
    }

    if (obj && typeof obj === 'object') {
      const result = {};
      for (const [key, value] of Object.entries(obj)) {
        // Redact known sensitive keys
        if (
          config.privacy.redactEnvVars &&
          /^(.*_)?(API_KEY|SECRET|PASSWORD|TOKEN|AUTH)(_.*)?$/i.test(key)
        ) {
          result[key] = '[REDACTED]';
        } else {
          result[key] = sanitizeRecursive(value);
        }
      }
      return result;
    }

    return obj;
  }

  return sanitizeRecursive(sanitized);
}

// ═══════════════════════════════════════════════════════════════════════════
// Token Tracking
// ═══════════════════════════════════════════════════════════════════════════

function trackTokens(eventData) {
  if (!config.tokens.trackCumulative) {
    return;
  }

  const { prompt = 0, completion = 0, total = 0 } = eventData.tokens || {};

  cumulativeTokens.prompt += prompt;
  cumulativeTokens.completion += completion;
  cumulativeTokens.total += total;

  // Track per message
  if (config.tokens.trackPerMessage) {
    cumulativeTokens.byMessage.push({
      messageId: messageCounter,
      timestamp: new Date().toISOString(),
      tokens: { prompt, completion, total },
    });
  }

  // Warn if threshold exceeded
  if (config.tokens.warnThreshold && total > config.tokens.warnThreshold) {
    writeLog({
      event: 'token_warning',
      level: 'warn',
      message: `Message used ${total} tokens (threshold: ${config.tokens.warnThreshold})`,
      messageId: messageCounter,
      tokens: { prompt, completion, total },
    });
  }
}

function trackToolTokens(toolName, tokens) {
  if (!config.tokens.trackPerTool) {
    return;
  }

  if (!cumulativeTokens.byTool[toolName]) {
    cumulativeTokens.byTool[toolName] = {
      count: 0,
      totalTokens: 0,
    };
  }

  cumulativeTokens.byTool[toolName].count += 1;
  cumulativeTokens.byTool[toolName].totalTokens += tokens.total || 0;
}

function estimateCost(tokens) {
  if (!config.tokens.estimateCost) {
    return null;
  }

  // Pricing as of 2025-01 (adjust as needed)
  // Claude Sonnet 4.5: $3/MTok input, $15/MTok output
  const INPUT_COST_PER_MTOK = 3.0;
  const OUTPUT_COST_PER_MTOK = 15.0;

  const inputCost = (tokens.prompt / 1_000_000) * INPUT_COST_PER_MTOK;
  const outputCost = (tokens.completion / 1_000_000) * OUTPUT_COST_PER_MTOK;

  return {
    input: inputCost.toFixed(6),
    output: outputCost.toFixed(6),
    total: (inputCost + outputCost).toFixed(6),
    currency: 'USD',
  };
}

// ═══════════════════════════════════════════════════════════════════════════
// Logging Functions
// ═══════════════════════════════════════════════════════════════════════════

function writeLog(entry) {
  initializeSession();

  // Skip based on verbosity
  const level = entry.level || 'info';
  if (
    config.verbosity === 'minimal' &&
    level !== 'error' &&
    entry.event !== 'session_start' &&
    entry.event !== 'session_end'
  ) {
    return;
  }

  // Sanitize entry
  const sanitized = sanitizeData(entry);

  // Add standard fields
  const logEntry = {
    sessionId,
    timestamp: new Date().toISOString(),
    elapsedMs: sessionStartTime ? Date.now() - sessionStartTime : 0,
    ...sanitized,
  };

  // Write as JSON Lines format
  try {
    fs.appendFileSync(logFilePath, JSON.stringify(logEntry) + '\n');
  } catch (error) {
    // Fail silently - don't break the workflow
    console.error('Logging error:', error.message);
  }
}

// ═══════════════════════════════════════════════════════════════════════════
// Hook Event Handlers
// ═══════════════════════════════════════════════════════════════════════════

function handleBeforeMessage(data) {
  messageCounter++;

  writeLog({
    event: 'beforeMessage',
    messageId: messageCounter,
    level: 'info',
    data:
      config.verbosity === 'verbose'
        ? {
            messageLength: JSON.stringify(data).length,
            conversationTurn: messageCounter,
            preview: JSON.stringify(data).substring(0, 200),
          }
        : {
            messageLength: JSON.stringify(data).length,
            conversationTurn: messageCounter,
          },
  });
}

function handleAfterMessage(data) {
  const tokens = data?.usage || data?.tokens || {};

  trackTokens({ tokens });

  writeLog({
    event: 'afterMessage',
    messageId: messageCounter,
    level: 'info',
    data: {
      tokens,
      estimatedCost: estimateCost(tokens),
      responseLength: JSON.stringify(data).length,
      toolCallsCount: data?.toolCalls?.length || 0,
    },
  });
}

function handleBeforeToolUse(data) {
  const toolId = data?.toolUseId || `tool_${Date.now()}`;
  const toolName = data?.name || data?.tool || 'unknown';

  toolCallStack[toolId] = {
    name: toolName,
    startTime: Date.now(),
    params: data?.input || data?.parameters || {},
  };

  if (config.verbosity === 'verbose') {
    writeLog({
      event: 'beforeToolUse',
      messageId: messageCounter,
      toolId,
      toolName,
      level: 'debug',
      data: {
        parameters: data?.input || data?.parameters || {},
      },
    });
  } else {
    writeLog({
      event: 'beforeToolUse',
      messageId: messageCounter,
      toolId,
      toolName,
      level: 'info',
      data: {
        parameterCount: Object.keys(data?.input || data?.parameters || {}).length,
      },
    });
  }
}

function handleAfterToolUse(data) {
  const toolId = data?.toolUseId || `tool_${Date.now()}`;
  const toolName = data?.name || data?.tool || 'unknown';
  const startTime = toolCallStack[toolId]?.startTime || Date.now();
  const durationMs = Date.now() - startTime;

  // Track tool-specific tokens (estimate based on result size)
  const resultSize = JSON.stringify(data?.result || {}).length;
  const estimatedTokens = Math.ceil(resultSize / 4); // Rough estimate: 4 chars per token
  trackToolTokens(toolName, { total: estimatedTokens });

  // Warn if slow
  if (config.performance.trackDuration && durationMs > config.performance.slowToolThreshold) {
    writeLog({
      event: 'performance_warning',
      level: 'warn',
      message: `Tool ${toolName} took ${durationMs}ms (threshold: ${config.performance.slowToolThreshold}ms)`,
      toolName,
      durationMs,
    });
  }

  writeLog({
    event: 'afterToolUse',
    messageId: messageCounter,
    toolId,
    toolName,
    level: 'info',
    data: {
      durationMs,
      success: !data?.error,
      resultSize,
      estimatedTokens,
    },
  });

  // Cleanup stack
  delete toolCallStack[toolId];
}

function handleOnTokenUsage(data) {
  trackTokens({ tokens: data });

  writeLog({
    event: 'onTokenUsage',
    messageId: messageCounter,
    level: 'info',
    data: {
      tokens: data,
      cumulative: {
        ...cumulativeTokens,
        byMessage: undefined, // Don't duplicate large array
        estimatedCost: estimateCost(cumulativeTokens),
      },
    },
  });
}

function handleOnThinking(data) {
  if (config.verbosity !== 'verbose') {
    return; // Only log thinking in verbose mode
  }

  writeLog({
    event: 'onThinking',
    messageId: messageCounter,
    level: 'debug',
    data: {
      thinkingLength: JSON.stringify(data).length,
      preview: JSON.stringify(data).substring(0, 500),
    },
  });
}

function handleOnStreamChunk(data) {
  if (config.verbosity !== 'verbose') {
    return; // Only log stream chunks in verbose mode
  }

  writeLog({
    event: 'onStreamChunk',
    messageId: messageCounter,
    level: 'debug',
    data: {
      chunkSize: JSON.stringify(data).length,
    },
  });
}

// ═══════════════════════════════════════════════════════════════════════════
// Session End Handler
// ═══════════════════════════════════════════════════════════════════════════

function handleSessionEnd() {
  writeLog({
    event: 'session_end',
    level: 'info',
    sessionDurationMs: sessionStartTime ? Date.now() - sessionStartTime : 0,
    summary: {
      totalMessages: messageCounter,
      tokens: {
        ...cumulativeTokens,
        byMessage: undefined, // Don't duplicate
        estimatedCost: estimateCost(cumulativeTokens),
      },
      topTools: Object.entries(cumulativeTokens.byTool)
        .sort((a, b) => b[1].count - a[1].count)
        .slice(0, 10)
        .map(([name, stats]) => ({ name, ...stats })),
    },
  });
}

// Register cleanup handlers
process.on('exit', handleSessionEnd);
process.on('SIGINT', () => {
  handleSessionEnd();
  process.exit(0);
});
process.on('SIGTERM', () => {
  handleSessionEnd();
  process.exit(0);
});

// ═══════════════════════════════════════════════════════════════════════════
// Main Entry Point
// ═══════════════════════════════════════════════════════════════════════════

function main() {
  loadConfig();

  const hookEvent = process.argv[2];
  const inputData = process.argv[3] ? JSON.parse(process.argv[3]) : {};

  // Route to appropriate handler
  switch (hookEvent) {
    case 'beforeMessage':
      handleBeforeMessage(inputData);
      break;
    case 'afterMessage':
      handleAfterMessage(inputData);
      break;
    case 'beforeToolUse':
      handleBeforeToolUse(inputData);
      break;
    case 'afterToolUse':
      handleAfterToolUse(inputData);
      break;
    case 'onTokenUsage':
      handleOnTokenUsage(inputData);
      break;
    case 'onThinking':
      handleOnThinking(inputData);
      break;
    case 'onStreamChunk':
      handleOnStreamChunk(inputData);
      break;
    default:
      console.error(`Unknown hook event: ${hookEvent}`);
      process.exit(1);
  }

  // Exit successfully
  process.exit(0);
}

// Run if called directly
if (import.meta.url === `file://${process.argv[1]}`) {
  main();
}

export {
  loadConfig,
  writeLog,
  handleBeforeMessage,
  handleAfterMessage,
  handleBeforeToolUse,
  handleAfterToolUse,
  handleOnTokenUsage,
  handleOnThinking,
  handleOnStreamChunk,
};
