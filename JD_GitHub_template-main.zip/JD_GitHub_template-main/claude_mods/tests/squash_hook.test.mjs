#!/usr/bin/env node

/**
 * Unit tests for Enhanced Pre-Push Commit Squashing Hook
 *
 * Run with: node tests/squash_hook.test.mjs
 *
 * These tests mock git commands and test core functionality:
 * - Semantic commit parsing
 * - Commit analysis logic
 * - Input validation
 * - Configuration loading
 */

import { strict as assert } from 'assert';

// Test results tracking
const tests = [];
let passed = 0;
let failed = 0;

/**
 * Simple test runner
 */
function test(name, fn) {
  tests.push({ name, fn });
}

/**
 * Run all tests
 */
async function runTests() {
  console.log('\n' + '='.repeat(80));
  console.log('Running Enhanced Squash Hook Tests');
  console.log('='.repeat(80) + '\n');

  for (const { name, fn } of tests) {
    try {
      await fn();
      console.log(`✓ ${name}`);
      passed++;
    } catch (error) {
      console.error(`✗ ${name}`);
      console.error(`  Error: ${error.message}`);
      if (error.stack) {
        console.error(`  ${error.stack.split('\n').slice(1, 3).join('\n  ')}`);
      }
      failed++;
    }
  }

  console.log('\n' + '='.repeat(80));
  console.log(`Results: ${passed} passed, ${failed} failed, ${tests.length} total`);
  console.log('='.repeat(80) + '\n');

  process.exit(failed > 0 ? 1 : 0);
}

// ============================================================================
// Test Utilities
// ============================================================================

/**
 * Parse semantic commit message (duplicated from main hook for testing)
 */
function parseConventionalCommit(message) {
  const pattern = /^(\w+)(?:\(([^)]+)\))?(!)?: (.+)$/;
  const match = message.match(pattern);

  if (!match) {
    return {
      type: null,
      scope: null,
      breaking: false,
      subject: message,
      conventional: false,
    };
  }

  return {
    type: match[1],
    scope: match[2] || null,
    breaking: match[3] === '!',
    subject: match[4],
    conventional: true,
  };
}

/**
 * Validate user input (duplicated from main hook for testing)
 */
function validateInput(input, options = {}) {
  const {
    minLength = 0,
    maxLength = Infinity,
    pattern = null,
    forbiddenChars = [],
    allowEmpty = false,
  } = options;

  if (!input || input.trim() === '') {
    if (allowEmpty) {
      return { valid: true };
    }
    return { valid: false, error: 'Input cannot be empty' };
  }

  if (input.length < minLength) {
    return { valid: false, error: `Input must be at least ${minLength} characters` };
  }

  if (input.length > maxLength) {
    return { valid: false, error: `Input must be at most ${maxLength} characters` };
  }

  for (const char of forbiddenChars) {
    if (input.includes(char)) {
      return { valid: false, error: `Input contains forbidden character: ${JSON.stringify(char)}` };
    }
  }

  if (pattern && !pattern.test(input)) {
    return { valid: false, error: 'Input does not match required pattern' };
  }

  return { valid: true };
}

/**
 * Analyze commits (simplified version for testing)
 */
function analyzeCommits(commits, config) {
  // Check if all commits are from the same author
  const authors = new Set(commits.map((c) => c.email));
  const singleAuthor = authors.size === 1;

  // Check if commits look like incremental work
  const wipKeywords = config.wipKeywords || [
    'wip',
    'fix',
    'update',
    'temp',
    'tmp',
    'debug',
    'test',
  ];
  const wipCommits = commits.filter((c) =>
    wipKeywords.some((kw) => c.subject.toLowerCase().includes(kw))
  );

  // Check if commits are closely spaced
  let closelySpaced = true;
  if (commits.length > 1) {
    const timestamps = commits.map((c) => c.timestamp);
    const maxGap = Math.max(...timestamps) - Math.min(...timestamps);
    closelySpaced = maxGap < (config.timeThreshold || 3600);
  }

  // Semantic commit analysis
  let semanticInfo = null;
  if (config.semanticParsing) {
    const conventionalCommits = commits.filter((c) => c.semantic && c.semantic.conventional);
    const uniqueTypes = new Set(conventionalCommits.map((c) => c.semantic.type));
    const hasBreaking = commits.some((c) => c.semantic && c.semantic.breaking);

    semanticInfo = {
      conventionalCount: conventionalCommits.length,
      uniqueTypes: Array.from(uniqueTypes),
      hasBreaking,
      allConventional: conventionalCommits.length === commits.length,
    };
  }

  // Generate recommendation
  if (commits.length === 1) {
    return {
      strategy: 'keep',
      reason: 'Only one commit - no squashing needed',
      confidence: 'high',
    };
  }

  if (semanticInfo && semanticInfo.allConventional && semanticInfo.uniqueTypes.length > 1) {
    return {
      strategy: 'keep',
      reason: `All commits follow Conventional Commits with ${semanticInfo.uniqueTypes.length} different types`,
      confidence: 'high',
    };
  }

  if (semanticInfo && semanticInfo.hasBreaking) {
    return {
      strategy: 'interactive',
      reason: 'Breaking change detected',
      confidence: 'high',
    };
  }

  if (singleAuthor && wipCommits.length > commits.length / 2) {
    return {
      strategy: 'squash-all',
      reason: `${wipCommits.length}/${commits.length} commits appear to be incremental work`,
      confidence: 'high',
    };
  }

  if (singleAuthor && closelySpaced) {
    return {
      strategy: 'squash-all',
      reason: 'All commits from same author within short timeframe',
      confidence: 'medium',
    };
  }

  if (!singleAuthor) {
    return {
      strategy: 'keep',
      reason: `Multiple authors detected (${authors.size})`,
      confidence: 'medium',
    };
  }

  return {
    strategy: 'interactive',
    reason: 'Mixed commit types detected',
    confidence: 'low',
  };
}

// ============================================================================
// Semantic Commit Parsing Tests
// ============================================================================

test('parseConventionalCommit - feat type', () => {
  const result = parseConventionalCommit('feat: add new feature');
  assert.equal(result.type, 'feat');
  assert.equal(result.scope, null);
  assert.equal(result.breaking, false);
  assert.equal(result.subject, 'add new feature');
  assert.equal(result.conventional, true);
});

test('parseConventionalCommit - feat with scope', () => {
  const result = parseConventionalCommit('feat(auth): add login functionality');
  assert.equal(result.type, 'feat');
  assert.equal(result.scope, 'auth');
  assert.equal(result.breaking, false);
  assert.equal(result.subject, 'add login functionality');
  assert.equal(result.conventional, true);
});

test('parseConventionalCommit - breaking change', () => {
  const result = parseConventionalCommit('feat!: remove deprecated API');
  assert.equal(result.type, 'feat');
  assert.equal(result.scope, null);
  assert.equal(result.breaking, true);
  assert.equal(result.subject, 'remove deprecated API');
  assert.equal(result.conventional, true);
});

test('parseConventionalCommit - breaking change with scope', () => {
  const result = parseConventionalCommit('feat(api)!: change authentication method');
  assert.equal(result.type, 'feat');
  assert.equal(result.scope, 'api');
  assert.equal(result.breaking, true);
  assert.equal(result.subject, 'change authentication method');
  assert.equal(result.conventional, true);
});

test('parseConventionalCommit - non-conventional commit', () => {
  const result = parseConventionalCommit('WIP: working on feature');
  // "WIP: ..." matches the pattern but WIP is not a standard conventional type
  // The parser will match it as type="WIP", which is technically correct for the regex
  // but the semantic analysis should handle non-standard types appropriately
  assert.equal(result.conventional, true); // Matches the pattern
  assert.equal(result.type, 'WIP'); // Type is WIP
  assert.equal(result.subject, 'working on feature');
});

test('parseConventionalCommit - fix type', () => {
  const result = parseConventionalCommit('fix(ui): resolve button alignment issue');
  assert.equal(result.type, 'fix');
  assert.equal(result.scope, 'ui');
  assert.equal(result.breaking, false);
  assert.equal(result.subject, 'resolve button alignment issue');
  assert.equal(result.conventional, true);
});

// ============================================================================
// Input Validation Tests
// ============================================================================

test('validateInput - valid input', () => {
  const result = validateInput('Hello world');
  assert.equal(result.valid, true);
});

test('validateInput - empty input not allowed', () => {
  const result = validateInput('', { allowEmpty: false });
  assert.equal(result.valid, false);
  assert.match(result.error, /cannot be empty/i);
});

test('validateInput - empty input allowed', () => {
  const result = validateInput('', { allowEmpty: true });
  assert.equal(result.valid, true);
});

test('validateInput - min length check', () => {
  const result = validateInput('ab', { minLength: 3 });
  assert.equal(result.valid, false);
  assert.match(result.error, /at least 3 characters/i);
});

test('validateInput - max length check', () => {
  const result = validateInput('abcdefgh', { maxLength: 5 });
  assert.equal(result.valid, false);
  assert.match(result.error, /at most 5 characters/i);
});

test('validateInput - forbidden characters', () => {
  const result = validateInput('hello\x00world', { forbiddenChars: ['\x00'] });
  assert.equal(result.valid, false);
  assert.match(result.error, /forbidden character/i);
});

test('validateInput - pattern matching', () => {
  const result = validateInput('abc123', { pattern: /^[0-9]+$/ });
  assert.equal(result.valid, false);
  assert.match(result.error, /does not match required pattern/i);
});

test('validateInput - pattern matching success', () => {
  const result = validateInput('123456', { pattern: /^[0-9]+$/ });
  assert.equal(result.valid, true);
});

// ============================================================================
// Commit Analysis Tests
// ============================================================================

test('analyzeCommits - single commit', () => {
  const commits = [
    {
      hash: 'abc123',
      shortHash: 'abc123',
      author: 'John Doe',
      email: 'john@example.com',
      timestamp: 1609459200,
      subject: 'feat: add new feature',
      body: '',
      semantic: parseConventionalCommit('feat: add new feature'),
    },
  ];

  const config = { semanticParsing: true, wipKeywords: ['wip', 'fix'], timeThreshold: 3600 };
  const result = analyzeCommits(commits, config);

  assert.equal(result.strategy, 'keep');
  assert.match(result.reason, /only one commit/i);
  assert.equal(result.confidence, 'high');
});

test('analyzeCommits - multiple WIP commits from same author', () => {
  const baseTime = 1609459200;
  const commits = [
    {
      hash: 'abc123',
      author: 'John Doe',
      email: 'john@example.com',
      timestamp: baseTime,
      subject: 'WIP initial work',
      semantic: parseConventionalCommit('WIP initial work'),
    },
    {
      hash: 'def456',
      author: 'John Doe',
      email: 'john@example.com',
      timestamp: baseTime + 600,
      subject: 'fix minor bug',
      semantic: parseConventionalCommit('fix minor bug'),
    },
    {
      hash: 'ghi789',
      author: 'John Doe',
      email: 'john@example.com',
      timestamp: baseTime + 1200,
      subject: 'update documentation',
      semantic: parseConventionalCommit('update documentation'),
    },
  ];

  const config = {
    semanticParsing: true,
    wipKeywords: ['wip', 'fix', 'update'],
    timeThreshold: 3600,
  };
  const result = analyzeCommits(commits, config);

  assert.equal(result.strategy, 'squash-all');
  assert.match(result.reason, /incremental work/i);
  assert.equal(result.confidence, 'high');
});

test('analyzeCommits - multiple conventional commits with different types', () => {
  const baseTime = 1609459200;
  const commits = [
    {
      hash: 'abc123',
      author: 'John Doe',
      email: 'john@example.com',
      timestamp: baseTime,
      subject: 'feat: add authentication',
      semantic: parseConventionalCommit('feat: add authentication'),
    },
    {
      hash: 'def456',
      author: 'John Doe',
      email: 'john@example.com',
      timestamp: baseTime + 600,
      subject: 'docs: update README',
      semantic: parseConventionalCommit('docs: update README'),
    },
    {
      hash: 'ghi789',
      author: 'John Doe',
      email: 'john@example.com',
      timestamp: baseTime + 1200,
      subject: 'test: add unit tests',
      semantic: parseConventionalCommit('test: add unit tests'),
    },
  ];

  const config = { semanticParsing: true, wipKeywords: ['wip', 'fix'], timeThreshold: 3600 };
  const result = analyzeCommits(commits, config);

  assert.equal(result.strategy, 'keep');
  assert.match(result.reason, /conventional commits/i);
  assert.equal(result.confidence, 'high');
});

test('analyzeCommits - breaking change detected', () => {
  const baseTime = 1609459200;
  const commits = [
    {
      hash: 'abc123',
      author: 'John Doe',
      email: 'john@example.com',
      timestamp: baseTime,
      subject: 'feat: add feature',
      semantic: parseConventionalCommit('feat: add feature'),
    },
    {
      hash: 'def456',
      author: 'John Doe',
      email: 'john@example.com',
      timestamp: baseTime + 600,
      subject: 'feat!: breaking change',
      semantic: parseConventionalCommit('feat!: breaking change'),
    },
  ];

  const config = { semanticParsing: true, wipKeywords: ['wip', 'fix'], timeThreshold: 3600 };
  const result = analyzeCommits(commits, config);

  assert.equal(result.strategy, 'interactive');
  assert.match(result.reason, /breaking change/i);
  assert.equal(result.confidence, 'high');
});

test('analyzeCommits - multiple authors', () => {
  const baseTime = 1609459200;
  const commits = [
    {
      hash: 'abc123',
      author: 'John Doe',
      email: 'john@example.com',
      timestamp: baseTime,
      subject: 'Add feature implementation',
      semantic: parseConventionalCommit('Add feature implementation'),
    },
    {
      hash: 'def456',
      author: 'Jane Smith',
      email: 'jane@example.com',
      timestamp: baseTime + 600,
      subject: 'Resolve bug in feature',
      semantic: parseConventionalCommit('Resolve bug in feature'),
    },
  ];

  const config = { semanticParsing: false, wipKeywords: ['wip', 'fix'], timeThreshold: 3600 };
  const result = analyzeCommits(commits, config);

  assert.equal(result.strategy, 'keep');
  assert.match(result.reason, /multiple authors/i);
  assert.equal(result.confidence, 'medium');
});

test('analyzeCommits - closely spaced commits from same author', () => {
  const baseTime = 1609459200;
  const commits = [
    {
      hash: 'abc123',
      author: 'John Doe',
      email: 'john@example.com',
      timestamp: baseTime,
      subject: 'Add authentication module',
      semantic: parseConventionalCommit('Add authentication module'),
    },
    {
      hash: 'def456',
      author: 'John Doe',
      email: 'john@example.com',
      timestamp: baseTime + 1800, // 30 minutes later
      subject: 'Add tests for authentication',
      semantic: parseConventionalCommit('Add tests for authentication'),
    },
  ];

  const config = { semanticParsing: false, wipKeywords: ['wip', 'fix'], timeThreshold: 3600 };
  const result = analyzeCommits(commits, config);

  assert.equal(result.strategy, 'squash-all');
  assert.match(result.reason, /short timeframe/i);
  assert.equal(result.confidence, 'medium');
});

// ============================================================================
// Run all tests
// ============================================================================

runTests();
