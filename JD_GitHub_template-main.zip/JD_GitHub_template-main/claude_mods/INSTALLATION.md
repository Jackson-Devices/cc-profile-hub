# Pre-Push Commit Squashing Hook - Installation Guide

This guide walks you through installing and configuring the pre-push commit squashing hook for Claude Code.

## Table of Contents

- [Overview](#overview)
- [Prerequisites](#prerequisites)
- [Installation Steps](#installation-steps)
- [Configuration](#configuration)
- [Testing](#testing)
- [Troubleshooting](#troubleshooting)
- [Uninstallation](#uninstallation)

---

## Overview

The pre-push commit squashing hook intercepts `git push` operations initiated by Claude Code and prompts you to squash commits when multiple commits are detected. This helps maintain a clean git history.

**Key Features:**

- Automatically detects commits ahead of upstream
- Displays commit details with intelligent recommendations
- Provides interactive squashing options
- Handles edge cases (first push, single commit, detached HEAD, etc.)
- Works cross-platform (Windows, Linux, macOS)

---

## Prerequisites

### Required

- **Claude Code CLI** installed and configured
- **Git** installed and accessible from command line
- **Node.js** installed on your local machine (v14.0.0 or higher)
  - Required for Windows users (native)
  - Required for Linux/macOS users if using `.mjs` version

### Optional

- **Bash 4.0+** for Linux/macOS/WSL users (if using `.sh` version)

### Verify Prerequisites

```bash
# Check Node.js version
node --version
# Should output: v14.0.0 or higher

# Check Git version
git --version
# Should output: git version 2.x.x or higher

# Check Bash version (Linux/macOS/WSL only)
bash --version
# Should output: GNU bash, version 4.x.x or higher

# Check Claude Code
claude --version
# Should output Claude Code version
```

---

## Installation Steps

### Step 1: Locate Your Claude Code Configuration Directory

Claude Code uses a `.claude` directory for configuration. This directory is typically located:

- **Windows:** `C:\Users\<YourUsername>\.claude\`
- **macOS:** `~/.claude/`
- **Linux:** `~/.claude/`

You can find your configuration directory by running:

```bash
claude config path
```

If the directory doesn't exist, create it:

```bash
mkdir -p ~/.claude
```

### Step 2: Copy Hook Script to Claude Configuration

Choose the appropriate script based on your platform:

#### For Windows (Native Node.js):

```powershell
# Create hooks directory
mkdir $env:USERPROFILE\.claude\hooks -Force

# Copy Node.js hook script
copy claude_mods\pre_push_squash_check.mjs $env:USERPROFILE\.claude\hooks\
```

#### For Linux/macOS/WSL (Bash):

```bash
# Create hooks directory
mkdir -p ~/.claude/hooks

# Copy bash hook script
cp claude_mods/pre_push_squash_check.sh ~/.claude/hooks/

# Make executable
chmod +x ~/.claude/hooks/pre_push_squash_check.sh
```

#### Alternative: Use Node.js version on Linux/macOS

```bash
# Copy Node.js hook script
cp claude_mods/pre_push_squash_check.mjs ~/.claude/hooks/

# Make executable
chmod +x ~/.claude/hooks/pre_push_squash_check.mjs
```

### Step 3: Create or Update hooks.json

Create or edit the Claude Code hooks configuration file:

**File location:** `.claude/hooks.json`

#### For Windows (PowerShell):

```powershell
# Navigate to .claude directory
cd $env:USERPROFILE\.claude

# Create hooks.json (or use a text editor)
@"
{
  "hooks": {
    "before-bash": [
      {
        "name": "pre-push-squash-check",
        "pattern": "git push.*",
        "command": "node $env:USERPROFILE\\.claude\\hooks\\pre_push_squash_check.mjs",
        "blocking": true,
        "description": "Check and prompt for commit squashing before git push"
      }
    ]
  }
}
"@ | Out-File -FilePath hooks.json -Encoding UTF8
```

#### For Linux/macOS/WSL (Bash version):

```bash
# Navigate to .claude directory
cd ~/.claude

# Create hooks.json
cat > hooks.json << 'EOF'
{
  "hooks": {
    "before-bash": [
      {
        "name": "pre-push-squash-check",
        "pattern": "git push.*",
        "command": "~/.claude/hooks/pre_push_squash_check.sh",
        "blocking": true,
        "description": "Check and prompt for commit squashing before git push"
      }
    ]
  }
}
EOF
```

#### For Linux/macOS (Node.js version):

```bash
# Navigate to .claude directory
cd ~/.claude

# Create hooks.json
cat > hooks.json << 'EOF'
{
  "hooks": {
    "before-bash": [
      {
        "name": "pre-push-squash-check",
        "pattern": "git push.*",
        "command": "node ~/.claude/hooks/pre_push_squash_check.mjs",
        "blocking": true,
        "description": "Check and prompt for commit squashing before git push"
      }
    ]
  }
}
EOF
```

**Hook Configuration Explanation:**

- `"before-bash"`: Triggers before bash commands are executed
- `"pattern": "git push.*"`: Matches any command starting with "git push"
- `"blocking": true`: **CRITICAL** - Blocks the push command until hook completes
- `"command"`: Path to the hook script to execute

---

## Configuration

### Customizing the Hook

The hook scripts support several behaviors that can be modified by editing the script files directly:

#### Auto-Allow Single Commits

By default, the hook automatically allows pushes with only one commit. To change this behavior, edit the hook script:

**In `pre_push_squash_check.mjs` (around line 370):**

```javascript
if (commits.length === 1) {
  print('✓ Only one commit ahead of upstream', 'green');
  print('No squashing needed. Proceeding with push...', 'dim');
  process.exit(0); // Change to process.exit(1) to block single commits too
}
```

**In `pre_push_squash_check.sh` (around line 286):**

```bash
if [[ $commit_count -eq 1 ]]; then
    print "✓ Only one commit ahead of upstream" "$GREEN"
    print "No squashing needed. Proceeding with push..." "$DIM"
    exit 0  # Change to exit 1 to block single commits too
fi
```

#### Adjust Recommendation Logic

You can modify the commit analysis logic to change when squashing is recommended:

**In `pre_push_squash_check.mjs` (function `analyzeCommits()`):**

```javascript
// Modify WIP keywords
const wipKeywords = ['wip', 'fix', 'update', 'temp', 'tmp', 'debug', 'test', 'merge'];

// Modify time threshold (currently 1 hour = 3600 seconds)
closelySpaced = maxGap < 3600;
```

---

## Testing

### Test 1: Verify Hook is Configured

Check that Claude Code recognizes your hook:

```bash
# List configured hooks (if Claude Code supports this)
claude hooks list
```

### Test 2: Create Test Commits

Create a test scenario with multiple commits:

```bash
# Create a test branch
git checkout -b test-squash-hook

# Make multiple test commits
echo "test1" > test1.txt
git add test1.txt
git commit -m "WIP: test commit 1"

echo "test2" > test2.txt
git add test2.txt
git commit -m "fix: test commit 2"

echo "test3" > test3.txt
git add test3.txt
git commit -m "update: test commit 3"
```

### Test 3: Trigger Hook with Claude Code

Now ask Claude Code to push:

1. Open Claude Code in this repository
2. Ask Claude: "Please push these changes"
3. Claude will execute `git push`, triggering the hook
4. You should see:
   - List of commits ahead of upstream
   - Recommendation for squashing
   - Options menu (1-4)

### Test 4: Test Each Option

Test each hook option:

1. **Option 1 (Squash All):** Squashes all commits into one
2. **Option 2 (Interactive):** Opens interactive rebase
3. **Option 3 (Keep Separate):** Proceeds with push as-is
4. **Option 4 (Cancel):** Cancels the push

### Expected Output

When the hook runs, you should see output like this:

```
================================================================================
  Pre-Push Commit Squashing Hook
================================================================================

Current branch: test-squash-hook
Upstream branch: origin/main

================================================================================
  Commits Ahead of Upstream
================================================================================

Commit 1/3:
  SHA:     a1b2c3d
  Author:  Your Name <you@example.com>
  Date:    2025-11-08 10:30:00
  Subject: WIP: test commit 1

Commit 2/3:
  SHA:     e4f5g6h
  Author:  Your Name <you@example.com>
  Date:    2025-11-08 10:31:00
  Subject: fix: test commit 2

Commit 3/3:
  SHA:     i7j8k9l
  Author:  Your Name <you@example.com>
  Date:    2025-11-08 10:32:00
  Subject: update: test commit 3

================================================================================
  Recommendation
================================================================================

Strategy: Squash all commits into one
Reason:   3/3 commits appear to be incremental work (WIP/fix/update). Squashing recommended for clean history.
Confidence: HIGH

================================================================================
  Squashing Options
================================================================================

1. Squash all commits into one (clean history)
2. Interactive squash (review and choose what to squash)
3. Keep commits separate (proceed with push)
4. Cancel push (abort operation)

Recommended: Option 1

Enter choice [1-4] (default: 1):
```

---

## Troubleshooting

### Hook Doesn't Run

**Symptom:** Claude Code pushes without triggering the hook.

**Solutions:**

1. **Verify hooks.json exists and is valid:**

   ```bash
   # Check file exists
   ls -la ~/.claude/hooks.json

   # Validate JSON syntax
   node -e "console.log(JSON.parse(require('fs').readFileSync(process.env.HOME + '/.claude/hooks.json')))"
   ```

2. **Check pattern matching:**
   - Ensure pattern is `"git push.*"` (matches any git push command)
   - Ensure `"blocking": true` is set

3. **Check script permissions:**

   ```bash
   # Make sure script is executable
   chmod +x ~/.claude/hooks/pre_push_squash_check.sh
   chmod +x ~/.claude/hooks/pre_push_squash_check.mjs
   ```

4. **Check Claude Code logs:**
   - Look for hook execution errors in Claude Code output

### "Node.js Not Found" Error

**Symptom:** Error message about `node` command not found.

**Solutions:**

1. **Verify Node.js installation:**

   ```bash
   node --version
   ```

2. **Add Node.js to PATH:**
   - **Windows:** Add Node.js installation directory to System PATH
   - **Linux/macOS:** Add to `~/.bashrc` or `~/.zshrc`:
     ```bash
     export PATH="/usr/local/bin:$PATH"
     ```

3. **Use absolute path in hooks.json:**
   ```json
   {
     "command": "/usr/local/bin/node ~/.claude/hooks/pre_push_squash_check.mjs"
   }
   ```

### "No Upstream Branch" Error

**Symptom:** Hook reports no upstream branch configured.

**Solutions:**

1. **Set upstream branch:**

   ```bash
   git push -u origin <branch-name>
   ```

2. **This is expected on first push** - hook automatically allows it.

### Interactive Rebase Fails

**Symptom:** Interactive rebase opens but fails or is cancelled.

**Solutions:**

1. **Check Git editor configuration:**

   ```bash
   # Set default editor
   git config --global core.editor "vim"  # or nano, emacs, code, etc.
   ```

2. **Rebase conflicts:**
   - If rebase has conflicts, resolve them:
     ```bash
     # Edit conflicting files
     git add <resolved-files>
     git rebase --continue
     ```

3. **Cancel rebase if needed:**
   ```bash
   git rebase --abort
   ```

### Squash Creates Wrong Message

**Symptom:** Squashed commit message is not what you expected.

**Solutions:**

1. **Use custom message option** when prompted
2. **Amend commit after squashing:**
   ```bash
   git commit --amend
   ```

### Hook Blocks Even with Single Commit

**Symptom:** Hook runs even when there's only one commit.

**Solution:** This is expected behavior for safety. Choose "Keep commits separate" (option 3) to proceed.

Alternatively, modify the script to auto-allow single commits (see [Configuration](#configuration) section).

---

## Uninstallation

### Remove Hook Configuration

1. **Delete hook from hooks.json:**

   Edit `~/.claude/hooks.json` and remove the `pre-push-squash-check` entry.

   Or delete the entire file if it only contains this hook:

   ```bash
   rm ~/.claude/hooks.json
   ```

2. **Delete hook script:**

   ```bash
   # Remove hook script
   rm ~/.claude/hooks/pre_push_squash_check.sh
   rm ~/.claude/hooks/pre_push_squash_check.mjs
   ```

3. **Verify removal:**

   Ask Claude Code to push - it should proceed without prompting.

---

## Advanced Configuration

### Multiple Hook Integration

If you already have other hooks configured, merge the configurations:

**Example hooks.json with multiple hooks:**

```json
{
  "hooks": {
    "before-bash": [
      {
        "name": "pre-commit-linter",
        "pattern": "git commit.*",
        "command": "~/.claude/hooks/run_linter.sh",
        "blocking": true,
        "description": "Run linter before commit"
      },
      {
        "name": "pre-push-squash-check",
        "pattern": "git push.*",
        "command": "node ~/.claude/hooks/pre_push_squash_check.mjs",
        "blocking": true,
        "description": "Check and prompt for commit squashing before git push"
      }
    ],
    "after-bash": [
      {
        "name": "post-push-notify",
        "pattern": "git push.*",
        "command": "~/.claude/hooks/notify_push.sh",
        "blocking": false,
        "description": "Send notification after successful push"
      }
    ]
  }
}
```

### Hook Logging

To debug hook execution, add logging to the scripts:

**For Node.js version:**

Add at the top of `pre_push_squash_check.mjs`:

```javascript
import fs from 'fs';

const logFile = process.env.HOME + '/.claude/hooks/squash_hook.log';
const log = (msg) => fs.appendFileSync(logFile, `[${new Date().toISOString()}] ${msg}\n`);

// Use log() throughout the script
log('Hook started');
```

**For Bash version:**

Add at the top of `pre_push_squash_check.sh`:

```bash
LOG_FILE="$HOME/.claude/hooks/squash_hook.log"
log() {
    echo "[$(date -Iseconds)] $*" >> "$LOG_FILE"
}

# Use log throughout the script
log "Hook started"
```

---

## Support

If you encounter issues not covered in this guide:

1. Check Claude Code documentation: https://docs.claude.com
2. Review hook script comments for additional details
3. Check git configuration: `git config --list`
4. Test hook script manually:

   ```bash
   # Test Node.js version
   node ~/.claude/hooks/pre_push_squash_check.mjs

   # Test Bash version
   ~/.claude/hooks/pre_push_squash_check.sh
   ```

---

**Last Updated:** 2025-11-08
**Version:** 1.0
**Maintainer:** Claude Mods Collection
