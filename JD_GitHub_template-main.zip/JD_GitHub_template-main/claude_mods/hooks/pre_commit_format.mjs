#!/usr/bin/env node

/**
 * pre_commit_format.mjs - Pre-Commit Formatting Hook
 *
 * Automatically checks staged files for formatting issues before commit.
 * Presents diff with merge/replace/cancel options.
 *
 * Features:
 * - Auto-detects staged files
 * - Filters by supported extensions (.yml, .yaml, .md, .json, .js, .ts, .mjs, .css, .html)
 * - Runs formatter check (Prettier)
 * - Shows interactive diff if changes needed
 * - Applies formatting based on user choice
 * - Logs operations to .ai_logs/formatter_log.jsonl
 *
 * Exit codes:
 *   0 - Success (no changes or changes accepted)
 *   1 - Cancelled by user or error
 */

import { exec } from 'child_process';
import { promisify } from 'util';
import { appendFile, mkdir } from 'fs/promises';
import { existsSync } from 'fs';
import { join, dirname } from 'path';
import { fileURLToPath } from 'url';
import { reviewChanges, applyFormatting } from '../scripts/format_diff.mjs';

const execAsync = promisify(exec);
const __filename = fileURLToPath(import.meta.url);
const __dirname = dirname(__filename);

// ANSI colors
const colors = {
  reset: '\x1b[0m',
  bold: '\x1b[1m',
  red: '\x1b[31m',
  green: '\x1b[32m',
  yellow: '\x1b[33m',
  cyan: '\x1b[36m',
};

// Supported file extensions
const SUPPORTED_EXTENSIONS = [
  '.yml',
  '.yaml',
  '.md',
  '.json',
  '.js',
  '.ts',
  '.mjs',
  '.css',
  '.html',
  '.sh',
];

/**
 * Get list of staged files
 * @returns {Promise<string[]>}
 */
async function getStagedFiles() {
  try {
    const { stdout } = await execAsync('git diff --cached --name-only --diff-filter=ACM');
    return stdout
      .trim()
      .split('\n')
      .filter((f) => f.length > 0);
  } catch (error) {
    console.error(`${colors.red}Error getting staged files: ${error.message}${colors.reset}`);
    return [];
  }
}

/**
 * Filter files by supported extensions
 * @param {string[]} files
 * @returns {string[]}
 */
function filterSupportedFiles(files) {
  return files.filter((file) => {
    return SUPPORTED_EXTENSIONS.some((ext) => file.endsWith(ext));
  });
}

/**
 * Check which files need formatting
 * @param {string[]} files
 * @returns {Promise<string[]>} Files that need formatting
 */
async function checkFormatting(files) {
  if (files.length === 0) {
    return [];
  }

  try {
    const filesArg = files.map((f) => `"${f}"`).join(' ');
    await execAsync(`npx prettier --check ${filesArg}`);
    // If prettier --check succeeds, no files need formatting
    return [];
  } catch {
    // prettier --check exits with code 1 if files need formatting
    // Parse output to find which files need formatting
    const needsFormatting = [];

    for (const file of files) {
      try {
        await execAsync(`npx prettier --check "${file}"`);
      } catch {
        needsFormatting.push(file);
      }
    }

    return needsFormatting;
  }
}

/**
 * Log formatter operation
 * @param {object} logEntry
 */
async function logOperation(logEntry) {
  const logDir = join(process.cwd(), '.ai_logs');
  const logFile = join(logDir, 'formatter_log.jsonl');

  try {
    if (!existsSync(logDir)) {
      await mkdir(logDir, { recursive: true });
    }

    const logLine = JSON.stringify({
      timestamp: new Date().toISOString(),
      ...logEntry,
    });

    await appendFile(logFile, logLine + '\n', 'utf-8');
  } catch (error) {
    // Silent fail - logging shouldn't block commits
    console.error(
      `${colors.yellow}Warning: Could not write to formatter log: ${error.message}${colors.reset}`
    );
  }
}

/**
 * Main hook execution
 */
async function main() {
  console.log(
    `\n${colors.bold}${colors.cyan}Running pre-commit formatter check...${colors.reset}\n`
  );

  const startTime = Date.now();

  // Get staged files
  const stagedFiles = await getStagedFiles();

  if (stagedFiles.length === 0) {
    console.log(`${colors.yellow}No files staged for commit${colors.reset}`);
    await logOperation({
      event: 'pre_commit_check',
      status: 'skipped',
      reason: 'no_staged_files',
    });
    process.exit(0);
  }

  console.log(`Found ${colors.cyan}${stagedFiles.length}${colors.reset} staged file(s)`);

  // Filter to supported file types
  const supportedFiles = filterSupportedFiles(stagedFiles);

  if (supportedFiles.length === 0) {
    console.log(`${colors.green}✓ No formattable files in this commit${colors.reset}`);
    await logOperation({
      event: 'pre_commit_check',
      status: 'skipped',
      reason: 'no_supported_files',
      total_staged: stagedFiles.length,
    });
    process.exit(0);
  }

  console.log(
    `Checking ${colors.cyan}${supportedFiles.length}${colors.reset} formattable file(s)...\n`
  );

  // Check which files need formatting
  const needsFormatting = await checkFormatting(supportedFiles);

  if (needsFormatting.length === 0) {
    console.log(`${colors.green}✓ All files are properly formatted${colors.reset}`);
    await logOperation({
      event: 'pre_commit_check',
      status: 'passed',
      files_checked: supportedFiles.length,
      elapsed_ms: Date.now() - startTime,
    });
    process.exit(0);
  }

  // Files need formatting - present diff and get user decision
  console.log(
    `${colors.yellow}⚠ Found ${needsFormatting.length} file(s) that need formatting${colors.reset}`
  );

  const result = await reviewChanges(needsFormatting);

  if (result.action === 'cancel') {
    console.log(`\n${colors.red}✗ Commit aborted - formatting changes rejected${colors.reset}`);
    await logOperation({
      event: 'pre_commit_check',
      status: 'cancelled',
      files_needing_format: needsFormatting.length,
      action: 'cancel',
      elapsed_ms: Date.now() - startTime,
    });
    process.exit(1);
  } else if (result.action === 'replace') {
    if (result.acceptedFiles.length > 0) {
      await applyFormatting(result.acceptedFiles);
      console.log(
        `\n${colors.green}✓ Formatting applied to ${result.acceptedFiles.length} file(s)${colors.reset}`
      );
    }

    await logOperation({
      event: 'pre_commit_check',
      status: 'completed',
      action: 'replace',
      files_formatted: result.acceptedFiles.length,
      files_needing_format: needsFormatting.length,
      elapsed_ms: Date.now() - startTime,
    });

    console.log(`${colors.green}✓ Commit can proceed${colors.reset}\n`);
    process.exit(0);
  } else if (result.action === 'merge') {
    if (result.acceptedFiles.length > 0) {
      await applyFormatting(result.acceptedFiles);
      console.log(
        `\n${colors.green}✓ Formatting applied to ${result.acceptedFiles.length} file(s)${colors.reset}`
      );
    }

    await logOperation({
      event: 'pre_commit_check',
      status: 'completed',
      action: 'merge',
      files_formatted: result.acceptedFiles.length,
      files_skipped: needsFormatting.length - result.acceptedFiles.length,
      files_needing_format: needsFormatting.length,
      elapsed_ms: Date.now() - startTime,
    });

    console.log(`${colors.green}✓ Commit can proceed${colors.reset}\n`);
    process.exit(0);
  }
}

// Run the hook
main().catch((error) => {
  console.error(`\n${colors.red}✗ Pre-commit hook error: ${error.message}${colors.reset}`);
  logOperation({
    event: 'pre_commit_check',
    status: 'error',
    error: error.message,
    stack: error.stack,
  }).catch(() => {});
  process.exit(1);
});
