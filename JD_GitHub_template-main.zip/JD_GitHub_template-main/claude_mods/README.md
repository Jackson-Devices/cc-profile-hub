# Claude Code Modifications (claude_mods)

This directory contains modifications, enhancements, and custom configurations for Claude Code that cannot be applied automatically within the repository. These files must be manually installed by the user into their local Claude Code configuration.

## Why This Directory Exists

Claude Code configuration is stored in a user-specific directory (`.claude/`) that is gitignored and not tracked in the repository. This `claude_mods/` directory provides a collection of useful modifications that can be manually applied to your local Claude Code setup.

## Contents

### 🎯 Pre-Push Commit Squashing Hook

**Purpose:** Automatically prompts you to squash commits before pushing to remote, maintaining a clean git history.

**Files:**

- `pre_push_squash_check.mjs` - Node.js version (Windows, Linux, macOS)
- `pre_push_squash_check.sh` - Bash version (Linux, macOS, WSL)
- `INSTALLATION.md` - Complete installation and configuration guide
- `BEST_PRACTICES.md` - Commit squashing best practices and guidelines
- `hooks.json.example` - Example hooks configuration (Node.js/Linux/macOS)
- `hooks.json.windows.example` - Example hooks configuration (Windows)
- `hooks.json.bash.example` - Example hooks configuration (Bash)

**Quick Start:**

1. **Choose your platform:**
   - **Windows (native):** Use `pre_push_squash_check.mjs`
   - **Linux/macOS/WSL:** Use `pre_push_squash_check.sh` or `pre_push_squash_check.mjs`

2. **Follow installation guide:**
   - Read [INSTALLATION.md](./INSTALLATION.md) for step-by-step instructions

3. **Install the hook:**

   ```bash
   # Linux/macOS/WSL (Node.js version)
   cp pre_push_squash_check.mjs ~/.claude/hooks/
   chmod +x ~/.claude/hooks/pre_push_squash_check.mjs

   # Linux/macOS/WSL (Bash version)
   cp pre_push_squash_check.sh ~/.claude/hooks/
   chmod +x ~/.claude/hooks/pre_push_squash_check.sh
   ```

   ```powershell
   # Windows (PowerShell)
   mkdir $env:USERPROFILE\.claude\hooks -Force
   copy pre_push_squash_check.mjs $env:USERPROFILE\.claude\hooks\
   ```

4. **Configure Claude Code:**
   - Copy appropriate `hooks.json.*.example` to `~/.claude/hooks.json`
   - Edit paths to match your system

5. **Test the hook:**
   - Create multiple commits
   - Ask Claude Code to push
   - Hook should trigger and prompt you for action

**Features:**

✅ **Automatic Detection:** Detects commits ahead of upstream
✅ **Intelligent Recommendations:** Analyzes commits and suggests optimal strategy
✅ **Interactive Options:** Choose how to handle commits (squash all, interactive, keep, cancel)
✅ **Verbose Output:** Shows detailed information during squashing
✅ **Edge Case Handling:** Handles first push, single commits, detached HEAD, etc.
✅ **Cross-Platform:** Works on Windows (Node.js), Linux, macOS, WSL (Bash or Node.js)

**Example Output:**

```
================================================================================
  Pre-Push Commit Squashing Hook
================================================================================

Current branch: feature-branch
Upstream branch: origin/main

================================================================================
  Commits Ahead of Upstream
================================================================================

Commit 1/3:
  SHA:     a1b2c3d
  Author:  Your Name <you@example.com>
  Date:    2025-11-08 10:30:00
  Subject: WIP: initial implementation

Commit 2/3:
  SHA:     e4f5g6h
  Author:  Your Name <you@example.com>
  Date:    2025-11-08 10:35:00
  Subject: fix: typo in variable name

Commit 3/3:
  SHA:     i7j8k9l
  Author:  Your Name <you@example.com>
  Date:    2025-11-08 10:40:00
  Subject: update: add error handling

================================================================================
  Recommendation
================================================================================

Strategy: Squash all commits into one
Reason:   3/3 commits appear to be incremental work (WIP/fix/update).
          Squashing recommended for clean history.
Confidence: HIGH

================================================================================
  Squashing Options
================================================================================

1. Squash all commits into one (clean history)
2. Interactive squash (review and choose what to squash)
3. Keep commits separate (proceed with push)
4. Cancel push (abort operation)

Recommended: Option 1

Enter choice [1-4] (default: 1):
```

---

### 📊 Comprehensive Logging System

**Purpose:** Tracks all Claude Code activity for analysis, optimization, and comprehensive token usage monitoring. Zero token overhead - logs everything without impacting your Claude conversations.

**Files:**

- `logging_hook.mjs` - Main logging hook (Node.js, cross-platform)
- `analyze_logs.mjs` - Log analysis tool with token breakdowns
- `LOGGING_INSTALLATION.md` - Complete installation guide
- `LOGGING_GUIDE.md` - Usage guide and optimization tips
- `hooks.json.logging.example` - Logging-only hooks configuration
- `hooks.json.combined.example` - Combined with commit squashing
- `logging_config.json.example` - Configuration template

**Quick Start:**

1. **Install the logging hook:**

   ```bash
   # Linux/macOS/WSL
   mkdir -p ~/.claude/hooks
   cp logging_hook.mjs ~/.claude/hooks/
   cp analyze_logs.mjs ~/.claude/hooks/
   chmod +x ~/.claude/hooks/logging_hook.mjs
   chmod +x ~/.claude/hooks/analyze_logs.mjs
   ```

   ```powershell
   # Windows (PowerShell)
   New-Item -Path "$env:USERPROFILE\.claude\hooks" -ItemType Directory -Force
   Copy-Item logging_hook.mjs "$env:USERPROFILE\.claude\hooks\"
   Copy-Item analyze_logs.mjs "$env:USERPROFILE\.claude\hooks\"
   ```

2. **Configure hooks:**

   ```bash
   # Linux/macOS/WSL - Logging only
   cp hooks.json.logging.example ~/.claude/hooks.json

   # OR if you also use commit squashing:
   cp hooks.json.combined.example ~/.claude/hooks.json
   ```

   ```powershell
   # Windows (PowerShell) - Logging only
   Copy-Item hooks.json.logging.example "$env:USERPROFILE\.claude\hooks.json"

   # OR if you also use commit squashing:
   Copy-Item hooks.json.combined.example "$env:USERPROFILE\.claude\hooks.json"
   ```

3. **Use Claude Code normally - logs appear automatically:**
   - Logs saved to `.ai_logs/session_*.jsonl`
   - Automatically gitignored (never committed)
   - Privacy: secrets automatically redacted

4. **Analyze your usage:**

   ```bash
   # Summary of latest session
   node ~/.claude/hooks/analyze_logs.mjs

   # Comprehensive token analysis
   node ~/.claude/hooks/analyze_logs.mjs --tokens

   # Tool usage and performance
   node ~/.claude/hooks/analyze_logs.mjs --tools

   # Everything
   node ~/.claude/hooks/analyze_logs.mjs --all
   ```

**Features:**

✅ **Comprehensive Tracking:** All 7 hook events (beforeMessage, afterMessage, beforeToolUse, afterToolUse, onTokenUsage, onThinking, onStreamChunk)
✅ **Zero Token Overhead:** Logging adds ZERO tokens to your usage
✅ **Token Analysis:** Per-message, per-tool, cumulative token tracking with detailed breakdowns
✅ **Cost Estimation:** Automatic USD cost calculation based on model pricing
✅ **Performance Metrics:** Tool duration, session length, slow tool warnings
✅ **Privacy-First:** Automatic secret redaction (API keys, tokens, SSH keys, etc.)
✅ **Configurable Verbosity:** Minimal, normal, or verbose logging
✅ **Tool Efficiency:** Identify which tools use the most tokens
✅ **Cross-Platform:** Works on Windows, Linux, macOS, WSL

**What Gets Logged:**

- 📝 **Messages:** Full prompts and Claude's responses
- 🔧 **Tools:** Every Read, Write, Edit, Bash, Grep with parameters and results
- 💰 **Tokens:** Comprehensive tracking (prompt, completion, total) per message and per tool
- ⏱️ **Performance:** Tool execution time, warnings for slow operations
- 🧠 **Thinking:** Extended thinking process (optional, verbose mode)
- 📊 **Analysis:** Real-time insights into your Claude Code usage patterns

**Example Token Analysis Output:**

```
═══════════════════════════════════════════════════════════════════════════
  Comprehensive Token Analysis
═══════════════════════════════════════════════════════════════════════════

📊 Overall Token Usage:
  Prompt Tokens:     12,345
  Completion Tokens: 6,789
  Total Tokens:      19,134
  Ratio (out/in):    0.55

💰 Cost Breakdown:
  Input Cost:  USD $0.0370 (12,345 tokens @ $3.00/MTok)
  Output Cost: USD $0.1018 (6,789 tokens @ $15.00/MTok)
  Total Cost:  USD $0.1388

📝 Per-Message Token Usage:
  Msg ID  | Prompt  | Completion | Total   | Cost
  --------|---------|------------|---------|----------
       1  |    1234 |        567 |    1801 | $0.0122
       2  |    2345 |        890 |    3235 | $0.0204
  ...

🔧 Per-Tool Token Estimate:
  Tool Name         | Calls | Total Tokens | Avg/Call
  ------------------|-------|--------------|----------
  Read              |    25 |         5000 |      200
  Write             |    10 |         3000 |      300
  Edit              |     8 |         2000 |      250
  Bash              |    15 |         1500 |      100
```

**Configuration:**

Customize behavior in `~/.claude/logging_config.json`:

```json
{
  "verbosity": "normal", // minimal, normal, verbose
  "privacy": {
    "enabled": true,
    "redactSecrets": true,
    "redactPaths": true,
    "redactEnvVars": true
  },
  "tokens": {
    "trackPerTool": true,
    "trackPerMessage": true,
    "trackCumulative": true,
    "estimateCost": true,
    "warnThreshold": 50000
  },
  "performance": {
    "trackDuration": true,
    "slowToolThreshold": 5000
  }
}
```

**Privacy & Security:**

- ✅ All logs automatically excluded from git (`.ai_logs/.gitignore`)
- ✅ Automatic secret redaction (API keys, tokens, SSH keys, JWTs)
- ✅ Path redaction (full paths → filenames only)
- ✅ Environment variable redaction
- ✅ Configurable privacy settings
- ✅ Zero-overhead logging (doesn't slow down Claude Code)

**Optimization Insights:**

Use logging data to:

- **Reduce costs:** Identify token-heavy operations
- **Improve performance:** Find slow tool calls
- **Track trends:** Monitor usage over time
- **Debug issues:** See exactly what Claude Code is doing
- **Optimize workflows:** Find inefficient patterns

**Example Optimizations Discovered:**

```
Before: Reading entire 10,000-line file → 50,000 tokens
After:  Using Grep to find relevant section → 2,000 tokens
Savings: 48,000 tokens ($0.72 per session)

Before: Verbose responses with examples → 8,000 completion tokens
After:  Specific questions → 2,000 completion tokens
Savings: 6,000 tokens ($0.09 per message)
```

---

## Installation Overview

All modifications in this directory require manual installation because:

1. **User-Specific Configuration:** Claude Code configuration is stored in `~/.claude/` (gitignored)
2. **Platform Differences:** Windows, Linux, and macOS have different paths and requirements
3. **Customization:** Users may want to modify behavior before installing
4. **Safety:** Prevents automatic execution of scripts without user review

### General Installation Pattern

1. **Review the modification** - Read README and understand what it does
2. **Choose appropriate version** - Select files for your platform
3. **Follow installation guide** - Each modification includes detailed instructions
4. **Test functionality** - Verify it works as expected
5. **Customize if needed** - Modify behavior to match your workflow

---

## Documentation

### Per-Modification Documentation

Each modification includes its own comprehensive documentation:

- **README** - Overview and quick start (you are here)
- **INSTALLATION.md** - Step-by-step installation instructions
- **BEST_PRACTICES.md** - Usage guidelines and recommendations
- **Example files** - Configuration templates for different platforms

### Repository Documentation

This directory is part of the larger Jackson-Devices GitHub Template repository. See also:

- **[Repository README](../README.md)** - Main repository documentation
- **[TODO.md](../TODO.md)** - Current development status and roadmap
- **[LABEL_DESIGN_SPEC.md](../LABEL_DESIGN_SPEC.md)** - Label taxonomy
- **[.github/WORKFLOW_BEHAVIOR.md](../.github/WORKFLOW_BEHAVIOR.md)** - Workflow documentation

---

## Platform Support

### Windows

**Supported:**

- ✅ Node.js version (`pre_push_squash_check.mjs`)
- ✅ Native Windows (PowerShell/CMD)
- ✅ WSL (both Bash and Node.js versions)

**Requirements:**

- Node.js v14.0.0 or higher
- Git for Windows
- Claude Code CLI

### Linux

**Supported:**

- ✅ Bash version (`pre_push_squash_check.sh`)
- ✅ Node.js version (`pre_push_squash_check.mjs`)

**Requirements:**

- Bash 4.0+ (for bash version)
- Node.js v14.0.0+ (for node version)
- Git 2.x+
- Claude Code CLI

### macOS

**Supported:**

- ✅ Bash version (`pre_push_squash_check.sh`)
- ✅ Node.js version (`pre_push_squash_check.mjs`)

**Requirements:**

- Bash 4.0+ (may need to update default bash)
- Node.js v14.0.0+
- Git 2.x+
- Claude Code CLI

---

## Troubleshooting

### Common Issues

**Hook doesn't run:**

- Verify `hooks.json` exists in `~/.claude/`
- Check JSON syntax is valid
- Ensure `"blocking": true` is set
- Verify script has execute permissions

**"Command not found" errors:**

- Check Node.js is installed: `node --version`
- Check Git is installed: `git --version`
- Verify paths in `hooks.json` are correct
- Use absolute paths if relative paths fail

**Permission denied:**

```bash
# Make scripts executable
chmod +x ~/.claude/hooks/pre_push_squash_check.sh
chmod +x ~/.claude/hooks/pre_push_squash_check.mjs
```

**Hook runs but fails:**

- Check Claude Code logs for error messages
- Test script manually: `node ~/.claude/hooks/pre_push_squash_check.mjs`
- Review script output for specific errors

### Getting Help

1. **Read INSTALLATION.md** - Most issues are covered in troubleshooting section
2. **Read BEST_PRACTICES.md** - Understand expected behavior
3. **Test manually** - Run scripts outside of Claude Code to isolate issues
4. **Check prerequisites** - Ensure all requirements are met

---

## Contributing

If you develop new modifications or improvements:

1. **Create new files** in this directory
2. **Include documentation:**
   - README section describing the modification
   - INSTALLATION guide with platform-specific instructions
   - Example configuration files
   - Best practices document
3. **Test on multiple platforms** (Windows, Linux, macOS)
4. **Update this README** with new modification details

---

## Future Modifications

This directory will grow over time with additional Claude Code enhancements:

**Implemented:**

- ✅ Pre-push commit squashing hook
- ✅ Comprehensive logging system with token tracking

**Planned:**

- Pre-commit linting hooks
- Automatic issue template validation
- Test execution hooks
- Custom Claude Code commands
- Workflow automation scripts
- GitHub Actions integration hooks

**Suggestions welcome!** If you have ideas for useful modifications, submit them to the repository issue tracker.

---

## Version History

### v1.1 - 2025-11-08

**Added:**

- Comprehensive logging system with all 7 hook events
- Advanced token tracking (per-message, per-tool, cumulative, cost estimation)
- Log analysis tool with detailed breakdowns
- Privacy-first design with automatic secret redaction
- Configurable verbosity levels
- Performance metrics and optimization insights
- LOGGING_INSTALLATION.md and LOGGING_GUIDE.md documentation

### v1.0 - 2025-11-08

**Added:**

- Pre-push commit squashing hook (Node.js and Bash versions)
- Installation guide with platform-specific instructions
- Best practices documentation
- Example hooks.json configurations
- This README

---

## License

This directory and its contents are part of the Jackson-Devices GitHub Template repository.

See repository LICENSE for details.

---

## Support

For issues, questions, or suggestions:

1. Check **INSTALLATION.md** troubleshooting section
2. Review **BEST_PRACTICES.md** for usage guidance
3. Search repository issues for similar problems
4. Create new issue in repository with:
   - Modification name
   - Platform (Windows/Linux/macOS)
   - Error message or unexpected behavior
   - Steps to reproduce

---

**Last Updated:** 2025-11-08
**Maintainer:** Jackson-Devices
**Repository:** https://github.com/Jackson-Devices/JD_GitHub_template
