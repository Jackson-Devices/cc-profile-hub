#!/usr/bin/env node

/**
 * Claude Code Log Analyzer
 *
 * Analyzes .ai_logs/*.jsonl files to provide insights into:
 * - Comprehensive token usage (total, per tool, per message, trends)
 * - Performance metrics (tool duration, session length)
 * - Cost estimation
 * - Usage patterns
 *
 * Usage:
 *   node analyze_logs.mjs [session_file.jsonl]
 *   node analyze_logs.mjs --all
 *   node analyze_logs.mjs --tokens
 *   node analyze_logs.mjs --tools
 *   node analyze_logs.mjs --cost
 */

import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

// ═══════════════════════════════════════════════════════════════════════════
// Configuration
// ═══════════════════════════════════════════════════════════════════════════

const LOGS_DIR = '.ai_logs';
const DEFAULT_ANALYSIS = 'summary'; // summary, tokens, tools, cost, performance, all

// ═══════════════════════════════════════════════════════════════════════════
// ANSI Color Codes
// ═══════════════════════════════════════════════════════════════════════════

const COLORS = {
  reset: '\x1b[0m',
  bold: '\x1b[1m',
  dim: '\x1b[2m',
  red: '\x1b[31m',
  green: '\x1b[32m',
  yellow: '\x1b[33m',
  blue: '\x1b[34m',
  magenta: '\x1b[35m',
  cyan: '\x1b[36m',
  white: '\x1b[37m',
};

function color(text, colorName) {
  return `${COLORS[colorName] || ''}${text}${COLORS.reset}`;
}

// ═══════════════════════════════════════════════════════════════════════════
// Log Loading
// ═══════════════════════════════════════════════════════════════════════════

function findLogsDir(startPath = process.cwd()) {
  let currentPath = startPath;
  while (currentPath !== path.dirname(currentPath)) {
    const logsPath = path.join(currentPath, LOGS_DIR);
    if (fs.existsSync(logsPath)) {
      return logsPath;
    }
    // Also check for .git to find repo root
    if (fs.existsSync(path.join(currentPath, '.git'))) {
      const repoLogsPath = path.join(currentPath, LOGS_DIR);
      if (fs.existsSync(repoLogsPath)) {
        return repoLogsPath;
      }
      // Create it if we're at repo root
      fs.mkdirSync(repoLogsPath, { recursive: true });
      return repoLogsPath;
    }
    currentPath = path.dirname(currentPath);
  }
  return null;
}

function loadSessionLog(filePath) {
  const lines = fs
    .readFileSync(filePath, 'utf8')
    .split('\n')
    .filter((l) => l.trim());
  return lines
    .map((line) => {
      try {
        return JSON.parse(line);
      } catch {
        return null;
      }
    })
    .filter((entry) => entry !== null);
}

function findLatestSession(logsDir) {
  const files = fs
    .readdirSync(logsDir)
    .filter((f) => f.startsWith('session_') && f.endsWith('.jsonl'))
    .map((f) => ({
      name: f,
      path: path.join(logsDir, f),
      mtime: fs.statSync(path.join(logsDir, f)).mtime,
    }))
    .sort((a, b) => b.mtime - a.mtime);

  return files.length > 0 ? files[0].path : null;
}

function _loadAllSessions(logsDir) {
  const files = fs
    .readdirSync(logsDir)
    .filter((f) => f.startsWith('session_') && f.endsWith('.jsonl'))
    .map((f) => path.join(logsDir, f));

  return files.flatMap((file) => loadSessionLog(file));
}

// ═══════════════════════════════════════════════════════════════════════════
// Analysis Functions
// ═══════════════════════════════════════════════════════════════════════════

function analyzeTokens(entries) {
  const tokenEvents = entries.filter(
    (e) => e.event === 'onTokenUsage' || e.event === 'afterMessage'
  );

  let totalPrompt = 0;
  let totalCompletion = 0;
  let totalTokens = 0;
  const perMessage = [];
  const byTool = {};

  tokenEvents.forEach((e) => {
    const tokens = e.data?.tokens || {};
    const cumulative = e.data?.cumulative || {};

    if (tokens.prompt !== undefined) {
      totalPrompt += tokens.prompt || 0;
      totalCompletion += tokens.completion || 0;
      totalTokens += tokens.total || 0;

      perMessage.push({
        messageId: e.messageId,
        timestamp: e.timestamp,
        tokens: { ...tokens },
      });
    }

    // Extract per-tool stats from cumulative
    if (cumulative.byTool) {
      Object.assign(byTool, cumulative.byTool);
    }
  });

  // Also extract from session_end summary
  const sessionEnd = entries.find((e) => e.event === 'session_end');
  if (sessionEnd?.summary?.tokens) {
    const { prompt, completion, total, byTool: toolStats } = sessionEnd.summary.tokens;
    totalPrompt = prompt || totalPrompt;
    totalCompletion = completion || totalCompletion;
    totalTokens = total || totalTokens;
    if (toolStats) {
      Object.assign(byTool, toolStats);
    }
  }

  return {
    total: {
      prompt: totalPrompt,
      completion: totalCompletion,
      total: totalTokens,
    },
    perMessage,
    byTool,
  };
}

function analyzeTools(entries) {
  const toolEvents = entries.filter(
    (e) => e.event === 'beforeToolUse' || e.event === 'afterToolUse'
  );

  const tools = {};
  const _durations = {};

  toolEvents.forEach((e) => {
    const toolName = e.toolName || 'unknown';

    if (!tools[toolName]) {
      tools[toolName] = {
        count: 0,
        totalDuration: 0,
        avgDuration: 0,
        maxDuration: 0,
        minDuration: Infinity,
        errors: 0,
        totalTokens: 0,
      };
    }

    if (e.event === 'afterToolUse') {
      tools[toolName].count++;
      const duration = e.data?.durationMs || 0;
      tools[toolName].totalDuration += duration;
      tools[toolName].maxDuration = Math.max(tools[toolName].maxDuration, duration);
      tools[toolName].minDuration = Math.min(tools[toolName].minDuration, duration);
      tools[toolName].totalTokens += e.data?.estimatedTokens || 0;

      if (!e.data?.success) {
        tools[toolName].errors++;
      }
    }
  });

  // Calculate averages
  Object.values(tools).forEach((tool) => {
    if (tool.count > 0) {
      tool.avgDuration = Math.round(tool.totalDuration / tool.count);
    }
    if (tool.minDuration === Infinity) {
      tool.minDuration = 0;
    }
  });

  return tools;
}

function analyzeCost(tokenData) {
  const { total } = tokenData;

  // Pricing (adjust as needed)
  const INPUT_COST_PER_MTOK = 3.0;
  const OUTPUT_COST_PER_MTOK = 15.0;

  const inputCost = (total.prompt / 1_000_000) * INPUT_COST_PER_MTOK;
  const outputCost = (total.completion / 1_000_000) * OUTPUT_COST_PER_MTOK;
  const totalCost = inputCost + outputCost;

  return {
    input: inputCost,
    output: outputCost,
    total: totalCost,
    currency: 'USD',
    rateInfo: {
      inputPerMTok: INPUT_COST_PER_MTOK,
      outputPerMTok: OUTPUT_COST_PER_MTOK,
    },
  };
}

function analyzePerformance(entries) {
  const _sessionStart = entries.find((e) => e.event === 'session_start');
  const sessionEnd = entries.find((e) => e.event === 'session_end');

  const durationMs = sessionEnd?.sessionDurationMs || 0;
  const totalMessages = sessionEnd?.summary?.totalMessages || 0;

  const warnings = entries.filter(
    (e) => e.event === 'token_warning' || e.event === 'performance_warning'
  );

  return {
    sessionDurationMs: durationMs,
    sessionDurationHuman: formatDuration(durationMs),
    totalMessages,
    avgMessageTime: totalMessages > 0 ? Math.round(durationMs / totalMessages) : 0,
    warnings: {
      count: warnings.length,
      details: warnings.map((w) => ({
        type: w.event,
        message: w.message,
        timestamp: w.timestamp,
      })),
    },
  };
}

// ═══════════════════════════════════════════════════════════════════════════
// Formatting Utilities
// ═══════════════════════════════════════════════════════════════════════════

function formatNumber(num) {
  return num.toLocaleString();
}

function formatDuration(ms) {
  const seconds = Math.floor(ms / 1000);
  const minutes = Math.floor(seconds / 60);
  const hours = Math.floor(minutes / 60);

  if (hours > 0) {
    return `${hours}h ${minutes % 60}m ${seconds % 60}s`;
  } else if (minutes > 0) {
    return `${minutes}m ${seconds % 60}s`;
  } else {
    return `${seconds}s`;
  }
}

function formatCurrency(amount, currency = 'USD') {
  return `${currency} $${amount.toFixed(4)}`;
}

// ═══════════════════════════════════════════════════════════════════════════
// Report Generators
// ═══════════════════════════════════════════════════════════════════════════

function printHeader(title) {
  console.log('\n' + color('═'.repeat(80), 'cyan'));
  console.log(color(`  ${title}`, 'bold'));
  console.log(color('═'.repeat(80), 'cyan'));
}

function printSummary(entries) {
  printHeader('Session Summary');

  const sessionStart = entries.find((e) => e.event === 'session_start');
  const sessionEnd = entries.find((e) => e.event === 'session_end');

  if (sessionStart) {
    console.log(color('\nSession Info:', 'yellow'));
    console.log(`  Session ID: ${sessionStart.sessionId}`);
    console.log(`  Started:    ${new Date(sessionStart.timestamp).toLocaleString()}`);
    console.log(
      `  Platform:   ${sessionStart.environment?.platform} (${sessionStart.environment?.arch})`
    );
    console.log(`  Node:       ${sessionStart.environment?.node}`);
  }

  if (sessionEnd) {
    console.log(color('\nSession Duration:', 'yellow'));
    console.log(`  Total:      ${formatDuration(sessionEnd.sessionDurationMs)}`);
    console.log(`  Messages:   ${sessionEnd.summary?.totalMessages || 0}`);
  }

  const tokenData = analyzeTokens(entries);
  const costData = analyzeCost(tokenData);

  console.log(color('\nToken Usage:', 'yellow'));
  console.log(`  Prompt:     ${color(formatNumber(tokenData.total.prompt), 'cyan')} tokens`);
  console.log(`  Completion: ${color(formatNumber(tokenData.total.completion), 'cyan')} tokens`);
  console.log(`  Total:      ${color(formatNumber(tokenData.total.total), 'bold')} tokens`);

  console.log(color('\nEstimated Cost:', 'yellow'));
  console.log(`  Input:      ${color(formatCurrency(costData.input), 'green')}`);
  console.log(`  Output:     ${color(formatCurrency(costData.output), 'green')}`);
  console.log(`  Total:      ${color(formatCurrency(costData.total), 'bold')}`);

  const perfData = analyzePerformance(entries);
  if (perfData.warnings.count > 0) {
    console.log(color(`\n⚠️  Warnings: ${perfData.warnings.count}`, 'red'));
  }
}

function printTokenAnalysis(entries) {
  printHeader('Comprehensive Token Analysis');

  const tokenData = analyzeTokens(entries);
  const costData = analyzeCost(tokenData);

  // Overall stats
  console.log(color('\n📊 Overall Token Usage:', 'yellow'));
  console.log(`  Prompt Tokens:     ${color(formatNumber(tokenData.total.prompt), 'cyan')}`);
  console.log(`  Completion Tokens: ${color(formatNumber(tokenData.total.completion), 'cyan')}`);
  console.log(`  Total Tokens:      ${color(formatNumber(tokenData.total.total), 'bold')}`);
  console.log(
    `  Ratio (out/in):    ${color((tokenData.total.completion / tokenData.total.prompt).toFixed(2), 'magenta')}`
  );

  // Cost breakdown
  console.log(color('\n💰 Cost Breakdown:', 'yellow'));
  console.log(
    `  Input Cost:  ${color(formatCurrency(costData.input), 'green')} (${formatNumber(tokenData.total.prompt)} tokens @ $${costData.rateInfo.inputPerMTok}/MTok)`
  );
  console.log(
    `  Output Cost: ${color(formatCurrency(costData.output), 'green')} (${formatNumber(tokenData.total.completion)} tokens @ $${costData.rateInfo.outputPerMTok}/MTok)`
  );
  console.log(`  Total Cost:  ${color(formatCurrency(costData.total), 'bold')}`);

  // Per-message breakdown
  if (tokenData.perMessage.length > 0) {
    console.log(color('\n📝 Per-Message Token Usage:', 'yellow'));
    console.log(color('  Msg ID  | Prompt  | Completion | Total   | Cost', 'dim'));
    console.log(color('  --------|---------|------------|---------|----------', 'dim'));

    tokenData.perMessage.forEach((msg) => {
      const msgCost = analyzeCost({ total: msg.tokens });
      const msgId = String(msg.messageId).padStart(6);
      const prompt = String(msg.tokens.prompt || 0).padStart(7);
      const completion = String(msg.tokens.completion || 0).padStart(10);
      const total = String(msg.tokens.total || 0).padStart(7);
      const cost = `$${msgCost.total.toFixed(4)}`.padStart(8);

      console.log(`  ${msgId}  | ${prompt} | ${completion} | ${total} | ${cost}`);
    });

    // Statistics
    const avgTokens = tokenData.total.total / tokenData.perMessage.length;
    const maxMessage = tokenData.perMessage.reduce((max, msg) =>
      (msg.tokens.total || 0) > (max.tokens.total || 0) ? msg : max
    );

    console.log(color('\n  Statistics:', 'yellow'));
    console.log(
      `    Average per message: ${color(formatNumber(Math.round(avgTokens)), 'cyan')} tokens`
    );
    console.log(
      `    Max single message:  ${color(formatNumber(maxMessage.tokens.total), 'cyan')} tokens (Message ${maxMessage.messageId})`
    );
  }

  // Per-tool breakdown
  if (Object.keys(tokenData.byTool).length > 0) {
    console.log(color('\n🔧 Per-Tool Token Estimate:', 'yellow'));
    console.log(color('  Tool Name         | Calls | Total Tokens | Avg/Call', 'dim'));
    console.log(color('  ------------------|-------|--------------|----------', 'dim'));

    const sortedTools = Object.entries(tokenData.byTool).sort(
      (a, b) => b[1].totalTokens - a[1].totalTokens
    );

    sortedTools.forEach(([toolName, stats]) => {
      const name = toolName.padEnd(17);
      const calls = String(stats.count).padStart(5);
      const total = String(stats.totalTokens).padStart(12);
      const avg = String(Math.round(stats.totalTokens / stats.count)).padStart(8);

      console.log(`  ${name} | ${calls} | ${total} | ${avg}`);
    });
  }
}

function printToolAnalysis(entries) {
  printHeader('Tool Usage Analysis');

  const tools = analyzeTools(entries);

  if (Object.keys(tools).length === 0) {
    console.log(color('\n  No tool usage data found.', 'dim'));
    return;
  }

  console.log(color('\n🔧 Tool Performance:', 'yellow'));
  console.log(
    color('  Tool Name         | Calls | Avg Time | Max Time | Errors | Est. Tokens', 'dim')
  );
  console.log(
    color('  ------------------|-------|----------|----------|--------|-------------', 'dim')
  );

  const sortedTools = Object.entries(tools).sort((a, b) => b[1].count - a[1].count);

  sortedTools.forEach(([toolName, stats]) => {
    const name = toolName.padEnd(17);
    const calls = String(stats.count).padStart(5);
    const avgTime = `${stats.avgDuration}ms`.padStart(8);
    const maxTime = `${stats.maxDuration}ms`.padStart(8);
    const errors = String(stats.errors).padStart(6);
    const tokens = String(stats.totalTokens).padStart(11);

    const errorColor = stats.errors > 0 ? 'red' : 'white';

    console.log(
      `  ${name} | ${calls} | ${avgTime} | ${maxTime} | ${color(errors, errorColor)} | ${tokens}`
    );
  });

  // Tool efficiency
  console.log(color('\n📈 Tool Efficiency (tokens per call):', 'yellow'));
  const efficiency = Object.entries(tools)
    .map(([name, stats]) => ({
      name,
      efficiency: stats.totalTokens / stats.count,
    }))
    .sort((a, b) => b.efficiency - a.efficiency)
    .slice(0, 10);

  efficiency.forEach((tool) => {
    const bar = '█'.repeat(Math.min(Math.round(tool.efficiency / 100), 50));
    console.log(`  ${tool.name.padEnd(20)} ${color(bar, 'cyan')} ${Math.round(tool.efficiency)}`);
  });
}

function printPerformanceAnalysis(entries) {
  printHeader('Performance Analysis');

  const perfData = analyzePerformance(entries);

  console.log(color('\n⏱️  Session Performance:', 'yellow'));
  console.log(`  Duration:        ${perfData.sessionDurationHuman}`);
  console.log(`  Total Messages:  ${perfData.totalMessages}`);
  console.log(`  Avg per Message: ${perfData.avgMessageTime}ms`);

  if (perfData.warnings.count > 0) {
    console.log(color(`\n⚠️  Performance Warnings (${perfData.warnings.count}):`, 'red'));
    perfData.warnings.details.forEach((w) => {
      console.log(`  ${color('•', 'red')} ${w.message}`);
      console.log(`    ${color(new Date(w.timestamp).toLocaleString(), 'dim')}`);
    });
  } else {
    console.log(color('\n✅ No performance warnings', 'green'));
  }
}

// ═══════════════════════════════════════════════════════════════════════════
// Main
// ═══════════════════════════════════════════════════════════════════════════

function main() {
  const args = process.argv.slice(2);

  // Determine analysis type
  let analysisType = DEFAULT_ANALYSIS;
  let sessionFile = null;

  if (args.includes('--all')) {
    analysisType = 'all';
  } else if (args.includes('--tokens')) {
    analysisType = 'tokens';
  } else if (args.includes('--tools')) {
    analysisType = 'tools';
  } else if (args.includes('--cost')) {
    analysisType = 'cost';
  } else if (args.includes('--performance')) {
    analysisType = 'performance';
  } else if (args.length > 0 && !args[0].startsWith('--')) {
    sessionFile = args[0];
  }

  // Find logs directory
  const logsDir = findLogsDir();
  if (!logsDir) {
    console.error(color('❌ Could not find .ai_logs directory', 'red'));
    console.error(color('   Run this from a repository with logging enabled', 'dim'));
    process.exit(1);
  }

  // Load session data
  let entries = [];
  if (sessionFile) {
    entries = loadSessionLog(sessionFile);
    console.log(color(`\nAnalyzing: ${path.basename(sessionFile)}`, 'cyan'));
  } else {
    const latestSession = findLatestSession(logsDir);
    if (!latestSession) {
      console.error(color('❌ No session logs found', 'red'));
      process.exit(1);
    }
    entries = loadSessionLog(latestSession);
    console.log(color(`\nAnalyzing: ${path.basename(latestSession)} (latest)`, 'cyan'));
  }

  if (entries.length === 0) {
    console.error(color('❌ No log entries found', 'red'));
    process.exit(1);
  }

  // Generate reports
  if (analysisType === 'summary' || analysisType === 'all') {
    printSummary(entries);
  }

  if (analysisType === 'tokens' || analysisType === 'all') {
    printTokenAnalysis(entries);
  }

  if (analysisType === 'tools' || analysisType === 'all') {
    printToolAnalysis(entries);
  }

  if (analysisType === 'performance' || analysisType === 'all') {
    printPerformanceAnalysis(entries);
  }

  console.log('\n');
}

main();
