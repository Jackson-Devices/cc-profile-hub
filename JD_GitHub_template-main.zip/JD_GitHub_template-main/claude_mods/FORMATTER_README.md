# Claude Code Configuration

This directory contains Claude Code CLI configuration, hooks, and scripts for the repository.

## Directory Structure

```
.claude/
├── hooks/              # Pre-commit and other git hooks
│   └── pre_commit_format.mjs    # Automatic formatting hook
├── scripts/            # Utility scripts used by hooks
│   └── format_diff.mjs          # Diff presentation module
├── hooks.json          # Active hooks configuration (gitignored, user-specific)
└── hooks.json.example  # Example hooks configuration
```

## Formatter Setup

### Installation

1. **Install hook and script files to .claude directory:**

   ```bash
   # Create .claude directories if they don't exist
   mkdir -p .claude/hooks .claude/scripts

   # Copy hook files
   cp claude_mods/hooks/pre_commit_format.mjs .claude/hooks/
   cp claude_mods/scripts/format_diff.mjs .claude/scripts/

   # Make executable
   chmod +x .claude/hooks/pre_commit_format.mjs .claude/scripts/format_diff.mjs
   ```

2. **Enable the hook:**

   ```bash
   # If you don't have .claude/hooks.json yet:
   cp claude_mods/hooks.json.formatter.example .claude/hooks.json

   # OR if you already have hooks.json, manually add the pre_commit hook:
   # See claude_mods/hooks.json.formatter_and_squash.example for combined config
   ```

3. **Install dependencies** (if not already installed):

   ```bash
   npm install
   ```

4. **Test the hook** (stage a file and try to commit):
   ```bash
   git add somefile.yml
   git commit -m "test"
   ```

The pre-commit hook will automatically run and check formatting.

### How It Works

When you commit files, the pre-commit hook:

1. **Detects** staged files (.yml, .yaml, .md, .json, .js, .ts, .mjs, .css, .html, .sh)
2. **Checks** if formatting is needed (runs Prettier)
3. **Presents** color-coded diff if changes are required
4. **Asks** how you want to proceed:
   - **[r] replace** - Accept all formatting changes, update staging area
   - **[m] merge** - Review changes file-by-file (approve/reject per file)
   - **[c] cancel** - Abort commit, keep original formatting
5. **Applies** formatting based on your choice
6. **Logs** operation to `.ai_logs/formatter_log.jsonl`

### Features

- ✅ **Color-coded diffs** (red = removed, green = added)
- ✅ **File-by-file review** mode
- ✅ **Summary statistics** (files changed, lines added/removed)
- ✅ **Non-blocking** (you can cancel if needed)
- ✅ **Auto-staging** (formatted files are automatically staged)
- ✅ **Comprehensive logging** (all operations logged)

### Manual Testing

You can test the formatter manually on any files:

```bash
# Check all files
npm run format:check

# Format all files
npm run format

# Format only staged files
npm run format:staged

# Test the diff UI directly
node .claude/scripts/format_diff.mjs path/to/file.yml
```

### Disabling the Hook

To temporarily disable the pre-commit hook:

1. Edit `.claude/hooks.json`
2. Set `"enabled": false` for the `pre_commit` hook
3. Or delete `.claude/hooks.json` to disable all hooks

### Troubleshooting

**Hook not running:**

- Ensure `.claude/hooks.json` exists (copy from `.claude/hooks.json.example`)
- Ensure `"enabled": true` in hooks.json
- Ensure scripts are executable: `chmod +x .claude/hooks/*.mjs .claude/scripts/*.mjs`

**Prettier errors:**

- Ensure dependencies are installed: `npm install`
- Check Prettier configuration: `.prettierrc.json`

**Git errors:**

- Ensure you're in a git repository: `git status`
- Ensure files are staged: `git add <files>`

## Configuration Files

This directory is for **user-specific** configuration and is gitignored. The repository provides:

- `.claude/hooks.json.example` - Example hooks configuration
- `.claude/hooks/` - Hook scripts (committed to repo)
- `.claude/scripts/` - Utility scripts (committed to repo)

Users create their own `.claude/hooks.json` by copying the example.

## More Information

See:

- `docs/formatters/README.md` - Formatter system overview (when created)
- `docs/formatters/HOUSE_STYLE.md` - Style rules (when created)
- `TODO.md` - Code formatter implementation progress
