# Commit Squashing Best Practices

This guide explains when and how to squash commits effectively, helping you maintain a clean and meaningful git history.

## Table of Contents

- [Why Squash Commits?](#why-squash-commits)
- [When to Squash](#when-to-squash)
- [When NOT to Squash](#when-not-to-squash)
- [Squashing Strategies](#squashing-strategies)
- [Common Scenarios](#common-scenarios)
- [Examples](#examples)
- [Git History Philosophy](#git-history-philosophy)

---

## Why Squash Commits?

### Benefits of Clean History

1. **Improved Readability**
   - One commit per feature/fix makes history easier to understand
   - Reviewers can see complete changes without noise
   - Future developers understand intent better

2. **Better Debugging**
   - `git bisect` is more effective with meaningful commits
   - Easier to identify when bugs were introduced
   - Simpler to revert problematic changes

3. **Professional Collaboration**
   - Clean history shows professional development practices
   - Easier for team members to review and understand
   - Better for open source contributions

4. **Simplified Release Management**
   - Changelogs are easier to generate
   - Release notes are clearer
   - Cherry-picking features is simpler

### Problems with Messy History

**Before Squashing (Messy):**

```
a1b2c3d WIP: started feature
e4f5g6h fix typo
i7j8k9l debug logging
m9n8o7p remove debug
p6q5r4s actually fix the bug
t3u2v1w update tests
x0y9z8a fix test
b7c6d5e final fix
```

**After Squashing (Clean):**

```
f4e3d2c Add user authentication feature

- Implement login/logout functionality
- Add password hashing with bcrypt
- Create user session management
- Add comprehensive test coverage
```

---

## When to Squash

### ✅ Always Squash These

1. **Work-in-Progress (WIP) Commits**

   ```
   ❌ WIP: initial attempt
   ❌ WIP: still working on it
   ❌ WIP: almost done
   ✅ Add feature X (squashed)
   ```

2. **Fix Commits That Fix Previous Commits**

   ```
   ❌ Add validation
   ❌ fix typo in validation
   ❌ fix validation bug
   ❌ another validation fix
   ✅ Add input validation (squashed)
   ```

3. **Debug/Temporary Commits**

   ```
   ❌ add debug logging
   ❌ more debug info
   ❌ remove debug logging
   ✅ Fix race condition in event handler (squashed)
   ```

4. **Multiple Small Changes to Same Feature**

   ```
   ❌ add button
   ❌ style button
   ❌ add button handler
   ❌ fix button alignment
   ✅ Add submit button with validation (squashed)
   ```

5. **Commits During AI-Assisted Development**
   - Claude Code often makes multiple commits during a session
   - These incremental commits should usually be squashed
   - Each AI pass/attempt can be one commit (if successful)

### ✅ Usually Squash These

1. **Commits from Same Author Within Short Timeframe**
   - Multiple commits within 1 hour from same author
   - Likely part of same work session
   - Exception: if commits are truly independent changes

2. **Refactoring with Multiple Steps**
   - Rename variables → Update tests → Fix edge cases
   - Squash into: "Refactor validation module"

3. **Documentation Updates During Feature Work**
   - Add feature → Update README → Fix README typo
   - Squash into: "Add feature X with documentation"

---

## When NOT to Squash

### ❌ Never Squash These

1. **Commits from Multiple Authors**

   ```
   ✅ Alice: Add database schema
   ✅ Bob: Add API endpoints
   ❌ DON'T squash → loses attribution
   ```

2. **Separate Logical Changes**

   ```
   ✅ Fix bug #123 in user login
   ✅ Add feature: password reset
   ❌ DON'T squash → separate concerns
   ```

3. **Already Pushed to Shared Branch**
   - If others have pulled your commits, DON'T squash
   - Squashing requires force push (dangerous)
   - Exception: feature branches that only you use

4. **Deliberate Checkpoint Commits**
   ```
   ✅ Implement phase 1: data model
   ✅ Implement phase 2: API layer
   ✅ Implement phase 3: UI components
   ❌ DON'T squash → intentional milestones
   ```

### ❌ Usually Don't Squash These

1. **Bug Fixes with Separate Test Commits**

   ```
   ✅ Fix: Handle null pointer in parser
   ✅ Test: Add regression test for null handling
   ⚠️  Consider keeping separate for clarity
   ```

2. **Refactoring Followed by Feature**

   ```
   ✅ Refactor: Extract validation helper
   ✅ Feature: Add email validation using helper
   ⚠️  Keep separate to show intent
   ```

3. **Commits with Different Types**
   ```
   ✅ fix: resolve race condition
   ✅ docs: update API documentation
   ✅ test: add unit tests for edge cases
   ⚠️  Different types → keep separate
   ```

---

## Squashing Strategies

### Strategy 1: Squash All (Recommended for Most Cases)

**When to use:**

- All commits from same author
- All commits part of same feature/fix
- Commits are incremental work (WIP, fix, update, etc.)

**How it works:**

- Combines all commits into one
- Keeps all file changes
- Creates new commit message summarizing all work

**Example:**

```bash
Before: 5 commits (WIP, fix, update, test, final)
After:  1 commit (Add authentication feature)
```

### Strategy 2: Interactive Squash (Advanced)

**When to use:**

- Want to keep some commits separate
- Need to reorder commits
- Want to edit commit messages individually
- Mixed types of changes

**How it works:**

- Opens interactive rebase editor
- You choose what to do with each commit:
  - `pick` = keep commit as-is
  - `squash` = merge with previous, keep message
  - `fixup` = merge with previous, discard message
  - `drop` = remove commit entirely
  - `reword` = keep commit, change message

**Example:**

```bash
Before:
  1. Add feature A
  2. WIP feature B
  3. Fix feature B
  4. Add tests for B
  5. Update docs

After interactive squash:
  1. Add feature A (picked)
  2. Add feature B (squashed 2+3+4)
  3. Update documentation (reworded from 5)
```

### Strategy 3: Keep Separate (No Squashing)

**When to use:**

- Multiple authors
- Separate logical changes
- Already pushed to shared branch
- Intentional checkpoint commits

**How it works:**

- No squashing performed
- All commits pushed as-is
- Preserves complete history

---

## Common Scenarios

### Scenario 1: AI-Assisted Feature Development

**Situation:**
Claude Code creates 7 commits while implementing a feature:

```
1. Initial implementation
2. Fix syntax error
3. Add error handling
4. Update tests
5. Fix test failures
6. Add documentation
7. Fix typo in docs
```

**Recommendation:** **Squash All**

**Reason:**

- Single author (you + Claude)
- Single feature
- Incremental development
- Final state is what matters

**Result:**

```
Add user profile feature

- Implement profile CRUD operations
- Add comprehensive error handling
- Include unit and integration tests
- Update API documentation
```

### Scenario 2: Multiple Independent Bug Fixes

**Situation:**
You fix 3 separate bugs in one session:

```
1. Fix null pointer in parser
2. Fix race condition in event handler
3. Fix memory leak in cache
```

**Recommendation:** **Keep Separate**

**Reason:**

- Three different bugs
- Different files/modules
- Independent fixes
- Easier to track/revert individually

**Result:**

```
1. Fix: Handle null values in JSON parser
2. Fix: Resolve race condition in event handler
3. Fix: Prevent memory leak in cache manager
```

### Scenario 3: Feature + Refactoring

**Situation:**
You refactor code, then add a feature:

```
1. Refactor: Extract database helper
2. Refactor: Simplify query logic
3. Add: User search feature
4. Fix: Typo in search
```

**Recommendation:** **Interactive Squash**

**Reason:**

- Refactoring is separate concern from feature
- But refactoring commits can be squashed together
- Feature commits (3+4) should be squashed

**Result:**

```
1. Refactor database query logic (squashed 1+2)
2. Add user search feature (squashed 3+4)
```

### Scenario 4: Collaborative Feature Branch

**Situation:**
You and teammate work on feature branch:

```
1. Alice: Add database schema
2. Alice: Fix schema bug
3. Bob: Add API endpoints
4. Bob: Fix API bug
5. Alice: Add frontend
```

**Recommendation:** **Selective Interactive Squash**

**Reason:**

- Multiple authors → preserve attribution
- But each author's incremental commits can be squashed

**Process:**

1. Alice squashes her commits: 1+2 → "Add database schema"
2. Bob squashes his commits: 3+4 → "Add API endpoints"
3. Alice's commit 5 stays separate: "Add frontend"

**Result:**

```
1. Alice: Add database schema
2. Bob: Add API endpoints
3. Alice: Add frontend components
```

### Scenario 5: Already Pushed Commits

**Situation:**
You pushed 5 commits to remote, then realize you should have squashed:

```
1. WIP: feature start (pushed)
2. Fix: typo (pushed)
3. Update: more work (pushed)
4. Final: done (local only)
```

**Recommendation:** **Depends on Branch Type**

**If feature/personal branch (no collaborators):**

- Squash all 4 commits
- Force push: `git push --force-with-lease`
- Safe because only you use this branch

**If shared branch (others have pulled):**

- DON'T squash commits 1-3 (already pushed)
- Only squash commit 4 into 3 if really needed
- Avoid force push to shared branches

---

## Examples

### Example 1: Before and After Squashing

**Before Squashing:**

```bash
$ git log --oneline
a1b2c3d (HEAD -> feature-branch) fix typo in comment
e4f5g6h add final test case
i7j8k9l fix test failure
m9n8o7p add error handling
p6q5r4s fix syntax error
t3u2v1w initial implementation
x0y9z8a (origin/main) Previous work
```

**After Squashing:**

```bash
$ git log --oneline
f4e3d2c (HEAD -> feature-branch) Add input validation feature
x0y9z8a (origin/main) Previous work
```

**Squashed Commit Message:**

```
Add input validation feature

Implemented comprehensive input validation for user forms:
- Added regex-based email validation
- Added password strength checking
- Added phone number format validation
- Included error messages for all validation failures
- Added unit tests with 95% coverage
```

### Example 2: Interactive Squash Session

**Starting State:**

```bash
$ git log --oneline
a1b2c3d (HEAD) docs: update README
e4f5g6h test: add edge case
i7j8k9l fix: handle null input
m9n8o7p wip: feature work
p6q5r4s feat: add validation
t3u2v1w (origin/main) Previous work
```

**Interactive Rebase:**

```bash
$ git rebase -i origin/main
```

**Editor shows:**

```
pick p6q5r4s feat: add validation
fixup m9n8o7p wip: feature work
fixup i7j8k9l fix: handle null input
pick e4f5g6h test: add edge case
reword a1b2c3d docs: update README
```

**Result:**

```bash
$ git log --oneline
b7c6d5e (HEAD) docs: Add validation documentation
e4f5g6h test: add edge case
f4e3d2c feat: add validation
t3u2v1w (origin/main) Previous work
```

### Example 3: Real-World Claude Code Session

**Before (typical Claude Code session):**

```bash
$ git log --oneline --all
a1b2c3d (HEAD -> claude/feature-xyz) Apply review feedback
e4f5g6h Fix linting errors
i7j8k9l Update tests
m9n8o7p Fix test failures
p6q5r4s Add test coverage
t3u2v1w Implement feature logic
x0y9z8a Initial feature scaffold
b7c6d5e (origin/main) Merge pull request #15
```

**Recommendation:** Squash all (commits a1b2c3d through x0y9z8a)

**Squash Process:**

```bash
$ git reset --soft origin/main
$ git commit -m "Add feature XYZ

- Implement core feature logic
- Add comprehensive test coverage
- Apply code review feedback
- Pass all linting and tests"
```

**After:**

```bash
$ git log --oneline --all
f4e3d2c (HEAD -> claude/feature-xyz) Add feature XYZ
b7c6d5e (origin/main) Merge pull request #15
```

---

## Git History Philosophy

### The "Why vs What" Rule

**Good commits answer "Why?"**

```
✅ Fix: Prevent race condition in user session cleanup

The session cleanup timer could fire while a user was still active,
causing premature logout. Added synchronization to prevent cleanup
during active sessions.
```

**Poor commits only show "What?"**

```
❌ update session.js
❌ fix bug
❌ changes
```

### Atomic Commits

Each commit should be:

1. **Complete** - Includes all changes needed for the feature/fix
2. **Functional** - Code compiles/runs at this commit
3. **Focused** - Does one thing well
4. **Reversible** - Can be reverted without breaking other features

### Commit Message Best Practices

**Format:**

```
<type>: <short summary> (50 chars or less)

<detailed explanation if needed>

- Key change 1
- Key change 2
- Key change 3

Fixes #123
Related to #456
```

**Types:**

- `feat`: New feature
- `fix`: Bug fix
- `docs`: Documentation changes
- `test`: Test additions/changes
- `refactor`: Code refactoring
- `perf`: Performance improvement
- `chore`: Maintenance tasks

---

## Decision Matrix

Use this matrix to decide whether to squash:

| Criteria                  | Squash All | Interactive | Keep Separate |
| ------------------------- | ---------- | ----------- | ------------- |
| Single author             | ✅         | ✅          | ❌            |
| Multiple authors          | ❌         | Maybe       | ✅            |
| WIP/fix commits           | ✅         | ✅          | ❌            |
| Single feature            | ✅         | ❌          | ❌            |
| Multiple features         | ❌         | ✅          | ✅            |
| Same timeframe            | ✅         | ❌          | ❌            |
| Separate concerns         | ❌         | ✅          | ✅            |
| Already pushed (shared)   | ❌         | ❌          | ✅            |
| Already pushed (personal) | ✅         | ✅          | ❌            |
| Incremental work          | ✅         | ❌          | ❌            |
| Deliberate checkpoints    | ❌         | ✅          | ✅            |

---

## Hook Recommendations

When the pre-push squashing hook runs, it analyzes your commits and provides recommendations. Here's what each recommendation means:

### "Squash all commits" (High Confidence)

**What it means:**

- All commits from same author
- Most commits are WIP/fix/update type
- All within short timeframe
- Likely part of same work session

**What to do:**

- Choose **Option 1** (Squash all)
- Review generated commit message
- Customize message if needed

### "Interactive squash" (Medium/Low Confidence)

**What it means:**

- Mixed commit types detected
- May have separate concerns mixed together
- Hook isn't sure what you intended

**What to do:**

- Choose **Option 2** (Interactive)
- Review each commit individually
- Squash related commits, keep separate concerns

### "Keep commits separate" (High Confidence)

**What it means:**

- Multiple authors detected
- Commits appear to be separate concerns
- Good attribution/organization already

**What to do:**

- Choose **Option 3** (Keep separate)
- Proceed with push as-is

---

## Summary

**Default Strategy:**

- **When working with Claude Code:** Squash all commits from a single session
- **When collaborating:** Keep commits separate unless you own the branch
- **When in doubt:** Use interactive squash to review each commit

**Remember:**

- Git history is for humans, not computers
- Clean history helps future you and your teammates
- Squashing is about communication, not hiding work
- Use the hook's recommendations as a guide, not a rule

**Quick Tips:**

1. Squash before pushing to shared branches
2. Never force-push to shared branches after others have pulled
3. Use meaningful commit messages after squashing
4. Think "one commit per logical change"
5. Trust the hook's recommendations, but use your judgment

---

**Last Updated:** 2025-11-08
**Version:** 1.0
**Related:** [INSTALLATION.md](./INSTALLATION.md), [README.md](./README.md)
