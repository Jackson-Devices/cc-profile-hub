# Claude Code Comprehensive Logging - Usage Guide

This guide covers how to use the logging system, analyze logs, and optimize your Claude Code usage.

## Table of Contents

1. [Overview](#overview)
2. [What Gets Logged](#what-gets-logged)
3. [Analyzing Logs](#analyzing-logs)
4. [Understanding Token Usage](#understanding-token-usage)
5. [Optimizing Performance](#optimizing-performance)
6. [Privacy & Security](#privacy--security)
7. [Advanced Usage](#advanced-usage)
8. [Troubleshooting](#troubleshooting)

---

## Overview

The logging system captures **everything** Claude Code does during a session:

- Messages you send and responses from Claude
- Every tool call (Read, Write, Edit, Bash, Grep, etc.)
- Token usage (prompt, completion, total) per message and per tool
- Performance metrics (duration, warnings)
- Extended thinking process (optional)
- Real-time streaming (optional)

All data is saved to `.ai_logs/session_*.jsonl` in JSON Lines format.

### Zero Token Overhead

**Important**: Logging adds **ZERO additional tokens** to your Claude Code usage. The hooks run outside of the AI context and only observe what's happening.

---

## What Gets Logged

### Session Events

**`session_start`** - When Claude Code session begins

```json
{
  "event": "session_start",
  "sessionId": "sess_1234567890_abc123",
  "timestamp": "2025-11-08T14:30:00.000Z",
  "environment": {
    "node": "v18.17.0",
    "platform": "linux",
    "arch": "x64"
  }
}
```

**`session_end`** - When session ends (includes summary)

```json
{
  "event": "session_end",
  "sessionDurationMs": 3600000,
  "summary": {
    "totalMessages": 15,
    "tokens": {
      "prompt": 12000,
      "completion": 8000,
      "total": 20000,
      "estimatedCost": {
        "input": "0.0360",
        "output": "0.1200",
        "total": "0.1560",
        "currency": "USD"
      }
    },
    "topTools": [
      { "name": "Read", "count": 25, "totalTokens": 5000 },
      { "name": "Write", "count": 10, "totalTokens": 3000 }
    ]
  }
}
```

### Message Events

**`beforeMessage`** - Before prompt sent to Claude

- Message length
- Conversation turn number
- Preview of content (verbose mode only)

**`afterMessage`** - After Claude responds

- Token usage (prompt, completion, total)
- Estimated cost
- Response length
- Number of tool calls made

**`onTokenUsage`** - Dedicated token tracking event

- Tokens for this message
- Cumulative tokens for entire session
- Per-tool breakdown

### Tool Events

**`beforeToolUse`** - Before tool executes

- Tool name (Read, Write, Edit, Bash, etc.)
- Parameters passed to tool
- Timestamp

**`afterToolUse`** - After tool executes

- Tool name
- Duration (milliseconds)
- Success/failure status
- Result size
- Estimated tokens based on result

### Performance Events

**`token_warning`** - Message exceeded token threshold

```json
{
  "event": "token_warning",
  "level": "warn",
  "message": "Message used 55000 tokens (threshold: 50000)",
  "tokens": {...}
}
```

**`performance_warning`** - Tool took longer than threshold

```json
{
  "event": "performance_warning",
  "level": "warn",
  "message": "Tool Bash took 6500ms (threshold: 5000ms)",
  "toolName": "Bash",
  "durationMs": 6500
}
```

### Optional Events

**`onThinking`** (verbose mode) - Extended thinking process

- Captures Claude's internal reasoning
- High overhead - only enable for debugging

**`onStreamChunk`** (verbose mode) - Real-time streaming

- Captures response as it streams
- Very high overhead - debugging only

---

## Analyzing Logs

### Quick Analysis (Latest Session)

```bash
node claude_mods/analyze_logs.mjs
```

Prints summary of latest session:

- Session duration
- Total messages
- Token usage (prompt, completion, total)
- Estimated cost
- Warnings (if any)

### Comprehensive Token Analysis

```bash
node claude_mods/analyze_logs.mjs --tokens
```

Shows:

- **Overall Usage**: Total prompt/completion/total tokens, ratio
- **Cost Breakdown**: Input cost, output cost, total cost with pricing details
- **Per-Message Breakdown**: Table showing tokens for each message
- **Statistics**: Average per message, max single message
- **Per-Tool Estimate**: Tokens by tool (Read, Write, etc.)

Example output:

```
═══════════════════════════════════════════════════════════════════════════
  Comprehensive Token Analysis
═══════════════════════════════════════════════════════════════════════════

📊 Overall Token Usage:
  Prompt Tokens:     12,345
  Completion Tokens: 6,789
  Total Tokens:      19,134
  Ratio (out/in):    0.55

💰 Cost Breakdown:
  Input Cost:  USD $0.0370 (12,345 tokens @ $3.00/MTok)
  Output Cost: USD $0.1018 (6,789 tokens @ $15.00/MTok)
  Total Cost:  USD $0.1388

📝 Per-Message Token Usage:
  Msg ID  | Prompt  | Completion | Total   | Cost
  --------|---------|------------|---------|----------
       1  |    1234 |        567 |    1801 | $0.0122
       2  |    2345 |        890 |    3235 | $0.0204
  ...

🔧 Per-Tool Token Estimate:
  Tool Name         | Calls | Total Tokens | Avg/Call
  ------------------|-------|--------------|----------
  Read              |    25 |         5000 |      200
  Write             |    10 |         3000 |      300
  Edit              |     8 |         2000 |      250
```

### Tool Usage Analysis

```bash
node claude_mods/analyze_logs.mjs --tools
```

Shows:

- **Tool Performance Table**: Calls, avg time, max time, errors, estimated tokens
- **Tool Efficiency**: Tokens per call (helps identify expensive tools)

Useful for:

- Finding slow tools
- Identifying tool-heavy workflows
- Spotting tools that use lots of tokens

### Performance Analysis

```bash
node claude_mods/analyze_logs.mjs --performance
```

Shows:

- Session duration
- Total messages
- Average time per message
- Performance warnings (slow tools, high token usage)

### Full Analysis

```bash
node claude_mods/analyze_logs.mjs --all
```

Combines all analysis types above.

### Analyzing Specific Session

```bash
# List all sessions
ls -lh .ai_logs/session_*.jsonl

# Analyze specific session
node claude_mods/analyze_logs.mjs .ai_logs/session_2025-11-08_14-30-00.jsonl
```

---

## Understanding Token Usage

### What Are Tokens?

Tokens are the basic units of text that AI models process:

- **Prompt tokens**: Your input to Claude (questions, context, tool results)
- **Completion tokens**: Claude's responses (answers, tool calls)
- **Total tokens**: Prompt + completion

**Rule of thumb**: ~4 characters = 1 token (varies by language/content)

### Why Track Tokens?

1. **Cost**: You pay per token (input and output have different rates)
2. **Performance**: More tokens = slower responses
3. **Limits**: Models have maximum context windows
4. **Optimization**: Identify wasteful patterns

### Token Usage Patterns

**High prompt tokens:**

- Reading large files
- Providing lots of context
- Many tool results
- Long conversation history

**High completion tokens:**

- Verbose responses
- Large file writes
- Detailed explanations
- Multiple tool calls

**Optimization opportunities:**

- Use `Grep` instead of `Read` for searching
- Read files with `offset`/`limit` instead of entire file
- Be specific in questions (reduces verbose responses)
- Break large tasks into smaller chunks

### Cost Estimation

The logger estimates cost using current Claude Sonnet 4.5 pricing:

- **Input**: $3.00 per million tokens
- **Output**: $15.00 per million tokens

Example session cost:

```
Input:  12,345 tokens × $3.00/MTok  = $0.0370
Output:  6,789 tokens × $15.00/MTok = $0.1018
Total:  $0.1388
```

**Note**: Pricing may change. Edit `logging_hook.mjs` to update rates.

### Token Warnings

If a single message exceeds your threshold (default: 50,000 tokens), you'll get a warning:

```json
{
  "event": "token_warning",
  "message": "Message used 55000 tokens (threshold: 50000)"
}
```

This helps catch:

- Accidentally reading huge files
- Overly broad searches
- Context bloat

---

## Optimizing Performance

### Reduce Token Usage

1. **Use targeted tool calls:**

   ```
   ❌ BAD:  "Read the entire codebase"
   ✅ GOOD: "Grep for 'function authenticate' in src/**/*.js"
   ```

2. **Read files efficiently:**

   ```
   ❌ BAD:  Read entire 10,000-line file
   ✅ GOOD: Read with offset=100, limit=50 for relevant section
   ```

3. **Break up large tasks:**

   ```
   ❌ BAD:  "Refactor all files and update tests"
   ✅ GOOD: "Refactor auth.js, then I'll ask about tests"
   ```

4. **Be specific:**
   ```
   ❌ BAD:  "Tell me about this code"
   ✅ GOOD: "Explain the error handling in parseRequest() at line 45"
   ```

### Reduce Tool Call Duration

Analyze slow tools:

```bash
node claude_mods/analyze_logs.mjs --tools
```

Look for:

- Tools with high max duration
- Tools called frequently
- Tools with high error rates

Common slow operations:

- `Bash` with long-running commands
- `Read` on very large files
- `Grep` with broad patterns across many files
- Network operations

Solutions:

- Cache results of slow operations
- Use more specific search patterns
- Limit file sizes for Read
- Run long commands separately (not through Claude)

### Monitor Session Costs

```bash
# Quick cost check
node claude_mods/analyze_logs.mjs | grep "Total Cost"

# Track costs over time
for log in .ai_logs/session_*.jsonl; do
  echo "$(basename $log):"
  node claude_mods/analyze_logs.mjs "$log" 2>/dev/null | grep "Total Cost"
done
```

---

## Privacy & Security

### What's Redacted Automatically

The logging hook redacts:

- **API keys**: `sk_...`, `pk_...`, `AKIA...`
- **GitHub tokens**: `ghp_...`, `gho_...`
- **SSH keys**: `-----BEGIN PRIVATE KEY-----`
- **JWT tokens**: `eyJ...`
- **UUID tokens**: Patterns that look like tokens
- **Environment variables**: `API_KEY=...`, `SECRET=...`, `PASSWORD=...`

### Privacy Settings

Edit `~/.claude/logging_config.json`:

```json
{
  "privacy": {
    "enabled": true, // Master switch
    "redactSecrets": true, // Redact API keys, tokens, etc.
    "redactPaths": true, // Replace /full/path with filename only
    "redactEnvVars": true, // Redact sensitive env vars
    "allowList": [] // Patterns that should NOT be redacted
  }
}
```

### Override Redaction (Use Carefully!)

If you have public variables that match redaction patterns:

```json
{
  "privacy": {
    "allowList": ["MY_PUBLIC_API_KEY", "TEST_TOKEN"]
  }
}
```

These patterns will NOT be redacted.

### Best Practices

1. **Keep logs local** - Never commit `.ai_logs/` to git (already .gitignored)
2. **Review logs before sharing** - Even with redaction, double-check
3. **Delete sensitive sessions** - `rm .ai_logs/session_YYYY-MM-DD_HH-MM-SS.jsonl`
4. **Use minimal verbosity** - Reduces data captured
5. **Disable hooks for sensitive work** - Edit `~/.claude/hooks.json`, set `"enabled": false`

---

## Advanced Usage

### Custom Analysis Scripts

Logs are in JSON Lines format - easy to process with any tool:

**Using jq:**

```bash
# Extract all token usage events
cat .ai_logs/session_*.jsonl | jq 'select(.event == "onTokenUsage")'

# Sum total tokens across all messages
cat .ai_logs/session_*.jsonl | \
  jq 'select(.event == "onTokenUsage") | .data.tokens.total' | \
  awk '{sum+=$1} END {print sum}'

# Find slowest tool calls
cat .ai_logs/session_*.jsonl | \
  jq 'select(.event == "afterToolUse") | {tool: .toolName, duration: .data.durationMs}' | \
  jq -s 'sort_by(.duration) | reverse | .[:10]'
```

**Using Python:**

```python
import json

# Load session
with open('.ai_logs/session_2025-11-08_14-30-00.jsonl') as f:
    events = [json.loads(line) for line in f]

# Calculate total cost
token_events = [e for e in events if e['event'] == 'onTokenUsage']
total_tokens = sum(e['data']['tokens']['total'] for e in token_events)
print(f"Total tokens: {total_tokens}")
```

### Verbosity Levels

Edit `~/.claude/logging_config.json`:

**Minimal** - Only errors and session markers

```json
{ "verbosity": "minimal" }
```

- Smallest log files (~100KB/hour)
- Use when you only want cost tracking

**Normal** - Key events (recommended)

```json
{ "verbosity": "normal" }
```

- Moderate log files (~1-2MB/hour)
- Captures messages, tools, tokens, performance

**Verbose** - Everything including thinking and streaming

```json
{ "verbosity": "verbose" }
```

- Large log files (~5-10MB/hour)
- Only use for debugging specific issues

### Custom Thresholds

**Token warning threshold:**

```json
{
  "tokens": {
    "warnThreshold": 100000 // Warn at 100K instead of 50K
  }
}
```

**Performance warning threshold:**

```json
{
  "performance": {
    "slowToolThreshold": 10000 // Warn if tool >10s instead of >5s
  }
}
```

### Log Rotation

By default, logs rotate at 10MB and keep last 10 session files.

Customize:

```json
{
  "logFile": {
    "rotateSize": 5242880, // 5MB instead of 10MB
    "keepLast": 20 // Keep last 20 instead of 10
  }
}
```

### Disable Specific Hooks

Edit `~/.claude/hooks.json` to disable hooks you don't need:

```json
{
  "hooks": {
    "beforeMessage": { "enabled": true },
    "afterMessage": { "enabled": true },
    "beforeToolUse": { "enabled": false }, // Disabled
    "afterToolUse": { "enabled": false }, // Disabled
    "onTokenUsage": { "enabled": true }
  }
}
```

---

## Troubleshooting

### Logs are huge

**Symptoms:** `.ai_logs/` directory is many gigabytes

**Solutions:**

1. **Check verbosity:**

   ```bash
   cat ~/.claude/logging_config.json | jq '.verbosity'
   ```

   Should be `"normal"` or `"minimal"`, not `"verbose"`

2. **Disable expensive hooks:**

   ```bash
   cat ~/.claude/hooks.json | jq '.hooks.onThinking.enabled'
   ```

   Should be `false`

3. **Clean up old logs:**
   ```bash
   find .ai_logs -name "session_*.jsonl" -mtime +7 -delete
   ```

### Missing token data

**Symptoms:** `analyze_logs.mjs` shows 0 tokens

**Solutions:**

1. **Verify `onTokenUsage` hook enabled:**

   ```bash
   cat ~/.claude/hooks.json | jq '.hooks.onTokenUsage.enabled'
   ```

   Should be `true`

2. **Verify `afterMessage` hook enabled:**

   ```bash
   cat ~/.claude/hooks.json | jq '.hooks.afterMessage.enabled'
   ```

   Should be `true`

3. **Check log file has token events:**
   ```bash
   cat .ai_logs/session_*.jsonl | jq 'select(.event == "onTokenUsage")' | head -1
   ```
   Should print a JSON object with token data

### Inaccurate cost estimates

**Symptoms:** Estimated costs seem wrong

**Solutions:**

1. **Verify pricing in `logging_hook.mjs`:**

   ```bash
   grep "COST_PER_MTOK" claude_mods/logging_hook.mjs
   ```

   Should show current Claude Sonnet 4.5 pricing

2. **Update pricing:**
   Edit `claude_mods/logging_hook.mjs`, search for:
   ```javascript
   const INPUT_COST_PER_MTOK = 3.0;
   const OUTPUT_COST_PER_MTOK = 15.0;
   ```
   Update to current rates, then reinstall hook

### Privacy concerns

**Symptoms:** Logs contain sensitive data

**Solutions:**

1. **Verify privacy enabled:**

   ```bash
   cat ~/.claude/logging_config.json | jq '.privacy.enabled'
   ```

   Should be `true`

2. **Check for leaks:**

   ```bash
   grep -i "password\|secret\|key" .ai_logs/session_*.jsonl
   ```

   Should show `[REDACTED]` instead of actual values

3. **Delete compromised logs:**

   ```bash
   rm .ai_logs/session_YYYY-MM-DD_HH-MM-SS.jsonl
   ```

4. **Increase redaction:**
   Edit `~/.claude/logging_config.json`, ensure all privacy settings `true`

---

## Summary

### Key Takeaways

1. **Zero overhead** - Logging doesn't add tokens or slow down Claude
2. **Comprehensive** - Tracks messages, tools, tokens, performance
3. **Private** - Automatic redaction, logs never committed to git
4. **Analyzable** - Use `analyze_logs.mjs` or custom scripts
5. **Configurable** - Control verbosity, privacy, tracking, rotation

### Quick Commands

```bash
# Analyze latest session
node claude_mods/analyze_logs.mjs

# Full token analysis
node claude_mods/analyze_logs.mjs --tokens

# Tool performance
node claude_mods/analyze_logs.mjs --tools

# Everything
node claude_mods/analyze_logs.mjs --all

# Clean up old logs
find .ai_logs -name "session_*.jsonl" -mtime +7 -delete

# Check disk usage
du -sh .ai_logs
```

### Configuration Files

- `~/.claude/hooks.json` - Which hooks to run
- `~/.claude/logging_config.json` - How logging behaves
- `.ai_logs/.gitignore` - Privacy protection

### Documentation

- `LOGGING_INSTALLATION.md` - How to install
- `LOGGING_GUIDE.md` - This file (how to use)
- `.ai_logs/README.md` - Overview of log directory

---

**Last Updated:** 2025-11-08
**Version:** 1.0
**Maintainer:** Jackson-Devices
