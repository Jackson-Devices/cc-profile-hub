#!/usr/bin/env node

/**
 * format_diff.mjs - Formatter Diff Presentation Module
 *
 * Provides interactive diff presentation for code formatting changes.
 * Features:
 * - Color-coded terminal output (ANSI codes)
 * - File-by-file review mode
 * - Merge/replace/cancel logic
 * - Summary statistics
 *
 * Usage:
 *   import { presentDiff, reviewChanges } from './format_diff.mjs';
 *   const result = await reviewChanges(changedFiles);
 */

import { exec } from 'child_process';
import { promisify } from 'util';
import { createInterface } from 'readline';

const execAsync = promisify(exec);

// ANSI color codes
const colors = {
  reset: '\x1b[0m',
  bold: '\x1b[1m',
  dim: '\x1b[2m',
  red: '\x1b[31m',
  green: '\x1b[32m',
  yellow: '\x1b[33m',
  blue: '\x1b[34m',
  magenta: '\x1b[35m',
  cyan: '\x1b[36m',
  white: '\x1b[37m',
  bgRed: '\x1b[41m',
  bgGreen: '\x1b[42m',
};

/**
 * Format a diff line with color coding
 * @param {string} line - Diff line
 * @returns {string} Colored line
 */
function colorDiffLine(line) {
  if (line.startsWith('+')) {
    return `${colors.green}${line}${colors.reset}`;
  } else if (line.startsWith('-')) {
    return `${colors.red}${line}${colors.reset}`;
  } else if (line.startsWith('@@')) {
    return `${colors.cyan}${line}${colors.reset}`;
  } else if (line.startsWith('diff --git')) {
    return `${colors.bold}${colors.white}${line}${colors.reset}`;
  }
  return `${colors.dim}${line}${colors.reset}`;
}

/**
 * Get diff for a single file
 * @param {string} filePath - Path to file
 * @returns {Promise<string>} Diff output
 */
async function getFileDiff(filePath) {
  try {
    // Get diff between working tree and staged version
    const { stdout } = await execAsync(`git diff HEAD -- "${filePath}"`);
    return stdout;
  } catch {
    // If file is not in git yet, show full content as added
    try {
      const { stdout } = await execAsync(`git diff --no-index /dev/null "${filePath}"`);
      return stdout;
    } catch {
      return '';
    }
  }
}

/**
 * Get diff statistics for a file
 * @param {string} diff - Diff output
 * @returns {{additions: number, deletions: number}}
 */
function getDiffStats(diff) {
  const lines = diff.split('\n');
  let additions = 0;
  let deletions = 0;

  for (const line of lines) {
    if (line.startsWith('+') && !line.startsWith('+++')) {
      additions++;
    } else if (line.startsWith('-') && !line.startsWith('---')) {
      deletions++;
    }
  }

  return { additions, deletions };
}

/**
 * Present a colored diff for a file
 * @param {string} filePath - File path
 * @param {string} diff - Diff output
 */
function presentFileDiff(filePath, diff) {
  console.log(
    `\n${colors.bold}${colors.blue}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━${colors.reset}`
  );
  console.log(`${colors.bold}File: ${colors.cyan}${filePath}${colors.reset}`);

  const stats = getDiffStats(diff);
  const statsStr = `${colors.green}+${stats.additions}${colors.reset} ${colors.red}-${stats.deletions}${colors.reset}`;
  console.log(`${colors.bold}Changes: ${statsStr}${colors.reset}`);
  console.log(
    `${colors.bold}${colors.blue}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━${colors.reset}\n`
  );

  // Color-code and print each diff line
  const lines = diff.split('\n');
  for (const line of lines) {
    console.log(colorDiffLine(line));
  }
}

/**
 * Create a readline interface for user input
 * @returns {readline.Interface}
 */
function createReadline() {
  return createInterface({
    input: process.stdin,
    output: process.stdout,
  });
}

/**
 * Ask user a question and get response
 * @param {readline.Interface} rl - Readline interface
 * @param {string} question - Question to ask
 * @returns {Promise<string>} User response
 */
function askQuestion(rl, question) {
  return new Promise((resolve) => {
    rl.question(question, (answer) => {
      resolve(answer.trim().toLowerCase());
    });
  });
}

/**
 * Present all diffs and get summary
 * @param {string[]} files - Array of file paths
 * @returns {Promise<{files: number, additions: number, deletions: number}>}
 */
export async function presentDiff(files) {
  let totalAdditions = 0;
  let totalDeletions = 0;

  for (const file of files) {
    const diff = await getFileDiff(file);
    if (diff) {
      presentFileDiff(file, diff);
      const stats = getDiffStats(diff);
      totalAdditions += stats.additions;
      totalDeletions += stats.deletions;
    }
  }

  return {
    files: files.length,
    additions: totalAdditions,
    deletions: totalDeletions,
  };
}

/**
 * Review changes interactively with merge/replace/cancel options
 * @param {string[]} files - Array of file paths that have formatting changes
 * @returns {Promise<{action: 'replace'|'merge'|'cancel', acceptedFiles: string[]}>}
 */
export async function reviewChanges(files) {
  if (files.length === 0) {
    console.log(`${colors.green}✓ No formatting changes needed${colors.reset}`);
    return { action: 'replace', acceptedFiles: [] };
  }

  console.log(
    `\n${colors.bold}${colors.yellow}╔══════════════════════════════════════════════════════════════════╗${colors.reset}`
  );
  console.log(
    `${colors.bold}${colors.yellow}║        FORMATTING CHANGES DETECTED - REVIEW REQUIRED             ║${colors.reset}`
  );
  console.log(
    `${colors.bold}${colors.yellow}╚══════════════════════════════════════════════════════════════════╝${colors.reset}\n`
  );

  // Show summary first
  const stats = await presentDiff(files);

  console.log(`\n${colors.bold}${colors.white}Summary:${colors.reset}`);
  console.log(`  Files changed: ${colors.cyan}${stats.files}${colors.reset}`);
  console.log(`  Lines added:   ${colors.green}+${stats.additions}${colors.reset}`);
  console.log(`  Lines removed: ${colors.red}-${stats.deletions}${colors.reset}`);

  console.log(`\n${colors.bold}${colors.white}Options:${colors.reset}`);
  console.log(
    `  ${colors.green}[r] replace${colors.reset} - Accept all formatting changes, update staging area`
  );
  console.log(
    `  ${colors.yellow}[m] merge${colors.reset}   - Review changes file-by-file (interactive approval)`
  );
  console.log(
    `  ${colors.red}[c] cancel${colors.reset}  - Abort commit, keep original formatting\n`
  );

  const rl = createReadline();

  let action = await askQuestion(
    rl,
    `${colors.bold}How do you want to proceed? [r/m/c]: ${colors.reset}`
  );

  // Validate input
  while (!['r', 'replace', 'm', 'merge', 'c', 'cancel'].includes(action)) {
    action = await askQuestion(
      rl,
      `${colors.red}Invalid choice.${colors.reset} Please enter ${colors.green}r${colors.reset}, ${colors.yellow}m${colors.reset}, or ${colors.red}c${colors.reset}: `
    );
  }

  // Normalize action
  if (action === 'r') action = 'replace';
  if (action === 'm') action = 'merge';
  if (action === 'c') action = 'cancel';

  let acceptedFiles = [];

  if (action === 'replace') {
    console.log(`\n${colors.green}✓ Accepting all formatting changes...${colors.reset}`);
    acceptedFiles = [...files];
  } else if (action === 'merge') {
    console.log(`\n${colors.yellow}Starting file-by-file review...${colors.reset}\n`);

    for (const file of files) {
      const diff = await getFileDiff(file);
      if (!diff) continue;

      presentFileDiff(file, diff);

      let fileAction = await askQuestion(
        rl,
        `\n${colors.bold}Accept changes to ${colors.cyan}${file}${colors.reset}? ${colors.green}[y]es${colors.reset}/${colors.red}[n]o${colors.reset}/${colors.yellow}[q]uit${colors.reset}: `
      );

      while (!['y', 'yes', 'n', 'no', 'q', 'quit'].includes(fileAction)) {
        fileAction = await askQuestion(
          rl,
          `${colors.red}Invalid choice.${colors.reset} Please enter ${colors.green}y${colors.reset}, ${colors.red}n${colors.reset}, or ${colors.yellow}q${colors.reset}: `
        );
      }

      if (fileAction === 'q' || fileAction === 'quit') {
        console.log(`\n${colors.red}✗ Review cancelled${colors.reset}`);
        rl.close();
        return { action: 'cancel', acceptedFiles: [] };
      } else if (fileAction === 'y' || fileAction === 'yes') {
        acceptedFiles.push(file);
        console.log(`${colors.green}✓ Accepted changes to ${file}${colors.reset}`);
      } else {
        console.log(`${colors.yellow}○ Skipped changes to ${file}${colors.reset}`);
      }
    }

    console.log(`\n${colors.bold}Review complete:${colors.reset}`);
    console.log(`  Accepted: ${colors.green}${acceptedFiles.length}${colors.reset} files`);
    console.log(
      `  Skipped:  ${colors.yellow}${files.length - acceptedFiles.length}${colors.reset} files`
    );
  } else {
    console.log(`\n${colors.red}✗ Commit cancelled${colors.reset}`);
  }

  rl.close();
  return { action, acceptedFiles };
}

/**
 * Apply formatting to accepted files
 * @param {string[]} files - Files to format
 * @returns {Promise<void>}
 */
export async function applyFormatting(files) {
  if (files.length === 0) {
    return;
  }

  console.log(`\n${colors.cyan}Applying formatting to ${files.length} file(s)...${colors.reset}`);

  try {
    const filesArg = files.map((f) => `"${f}"`).join(' ');
    await execAsync(`npx prettier --write ${filesArg}`);
    console.log(`${colors.green}✓ Formatting applied successfully${colors.reset}`);

    // Stage the formatted files
    await execAsync(`git add ${filesArg}`);
    console.log(`${colors.green}✓ Formatted files staged${colors.reset}`);
  } catch (error) {
    console.error(`${colors.red}✗ Error applying formatting: ${error.message}${colors.reset}`);
    throw error;
  }
}

// CLI mode - if run directly
if (import.meta.url === `file://${process.argv[1]}`) {
  const files = process.argv.slice(2);

  if (files.length === 0) {
    console.log('Usage: format_diff.mjs <file1> <file2> ...');
    process.exit(1);
  }

  const result = await reviewChanges(files);

  if (result.action === 'replace' && result.acceptedFiles.length > 0) {
    await applyFormatting(result.acceptedFiles);
  } else if (result.action === 'merge' && result.acceptedFiles.length > 0) {
    await applyFormatting(result.acceptedFiles);
  } else if (result.action === 'cancel') {
    console.log(`\n${colors.yellow}No changes were applied${colors.reset}`);
    process.exit(1);
  }
}
