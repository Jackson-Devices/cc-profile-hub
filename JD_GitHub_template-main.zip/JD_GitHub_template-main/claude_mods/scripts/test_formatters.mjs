#!/usr/bin/env node

/**
 * Formatter Testing Suite
 *
 * Tests that formatters (Prettier) correctly format broken sample files
 * and match expected outputs.
 *
 * Usage: node claude_mods/scripts/test_formatters.mjs
 */

import { readFile } from 'fs/promises';
import { fileURLToPath } from 'url';
import { dirname, join } from 'path';
import prettier from 'prettier';

const __filename = fileURLToPath(import.meta.url);
const __dirname = dirname(__filename);
const projectRoot = join(__dirname, '../..');

// ANSI color codes
const colors = {
  reset: '\x1b[0m',
  bright: '\x1b[1m',
  green: '\x1b[32m',
  red: '\x1b[31m',
  yellow: '\x1b[33m',
  cyan: '\x1b[36m',
  gray: '\x1b[90m',
};

/**
 * Test files configuration
 */
const testFiles = [
  { name: 'broken.yaml', parser: 'yaml' },
  { name: 'broken.md', parser: 'markdown' },
  { name: 'broken.json', parser: 'json' },
];

/**
 * Read file content
 */
async function readFileContent(filePath) {
  try {
    return await readFile(filePath, 'utf-8');
  } catch (error) {
    throw new Error(`Failed to read ${filePath}: ${error.message}`);
  }
}

/**
 * Format content using Prettier
 */
async function formatContent(content, filePath) {
  try {
    // Resolve config using the actual file path for proper config resolution
    const options = await prettier.resolveConfig(filePath);
    return await prettier.format(content, {
      ...options,
      filepath: filePath,
    });
  } catch (error) {
    throw new Error(`Failed to format ${filePath}: ${error.message}`);
  }
}

/**
 * Compare two strings and return diff statistics
 */
function compareStrings(actual, expected) {
  if (actual === expected) {
    return { match: true, differences: 0 };
  }

  const actualLines = actual.split('\n');
  const expectedLines = expected.split('\n');
  let differences = 0;

  const maxLines = Math.max(actualLines.length, expectedLines.length);
  for (let i = 0; i < maxLines; i++) {
    if (actualLines[i] !== expectedLines[i]) {
      differences++;
    }
  }

  return { match: false, differences };
}

/**
 * Run a single test
 */
async function runTest(testFile) {
  const brokenPath = join(projectRoot, 'tests/formatters/samples/broken', testFile.name);
  const expectedPath = join(projectRoot, 'tests/formatters/samples/expected', testFile.name);

  try {
    // Read broken file
    const brokenContent = await readFileContent(brokenPath);

    // Read expected file
    const expectedContent = await readFileContent(expectedPath);

    // Format broken file
    const formattedContent = await formatContent(brokenContent, brokenPath);

    // Compare formatted with expected
    const comparison = compareStrings(formattedContent, expectedContent);

    return {
      success: comparison.match,
      name: testFile.name,
      differences: comparison.differences,
      formattedLength: formattedContent.length,
      expectedLength: expectedContent.length,
    };
  } catch (error) {
    return {
      success: false,
      name: testFile.name,
      error: error.message,
    };
  }
}

/**
 * Print test result
 */
function printTestResult(result) {
  const status = result.success
    ? `${colors.green}✓ PASS${colors.reset}`
    : `${colors.red}✗ FAIL${colors.reset}`;

  console.log(`  ${status} ${colors.cyan}${result.name}${colors.reset}`);

  if (!result.success) {
    if (result.error) {
      console.log(`    ${colors.red}Error:${colors.reset} ${result.error}`);
    } else if (result.differences) {
      console.log(
        `    ${colors.yellow}Differences:${colors.reset} ${result.differences} lines differ`
      );
      console.log(
        `    ${colors.gray}Formatted: ${result.formattedLength} bytes, Expected: ${result.expectedLength} bytes${colors.reset}`
      );
    }
  }
}

/**
 * Print summary statistics
 */
function printSummary(results) {
  const total = results.length;
  const passed = results.filter((r) => r.success).length;
  const failed = total - passed;

  console.log('\n' + '─'.repeat(50));
  console.log(`${colors.bright}Summary:${colors.reset}`);
  console.log(`  Total:  ${total} tests`);
  console.log(`  ${colors.green}Passed: ${passed}${colors.reset}`);
  console.log(`  ${colors.red}Failed: ${failed}${colors.reset}`);

  const successRate = total > 0 ? ((passed / total) * 100).toFixed(1) : 0;
  console.log(`  ${colors.cyan}Success Rate: ${successRate}%${colors.reset}`);
  console.log('─'.repeat(50) + '\n');
}

/**
 * Main test runner
 */
async function main() {
  console.log(`${colors.bright}${colors.cyan}Formatter Testing Suite${colors.reset}\n`);
  console.log(`Testing ${testFiles.length} sample files...\n`);

  const results = [];

  for (const testFile of testFiles) {
    const result = await runTest(testFile);
    results.push(result);
    printTestResult(result);
  }

  printSummary(results);

  // Exit with appropriate code
  const allPassed = results.every((r) => r.success);
  process.exit(allPassed ? 0 : 1);
}

// Run tests
main().catch((error) => {
  console.error(`${colors.red}Fatal error:${colors.reset}`, error);
  process.exit(1);
});
