# Claude Code Comprehensive Logging - Installation Guide

This guide walks you through installing and configuring the comprehensive logging system for Claude Code.

## Table of Contents

1. [Prerequisites](#prerequisites)
2. [Quick Start](#quick-start)
3. [Detailed Installation](#detailed-installation)
4. [Configuration](#configuration)
5. [Testing](#testing)
6. [Troubleshooting](#troubleshooting)

---

## Prerequisites

Before installing, ensure you have:

- ✅ **Claude Code CLI** installed and working
- ✅ **Node.js v14.0.0+** (`node --version`)
- ✅ **Git** (`git --version`)
- ✅ **Repository with `.ai_logs/` directory** (created automatically if missing)

### Platform Support

- ✅ **Windows** (native, PowerShell)
- ✅ **Linux** (all distros)
- ✅ **macOS** (all versions)
- ✅ **WSL** (Windows Subsystem for Linux)

---

## Quick Start

**For the impatient:**

```bash
# 1. Copy logging hook to Claude Code hooks directory
mkdir -p ~/.claude/hooks
cp claude_mods/logging_hook.mjs ~/.claude/hooks/
chmod +x ~/.claude/hooks/logging_hook.mjs

# 2. Copy analysis tool (optional, for convenience)
cp claude_mods/analyze_logs.mjs ~/.claude/hooks/
chmod +x ~/.claude/hooks/analyze_logs.mjs

# 3. Configure hooks (logging only)
cp claude_mods/hooks.json.logging.example ~/.claude/hooks.json

# OR if you also use the commit squashing hook:
cp claude_mods/hooks.json.combined.example ~/.claude/hooks.json

# 4. Test
node ~/.claude/hooks/logging_hook.mjs beforeMessage '{"test": true}'
# Should exit successfully (creates .ai_logs/session_*.jsonl)

# 5. Use Claude Code normally - logs will be created automatically
```

**Done!** Logs will appear in `.ai_logs/session_*.jsonl` when you use Claude Code.

---

## Detailed Installation

### Step 1: Create Claude Code Hooks Directory

Claude Code looks for hooks in `~/.claude/hooks/`.

**Linux/macOS/WSL:**

```bash
mkdir -p ~/.claude/hooks
```

**Windows (PowerShell):**

```powershell
New-Item -Path "$env:USERPROFILE\.claude\hooks" -ItemType Directory -Force
```

### Step 2: Copy Logging Hook Script

**Linux/macOS/WSL:**

```bash
# Copy from repository to Claude Code hooks directory
cp claude_mods/logging_hook.mjs ~/.claude/hooks/

# Make executable
chmod +x ~/.claude/hooks/logging_hook.mjs

# Verify
ls -lh ~/.claude/hooks/logging_hook.mjs
```

**Windows (PowerShell):**

```powershell
# Copy from repository
Copy-Item claude_mods\logging_hook.mjs "$env:USERPROFILE\.claude\hooks\"

# Verify
Get-Item "$env:USERPROFILE\.claude\hooks\logging_hook.mjs"
```

### Step 3: Copy Analysis Tool (Optional)

The analysis tool can be used from anywhere, but copying it to `~/.claude/hooks/` makes it convenient.

**Linux/macOS/WSL:**

```bash
cp claude_mods/analyze_logs.mjs ~/.claude/hooks/
chmod +x ~/.claude/hooks/analyze_logs.mjs
```

**Windows (PowerShell):**

```powershell
Copy-Item claude_mods\analyze_logs.mjs "$env:USERPROFILE\.claude\hooks\"
```

### Step 4: Configure Hooks

You need to create or update `~/.claude/hooks.json` to tell Claude Code when to invoke the logging hook.

**Choose ONE of these options:**

#### Option A: Logging Only (No Other Hooks)

```bash
# Linux/macOS/WSL
cp claude_mods/hooks.json.logging.example ~/.claude/hooks.json
```

```powershell
# Windows (PowerShell)
Copy-Item claude_mods\hooks.json.logging.example "$env:USERPROFILE\.claude\hooks.json"
```

#### Option B: Combined (Logging + Commit Squashing)

If you already have the pre-push commit squashing hook installed:

```bash
# Linux/macOS/WSL
cp claude_mods/hooks.json.combined.example ~/.claude/hooks.json
```

```powershell
# Windows (PowerShell)
Copy-Item claude_mods\hooks.json.combined.example "$env:USERPROFILE\.claude\hooks.json"
```

#### Option C: Manual Configuration

Edit `~/.claude/hooks.json` and add the logging hooks manually. See the example files for reference.

**Important**: Verify JSON syntax after editing:

```bash
cat ~/.claude/hooks.json | jq .
# Should print formatted JSON without errors
```

### Step 5: Create Default Configuration (Optional)

The logging hook will create `~/.claude/logging_config.json` automatically with default settings on first run.

To customize before first use:

```bash
# Linux/macOS/WSL
cp claude_mods/logging_config.json.example ~/.claude/logging_config.json
```

```powershell
# Windows (PowerShell)
Copy-Item claude_mods\logging_config.json.example "$env:USERPROFILE\.claude\logging_config.json"
```

Then edit `~/.claude/logging_config.json` to adjust:

- Verbosity level
- Privacy settings
- Token tracking options
- Performance monitoring

---

## Configuration

### Hooks Configuration (`~/.claude/hooks.json`)

The hooks.json file tells Claude Code **when** to invoke the logging script.

**Key settings:**

```json
{
  "hooks": {
    "beforeMessage": {
      "enabled": true, // ← Turn on/off
      "blocking": false, // ← Don't block Claude if logging fails
      "script": "~/.claude/hooks/logging_hook.mjs",
      "args": ["beforeMessage"] // ← Which event to log
    }
  }
}
```

**Available hooks:**

- `beforeMessage` - Log prompts before sending to Claude
- `afterMessage` - Log Claude's response including tokens
- `beforeToolUse` - Log before tool execution (Read, Write, etc.)
- `afterToolUse` - Log after tool execution with results and timing
- `onTokenUsage` - Dedicated token tracking event
- `onThinking` - Log extended thinking (verbose mode, high overhead)
- `onStreamChunk` - Log real-time streaming (verbose mode, very high overhead)

**Recommended setup:**

- Enable: `beforeMessage`, `afterMessage`, `beforeToolUse`, `afterToolUse`, `onTokenUsage`
- Disable: `onThinking`, `onStreamChunk` (unless debugging)

### Logging Configuration (`~/.claude/logging_config.json`)

This file controls **how** logging behaves.

**Key settings:**

```json
{
  "verbosity": "normal", // minimal, normal, verbose
  "privacy": {
    "enabled": true, // Enable privacy features
    "redactSecrets": true,
    "redactPaths": true,
    "redactEnvVars": true
  },
  "tokens": {
    "trackPerTool": true,
    "trackPerMessage": true,
    "trackCumulative": true,
    "estimateCost": true,
    "warnThreshold": 50000 // Warn if message uses >50K tokens
  }
}
```

**Verbosity levels:**

- `minimal` - Only errors and session markers
- `normal` - Key events (messages, tools, tokens) ← **Recommended**
- `verbose` - Everything including thinking and streaming (very large logs)

---

## Testing

### Test 1: Hook Script Works

Run the logging hook directly:

```bash
node ~/.claude/hooks/logging_hook.mjs beforeMessage '{"test": true}'
```

**Expected:**

- Exit code 0 (success)
- New file appears in `.ai_logs/session_*.jsonl`
- File contains a JSON line with `"event": "beforeMessage"`

### Test 2: Hooks.json Valid

Verify your hooks configuration:

```bash
cat ~/.claude/hooks.json | jq .
```

**Expected:**

- JSON prints without errors
- All hook paths are correct

### Test 3: Claude Code Integration

Start Claude Code and ask it to perform a simple task:

```
User: Read the README.md file
```

**Expected:**

- Claude reads the file normally
- New `.ai_logs/session_*.jsonl` file created (or updated)
- Log contains `beforeToolUse` and `afterToolUse` entries for Read tool

**Check logs:**

```bash
tail -f .ai_logs/session_*.jsonl | jq .
# Should show JSON entries as Claude Code runs
```

### Test 4: Analysis Tool

Analyze the session:

```bash
node ~/.claude/hooks/analyze_logs.mjs --all
```

**Expected:**

- Prints session summary
- Shows token usage
- Shows tool usage
- Shows performance metrics
- No errors

---

## Troubleshooting

### Problem: No logs appear

**Symptoms:**

- `.ai_logs/` directory exists but no `session_*.jsonl` files
- Claude Code works normally

**Solutions:**

1. **Verify hooks.json exists:**

   ```bash
   ls -lh ~/.claude/hooks.json
   ```

   If missing, copy from example files.

2. **Verify hooks.json syntax:**

   ```bash
   cat ~/.claude/hooks.json | jq .
   ```

   Fix any JSON syntax errors.

3. **Verify script is executable:**

   ```bash
   ls -lh ~/.claude/hooks/logging_hook.mjs
   # Should show 'x' permission on Linux/macOS
   ```

   Fix: `chmod +x ~/.claude/hooks/logging_hook.mjs`

4. **Test script manually:**

   ```bash
   node ~/.claude/hooks/logging_hook.mjs beforeMessage '{"test": true}'
   echo $?  # Should print 0
   ```

5. **Check Claude Code logs:**
   Look for errors related to hooks in Claude Code output.

### Problem: Logs created but empty or malformed

**Symptoms:**

- `.ai_logs/session_*.jsonl` exists but contains no data or invalid JSON

**Solutions:**

1. **Check file permissions:**

   ```bash
   ls -lh .ai_logs/
   # Ensure you can write to .ai_logs/
   ```

2. **Check disk space:**

   ```bash
   df -h .
   ```

3. **Run hook manually with verbose output:**

   ```bash
   node ~/.claude/hooks/logging_hook.mjs beforeMessage '{"test": "data"}' 2>&1
   ```

4. **Check for write errors:**
   ```bash
   tail -100 .ai_logs/session_*.jsonl
   # Look for partial entries or errors
   ```

### Problem: "Command not found" error

**Symptoms:**

- Claude Code reports "command not found" when trying to run hook
- Hook works when run manually

**Solutions:**

1. **Use absolute paths in hooks.json:**

   ```json
   {
     "hooks": {
       "beforeMessage": {
         "script": "/home/user/.claude/hooks/logging_hook.mjs"
       }
     }
   }
   ```

2. **Verify Node.js in PATH:**

   ```bash
   which node
   # Should print path to node binary
   ```

3. **Add shebang to script:**
   The script already has `#!/usr/bin/env node` at the top. Verify it's present.

### Problem: Logs too large / disk space

**Symptoms:**

- `.ai_logs/` directory growing very large
- Disk space running low

**Solutions:**

1. **Reduce verbosity:**
   Edit `~/.claude/logging_config.json`:

   ```json
   {
     "verbosity": "minimal"
   }
   ```

2. **Disable expensive hooks:**
   Edit `~/.claude/hooks.json`, set `"enabled": false` for:
   - `onThinking`
   - `onStreamChunk`

3. **Clean up old logs:**

   ```bash
   # Delete logs older than 7 days
   find .ai_logs -name "session_*.jsonl" -mtime +7 -delete
   ```

4. **Reduce log retention:**
   Edit `~/.claude/logging_config.json`:
   ```json
   {
     "logFile": {
       "keepLast": 3 // Only keep last 3 session files
     }
   }
   ```

### Problem: Privacy concerns

**Symptoms:**

- Logs contain sensitive data despite redaction

**Solutions:**

1. **Verify privacy settings:**
   Edit `~/.claude/logging_config.json`:

   ```json
   {
     "privacy": {
       "enabled": true,
       "redactSecrets": true,
       "redactPaths": true,
       "redactEnvVars": true
     }
   }
   ```

2. **Review logs for leaks:**

   ```bash
   grep -i "password\|secret\|key" .ai_logs/session_*.jsonl
   ```

3. **Delete sensitive logs:**

   ```bash
   rm .ai_logs/session_*.jsonl
   ```

4. **Add to .gitignore (should already be done):**
   ```bash
   cat .ai_logs/.gitignore
   # Should show session_*.jsonl is ignored
   ```

### Problem: Analysis tool errors

**Symptoms:**

- `analyze_logs.mjs` crashes or shows errors

**Solutions:**

1. **Verify log file format:**

   ```bash
   head -1 .ai_logs/session_*.jsonl | jq .
   # Should parse as valid JSON
   ```

2. **Check for partial/corrupted entries:**

   ```bash
   cat .ai_logs/session_*.jsonl | while read line; do
     echo "$line" | jq . >/dev/null 2>&1 || echo "Invalid: $line"
   done
   ```

3. **Specify log file explicitly:**
   ```bash
   node analyze_logs.mjs .ai_logs/session_2025-11-08_14-30-00.jsonl
   ```

---

## Next Steps

After successful installation:

1. **Read LOGGING_GUIDE.md** - Learn how to analyze logs and optimize token usage
2. **Customize configuration** - Adjust verbosity, privacy, tracking to your needs
3. **Run analysis regularly** - Use `analyze_logs.mjs` to understand Claude Code usage patterns

---

## Getting Help

If you encounter issues not covered here:

1. **Check LOGGING_GUIDE.md** - Advanced usage and troubleshooting
2. **Test manually** - Run hook script directly to isolate issues
3. **Check file permissions** - Ensure scripts are executable, directories writable
4. **Review configuration** - Verify JSON syntax in hooks.json and logging_config.json
5. **Report bugs** - Create issue in repository with:
   - Platform (Windows/Linux/macOS)
   - Error message
   - Output of manual test: `node ~/.claude/hooks/logging_hook.mjs beforeMessage '{"test":true}'`
   - Contents of `~/.claude/hooks.json` (remove sensitive paths)

---

**Last Updated:** 2025-11-08
**Version:** 1.0
**Maintainer:** Jackson-Devices
