import js from '@eslint/js';
import prettier from 'eslint-config-prettier';
import nodePlugin from 'eslint-plugin-n';
import globals from 'globals';

export default [
  // Base recommended config
  js.configs.recommended,

  // Node.js plugin recommended rules
  {
    ...nodePlugin.configs['flat/recommended-module'],
    settings: {
      node: {
        version: '>=20.13.0',
      },
    },
  },

  // Custom configuration
  {
    files: ['**/*.js', '**/*.mjs'],

    languageOptions: {
      ecmaVersion: 2022,
      sourceType: 'module',
      globals: {
        ...globals.node,
        ...globals.es2021,
      },
    },

    rules: {
      // === Core Defect Detection ===

      // Unused code detection
      'no-unused-vars': [
        'error',
        {
          argsIgnorePattern: '^_',
          varsIgnorePattern: '^_',
          caughtErrors: 'all',
        },
      ],

      // Unreachable code
      'no-unreachable': 'error',
      'no-unreachable-loop': 'error',

      // Variable issues
      'no-undef': 'error',
      'no-redeclare': 'error',

      // === Async/Promise Safety (Critical for GitHub API) ===

      // Prevent race conditions in async
      'require-atomic-updates': 'error',

      // Promise best practices
      'no-async-promise-executor': 'error',
      'no-promise-executor-return': 'error',
      'no-await-in-loop': 'off', // Often intentional in scripts for sequential operations

      // === Error Handling ===

      // Ensure proper error handling
      'no-ex-assign': 'error',
      'no-unsafe-finally': 'error',

      // === Code Quality ===

      // Prevent confusing patterns
      'no-fallthrough': 'error',
      'no-constant-condition': ['error', { checkLoops: false }],
      'no-empty': ['error', { allowEmptyCatch: false }],

      // === Node.js Specific ===

      // Handle callbacks properly
      'n/handle-callback-err': ['error', '^(err|error)$'],

      // Validate Node.js APIs
      'n/no-deprecated-api': 'error',

      // Process exit is acceptable in CLI scripts
      'n/no-process-exit': 'off',

      // Allow shebangs in script files (this repo contains executable scripts)
      'n/hashbang': 'off',
    },
  },

  // Test files - allow experimental Node.js test runner features
  {
    files: ['tests/**/*.js', 'tests/**/*.mjs'],
    rules: {
      // Node test runner features are stable in Node 20.13+ despite ESLint plugin saying otherwise
      'n/no-unsupported-features/node-builtins': [
        'error',
        {
          ignores: [
            'test',
            'test.test',
            'test.describe',
            'test.afterEach',
            'test.beforeEach',
            'test.mock',
            'test.mock.method',
            'test.run',
          ],
        },
      ],
    },
  },

  // Ignore patterns
  {
    ignores: ['node_modules/**', 'dist/**', 'build/**', '.git/**', 'coverage/**'],
  },

  // Disable Prettier conflicts (MUST BE LAST)
  prettier,
];
