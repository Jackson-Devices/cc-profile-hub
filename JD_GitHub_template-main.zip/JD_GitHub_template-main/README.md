# Jackson-Devices GitHub Repository Template

**Purpose:** Sets up new repositories with consistent, brand-standard labels and settings for workflow alignment.

## What This Template Provides

### Label Taxonomy System

A comprehensive label system designed for Jackson-Devices workflow:

- **Difficulty levels** (5) - Classify task complexity
- **AI capability** (4) - Track what AI can handle
- **Workflow status** (7) - Track issue/PR lifecycle
- **Validation status** (3) - Track testing validation gates
- **Test type** (4) - Classify test behavior complexity
- **Role** (2) - Define hierarchy for suites and features
- **Work types** (8) - Categorize the nature of work
- **Special flags** (1) - Mark tasks requiring human intervention

See `LABEL_DESIGN_SPEC.md` for complete details on all 36 issue labels + 10 project labels (Linear only).

### Test Hierarchy & Naming Structure

**Issue Hierarchy:**

```mermaid
graph TD
    A[Issue #10: Feature XYZ<br/>type: feature] --> B[Issue #42: Build Test Suite<br/>role: test suite]
    B --> C[Issue #100: Test buffer processing<br/>type: test]
    B --> D[Issue #101: Test state machine<br/>type: test]
    B --> E[Issue #102: Test error handling<br/>type: test]

    style A fill:#3b82f6,color:#fff
    style B fill:#ec4899,color:#fff
    style C fill:#ec4899,color:#fff
    style D fill:#ec4899,color:#fff
    style E fill:#ec4899,color:#fff
```

**Text Representation:**

```
Issue #10: Feature XYZ (parent p)
  └─ Issue #42: Build Test Suite (child c1, role: test suite)
      ├─ Issue #100: Test buffer processing (test leaf, type: test)
      ├─ Issue #101: Test state machine (test leaf, type: test)
      └─ Issue #102: Test error handling (test leaf, type: test)
```

**IB/OOB Naming - Per Test Issue Namespace:**

Each test issue has its own namespace. `IB-01` in issue #100 is DIFFERENT from `IB-01` in issue #101.

```mermaid
graph LR
    A[Issue #100<br/>Test buffer processing] --> B[IB-01: Valid buffer<br/>IB-02: Edge boundary<br/>OOB-01: Overflow<br/>OOB-02: NULL]
    C[Issue #101<br/>Test state machine] --> D[IB-01: Valid transition<br/>OOB-01: Invalid state<br/>OOB-02: Uninitialized]

    style A fill:#3b82f6,color:#fff
    style C fill:#3b82f6,color:#fff
    style B fill:#22c55e,color:#000
    style D fill:#22c55e,color:#000
```

**In issue #100:**

```
- IB-01: Valid buffer with 512 samples
- IB-02: Edge case at boundary
- OOB-01: Buffer overflow (1025 samples)
- OOB-02: NULL pointer
```

**In issue #101:**

```
- IB-01: Valid state transition ← Different IB-01, no conflict!
- OOB-01: Invalid state code
- OOB-02: Uninitialized state
```

**Filesystem Structure (maps to issue number):**

```
tests/
  test_100_buffer_processing/
    IB_01_valid_buffer.c
    IB_02_edge_boundary.c
    OOB_01_overflow.c
    OOB_02_null_pointer.c
  test_101_state_machine/
    IB_01_valid_transition.c
    OOB_01_invalid_state.c
    OOB_02_uninitialized.c
```

**Key Rule:** The GitHub issue number IS the namespace. When writing test cases, use simple `IB-01`, `IB-02`, `OOB-01`, `OOB-02` - the issue you're editing provides the context.

### Automated Label Sync

A GitHub Actions workflow that:

- Creates/updates labels from configuration file
- Deletes non-standard labels automatically
- Includes dry-run preview mode
- Requires manual approval for safety
- Has security guardrails built-in

## Intelligent Workflow Orchestration System

An intelligent, self-healing orchestration system that coordinates all GitHub Actions workflows with automatic retry logic, multi-threshold error handling, and complete automation from commit to merge.

### Architecture Overview

The orchestration system implements a **5-tier threshold model** with intelligent retry logic:

1. **Tier 1 - Warning**: Log warning, continue execution
2. **Tier 2 - Retry**: Attempt auto-fix, retry operation
3. **Tier 3 - Internal Validation**: Run internal checks before external reporting
4. **Tier 4 - Multiple Retry Passes**: Execute up to 3 retry attempts with escalating strategies
5. **Tier 5 - Human Escalation**: Provide detailed failure report and escalate

```mermaid
graph TD
    Start([Commit Push]) --> PreCheck{Pre-Flight<br/>Checks}

    PreCheck -->|Pass| Orchestrator[Orchestrator<br/>Auto-Trigger]
    PreCheck -->|Fail - T1| Warn1[Tier 1: Warning<br/>Log & Continue]
    Warn1 --> Orchestrator

    Orchestrator --> SeqGate{Sequential<br/>Commits Gate}
    SeqGate -->|Single Commit| Phase1[Phase 1:<br/>Pre-Checks]
    SeqGate -->|Multiple Commits<br/>T2| AutoSquash[Tier 2: Auto-Squash<br/>Retry]
    AutoSquash -->|Success| Phase1
    AutoSquash -->|Fail - T5| Escalate1[Tier 5: Escalate<br/>Manual Squash Needed]

    Phase1 --> RaceDetect{Race Condition<br/>Detection}
    RaceDetect -->|Clear| Phase2[Phase 2:<br/>Linting]
    RaceDetect -->|Detected - T2| AcquireLock[Tier 2: Acquire Lock<br/>Wait & Retry]
    AcquireLock -->|Lock Acquired| Phase2
    AcquireLock -->|Timeout - T5| Escalate2[Tier 5: Escalate<br/>Lock Timeout]

    Phase2 --> ESLint{ESLint<br/>Check}
    ESLint -->|Pass| Phase3[Phase 3:<br/>Formatting]
    ESLint -->|Fail - T2| ESLintFix[Tier 2: Auto-Fix<br/>Apply ESLint]
    ESLintFix --> ESLintRecheck{Internal<br/>Re-Check<br/>T3}
    ESLintRecheck -->|Pass| Phase3
    ESLintRecheck -->|Fail - T4| ESLintRetry{Retry<br/>Count < 3?}
    ESLintRetry -->|Yes| ESLintFix
    ESLintRetry -->|No - T5| Escalate3[Tier 5: Escalate<br/>Detailed ESLint Report]

    Phase3 --> Format{Format<br/>Check}
    Format -->|Pass| Phase4[Phase 4:<br/>Validation]
    Format -->|Fail - T2| FormatFix[Tier 2: Auto-Fix<br/>Apply Prettier]
    FormatFix --> FormatRecheck{Internal<br/>Re-Check<br/>T3}
    FormatRecheck -->|Pass| Phase4
    FormatRecheck -->|Fail - T4| FormatRetry{Retry<br/>Count < 3?}
    FormatRetry -->|Yes| FormatFix
    FormatRetry -->|No - T5| Escalate4[Tier 5: Escalate<br/>Detailed Format Report]

    Phase4 --> WorkflowLint{Workflow<br/>Lint}
    WorkflowLint -->|Pass| Phase5[Phase 5:<br/>Post-Checks]
    WorkflowLint -->|Fail - T2| WorkflowFix[Tier 2: Auto-Fix<br/>Shellcheck Apply]
    WorkflowFix --> WorkflowRecheck{Internal<br/>Re-Check<br/>T3}
    WorkflowRecheck -->|Pass| Phase5
    WorkflowRecheck -->|Fail - T4| WorkflowRetry{Retry<br/>Count < 3?}
    WorkflowRetry -->|Yes| WorkflowFix
    WorkflowRetry -->|No - T5| Escalate5[Tier 5: Escalate<br/>Detailed Workflow Report]

    Phase5 --> FinalValidation{Final<br/>Validation<br/>T3}
    FinalValidation -->|Pass| IssueLink{Issue<br/>Linked?}
    FinalValidation -->|Fail - T4| FinalRetry{All Phases<br/>Retry?}
    FinalRetry -->|Yes| Phase1
    FinalRetry -->|No - T5| Escalate6[Tier 5: Escalate<br/>Complete Audit Trail]

    IssueLink -->|Yes| AutoPR[Auto-Create PR]
    IssueLink -->|No - T1| WarnNoIssue[Tier 1: Warning<br/>No Issue Link]
    WarnNoIssue --> AutoPR

    AutoPR --> PRDesc{PR Description<br/>Valid?}
    PRDesc -->|Yes| AllChecks{All Checks<br/>Pass?}
    PRDesc -->|Blank - T5| Escalate7[Tier 5: Escalate<br/>Blank PR Not Allowed]

    AllChecks -->|Pass| AutoMerge[Auto-Merge PR]
    AllChecks -->|Fail - T5| Escalate8[Tier 5: Escalate<br/>Cannot Merge<br/>Detailed Report]

    AutoMerge --> Success([✅ Complete:<br/>Commit → PR → Merged])

    Escalate1 --> ManualReview[👤 Human Review]
    Escalate2 --> ManualReview
    Escalate3 --> ManualReview
    Escalate4 --> ManualReview
    Escalate5 --> ManualReview
    Escalate6 --> ManualReview
    Escalate7 --> ManualReview
    Escalate8 --> ManualReview

    style Start fill:#10b981,color:#fff
    style Success fill:#10b981,color:#fff
    style ManualReview fill:#ef4444,color:#fff
    style Orchestrator fill:#3b82f6,color:#fff
    style AutoPR fill:#8b5cf6,color:#fff
    style AutoMerge fill:#8b5cf6,color:#fff
    style Warn1 fill:#f59e0b,color:#000
    style WarnNoIssue fill:#f59e0b,color:#000
    style AutoSquash fill:#06b6d4,color:#fff
    style ESLintFix fill:#06b6d4,color:#fff
    style FormatFix fill:#06b6d4,color:#fff
    style WorkflowFix fill:#06b6d4,color:#fff
    style AcquireLock fill:#06b6d4,color:#fff
    style ESLintRecheck fill:#14b8a6,color:#fff
    style FormatRecheck fill:#14b8a6,color:#fff
    style WorkflowRecheck fill:#14b8a6,color:#fff
    style FinalValidation fill:#14b8a6,color:#fff
    style Escalate1 fill:#ef4444,color:#fff
    style Escalate2 fill:#ef4444,color:#fff
    style Escalate3 fill:#ef4444,color:#fff
    style Escalate4 fill:#ef4444,color:#fff
    style Escalate5 fill:#ef4444,color:#fff
    style Escalate6 fill:#ef4444,color:#fff
    style Escalate7 fill:#ef4444,color:#fff
    style Escalate8 fill:#ef4444,color:#fff
```

### Threshold Model Explained

**Tier 1 - Warning (Continue Execution)**

- Issue detected but non-blocking
- Log warning message for audit trail
- Continue with normal workflow execution
- **Example**: Commit not linked to an issue

**Tier 2 - Auto-Fix & Retry (Single Attempt)**

- Issue detected that has known auto-fix
- Apply automated fix immediately
- Retry operation once
- **Examples**: ESLint errors, format drift, multiple commits on branch

**Tier 3 - Internal Validation (Before External Reporting)**

- Run internal checks after auto-fix
- Validate success before proceeding to next phase
- Prevents cascading failures
- **Examples**: Re-run ESLint after auto-fix, verify format after Prettier

**Tier 4 - Multiple Retry Passes (Up to 3 Attempts)**

- Internal validation failed
- Attempt up to 3 retry cycles with escalating strategies
- Each retry may use different approach
- Track all attempts for detailed reporting
- **Example**: ESLint fix → internal check → fail → retry with different config

**Tier 5 - Human Escalation (Detailed Failure Report)**

- All automated retry attempts exhausted
- Generate comprehensive failure report including:
  - Complete audit trail of all attempts
  - Specific errors encountered at each threshold
  - Commands attempted and their outputs
  - Recommendations for manual resolution
- Create issue or notification for human review
- **Examples**:
  - "Tried auto-squash 3 times with configs X, Y, Z - still multiple commits"
  - "ESLint auto-fix applied 3 times, all checks still failing on lines 42, 87, 193"
  - "Lock timeout after 5 minutes - concurrent workflow still running"

### Complete Workflow Flow

**1. Commit Pushed to `claude/**` Branch\*\*

```
→ Pre-flight checks (basic validation)
→ Orchestrator auto-triggers (ONLY workflow to auto-trigger on claude/** branches)
→ Sequential commits gate validates single commit
```

**2. Orchestrator Phases (Sequential Execution)**

```
Phase 1: Pre-Checks
├─ Race condition detection (with jq auto-install)
├─ Git lock acquisition (5min timeout)
└─ Basic validation checks

Phase 2: Linting
├─ ESLint check → Auto-fix if needed → Internal re-check → Retry up to 3x
├─ Workflow lint (actionlint) → Auto-fix if needed → Internal re-check → Retry up to 3x
└─ Static analysis validation

Phase 3: Formatting
├─ Prettier check → Auto-fix if needed → Internal re-check → Retry up to 3x
└─ Format validation

Phase 4: Validation
├─ PR risk assessment
├─ Docs drift detection
└─ Integration checks

Phase 5: Post-Checks
├─ Final race condition check
├─ Lock cleanup
└─ Comprehensive validation pass
```

**3. Auto-PR Creation**

```
→ Check issue linking (warn if missing)
→ Extract commit description for PR body
→ Validate PR description not blank (fail if empty)
→ Create PR automatically with commit description
→ Link to parent issue if specified
```

**4. Auto-Merge Decision**

```
→ Wait for all checks to complete
→ Verify ALL checks passed (no failures)
→ If all pass: Auto-merge immediately
→ If any fail: Escalate with detailed report of which checks failed and why
```

### Key Features

**✅ Self-Healing Automation**

- Automatically fixes common issues (linting, formatting, etc.)
- Multiple retry attempts with escalating strategies
- Internal validation before external reporting
- Detailed audit trail of all auto-fix attempts

**✅ Race Condition Prevention**

- File-based git operation locks (5min timeout)
- Automatic stale lock detection (10min threshold)
- Only orchestrator auto-triggers on claude/\*\* branches
- All other workflows coordinated through orchestrator

**✅ Intelligent Error Handling**

- 5-tier threshold model (warn → retry → internal check → multiple retries → escalate)
- Up to 3 automated retry attempts per failure
- Comprehensive failure reports with "tried X, Y, Z" details
- Clear escalation path to human review

**✅ Complete Automation Flow**

- Commit → Auto-PR → Auto-Merge (if all checks pass)
- Single commit per branch enforced
- Commit descriptions become PR descriptions
- No blank PRs allowed (enforced validation)

**✅ Issue Linking Integration**

- Warns if commit not linked to issue
- Allows merge but creates notification
- Enables post-facto issue linkage
- Tracks unlinked commits for audit

### Configuration

**Workflow Orchestration** (`.github/workflow-orchestration.yml`):

```yaml
orchestration:
  version: '1.0'
  settings:
    enabled: true
    retry_attempts: 3
    internal_validation: true
    auto_pr: true
    auto_merge: true
  phases:
    pre_checks: [...]
    linting: [...]
    formatting: [...]
    validation: [...]
    post_checks: [...]
```

**Retry Configuration** (Per Workflow):

```yaml
retry:
  max_attempts: 3
  strategies:
    - attempt_1: default_config
    - attempt_2: strict_config
    - attempt_3: permissive_config
```

### Usage

**Manual Orchestration Trigger**:

```bash
# Run all phases
gh workflow run orchestrator.yml

# Run specific phase
gh workflow run orchestrator.yml -f phase=linting

# Dry run (preview only)
gh workflow run orchestrator.yml -f dry_run=true

# Skip race detection
gh workflow run orchestrator.yml -f skip_race_detection=true
```

**Auto-PR Workflow** (Automatic on push to `claude/**`):

```
1. Push commit to claude/** branch
2. Orchestrator auto-triggers and runs all phases
3. If all checks pass: PR created automatically
4. If PR checks pass: Auto-merged immediately
5. If any failures: Detailed escalation report generated
```

**Monitor Workflow Status**:

```bash
# Check lock status
.github/scripts/git-lock.sh list

# Check for race conditions
.github/scripts/race-condition-detector.sh --check-git

# View recent workflow runs
gh run list --branch claude/your-branch --limit 10
```

### Documentation

**Complete Technical Reference**:

- [WORKFLOW_ORCHESTRATION.md](./.github/WORKFLOW_ORCHESTRATION.md) - Full architecture and implementation details
- [ORCHESTRATION_SUMMARY.md](./.github/ORCHESTRATION_SUMMARY.md) - Quick reference guide

**Scripts**:

- `.github/scripts/git-lock.sh` - File-based git operation locking (9.2KB)
- `.github/scripts/race-condition-detector.sh` - Race condition detection (13.8KB)
- `.github/scripts/check-sequential-commits.mjs` - Commit validation logic

### Monitoring & Debugging

**Workflow Execution Logs**:

- Each phase generates detailed step-by-step logs
- Auto-fix attempts logged with before/after diffs
- Retry attempts tracked with attempt number and strategy
- Internal validation results logged separately from external

**Failure Escalation Reports**:

```
❌ Escalation Required: ESLint Validation Failed After 3 Attempts

Audit Trail:
---
Attempt 1 (default_config):
  Command: npm run lint:fix
  Exit Code: 1
  Errors: src/utils.js:42 - 'foo' is not defined
  Duration: 2.3s

Attempt 2 (strict_config):
  Command: npm run lint:fix -- --strict
  Exit Code: 1
  Errors: src/utils.js:42 - 'foo' is not defined
  Duration: 2.1s

Attempt 3 (permissive_config):
  Command: npm run lint:fix -- --allow-warnings
  Exit Code: 1
  Errors: src/utils.js:42 - 'foo' is not defined
  Duration: 2.2s

Recommendation:
Variable 'foo' is referenced but never declared. Manual fix required:
  1. Add variable declaration: const foo = ...
  2. Or remove reference to undefined variable
  3. Then push changes to retry orchestration

Failed Check: eslint-gate.yml
Branch: claude/fix-broken-workflows-011CV4ytHzLBXMePN9FLatGT
Commit: a64a3ff
```

### Performance & Reliability

**Execution Time**: 5-8 minutes for complete orchestration (all phases)
**Accuracy**: Multi-tier validation ensures > 95% auto-resolution rate
**Reliability**: Concurrency controls prevent race conditions entirely
**Audit**: Complete audit trail of all operations and decisions

## AI Workflow: Git Worktrees + Atomic Tasks (CORE)

**This is the foundational workflow** that enables true parallel AI development without commit chaos or merge conflicts.

### The Problem: Sequential Commits on Single Branch

When AI works on multiple phases sequentially on one branch:

```
Branch: claude/task-123
├─ Commit 1: Phase 1 (schemas)
├─ Commit 2: Phase 2A (create files)
├─ Commit 3: Phase 2B (verify files)
└─ Commit 4: Phase 3 (integration)
```

**Issues:**

- ❌ Commits pile up if not merged immediately
- ❌ Merged together = garbled descriptions, lost audit trail
- ❌ AI must wait for human to merge before continuing
- ❌ Cannot work on independent phases in parallel

### The Solution: Git Worktrees + Atomic Tasks

Each **atomic phase** gets its own **branch** and **worktree**:

```bash
# Main working directory (original clone)
/home/user/project/

# Phase-specific worktrees (isolated working directories)
/home/user/project-worktrees/
  ├─ p0.2-phase1/     → Branch: claude/p0.2-phase1-[session]
  ├─ p0.2-phase2a/    → Branch: claude/p0.2-phase2a-[session]
  ├─ p0.2-phase2b/    → Branch: claude/p0.2-phase2b-[session]
  └─ p0.2-phase3/     → Branch: claude/p0.2-phase3-[session]
```

**Creating a worktree for each phase:**

```bash
# Start new phase in isolated worktree
git worktree add ../project-worktrees/p0.2-phase1 -b claude/p0.2-phase1-[session-id]

# Work in that directory
cd ../project-worktrees/p0.2-phase1

# Make changes, commit, push
git add .
git commit -m "docs: Complete P0.2 Phase 1 - Template schemas"
git push -u origin claude/p0.2-phase1-[session-id]

# Human merges Phase 1 PR whenever ready

# Meanwhile, AI starts Phase 2A in NEW worktree (doesn't wait for merge!)
cd /home/user/project
git worktree add ../project-worktrees/p0.2-phase2a -b claude/p0.2-phase2a-[session-id]
cd ../project-worktrees/p0.2-phase2a
# ... work continues independently
```

### Benefits of This Workflow

✅ **True Parallelization**: AI works on Phase 3 while Phase 1 awaits human review
✅ **No Commit Pileup**: Each phase = one branch = one PR = clean merge
✅ **Audit-Friendly**: Each commit has comprehensive description preserved
✅ **No Garbled Descriptions**: Each phase merged independently, descriptions intact
✅ **Dependency-Safe**: Atomic tasks with explicit dependencies prevent conflicts
✅ **Compounding Engineering**: Each phase builds reusable artifacts for future work

### Workflow Integration with BMAD

This workflow is **core to BMAD (Build-Measure-Analyze-Document)** and compounding engineering:

1. **Build** - Each atomic task creates something measurable (template, test, feature)
2. **Measure** - Verification phase confirms success criteria met
3. **Analyze** - Commit descriptions document decisions and outcomes
4. **Document** - Reusable patterns/artifacts left for future work

**Every completed phase:**

- Leaves behind reusable fixtures, generators, or documentation
- Makes the next phase easier and faster
- Compounds quality improvements over time

### AI Execution Pattern

**For AI assistants working on atomic tasks:**

```python
# Pseudo-code workflow
for phase in task.phases:
    if phase.has_upstream_dependency():
        wait_for_dependency_merge()

    # Create isolated worktree
    create_worktree(f"phase-{phase.id}")

    # Execute phase atomically
    execute_atomic_tasks(phase.tasks)

    # Commit with comprehensive description
    commit_with_audit_trail(phase)

    # Push and create PR
    push_and_pr(phase)

    # Human merges when ready (AI doesn't wait, moves to next independent phase)
```

### When to Use Worktrees

**Use worktrees when:**

- ✅ Working on independent phases that can be merged separately
- ✅ Atomic tasks have no dependencies on uncommitted work
- ✅ Each phase has distinct deliverables (schemas vs implementations vs tests)
- ✅ Human review/merge timing is unpredictable

**Don't use worktrees when:**

- ❌ Sequential tasks must build on uncommitted changes from previous task
- ❌ Single atomic task that completes in one commit
- ❌ Rapid iteration where immediate merge is guaranteed

### Task Planning: Atomic + Dependency Tracking

See [current_work_todo.md](./current_work_todo.md) for complete atomic task breakdowns with:

- ⬆️ **UPSTREAM DEPENDENCY** markers - Shows what must complete first
- **Parallelization notes** - Which tasks can run concurrently in separate worktrees
- **Estimated times** - All tasks ≤30 min (AI capability threshold)
- **Phase groupings** - Logical units for worktree isolation

### Documentation

- **Task Reference**: [TASK_REFERENCE_INDEX.md](./TASK_REFERENCE_INDEX.md) - Maps all tasks with worktree workflow
- **Atomic TDD Framework**: [ATOMIC_TDD_FRAMEWORK.md](./ATOMIC_TDD_FRAMEWORK.md) - Full methodology
- **Active Work**: [current_work_todo.md](./current_work_todo.md) - Current priorities with dependency tracking

## Using This Template

### For Claude Code (AI Assistant)

When the user asks you to create a new repository from this template, run:

```bash
# Create repo from template and clone it
gh repo create Jackson-Devices/<NEW_REPO_NAME> \
  --template Jackson-Devices/JD_GitHub_template \
  --private \
  --clone

cd <NEW_REPO_NAME>

# Trigger workflow in dry-run mode to preview changes
gh workflow run apply_settings.yml -f mode=dry_run

# Watch the run and show output
gh run watch

# After user verifies the preview looks correct, trigger apply mode
gh workflow run apply_settings.yml -f mode=apply

# Watch the apply run
gh run watch

# After labels are applied successfully, clean up init file
git rm REPO_INIT.md
git commit -m "Remove init checklist after setup"
git push
```

No environment setup is required - the workflow uses security guardrails instead.

### Manual Setup (Without CLI)

1. Create new repository from this template on GitHub
2. Clone locally and follow the `REPO_INIT.md` checklist
3. Customize labels in `.github/settings.yml` if needed
4. Run workflow to apply labels
5. Delete `REPO_INIT.md` when setup is complete

## Documentation

**Quick Start**:

- [REPO_VARIABLES.md](./.github/REPO_VARIABLES.md) - Configure workflow behavior via repository variables
- [WORKFLOW_BEHAVIOR.md](./.github/WORKFLOW_BEHAVIOR.md) - Complete workflow reference with commands and examples

**Design Reference**:

- [LABEL_DESIGN_SPEC.md](./LABEL_DESIGN_SPEC.md) - Complete label taxonomy specification

## Files Included

- `.github/settings.yml` - Label configuration (edit this to customize labels)
- `.github/workflows/` - Four automated workflows:
  - `apply_settings.yml` - Label sync (manual trigger)
  - `context-commands.yml` - Context variable management (`/context` commands)
  - `enforce_test_gate.yml` - Validation gate enforcement (auto-runs)
  - `seed-test-runlist.yml` - Test checklist generation (auto-runs + `/seed` commands)
- `.github/scripts/apply_settings.mjs` - Label sync script
- `.github/REPO_VARIABLES.md` - Repository variables documentation
- `.github/WORKFLOW_BEHAVIOR.md` - Workflow behavior guide
- `REPO_INIT.md` - Setup checklist (delete after initialization)
- `README.md` - This file (replace with your project README)

## Configuration Notes

### Workflow Behavior

- **Strict mode enabled** - Automatically deletes labels not in settings.yml
- **Rename support** - Use `from_name` to preserve issue/PR attachments
- **Preview before apply** - Dry-run mode shows changes before applying
- **Security guardrails** - Restricted to Jackson-Devices organization

### Customizing Labels

Edit `.github/settings.yml` to:

- Add new labels to your taxonomy
- Modify colors or descriptions
- Remove labels you don't need

Labels not in settings.yml will be automatically deleted when workflow runs.

## Maintenance

Once initialized, the workflow automatically syncs labels whenever:

- Changes are pushed to `.github/settings.yml` on main branch
- Workflow is manually triggered via Actions tab

This ensures label consistency across all Jackson-Devices repositories.

---

## Future Enhancements

For all planned improvements, enhancements, and future work:

- **Primary Task List:** [current_work_todo.md](./current_work_todo.md) - Atomic P0-P4 plan with tracking
- **Task Reference Index:** [TASK_REFERENCE_INDEX.md](./TASK_REFERENCE_INDEX.md) - Complete task mapping
- **Historical Archive:** [docs/archive/](./docs/archive/) - Previous TODO files with detailed subtasks

---

## Recent Improvements (v1.3)

### Workflow Robustness

- **Concurrency control**: Per-issue locking prevents race conditions
- **Better feedback**: Detailed error messages and audit trails
- **Input validation**: Stricter regex patterns for IB/OOB cases (no leading zeros)
- **Configurable**: Hardcoded values moved to repository variables
- **API efficiency**: Batch label updates, optimized API calls
- **Preview consistency**: Clear "what will change" output across workflows

### New Features

- `/context preview` command - See changes before applying
- `/seed keep/merge/overwrite` commands - Conflict resolution for Run checklists
- Manual edit detection - Workflows detect and preserve user changes
- Comprehensive documentation - REPO_VARIABLES.md and WORKFLOW_BEHAVIOR.md guides

### See Also

- [WORKFLOW_BEHAVIOR.md](./.github/WORKFLOW_BEHAVIOR.md) for complete workflow reference
- [REPO_VARIABLES.md](./.github/REPO_VARIABLES.md) for configuration options
- [current_work_todo.md](./current_work_todo.md) for planned work with atomic tracking
- [TASK_REFERENCE_INDEX.md](./TASK_REFERENCE_INDEX.md) for complete task mapping

---

**Template Version:** 1.3
**Last Updated:** 2025-11-07
**Maintained by:** Jackson-Devices
