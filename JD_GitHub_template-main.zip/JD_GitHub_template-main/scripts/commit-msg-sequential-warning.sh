#!/bin/bash
# Commit-msg hook: Warn about sequential commits (informational only)
# This hook provides guidance but does NOT block commits
# Enforcement happens via GitHub Actions workflow

set -e

# Get current branch name
CURRENT_BRANCH=$(git rev-parse --abbrev-ref HEAD 2>/dev/null || echo "unknown")

# Only check claude/ branches
if [[ ! "$CURRENT_BRANCH" =~ ^claude/ ]]; then
    exit 0
fi

# Get default branch
DEFAULT_BRANCH=$(git remote show origin 2>/dev/null | grep 'HEAD branch' | cut -d' ' -f5 || echo "main")

# Count existing commits on this branch (not including the one being created)
TOTAL_COMMITS=$(git rev-list --count origin/${DEFAULT_BRANCH}..HEAD 2>/dev/null || echo "0")

# If branch already has commits, warn the user
if [ "$TOTAL_COMMITS" -ge 1 ]; then
    echo ""
    echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
    echo "⚠️  SEQUENTIAL COMMIT WARNING"
    echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
    echo ""
    echo "📍 Branch: $CURRENT_BRANCH"
    echo "📊 Existing commits: $TOTAL_COMMITS"
    echo ""
    echo "⚠️  This branch already has commits. Sequential commits are discouraged."
    echo ""
    echo "💡 RECOMMENDED ACTION:"
    echo "   Create a NEW branch for additional changes:"
    echo ""
    echo "   git stash                    # Save your changes"
    echo "   git checkout -b claude/new-branch-<SESSION_ID>"
    echo "   git stash pop                # Restore changes"
    echo "   git add ."
    echo "   git commit -m \"your message\""
    echo ""
    echo "ℹ️  If you proceed, this commit will be created locally but may be"
    echo "   blocked by GitHub Actions when pushed."
    echo ""
    echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
    echo ""
fi

# Always allow commit (informational only)
exit 0
