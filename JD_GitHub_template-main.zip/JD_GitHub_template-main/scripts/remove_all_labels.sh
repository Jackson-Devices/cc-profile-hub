#!/bin/bash

# Script to remove all labels from all issues and then delete all labels from repository
# This prepares for the label migration to capitalized names

REPO="Jackson-Devices/JD_GitHub_template"

echo "=========================================="
echo "Label Migration Cleanup Script"
echo "=========================================="
echo ""
echo "This script will:"
echo "1. Remove all labels from ALL issues"
echo "2. Delete ALL labels from the repository"
echo "3. You can then run the label sync workflow to create new capitalized labels"
echo ""
read -p "Are you sure you want to continue? (yes/no): " confirm

if [ "$confirm" != "yes" ]; then
    echo "Aborted."
    exit 0
fi

echo ""
echo "Step 1: Removing labels from all issues..."
echo "=========================================="

# Get all issue numbers
issue_numbers=$(gh issue list --repo "$REPO" --limit 1000 --json number --jq '.[].number')

for issue_num in $issue_numbers; do
    echo "Processing issue #$issue_num..."

    # Get all labels on this issue
    labels=$(gh issue view "$issue_num" --repo "$REPO" --json labels --jq '.labels[].name')

    if [ -n "$labels" ]; then
        # Remove each label
        while IFS= read -r label; do
            echo "  Removing label: $label"
            gh issue edit "$issue_num" --repo "$REPO" --remove-label "$label" 2>/dev/null || echo "  Failed to remove: $label"
        done <<< "$labels"
    else
        echo "  No labels to remove"
    fi
done

echo ""
echo "Step 2: Deleting all labels from repository..."
echo "=========================================="

# Get all repository labels
repo_labels=$(gh label list --repo "$REPO" --limit 1000 --json name --jq '.[].name')

for label in $repo_labels; do
    echo "Deleting label: $label"
    gh label delete "$label" --repo "$REPO" --yes 2>/dev/null || echo "Failed to delete: $label"
done

echo ""
echo "=========================================="
echo "Cleanup Complete!"
echo "=========================================="
echo ""
echo "Next steps:"
echo "1. Commit and push the updated settings.yml and workflow files"
echo "2. Trigger the label sync workflow manually:"
echo "   gh workflow run apply_settings.yml --repo $REPO"
echo "3. Wait for the workflow to complete (creates new capitalized labels)"
echo "4. Manually re-apply labels to issues #43-53 with new capitalized names"
echo ""
