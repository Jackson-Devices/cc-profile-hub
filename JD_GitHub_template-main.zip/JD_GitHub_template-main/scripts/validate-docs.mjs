#!/usr/bin/env node

import { readFileSync, readdirSync, statSync, existsSync } from 'fs';
import { join, dirname, relative } from 'path';
import { fileURLToPath } from 'url';
import Ajv from 'ajv';
import yaml from 'js-yaml';

const __filename = fileURLToPath(import.meta.url);
const __dirname = dirname(__filename);
const rootDir = join(__dirname, '..');

// Parse command line arguments
const args = process.argv.slice(2);
const options = {
  help: args.includes('--help') || args.includes('-h'),
  verbose: args.includes('--verbose') || args.includes('-v'),
  format: args.find((a) => a.startsWith('--format='))?.split('=')[1] || 'text',
  checks:
    args
      .find((a) => a.startsWith('--checks='))
      ?.split('=')[1]
      ?.split(',') || 'all',
  card: args.find((a) => a.startsWith('--card='))?.split('=')[1],
};

if (options.help) {
  console.log(`
Documentation Validation CLI

Usage: npm run validate:docs [options]

Options:
  --help, -h          Show this help message
  --verbose, -v       Show detailed output
  --format=<format>   Output format: text, json (default: text)
  --checks=<checks>   Comma-separated list of checks to run (default: all)
                      Available: schema,tokens,links,identity,tasks,mirrors,duplicates,budget
  --card=<path>       Validate specific card only

Examples:
  npm run validate:docs
  npm run validate:docs -- --verbose
  npm run validate:docs -- --checks=schema,tokens
  npm run validate:docs -- --card=docs/cards/task/testing-workflow.md
  `);
  process.exit(0);
}

// Validation results
const results = {
  schema: { pass: 0, warn: 0, error: 0, issues: [] },
  tokens: { pass: 0, warn: 0, error: 0, issues: [] },
  links: { pass: 0, warn: 0, error: 0, issues: [] },
  identity: { pass: 0, warn: 0, error: 0, issues: [] },
  tasks: { pass: 0, warn: 0, error: 0, issues: [] },
  mirrors: { pass: 0, warn: 0, error: 0, issues: [] },
  duplicates: { pass: 0, warn: 0, error: 0, issues: [] },
  budget: { pass: 0, warn: 0, error: 0, issues: [] },
};

// Helper: Extract front-matter
function extractFrontMatter(content) {
  const frontMatterRegex = /^---\s*\n([\s\S]*?)\n---/;
  const match = content.match(frontMatterRegex);
  if (!match) return null;
  try {
    return yaml.load(match[1]);
    // eslint-disable-next-line no-unused-vars
  } catch (_err) {
    return null;
  }
}

// Helper: Find all card files
function findCardFiles(dir, fileList = []) {
  if (!existsSync(dir)) return fileList;
  const files = readdirSync(dir);
  files.forEach((file) => {
    const filePath = join(dir, file);
    const stat = statSync(filePath);
    if (stat.isDirectory()) {
      findCardFiles(filePath, fileList);
    } else if (file.endsWith('.md') && file !== 'README.md') {
      fileList.push(filePath);
    }
  });
  return fileList;
}

// Check 1: Metadata Schema Validation
function validateSchema(cardFiles, schema) {
  const ajv = new Ajv({ allErrors: true });
  const validate = ajv.compile(schema);

  cardFiles.forEach((filePath) => {
    const content = readFileSync(filePath, 'utf8');
    const frontMatter = extractFrontMatter(content);
    const relativePath = relative(rootDir, filePath);

    if (!frontMatter) {
      results.schema.error++;
      results.schema.issues.push({
        file: relativePath,
        message: 'No front-matter found',
      });
      return;
    }

    const valid = validate(frontMatter);
    if (valid) {
      results.schema.pass++;
    } else {
      results.schema.error++;
      validate.errors.forEach((err) => {
        results.schema.issues.push({
          file: relativePath,
          field: err.instancePath || '(root)',
          message: err.message,
        });
      });
    }
  });
}

// Check 2: Token Estimate Accuracy
function validateTokens(cardFiles) {
  cardFiles.forEach((filePath) => {
    const content = readFileSync(filePath, 'utf8');
    const frontMatter = extractFrontMatter(content);
    const relativePath = relative(rootDir, filePath);

    if (!frontMatter || !frontMatter.tokens_estimate) {
      return;
    }

    const actualTokens = Math.ceil(content.length / 4);
    const estimatedTokens = frontMatter.tokens_estimate;
    const diff = Math.abs(actualTokens - estimatedTokens);
    const percentDiff = (diff / actualTokens) * 100;

    if (percentDiff > 10) {
      results.tokens.warn++;
      results.tokens.issues.push({
        file: relativePath,
        expected: estimatedTokens,
        actual: actualTokens,
        drift: `${percentDiff.toFixed(1)}%`,
      });
    } else {
      results.tokens.pass++;
    }
  });
}

// Check 3: Link and Anchor Resolution
function validateLinks(cardFiles) {
  cardFiles.forEach((filePath) => {
    const content = readFileSync(filePath, 'utf8');
    const relativePath = relative(rootDir, filePath);

    // Match markdown links: [text](path) or [text](path#anchor)
    const linkRegex = /\[([^\]]+)\]\(([^)]+)\)/g;
    let match;

    while ((match = linkRegex.exec(content)) !== null) {
      const linkPath = match[2];

      // Skip external links
      if (linkPath.startsWith('http://') || linkPath.startsWith('https://')) {
        continue;
      }

      // Parse link and anchor
      const [path, _anchor] = linkPath.split('#');
      if (!path) continue; // Anchor-only link

      // Resolve relative path
      const targetPath = join(dirname(filePath), path);

      if (!existsSync(targetPath)) {
        results.links.error++;
        results.links.issues.push({
          file: relativePath,
          link: linkPath,
          message: `File not found: ${relative(rootDir, targetPath)}`,
        });
      } else {
        results.links.pass++;
      }

      // TODO: Validate anchors (would need to parse target file headings)
    }
  });
}

// Check 4: Identity Checks
function validateIdentity(cardFiles) {
  const ids = new Map();
  const titlesByTopic = new Map();

  cardFiles.forEach((filePath) => {
    const content = readFileSync(filePath, 'utf8');
    const frontMatter = extractFrontMatter(content);
    const relativePath = relative(rootDir, filePath);

    if (!frontMatter) return;

    // Check unique IDs
    if (frontMatter.id) {
      if (ids.has(frontMatter.id)) {
        results.identity.error++;
        results.identity.issues.push({
          file: relativePath,
          id: frontMatter.id,
          message: `Duplicate ID (also in ${ids.get(frontMatter.id)})`,
        });
      } else {
        ids.set(frontMatter.id, relativePath);
        results.identity.pass++;
      }
    }

    // Check duplicate titles per topic
    if (frontMatter.title && frontMatter.topics) {
      frontMatter.topics.forEach((topic) => {
        if (!titlesByTopic.has(topic)) {
          titlesByTopic.set(topic, new Map());
        }
        const topicTitles = titlesByTopic.get(topic);
        if (topicTitles.has(frontMatter.title)) {
          results.identity.warn++;
          results.identity.issues.push({
            file: relativePath,
            title: frontMatter.title,
            topic: topic,
            message: `Duplicate title in topic "${topic}" (also in ${topicTitles.get(frontMatter.title)})`,
          });
        } else {
          topicTitles.set(frontMatter.title, relativePath);
        }
      });
    }
  });
}

// Check 5: Tasks Map Integrity
function validateTasksMap() {
  const tasksMapPath = join(rootDir, 'docs/tasks.map.yaml');
  if (!existsSync(tasksMapPath)) {
    results.tasks.warn++;
    results.tasks.issues.push({ message: 'tasks.map.yaml not found' });
    return;
  }

  try {
    const tasksMap = yaml.load(readFileSync(tasksMapPath, 'utf8'));

    Object.entries(tasksMap.tasks || {}).forEach(([taskId, task]) => {
      if (!task.sequence || !Array.isArray(task.sequence)) {
        results.tasks.error++;
        results.tasks.issues.push({
          task: taskId,
          message: 'Missing or invalid sequence',
        });
        return;
      }

      task.sequence.forEach((ref, index) => {
        const cardPath = join(rootDir, 'docs/cards', `${ref.id}.md`);
        if (!existsSync(cardPath)) {
          results.tasks.error++;
          results.tasks.issues.push({
            task: taskId,
            sequence: index + 1,
            card: ref.id,
            message: `Referenced card not found: ${ref.id}`,
          });
        } else {
          results.tasks.pass++;
        }
      });
    });
  } catch (err) {
    results.tasks.error++;
    results.tasks.issues.push({ message: `Failed to parse tasks.map.yaml: ${err.message}` });
  }
}

// Check 6: Issue Mirror Freshness (simplified - just check directory exists)
function validateMirrors() {
  const mirrorsDir = join(rootDir, 'docs/issues_mirror');
  if (!existsSync(mirrorsDir)) {
    results.mirrors.warn++;
    results.mirrors.issues.push({ message: 'issues_mirror directory not found' });
    return;
  }

  const mirrorFiles = readdirSync(mirrorsDir).filter((f) => f.endsWith('.md') && f !== 'README.md');
  results.mirrors.pass = mirrorFiles.length;

  // TODO: Check last_synced_commit age (would need git log timestamps)
}

// Check 7: Near-Duplicate Detection (simplified similarity check)
function validateDuplicates(cardFiles) {
  // Simplified: Check for very similar titles
  const titles = new Map();

  cardFiles.forEach((filePath) => {
    const content = readFileSync(filePath, 'utf8');
    const frontMatter = extractFrontMatter(content);
    const relativePath = relative(rootDir, filePath);

    if (!frontMatter?.title) return;

    const normalizedTitle = frontMatter.title.toLowerCase().trim();
    if (titles.has(normalizedTitle)) {
      results.duplicates.warn++;
      results.duplicates.issues.push({
        file: relativePath,
        title: frontMatter.title,
        similar: titles.get(normalizedTitle),
      });
    } else {
      titles.set(normalizedTitle, relativePath);
      results.duplicates.pass++;
    }
  });
}

// Check 8: Budget Simulation
function validateBudget() {
  const tasksMapPath = join(rootDir, 'docs/tasks.map.yaml');
  if (!existsSync(tasksMapPath)) {
    return;
  }

  try {
    const tasksMap = yaml.load(readFileSync(tasksMapPath, 'utf8'));

    Object.entries(tasksMap.tasks || {}).forEach(([taskId, task]) => {
      if (!task.sequence) return;

      let totalTokens = 0;
      task.sequence.forEach((ref) => {
        const cardPath = join(rootDir, 'docs/cards', `${ref.id}.md`);
        if (existsSync(cardPath)) {
          const content = readFileSync(cardPath, 'utf8');
          const frontMatter = extractFrontMatter(content);
          if (frontMatter?.tokens_estimate) {
            totalTokens += frontMatter.tokens_estimate + 50; // +50 overhead
          }
        }
      });

      if (totalTokens <= task.bundle_budget_tokens) {
        results.budget.pass++;
      } else {
        results.budget.warn++;
        results.budget.issues.push({
          task: taskId,
          total: totalTokens,
          budget: task.bundle_budget_tokens,
          overrun: totalTokens - task.bundle_budget_tokens,
        });
      }
    });
    // eslint-disable-next-line no-unused-vars
  } catch (_err) {
    // Already handled in tasks validation
  }
}

// Main validation
console.log('🔍 Validating Documentation System...\n');

const startTime = Date.now();

// Load schema
const schemaPath = join(rootDir, 'docs/cards/card-schema.json');
const schema = JSON.parse(readFileSync(schemaPath, 'utf8'));

// Get card files
const cardsDir = join(rootDir, 'docs/cards');
let cardFiles = options.card ? [join(rootDir, options.card)] : findCardFiles(cardsDir);

// Run checks
const checksToRun = options.checks === 'all' ? Object.keys(results) : options.checks;

if (checksToRun.includes('schema')) {
  console.log('[1/8] Metadata Schema...');
  validateSchema(cardFiles, schema);
}

if (checksToRun.includes('tokens')) {
  console.log('[2/8] Token Estimates...');
  validateTokens(cardFiles);
}

if (checksToRun.includes('links')) {
  console.log('[3/8] Links and Anchors...');
  validateLinks(cardFiles);
}

if (checksToRun.includes('identity')) {
  console.log('[4/8] Identity...');
  validateIdentity(cardFiles);
}

if (checksToRun.includes('tasks')) {
  console.log('[5/8] Tasks Map Integrity...');
  validateTasksMap();
}

if (checksToRun.includes('mirrors')) {
  console.log('[6/8] Issue Mirror Freshness...');
  validateMirrors();
}

if (checksToRun.includes('duplicates')) {
  console.log('[7/8] Near-Duplicates...');
  validateDuplicates(cardFiles);
}

if (checksToRun.includes('budget')) {
  console.log('[8/8] Budget Simulation...');
  validateBudget();
}

const duration = ((Date.now() - startTime) / 1000).toFixed(1);

// Output results
console.log('\n━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━');
console.log('📊 Validation Summary');
console.log('━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━');

let totalErrors = 0;
let totalWarnings = 0;

Object.entries(results).forEach(([check, result]) => {
  if (!checksToRun.includes(check) && checksToRun !== 'all') return;

  const status = result.error > 0 ? '✗ ERROR' : result.warn > 0 ? '⚠ WARN' : '✓ PASS';
  console.log(
    `${check.padEnd(15)} ${status} (${result.pass} pass, ${result.warn} warn, ${result.error} error)`
  );

  totalErrors += result.error;
  totalWarnings += result.warn;

  if (options.verbose && result.issues.length > 0) {
    result.issues.slice(0, 10).forEach((issue) => {
      console.log(`  - ${JSON.stringify(issue)}`);
    });
    if (result.issues.length > 10) {
      console.log(`  ... and ${result.issues.length - 10} more`);
    }
  }
});

console.log(`\nCompleted in ${duration}s`);
console.log(`\n${totalErrors} errors, ${totalWarnings} warnings`);
console.log('\n⚠️  Warnings do not fail validation (warn-only mode)');

// Always exit 0 (warn-only)
process.exit(0);
