#!/usr/bin/env node

import { readFileSync, readdirSync, statSync } from 'fs';
import { join, dirname, relative } from 'path';
import { fileURLToPath } from 'url';
import yaml from 'js-yaml';

const __filename = fileURLToPath(import.meta.url);
const __dirname = dirname(__filename);
const rootDir = join(__dirname, '..');

// Get changed files from environment (passed from workflow)
const changedFilesStr = process.env.CHANGED_FILES || '';
const changedFiles = changedFilesStr
  .split('\n')
  .map((f) => f.trim())
  .filter((f) => f.length > 0);

if (changedFiles.length === 0) {
  console.log('No changed files detected. Exiting.');
  process.exit(0);
}

console.log(`📊 Analyzing ${changedFiles.length} changed files for documentation drift...`);
console.log('');

// Extract front-matter from markdown
function extractFrontMatter(content) {
  const frontMatterRegex = /^---\s*\n([\s\S]*?)\n---/;
  const match = content.match(frontMatterRegex);

  if (!match) {
    return null;
  }

  try {
    return yaml.load(match[1]);
    // eslint-disable-next-line no-unused-vars
  } catch (_err) {
    return null;
  }
}

// Recursively find all .md files in docs/cards
function findCardFiles(dir, fileList = []) {
  const files = readdirSync(dir);

  files.forEach((file) => {
    const filePath = join(dir, file);
    const stat = statSync(filePath);

    if (stat.isDirectory()) {
      findCardFiles(filePath, fileList);
    } else if (file.endsWith('.md') && file !== 'README.md') {
      fileList.push(filePath);
    }
  });

  return fileList;
}

// Check if changed file matches any source_paths
function matchesSourcePath(changedFile, sourcePaths) {
  if (!sourcePaths || !Array.isArray(sourcePaths)) {
    return false;
  }

  return sourcePaths.some((sourcePath) => {
    // Normalize paths for comparison
    const normalizedChanged = changedFile.replace(/^\.\//, '');
    const normalizedSource = sourcePath.replace(/^\.\//, '');

    // Exact match or pattern match (simple wildcard support)
    if (normalizedChanged === normalizedSource) {
      return true;
    }

    // Check if changed file starts with source path (directory match)
    if (normalizedChanged.startsWith(normalizedSource + '/')) {
      return true;
    }

    return false;
  });
}

// Calculate staleness (days since last verification)
function calculateStaleness(lastVerifiedCommit) {
  // This is a simplified version - in production, we'd use git log timestamps
  // For now, we'll just note the commit hash
  return { commit: lastVerifiedCommit, age: 'unknown' };
}

// Main drift detection
const cardsDir = join(rootDir, 'docs/cards');
const cardFiles = findCardFiles(cardsDir);

const affectedCards = [];

cardFiles.forEach((cardPath) => {
  try {
    const content = readFileSync(cardPath, 'utf8');
    const frontMatter = extractFrontMatter(content);

    if (!frontMatter) {
      return; // Skip cards without front-matter
    }

    const sourcePaths = frontMatter.source_paths || [];

    // Check if any changed file affects this card
    const matchingChanges = changedFiles.filter((changedFile) =>
      matchesSourcePath(changedFile, sourcePaths)
    );

    if (matchingChanges.length > 0) {
      const relativePath = relative(rootDir, cardPath);
      const staleness = calculateStaleness(frontMatter.last_verified_commit);

      affectedCards.push({
        id: frontMatter.id,
        title: frontMatter.title,
        path: relativePath,
        version: frontMatter.version,
        last_verified_commit: frontMatter.last_verified_commit,
        staleness: staleness,
        source_paths: sourcePaths,
        related_tasks: frontMatter.related_tasks || [],
        matching_changes: matchingChanges,
      });
    }
    // eslint-disable-next-line no-unused-vars
  } catch (_err) {
    // Skip files that can't be read or parsed
  }
});

// Output results
if (affectedCards.length === 0) {
  console.log('✅ No documentation drift detected.');
  console.log('   All changed files are outside of documented source paths.');
  process.exit(0);
}

console.log(`⚠️  Documentation drift detected: ${affectedCards.length} card(s) may need updates`);
console.log('');

affectedCards.forEach((card, index) => {
  console.log(`${index + 1}. ${card.path}`);
  console.log(`   Card: ${card.title} (${card.id})`);
  console.log(`   Version: ${card.version}`);
  console.log(`   Last verified: ${card.last_verified_commit}`);
  console.log(`   Changed files affecting this card:`);
  card.matching_changes.forEach((file) => {
    console.log(`     - ${file}`);
  });

  if (card.related_tasks.length > 0) {
    console.log(`   Related tasks: ${card.related_tasks.join(', ')}`);
  } else {
    console.log(`   Related tasks: none (may need tracking issue)`);
  }

  console.log('');
});

// Generate output for GitHub Actions (summary and annotations)
console.log('━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━');
console.log('📋 Next Steps:');
console.log('');
console.log('1. Review affected cards for accuracy');
console.log('2. Update card content if changes affect documentation');
console.log('3. Update last_verified_commit if content still valid');
console.log('4. Apply Docs: Ready label when complete');
console.log('');
console.log('⚠️  This is a warning only - does not block merge');
console.log('━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━');

// Output JSON for workflow consumption
if (process.env.GITHUB_OUTPUT) {
  const _output = {
    affected_cards: affectedCards.length,
    has_drift: affectedCards.length > 0,
    cards: affectedCards.map((c) => ({
      id: c.id,
      path: c.path,
      title: c.title,
    })),
  };

  console.log('');
  console.log('DRIFT_DETECTED=' + (affectedCards.length > 0 ? 'true' : 'false'));
  console.log('AFFECTED_COUNT=' + affectedCards.length);
}

// Always exit 0 (warn-only mode)
process.exit(0);
