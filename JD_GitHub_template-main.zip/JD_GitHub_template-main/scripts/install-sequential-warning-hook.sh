#!/bin/bash
# Install commit-msg hook for sequential commit warnings
# This hook provides informational warnings but does NOT block commits

set -e

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
HOOK_SOURCE="$SCRIPT_DIR/commit-msg-sequential-warning.sh"
HOOK_DEST=".git/hooks/commit-msg"

echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
echo "Installing Sequential Commit Warning Hook"
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
echo ""

# Check if hook source exists
if [ ! -f "$HOOK_SOURCE" ]; then
    echo "❌ Error: Hook source not found at $HOOK_SOURCE"
    exit 1
fi

# Backup existing hook if present
if [ -f "$HOOK_DEST" ]; then
    BACKUP="${HOOK_DEST}.backup.$(date +%Y%m%d_%H%M%S)"
    echo "📦 Backing up existing commit-msg hook to:"
    echo "   $BACKUP"
    cp "$HOOK_DEST" "$BACKUP"
    echo ""
fi

# Copy hook
echo "📝 Installing commit-msg hook..."
cp "$HOOK_SOURCE" "$HOOK_DEST"

# Make executable
chmod +x "$HOOK_DEST"
echo "✅ Hook installed and made executable"
echo ""

# Verify installation
if [ -x "$HOOK_DEST" ]; then
    echo "✅ Installation successful!"
    echo ""
    echo "📋 This hook will:"
    echo "   • Warn when adding commits to branches that already have commits"
    echo "   • Suggest creating a new branch for additional changes"
    echo "   • NOT block commits (informational only)"
    echo ""
    echo "🔒 Enforcement still happens via GitHub Actions workflow"
    echo ""
else
    echo "❌ Installation failed - hook is not executable"
    exit 1
fi

echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
