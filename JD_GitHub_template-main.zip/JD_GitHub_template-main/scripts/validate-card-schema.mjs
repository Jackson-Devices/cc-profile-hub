#!/usr/bin/env node

import { readFileSync, readdirSync, statSync } from 'fs';
import { join, dirname } from 'path';
import { fileURLToPath } from 'url';
import Ajv from 'ajv';
import yaml from 'js-yaml';

const __filename = fileURLToPath(import.meta.url);
const __dirname = dirname(__filename);
const rootDir = join(__dirname, '..');

// Load JSON schema
const schemaPath = join(rootDir, 'docs/cards/card-schema.json');
const schema = JSON.parse(readFileSync(schemaPath, 'utf8'));

// Initialize AJV
const ajv = new Ajv({ allErrors: true });
const validate = ajv.compile(schema);

// Extract front-matter from markdown
function extractFrontMatter(content) {
  const frontMatterRegex = /^---\s*\n([\s\S]*?)\n---/;
  const match = content.match(frontMatterRegex);

  if (!match) {
    throw new Error('No front-matter found');
  }

  return yaml.load(match[1]);
}

// Recursively find all .md files
function findMarkdownFiles(dir, fileList = []) {
  const files = readdirSync(dir);

  files.forEach((file) => {
    const filePath = join(dir, file);
    const stat = statSync(filePath);

    if (stat.isDirectory()) {
      findMarkdownFiles(filePath, fileList);
    } else if (file.endsWith('.md') && file !== 'README.md') {
      fileList.push(filePath);
    }
  });

  return fileList;
}

// Main validation
const cardsDir = join(rootDir, 'docs/cards');
const cardFiles = findMarkdownFiles(cardsDir);

let totalCards = 0;
let validCards = 0;
let invalidCards = 0;
const errors = [];

console.log('🔍 Validating documentation cards against schema...\n');

cardFiles.forEach((filePath) => {
  totalCards++;
  const relativePath = filePath.replace(rootDir + '/', '');

  try {
    const content = readFileSync(filePath, 'utf8');
    const frontMatter = extractFrontMatter(content);

    const valid = validate(frontMatter);

    if (valid) {
      validCards++;
      console.log(`✅ ${relativePath}`);
    } else {
      invalidCards++;
      console.log(`❌ ${relativePath}`);
      errors.push({
        file: relativePath,
        errors: validate.errors,
      });
    }
  } catch (err) {
    invalidCards++;
    console.log(`❌ ${relativePath}`);
    errors.push({
      file: relativePath,
      errors: [{ message: err.message }],
    });
  }
});

console.log('\n━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━');
console.log(`📊 Validation Summary`);
console.log(`━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━`);
console.log(`Total cards: ${totalCards}`);
console.log(`Valid: ${validCards}`);
console.log(`Invalid: ${invalidCards}`);

if (errors.length > 0) {
  console.log('\n❌ Validation Errors:\n');
  errors.forEach(({ file, errors }) => {
    console.log(`\n${file}:`);
    errors.forEach((err) => {
      if (err.instancePath) {
        console.log(`  - ${err.instancePath}: ${err.message}`);
      } else {
        console.log(`  - ${err.message}`);
      }
    });
  });
  process.exit(1);
} else {
  console.log('\n✅ All cards pass schema validation!');
  process.exit(0);
}
