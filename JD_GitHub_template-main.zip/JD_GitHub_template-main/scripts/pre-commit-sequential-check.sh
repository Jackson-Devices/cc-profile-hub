#!/bin/bash
# Pre-commit hook to prevent sequential commits on the same branch
#
# This hook checks if the current branch already has commits beyond the base branch.
# If it does, it prevents the commit and instructs the user to create a new branch.
#
# Installation:
#   cp scripts/pre-commit-sequential-check.sh .git/hooks/pre-commit
#   chmod +x .git/hooks/pre-commit

set -e

# Get current branch name
CURRENT_BRANCH=$(git symbolic-ref --short HEAD 2>/dev/null || echo "detached")

# Only check claude/ branches
if [[ ! "$CURRENT_BRANCH" =~ ^claude/ ]]; then
    # Not a claude branch, allow commit
    exit 0
fi

# Get the default branch
DEFAULT_BRANCH=$(git remote show origin 2>/dev/null | grep 'HEAD branch' | cut -d' ' -f5)
if [ -z "$DEFAULT_BRANCH" ]; then
    DEFAULT_BRANCH="main"  # Fallback to main if we can't detect
fi

# Ensure we have the latest remote info
git fetch origin "$DEFAULT_BRANCH" --quiet 2>/dev/null || true

# Count commits on current branch not in default branch
COMMIT_COUNT=$(git rev-list --count origin/${DEFAULT_BRANCH}..HEAD 2>/dev/null || echo "0")

# If there's already 1 or more commits, prevent this new commit
if [ "$COMMIT_COUNT" -ge 1 ]; then
    cat << 'EOF'

❌ COMMIT BLOCKED: Sequential commits not allowed
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

This branch already has commits. Sequential commits are not permitted.

📋 CURRENT STATUS:
EOF
    echo "   • Branch: $CURRENT_BRANCH"
    echo "   • Existing commits: $COMMIT_COUNT"
    cat << 'EOF'

📋 ACTION REQUIRED:
   Create a NEW branch for your additional changes.

🔧 SUGGESTED FIX:
   1. Stash your current changes:
      git stash

   2. Create a new branch (use your session ID):
      git checkout -b claude/your-new-task-<SESSION_ID>

   3. Apply your stashed changes:
      git stash pop

   4. Commit on the new branch:
      git add .
      git commit -m "your commit message"

💡 WHY THIS POLICY EXISTS:
   • Ensures one logical change per branch
   • Makes PR reviews cleaner and more focused
   • Better separation of concerns
   • Easier to rollback individual changes

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

EOF
    exit 1
fi

# First commit on this branch, allow it
exit 0
