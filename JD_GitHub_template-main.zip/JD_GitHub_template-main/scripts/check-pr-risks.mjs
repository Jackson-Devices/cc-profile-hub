#!/usr/bin/env node

import { readFileSync } from 'fs';
import { Octokit } from '@octokit/core';
import { paginateRest } from '@octokit/plugin-paginate-rest';

const MyOctokit = Octokit.plugin(paginateRest);

// Configuration: Risky patterns to detect
const PATTERNS = {
  // High-risk patterns (blocking)
  DEBUGGER: {
    regex: /\bdebugger\b/g,
    level: 'error',
    message: 'Debugger statement found (likely debug code)',
  },
  CONSOLE_LOG: {
    regex: /console\.(log|debug|info)\(/g,
    level: 'error',
    message: 'Console log statement found (likely debug code)',
    // Whitelist: workflow files use console.log for intentional logging to GitHub Actions
    // Documentation files contain console.log in code examples
    excludePattern: /^\.github\/workflows\/.*\.yml$|\.md$/,
  },
  TEST_ONLY: {
    regex: /\.(only|skip)\(/g,
    level: 'error',
    message: 'Test .only() or .skip() found (prevents full test suite)',
    filePattern: /test|spec/i,
  },

  // Medium-risk patterns (warnings)
  TODO: {
    regex: /\b(TODO|FIXME|XXX|HACK)\b/g,
    level: 'warning',
    message: 'TODO/FIXME comment found',
  },
  CONSOLE_WARN_ERROR: {
    regex: /console\.(warn|error)\(/g,
    level: 'warning',
    message: 'Console warn/error found (may be intentional)',
  },
};

const LARGE_FILE_THRESHOLD = 500; // lines changed

/**
 * Parse GitHub event payload
 */
function getEventData() {
  const eventPath = process.env.GITHUB_EVENT_PATH;
  if (!eventPath) {
    console.error('❌ GITHUB_EVENT_PATH not found');
    process.exit(1);
  }

  try {
    const eventData = JSON.parse(readFileSync(eventPath, 'utf8'));
    return {
      prNumber: eventData.pull_request?.number,
      owner: eventData.repository?.owner?.login,
      repo: eventData.repository?.name,
      baseRef: eventData.pull_request?.base?.ref,
      headRef: eventData.pull_request?.head?.ref,
    };
  } catch (err) {
    console.error('❌ Failed to parse GitHub event:', err.message);
    process.exit(1);
  }
}

/**
 * Get PR files and their diffs
 */
async function getPRFiles(octokit, owner, repo, prNumber) {
  try {
    const { data: files } = await octokit.request(
      'GET /repos/{owner}/{repo}/pulls/{pull_number}/files',
      {
        owner,
        repo,
        pull_number: prNumber,
        per_page: 100,
      }
    );

    return files;
  } catch (err) {
    console.error('❌ Failed to fetch PR files:', err.message);
    process.exit(1);
  }
}

/**
 * Check for risky patterns in diff
 */
function checkPatterns(files) {
  const findings = {
    errors: [],
    warnings: [],
    info: [],
  };

  for (const file of files) {
    const { filename, patch, additions, deletions, status } = file;

    // Skip deleted files
    if (status === 'removed' || !patch) continue;

    // Check large file changes
    const totalChanges = additions + deletions;
    if (totalChanges > LARGE_FILE_THRESHOLD) {
      findings.warnings.push({
        file: filename,
        pattern: 'LARGE_FILE',
        message: `Large file change: ${totalChanges} lines (${additions}+ ${deletions}-)`,
        line: null,
      });
    }

    // Check each pattern
    for (const [patternName, config] of Object.entries(PATTERNS)) {
      // Skip if file pattern doesn't match (for test-specific patterns)
      if (config.filePattern && !config.filePattern.test(filename)) {
        continue;
      }

      // Skip if file is explicitly excluded (whitelist)
      if (config.excludePattern && config.excludePattern.test(filename)) {
        continue;
      }

      // Find matches in the diff (only added lines)
      const addedLines = patch
        .split('\n')
        .filter((line) => line.startsWith('+') && !line.startsWith('+++'));

      addedLines.forEach((line) => {
        const matches = line.match(config.regex);
        if (matches) {
          const finding = {
            file: filename,
            pattern: patternName,
            message: config.message,
            line: line.trim().substring(1).trim(), // Remove leading '+'
            match: matches[0],
          };

          if (config.level === 'error') {
            findings.errors.push(finding);
          } else if (config.level === 'warning') {
            findings.warnings.push(finding);
          } else {
            findings.info.push(finding);
          }
        }
      });
    }
  }

  return findings;
}

/**
 * Check if tests are missing when code changes
 */
function checkMissingTests(files) {
  const codeFiles = files.filter(
    (f) =>
      (f.filename.endsWith('.js') || f.filename.endsWith('.mjs') || f.filename.endsWith('.ts')) &&
      !f.filename.includes('test') &&
      !f.filename.includes('spec') &&
      f.status !== 'removed'
  );

  const testFiles = files.filter(
    (f) => (f.filename.includes('test') || f.filename.includes('spec')) && f.status !== 'removed'
  );

  if (codeFiles.length > 0 && testFiles.length === 0) {
    return {
      warning: true,
      message: `Code files changed (${codeFiles.length}) but no test files modified`,
      codeFiles: codeFiles.map((f) => f.filename),
    };
  }

  return { warning: false };
}

/**
 * Print report
 */
function printReport(findings, missingTests) {
  console.log('\n🔍 PR Risk Detection Report');
  console.log('━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n');

  // Errors (blocking)
  if (findings.errors.length > 0) {
    console.log('❌ ERRORS (blocking):');
    findings.errors.forEach(({ file, pattern, message, line, match }) => {
      console.log(`  ${file}`);
      console.log(`    Pattern: ${pattern}`);
      console.log(`    Message: ${message}`);
      console.log(`    Match: "${match}"`);
      console.log(`    Line: ${line}`);
      console.log();
    });
  }

  // Warnings
  if (findings.warnings.length > 0) {
    console.log('⚠️  WARNINGS:');
    findings.warnings.forEach(({ file, pattern, message, line, match }) => {
      console.log(`  ${file}`);
      console.log(`    Pattern: ${pattern}`);
      console.log(`    Message: ${message}`);
      if (match) console.log(`    Match: "${match}"`);
      if (line) console.log(`    Line: ${line}`);
      console.log();
    });
  }

  // Missing tests warning
  if (missingTests.warning) {
    console.log('⚠️  WARNINGS:');
    console.log(`  ${missingTests.message}`);
    console.log(`  Changed files: ${missingTests.codeFiles.join(', ')}`);
    console.log();
  }

  // Summary
  console.log('━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━');
  console.log('📊 Summary:');
  console.log(`  Errors: ${findings.errors.length}`);
  console.log(`  Warnings: ${findings.warnings.length}`);

  if (findings.errors.length === 0 && findings.warnings.length === 0) {
    console.log('\n✅ No risky patterns detected!');
  }

  console.log('━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n');
}

/**
 * Main execution
 */
async function main() {
  const startTime = Date.now();

  console.log('🚀 Starting PR risk detection...\n');

  // Get event data
  const { prNumber, owner, repo } = getEventData();

  if (!prNumber || !owner || !repo) {
    console.error('❌ Missing required PR information');
    process.exit(1);
  }

  console.log(`📋 Analyzing PR #${prNumber} in ${owner}/${repo}\n`);

  // Initialize Octokit
  const token = process.env.GITHUB_TOKEN;
  if (!token) {
    console.error('❌ GITHUB_TOKEN not found');
    process.exit(1);
  }

  const octokit = new MyOctokit({ auth: token });

  // Get PR files
  console.log('📥 Fetching PR files...');
  const files = await getPRFiles(octokit, owner, repo, prNumber);
  console.log(`   Found ${files.length} files\n`);

  // Check patterns
  console.log('🔎 Checking for risky patterns...');
  const findings = checkPatterns(files);

  // Check missing tests
  const missingTests = checkMissingTests(files);

  // Print report
  printReport(findings, missingTests);

  // Execution time
  const duration = ((Date.now() - startTime) / 1000).toFixed(2);
  console.log(`⏱️  Completed in ${duration}s\n`);

  // Set GitHub Actions outputs if running in CI
  const hasWarnings = findings.warnings.length > 0 || missingTests.warning;
  const hasErrors = findings.errors.length > 0;

  if (process.env.GITHUB_OUTPUT) {
    const fs = await import('fs');

    // Create detailed error summary
    let errorSummary = '';
    if (hasErrors) {
      errorSummary = findings.errors
        .map(
          ({ file, pattern, message, line, match }) =>
            `${file} | ${pattern}: ${message} | Match: "${match}" | Line: ${line}`
        )
        .join('\\n');
    }

    fs.appendFileSync(
      process.env.GITHUB_OUTPUT,
      `has_warnings=${hasWarnings}\nhas_issues=${hasErrors}\nerror_summary<<EOF\n${errorSummary}\nEOF\n`
    );
  }

  // Exit with appropriate code
  if (hasErrors) {
    console.log('❌ PR contains blocking issues. Please fix before merging.');
    process.exit(1);
  }

  if (hasWarnings) {
    console.log('✅ No blocking issues, but warnings present. Review recommended.');
  } else {
    console.log('✅ All checks passed!');
  }

  process.exit(0);
}

main();
