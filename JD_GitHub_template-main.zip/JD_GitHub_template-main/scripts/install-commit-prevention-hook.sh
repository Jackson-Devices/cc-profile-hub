#!/bin/bash
# Installation script for the sequential commit prevention hook
#
# Usage:
#   ./scripts/install-commit-prevention-hook.sh

set -e

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
HOOK_SOURCE="${SCRIPT_DIR}/pre-commit-sequential-check.sh"
HOOK_DEST=".git/hooks/pre-commit"

echo "🔧 Installing Sequential Commit Prevention Hook"
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"

# Check if .git directory exists
if [ ! -d ".git" ]; then
    echo "❌ Error: Not in a git repository root"
    echo "   Please run this script from the repository root"
    exit 1
fi

# Check if hook source exists
if [ ! -f "$HOOK_SOURCE" ]; then
    echo "❌ Error: Hook source not found at $HOOK_SOURCE"
    exit 1
fi

# Backup existing pre-commit hook if it exists
if [ -f "$HOOK_DEST" ]; then
    BACKUP="${HOOK_DEST}.backup.$(date +%Y%m%d_%H%M%S)"
    echo "📦 Backing up existing pre-commit hook to: ${BACKUP}"
    cp "$HOOK_DEST" "$BACKUP"
fi

# Copy and install the hook
echo "📋 Installing hook to: $HOOK_DEST"
cp "$HOOK_SOURCE" "$HOOK_DEST"
chmod +x "$HOOK_DEST"

echo ""
echo "✅ Installation complete!"
echo ""
echo "📋 What this hook does:"
echo "   • Prevents sequential commits on claude/ branches"
echo "   • Forces creation of new branches for new work"
echo "   • Provides helpful error messages and instructions"
echo ""
echo "🔧 To uninstall:"
echo "   rm .git/hooks/pre-commit"
echo ""
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
