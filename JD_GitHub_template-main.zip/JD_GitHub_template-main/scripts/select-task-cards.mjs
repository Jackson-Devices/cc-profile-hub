#!/usr/bin/env node

import { readFileSync } from 'fs';
import { join, dirname } from 'path';
import { fileURLToPath } from 'url';
import yaml from 'js-yaml';

const __filename = fileURLToPath(import.meta.url);
const __dirname = dirname(__filename);
const rootDir = join(__dirname, '..');

// Load tasks map
const tasksMapPath = join(rootDir, 'docs/tasks.map.yaml');
const tasksMap = yaml.load(readFileSync(tasksMapPath, 'utf8'));

// Extract front-matter from markdown
function extractFrontMatter(content) {
  const frontMatterRegex = /^---\s*\n([\s\S]*?)\n---/;
  const match = content.match(frontMatterRegex);

  if (!match) {
    throw new Error('No front-matter found');
  }

  return yaml.load(match[1]);
}

// Load card metadata
function loadCard(cardId) {
  const cardPath = join(rootDir, 'docs/cards', `${cardId}.md`);
  try {
    const content = readFileSync(cardPath, 'utf8');
    const frontMatter = extractFrontMatter(content);
    return {
      id: cardId,
      ...frontMatter,
      path: cardPath,
    };
  } catch (err) {
    throw new Error(`Failed to load card ${cardId}: ${err.message}`);
  }
}

// Calculate bundle tokens
function calculateBundleTokens(cards) {
  const FRONTMATTER_OVERHEAD = 50; // tokens per card
  let total = 0;

  cards.forEach((card) => {
    total += card.tokens_estimate + FRONTMATTER_OVERHEAD;
  });

  return total;
}

// Generate subtopic menu for overflow
function generateSubtopicMenu(task, cards, totalTokens, budget) {
  const overrun = totalTokens - budget;

  console.log(`\n⚠️  Selected cards exceed budget (${totalTokens} / ${budget} tokens)`);
  console.log(`    Overrun: ${overrun} tokens\n`);
  console.log(`Available options:`);
  console.log(`  1. Accept full bundle (${totalTokens} tokens)`);
  console.log(`  2. Increase budget for this task`);
  console.log(`  3. Select specific cards to exclude:\n`);

  cards.forEach((card, index) => {
    const savings = card.tokens_estimate + 50;
    console.log(
      `     [${index + 1}] Exclude ${card.id} (save ${savings} tokens) - "${card.title}"`
    );
  });
}

// Select task cards
function selectTaskCards(taskId) {
  const task = tasksMap.tasks[taskId];

  if (!task) {
    console.error(`❌ Task not found: ${taskId}`);
    console.log('\nAvailable tasks:');
    Object.keys(tasksMap.tasks).forEach((id) => {
      console.log(`  - ${id}: ${tasksMap.tasks[id].description}`);
    });
    process.exit(1);
  }

  console.log(`\n📋 Task: ${taskId}`);
  console.log(`Description: ${task.description}`);
  console.log(`Audience: ${task.audience}`);
  console.log(`Budget: ${task.bundle_budget_tokens} tokens\n`);

  // Load cards
  const cards = [];
  task.sequence.forEach((ref) => {
    try {
      const card = loadCard(ref.id);
      cards.push(card);
    } catch (err) {
      console.error(`❌ ${err.message}`);
      process.exit(1);
    }
  });

  // Display card sequence
  console.log(`Card Sequence (${cards.length} cards):`);
  cards.forEach((card, index) => {
    console.log(`  ${index + 1}. ${card.id} (${card.tokens_estimate} tokens) - "${card.title}"`);
  });

  // Calculate total tokens
  const totalTokens = calculateBundleTokens(cards);
  console.log(`\n📊 Token Budget Analysis:`);
  console.log(`  Total estimated: ${totalTokens} tokens`);
  console.log(`  Budget limit: ${task.bundle_budget_tokens} tokens`);

  if (totalTokens <= task.bundle_budget_tokens) {
    const remaining = task.bundle_budget_tokens - totalTokens;
    console.log(`  Status: ✅ Within budget (${remaining} tokens remaining)`);
  } else {
    console.log(`  Status: ⚠️  Over budget`);
    generateSubtopicMenu(task, cards, totalTokens, task.bundle_budget_tokens);
  }

  return {
    task,
    cards,
    totalTokens,
    withinBudget: totalTokens <= task.bundle_budget_tokens,
  };
}

// Main CLI
const args = process.argv.slice(2);

if (args.length === 0 || args[0] === '--help') {
  console.log(`
Usage: npm run select-task <task-id>

Selects documentation cards for a task and validates token budget.

Available tasks:
`);
  Object.keys(tasksMap.tasks).forEach((id) => {
    console.log(`  ${id}`);
    console.log(`    ${tasksMap.tasks[id].description}`);
  });
  process.exit(0);
}

const taskId = args[0];
selectTaskCards(taskId);
