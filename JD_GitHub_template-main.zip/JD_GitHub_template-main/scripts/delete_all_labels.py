#!/usr/bin/env python3
"""Delete all labels from the repository using GitHub API"""

import subprocess
import json
import urllib.parse

def get_all_labels():
    """Get all label names from the repository"""
    result = subprocess.run(
        ['gh', 'api', 'repos/Jackson-Devices/JD_GitHub_template/labels', '--paginate', '--jq', '.[].name'],
        capture_output=True,
        text=True
    )
    return [line.strip() for line in result.stdout.strip().split('\n') if line.strip()]

def delete_label(label_name):
    """Delete a single label"""
    encoded = urllib.parse.quote(label_name, safe='')
    print(f"Deleting: {label_name} (encoded: {encoded})")
    try:
        subprocess.run(
            ['gh', 'api', '-X', 'DELETE', f'repos/Jackson-Devices/JD_GitHub_template/labels/{encoded}'],
            check=True,
            capture_output=True
        )
        print(f"  ✓ Deleted: {label_name}")
        return True
    except subprocess.CalledProcessError as e:
        print(f"  ✗ Failed: {label_name} - {e.stderr.decode() if e.stderr else 'Unknown error'}")
        return False

def main():
    print("=" * 60)
    print("GitHub Label Deletion Script")
    print("=" * 60)
    print()

    labels = get_all_labels()
    print(f"Found {len(labels)} labels to delete\n")

    deleted = 0
    failed = 0

    for label in labels:
        if delete_label(label):
            deleted += 1
        else:
            failed += 1

    print()
    print("=" * 60)
    print(f"Summary: {deleted} deleted, {failed} failed")
    print("=" * 60)

    if failed > 0:
        return 1
    return 0

if __name__ == '__main__':
    exit(main())
