#!/usr/bin/env node
/* eslint-disable n/no-unsupported-features/node-builtins */

/**
 * Smart Sequential Commits Checker
 *
 * This script analyzes commits on a branch and determines if additional commits
 * are legitimate fixes for previous failures or if they should be on a new branch.
 *
 * It checks:
 * 1. Are there multiple commits?
 * 2. Did previous commits have CI/gate failures?
 * 3. Do new commits appear to be fixes (based on commit message patterns)?
 * 4. Should we auto-squash or warn the user?
 */

import { execSync } from 'child_process';
import { exit } from 'process';

const GITHUB_TOKEN = process.env.GITHUB_TOKEN;
const REPO = process.env.GITHUB_REPOSITORY;
const CURRENT_BRANCH = process.env.GITHUB_REF_NAME;

// Patterns that indicate a fix commit
const FIX_PATTERNS = [
  /^fix:/i,
  /^style:/i,
  /^chore:/i,
  /fix.*error/i,
  /fix.*failure/i,
  /fix.*issue/i,
  /resolve.*conflict/i,
  /satisfy.*shellcheck/i,
  /satisfy.*lint/i,
  /add.*quote/i,
  /format/i,
];

function exec(command) {
  try {
    return execSync(command, { encoding: 'utf8' }).trim();
  } catch {
    return '';
  }
}

function getCommitCount(baseBranch) {
  const count = exec(`git rev-list --count origin/${baseBranch}..HEAD`);
  return parseInt(count, 10) || 0;
}

function getCommitMessages(baseBranch) {
  // Only get SHA and subject to avoid multi-line body parsing issues
  const messages = exec(`git log --format="%H|%s" origin/${baseBranch}..HEAD`);
  if (!messages) return [];

  return messages.split('\n').map((line) => {
    const [sha, subject] = line.split('|');
    return { sha, subject: subject || '' };
  });
}

function isFixCommit(commitMessage) {
  return FIX_PATTERNS.some((pattern) => pattern.test(commitMessage));
}

async function checkPreviousCommitStatus(commitSha) {
  if (!GITHUB_TOKEN || !REPO) {
    console.log('⚠️  Cannot check CI status - missing GITHUB_TOKEN or GITHUB_REPOSITORY');
    return null;
  }

  try {
    const response = await fetch(
      `https://api.github.com/repos/${REPO}/commits/${commitSha}/status`,
      {
        headers: {
          Authorization: `Bearer ${GITHUB_TOKEN}`,
          Accept: 'application/vnd.github.v3+json',
        },
      }
    );

    if (!response.ok) {
      console.log(`⚠️  Could not fetch status for ${commitSha}: ${response.status}`);
      return null;
    }

    const data = await response.json();
    return data.state; // 'pending', 'success', 'failure', 'error'
  } catch (_error) {
    console.log(`⚠️  Error checking commit status: ${_error.message}`);
    return null;
  }
}

async function analyzeCommits() {
  console.log('🔍 Analyzing commit history...\n');

  const defaultBranch =
    exec('git remote show origin | grep "HEAD branch" | cut -d" " -f5') || 'main';
  console.log(`📍 Base branch: ${defaultBranch}`);
  console.log(`📍 Current branch: ${CURRENT_BRANCH}\n`);

  const commitCount = getCommitCount(defaultBranch);
  console.log(`📊 Total commits on this branch: ${commitCount}\n`);

  if (commitCount <= 1) {
    console.log('✅ Single commit - no analysis needed\n');
    return { allowed: true, reason: 'single_commit' };
  }

  const commits = getCommitMessages(defaultBranch);
  console.log('📋 Commits on this branch:');
  console.log('━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━');

  for (let i = 0; i < commits.length; i++) {
    const commit = commits[i];
    const isLatest = i === commits.length - 1;
    const isFix = isFixCommit(commit.subject);

    console.log(`${i + 1}. ${commit.sha.substring(0, 7)} - ${commit.subject}`);
    console.log(
      `   ${isLatest ? '→ CURRENT' : '  '} ${isFix ? '[FIX COMMIT]' : '[FEATURE COMMIT]'}`
    );
  }

  console.log('━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n');

  // Check if there are previous commits (excluding the latest)
  const previousCommits = commits.slice(0, -1);
  const latestCommit = commits[commits.length - 1];

  // Check if the latest commit is a fix
  const latestIsFix = isFixCommit(latestCommit.subject);

  if (previousCommits.length === 0) {
    return { allowed: true, reason: 'first_commit' };
  }

  // Check status of previous commits
  console.log('🔍 Checking CI status of previous commits...\n');

  let hasPreviousFailures = false;
  let statusChecksFailed = false;
  for (const commit of previousCommits) {
    const status = await checkPreviousCommitStatus(commit.sha);
    console.log(`   ${commit.sha.substring(0, 7)}: ${status || 'unknown'}`);

    if (status === 'failure' || status === 'error') {
      hasPreviousFailures = true;
    }
    if (status === null) {
      statusChecksFailed = true;
    }
  }

  console.log('');

  // If we couldn't check status, be lenient - assume failures may have occurred
  if (statusChecksFailed && previousCommits.length > 0) {
    console.log('⚠️  Could not verify all commit statuses via GitHub API');
    console.log('💡 Being lenient - assuming previous commits may have had failures\n');
    hasPreviousFailures = true;
  }

  // Decision logic
  if (latestIsFix && hasPreviousFailures) {
    console.log('✅ ALLOWED: Latest commit appears to be fixing previous failures\n');
    console.log('💡 Recommendation: Consider using auto-squash workflow to combine commits');
    return {
      allowed: true,
      reason: 'fix_for_failures',
      suggestSquash: true,
    };
  }

  if (latestIsFix && !hasPreviousFailures) {
    console.log('⚠️  WARNING: Latest commit is a fix, but no failures detected\n');
    console.log('💡 This might be a legitimate fix or style update');
    console.log('💡 Consider using auto-squash workflow to maintain clean history');
    return {
      allowed: true,
      reason: 'fix_commit_no_failures',
      suggestSquash: true,
    };
  }

  // Multiple feature commits - trigger intelligent splitting
  console.log('❌ BLOCKED: Multiple feature commits detected\n');
  console.log('📋 AUTO-REMEDIATION AVAILABLE:');
  console.log('   This branch has multiple feature commits.');
  console.log('   The intelligent commit splitter can analyze and reorganize them.\n');
  console.log('💡 Automated Options:');
  console.log('   1. Run split-commits-intelligently.mjs to analyze file changes');
  console.log('   2. Auto-squash workflow will combine if all changes are related');
  console.log('   3. Manual option: Create a new branch for unrelated changes');
  console.log('');

  return {
    allowed: false,
    reason: 'multiple_features',
    suggestSplit: true,
  };
}

// Main execution
(async () => {
  console.log('━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━');
  console.log('🔍 Smart Sequential Commits Analysis');
  console.log('━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n');

  const result = await analyzeCommits();

  console.log('━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━');
  console.log(`Result: ${result.allowed ? '✅ PASS' : '❌ FAIL'}`);
  console.log(`Reason: ${result.reason}`);
  if (result.suggestSquash) {
    console.log('Suggestion: Run auto-squash workflow');
  }
  console.log('━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━');

  exit(result.allowed ? 0 : 1);
})();
