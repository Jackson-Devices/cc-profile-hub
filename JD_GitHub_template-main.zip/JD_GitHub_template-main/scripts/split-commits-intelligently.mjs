#!/usr/bin/env node

/**
 * Intelligent Commit Splitter
 *
 * Analyzes commit history using file diffs and semantic understanding
 * to determine if commits should be squashed or split across branches.
 *
 * Exit Codes:
 *   0 - Success (no action needed or auto-remediation applied)
 *   1 - Needs squash (related commits should be combined)
 *   2 - Needs split (unrelated features should be on separate branches)
 *   3 - Error (analysis failed)
 *
 * Flags:
 *   --dry-run: Run analysis without making any changes
 *   --verbose: Show detailed debug information
 *
 * Safety Features:
 *   - Validates git repository state before analysis
 *   - Never modifies commits (read-only analysis)
 *   - Handles errors gracefully
 *   - Validates all git commands
 */

import { execSync } from 'child_process';
import { exit } from 'process';

// Parse command line arguments
const args = process.argv.slice(2);
const DRY_RUN = args.includes('--dry-run');
const VERBOSE = args.includes('--verbose');

// Configuration
const SIMILARITY_THRESHOLD = 0.6; // 60% similarity to group commits
const LARGE_CHANGE_THRESHOLD = 1000; // Lines changed

// Exit codes
const EXIT_SUCCESS = 0;
const EXIT_NEEDS_SQUASH = 1;
const EXIT_NEEDS_SPLIT = 2;
const EXIT_ERROR = 3;

// Protected branches that should never be analyzed
const PROTECTED_BRANCHES = ['main', 'master', 'develop', 'production'];

function exec(command) {
  try {
    return execSync(command, { encoding: 'utf8' }).trim();
  } catch (error) {
    if (VERBOSE) {
      console.error(`Command failed: ${command}`);
      console.error(error.message);
    }
    return '';
  }
}

// Safety validation functions
function validateGitRepository() {
  const isGitRepo = exec('git rev-parse --git-dir');
  if (!isGitRepo) {
    console.error('❌ ERROR: Not a git repository');
    console.error('   This script must be run from within a git repository');
    return false;
  }
  return true;
}

function validateNotProtectedBranch() {
  const currentBranch = exec('git rev-parse --abbrev-ref HEAD');
  if (PROTECTED_BRANCHES.includes(currentBranch)) {
    console.error(`❌ ERROR: Cannot analyze protected branch: ${currentBranch}`);
    console.error('   This script should not be run on protected branches');
    console.error(`   Protected branches: ${PROTECTED_BRANCHES.join(', ')}`);
    return false;
  }
  return true;
}

function validateCleanWorkingTree() {
  const status = exec('git status --porcelain');
  if (status && status.length > 0) {
    console.warn('⚠️  WARNING: Working tree has uncommitted changes');
    console.warn('   Analysis will proceed but results may be affected');
    if (VERBOSE) {
      console.warn('   Uncommitted changes:');
      console.warn(status);
    }
  }
  return true; // Just a warning, not a blocker
}

function validateRemoteExists() {
  const remote = exec('git remote');
  if (!remote) {
    console.warn('⚠️  WARNING: No remote repository configured');
    console.warn('   Some features may not work correctly');
  }
  return true; // Just a warning
}

function runSafetyChecks() {
  console.log('🔒 Running safety checks...\n');

  if (!validateGitRepository()) {
    return false;
  }

  if (!validateNotProtectedBranch()) {
    return false;
  }

  validateCleanWorkingTree();
  validateRemoteExists();

  console.log('✅ Safety checks passed\n');
  return true;
}

function getBaseBranch() {
  // Step 1: Try to find the upstream tracking branch
  const upstream = exec('git rev-parse --abbrev-ref --symbolic-full-name @{u} 2>/dev/null');
  if (upstream) {
    // Extract branch name from refs/remotes/origin/branch-name
    const match = upstream.match(/^(?:refs\/remotes\/)?(?:origin\/)?(.+)$/);
    if (match) {
      const baseBranch = match[1];
      if (VERBOSE) {
        console.log(`   Detected upstream tracking branch: ${baseBranch}`);
      }
      return baseBranch;
    }
  }

  // Step 2: Try to find merge base with common branches
  const currentBranch = exec('git rev-parse --abbrev-ref HEAD');
  const commonBases = ['main', 'master', 'develop', 'development'];

  for (const base of commonBases) {
    // Check if branch exists locally or remotely
    const localExists = exec(`git rev-parse --verify ${base} 2>/dev/null`);
    const remoteExists = exec(`git rev-parse --verify origin/${base} 2>/dev/null`);

    if (localExists || remoteExists) {
      const branchRef = remoteExists ? `origin/${base}` : base;
      // Check if we can find a merge base
      const mergeBase = exec(`git merge-base HEAD ${branchRef} 2>/dev/null`);
      if (mergeBase) {
        if (VERBOSE) {
          console.log(`   Found merge base with ${base}: ${mergeBase.substring(0, 7)}`);
        }
        return base;
      }
    }
  }

  // Step 3: Try to get default branch from remote
  const remoteBranch = exec('git remote show origin 2>/dev/null | grep "HEAD branch" | cut -d" " -f5');
  if (remoteBranch) {
    if (VERBOSE) {
      console.log(`   Using remote default branch: ${remoteBranch}`);
    }
    return remoteBranch;
  }

  // Step 4: Fallback - check what branches exist
  const branches = exec('git branch --format="%(refname:short)"').split('\n').filter(Boolean);
  for (const base of commonBases) {
    if (branches.includes(base) && base !== currentBranch) {
      if (VERBOSE) {
        console.log(`   Falling back to local branch: ${base}`);
      }
      return base;
    }
  }

  // Final fallback
  console.warn('⚠️  WARNING: Could not determine base branch, defaulting to "main"');
  console.warn('   Set upstream with: git branch --set-upstream-to=origin/BRANCH');
  return 'main';
}

function getCommitCount(baseBranch) {
  // Try with remote first
  let count = exec(`git rev-list --count origin/${baseBranch}..HEAD 2>/dev/null`);

  // Fallback to local base branch if no remote
  if (!count) {
    count = exec(`git rev-list --count ${baseBranch}..HEAD`);
  }

  return parseInt(count, 10) || 0;
}

function getCommitShas(baseBranch) {
  // Try with remote first
  let shas = exec(`git log --format="%H" origin/${baseBranch}..HEAD 2>/dev/null`);

  // Fallback to local base branch if no remote
  if (!shas) {
    shas = exec(`git log --format="%H" ${baseBranch}..HEAD`);
  }

  return shas ? shas.split('\n').reverse() : [];
}

function getCommitMessage(sha) {
  return exec(`git log --format="%s" -n 1 ${sha}`);
}

function getCommitDiff(sha) {
  // Get diff stats: files changed, insertions, deletions
  const stats = exec(`git show --stat --format="" ${sha}`);
  const files = [];
  let insertions = 0;
  let deletions = 0;

  if (stats) {
    const lines = stats.split('\n').filter((l) => l.trim());
    for (const line of lines) {
      // Parse lines like: " src/file.js | 10 ++++------"
      const match = line.match(/^\s*(.+?)\s*\|\s*(\d+)\s*([+-]+)?/);
      if (match) {
        const [, file] = match;
        files.push(file.trim());

        // Count + and - symbols
        const symbols = match[3] || '';
        const plus = (symbols.match(/\+/g) || []).length;
        const minus = (symbols.match(/-/g) || []).length;
        insertions += plus;
        deletions += minus;
      }
    }

    // Also parse summary line: "2 files changed, 10 insertions(+), 5 deletions(-)"
    const summaryMatch = stats.match(
      /(\d+) insertion[s]?\(\+\)|(\d+) deletion[s]?\(-\)/g
    );
    if (summaryMatch) {
      summaryMatch.forEach((m) => {
        const num = parseInt(m.match(/\d+/)[0], 10);
        if (m.includes('insertion')) insertions = Math.max(insertions, num);
        if (m.includes('deletion')) deletions = Math.max(deletions, num);
      });
    }
  }

  return { files, insertions, deletions };
}

function parseCommitType(message) {
  // Extract conventional commit type and scope
  const match = message.match(/^(\w+)(?:\(([^)]+)\))?:\s*(.+)/);
  if (match) {
    const [, type, scope, description] = match;
    return {
      type: type.toLowerCase(),
      scope: scope || null,
      description,
      isConventional: true,
    };
  }

  // Try to detect type from message content
  const lowerMsg = message.toLowerCase();
  if (lowerMsg.startsWith('merge')) {
    return { type: 'merge', scope: null, description: message, isConventional: false };
  }
  if (lowerMsg.includes('fix')) {
    return { type: 'fix', scope: null, description: message, isConventional: false };
  }
  if (lowerMsg.includes('add') || lowerMsg.includes('implement')) {
    return { type: 'feat', scope: null, description: message, isConventional: false };
  }

  return {
    type: 'unknown',
    scope: null,
    description: message,
    isConventional: false,
  };
}

function extractFeatureArea(files) {
  // Determine primary feature area from file paths
  const areas = new Map();

  files.forEach((file) => {
    const parts = file.split('/');

    // Skip single-level files (like README.md)
    if (parts.length < 2) {
      areas.set('root', (areas.get('root') || 0) + 1);
      return;
    }

    // For deeper paths, use first 2-3 meaningful parts
    let area = parts.slice(0, Math.min(3, parts.length - 1)).join('/');

    // Special handling for common patterns
    if (file.includes('test')) area = `tests/${parts[1] || 'general'}`;
    if (file.endsWith('.md') || file.startsWith('docs/'))
      area = 'documentation';
    if (file.startsWith('.github/')) area = 'ci-cd';

    areas.set(area, (areas.get(area) || 0) + 1);
  });

  // Return most common area
  let maxCount = 0;
  let primaryArea = 'unknown';
  for (const [area, count] of areas) {
    if (count > maxCount) {
      maxCount = count;
      primaryArea = area;
    }
  }

  return { primaryArea, areas: Array.from(areas.keys()) };
}

function calculateSimilarity(commit1, commit2) {
  let score = 0;

  // Factor 1: Same commit type (30%)
  if (commit1.type === commit2.type) {
    score += 0.3;
  }

  // Factor 2: Same or related scope (20%)
  if (commit1.scope && commit2.scope && commit1.scope === commit2.scope) {
    score += 0.2;
  } else if (
    commit1.scope &&
    commit2.scope &&
    (commit1.scope.includes(commit2.scope) ||
      commit2.scope.includes(commit1.scope))
  ) {
    score += 0.1;
  }

  // Factor 3: Overlapping feature areas (40%)
  const areas1 = new Set(commit1.featureAreas);
  const areas2 = new Set(commit2.featureAreas);
  const intersection = new Set([...areas1].filter((x) => areas2.has(x)));
  const union = new Set([...areas1, ...areas2]);

  if (union.size > 0) {
    const areaOverlap = intersection.size / union.size;
    score += areaOverlap * 0.4;
  }

  // Factor 4: File overlap (10%)
  const files1 = new Set(commit1.files);
  const files2 = new Set(commit2.files);
  const fileIntersection = new Set([...files1].filter((x) => files2.has(x)));
  const fileUnion = new Set([...files1, ...files2]);

  if (fileUnion.size > 0) {
    const fileOverlap = fileIntersection.size / fileUnion.size;
    score += fileOverlap * 0.1;
  }

  return score;
}

function groupCommits(commits) {
  if (commits.length <= 1) return [commits];

  const groups = [];
  const assigned = new Set();

  for (let i = 0; i < commits.length; i++) {
    if (assigned.has(i)) continue;

    const group = [commits[i]];
    assigned.add(i);

    for (let j = i + 1; j < commits.length; j++) {
      if (assigned.has(j)) continue;

      // Check similarity with all commits in current group
      const similarities = group.map((c) =>
        calculateSimilarity(c, commits[j])
      );
      const avgSimilarity =
        similarities.reduce((a, b) => a + b, 0) / similarities.length;

      if (avgSimilarity >= SIMILARITY_THRESHOLD) {
        group.push(commits[j]);
        assigned.add(j);
      }
    }

    groups.push(group);
  }

  return groups;
}

function analyzeCommits(baseBranch) {
  console.log('━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━');
  console.log('🧠 Intelligent Commit Analysis');
  console.log('━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n');

  const currentBranch = exec('git rev-parse --abbrev-ref HEAD');
  console.log(`📍 Current branch: ${currentBranch}`);
  console.log(`📍 Base branch: ${baseBranch}\n`);

  const commitCount = getCommitCount(baseBranch);
  console.log(`📊 Total commits to analyze: ${commitCount}\n`);

  if (commitCount <= 1) {
    console.log('✅ Single commit - no analysis needed\n');
    return { action: 'no_action', reason: 'single_commit', exitCode: EXIT_SUCCESS };
  }

  const shas = getCommitShas(baseBranch);
  const commits = [];

  console.log('📋 Analyzing commit details:\n');

  for (const sha of shas) {
    const message = getCommitMessage(sha);
    const parsed = parseCommitType(message);
    const diff = getCommitDiff(sha);
    const { primaryArea, areas } = extractFeatureArea(diff.files);

    const commit = {
      sha,
      shortSha: sha.substring(0, 7),
      message,
      ...parsed,
      ...diff,
      primaryArea,
      featureAreas: areas,
      changeSize: diff.insertions + diff.deletions,
    };

    commits.push(commit);

    console.log(`  ${commit.shortSha} [${commit.type}] ${commit.description}`);
    console.log(`    📁 Area: ${primaryArea}`);
    console.log(`    📝 Files: ${diff.files.length}, Changes: +${diff.insertions}/-${diff.deletions}`);
    console.log('');
  }

  // Skip merge commits
  const nonMergeCommits = commits.filter((c) => c.type !== 'merge');
  if (nonMergeCommits.length !== commits.length) {
    console.log(`ℹ️  Skipping ${commits.length - nonMergeCommits.length} merge commit(s)\n`);
  }

  if (nonMergeCommits.length <= 1) {
    return { action: 'no_action', reason: 'single_commit_after_filter', exitCode: EXIT_SUCCESS };
  }

  // Group similar commits
  console.log('🔍 Grouping related commits...\n');
  const groups = groupCommits(nonMergeCommits);

  console.log(`📦 Found ${groups.length} feature group(s):\n`);

  groups.forEach((group, idx) => {
    const primaryAreas = [...new Set(group.map((c) => c.primaryArea))];
    const types = [...new Set(group.map((c) => c.type))];

    console.log(`  Group ${idx + 1}: ${group.length} commit(s)`);
    console.log(`    Types: ${types.join(', ')}`);
    console.log(`    Areas: ${primaryAreas.join(', ')}`);
    console.log(`    Commits: ${group.map((c) => c.shortSha).join(', ')}`);
    console.log('');
  });

  // Decision logic
  return makeDecision(groups, commits);
}

function makeDecision(groups) {
  console.log('━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━');
  console.log('💡 Decision Analysis');
  console.log('━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n');

  // Single group - all commits are related
  if (groups.length === 1) {
    const group = groups[0];
    const hasLargeRefactor = group.some(
      (c) => c.type === 'refactor' && c.changeSize > LARGE_CHANGE_THRESHOLD
    );

    if (hasLargeRefactor) {
      console.log('📌 Large refactor detected - keeping commits as is\n');
      return {
        action: 'keep_as_is',
        reason: 'large_refactor',
        exitCode: EXIT_SUCCESS,
        groups,
      };
    }

    console.log('✅ All commits are related to the same feature\n');
    console.log('📋 Recommendation: SQUASH\n');
    console.log('   All commits can be combined into a single commit\n');

    const suggestedMessage = suggestCommitMessage(group);
    console.log('📝 Suggested commit message:');
    console.log('   ' + suggestedMessage + '\n');

    return {
      action: 'squash',
      reason: 'single_feature_group',
      confidence: 0.95,
      exitCode: EXIT_NEEDS_SQUASH,
      groups,
      suggestedMessage,
    };
  }

  // Multiple groups - check if they're truly different features
  const featureGroups = groups.filter((g) =>
    g.some((c) => c.type === 'feat' || c.type === 'refactor')
  );
  const docGroups = groups.filter((g) => g.every((c) => c.type === 'docs'));
  const fixGroups = groups.filter((g) =>
    g.every((c) => c.type === 'fix' || c.type === 'style' || c.type === 'test')
  );

  // If we have multiple feature groups, recommend split
  if (featureGroups.length > 1) {
    console.log(`⚠️  Multiple distinct features detected (${featureGroups.length} groups)\n`);
    console.log('📋 Recommendation: SPLIT\n');
    console.log('   These features should be on separate branches:\n');

    featureGroups.forEach((group, idx) => {
      const primaryArea = group[0].primaryArea;
      const suggestedBranch = `feature/${primaryArea.replace(/\//g, '-')}`;

      console.log(`   ${idx + 1}. Branch: ${suggestedBranch}`);
      console.log(`      Commits: ${group.map((c) => c.shortSha).join(', ')}`);
      console.log(`      Area: ${primaryArea}\n`);
    });

    console.log('💡 Auto-remediation options:');
    console.log('   1. Auto-squash all commits if they\'re actually related (override)');
    console.log('   2. Create separate branches for each feature group');
    console.log('   3. Keep current branch, create new branch for additional features\n');

    return {
      action: 'split',
      reason: 'multiple_features',
      confidence: 0.85,
      exitCode: EXIT_NEEDS_SPLIT,
      groups: featureGroups,
      docGroups,
      fixGroups,
    };
  }

  // One feature group + docs/fixes - can squash
  console.log('✅ Commits can be logically grouped\n');
  console.log('📋 Recommendation: SQUASH\n');

  if (docGroups.length > 0) {
    console.log('   ℹ️  Documentation commits will be included\n');
  }
  if (fixGroups.length > 0) {
    console.log('   ℹ️  Fix commits will be included\n');
  }

  return {
    action: 'squash',
    reason: 'related_with_fixes_and_docs',
    confidence: 0.8,
    exitCode: EXIT_NEEDS_SQUASH,
    groups,
  };
}

function suggestCommitMessage(group) {
  const primaryType = group[0].type;
  const types = [...new Set(group.map((c) => c.type))];

  // If all same type, use that
  let type = types.length === 1 ? primaryType : 'feat';

  // Get scope if available
  const scopes = group.map((c) => c.scope).filter(Boolean);
  const scope = scopes.length > 0 ? scopes[0] : null;

  // Combine descriptions
  const descriptions = group.map((c) => c.description);
  const mainDescription = descriptions[0];

  let message = scope ? `${type}(${scope}): ${mainDescription}` : `${type}: ${mainDescription}`;

  return message;
}

// Main execution
(async () => {
  try {
    // Header
    console.log('━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━');
    console.log('🧠 Intelligent Commit Splitter');
    if (DRY_RUN) {
      console.log('🔍 MODE: DRY RUN (no changes will be made)');
    }
    if (VERBOSE) {
      console.log('📢 MODE: VERBOSE (detailed output enabled)');
    }
    console.log('━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n');

    // Run safety checks
    if (!runSafetyChecks()) {
      console.error('\n❌ Safety checks failed - aborting analysis\n');
      exit(EXIT_ERROR);
    }

    // Perform analysis
    const baseBranch = getBaseBranch();
    const result = analyzeCommits(baseBranch);

    // Display results
    console.log('━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━');
    console.log('📊 Final Result');
    console.log('━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n');
    console.log(`Action: ${result.action}`);
    console.log(`Reason: ${result.reason}`);
    if (result.confidence) {
      console.log(`Confidence: ${(result.confidence * 100).toFixed(0)}%`);
    }

    if (DRY_RUN) {
      console.log('\n🔍 DRY RUN: No changes were made');
      console.log('   Run without --dry-run to apply recommendations');
    }
    console.log('');

    // Output JSON for workflows to parse
    if (process.env.GITHUB_OUTPUT && !DRY_RUN) {
      const fs = await import('fs');
      fs.appendFileSync(
        process.env.GITHUB_OUTPUT,
        `action=${result.action}\n`
      );
      fs.appendFileSync(
        process.env.GITHUB_OUTPUT,
        `reason=${result.reason}\n`
      );
      fs.appendFileSync(
        process.env.GITHUB_OUTPUT,
        `exit_code=${result.exitCode}\n`
      );
    }

    // In dry-run mode, always exit with success
    const exitCode = DRY_RUN ? EXIT_SUCCESS : result.exitCode;

    if (VERBOSE) {
      console.log(`Exit code: ${exitCode}`);
    }

    exit(exitCode);
  } catch (error) {
    console.error('❌ Error during analysis:', error.message);
    if (VERBOSE) {
      console.error('Stack trace:');
      console.error(error.stack);
    }
    console.error('\n💡 Tip: Run with --verbose for more details');
    exit(EXIT_ERROR);
  }
})();
