#!/usr/bin/env node

import { writeFileSync } from 'fs';
import { join, dirname } from 'path';
import { fileURLToPath } from 'url';
import { execSync } from 'child_process';
import yaml from 'js-yaml';

const __filename = fileURLToPath(import.meta.url);
const __dirname = dirname(__filename);
const rootDir = join(__dirname, '..');

// Get GitHub token from environment
const GITHUB_TOKEN = process.env.GITHUB_TOKEN;
const ISSUE_NUMBER = process.env.ISSUE_NUMBER || process.argv[2];

if (!ISSUE_NUMBER) {
  console.error('❌ No issue number provided');
  console.error('Usage: ISSUE_NUMBER=42 npm run sync-issue');
  console.error('   or: npm run sync-issue 42');
  process.exit(1);
}

// Detect repository from git remote
function getRepoInfo() {
  try {
    const remote = execSync('git config --get remote.origin.url', { encoding: 'utf8' }).trim();
    const match = remote.match(/github\.com[:/](.+?)\/(.+?)(\.git)?$/);
    if (match) {
      return {
        owner: match[1],
        repo: match[2],
      };
    }
    // eslint-disable-next-line no-unused-vars
  } catch (_err) {
    console.error('❌ Failed to detect repository from git remote');
  }
  return null;
}

// Fetch issue from GitHub API
// Note: Requires Node.js 18+ for native fetch API
async function fetchIssue(owner, repo, issueNumber) {
  const url = `https://api.github.com/repos/${owner}/${repo}/issues/${issueNumber}`;
  const headers = {
    Accept: 'application/vnd.github.v3+json',
    'User-Agent': 'issue-mirror-sync',
  };

  if (GITHUB_TOKEN) {
    headers.Authorization = `token ${GITHUB_TOKEN}`;
  }

  try {
    // eslint-disable-next-line n/no-unsupported-features/node-builtins
    const response = await fetch(url, { headers });

    if (!response.ok) {
      throw new Error(`GitHub API error: ${response.status} ${response.statusText}`);
    }

    return await response.json();
    // eslint-disable-next-line no-unused-vars
  } catch (_err) {
    throw new Error(`Failed to fetch issue from GitHub API`);
  }
}

// Slugify title for filename
function slugify(text) {
  return text
    .toLowerCase()
    .replace(/[^\w\s-]/g, '')
    .replace(/[\s_-]+/g, '-')
    .replace(/^-+|-+$/g, '');
}

// Calculate token estimate
function estimateTokens(content) {
  return Math.ceil(content.length / 4);
}

// Get current commit hash
function getCurrentCommit() {
  try {
    return execSync('git rev-parse --short HEAD', { encoding: 'utf8' }).trim();
    // eslint-disable-next-line no-unused-vars
  } catch (_err) {
    return 'unknown';
  }
}

// Generate mirror file
function generateMirrorFile(issue) {
  const frontMatter = {
    issue_number: issue.number,
    title: issue.title,
    state: issue.state,
    labels: issue.labels.map((l) => l.name),
    created_at: issue.created_at,
    updated_at: issue.updated_at,
    last_synced_commit: getCurrentCommit(),
    tokens_estimate: estimateTokens(issue.body || ''),
    author: issue.user.login,
  };

  if (issue.assignees && issue.assignees.length > 0) {
    frontMatter.assignees = issue.assignees.map((a) => a.login);
  }

  if (issue.milestone) {
    frontMatter.milestone = issue.milestone.title;
  }

  if (issue.closed_at) {
    frontMatter.closed_at = issue.closed_at;
  }

  const yamlFrontMatter = yaml.dump(frontMatter, {
    lineWidth: -1, // No line wrapping
    quotingType: '"',
    forceQuotes: false,
  });

  const content = `---
${yamlFrontMatter.trim()}
---

${issue.body || '_No description provided._'}
`;

  return content;
}

// Main sync function
async function syncIssueMirror() {
  const repoInfo = getRepoInfo();
  if (!repoInfo) {
    console.error('❌ Could not detect repository. Set manually or run from git repository.');
    process.exit(1);
  }

  console.log(`🔄 Syncing issue #${ISSUE_NUMBER} from ${repoInfo.owner}/${repoInfo.repo}...`);

  try {
    const issue = await fetchIssue(repoInfo.owner, repoInfo.repo, ISSUE_NUMBER);

    // Generate filename
    const paddedNumber = String(issue.number).padStart(3, '0');
    const slug = slugify(issue.title);
    const filename = `${paddedNumber}-${slug}.md`;
    const filepath = join(rootDir, 'docs/issues_mirror', filename);

    // Generate content
    const content = generateMirrorFile(issue);

    // Write file
    writeFileSync(filepath, content, 'utf8');

    console.log(`✅ Issue mirrored successfully`);
    console.log(`   File: docs/issues_mirror/${filename}`);
    console.log(`   Title: ${issue.title}`);
    console.log(`   State: ${issue.state}`);
    console.log(`   Labels: ${issue.labels.map((l) => l.name).join(', ') || 'none'}`);
    console.log(`   Tokens: ~${estimateTokens(issue.body || '')} tokens`);
  } catch (err) {
    console.error(`❌ ${err.message}`);
    process.exit(1);
  }
}

syncIssueMirror();
