# Issue #26 Sub-Issue Templates

**Purpose**: Copy-paste templates for creating sub-feature and function issues manually via GitHub web UI

---

## Sub-Feature 1: Static Analysis & Tooling Foundation

**Title**: `Sub-Feature 1: Static Analysis & Tooling Foundation`

**Labels**: `role: sub-feature`, `priority: p0`, `difficulty: easy`

**Body**:

```markdown
**Parent Feature**: #26 - Comprehensive Synthetic Testing Infrastructure

**Priority**: P0 (Critical Foundation)
**Estimated Time**: 4-6 hours

## Purpose

Establish the foundational tooling for static analysis of workflows and configuration files. This provides the first layer of validation before any code execution.

## Acceptance Criteria

- [ ] actionlint installed and validates all workflow files
- [ ] yamllint installed and validates all YAML files
- [ ] act installed and can execute workflows locally
- [ ] Test directory structure created with proper organization
- [ ] All tools integrated into package.json scripts

## Child Functions

- Function 1.1: Install and Configure actionlint
- Function 1.2: Install and Configure yamllint
- Function 1.3: Install and Configure act
- Function 1.4: Set Up Test Directory Structure

## Dependencies

None - this is the foundation for all testing work.

## Reference

See ISSUE_26_BREAKDOWN.md for complete details.
```

---

## Function 1.1: Install and Configure actionlint

**Title**: `Function 1.1: Install and Configure actionlint`

**Labels**: `type: function`, `priority: p0`, `difficulty: easy`

**Body**:

```markdown
**Parent Sub-Feature**: #[INSERT_SF1_NUMBER] - Static Analysis & Tooling Foundation
**Type**: `type: tooling`
**Difficulty**: `difficulty: easy`
**Estimated Time**: 45 minutes

## Purpose

Install and configure actionlint to validate GitHub Actions workflow syntax.

## Contract

**Inputs**: Workflow YAML files in `.github/workflows/`
**Outputs**: Validation report (pass/fail + error details)
**Invariants**: All workflows must pass actionlint validation
**Pre-conditions**: Workflow files exist
**Post-conditions**: actionlint binary installed, npm script created

## Tasks

1. Research actionlint installation methods (binary vs npm)
2. Install actionlint (prefer binary for speed)
3. Create `package.json` script: `"lint:workflows": "actionlint"`
4. Run actionlint on all workflows
5. Fix any reported issues
6. Document usage in `tests/README.md`

## Test Suite

Create separate test-suite issue with:

- IB-01: Valid workflow passes actionlint
- OOB-01: Invalid syntax detected and reported
- OOB-02: Missing required fields detected

## Reference

See ISSUE_26_BREAKDOWN.md - Function 1.1
```

---

## Function 1.2: Install and Configure yamllint

**Title**: `Function 1.2: Install and Configure yamllint`

**Labels**: `type: function`, `priority: p0`, `difficulty: easy`

**Body**:

```markdown
**Parent Sub-Feature**: #[INSERT_SF1_NUMBER] - Static Analysis & Tooling Foundation
**Type**: `type: tooling`
**Difficulty**: `difficulty: easy`
**Estimated Time**: 30 minutes

## Purpose

Install and configure yamllint to validate YAML syntax in templates and config files.

## Contract

**Inputs**: YAML files (`.github/settings.yml`, `.github/ISSUE_TEMPLATE/*.yml`)
**Outputs**: Validation report
**Invariants**: All YAML files must be syntactically valid
**Pre-conditions**: YAML files exist
**Post-conditions**: yamllint configured with house style rules

## Tasks

1. Install yamllint (via pip or binary)
2. Create `.yamllint.yml` configuration matching house style
3. Create `package.json` script: `"lint:yaml": "yamllint .github/"`
4. Run yamllint on all YAML files
5. Fix any reported issues
6. Add to CI workflow

## Test Suite

- IB-01: Valid YAML passes yamllint
- OOB-01: Malformed YAML detected
- OOB-02: Indentation errors caught

## Reference

See ISSUE_26_BREAKDOWN.md - Function 1.2
```

---

## Function 1.3: Install and Configure act

**Title**: `Function 1.3: Install and Configure act`

**Labels**: `type: function`, `priority: p0`, `difficulty: medium`

**Body**:

```markdown
**Parent Sub-Feature**: #[INSERT_SF1_NUMBER] - Static Analysis & Tooling Foundation
**Type**: `type: tooling`
**Difficulty**: `difficulty: medium`
**Estimated Time**: 1.5 hours

## Purpose

Install act for local workflow execution and testing.

## Contract

**Inputs**: Workflow files
**Outputs**: Local workflow execution results
**Invariants**: act can execute all workflows without errors
**Pre-conditions**: Docker installed, workflows exist
**Post-conditions**: act configured with proper secrets/env vars

## Tasks

1. Research act installation and requirements
2. Install act binary
3. Create `.actrc` configuration file
4. Create `.secrets` file for local testing (gitignored)
5. Test execution of simple workflow
6. Document how to run workflows locally
7. Create helper script `scripts/test-workflow-local.sh`

## Test Suite

- IB-01: Simple workflow executes successfully
- OOB-01: Workflow with missing secrets fails gracefully
- OOB-02: Invalid workflow syntax caught before execution

## Reference

See ISSUE_26_BREAKDOWN.md - Function 1.3
```

---

## Function 1.4: Set Up Test Directory Structure

**Title**: `Function 1.4: Set Up Test Directory Structure`

**Labels**: `type: function`, `priority: p0`, `difficulty: trivial`

**Body**:

```markdown
**Parent Sub-Feature**: #[INSERT_SF1_NUMBER] - Static Analysis & Tooling Foundation
**Type**: `type: tooling`
**Difficulty**: `difficulty: trivial`
**Estimated Time**: 30 minutes

## Purpose

Create organized test directory structure following best practices.

## Contract

**Inputs**: None
**Outputs**: Complete test directory structure
**Invariants**: Structure matches testing pyramid (70% unit, 20% integration, 10% e2e)
**Pre-conditions**: None
**Post-conditions**: All directories created, README.md written

## Tasks

1. Create `tests/unit/`, `tests/integration/`, `tests/e2e/` directories
2. Create `tests/fixtures/`, `tests/mocks/`, `tests/helpers/` directories
3. Create `tests/README.md` with structure documentation
4. Add `.gitkeep` files to empty directories
5. Update main `README.md` with testing section

## Test Suite

- IB-01: All directories exist and are properly organized
- OOB-01: Invalid directory structure rejected by linter

## Reference

See ISSUE_26_BREAKDOWN.md - Function 1.4
```

---

## Sub-Feature 2: Unit Testing Framework

**Title**: `Sub-Feature 2: Unit Testing Framework`

**Labels**: `role: sub-feature`, `priority: p1`, `difficulty: hard`

**Body**:

```markdown
**Parent Feature**: #26 - Comprehensive Synthetic Testing Infrastructure

**Priority**: P0/P1 (Critical for Phase 1-2)
**Estimated Time**: 20-30 hours
**Dependencies**: Sub-Feature 1 complete (#[INSERT_SF1_NUMBER])

## Purpose

Build the core unit testing infrastructure including validation logic extraction, mocking systems, and comprehensive unit tests for all workflows and scripts.

## Acceptance Criteria

- [ ] All validation logic extracted into testable modules
- [ ] GitHub API mocking infrastructure complete
- [ ] File system mocking infrastructure complete
- [ ] 70%+ unit test coverage for workflows
- [ ] 70%+ unit test coverage for scripts
- [ ] All tests run in <10 seconds

## Child Functions

- Function 2.1: Extract Validation Logic into Modules
- Function 2.2: Create GitHub API Mocking Infrastructure
- Function 2.3: Create File System Mocking Infrastructure
- Function 2.4: Write Unit Tests for Workflow Validation
- Function 2.5: Write Unit Tests for Scripts

## Dependencies

- ⬆️ Sub-Feature 1 (#[INSERT_SF1_NUMBER]) must complete first

## Reference

See ISSUE_26_BREAKDOWN.md for complete details.
```

---

**(Continue for Functions 2.1-2.5 and Sub-Features 3-6...)**

**Note**: See ISSUE_26_BREAKDOWN.md for complete templates for all 25 functions and 6 sub-features.

---

## Instructions for Manual Creation

1. **Create Sub-Feature 1** first using template above
2. **Note the issue number** (e.g., #123)
3. **Replace** `#[INSERT_SF1_NUMBER]` in Function templates with actual number
4. **Create each function issue** under Sub-Feature 1
5. **Repeat** for Sub-Features 2-6

## Quick Reference

| Sub-Feature              | Functions | Priority |
| ------------------------ | --------- | -------- |
| SF1: Static Analysis     | 4         | P0       |
| SF2: Unit Testing        | 5         | P0/P1    |
| SF3: Integration Testing | 4         | P1       |
| SF4: CI/CD Integration   | 4         | P1       |
| SF5: E2E Testing         | 4         | P2       |
| SF6: Documentation       | 4         | P1/P2    |
| **TOTAL**                | **25**    | -        |
