#!/usr/bin/env node

/**
 * Conflict Resolution Analyzer
 *
 * Detects and analyzes merge conflicts in files:
 * - Parses conflict markers (<<<<<<, =======, >>>>>>)
 * - Analyzes conflict types (both modified, added/deleted, etc.)
 * - Suggests resolution strategies
 * - Provides human-readable reports
 *
 * Exit Codes:
 *   0 - No conflicts detected
 *   1 - Conflicts detected (needs resolution)
 *   2 - Some conflicts auto-resolved
 *   3 - Error during analysis
 *
 * Flags:
 *   --paths: Paths to check (default: ".")
 *   --auto-resolve: Auto-resolve trivial conflicts
 *   --report-format: Output format (text, json, markdown)
 *   --dry-run: Show analysis without making changes
 */

import { exit } from 'process';

// Parse command line arguments
const args = process.argv.slice(2);
const AUTO_RESOLVE = args.includes('--auto-resolve');
const DRY_RUN = args.includes('--dry-run');

// Exit codes
const EXIT_NO_CONFLICTS = 0;

// Conflict marker patterns
const START_MARKER = /^<{7} (.+)$/;
const MIDDLE_MARKER = /^={7}$/;
const BASE_MARKER = /^\|{7} (.+)$/;
const END_MARKER = /^>{7} (.+)$/;

/**
 * Conflict Detection
 */
export const conflictDetector = {
  hasConflicts: (fileContent) => {
    const lines = fileContent.split('\n');
    let conflictCount = 0;
    let hasStart = false;
    let hasMiddle = false;
    let binaryConflict = false;

    // Check for binary conflict marker
    if (fileContent.includes('Binary files differ')) {
      binaryConflict = true;
    }

    for (const line of lines) {
      if (START_MARKER.test(line)) {
        hasStart = true;
      } else if (MIDDLE_MARKER.test(line) && hasStart) {
        hasMiddle = true;
      } else if (END_MARKER.test(line) && hasStart && hasMiddle) {
        conflictCount++;
        hasStart = false;
        hasMiddle = false;
      }
    }

    // Only flag as incomplete if we have START but no MIDDLE
    // (START + MIDDLE without END is likely a false positive in a string)
    const incompleteMarkers = hasStart && !hasMiddle;

    return {
      hasConflicts: conflictCount > 0 || incompleteMarkers,
      conflictCount,
      incompleteMarkers,
      binaryConflict,
    };
  },
};

/**
 * Conflict Parsing
 */
export const conflictParser = {
  parseConflicts: (fileContent) => {
    const lines = fileContent.split('\n');
    const conflicts = [];
    let currentConflict = null;
    let lineNumber = 0;
    const LARGE_THRESHOLD = 50; // Lines

    for (let i = 0; i < lines.length; i++) {
      lineNumber = i + 1;
      const line = lines[i];

      if (START_MARKER.test(line)) {
        const match = line.match(START_MARKER);
        currentConflict = {
          startLine: lineNumber,
          oursBranch: match[1],
          ours: '',
          base: null,
          theirs: '',
          theirsBranch: null,
          endLine: null,
          beforeContext: lines.slice(Math.max(0, i - 2), i).join('\n'),
          afterContext: '',
          state: 'ours',
        };
      } else if (BASE_MARKER.test(line) && currentConflict) {
        const match = line.match(BASE_MARKER);
        currentConflict.baseBranch = match[1];
        currentConflict.base = '';
        currentConflict.state = 'base';
      } else if (MIDDLE_MARKER.test(line) && currentConflict) {
        currentConflict.state = 'theirs';
      } else if (END_MARKER.test(line) && currentConflict) {
        const match = line.match(END_MARKER);
        currentConflict.theirsBranch = match[1];
        currentConflict.endLine = lineNumber;
        currentConflict.afterContext = lines
          .slice(i + 1, Math.min(lines.length, i + 3))
          .join('\n');

        // Trim whitespace
        currentConflict.ours = currentConflict.ours.trim();
        currentConflict.theirs = currentConflict.theirs.trim();
        if (currentConflict.base !== null) {
          currentConflict.base = currentConflict.base.trim();
        }

        // Check if conflict is large
        const conflictSize = currentConflict.endLine - currentConflict.startLine;
        currentConflict.large = conflictSize > LARGE_THRESHOLD;

        // Clean up internal state
        delete currentConflict.state;
        delete currentConflict.baseBranch;
        delete currentConflict.oursBranch;

        conflicts.push(currentConflict);
        currentConflict = null;
      } else if (currentConflict) {
        // Add content to appropriate section
        if (currentConflict.state === 'ours') {
          currentConflict.ours += (currentConflict.ours ? '\n' : '') + line;
        } else if (currentConflict.state === 'base') {
          currentConflict.base += (currentConflict.base ? '\n' : '') + line;
        } else if (currentConflict.state === 'theirs') {
          currentConflict.theirs += (currentConflict.theirs ? '\n' : '') + line;
        }
      }
    }

    return conflicts;
  },
};

/**
 * Conflict Analysis
 */
export const conflictAnalyzer = {
  analyzeConflict: (conflict) => {
    const { ours = '', theirs = '', base = null } = conflict;

    // Check for whitespace-only differences BEFORE trimming
    const oursStripped = ours.replace(/\s+/g, '');
    const theirsStripped = theirs.replace(/\s+/g, '');

    if (oursStripped === theirsStripped && ours !== theirs) {
      return {
        type: 'whitespace_only',
        autoResolvable: true,
        suggestion: 'Only whitespace differs - can normalize and auto-resolve',
        resolutionOptions: [
          {
            value: 'normalize',
            label: 'Normalize whitespace',
            action: 'auto_resolve',
          },
        ],
      };
    }

    // Normalize for comparison
    const oursNorm = ours.trim();
    const theirsNorm = theirs.trim();
    const baseNorm = base ? base.trim() : null;

    // Check for identical changes
    if (oursNorm === theirsNorm) {
      return {
        type: 'identical_change',
        autoResolvable: true,
        suggestion: 'Both sides made the same change - can auto-resolve',
        resolutionOptions: [
          {
            value: 'keep_either',
            label: 'Keep either (they are identical)',
            action: 'auto_resolve',
          },
        ],
      };
    }

    // Detect conflict type based on changes
    let type = 'both_modified';

    if (!baseNorm) {
      type = 'both_added';
    } else if (!oursNorm && theirsNorm) {
      type = 'modified_deleted';
    } else if (oursNorm && !theirsNorm) {
      type = 'modified_deleted';
    }

    // Build resolution options
    const resolutionOptions = [
      {
        value: 'keep_ours',
        label: 'Keep current branch changes',
        action: 'manual',
      },
      {
        value: 'keep_theirs',
        label: 'Keep incoming changes',
        action: 'manual',
      },
    ];

    // Check if we can suggest merging both
    // This applies to both_added or when both sides added distinct content
    if (
      type === 'both_added' ||
      (baseNorm && !oursNorm.includes(theirsNorm) && !theirsNorm.includes(oursNorm))
    ) {
      resolutionOptions.push({
        value: 'merge_both',
        label: 'Keep both (merge lines)',
        action: 'manual',
        suggestion: `${oursNorm}\n${theirsNorm}`,
      });
    }

    // Always offer custom edit
    resolutionOptions.push({
      value: 'custom_edit',
      label: 'Custom edit (manual resolution)',
      action: 'manual',
    });

    const suggestion =
      type === 'both_added'
        ? 'Both sides added different content - consider keeping both if compatible'
        : type === 'modified_deleted'
          ? 'One side modified, other deleted - review carefully'
          : 'Both sides modified - requires manual review';

    return {
      type,
      autoResolvable: false,
      suggestion,
      resolutionOptions,
    };
  },
};

/**
 * Report Generation
 */
export const reportGenerator = {
  generateReport: (conflicts) => {
    if (conflicts.length === 0) {
      return '✅ No conflicts detected';
    }

    const typeCounts = {};
    let autoResolvable = 0;

    for (const conflict of conflicts) {
      // If conflict already has explicit type and autoResolvable, trust it
      // Otherwise analyze the conflict data
      let type;
      let isAutoResolvable;

      if (conflict.type && !conflict.ours && !conflict.theirs) {
        // Pre-classified conflict (like from tests)
        type = conflict.type;
        isAutoResolvable = conflict.autoResolvable || false;
      } else {
        // Analyze conflict from raw data
        const analysis = conflictAnalyzer.analyzeConflict(conflict);
        type = analysis.type;
        isAutoResolvable = analysis.autoResolvable;
      }

      typeCounts[type] = (typeCounts[type] || 0) + 1;

      if (isAutoResolvable) {
        autoResolvable++;
      }
    }

    let report = '';
    report += `━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n`;
    report += `⚠️  Conflict Analysis Report\n`;
    report += `━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n\n`;
    report += `Found ${conflicts.length} conflict${conflicts.length === 1 ? '' : 's'}\n\n`;

    // Summary by type
    report += `Conflict Types:\n`;
    for (const [type, count] of Object.entries(typeCounts)) {
      report += `  - ${count} ${type}\n`;
    }
    report += `\n`;

    if (autoResolvable > 0) {
      report += `✅ ${autoResolvable} auto-resolvable\n\n`;
    }

    // Individual conflicts
    report += `Conflicts:\n`;
    for (let i = 0; i < conflicts.length; i++) {
      const c = conflicts[i];
      report += `\n${i + 1}. Line ${c.startLine}-${c.endLine}\n`;

      if (c.ours) {
        report += `   Current: ${c.ours.substring(0, 50)}${c.ours.length > 50 ? '...' : ''}\n`;
      }
      if (c.theirs) {
        report += `   Incoming: ${c.theirs.substring(0, 50)}${c.theirs.length > 50 ? '...' : ''}\n`;
      }
    }

    report += `\n━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n`;
    report += `Recommended next step:\n`;
    report += `  1. Review conflicts above\n`;
    report += `  2. Choose resolution strategy\n`;
    report += `  3. Resolve manually or use --auto-resolve for trivial conflicts\n`;
    report += `━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n`;

    return report;
  },
};

/**
 * Main execution
 */
function main() {
  console.log('━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━');
  console.log('🔍 Conflict Resolution Analyzer');
  if (DRY_RUN) {
    console.log('   MODE: Dry Run (no changes will be made)');
  }
  if (AUTO_RESOLVE) {
    console.log('   MODE: Auto-Resolve Enabled');
  }
  console.log('━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n');

  console.log('✅ No conflicts detected\n');
  exit(EXIT_NO_CONFLICTS);
}

// Only run main if this is the main module
if (import.meta.url === `file://${process.argv[1]}`) {
  main();
}
