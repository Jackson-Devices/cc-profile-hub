#!/usr/bin/env node
/**
 * Delete all labels from the repository using GitHub API
 */

import { exec } from 'child_process';
import { promisify } from 'util';

const execAsync = promisify(exec);

async function getAllLabels() {
  const { stdout } = await execAsync(
    'gh api repos/Jackson-Devices/JD_GitHub_template/labels --paginate --jq ".[].name"'
  );
  return stdout
    .trim()
    .split('\n')
    .filter((l) => l.trim());
}

async function deleteLabel(labelName) {
  const encoded = encodeURIComponent(labelName);
  console.log(`Deleting: ${labelName} (encoded: ${encoded})`);
  try {
    await execAsync(
      `gh api -X DELETE "repos/Jackson-Devices/JD_GitHub_template/labels/${encoded}"`
    );
    console.log(`  ✓ Deleted: ${labelName}`);
    return true;
  } catch (error) {
    console.log(`  ✗ Failed: ${labelName} - ${error.message}`);
    return false;
  }
}

async function main() {
  console.log('='.repeat(60));
  console.log('GitHub Label Deletion Script');
  console.log('='.repeat(60));
  console.log('');

  const labels = await getAllLabels();
  console.log(`Found ${labels.length} labels to delete\n`);

  let deleted = 0;
  let failed = 0;

  for (const label of labels) {
    if (await deleteLabel(label)) {
      deleted++;
    } else {
      failed++;
    }
  }

  console.log('');
  console.log('='.repeat(60));
  console.log(`Summary: ${deleted} deleted, ${failed} failed`);
  console.log('='.repeat(60));

  process.exit(failed > 0 ? 1 : 0);
}

main().catch((error) => {
  console.error('Fatal error:', error);
  process.exit(1);
});
