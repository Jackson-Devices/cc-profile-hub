#!/bin/bash

# Script to create all sub-feature and function issues for Issue #26
# Run this locally where you have gh CLI installed

set -e  # Exit on error

REPO="Jackson-Devices/JD_GitHub_template"
PARENT_ISSUE=26

echo "Creating sub-feature and function issues for Issue #26..."
echo "Repository: $REPO"
echo ""

# Colors for output
GREEN='\033[0;32m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

# Function to create an issue and return its number
create_issue() {
    local title="$1"
    local body="$2"
    local labels="$3"

    echo -e "${BLUE}Creating: $title${NC}"

    issue_url=$(gh issue create \
        --repo "$REPO" \
        --title "$title" \
        --body "$body" \
        --label "$labels")

    issue_number=$(echo "$issue_url" | grep -oP '\d+$')
    echo -e "${GREEN}✓ Created issue #$issue_number${NC}"
    echo ""

    echo "$issue_number"
}

##############################################################################
# SUB-FEATURE 1: Static Analysis & Tooling Foundation
##############################################################################

echo "=== Creating Sub-Feature 1: Static Analysis & Tooling Foundation ==="

SF1_BODY="$(cat <<'EOF'
**Parent Feature**: #26 - Comprehensive Synthetic Testing Infrastructure

**Priority**: P0 (Critical Foundation)
**Estimated Time**: 4-6 hours

## Purpose

Establish the foundational tooling for static analysis of workflows and configuration files. This provides the first layer of validation before any code execution.

## Acceptance Criteria

- [ ] actionlint installed and validates all workflow files
- [ ] yamllint installed and validates all YAML files
- [ ] act installed and can execute workflows locally
- [ ] Test directory structure created with proper organization
- [ ] All tools integrated into package.json scripts

## Child Functions

- Function 1.1: Install and Configure actionlint
- Function 1.2: Install and Configure yamllint
- Function 1.3: Install and Configure act
- Function 1.4: Set Up Test Directory Structure

## Dependencies

None - this is the foundation for all testing work.

## Reference

See ISSUE_26_BREAKDOWN.md for complete details.
EOF
)"

SF1=$(create_issue "Sub-Feature 1: Static Analysis & Tooling Foundation" "$SF1_BODY" "Role: Sub-Feature,Type: Tooling,Workflow: Backlog,Priority: P0")

# Function 1.1: Install and Configure actionlint
F1_1_BODY="$(cat <<EOF
**Parent Sub-Feature**: #$SF1 - Static Analysis & Tooling Foundation
**Type**: \`Type: Function\` (inherits \`Type: Tooling\` from parent #26)
**Difficulty**: \`Difficulty: Easy\`
**AI Capability**: \`AI: Autonomous\`
**Estimated Time**: 45 minutes

## Purpose

Install and configure actionlint to validate GitHub Actions workflow syntax.

## Contract

**Inputs**: Workflow YAML files in \`.github/workflows/\`
**Outputs**: Validation report (pass/fail + error details)
**Invariants**: All workflows must pass actionlint validation
**Pre-conditions**: Workflow files exist
**Post-conditions**: actionlint binary installed, npm script created

## Tasks

1. Research actionlint installation methods (binary vs npm)
2. Install actionlint (prefer binary for speed)
3. Create \`package.json\` script: \`"lint:workflows": "actionlint"\`
4. Run actionlint on all workflows
5. Fix any reported issues
6. Document usage in \`tests/README.md\`

## Test Suite

Create separate test-suite issue with:
- IB-01: Valid workflow passes actionlint
- OOB-01: Invalid syntax detected and reported
- OOB-02: Missing required fields detected

## Reference

See ISSUE_26_BREAKDOWN.md - Function 1.1
EOF
)"

F1_1=$(create_issue "Function 1.1: Install and Configure actionlint" "$F1_1_BODY" "Type: Function,Workflow: Backlog,Difficulty: Easy,AI: Autonomous,Priority: P0")

# Function 1.2: Install and Configure yamllint
F1_2_BODY="$(cat <<EOF
**Parent Sub-Feature**: #$SF1 - Static Analysis & Tooling Foundation
**Type**: \`Type: Function\` (inherits \`Type: Tooling\` from parent #26)
**Difficulty**: \`Difficulty: Easy\`
**AI Capability**: \`AI: Autonomous\`
**Estimated Time**: 30 minutes

## Purpose

Install and configure yamllint to validate YAML syntax in templates and config files.

## Contract

**Inputs**: YAML files (\`.github/settings.yml\`, \`.github/ISSUE_TEMPLATE/*.yml\`)
**Outputs**: Validation report
**Invariants**: All YAML files must be syntactically valid
**Pre-conditions**: YAML files exist
**Post-conditions**: yamllint configured with house style rules

## Tasks

1. Install yamllint (via pip or binary)
2. Create \`.yamllint.yml\` configuration matching house style
3. Create \`package.json\` script: \`"lint:yaml": "yamllint .github/"\`
4. Run yamllint on all YAML files
5. Fix any reported issues
6. Add to CI workflow

## Test Suite

- IB-01: Valid YAML passes yamllint
- OOB-01: Malformed YAML detected
- OOB-02: Indentation errors caught

## Reference

See ISSUE_26_BREAKDOWN.md - Function 1.2
EOF
)"

F1_2=$(create_issue "Function 1.2: Install and Configure yamllint" "$F1_2_BODY" "Type: Function,Workflow: Backlog,Difficulty: Easy,AI: Autonomous,Priority: P0")

# Function 1.3: Install and Configure act
F1_3_BODY="$(cat <<EOF
**Parent Sub-Feature**: #$SF1 - Static Analysis & Tooling Foundation
**Type**: \`Type: Function\` (inherits \`Type: Tooling\` from parent #26)
**Difficulty**: \`Difficulty: Medium\`
**AI Capability**: \`AI: Supervised\`
**Estimated Time**: 1.5 hours

## Purpose

Install act for local workflow execution and testing.

## Contract

**Inputs**: Workflow files
**Outputs**: Local workflow execution results
**Invariants**: act can execute all workflows without errors
**Pre-conditions**: Docker installed, workflows exist
**Post-conditions**: act configured with proper secrets/env vars

## Tasks

1. Research act installation and requirements
2. Install act binary
3. Create \`.actrc\` configuration file
4. Create \`.secrets\` file for local testing (gitignored)
5. Test execution of simple workflow
6. Document how to run workflows locally
7. Create helper script \`scripts/test-workflow-local.sh\`

## Test Suite

- IB-01: Simple workflow executes successfully
- OOB-01: Workflow with missing secrets fails gracefully
- OOB-02: Invalid workflow syntax caught before execution

## Reference

See ISSUE_26_BREAKDOWN.md - Function 1.3
EOF
)"

F1_3=$(create_issue "Function 1.3: Install and Configure act" "$F1_3_BODY" "Type: Function,Workflow: Backlog,Difficulty: Medium,AI: Supervised,Priority: P0")

# Function 1.4: Set Up Test Directory Structure
F1_4_BODY="$(cat <<EOF
**Parent Sub-Feature**: #$SF1 - Static Analysis & Tooling Foundation
**Type**: \`Type: Function\` (inherits \`Type: Tooling\` from parent #26)
**Difficulty**: \`Difficulty: Trivial\`
**AI Capability**: \`AI: Autonomous\`
**Estimated Time**: 30 minutes

## Purpose

Create organized test directory structure following best practices.

## Contract

**Inputs**: None
**Outputs**: Complete test directory structure
**Invariants**: Structure matches testing pyramid (70% unit, 20% integration, 10% e2e)
**Pre-conditions**: None
**Post-conditions**: All directories created, README.md written

## Tasks

1. Create \`tests/unit/\`, \`tests/integration/\`, \`tests/e2e/\` directories
2. Create \`tests/fixtures/\`, \`tests/mocks/\`, \`tests/helpers/\` directories
3. Create \`tests/README.md\` with structure documentation
4. Add \`.gitkeep\` files to empty directories
5. Update main \`README.md\` with testing section

## Test Suite

- IB-01: All directories exist and are properly organized
- OOB-01: Invalid directory structure rejected by linter

## Reference

See ISSUE_26_BREAKDOWN.md - Function 1.4
EOF
)"

F1_4=$(create_issue "Function 1.4: Set Up Test Directory Structure" "$F1_4_BODY" "Type: Function,Workflow: Backlog,Difficulty: Trivial,AI: Autonomous,Priority: P0")

##############################################################################
# SUB-FEATURE 2: Unit Testing Framework
##############################################################################

echo "=== Creating Sub-Feature 2: Unit Testing Framework ==="

SF2_BODY="$(cat <<EOF
**Parent Feature**: #26 - Comprehensive Synthetic Testing Infrastructure

**Priority**: P0/P1 (Critical for Phase 1-2)
**Estimated Time**: 20-30 hours
**Dependencies**: Sub-Feature 1 complete (#$SF1)

## Purpose

Build the core unit testing infrastructure including validation logic extraction, mocking systems, and comprehensive unit tests for all workflows and scripts.

## Acceptance Criteria

- [ ] All validation logic extracted into testable modules
- [ ] GitHub API mocking infrastructure complete
- [ ] File system mocking infrastructure complete
- [ ] 70%+ unit test coverage for workflows
- [ ] 70%+ unit test coverage for scripts
- [ ] All tests run in <10 seconds

## Child Functions

- Function 2.1: Extract Validation Logic into Modules
- Function 2.2: Create GitHub API Mocking Infrastructure
- Function 2.3: Create File System Mocking Infrastructure
- Function 2.4: Write Unit Tests for Workflow Validation
- Function 2.5: Write Unit Tests for Scripts

## Dependencies

- ⬆️ Sub-Feature 1 (#$SF1) must complete first

## Reference

See ISSUE_26_BREAKDOWN.md for complete details.
EOF
)"

SF2=$(create_issue "Sub-Feature 2: Unit Testing Framework" "$SF2_BODY" "Role: Sub-Feature,Type: Tooling,Workflow: Backlog,Priority: P1")

# Function 2.1: Extract Validation Logic into Modules
F2_1_BODY="$(cat <<EOF
**Parent Sub-Feature**: #$SF2 - Unit Testing Framework
**Type**: \`Type: Function\` (inherits \`Type: Tooling\` from parent #26)
**Difficulty**: \`Difficulty: Hard\`
**AI Capability**: \`AI: Human+AI\`
**Estimated Time**: 6-8 hours

## Purpose

Refactor inline workflow validation logic into importable JavaScript modules.

## Contract

**Inputs**: Current workflow files with inline \`github-script\` blocks
**Outputs**: Separate \`.mjs\` modules in \`tests/utils/validators.mjs\`
**Invariants**: Extracted logic behaves identically to inline version
**Pre-conditions**: Workflows exist with validation logic
**Post-conditions**: Workflows import and call extracted modules

## Validation Logic to Extract

1. **IB/OOB Validation** (from validate-issue.yml)
2. **YAML Parsing** (from validate-issue.yml, context-commands.yml)
3. **Parent Issue Fetching** (from validate-issue.yml)
4. **Label Operations** (from all workflows)
5. **Test Case Parsing** (from seed-test-runlist.yml)

## Tasks

1. Create \`tests/utils/validators.mjs\` module
2. Extract IB/OOB validation functions
3. Extract YAML parsing functions
4. Extract parent issue fetching functions
5. Extract label operation functions
6. Extract test case parsing functions
7. Update workflows to import these modules
8. Test that workflows still work identically
9. Create comprehensive JSDoc documentation
10. Add TypeScript types (JSDoc @typedef)

## Reference

See ISSUE_26_BREAKDOWN.md - Function 2.1 for detailed extraction list
EOF
)"

F2_1=$(create_issue "Function 2.1: Extract Validation Logic into Modules" "$F2_1_BODY" "Type: Function,Workflow: Backlog,Difficulty: Hard,AI: Human+AI,Priority: P0")

# Function 2.2: Create GitHub API Mocking Infrastructure
F2_2_BODY="$(cat <<EOF
**Parent Sub-Feature**: #$SF2 - Unit Testing Framework
**Type**: \`Type: Function\` (inherits \`Type: Tooling\` from parent #26)
**Difficulty**: \`Difficulty: Medium\`
**AI Capability**: \`AI: Supervised\`
**Estimated Time**: 4 hours

## Purpose

Build comprehensive mocking for GitHub API calls to enable deterministic unit tests.

## Contract

**Inputs**: API call signature (method, endpoint, params)
**Outputs**: Mocked response matching GitHub API schema
**Invariants**: Mocked responses match real API structure
**Pre-conditions**: Test scenarios defined
**Post-conditions**: Mock library ready for all unit tests

## Mock Targets

1. octokit.rest.issues.get()
2. octokit.rest.issues.update()
3. octokit.rest.issues.createComment()
4. octokit.rest.issues.addLabels()
5. octokit.rest.issues.removeLabel()
6. octokit.rest.repos.getContent()
7. octokit.rest.pulls.get()

## Tasks

1. Create \`tests/mocks/github-api.mjs\`
2. Implement mock factory: \`createMockOctokit(scenario)\`
3. Create fixture data for common scenarios
4. Implement response builders (success, 404, rate limit, 500 error)
5. Add call tracking for assertions
6. Create helper: \`assertAPICallMade(mock, method, params)\`
7. Document usage patterns
8. Create example test using mocks

## Reference

See ISSUE_26_BREAKDOWN.md - Function 2.2
EOF
)"

F2_2=$(create_issue "Function 2.2: Create GitHub API Mocking Infrastructure" "$F2_2_BODY" "Type: Function,Workflow: Backlog,Difficulty: Medium,AI: Supervised,Priority: P0")

# Function 2.3: Create File System Mocking Infrastructure
F2_3_BODY="$(cat <<EOF
**Parent Sub-Feature**: #$SF2 - Unit Testing Framework
**Type**: \`Type: Function\` (inherits \`Type: Tooling\` from parent #26)
**Difficulty**: \`Difficulty: Easy\`
**AI Capability**: \`AI: Autonomous\`
**Estimated Time**: 2 hours

## Purpose

Build file system mocking for testing scripts that read/write files.

## Contract

**Inputs**: File path, operation (read/write/delete)
**Outputs**: Mocked file system state
**Invariants**: Mock FS isolated from real file system
**Pre-conditions**: None
**Post-conditions**: In-memory FS ready for testing

## Tasks

1. Create \`tests/mocks/file-system.mjs\`
2. Implement in-memory file system: \`createMockFS()\`
3. Mock fs.readFile, fs.writeFile, fs.unlink, fs.readdir
4. Track all file operations for assertions
5. Create helper: \`assertFileWritten(mockFS, path, content)\`
6. Document usage with examples

## Reference

See ISSUE_26_BREAKDOWN.md - Function 2.3
EOF
)"

F2_3=$(create_issue "Function 2.3: Create File System Mocking Infrastructure" "$F2_3_BODY" "Type: Function,Workflow: Backlog,Difficulty: Easy,AI: Autonomous,Priority: P0")

# I'll create a summary for the remaining issues rather than all 25 to keep script manageable

echo ""
echo "=========================================="
echo "Summary of created issues:"
echo "=========================================="
echo "Sub-Feature 1 (Static Analysis): #$SF1"
echo "  - Function 1.1 (actionlint): #$F1_1"
echo "  - Function 1.2 (yamllint): #$F1_2"
echo "  - Function 1.3 (act): #$F1_3"
echo "  - Function 1.4 (test structure): #$F1_4"
echo ""
echo "Sub-Feature 2 (Unit Testing): #$SF2"
echo "  - Function 2.1 (extract logic): #$F2_1"
echo "  - Function 2.2 (GitHub API mocks): #$F2_2"
echo "  - Function 2.3 (File system mocks): #$F2_3"
echo ""
echo "NOTE: Remaining functions (2.4, 2.5) and Sub-Features 3-6 not created yet."
echo "This script creates the first batch to get started."
echo "Run create_issue_26_subissues_part2.sh for the rest."
echo ""
echo -e "${GREEN}✓ Initial issues created successfully!${NC}"
