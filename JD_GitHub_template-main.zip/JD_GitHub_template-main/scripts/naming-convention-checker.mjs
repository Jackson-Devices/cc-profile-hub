#!/usr/bin/env node

/**
 * Naming Convention Checker & Fixer
 *
 * Validates and fixes naming conventions for:
 * - Branch names: type/description (e.g., feature/user-auth)
 * - Commit messages: Conventional Commits (e.g., feat: add login)
 * - Issue titles: [TYPE] Description (e.g., [BUG] Login fails)
 *
 * Exit Codes:
 *   0 - All conventions followed
 *   1 - Convention violations found
 *   2 - Configuration error
 *
 * Flags:
 *   --check-branches: Check branch naming (default: true)
 *   --check-commits: Check commit messages (default: true)
 *   --check-issues: Check issue titles (default: false)
 *   --auto-fix: Automatically fix violations (default: false)
 *   --dry-run: Show fixes without applying (default: false)
 */

import { execSync } from 'child_process';
import { exit } from 'process';

// Parse command line arguments
const args = process.argv.slice(2);
const CHECK_BRANCHES = !args.includes('--no-check-branches');
const CHECK_COMMITS = !args.includes('--no-check-commits');
const AUTO_FIX = args.includes('--auto-fix');
const DRY_RUN = args.includes('--dry-run');

// Exit codes
const EXIT_SUCCESS = 0;
const EXIT_VIOLATIONS = 1;

// Convention patterns
const BRANCH_TYPES = ['feature', 'fix', 'docs', 'refactor', 'test', 'chore', 'perf', 'ci', 'build', 'style'];
const COMMIT_TYPES = ['feat', 'fix', 'docs', 'style', 'refactor', 'test', 'chore', 'perf', 'ci', 'build'];
const ISSUE_TYPES = ['BUG', 'FEATURE', 'DOCS', 'ENHANCEMENT', 'QUESTION', 'TASK'];
const PROTECTED_BRANCHES = ['main', 'master', 'develop', 'development'];

function exec(command) {
  try {
    return execSync(command, { encoding: 'utf8' }).trim();
  } catch {
    return '';
  }
}

/**
 * Branch Naming Convention Validators
 */
export const branchValidation = {
  validate: (branchName) => {
    // Protected branches are always valid
    if (PROTECTED_BRANCHES.includes(branchName)) {
      return { valid: true };
    }

    // Pattern: type/description (e.g., feature/user-auth)
    const pattern = /^([a-z]+)\/([a-z0-9-]+)$/;
    const match = branchName.match(pattern);

    if (!match) {
      return {
        valid: false,
        reason: 'Branch name must follow pattern: type/description (e.g., feature/user-auth)',
      };
    }

    const [, type] = match;

    if (!BRANCH_TYPES.includes(type)) {
      return {
        valid: false,
        reason: `Invalid branch type '${type}'. Must be one of: ${BRANCH_TYPES.join(', ')}`,
      };
    }

    return { valid: true };
  },

  suggest: (branchName) => {
    // If already valid, return as-is
    const validation = branchValidation.validate(branchName);
    if (validation.valid) {
      return branchName;
    }

    // Convert camelCase to kebab-case (add hyphen before capital letters)
    let normalized = branchName.replace(/([a-z])([A-Z])/g, '$1-$2');

    // Convert to lowercase and replace underscores/spaces with hyphens
    normalized = normalized.toLowerCase().replace(/[_\s]+/g, '-');

    // Remove any non-alphanumeric characters except hyphens and slashes
    normalized = normalized.replace(/[^a-z0-9-/]/g, '');

    // Check if it already has a valid type
    const hasType = BRANCH_TYPES.some((type) => normalized.startsWith(type + '/'));

    if (hasType) {
      return normalized;
    }

    // Try to infer type from name and remove type from description
    let type = 'feature';
    let description = normalized;

    // Check if it starts with a type word
    for (const branchType of BRANCH_TYPES) {
      if (normalized.startsWith(branchType + '-')) {
        type = branchType;
        description = normalized.substring((branchType + '-').length);
        return `${type}/${description}`;
      }
    }

    if (normalized.includes('fix') || normalized.includes('bug')) {
      type = 'fix';
      // Remove 'fix' prefix from description
      description = description.replace(/^fix-?/, '');
    } else if (normalized.includes('doc')) {
      type = 'docs';
      // Only remove 'doc' or 'docs' if it's a standalone word, not part of a larger word
      description = description.replace(/^docs?-/, '');
    } else if (normalized.includes('test')) {
      type = 'test';
      description = description.replace(/^tests?-?/, '');
    }

    // Clean up any leading/trailing hyphens
    description = description.replace(/^-+|-+$/g, '');

    return `${type}/${description}`;
  },

  extractType: (branchName) => {
    const pattern = /^([a-z]+)\//;
    const match = branchName.match(pattern);
    return match ? match[1] : null;
  },
};

/**
 * Commit Message Convention Validators
 */
export const commitValidation = {
  validate: (message) => {
    // Pattern: type(scope)?: description
    // Examples: feat: add login, fix(auth): resolve token, feat!: breaking change
    const pattern = /^([a-z]+)(\([a-z0-9-]+\))?!?: .+$/;

    if (!pattern.test(message)) {
      return {
        valid: false,
        reason: 'Commit message must follow Conventional Commits format: type(scope)?: description',
      };
    }

    const typeMatch = message.match(/^([a-z]+)/);
    const type = typeMatch ? typeMatch[1] : null;

    if (type && !COMMIT_TYPES.includes(type)) {
      return {
        valid: false,
        reason: `Invalid commit type '${type}'. Must be one of: ${COMMIT_TYPES.join(', ')}`,
      };
    }

    // Check for empty description
    const descMatch = message.match(/: (.+)$/);
    if (!descMatch || !descMatch[1].trim()) {
      return {
        valid: false,
        reason: 'Commit message must have a description after the colon',
      };
    }

    return { valid: true };
  },

  suggest: (message) => {
    // If already valid, return as-is
    const validation = commitValidation.validate(message);
    if (validation.valid) {
      return message;
    }

    // Remove leading/trailing whitespace
    let normalized = message.trim();

    // Try to infer type from message content
    let type = 'feat';

    const lowerMessage = normalized.toLowerCase();
    if (lowerMessage.startsWith('fix') || lowerMessage.includes('bug')) {
      type = 'fix';
      normalized = normalized.replace(/^fix(ed)?:?\s*/i, 'resolve ');
    } else if (lowerMessage.includes('doc')) {
      type = 'docs';
      normalized = normalized.replace(/^(update(d)?|change(d)?):?\s*/i, 'update ');
    } else if (lowerMessage.startsWith('add') || lowerMessage.startsWith('implement')) {
      type = 'feat';
      normalized = normalized.replace(/^(add(ed)?|implement(ed)?):?\s*/i, 'add ');
    } else if (lowerMessage.startsWith('update') || lowerMessage.startsWith('change')) {
      type = 'feat';
      normalized = normalized.replace(/^(update(d)?|change(d)?):?\s*/i, 'update ');
    } else if (lowerMessage.startsWith('refactor')) {
      type = 'refactor';
      normalized = normalized.replace(/^refactor(ed)?:?\s*/i, 'refactor ');
    } else if (lowerMessage.startsWith('test')) {
      type = 'test';
      normalized = normalized.replace(/^test(ed)?:?\s*/i, 'add ');
    }

    // Ensure first word after type is lowercase
    normalized = normalized.charAt(0).toLowerCase() + normalized.slice(1);

    return `${type}: ${normalized}`;
  },

  extractType: (message) => {
    const pattern = /^([a-z]+)/;
    const match = message.match(pattern);

    if (!match) {
      return null;
    }

    const type = match[1];
    return COMMIT_TYPES.includes(type) ? type : null;
  },
};

/**
 * Issue Title Convention Validators
 */
export const issueValidation = {
  validate: (title) => {
    // Pattern: [TYPE] Description
    const pattern = /^\[([A-Z]+)\] .+$/;

    if (!pattern.test(title)) {
      return {
        valid: false,
        reason: 'Issue title must follow pattern: [TYPE] Description (e.g., [BUG] Login fails)',
      };
    }

    const match = title.match(pattern);
    const type = match ? match[1] : null;

    if (type && !ISSUE_TYPES.includes(type)) {
      return {
        valid: false,
        reason: `Invalid issue type '${type}'. Must be one of: ${ISSUE_TYPES.join(', ')}`,
      };
    }

    return { valid: true };
  },

  suggest: (title) => {
    // If already valid, return as-is
    const validation = issueValidation.validate(title);
    if (validation.valid) {
      return title;
    }

    // Remove any existing type tags
    let normalized = title.replace(/^\[([A-Z]+)\]\s*/i, '').trim();

    // Infer type from title content
    let type = 'FEATURE';

    const lowerTitle = normalized.toLowerCase();
    if (
      lowerTitle.includes('bug') ||
      lowerTitle.includes('error') ||
      lowerTitle.includes('fail') ||
      lowerTitle.includes('broken') ||
      lowerTitle.includes('issue')
    ) {
      type = 'BUG';
    } else if (lowerTitle.includes('doc')) {
      type = 'DOCS';
    } else if (lowerTitle.includes('question') || lowerTitle.startsWith('how')) {
      type = 'QUESTION';
    } else if (lowerTitle.includes('improve') || lowerTitle.includes('enhance')) {
      type = 'ENHANCEMENT';
    } else if (lowerTitle.includes('refactor') || lowerTitle.includes('cleanup')) {
      type = 'TASK';
    } else if (lowerTitle.startsWith('add') || lowerTitle.startsWith('implement')) {
      type = 'FEATURE';
    }

    return `[${type}] ${normalized}`;
  },

  extractType: (title) => {
    const pattern = /^\[([A-Z]+)\]/;
    const match = title.match(pattern);
    return match ? match[1] : null;
  },
};

/**
 * Main execution
 */
function main() {
  console.log('━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━');
  console.log('🔍 Naming Convention Checker');
  if (DRY_RUN) {
    console.log('   MODE: Dry Run (no changes will be made)');
  }
  if (AUTO_FIX) {
    console.log('   MODE: Auto-Fix Enabled');
  }
  console.log('━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n');

  const violations = [];

  // Check branch names
  if (CHECK_BRANCHES) {
    const currentBranch = exec('git rev-parse --abbrev-ref HEAD');

    if (currentBranch) {
      const result = branchValidation.validate(currentBranch);

      if (!result.valid) {
        const suggestion = branchValidation.suggest(currentBranch);
        violations.push({
          type: 'branch',
          current: currentBranch,
          suggested: suggestion,
          reason: result.reason,
        });

        console.log(`❌ Branch: '${currentBranch}'`);
        console.log(`   Reason: ${result.reason}`);
        console.log(`   Suggested: ${suggestion}\n`);
      } else {
        console.log(`✅ Branch: '${currentBranch}' follows convention\n`);
      }
    }
  }

  // Check recent commit messages
  if (CHECK_COMMITS) {
    const recentCommits = exec('git log --format=%s -n 5').split('\n').filter(Boolean);

    for (const message of recentCommits) {
      const result = commitValidation.validate(message);

      if (!result.valid) {
        const suggestion = commitValidation.suggest(message);
        violations.push({
          type: 'commit',
          current: message,
          suggested: suggestion,
          reason: result.reason,
        });

        console.log(`❌ Commit: '${message.substring(0, 60)}${message.length > 60 ? '...' : ''}'`);
        console.log(`   Reason: ${result.reason}`);
        console.log(`   Suggested: ${suggestion}\n`);
      }
    }

    if (violations.filter((v) => v.type === 'commit').length === 0) {
      console.log(`✅ Recent commits follow convention\n`);
    }
  }

  // Summary
  console.log('━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━');

  if (violations.length === 0) {
    console.log('✅ All naming conventions followed\n');
    exit(EXIT_SUCCESS);
  }

  console.log(`Found ${violations.length} naming convention violations\n`);

  if (DRY_RUN) {
    console.log('💡 Run without --dry-run to apply fixes\n');
  } else if (AUTO_FIX) {
    console.log('🔧 Auto-fix would be applied (requires approval)\n');
  }

  exit(EXIT_VIOLATIONS);
}

// Only run main if this is the main module
if (import.meta.url === `file://${process.argv[1]}`) {
  main();
}
