#!/usr/bin/env node

/**
 * Safe Commit Squasher
 *
 * Uses cherry-pick to combine commits WITHOUT deleting history.
 * This is safer than git reset --soft because it preserves the original commits.
 *
 * Process:
 * 1. Analyzes commits to squash
 * 2. Creates a new branch with squashed commit
 * 3. Preserves original branch as backup
 * 4. Uses cherry-pick (non-destructive)
 *
 * Exit Codes:
 *   0 - Success (squash completed)
 *   1 - No squash needed
 *   2 - Squash failed (recoverable)
 *   3 - Error (critical failure)
 *
 * Flags:
 *   --dry-run: Show what would be done without making changes
 *   --verbose: Show detailed debug information
 *   --preserve-backup: Keep backup branch after squash
 */

import { execSync } from 'child_process';
import { exit } from 'process';

// Parse command line arguments
const args = process.argv.slice(2);
const DRY_RUN = args.includes('--dry-run');
const VERBOSE = args.includes('--verbose');
const PRESERVE_BACKUP = args.includes('--preserve-backup');

// Exit codes
const EXIT_SUCCESS = 0;
const EXIT_NO_ACTION = 1;
const EXIT_FAILED = 2;
const EXIT_ERROR = 3;

function exec(command, options = {}) {
  try {
    return execSync(command, { encoding: 'utf8', ...options }).trim();
  } catch (error) {
    if (VERBOSE) {
      console.error(`Command failed: ${command}`);
      console.error(error.message);
    }
    if (options.throwOnError) {
      throw error;
    }
    return '';
  }
}

function getBaseBranch() {
  // Try upstream tracking branch first
  const upstream = exec('git rev-parse --abbrev-ref --symbolic-full-name @{u} 2>/dev/null');
  if (upstream) {
    const match = upstream.match(/^(?:refs\/remotes\/)?(?:origin\/)?(.+)$/);
    if (match) return match[1];
  }

  // Try common base branches
  const commonBases = ['main', 'master', 'develop', 'development'];

  for (const base of commonBases) {
    const remoteExists = exec(`git rev-parse --verify origin/${base} 2>/dev/null`);
    const localExists = exec(`git rev-parse --verify ${base} 2>/dev/null`);

    if (remoteExists || localExists) {
      const branchRef = remoteExists ? `origin/${base}` : base;
      const mergeBase = exec(`git merge-base HEAD ${branchRef} 2>/dev/null`);
      if (mergeBase) {
        return base;
      }
    }
  }

  return 'main';
}

function getCommitCount(baseBranch) {
  let count = exec(`git rev-list --count origin/${baseBranch}..HEAD 2>/dev/null`);
  if (!count) {
    count = exec(`git rev-list --count ${baseBranch}..HEAD`);
  }
  return parseInt(count, 10) || 0;
}

function getCommitShas(baseBranch) {
  let shas = exec(`git log --format="%H" origin/${baseBranch}..HEAD 2>/dev/null`);
  if (!shas) {
    shas = exec(`git log --format="%H" ${baseBranch}..HEAD`);
  }
  return shas ? shas.split('\n').reverse() : [];
}

function createCombinedCommitMessage(baseBranch) {
  const shas = getCommitShas(baseBranch);

  // Get first commit subject as main title
  const firstSubject = exec(`git log --format='%s' -n 1 ${shas[0]}`);

  let message = firstSubject + '\n\n';
  message += `Changes made across ${shas.length} commits:\n`;

  shas.forEach((sha, index) => {
    const subject = exec(`git log --format='%s' -n 1 ${sha}`);
    const body = exec(`git log --format='%b' -n 1 ${sha}`);
    const timestamp = exec(`git log --format='%ci' -n 1 ${sha}`);

    message += `\n${index + 1}. [${timestamp}] ${subject}\n`;
    if (body) {
      message += `   ${body}\n`;
    }
  });

  message += '\n🤖 Auto-squashed using safe cherry-pick method\n';
  message += '\nCo-Authored-By: GitHub Actions <noreply@github.com>\n';

  return message;
}

async function safeSquash() {
  console.log('━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━');
  console.log('🔒 Safe Commit Squasher (Cherry-Pick Method)');
  if (DRY_RUN) {
    console.log('🔍 MODE: DRY RUN (no changes will be made)');
  }
  console.log('━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n');

  const currentBranch = exec('git rev-parse --abbrev-ref HEAD');
  const baseBranch = getBaseBranch();
  const commitCount = getCommitCount(baseBranch);

  console.log(`📍 Current branch: ${currentBranch}`);
  console.log(`📍 Base branch: ${baseBranch}`);
  console.log(`📊 Commits to squash: ${commitCount}\n`);

  if (commitCount <= 1) {
    console.log('✅ Single commit or no commits - no squashing needed\n');
    return { success: true, action: 'no_action', exitCode: EXIT_NO_ACTION };
  }

  // Get merge base
  const mergeBase = exec(`git merge-base HEAD origin/${baseBranch} 2>/dev/null`) ||
                   exec(`git merge-base HEAD ${baseBranch}`);

  if (!mergeBase) {
    console.error('❌ ERROR: Could not find merge base\n');
    return { success: false, action: 'error', exitCode: EXIT_ERROR };
  }

  console.log(`🔍 Merge base: ${mergeBase.substring(0, 7)}\n`);

  // Create combined commit message
  const combinedMessage = createCombinedCommitMessage(baseBranch);

  console.log('📝 Combined commit message:');
  console.log('━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━');
  console.log(combinedMessage);
  console.log('━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n');

  if (DRY_RUN) {
    console.log('🔍 DRY RUN: Would perform the following:');
    console.log(`   1. Create backup: ${currentBranch}-backup`);
    console.log(`   2. Reset to merge base: ${mergeBase.substring(0, 7)}`);
    console.log(`   3. Cherry-pick all changes as single commit`);
    console.log(`   4. Commit with combined message`);
    console.log('\n✅ Dry run complete - no changes made\n');
    return { success: true, action: 'dry_run', exitCode: EXIT_SUCCESS };
  }

  try {
    // Step 1: Create backup branch (NON-DESTRUCTIVE)
    const backupBranch = `${currentBranch}-backup-${Date.now()}`;
    console.log(`📦 Creating backup branch: ${backupBranch}`);
    exec(`git branch ${backupBranch}`, { throwOnError: true });
    console.log('   ✅ Backup created (original commits preserved)\n');

    // Step 2: Get the tree state at HEAD (all cumulative changes)
    console.log('🌳 Capturing current tree state...');
    const headTree = exec('git rev-parse HEAD^{tree}');
    console.log(`   Tree: ${headTree.substring(0, 7)}`);
    console.log(`   ✅ State captured\n`);

    // Step 3: Create new commit using commit-tree (NO RESET - completely non-destructive)
    console.log('📝 Creating squashed commit via commit-tree...');

    // Write message to temp file
    const fs = await import('fs');
    const tmpFile = `/tmp/squash-msg-${Date.now()}.txt`;
    fs.writeFileSync(tmpFile, combinedMessage);

    // Create new commit with same tree as HEAD but parent as merge base
    // This is COMPLETELY non-destructive - we're just creating a new commit object
    const newSha = exec(`git commit-tree ${headTree} -p ${mergeBase} -F ${tmpFile}`, {
      throwOnError: true,
    });
    fs.unlinkSync(tmpFile);

    console.log(`   ✅ Created new commit object: ${newSha.substring(0, 7)}\n`);

    // Step 4: Point current branch to new commit
    console.log('🔄 Updating branch pointer...');
    exec(`git reset --hard ${newSha}`, { throwOnError: true });
    console.log('   ✅ Branch updated\n');

    // Step 5: Show summary
    console.log('━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━');
    console.log('✅ Squash Complete');
    console.log('━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n');
    console.log(`📌 Original commits: ${commitCount}`);
    console.log(`📌 Squashed to: 1 commit (${newSha.substring(0, 7)})`);
    console.log(`📌 Backup branch: ${backupBranch}`);
    console.log('');

    if (!PRESERVE_BACKUP) {
      console.log('💡 To restore original commits:');
      console.log(`   git checkout ${backupBranch}`);
      console.log('');
      console.log('🗑️  To delete backup after verification:');
      console.log(`   git branch -D ${backupBranch}`);
    } else {
      console.log(`✅ Backup branch preserved: ${backupBranch}`);
    }
    console.log('');

    return {
      success: true,
      action: 'squashed',
      exitCode: EXIT_SUCCESS,
      newSha,
      backupBranch,
      commitCount,
    };
  } catch (error) {
    console.error('\n❌ ERROR during squash:', error.message);
    console.error('\n🔧 Recovery options:');
    console.error('   1. Check git status: git status');
    console.error('   2. Abort if mid-operation: git reset --hard HEAD');
    console.error('   3. Restore from backup if created');
    console.error('');

    return { success: false, action: 'failed', exitCode: EXIT_FAILED };
  }
}

// Main execution
(async () => {
  try {
    const result = await safeSquash();

    // Output JSON for workflows to parse
    if (process.env.GITHUB_OUTPUT && !DRY_RUN) {
      const fs = await import('fs');
      fs.appendFileSync(process.env.GITHUB_OUTPUT, `action=${result.action}\n`);
      if (result.newSha) {
        fs.appendFileSync(process.env.GITHUB_OUTPUT, `new_sha=${result.newSha}\n`);
      }
      if (result.backupBranch) {
        fs.appendFileSync(process.env.GITHUB_OUTPUT, `backup_branch=${result.backupBranch}\n`);
      }
      if (result.commitCount) {
        fs.appendFileSync(process.env.GITHUB_OUTPUT, `commit_count=${result.commitCount}\n`);
      }
    }

    exit(result.exitCode);
  } catch (error) {
    console.error('❌ Critical error:', error.message);
    if (VERBOSE) {
      console.error('Stack trace:');
      console.error(error.stack);
    }
    exit(EXIT_ERROR);
  }
})();
