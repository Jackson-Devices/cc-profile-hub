#!/usr/bin/env node

/**
 * Validate Tool Manifests
 *
 * Validates all tool manifests against the schema and checks for common issues.
 */

import { readFileSync, readdirSync } from 'fs';
import { join, dirname } from 'path';
import { fileURLToPath } from 'url';
import Ajv from 'ajv';

const __filename = fileURLToPath(import.meta.url);
const __dirname = dirname(__filename);
const projectRoot = join(__dirname, '..');

const ajv = new Ajv({ allErrors: true, strict: false });

// Load schema
const schemaPath = join(projectRoot, 'schemas/tool-manifest.schema.json');
const schema = JSON.parse(readFileSync(schemaPath, 'utf8'));
const validate = ajv.compile(schema);

// Find all manifests
const manifestDir = join(projectRoot, '.orchestrator/tools');
let manifestFiles = [];

try {
  manifestFiles = readdirSync(manifestDir).filter((f) => f.endsWith('.manifest.json'));
} catch {
  console.log('ℹ️  No tool manifests directory found yet');
  console.log('   Create: .orchestrator/tools/');
  process.exit(0);
}

if (manifestFiles.length === 0) {
  console.log('ℹ️  No tool manifests found');
  console.log('   Add manifests to: .orchestrator/tools/*.manifest.json');
  process.exit(0);
}

console.log('━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━');
console.log('🔍 Validating Tool Manifests');
console.log('━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n');

let allValid = true;
let validCount = 0;
let invalidCount = 0;

for (const file of manifestFiles) {
  const manifestPath = join(manifestDir, file);
  console.log(`📄 Validating: ${file}`);

  try {
    const manifest = JSON.parse(readFileSync(manifestPath, 'utf8'));

    const valid = validate(manifest);

    if (valid) {
      console.log(`   ✅ Valid\n`);
      validCount++;

      // Additional checks
      checkMessagePatterns(manifest, file);
      checkExitCodes(manifest, file);
      checkApprovalPrompts(manifest, file);
    } else {
      console.log(`   ❌ Invalid`);
      console.log('   Errors:');
      for (const error of validate.errors) {
        console.log(`     - ${error.instancePath}: ${error.message}`);
        if (error.params) {
          console.log(`       ${JSON.stringify(error.params)}`);
        }
      }
      console.log('');
      invalidCount++;
      allValid = false;
    }
  } catch (error) {
    console.log(`   ❌ Failed to parse JSON`);
    console.log(`   Error: ${error.message}\n`);
    invalidCount++;
    allValid = false;
  }
}

console.log('━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━');
console.log('📊 Summary');
console.log('━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n');
console.log(`Total manifests: ${manifestFiles.length}`);
console.log(`✅ Valid: ${validCount}`);
console.log(`❌ Invalid: ${invalidCount}\n`);

if (allValid) {
  console.log('✅ All manifests are valid!\n');
  process.exit(0);
} else {
  console.log('❌ Some manifests are invalid - please fix errors above\n');
  process.exit(1);
}

/**
 * Check message patterns are valid regex
 */
function checkMessagePatterns(manifest, filename) {
  const messages = manifest.outputs?.message_registry || [];

  for (const msg of messages) {
    try {
      new RegExp(msg.pattern);
    } catch (error) {
      console.log(`   ⚠️  Invalid regex pattern in ${filename}:`);
      console.log(`      Pattern: ${msg.pattern}`);
      console.log(`      Error: ${error.message}`);
    }
  }
}

/**
 * Check exit codes are documented
 */
function checkExitCodes(manifest, filename) {
  const exitCodes = manifest.outputs?.exit_codes || {};

  // Check for common missing codes
  if (!exitCodes['0']) {
    console.log(`   ⚠️  Missing exit code 0 (success) in ${filename}`);
  }

  // Check for negative or very large codes
  for (const [code] of Object.entries(exitCodes)) {
    const num = parseInt(code, 10);
    if (num < 0 || num > 255) {
      console.log(`   ⚠️  Unusual exit code ${code} in ${filename}`);
      console.log(`      Exit codes should be 0-255`);
    }
  }
}

/**
 * Check approval prompts have valid options
 */
function checkApprovalPrompts(manifest, filename) {
  const prompts = manifest.human_approval?.approval_prompts || [];

  for (const prompt of prompts) {
    if (!prompt.options || prompt.options.length === 0) {
      console.log(`   ⚠️  Approval prompt with no options in ${filename}`);
      console.log(`      Message: ${prompt.message}`);
    }

    // Check for duplicate option values
    const values = prompt.options.map((o) => o.value);
    const duplicates = values.filter((v, i) => values.indexOf(v) !== i);
    if (duplicates.length > 0) {
      console.log(`   ⚠️  Duplicate option values in ${filename}:`);
      console.log(`      Values: ${duplicates.join(', ')}`);
    }
  }
}
