#!/usr/bin/env node

/**
 * Test PR risk pattern detection
 *
 * This test validates that the pattern detection logic correctly identifies
 * risky patterns in code diffs.
 */

// Pattern definitions (should match check-pr-risks.mjs)
const PATTERNS = {
  DEBUGGER: {
    regex: /\bdebugger\b/g,
    level: 'error',
  },
  CONSOLE_LOG: {
    regex: /console\.(log|debug|info)\(/g,
    level: 'error',
  },
  TEST_ONLY: {
    regex: /\.(only|skip)\(/g,
    level: 'error',
  },
  TODO: {
    regex: /\b(TODO|FIXME|XXX|HACK)\b/g,
    level: 'warning',
  },
};

// Test cases
const testCases = [
  {
    name: 'Detect debugger statement',
    code: 'function test() { debugger; }',
    shouldMatch: ['DEBUGGER'],
  },
  {
    name: 'Detect console.log',
    code: 'console.log("test");',
    shouldMatch: ['CONSOLE_LOG'],
  },
  {
    name: 'Detect console.debug',
    code: 'console.debug("test");',
    shouldMatch: ['CONSOLE_LOG'],
  },
  {
    name: 'Detect console.info',
    code: 'console.info("test");',
    shouldMatch: ['CONSOLE_LOG'],
  },
  {
    name: 'Detect .only in tests',
    code: 'describe.only("test", () => {});',
    shouldMatch: ['TEST_ONLY'],
  },
  {
    name: 'Detect .skip in tests',
    code: 'it.skip("test", () => {});',
    shouldMatch: ['TEST_ONLY'],
  },
  {
    name: 'Detect TODO comment',
    code: '// TODO: fix this later',
    shouldMatch: ['TODO'],
  },
  {
    name: 'Detect FIXME comment',
    code: '// FIXME: broken',
    shouldMatch: ['FIXME'],
  },
  {
    name: 'Detect multiple patterns',
    code: 'console.log("debug"); // TODO: remove',
    shouldMatch: ['CONSOLE_LOG', 'TODO'],
  },
  {
    name: 'Clean code should not match',
    code: 'function cleanFunction() { return 42; }',
    shouldMatch: [],
  },
  {
    name: 'console.error should not match CONSOLE_LOG',
    code: 'console.error("error");',
    shouldMatch: [],
  },
  {
    name: 'console.warn should not match CONSOLE_LOG',
    code: 'console.warn("warning");',
    shouldMatch: [],
  },
];

/**
 * Run tests
 */
function runTests() {
  let passed = 0;
  let failed = 0;
  const failures = [];

  console.log('🧪 Testing PR Risk Pattern Detection\n');

  for (const testCase of testCases) {
    const matches = [];

    // Check each pattern
    for (const [patternName, config] of Object.entries(PATTERNS)) {
      const regex = new RegExp(config.regex.source, config.regex.flags);
      if (regex.test(testCase.code)) {
        // Extract the actual match for validation
        const matchResult = testCase.code.match(regex);
        if (matchResult) {
          // For TODO pattern, check if it matches the specific keyword
          if (patternName === 'TODO') {
            const keyword = matchResult[0];
            if (testCase.shouldMatch.includes(keyword)) {
              matches.push(keyword);
            } else if (testCase.shouldMatch.includes('TODO')) {
              matches.push('TODO');
            }
          } else {
            matches.push(patternName);
          }
        }
      }
    }

    // Sort for comparison
    const expected = [...testCase.shouldMatch].sort();
    const actual = [...new Set(matches)].sort();

    const success =
      expected.length === actual.length && expected.every((val, idx) => val === actual[idx]);

    if (success) {
      passed++;
      console.log(`✅ ${testCase.name}`);
    } else {
      failed++;
      console.log(`❌ ${testCase.name}`);
      failures.push({
        name: testCase.name,
        expected,
        actual,
        code: testCase.code,
      });
    }
  }

  console.log('\n━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━');
  console.log('📊 Test Results:');
  console.log(`  Passed: ${passed}`);
  console.log(`  Failed: ${failed}`);
  console.log('━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n');

  if (failures.length > 0) {
    console.log('❌ Failed Tests:\n');
    failures.forEach(({ name, expected, actual, code }) => {
      console.log(`  ${name}`);
      console.log(`    Code: ${code}`);
      console.log(`    Expected: [${expected.join(', ')}]`);
      console.log(`    Actual: [${actual.join(', ')}]`);
      console.log();
    });
    process.exit(1);
  }

  console.log('✅ All tests passed!\n');
  process.exit(0);
}

runTests();
