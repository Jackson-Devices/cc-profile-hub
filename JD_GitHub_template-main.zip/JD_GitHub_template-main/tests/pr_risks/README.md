# PR Risk Detection Tests

This directory contains tests for the PR risk detection system.

## Test Files

- `test_pattern_detection.mjs` - Unit tests for pattern detection logic

## Running Tests

```bash
node tests/pr_risks/test_pattern_detection.mjs
```

## Test Coverage

The tests validate detection of:

1. **High-risk patterns (errors)**:
   - `debugger` statements
   - `console.log/debug/info` statements
   - `.only()` and `.skip()` in tests

2. **Medium-risk patterns (warnings)**:
   - TODO/FIXME/XXX/HACK comments

3. **False positives**:
   - `console.error()` and `console.warn()` should NOT be flagged
   - Clean code should pass
