# Broken Markdown File

This file has extra spaces between words.

## Section with Issues

- Bullet with trailing spaces
- Another bullet
- Inconsistent spacing

This is a really long line that exceeds the 100 character limit and should probably be preserved because proseWrap is set to preserve in the configuration but we want to test it anyway.

### Code Block

```javascript
const test = 'broken formatting';
```

## Links

[Link with spaces](https://example.com)

---

Trailing whitespace at end of lines causes issues.
