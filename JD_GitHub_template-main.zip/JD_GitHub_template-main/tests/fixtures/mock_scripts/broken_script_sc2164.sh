#!/bin/bash
# Test fixture: SC2164 - cd without error handling

# SC2164: Use 'cd ... || exit' in case cd fails
cd /tmp
echo "Changed to tmp"

cd /some/directory
echo "In some directory"

# This one should not be changed (already has error handling)
cd /another/path || exit 1
echo "In another path"

echo "Done"
