#!/bin/bash
# Test fixture: SC2086 - Unquoted variables causing word splitting

# SC2086: Quote to prevent word splitting
FILE_COUNT=$SOME_VAR

# SC2086: In test context
if [ $USER_INPUT ]; then
  echo "User provided input"
fi

# SC2086: In comparison
if [[ $VALUE == "test" ]]; then
  echo "Match"
fi

# SC2086: Redirection to GitHub Actions variables
echo "result=success" >> $GITHUB_OUTPUT
echo "summary=done" >> $GITHUB_STEP_SUMMARY
echo "VAR=value" >> $GITHUB_ENV
echo "/usr/bin" >> $GITHUB_PATH

# SC2086: In assignment (command substitution result)
RESULT=$(echo $VARIABLE)

echo "Done"
