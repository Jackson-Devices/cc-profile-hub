#!/bin/bash
# Test fixture: Script with intentional word splitting
# Conservative strategy should preserve this, aggressive might break it

# Intentional word splitting in for loop
FILES="file1.txt file2.txt file3.txt"

# This SHOULD trigger SC2086 but it's intentional
for file in $FILES; do
  echo "Processing: $file"
done

# Another case: command line arguments
ARGS="--verbose --output=test.log"

# Intentional word splitting for arguments
./some_command $ARGS

echo "Done"
