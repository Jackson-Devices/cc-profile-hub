#!/bin/bash
# Test fixture: SC2006 - Legacy backticked command substitution

# SC2006: Use $(...) instead of legacy backticked `...`
CURRENT_DIR=`pwd`
echo "Current directory: $CURRENT_DIR"

# SC2006: In test
if [ `whoami` = "root" ]; then
  echo "Running as root"
fi

# SC2006: Nested (simplified case)
DATE_STR=`date +%Y%m%d`
echo "Date: $DATE_STR"

echo "Done"
