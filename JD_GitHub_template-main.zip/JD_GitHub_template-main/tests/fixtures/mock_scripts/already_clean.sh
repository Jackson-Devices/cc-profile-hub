#!/bin/bash
# Test fixture: Script that already passes shellcheck

set -euo pipefail

# All variables properly quoted
USER_INPUT="${1:-default}"

# Proper test syntax
if [[ -n "$USER_INPUT" ]]; then
  echo "Input: $USER_INPUT"
fi

# Proper command substitution
CURRENT_DIR="$(pwd)"
echo "Directory: $CURRENT_DIR"

# Proper cd with error handling
cd /tmp || exit 1

# Proper GitHub Actions output
echo "result=success" >> "$GITHUB_OUTPUT"

echo "Done"
