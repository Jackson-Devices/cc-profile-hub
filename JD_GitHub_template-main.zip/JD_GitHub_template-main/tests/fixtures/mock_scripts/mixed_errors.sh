#!/bin/bash
# Test fixture: Multiple SC codes in one file

# SC2006: Backticks
WORKDIR=`pwd`

# SC2164: cd without error handling
cd "$WORKDIR"

# SC2086: Unquoted variable
if [ $USER ]; then
  echo "User is set"
fi

# SC2046: Unquoted command substitution
FILES=$(ls *.txt)
for f in $FILES; do
  echo "$f"
done

# SC2086: GitHub Actions variables
echo "status=ok" >> $GITHUB_OUTPUT

echo "Done"
