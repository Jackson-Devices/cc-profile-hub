#!/bin/bash
# Test fixture: SC2046 - Unquoted command substitution

# SC2046: Quote command substitution to prevent word splitting
for file in $(ls *.txt); do
  echo "$file"
done

# SC2046: In assignment
FILES=$(find . -name "*.sh")
echo $FILES

# SC2046: In array
declare -a items
items=($(cat list.txt))

echo "Done"
