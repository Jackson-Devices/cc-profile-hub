// Bad JavaScript with unused variable
const unusedVar = 'never used';

function test() {
  console.log('test');
}

test();
