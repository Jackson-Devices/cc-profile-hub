// Clean JavaScript code
function test() {
  console.log('test');
}

test();
