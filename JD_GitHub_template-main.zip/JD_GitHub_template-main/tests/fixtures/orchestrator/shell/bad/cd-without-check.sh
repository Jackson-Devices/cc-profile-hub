#!/bin/bash
# Bad script with cd without error check (SC2164)

cd /some/directory
echo "Changed to directory"
