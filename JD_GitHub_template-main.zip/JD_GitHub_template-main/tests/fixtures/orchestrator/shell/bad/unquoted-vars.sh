#!/bin/bash
# Bad script with unquoted variables (SC2086)

files="file1.txt file2.txt file3.txt"
for file in $files; do
    echo $file
done
