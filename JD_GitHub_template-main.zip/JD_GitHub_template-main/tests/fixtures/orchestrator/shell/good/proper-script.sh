#!/bin/bash
# Good script with no issues

files=("file1.txt" "file2.txt" "file3.txt")
for file in "${files[@]}"; do
    echo "$file"
done

if cd /some/directory; then
    echo "Changed to directory"
fi
