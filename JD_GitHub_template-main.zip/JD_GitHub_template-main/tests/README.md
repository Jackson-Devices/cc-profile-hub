# Test Suite for shellcheck-apply.sh

Comprehensive test suite for the `shellcheck-apply.sh` script, implementing the Testing Strategy Decision Log requirements.

## Table of Contents

- [Overview](#overview)
- [Prerequisites](#prerequisites)
- [Running Tests](#running-tests)
- [Test Structure](#test-structure)
- [Test Categories](#test-categories)
- [Adding New Tests](#adding-new-tests)
- [Snapshot Testing](#snapshot-testing)
- [Troubleshooting](#troubleshooting)

## Overview

This test suite validates the `shellcheck-apply.sh` script's ability to automatically fix shellcheck violations using different strategies:

- **Conservative**: Minimal changes, preserves intentional word splitting
- **Balanced**: Fixes common issues while maintaining script semantics
- **Aggressive**: Maximum fixes, may break intentional word splitting

### Test Framework

- **Node.js Native Test Runner**: Built-in testing (Node 18+)
- **No external dependencies**: Uses only Node.js standard library
- **Hermetic tests**: All tests use temporary file systems
- **Snapshot support**: Output verification through snapshots

## Prerequisites

1. **Node.js 18+**: Required for native test runner

   ```bash
   node --version  # Should be 18.0.0 or higher
   ```

2. **Shellcheck**: Required for testing

   ```bash
   sudo apt-get install shellcheck
   # or
   brew install shellcheck
   ```

3. **Shellcheck-apply.sh**: The script being tested
   - Located at: `.github/scripts/shellcheck-apply.sh`
   - Must be executable: `chmod +x .github/scripts/shellcheck-apply.sh`

## Running Tests

### Basic Usage

Run all tests:

```bash
node tests/run-shellcheck-tests.js
```

### Test Runner Options

```bash
# Verbose output
node tests/run-shellcheck-tests.js --verbose

# Filter tests by pattern
node tests/run-shellcheck-tests.js --grep=conservative

# Stop on first failure
node tests/run-shellcheck-tests.js --bail

# Watch mode (re-run on changes)
node tests/run-shellcheck-tests.js --watch

# Update snapshots
node tests/run-shellcheck-tests.js --update-snapshots
# or
UPDATE_SNAPSHOTS=true node tests/run-shellcheck-tests.js
```

### Running Individual Test Files

```bash
# Run a single test file
node --test tests/integration/shellcheck-apply/conservative-strategy.test.js

# Run with spec reporter
node --test --test-reporter=spec tests/integration/shellcheck-apply/balanced-strategy.test.js
```

### Running from npm (if configured)

```bash
# Add to package.json scripts:
{
  "scripts": {
    "test:shellcheck": "node tests/run-shellcheck-tests.js",
    "test:shellcheck:verbose": "node tests/run-shellcheck-tests.js --verbose",
    "test:shellcheck:watch": "node tests/run-shellcheck-tests.js --watch"
  }
}

# Then run:
npm run test:shellcheck
```

## Test Structure

```
tests/
├── integration/
│   └── shellcheck-apply/          # End-to-end integration tests
│       ├── conservative-strategy.test.js
│       ├── balanced-strategy.test.js
│       ├── aggressive-strategy.test.js
│       ├── multi-pass.test.js
│       ├── failure-scenarios.test.js
│       └── strategy-escalation.test.js
├── unit/
│   └── shellcheck-apply/          # Unit tests (future)
│       └── (unit tests here)
├── fixtures/
│   └── mock_scripts/              # Test fixture scripts
│       ├── broken_script_sc2086.sh
│       ├── broken_script_sc2046.sh
│       ├── broken_script_sc2006.sh
│       ├── broken_script_sc2164.sh
│       ├── mixed_errors.sh
│       ├── already_clean.sh
│       └── intentional_word_splitting.sh
├── snapshots/
│   └── shellcheck-apply/          # Snapshot files
│       └── *.txt
├── helpers/                       # Test utilities
│   ├── shell-runner.js           # Script execution helpers
│   ├── temp-fs.js                # Temporary file system helpers
│   └── snapshot-matcher.js       # Snapshot testing helpers
└── run-shellcheck-tests.js       # Main test runner
```

## Test Categories

### Integration Tests

**Location**: `tests/integration/shellcheck-apply/`

End-to-end tests that run the full `shellcheck-apply.sh` script with real shellcheck.

#### Conservative Strategy Tests

- Quote variables in test contexts only
- Preserve intentional word splitting
- Handle already-clean scripts
- Backup creation and removal

#### Balanced Strategy Tests

- Fix SC2086 in common contexts (GitHub Actions variables)
- Fix multiple SC code types (SC2006, SC2046, SC2164)
- Report total fixes applied
- Verify shellcheck passes after fixes

#### Aggressive Strategy Tests

- Fix all SC2086 violations
- May break intentional word splitting
- Handle complex mixed errors

#### Multi-pass Tests

- Perform multiple passes when needed
- Respect max-passes limit
- Stop when no more fixes applied
- Show progress for each pass

#### Failure Scenario Tests

- Exit with correct error codes
- Restore backup on failure
- Handle file not found
- Handle invalid arguments
- Show remaining issues
- Dry-run mode

#### Strategy Escalation Tests

- Escalate conservative → balanced
- Escalate balanced → aggressive
- Full escalation chain
- No escalation when disabled
- Reset passes on escalation

### Unit Tests

**Location**: `tests/unit/shellcheck-apply/`

Test individual functions in isolation (to be implemented).

### Snapshot Tests

Verify output format consistency using snapshot files.

## Adding New Tests

### 1. Create a Test Fixture

If testing a new SC code or scenario:

```bash
# Create fixture in tests/fixtures/mock_scripts/
cat > tests/fixtures/mock_scripts/my_new_fixture.sh << 'EOF'
#!/bin/bash
# Description of what this fixture tests

# SC code violation here
echo $UNQUOTED_VAR
EOF

chmod +x tests/fixtures/mock_scripts/my_new_fixture.sh
```

### 2. Write the Test

Create or add to a test file:

```javascript
import { test, describe, afterEach } from 'node:test';
import assert from 'node:assert';
import { runShellcheckApply, shellcheckPasses } from '../../helpers/shell-runner.js';
import { createTempWorkspace, getFixturePath } from '../../helpers/temp-fs.js';

describe('My New Feature', () => {
  let workspace;

  afterEach(async () => {
    if (workspace) {
      await workspace.cleanup();
    }
  });

  test('should do something specific', async () => {
    // Given: Setup test conditions
    workspace = await createTempWorkspace(getFixturePath('my_new_fixture.sh'));

    // When: Perform the action
    const result = await runShellcheckApply(['--strategy=balanced', workspace.filePath], {
      cwd: workspace.tempDir,
    });

    // Then: Assert expected outcomes
    assert.strictEqual(result.exitCode, 0, 'Should succeed');

    const passes = await shellcheckPasses(workspace.filePath);
    assert.ok(passes, 'Should pass shellcheck');
  });
});
```

### 3. Test Structure: Given/When/Then

All tests follow the Given/When/Then pattern:

```javascript
test('descriptive test name', async () => {
  // Given: Setup and preconditions
  workspace = await createTempWorkspace(getFixturePath('fixture.sh'));

  // When: Execute the action being tested
  const result = await runShellcheckApply([...args], options);

  // Then: Assert expected outcomes
  assert.strictEqual(result.exitCode, 0);
  assert.ok(await shellcheckPasses(workspace.filePath));
});
```

### 4. Run Your New Test

```bash
# Run just your new test file
node --test tests/integration/shellcheck-apply/my-new-test.test.js

# Or filter by test name
node tests/run-shellcheck-tests.js --grep="should do something specific"
```

## Snapshot Testing

### Creating Snapshots

Snapshots capture and verify output format:

```javascript
import { matchSnapshot, matchOutputPatterns } from '../../helpers/snapshot-matcher.js';

// Create or update snapshot
await matchSnapshot('my-test-scenario', result.stderr);

// Or match patterns without full snapshot
matchOutputPatterns(result.stderr, ['Expected text in output', /Expected regex pattern/]);
```

### Updating Snapshots

When output format intentionally changes:

```bash
# Update all snapshots
UPDATE_SNAPSHOTS=true node tests/run-shellcheck-tests.js

# Or use the flag
node tests/run-shellcheck-tests.js --update-snapshots
```

### Snapshot Location

Snapshots are stored in: `tests/snapshots/shellcheck-apply/`

### Snapshot Naming Convention

```
<scenario-name>_output.txt
```

Examples:

- `conservative_sc2086_output.txt`
- `balanced_multi_pass_output.txt`
- `aggressive_success_output.txt`

## Test Helpers

### Shell Runner (`shell-runner.js`)

```javascript
import { runShellcheckApply, shellcheckPasses, getViolations } from '../../helpers/shell-runner.js';

// Run shellcheck-apply.sh
const result = await runShellcheckApply(['--strategy=balanced', 'file.sh']);
// Returns: { stdout, stderr, exitCode }

// Check if file passes shellcheck
const passes = await shellcheckPasses('file.sh');
// Returns: boolean

// Get violations for specific SC code
const violations = await getViolations('file.sh', 2086);
// Returns: array of violation objects
```

### Temp File System (`temp-fs.js`)

```javascript
import { createTempWorkspace, createFile, readFile } from '../../helpers/temp-fs.js';

// Create temp workspace with fixture copy
const workspace = await createTempWorkspace(getFixturePath('fixture.sh'));
// Returns: { tempDir, filePath, cleanup }

// Always cleanup after test
await workspace.cleanup();

// Create a test file
const filePath = await createFile(tempDir, 'test.sh', '#!/bin/bash\necho "test"');

// Read file content
const content = await readFile(filePath);
```

### Snapshot Matcher (`snapshot-matcher.js`)

```javascript
import {
  matchSnapshot,
  matchOutputPatterns,
  assertOutputNotContains,
} from '../../helpers/snapshot-matcher.js';

// Match full snapshot
await matchSnapshot('scenario-name', actualOutput);

// Match patterns
matchOutputPatterns(output, ['Required text', /Required pattern/]);

// Assert patterns NOT in output
assertOutputNotContains(output, ['Should not appear', /Should not match/]);
```

## Troubleshooting

### Tests Failing: "shellcheck is not installed"

```bash
# Ubuntu/Debian
sudo apt-get update
sudo apt-get install shellcheck

# macOS
brew install shellcheck

# Verify
shellcheck --version
```

### Tests Failing: "shellcheck-apply.sh not found"

```bash
# Ensure script exists
ls -la .github/scripts/shellcheck-apply.sh

# Make executable
chmod +x .github/scripts/shellcheck-apply.sh
```

### Tests Failing: "Node version too old"

```bash
# Check Node version
node --version

# Need Node 18+
# Update Node.js if needed
```

### Snapshot Mismatches

If snapshots are outdated after intentional changes:

```bash
# Update snapshots
UPDATE_SNAPSHOTS=true node tests/run-shellcheck-tests.js

# Verify the changes are correct by reviewing:
git diff tests/snapshots/
```

### Tests Hanging

- Increase timeout in test runner (default: 30s)
- Check for processes not cleaning up
- Use `--verbose` to see where tests hang

### File Permission Errors

```bash
# Make sure temp directory is writable
ls -la /tmp

# Check fixture permissions
ls -la tests/fixtures/mock_scripts/
chmod +x tests/fixtures/mock_scripts/*.sh
```

## Best Practices

1. **Always cleanup**: Use `afterEach` to cleanup temporary files
2. **Test isolation**: Each test should be independent
3. **Descriptive names**: Test names should describe what they verify
4. **Given/When/Then**: Structure tests clearly
5. **Assert specifics**: Test specific behaviors, not just "it works"
6. **Test failures**: Test both success and failure paths
7. **Mock external deps**: Use temp file systems, don't modify real files

## Examples

### Example: Testing a New SC Code Fix

```javascript
test('should fix SC9999: New shellcheck rule', async () => {
  // Given: A script with SC9999 violations
  workspace = await createTempWorkspace(getFixturePath('broken_script_sc9999.sh'));

  const initialViolations = await countViolations(workspace.filePath, 9999);
  assert.ok(initialViolations > 0, 'Should have SC9999 violations');

  // When: Running balanced strategy
  const result = await runShellcheckApply(['--strategy=balanced', workspace.filePath], {
    cwd: workspace.tempDir,
  });

  // Then: Should fix the violations
  assert.strictEqual(result.exitCode, 0, 'Should succeed');

  const finalViolations = await countViolations(workspace.filePath, 9999);
  assert.strictEqual(finalViolations, 0, 'Should fix all SC9999 violations');

  // And: File should pass shellcheck
  const passes = await shellcheckPasses(workspace.filePath);
  assert.ok(passes, 'Should pass shellcheck');
});
```

### Example: Testing Output Format

```javascript
test('should display progress information', async () => {
  // Given: A script needing fixes
  workspace = await createTempWorkspace(getFixturePath('mixed_errors.sh'));

  // When: Running with verbose flag
  const result = await runShellcheckApply(['--verbose', workspace.filePath], {
    cwd: workspace.tempDir,
  });

  // Then: Should show expected output elements
  matchOutputPatterns(result.stderr, [
    'Shellcheck Apply',
    /Strategy: balanced/,
    /=== Pass \d+ ===/,
    /Attempting to fix SC\d+/,
    /Total fixes applied: \d+/,
  ]);
});
```

## Related Documentation

- [Testing Strategy Decision Log](../.github/decisions/testing-strategy.md) - Overall testing approach
- [Orchestration Roadmap](../ORCHESTRATION_ROADMAP.md) - Phase 1a development plan
- [shellcheck-apply.sh](../.github/scripts/shellcheck-apply.sh) - The script being tested

## Contributing

When adding tests:

1. Follow the existing test structure
2. Use Given/When/Then pattern
3. Add descriptive test names
4. Ensure tests are hermetic (use temp files)
5. Clean up resources in `afterEach`
6. Update this README if adding new test categories

## License

Same as parent project.
