/**
 * Helper utility for running shell scripts in tests
 */

import { execFile } from 'node:child_process';
import { promisify } from 'node:util';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const execFileAsync = promisify(execFile);

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

// Path to the shellcheck-apply.sh script
const SHELLCHECK_APPLY_SCRIPT = path.resolve(
  __dirname,
  '../../.github/scripts/shellcheck-apply.sh'
);

/**
 * Run shellcheck-apply.sh with given arguments
 * @param {string[]} args - Arguments to pass to the script
 * @param {Object} options - Additional options
 * @param {string} options.cwd - Working directory
 * @param {Object} options.env - Environment variables
 * @param {number} options.timeout - Timeout in milliseconds (default: 10000)
 * @returns {Promise<{stdout: string, stderr: string, exitCode: number}>}
 */
export async function runShellcheckApply(args = [], options = {}) {
  const { cwd = process.cwd(), env = process.env, timeout = 10000 } = options;

  // On Windows, we need to run shell scripts through bash
  const isWindows = process.platform === 'win32';
  const command = isWindows ? 'bash' : SHELLCHECK_APPLY_SCRIPT;
  const commandArgs = isWindows ? [SHELLCHECK_APPLY_SCRIPT, ...args] : args;

  try {
    const { stdout, stderr } = await execFileAsync(command, commandArgs, {
      cwd,
      env: { ...process.env, ...env },
      timeout,
      encoding: 'utf8',
    });

    return {
      stdout,
      stderr,
      exitCode: 0,
    };
  } catch (error) {
    // execFile rejects on non-zero exit, but we want to capture the output
    return {
      stdout: error.stdout || '',
      stderr: error.stderr || '',
      exitCode: error.code || 1,
    };
  }
}

/**
 * Run shellcheck directly on a file
 * @param {string} filePath - Path to the file to check
 * @param {Object} options - Additional options
 * @returns {Promise<{stdout: string, stderr: string, exitCode: number, violations: Object[]}>}
 */
export async function runShellcheck(filePath, options = {}) {
  const { format = 'json', cwd = process.cwd() } = options;

  try {
    const { stdout, stderr } = await execFileAsync('shellcheck', [`--format=${format}`, filePath], {
      cwd,
      encoding: 'utf8',
      timeout: 5000,
    });

    let violations = [];
    if (format === 'json' && stdout) {
      try {
        violations = JSON.parse(stdout);
      } catch {
        // If parsing fails, violations remain empty
      }
    }

    return {
      stdout,
      stderr,
      exitCode: 0,
      violations,
    };
  } catch (error) {
    let violations = [];
    if (format === 'json' && error.stdout) {
      try {
        violations = JSON.parse(error.stdout);
      } catch {
        // If parsing fails, violations remain empty
      }
    }

    return {
      stdout: error.stdout || '',
      stderr: error.stderr || '',
      exitCode: error.code || 1,
      violations,
    };
  }
}

/**
 * Check if a file passes shellcheck (no violations)
 * @param {string} filePath - Path to the file to check
 * @returns {Promise<boolean>}
 */
export async function shellcheckPasses(filePath) {
  const result = await runShellcheck(filePath);
  return result.exitCode === 0 && result.violations.length === 0;
}

/**
 * Get specific SC code violations from shellcheck output
 * @param {string} filePath - Path to the file to check
 * @param {number} scCode - SC code to filter (e.g., 2086)
 * @returns {Promise<Object[]>}
 */
export async function getViolations(filePath, scCode) {
  const result = await runShellcheck(filePath);
  return result.violations.filter((v) => v.code === scCode);
}

/**
 * Count violations for a specific SC code
 * @param {string} filePath - Path to the file to check
 * @param {number} scCode - SC code to count
 * @returns {Promise<number>}
 */
export async function countViolations(filePath, scCode) {
  const violations = await getViolations(filePath, scCode);
  return violations.length;
}
