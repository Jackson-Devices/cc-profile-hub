/**
 * Helper utility for creating temporary file systems in tests
 */

import fs from 'node:fs/promises';
import fsSync from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import os from 'node:os';
import crypto from 'node:crypto';

/**
 * Create a temporary directory for testing
 * @param {string} prefix - Prefix for the temp directory name
 * @returns {Promise<string>} Path to the temporary directory
 */
export async function createTempDir(prefix = 'shellcheck-test-') {
  const tmpDir = os.tmpdir();
  const uniqueSuffix = crypto.randomBytes(8).toString('hex');
  const tempPath = path.join(tmpDir, `${prefix}${uniqueSuffix}`);

  await fs.mkdir(tempPath, { recursive: true });
  return tempPath;
}

/**
 * Copy a file to a temporary location
 * @param {string} sourcePath - Source file path
 * @param {string} destDir - Destination directory
 * @param {string} destName - Optional destination filename (defaults to source basename)
 * @returns {Promise<string>} Path to the copied file
 */
export async function copyToTemp(sourcePath, destDir, destName = null) {
  const fileName = destName || path.basename(sourcePath);
  const destPath = path.join(destDir, fileName);

  await fs.copyFile(sourcePath, destPath);
  return destPath;
}

/**
 * Create a file with specified content in a directory
 * @param {string} dirPath - Directory path
 * @param {string} fileName - File name
 * @param {string} content - File content
 * @returns {Promise<string>} Path to the created file
 */
export async function createFile(dirPath, fileName, content) {
  const filePath = path.join(dirPath, fileName);
  await fs.writeFile(filePath, content, 'utf8');

  // Make shell scripts executable
  if (fileName.endsWith('.sh')) {
    await fs.chmod(filePath, 0o755);
  }

  return filePath;
}

/**
 * Read file content
 * @param {string} filePath - File path
 * @returns {Promise<string>} File content
 */
export async function readFile(filePath) {
  return fs.readFile(filePath, 'utf8');
}

/**
 * Check if a file exists
 * @param {string} filePath - File path
 * @returns {Promise<boolean>}
 */
export async function fileExists(filePath) {
  try {
    await fs.access(filePath);
    return true;
  } catch {
    return false;
  }
}

/**
 * Check if a file exists synchronously
 * @param {string} filePath - File path
 * @returns {boolean}
 */
export function fileExistsSync(filePath) {
  return fsSync.existsSync(filePath);
}

/**
 * Clean up a temporary directory and all its contents
 * @param {string} dirPath - Directory path to remove
 * @returns {Promise<void>}
 */
export async function cleanupTempDir(dirPath) {
  try {
    await fs.rm(dirPath, { recursive: true, force: true });
  } catch (error) {
    // Ignore errors during cleanup
    console.warn(`Warning: Failed to clean up ${dirPath}:`, error.message);
  }
}

/**
 * Create a temporary workspace with a copy of a fixture file
 * Returns an object with the temp directory, file path, and cleanup function
 * @param {string} fixturePath - Path to the fixture file
 * @returns {Promise<{tempDir: string, filePath: string, cleanup: () => Promise<void>}>}
 */
export async function createTempWorkspace(fixturePath) {
  const tempDir = await createTempDir();
  const filePath = await copyToTemp(fixturePath, tempDir);

  const cleanup = async () => {
    await cleanupTempDir(tempDir);
  };

  return {
    tempDir,
    filePath,
    cleanup,
  };
}

/**
 * Get the path to a fixture file
 * @param {string} fixtureName - Name of the fixture file (e.g., 'broken_script_sc2086.sh')
 * @returns {string} Absolute path to the fixture
 */
export function getFixturePath(fixtureName) {
  const currentFilePath = fileURLToPath(import.meta.url);
  return path.resolve(path.dirname(currentFilePath), '../fixtures/mock_scripts', fixtureName);
}
