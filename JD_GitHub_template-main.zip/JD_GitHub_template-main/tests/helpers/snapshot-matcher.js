/**
 * Helper utility for snapshot testing
 */

import fs from 'node:fs/promises';
import path from 'node:path';
import assert from 'node:assert';
import { fileURLToPath } from 'node:url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const SNAPSHOTS_DIR = path.resolve(__dirname, '../snapshots/shellcheck-apply');

// Ensure snapshots directory exists
await fs.mkdir(SNAPSHOTS_DIR, { recursive: true });

/**
 * Normalize output for consistent snapshot comparison
 * - Remove timestamps
 * - Normalize paths
 * - Remove ANSI color codes
 * @param {string} output - Output to normalize
 * @returns {string} Normalized output
 */
function normalizeOutput(output) {
  return (
    output
      // Remove ANSI color codes
      // eslint-disable-next-line no-control-regex
      .replace(/\x1b\[[0-9;]*m/g, '')
      // Normalize paths (replace temp paths with <TEMP>)
      .replace(/\/tmp\/[a-zA-Z0-9-_]+/g, '<TEMP>')
      // Normalize home directory
      .replace(new RegExp(process.env.HOME || '/home/user', 'g'), '<HOME>')
      // Normalize line endings
      .replace(/\r\n/g, '\n')
      // Trim trailing whitespace on each line
      .split('\n')
      .map((line) => line.trimEnd())
      .join('\n')
      // Ensure single trailing newline
      .trimEnd() + '\n'
  );
}

/**
 * Match output against a snapshot
 * @param {string} snapshotName - Name of the snapshot file (without extension)
 * @param {string} actualOutput - Actual output to compare
 * @param {Object} options - Options
 * @param {boolean} options.update - Whether to update the snapshot (default: from env UPDATE_SNAPSHOTS)
 * @returns {Promise<void>}
 * @throws {AssertionError} If output doesn't match snapshot and not updating
 */
export async function matchSnapshot(snapshotName, actualOutput, options = {}) {
  const { update = process.env.UPDATE_SNAPSHOTS === 'true' } = options;

  const snapshotPath = path.join(SNAPSHOTS_DIR, `${snapshotName}.txt`);
  const normalizedActual = normalizeOutput(actualOutput);

  try {
    // Try to read existing snapshot
    const existingSnapshot = await fs.readFile(snapshotPath, 'utf8');

    if (update) {
      // Update mode: always write new snapshot
      await fs.writeFile(snapshotPath, normalizedActual, 'utf8');
      console.log(`✓ Updated snapshot: ${snapshotName}`);
    } else {
      // Compare mode: assert equality
      assert.strictEqual(
        normalizedActual,
        existingSnapshot,
        `Snapshot mismatch for ${snapshotName}.\n` +
          `Run with UPDATE_SNAPSHOTS=true to update.\n` +
          `Snapshot path: ${snapshotPath}`
      );
    }
  } catch (error) {
    if (error.code === 'ENOENT') {
      // Snapshot doesn't exist yet - create it
      await fs.writeFile(snapshotPath, normalizedActual, 'utf8');
      console.log(`✓ Created snapshot: ${snapshotName}`);
    } else {
      throw error;
    }
  }
}

/**
 * Match partial output against patterns
 * Useful for checking that output contains expected elements without exact matching
 * @param {string} output - Output to check
 * @param {Array<string|RegExp>} patterns - Patterns that should be present
 * @returns {void}
 * @throws {AssertionError} If any pattern is not found
 */
export function matchOutputPatterns(output, patterns) {
  const normalizedOutput = normalizeOutput(output);

  for (const pattern of patterns) {
    if (typeof pattern === 'string') {
      assert.ok(
        normalizedOutput.includes(pattern),
        `Output should contain: "${pattern}"\nActual output:\n${normalizedOutput}`
      );
    } else if (pattern instanceof RegExp) {
      assert.match(
        normalizedOutput,
        pattern,
        `Output should match pattern: ${pattern}\nActual output:\n${normalizedOutput}`
      );
    }
  }
}

/**
 * Assert that output does NOT contain certain patterns
 * @param {string} output - Output to check
 * @param {Array<string|RegExp>} patterns - Patterns that should NOT be present
 * @returns {void}
 * @throws {AssertionError} If any pattern is found
 */
export function assertOutputNotContains(output, patterns) {
  const normalizedOutput = normalizeOutput(output);

  for (const pattern of patterns) {
    if (typeof pattern === 'string') {
      assert.ok(
        !normalizedOutput.includes(pattern),
        `Output should NOT contain: "${pattern}"\nActual output:\n${normalizedOutput}`
      );
    } else if (pattern instanceof RegExp) {
      assert.doesNotMatch(
        normalizedOutput,
        pattern,
        `Output should NOT match pattern: ${pattern}\nActual output:\n${normalizedOutput}`
      );
    }
  }
}

/**
 * Get the path to a snapshot file
 * @param {string} snapshotName - Name of the snapshot
 * @returns {string} Path to the snapshot file
 */
export function getSnapshotPath(snapshotName) {
  return path.join(SNAPSHOTS_DIR, `${snapshotName}.txt`);
}
