#!/usr/bin/env node

/**
 * Test suite for issue template validation
 *
 * This script tests the validation logic from validate-issue.yml against
 * test fixtures to ensure the workflow behaves correctly without needing
 * to create real GitHub issues.
 */

import fs from 'fs/promises';
import path from 'path';
import { fileURLToPath } from 'url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

// Configuration (matching repository variables)
const IB_MIN = 1;
const OOB_MIN = 2;

// Test Results
let passed = 0;
let failed = 0;
const results = [];

/**
 * Validation logic extracted from validate-issue.yml
 */
function validateIssueBody(body) {
  const errors = [];
  const warnings = [];
  const validations = [];

  // 1. Validate Issue Body Not Empty
  if (!body || body.trim() === '') {
    errors.push('❌ Issue body is empty');
    return { errors, warnings, validations, hasErrors: true };
  }
  validations.push('✅ Issue body is not empty');

  // 2. Validate Required Sections
  const requiredSections = [
    { name: 'Test ID', pattern: /### Test ID\s*\n+(.+)/, minLength: 4 },
    {
      name: 'Suite (c1) Issue URL',
      pattern: /### Suite \(c1\) Issue URL\s*\n+(.+)/,
      minLength: 10,
    },
    {
      name: 'Parent feature/bug (p) URL',
      pattern: /### Parent feature[/]bug [(]p[)] URL\s*\n+(.+)/,
      minLength: 10,
    },
    { name: 'Purpose', pattern: /### Purpose\s*\n+([\s\S]+?)(?=\n###|$)/, minLength: 20 },
    {
      name: 'In-Bounds Case(s)',
      pattern: /### In-Bounds Case\(s\)\s*\(IB≥1\)\s*\n+([\s\S]+?)(?=\n###|$)/,
      minLength: 30,
    },
    {
      name: 'Out-of-Bounds Case(s)',
      pattern: /### Out-of-Bounds Case\(s\)\s*\(OOB≥2 required\)\s*\n+([\s\S]+?)(?=\n###|$)/,
      minLength: 30,
    },
    {
      name: 'Expected Behavior',
      pattern: /### Expected Behavior \(authoritative\)\s*\n+([\s\S]+?)(?=\n###|$)/,
      minLength: 20,
    },
    {
      name: 'Validation Method',
      pattern: /### Validation Method\s*\n+([\s\S]+?)(?=\n###|$)/,
      minLength: 20,
    },
    {
      name: 'Validation Gate',
      pattern: /### Validation Gate\s*\n+([\s\S]+?)(?=\n###|$)/,
      minLength: 10,
    },
  ];

  for (const section of requiredSections) {
    const match = body.match(section.pattern);
    if (!match || !match[1]) {
      errors.push(`❌ Missing required section: **${section.name}**`);
    } else {
      const content = match[1].trim();
      if (content === '' || content === '_No response_') {
        errors.push(`❌ Section **${section.name}** is empty or contains only placeholder text`);
      } else if (section.minLength && content.length < section.minLength) {
        errors.push(
          `❌ Section **${section.name}** content is too short (${content.length} chars, min ${section.minLength})`
        );
      } else {
        validations.push(`✅ Section present with sufficient content: ${section.name}`);
      }
    }
  }

  // 3. Validate Test ID Format
  const testIdMatch = body.match(/### Test ID\s*\n+(.+)/);
  if (testIdMatch && testIdMatch[1]) {
    const testId = testIdMatch[1].trim();
    const testIdPattern = /^T-\d{3,}$/;

    if (!testIdPattern.test(testId)) {
      errors.push(
        `❌ Invalid Test ID format: "${testId}" (expected: T-XXX where XXX is 3+ digits)`
      );
    } else {
      validations.push(`✅ Test ID format valid: ${testId}`);
    }
  }

  // 4. Validate IB/OOB Test Case Format
  const ibRegex = /(^|\n)\s*-\s*(IB-(0[1-9]|[1-9][0-9]))\b/gi;
  const oobRegex = /(^|\n)\s*-\s*(OOB-(0[1-9]|[1-9][0-9]))\b/gi;

  const ibMatches = [...body.matchAll(ibRegex)].map((m) => m[2].toUpperCase());
  const oobMatches = [...body.matchAll(oobRegex)].map((m) => m[2].toUpperCase());

  // Deduplicate
  const IB = [...new Set(ibMatches)];
  const OOB = [...new Set(oobMatches)];

  if (IB.length < IB_MIN) {
    errors.push(`❌ Insufficient IB cases: found ${IB.length}, need ≥${IB_MIN}`);
  } else {
    validations.push(`✅ IB cases: found ${IB.length} (${IB.join(', ')})`);
  }

  if (OOB.length < OOB_MIN) {
    errors.push(`❌ Insufficient OOB cases: found ${OOB.length}, need ≥${OOB_MIN}`);
  } else {
    validations.push(`✅ OOB cases: found ${OOB.length} (${OOB.join(', ')})`);
  }

  // Check for invalid format
  const invalidIBPattern = /(^|\n)\s*-\s*(IB-(?:0|[1-9](?![0-9])|[0-9]{3,}))\b/gi;
  const invalidOOBPattern = /(^|\n)\s*-\s*(OOB-(?:0|[1-9](?![0-9])|[0-9]{3,}))\b/gi;

  const invalidIB = [...body.matchAll(invalidIBPattern)].map((m) => m[2]);
  const invalidOOB = [...body.matchAll(invalidOOBPattern)].map((m) => m[2]);

  if (invalidIB.length > 0) {
    errors.push(`❌ Invalid IB format detected (must use IB-01 to IB-99): ${invalidIB.join(', ')}`);
  }
  if (invalidOOB.length > 0) {
    errors.push(
      `❌ Invalid OOB format detected (must use OOB-01 to OOB-99): ${invalidOOB.join(', ')}`
    );
  }

  // 6. Validate Validation Gate Checkbox
  const gatePattern = /- \[( |x)\]\s*✅?\s*test\.validated\s*=\s*true/i;
  const gateMatch = body.match(gatePattern);

  if (!gateMatch) {
    errors.push(
      '❌ Validation gate checkbox not found (expected format: `- [ ] ✅ test.validated = true`)'
    );
  } else {
    validations.push('✅ Validation gate checkbox present');
  }

  return {
    errors,
    warnings,
    validations,
    hasErrors: errors.length > 0,
    errorCount: errors.length,
    warningCount: warnings.length,
    passedCount: validations.length,
    ibCases: IB,
    oobCases: OOB,
  };
}

/**
 * Test a single fixture
 */
async function testFixture(fixtureName, expectedErrors) {
  const fixturePath = path.join(__dirname, 'fixtures', fixtureName);

  try {
    const body = await fs.readFile(fixturePath, 'utf-8');
    const result = validateIssueBody(body);

    let testPassed = true;
    const messages = [];

    if (expectedErrors === null) {
      // Expecting validation to pass
      if (result.hasErrors) {
        testPassed = false;
        messages.push(`  Expected: No errors`);
        messages.push(`  Actual: ${result.errorCount} errors`);
        messages.push(`  Errors:`);
        result.errors.forEach((err) => messages.push(`    - ${err}`));
      } else {
        messages.push(`  ✅ Validation passed as expected`);
        messages.push(`  Found: ${result.ibCases.length} IB, ${result.oobCases.length} OOB`);
      }
    } else {
      // Expecting specific errors
      if (!result.hasErrors) {
        testPassed = false;
        messages.push(`  Expected: Errors`);
        messages.push(`  Actual: No errors (validation passed)`);
      } else {
        // Check if expected errors are present
        const foundExpected = expectedErrors.every((expectedErr) =>
          result.errors.some((actualErr) => actualErr.includes(expectedErr))
        );

        if (!foundExpected) {
          testPassed = false;
          messages.push(`  Expected errors: ${expectedErrors.join(', ')}`);
          messages.push(`  Actual errors:`);
          result.errors.forEach((err) => messages.push(`    - ${err}`));
        } else {
          messages.push(`  ✅ Failed with expected errors`);
          result.errors.forEach((err) => messages.push(`    - ${err}`));
        }
      }
    }

    return {
      fixture: fixtureName,
      passed: testPassed,
      messages,
    };
  } catch (err) {
    return {
      fixture: fixtureName,
      passed: false,
      messages: [`  ❌ Error reading fixture: ${err.message}`],
    };
  }
}

/**
 * Run all tests
 */
async function runTests() {
  console.log('🧪 Running Issue Template Validation Tests\n');
  console.log('='.repeat(60));
  console.log('');

  const tests = [
    // Valid fixtures (expecting no errors)
    { name: 'test-valid-minimal.md', expectedErrors: null },
    { name: 'test-valid-comprehensive.md', expectedErrors: null },

    // Invalid fixtures (expecting specific errors)
    { name: 'test-invalid-no-ib.md', expectedErrors: ['Insufficient IB cases'] },
    {
      name: 'test-invalid-wrong-format.md',
      expectedErrors: ['Invalid IB format', 'Invalid OOB format'],
    },
    {
      name: 'test-invalid-too-many-digits.md',
      expectedErrors: ['Invalid IB format', 'Invalid OOB format'],
    },
    { name: 'test-invalid-insufficient-oob.md', expectedErrors: ['Insufficient OOB cases'] },
  ];

  for (const test of tests) {
    const result = await testFixture(test.name, test.expectedErrors);
    results.push(result);

    if (result.passed) {
      passed++;
      console.log(`✅ PASS: ${result.fixture}`);
    } else {
      failed++;
      console.log(`❌ FAIL: ${result.fixture}`);
    }

    result.messages.forEach((msg) => console.log(msg));
    console.log('');
  }

  console.log('='.repeat(60));
  console.log('');
  console.log(
    `📊 Test Results: ${passed}/${tests.length} passed, ${failed}/${tests.length} failed`
  );
  console.log('');

  if (failed > 0) {
    console.log('❌ Some tests failed');
    process.exit(1);
  } else {
    console.log('✅ All tests passed!');
    process.exit(0);
  }
}

// Run tests
runTests().catch((err) => {
  console.error('Fatal error:', err);
  process.exit(1);
});
