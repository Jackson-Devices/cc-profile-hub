/**
 * Issue Template Workflow Test
 *
 * Verifies that all issue templates are properly configured and functional.
 * Tests the complete hierarchy: Feature → Sub-Feature → Function → Test-Suite → Test
 */

import { test } from 'node:test';
import assert from 'node:assert';
import { readFile } from 'node:fs/promises';
import { join, dirname } from 'node:path';
import { fileURLToPath } from 'node:url';
import yaml from 'yaml';

const __dirname = dirname(fileURLToPath(import.meta.url));
const templateDir = join(__dirname, '../../.github/ISSUE_TEMPLATE');

/**
 * Helper to load and parse YAML template
 */
async function loadTemplate(filename) {
  const content = await readFile(join(templateDir, filename), 'utf8');
  return yaml.parse(content);
}

/**
 * Test Suite
 */

test('Issue Template Workflow - Complete Hierarchy', async (t) => {
  await t.test('Config file exists and is valid', async () => {
    const config = await loadTemplate('config.yml');
    assert.ok(config, 'config.yml should exist');
    assert.strictEqual(typeof config.blank_issues_enabled, 'boolean',
      'blank_issues_enabled should be boolean');
  });

  await t.test('Feature template is properly structured', async () => {
    const template = await loadTemplate('feature.yml');

    assert.strictEqual(template.name, 'Feature', 'Template name should be Feature');
    assert.ok(template.description, 'Template should have description');
    assert.ok(template.title.startsWith('FEATURE:'), 'Title should use FEATURE: prefix');
    assert.ok(Array.isArray(template.body), 'Template should have body array');

    // Verify key fields exist
    const fields = template.body.map(field => field.id).filter(Boolean);
    assert.ok(fields.includes('feature_name'), 'Should have feature_name field');
    assert.ok(fields.includes('user_outcome'), 'Should have user_outcome field');
    assert.ok(fields.includes('work_type'), 'Should have work_type dropdown');
    assert.ok(fields.includes('acceptance_criteria'), 'Should have acceptance_criteria field');
    assert.ok(fields.includes('success_metrics'), 'Should have success_metrics field');
    assert.ok(fields.includes('ready_gate'), 'Should have ready_gate checklist');

    // Verify Work Type options
    const workTypeField = template.body.find(f => f.id === 'work_type');
    assert.ok(workTypeField, 'Work type field should exist');
    assert.ok(workTypeField.attributes.options.includes('Feature (new capability)'),
      'Should have Feature option');
    assert.ok(workTypeField.attributes.options.includes('Tooling (dev tools, testing infrastructure)'),
      'Should have Tooling option');
  });

  await t.test('Sub-Feature template is properly structured', async () => {
    const template = await loadTemplate('sub-feature.yml');

    assert.strictEqual(template.name, 'Sub-Feature', 'Template name should be Sub-Feature');
    assert.ok(template.title.includes('[Parent #XXX]'), 'Title should include parent reference');
    assert.ok(template.labels.includes('Role: Sub-Feature'),
      'Should auto-apply Role: Sub-Feature label');

    const fields = template.body.map(field => field.id).filter(Boolean);
    assert.ok(fields.includes('sub_feature_name'), 'Should have sub_feature_name field');
    assert.ok(fields.includes('parent_feature'), 'Should have parent_feature link field');
    assert.ok(fields.includes('acceptance_criterion'), 'Should have acceptance_criterion field');
    assert.ok(fields.includes('ready_gate'), 'Should have ready_gate checklist');
  });

  await t.test('Function template is properly structured', async () => {
    const template = await loadTemplate('function.yml');

    assert.strictEqual(template.name, 'Function', 'Template name should be Function');
    assert.ok(template.title.includes('FUNCTION:'), 'Title should use FUNCTION: prefix');
    assert.ok(template.labels.includes('Type: Function'),
      'Should auto-apply Type: Function label');

    const fields = template.body.map(field => field.id).filter(Boolean);
    assert.ok(fields.includes('function_name'), 'Should have function_name field');
    assert.ok(fields.includes('parent_sub_feature'), 'Should have parent_sub_feature link field');
    assert.ok(fields.includes('contract_inputs'), 'Should have contract_inputs field');
    assert.ok(fields.includes('contract_outputs'), 'Should have contract_outputs field');
    assert.ok(fields.includes('preconditions'), 'Should have preconditions field');
    assert.ok(fields.includes('postconditions'), 'Should have postconditions field');
    assert.ok(fields.includes('invariants'), 'Should have invariants field');
    assert.ok(fields.includes('ready_gate'), 'Should have ready_gate checklist');
  });

  await t.test('Test-Suite template is properly structured', async () => {
    const template = await loadTemplate('test-suite.yml');

    assert.strictEqual(template.name, 'Test Suite', 'Template name should be Test Suite');
    assert.ok(template.title.includes('TEST-SUITE:'), 'Title should use TEST-SUITE: prefix');
    assert.ok(template.labels.includes('Role: Test-Suite'),
      'Should auto-apply Role: Test-Suite label');

    const fields = template.body.map(field => field.id).filter(Boolean);
    assert.ok(fields.includes('test_suite_name'), 'Should have test_suite_name field');
    assert.ok(fields.includes('parent_function'), 'Should have parent_function link field');
    assert.ok(fields.includes('test_cases_ib'), 'Should have test_cases_ib field');
    assert.ok(fields.includes('test_cases_oob'), 'Should have test_cases_oob field');
    assert.ok(fields.includes('ready_gate'), 'Should have ready_gate checklist');
  });

  await t.test('Test template is properly structured', async () => {
    const template = await loadTemplate('test.yml');

    assert.strictEqual(template.name, 'Test', 'Template name should be Test');
    assert.ok(template.title.includes('TEST:'), 'Title should use TEST: prefix');
    assert.ok(template.labels.includes('Type: Test'),
      'Should auto-apply Type: Test label');

    const fields = template.body.map(field => field.id).filter(Boolean);
    assert.ok(fields.includes('test_name'), 'Should have test_name field');
    assert.ok(fields.includes('ib_oob_classification'), 'Should have IB/OOB classification');
    assert.ok(fields.includes('test_scenario'), 'Should have test_scenario field');
    assert.ok(fields.includes('expected_behavior'), 'Should have expected_behavior field');
    assert.ok(fields.includes('test_implementation'), 'Should have test_implementation field');
    assert.ok(fields.includes('ready_gate'), 'Should have ready_gate checklist');
  });

  await t.test('All templates have required metadata', async () => {
    const templates = [
      'feature.yml',
      'sub-feature.yml',
      'function.yml',
      'test-suite.yml',
      'test.yml'
    ];

    for (const filename of templates) {
      const template = await loadTemplate(filename);

      assert.ok(template.name, `${filename} should have name`);
      assert.ok(template.description, `${filename} should have description`);
      assert.ok(template.title, `${filename} should have title`);
      assert.ok(template.labels !== undefined, `${filename} should have labels (can be empty array)`);
      assert.ok(Array.isArray(template.body), `${filename} should have body array`);
      assert.ok(template.body.length > 0, `${filename} should have at least one field`);
    }
  });

  await t.test('All templates have Ready Gate checklists', async () => {
    const templates = [
      'feature.yml',
      'sub-feature.yml',
      'function.yml',
      'test-suite.yml',
      'test.yml'
    ];

    for (const filename of templates) {
      const template = await loadTemplate(filename);
      const readyGate = template.body.find(field => field.id === 'ready_gate');

      assert.ok(readyGate, `${filename} should have ready_gate field`);
      assert.strictEqual(readyGate.type, 'checkboxes',
        `${filename} ready_gate should be checkboxes type`);
      assert.ok(readyGate.attributes.label.includes('Ready Gate'),
        `${filename} ready_gate should have appropriate label`);
      assert.ok(Array.isArray(readyGate.attributes.options),
        `${filename} ready_gate should have options array`);
      assert.ok(readyGate.attributes.options.length > 0,
        `${filename} ready_gate should have at least one option`);
    }
  });

  await t.test('Template hierarchy is consistent', async () => {
    const feature = await loadTemplate('feature.yml');
    const subFeature = await loadTemplate('sub-feature.yml');
    const func = await loadTemplate('function.yml');
    const testSuite = await loadTemplate('test-suite.yml');
    const test = await loadTemplate('test.yml');

    // Verify parent linking fields exist
    assert.ok(
      subFeature.body.some(f => f.id === 'parent_feature'),
      'Sub-Feature should have parent_feature link'
    );

    assert.ok(
      func.body.some(f => f.id === 'parent_sub_feature'),
      'Function should have parent_sub_feature link'
    );

    assert.ok(
      testSuite.body.some(f => f.id === 'parent_function'),
      'Test-Suite should have parent_function link'
    );

    assert.ok(
      test.body.some(f => f.id === 'parent_test_suite'),
      'Test should have parent_test_suite link'
    );

    // Verify title formats indicate hierarchy
    assert.ok(feature.title.startsWith('FEATURE:'), 'Feature title should start with FEATURE:');
    assert.ok(subFeature.title.startsWith('SUB-FEATURE:'), 'Sub-Feature title should start with SUB-FEATURE:');
    assert.ok(func.title.startsWith('FUNCTION:'), 'Function title should start with FUNCTION:');
    assert.ok(testSuite.title.startsWith('TEST-SUITE:'), 'Test-Suite title should start with TEST-SUITE:');
    assert.ok(test.title.startsWith('TEST:'), 'Test title should start with TEST:');

    // Verify child templates reference parent in title
    assert.ok(subFeature.title.includes('[Parent #XXX]'), 'Sub-Feature title should reference parent');
    assert.ok(func.title.includes('[Parent #XXX]'), 'Function title should reference parent');
    assert.ok(testSuite.title.includes('[Parent #XXX]'), 'Test-Suite title should reference parent');
  });

  await t.test('Feature template Work Type dropdown maps to correct labels', async () => {
    const feature = await loadTemplate('feature.yml');
    const workTypeField = feature.body.find(f => f.id === 'work_type');

    assert.ok(workTypeField, 'Work type field should exist');
    assert.strictEqual(workTypeField.type, 'dropdown', 'Work type should be dropdown');

    const expectedOptions = [
      'Feature (new capability)',
      'Bug Fix (fixes incorrect behavior)',
      'Improvement (enhances existing feature)',
      'Refactor (internal restructuring, no behavior change)',
      'Tooling (dev tools, testing infrastructure)'
    ];

    for (const option of expectedOptions) {
      assert.ok(
        workTypeField.attributes.options.includes(option),
        `Should have Work Type option: ${option}`
      );
    }
  });

  await t.test('IB/OOB classification exists in Test template', async () => {
    const test = await loadTemplate('test.yml');
    const ibOobField = test.body.find(f => f.id === 'ib_oob_classification');

    assert.ok(ibOobField, 'Test template should have IB/OOB classification field');
    assert.strictEqual(ibOobField.type, 'dropdown', 'IB/OOB classification should be dropdown');

    const options = ibOobField.attributes.options;
    assert.ok(
      options.some(opt => opt.includes('IB') || opt.includes('In-Bounds')),
      'Should have IB/In-Bounds option'
    );
    assert.ok(
      options.some(opt => opt.includes('OOB') || opt.includes('Out-of-Bounds')),
      'Should have OOB/Out-of-Bounds option'
    );
  });
});

console.log('\n✅ All issue template workflow tests passed!\n');
console.log('Templates verified:');
console.log('  - Feature template');
console.log('  - Sub-Feature template');
console.log('  - Function template');
console.log('  - Test-Suite template');
console.log('  - Test template');
console.log('  - Config file');
console.log('\nHierarchy validation: PASS');
console.log('Ready Gate checklists: PASS');
console.log('Parent linking: PASS');
console.log('Label configuration: PASS\n');
