### Test ID

T-006

### Suite (c1) Issue URL

https://github.com/Jackson-Devices/JD_GitHub_template/issues/100

### Parent feature/bug (p) URL

https://github.com/Jackson-Devices/JD_GitHub_template/issues/50

### Purpose

Comprehensive test with multiple IB/OOB cases, proper structure, and complete documentation. This represents a well-formed test issue that should pass all validation.

### In-Bounds Case(s) (IB≥1)

- IB-01: Standard Gmail address returns SUCCESS
  - **Input(s):** "user@gmail.com"
  - **Steps:**
    1. Call validateEmail("user@gmail.com")
    2. Capture return value
    3. Verify no side effects (logs, memory)
  - **Expected:** Returns SUCCESS (0), no errors, no memory leaks

- IB-02: Corporate domain with subdomain returns SUCCESS
  - **Input(s):** "john.doe@eng.company.com"
  - **Steps:**
    1. Call validateEmail("john.doe@eng.company.com")
    2. Verify DNS lookup succeeds
    3. Capture return value
  - **Expected:** Returns SUCCESS (0), DNS query made exactly once

- IB-03: International domain (.co.uk) returns SUCCESS
  - **Input(s):** "user@example.co.uk"
  - **Steps:**
    1. Call validateEmail("user@example.co.uk")
    2. Capture return value
  - **Expected:** Returns SUCCESS (0), handles TLD correctly

### Out-of-Bounds Case(s) (OOB≥2 required)

- OOB-01: Missing @ symbol returns INVALID_FORMAT
  - **Input(s):** "usergmail.com"
  - **Steps:**
    1. Call validateEmail("usergmail.com")
    2. Verify error code
    3. Check no crash or exception
  - **Expected failure/guard:** Returns INVALID_FORMAT (1), no crash

- OOB-02: NULL pointer returns ERROR_NULL_POINTER
  - **Input(s):** NULL
  - **Steps:**
    1. Call validateEmail(NULL)
    2. Verify precondition violation detected
    3. Check no memory corruption
  - **Expected failure/guard:** Returns ERROR_NULL_POINTER (3), no segfault, no memory corruption

- OOB-03: Empty string returns INVALID_FORMAT
  - **Input(s):** ""
  - **Steps:**
    1. Call validateEmail("")
    2. Verify error code
  - **Expected failure/guard:** Returns INVALID_FORMAT (1)

- OOB-04: Email exceeding max length (300 chars) returns INVALID_FORMAT
  - **Input(s):** 300-character email string (exceeds RFC 5322 254 char limit)
  - **Steps:**
    1. Generate 300-char email: "a"\*280 + "@example.com"
    2. Call validateEmail with long string
    3. Verify no buffer overflow
  - **Expected failure/guard:** Returns INVALID_FORMAT (1), no buffer overflow, no memory corruption

- OOB-05: Invalid domain (no MX records) returns INVALID_DOMAIN
  - **Input(s):** "user@invalid-domain-xyz123.fake"
  - **Steps:**
    1. Call validateEmail("user@invalid-domain-xyz123.fake")
    2. Verify DNS lookup attempted
    3. Capture return value
  - **Expected failure/guard:** Returns INVALID_DOMAIN (2), DNS query made

### Expected Behavior (authoritative)

For valid email formats (IB-01, IB-02, IB-03):

- Function returns SUCCESS (0)
- Email format matches RFC 5322
- Domain exists and has valid MX records
- No memory leaks
- No side effects (input parameter unchanged)
- Thread-safe (can be called concurrently)

For invalid inputs (OOB-01 through OOB-05):

- Function returns appropriate error codes (INVALID_FORMAT, INVALID_DOMAIN, ERROR_NULL_POINTER)
- No crashes or exceptions thrown
- No memory corruption
- No buffer overflows
- Precondition violations detected safely

### Validation Method

**Test Framework:** Unity v2.5.2 with CMock v2.5.3

**Commands:**

```bash
# Build test suite
make clean && make test_validate_email

# Run with memory checking
valgrind --leak-check=full --show-leak-kinds=all ./build/test_validate_email

# Run with address sanitizer
ASAN_OPTIONS=detect_leaks=1 ./build/test_validate_email_asan

# Measure code coverage
gcov validateEmail.c
lcov --capture --directory . --output-file coverage.info
genhtml coverage.info --output-directory coverage_html
```

**Logs/Metrics to Capture:**

- Test execution output (stdout/stderr)
- Valgrind memory report (zero leaks expected)
- Address sanitizer report (zero errors expected)
- Code coverage report (≥95% line coverage expected)
- DNS query logs (verify one query per validation)

**Pass Thresholds:**

- All assertions pass (10/10 test cases)
- Zero memory leaks detected
- Zero address sanitizer errors
- Line coverage ≥95%
- Branch coverage ≥90%

**Determinism:**

- Fixed seed: 0x12345678
- Mock DNS resolver (no real network calls)
- Timestamps mocked to: 2025-01-01T00:00:00Z

### Evidence Attachments

- [x] Logs attached/linked
- [x] Screenshots/plots attached/linked
- [x] Repro commands recorded in issue
- [x] Version/hash of DUT recorded

### Dependencies (optional)

**Test Fixtures:**

- `tests/fixtures/valid_emails.txt` - List of 100 valid email examples
- `tests/fixtures/invalid_emails.txt` - List of 200 invalid email examples

**Mock Dependencies:**

- `tests/mocks/mock_dns_resolver.c` - Deterministic DNS resolver mock
- `tests/mocks/mock_time.c` - Fixed timestamp for deterministic testing

**Required Tools:**

- Unity v2.5.2 (testing framework)
- CMock v2.5.3 (mocking framework)
- Valgrind v3.19+ (memory leak detection)
- GCC with AddressSanitizer support
- lcov v1.15+ (code coverage reporting)

**Blocked By:**

- None - all dependencies resolved

**Environment:**

- OS: Ubuntu 22.04 LTS
- Compiler: GCC 11.4.0
- CMake: 3.22+
- Network: Isolated (no external DNS calls)

### Validation Gate

- [ ] ✅ test.validated = true

---

### Run checklist

- [ ] OOB-01
- [ ] IB-01
- [ ] OOB-02
- [ ] OOB-03
- [ ] OOB-04
- [ ] OOB-05
- [ ] IB-02
- [ ] IB-03
