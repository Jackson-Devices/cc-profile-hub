### Test ID

T-002

### Suite (c1) Issue URL

https://github.com/Jackson-Devices/JD_GitHub_template/issues/100

### Parent feature/bug (p) URL

https://github.com/Jackson-Devices/JD_GitHub_template/issues/50

### Purpose

This test has OOB cases but is missing IB cases, should fail validation with insufficient IB error.

### In-Bounds Case(s) (IB≥1)

_No IB cases defined - this should cause validation error_

### Out-of-Bounds Case(s) (OOB≥2 required)

- OOB-01: Empty string returns INVALID_FORMAT
  - Input(s): ""
  - Steps: Call validateEmail("")
  - Expected failure/guard: Returns INVALID_FORMAT (1)

- OOB-02: Very long email (300 chars) returns INVALID_FORMAT
  - Input(s): 300-character string exceeding RFC 5322 limit
  - Steps: Call validateEmail with 300-char email
  - Expected failure/guard: Returns INVALID_FORMAT (1), no buffer overflow

### Expected Behavior (authoritative)

Function rejects invalid email formats with appropriate error codes.

### Validation Method

- Tool(s): Unity test framework v2.5.2
- Command(s): `make test_validate_email_oob`
- Logs/metrics to capture: Return values
- Pass threshold(s): All OOB assertions pass

### Evidence Attachments

- [ ] Logs attached/linked
- [ ] Screenshots/plots attached/linked
- [ ] Repro commands recorded in issue
- [ ] Version/hash of DUT recorded

### Dependencies (optional)

_No response_

### Validation Gate

- [ ] ✅ test.validated = true
