### Test ID

T-004

### Suite (c1) Issue URL

https://github.com/Jackson-Devices/JD_GitHub_template/issues/100

### Parent feature/bug (p) URL

https://github.com/Jackson-Devices/JD_GitHub_template/issues/50

### Purpose

This test uses invalid IB/OOB format (too many digits), should fail validation.

### In-Bounds Case(s) (IB≥1)

- IB-001: This should fail - too many digits (should be IB-01, max IB-99)
  - Input(s): "user@example.com"
  - Steps: Call validateEmail
  - Expected: SUCCESS

### Out-of-Bounds Case(s) (OOB≥2 required)

- OOB-001: This should fail - too many digits (should be OOB-01, max OOB-99)
  - Input(s): ""
  - Steps: Call validateEmail("")
  - Expected failure/guard: INVALID_FORMAT

- OOB-100: This should fail - exceeds max (valid range is OOB-01 to OOB-99)
  - Input(s): NULL
  - Steps: Call validateEmail(NULL)
  - Expected failure/guard: ERROR_NULL_POINTER

### Expected Behavior (authoritative)

Function handles valid and invalid inputs correctly.

### Validation Method

- Tool(s): Unity test framework
- Command(s): make test
- Logs/metrics to capture: Results
- Pass threshold(s): All pass

### Evidence Attachments

- [ ] Logs attached/linked
- [ ] Screenshots/plots attached/linked
- [ ] Repro commands recorded in issue
- [ ] Version/hash of DUT recorded

### Dependencies (optional)

_No response_

### Validation Gate

- [ ] ✅ test.validated = true
