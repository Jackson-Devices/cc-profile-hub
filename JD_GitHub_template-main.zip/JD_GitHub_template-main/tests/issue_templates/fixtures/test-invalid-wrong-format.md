### Test ID

T-003

### Suite (c1) Issue URL

https://github.com/Jackson-Devices/JD_GitHub_template/issues/100

### Parent feature/bug (p) URL

https://github.com/Jackson-Devices/JD_GitHub_template/issues/50

### Purpose

This test uses invalid IB/OOB format (missing leading zeros), should fail validation.

### In-Bounds Case(s) (IB≥1)

- IB-1: This should fail - missing leading zero (should be IB-01)
  - Input(s): "user@example.com"
  - Steps: Call validateEmail
  - Expected: SUCCESS

### Out-of-Bounds Case(s) (OOB≥2 required)

- OOB-1: This should fail - missing leading zero (should be OOB-01)
  - Input(s): ""
  - Steps: Call validateEmail("")
  - Expected failure/guard: INVALID_FORMAT

- OOB-2: This should fail - missing leading zero (should be OOB-02)
  - Input(s): NULL
  - Steps: Call validateEmail(NULL)
  - Expected failure/guard: ERROR_NULL_POINTER

### Expected Behavior (authoritative)

Function handles valid and invalid inputs correctly.

### Validation Method

- Tool(s): Unity test framework
- Command(s): make test
- Logs/metrics to capture: Results
- Pass threshold(s): All pass

### Evidence Attachments

- [ ] Logs attached/linked
- [ ] Screenshots/plots attached/linked
- [ ] Repro commands recorded in issue
- [ ] Version/hash of DUT recorded

### Dependencies (optional)

_No response_

### Validation Gate

- [ ] ✅ test.validated = true
