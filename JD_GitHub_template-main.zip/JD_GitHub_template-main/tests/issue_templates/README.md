# Issue Template Test Fixtures

This directory contains test fixtures for validating issue template workflows.

## Purpose

These fixtures allow testing validation workflows (`validate-issue.yml`, `enforce_test_gate.yml`) without creating real GitHub issues.

## Fixtures

### Valid Fixtures

| Fixture                       | Description                               | Expected Result      |
| ----------------------------- | ----------------------------------------- | -------------------- |
| `test-valid-minimal.md`       | Minimal valid test with 1 IB, 2 OOB       | ✅ Validation passes |
| `test-valid-comprehensive.md` | Complete test with 3 IB, 5 OOB, full docs | ✅ Validation passes |

### Invalid Fixtures

| Fixture                            | Description                         | Expected Error                  |
| ---------------------------------- | ----------------------------------- | ------------------------------- |
| `test-invalid-no-ib.md`            | Missing IB cases (0 IB, 2 OOB)      | ❌ "Insufficient IB cases"      |
| `test-invalid-wrong-format.md`     | Wrong format: IB-1 instead of IB-01 | ❌ "Invalid IB format detected" |
| `test-invalid-too-many-digits.md`  | Too many digits: IB-001, OOB-100    | ❌ "Invalid IB/OOB format"      |
| `test-invalid-insufficient-oob.md` | Only 1 OOB case (min is 2)          | ❌ "Insufficient OOB cases"     |

## Fixture Structure

Each fixture is a markdown file matching the output format of the `test.yml` issue template.

**Required Sections:**

- Test ID (format: `T-\d{3,}`)
- Suite (c1) Issue URL
- Parent feature/bug (p) URL
- Purpose
- In-Bounds Case(s) (IB≥1)
- Out-of-Bounds Case(s) (OOB≥2 required)
- Expected Behavior
- Validation Method
- Evidence Attachments (checkboxes)
- Dependencies (optional)
- Validation Gate (checkbox)

## Using Fixtures

### Manual Testing

1. Copy fixture content
2. Create new issue with `type: test` label
3. Paste fixture content into issue body
4. Observe workflow behavior

### Automated Testing

Run the test suite:

```bash
cd tests/issue_templates
npm install
npm test
```

This will:

1. Load each fixture
2. Run validation logic against it
3. Assert expected results match actual results
4. Report pass/fail for each fixture

## Test Coverage

**Validation Rules Tested:**

- ✅ IB minimum count (≥1)
- ✅ OOB minimum count (≥2)
- ✅ IB format validation (IB-01 to IB-99)
- ✅ OOB format validation (OOB-01 to OOB-99)
- ✅ Test ID format (T-XXX)
- ✅ Required sections present
- ✅ Section content length minimums
- ✅ Validation gate checkbox format

**Validation Rules NOT YET Tested:**

- ⏳ Parent/suite issue accessibility
- ⏳ Suite issue YAML validation
- ⏳ Test case markdown structure warnings
- ⏳ Duplicate test case detection

## Adding New Fixtures

1. Create new `.md` file in `fixtures/` directory
2. Follow naming convention: `test-<valid|invalid>-<description>.md`
3. Document expected behavior in this README
4. Add test case to `test_validation.mjs`

## Related Files

- **Templates:** `.github/ISSUE_TEMPLATE/test.yml`
- **Validation Workflow:** `.github/workflows/validate-issue.yml`
- **Gate Enforcement:** `.github/workflows/enforce_test_gate.yml`
- **Documentation:** `docs/workflows/test_workflow_detailed.md`
