#!/usr/bin/env node
/**
 * Test runner for shellcheck-apply.sh tests
 *
 * Usage:
 *   node tests/run-shellcheck-tests.js [options]
 *
 * Options:
 *   --verbose       Show verbose test output
 *   --watch         Watch mode (re-run on file changes)
 *   --bail          Stop on first test failure
 *   --grep=PATTERN  Only run tests matching pattern
 *   --update-snapshots  Update snapshot files
 *
 * Examples:
 *   node tests/run-shellcheck-tests.js
 *   node tests/run-shellcheck-tests.js --verbose
 *   node tests/run-shellcheck-tests.js --grep=conservative
 *   UPDATE_SNAPSHOTS=true node tests/run-shellcheck-tests.js
 */

import { run } from 'node:test';
import { spec as specReporter } from 'node:test/reporters';
import { readdir } from 'node:fs/promises';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

// Parse command line arguments
const args = process.argv.slice(2);
const options = {
  verbose: args.includes('--verbose'),
  watch: args.includes('--watch'),
  bail: args.includes('--bail'),
  updateSnapshots: args.includes('--update-snapshots') || process.env.UPDATE_SNAPSHOTS === 'true',
  grep: args.find((arg) => arg.startsWith('--grep='))?.split('=')[1],
};

// Set UPDATE_SNAPSHOTS env var if flag is present
if (options.updateSnapshots) {
  process.env.UPDATE_SNAPSHOTS = 'true';
}

// Colors for output
const colors = {
  reset: '\x1b[0m',
  bright: '\x1b[1m',
  green: '\x1b[32m',
  red: '\x1b[31m',
  yellow: '\x1b[33m',
  blue: '\x1b[34m',
  cyan: '\x1b[36m',
};

/**
 * Print colored message
 */
function log(color, message) {
  console.log(`${color}${message}${colors.reset}`);
}

/**
 * Check if shellcheck is available
 */
async function checkShellcheck() {
  try {
    const { execFile } = await import('node:child_process');
    const { promisify } = await import('node:util');
    const execFileAsync = promisify(execFile);

    await execFileAsync('shellcheck', ['--version']);
    return true;
  } catch {
    return false;
  }
}

/**
 * Find all test files
 */
async function findTestFiles() {
  const testPatterns = [
    path.join(__dirname, 'integration/shellcheck-apply/**/*.test.js'),
    path.join(__dirname, 'unit/shellcheck-apply/**/*.test.js'),
  ];

  // Recursively find test files matching patterns
  async function findFiles(dir, pattern) {
    const files = [];
    const entries = await readdir(dir, { withFileTypes: true });
    for (const entry of entries) {
      const fullPath = path.join(dir, entry.name);
      if (entry.isDirectory()) {
        files.push(...(await findFiles(fullPath, pattern)));
      } else if (entry.name.endsWith('.test.js')) {
        files.push(fullPath);
      }
    }
    return files;
  }

  const allFiles = [];
  for (const pattern of testPatterns) {
    // Handle both forward and back slashes for cross-platform support
    const baseDir = pattern.replace(/[/\\]\*\*[/\\]\*\.test\.js$/, '');
    try {
      const files = await findFiles(baseDir, pattern);
      allFiles.push(...files);
    } catch {
      // Directory doesn't exist yet, skip
    }
  }

  // Filter by grep pattern if specified
  if (options.grep) {
    const grepRegex = new RegExp(options.grep, 'i');
    return allFiles.filter((file) => grepRegex.test(file));
  }

  return allFiles;
}

/**
 * Run tests
 */
async function runTests() {
  log(colors.cyan, '\n┌─────────────────────────────────────────────────┐');
  log(colors.cyan, '│  Shellcheck-Apply Test Suite                   │');
  log(colors.cyan, '└─────────────────────────────────────────────────┘\n');

  // Check prerequisites
  log(colors.blue, '📋 Checking prerequisites...');

  const hasShellcheck = await checkShellcheck();
  if (!hasShellcheck) {
    log(colors.red, '✗ Error: shellcheck is not installed');
    log(colors.yellow, '  Install with: apt-get install shellcheck');
    process.exit(1);
  }
  log(colors.green, '✓ shellcheck is available');

  // Check if shellcheck-apply.sh exists
  const shellcheckApplyPath = path.join(__dirname, '../.github/scripts/shellcheck-apply.sh');
  const fs = await import('node:fs/promises');
  try {
    await fs.access(shellcheckApplyPath);
    log(colors.green, '✓ shellcheck-apply.sh found');
  } catch {
    log(colors.red, '✗ Error: shellcheck-apply.sh not found');
    log(colors.yellow, `  Expected at: ${shellcheckApplyPath}`);
    process.exit(1);
  }

  // Find test files
  log(colors.blue, '\n📁 Finding test files...');
  const testFiles = await findTestFiles();

  if (testFiles.length === 0) {
    log(colors.yellow, '⚠ No test files found');
    if (options.grep) {
      log(colors.yellow, `  Pattern: ${options.grep}`);
    }
    process.exit(0);
  }

  log(colors.green, `✓ Found ${testFiles.length} test file(s)`);
  if (options.verbose) {
    testFiles.forEach((file) => {
      console.log(`  - ${path.relative(__dirname, file)}`);
    });
  }

  // Show options
  if (options.updateSnapshots) {
    log(colors.yellow, '\n⚠ UPDATE_SNAPSHOTS mode enabled');
  }
  if (options.grep) {
    log(colors.blue, `\n🔍 Filtering tests: ${options.grep}`);
  }

  // Run tests
  log(colors.blue, '\n🧪 Running tests...\n');

  const testStream = run({
    files: testFiles,
    concurrency: options.watch ? 1 : true,
    watch: options.watch,
    timeout: 30000, // 30 second timeout per test
  });

  // Use spec reporter for nice output
  testStream.compose(specReporter).pipe(process.stdout);

  // Track results
  let passed = 0;
  let failed = 0;
  let skipped = 0;

  testStream.on('test:pass', () => {
    passed++;
  });

  testStream.on('test:fail', () => {
    failed++;
    if (options.bail) {
      log(colors.red, '\n✗ Stopping on first failure (--bail)');
      process.exit(1);
    }
  });

  testStream.on('test:skip', () => {
    skipped++;
  });

  // Wait for completion
  await new Promise((resolve, reject) => {
    testStream.on('end', resolve);
    testStream.on('error', reject);
  });

  // Summary
  log(colors.cyan, '\n┌─────────────────────────────────────────────────┐');
  log(colors.cyan, '│  Test Summary                                   │');
  log(colors.cyan, '└─────────────────────────────────────────────────┘\n');

  if (passed > 0) {
    log(colors.green, `✓ Passed:  ${passed}`);
  }
  if (failed > 0) {
    log(colors.red, `✗ Failed:  ${failed}`);
  }
  if (skipped > 0) {
    log(colors.yellow, `⊘ Skipped: ${skipped}`);
  }

  console.log('');

  // Exit with appropriate code
  if (failed > 0) {
    log(colors.red, '✗ Tests failed');
    process.exit(1);
  } else {
    log(colors.green, '✓ All tests passed!');
    process.exit(0);
  }
}

// Handle errors
process.on('unhandledRejection', (error) => {
  log(colors.red, '\n✗ Unhandled error:');
  console.error(error);
  process.exit(1);
});

// Show help
if (args.includes('--help') || args.includes('-h')) {
  const help = `
Test runner for shellcheck-apply.sh tests

Usage:
  node tests/run-shellcheck-tests.js [options]

Options:
  --verbose           Show verbose test output
  --watch             Watch mode (re-run on file changes)
  --bail              Stop on first test failure
  --grep=PATTERN      Only run tests matching pattern
  --update-snapshots  Update snapshot files
  --help, -h          Show this help

Examples:
  node tests/run-shellcheck-tests.js
  node tests/run-shellcheck-tests.js --verbose
  node tests/run-shellcheck-tests.js --grep=conservative
  UPDATE_SNAPSHOTS=true node tests/run-shellcheck-tests.js
  `;
  console.log(help);
  process.exit(0);
}

// Run tests
runTests().catch((error) => {
  log(colors.red, '\n✗ Fatal error:');
  console.error(error);
  process.exit(1);
});
