/**
 * Integration tests for shellcheck-apply.sh - Aggressive Strategy
 */

import { test, describe, afterEach } from 'node:test';
import assert from 'node:assert';
import { runShellcheckApply, shellcheckPasses } from '../../helpers/shell-runner.js';
import { createTempWorkspace, getFixturePath, readFile } from '../../helpers/temp-fs.js';
import { matchOutputPatterns } from '../../helpers/snapshot-matcher.js';

describe('shellcheck-apply.sh - Aggressive Strategy', () => {
  let workspace;

  afterEach(async () => {
    if (workspace) {
      await workspace.cleanup();
    }
  });

  test('should fix all SC2086 violations aggressively', async () => {
    // Given: A script with SC2086 violations
    workspace = await createTempWorkspace(getFixturePath('broken_script_sc2086.sh'));

    // When: Running with aggressive strategy
    const result = await runShellcheckApply(
      ['--strategy=aggressive', '--verbose', workspace.filePath],
      { cwd: workspace.tempDir }
    );

    // Then: Should fix aggressively
    matchOutputPatterns(result.stderr, [/strategy: aggressive/]);

    // Note: Aggressive strategy may quote ALL variables, even where not strictly needed
    const content = await readFile(workspace.filePath);
    assert.ok(content.includes('"$'), 'Should have quoted variables');
  });

  test('should pass shellcheck after aggressive fixes', async () => {
    // Given: A script with multiple issues
    workspace = await createTempWorkspace(getFixturePath('broken_script_sc2086.sh'));

    // When: Running aggressive strategy
    const result = await runShellcheckApply(['--strategy=aggressive', workspace.filePath], {
      cwd: workspace.tempDir,
    });

    // Then: Should succeed
    assert.strictEqual(result.exitCode, 0, 'Should exit with code 0');

    // And: Should pass shellcheck
    const passes = await shellcheckPasses(workspace.filePath);
    assert.ok(passes, 'File should pass shellcheck');
  });

  test('may break intentional word splitting', async () => {
    // Given: A script with intentional word splitting
    workspace = await createTempWorkspace(getFixturePath('intentional_word_splitting.sh'));

    // When: Running aggressive strategy
    await runShellcheckApply(['--strategy=aggressive', workspace.filePath], {
      cwd: workspace.tempDir,
    });

    // Then: May quote variables that were intentionally unquoted
    // This is expected behavior for aggressive strategy
    const content = await readFile(workspace.filePath);

    // Note: Aggressive strategy prioritizes passing shellcheck over preserving behavior
    // In real scenarios, this might break scripts, but they'll pass shellcheck
    assert.ok(content, 'File should be modified');
  });

  test('should handle complex mixed errors', async () => {
    // Given: A script with multiple error types
    workspace = await createTempWorkspace(getFixturePath('mixed_errors.sh'));

    const initiallyPasses = await shellcheckPasses(workspace.filePath);
    assert.strictEqual(initiallyPasses, false, 'Should initially fail');

    // When: Running aggressive strategy
    const result = await runShellcheckApply(['--strategy=aggressive', workspace.filePath], {
      cwd: workspace.tempDir,
    });

    // Then: Should fix all issues aggressively
    matchOutputPatterns(result.stderr, ['Success']);

    // And: Should pass shellcheck
    const passes = await shellcheckPasses(workspace.filePath);
    assert.ok(passes, 'File should pass shellcheck after aggressive fixes');
  });
});
