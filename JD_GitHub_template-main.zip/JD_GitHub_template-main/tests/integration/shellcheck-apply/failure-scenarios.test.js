/**
 * Integration tests for shellcheck-apply.sh - Failure Scenarios
 */

import { test, describe, afterEach } from 'node:test';
import assert from 'node:assert';
import { runShellcheckApply } from '../../helpers/shell-runner.js';
import { createTempDir, createFile, readFile, fileExists } from '../../helpers/temp-fs.js';
import { matchOutputPatterns } from '../../helpers/snapshot-matcher.js';

describe('shellcheck-apply.sh - Failure Scenarios', () => {
  let workspace;

  afterEach(async () => {
    if (workspace) {
      await workspace.cleanup();
    }
  });

  test('should exit with code 1 when fixes fail', async () => {
    // Given: A script with unfixable syntax error
    const tempDir = await createTempDir();
    workspace = {
      tempDir,
      cleanup: async () => {
        const { cleanupTempDir } = await import('../../helpers/temp-fs.js');
        await cleanupTempDir(tempDir);
      },
    };

    // Create a script with syntax errors that can't be auto-fixed
    const filePath = await createFile(
      tempDir,
      'syntax_error.sh',
      '#!/bin/bash\nif [ $VAR\necho "missing fi"'
    );

    // When: Running shellcheck-apply
    const result = await runShellcheckApply(['--strategy=balanced', filePath], { cwd: tempDir });

    // Then: Should exit with failure code
    assert.strictEqual(result.exitCode, 1, 'Should exit with code 1 on failure');

    // And: Should show failure message
    matchOutputPatterns(result.stderr, ['Failed to fix all issues']);
  });

  test('should restore backup on failure', async () => {
    // Given: A script that will fail to fix
    const tempDir = await createTempDir();
    workspace = {
      tempDir,
      cleanup: async () => {
        const { cleanupTempDir } = await import('../../helpers/temp-fs.js');
        await cleanupTempDir(tempDir);
      },
    };

    const originalContent = '#!/bin/bash\nif [ $VAR\necho "broken"';
    const filePath = await createFile(tempDir, 'unfixable.sh', originalContent);

    // When: Running shellcheck-apply (will fail)
    await runShellcheckApply(['--strategy=balanced', filePath], { cwd: tempDir });

    // Then: File should be restored to original content
    const finalContent = await readFile(filePath);
    assert.strictEqual(
      finalContent,
      originalContent,
      'File should be restored to original content on failure'
    );

    // And: Backup file should be removed
    const backupPath = `${filePath}.shellcheck-backup`;
    const backupExists = await fileExists(backupPath);
    assert.strictEqual(backupExists, false, 'Backup should be removed');
  });

  test('should exit with code 3 when file not found', async () => {
    // Given: A non-existent file path
    const tempDir = await createTempDir();
    workspace = {
      tempDir,
      cleanup: async () => {
        const { cleanupTempDir } = await import('../../helpers/temp-fs.js');
        await cleanupTempDir(tempDir);
      },
    };

    const nonExistentFile = `${tempDir}/does_not_exist.sh`;

    // When: Running shellcheck-apply on non-existent file
    const result = await runShellcheckApply([nonExistentFile], { cwd: tempDir });

    // Then: Should exit with code 3
    assert.strictEqual(result.exitCode, 3, 'Should exit with code 3 for file not found');

    // And: Should show error message
    matchOutputPatterns(result.stderr, ['File not found']);
  });

  test('should exit with code 2 for invalid arguments', async () => {
    // Given: Invalid strategy argument
    const tempDir = await createTempDir();
    workspace = {
      tempDir,
      cleanup: async () => {
        const { cleanupTempDir } = await import('../../helpers/temp-fs.js');
        await cleanupTempDir(tempDir);
      },
    };

    const filePath = await createFile(tempDir, 'test.sh', '#!/bin/bash\necho "test"');

    // When: Running with invalid strategy
    const result = await runShellcheckApply(['--strategy=invalid', filePath], { cwd: tempDir });

    // Then: Should exit with code 2
    assert.strictEqual(result.exitCode, 2, 'Should exit with code 2 for invalid arguments');

    // And: Should show error
    matchOutputPatterns(result.stderr, ['Invalid strategy']);
  });

  test('should show remaining issues on failure', async () => {
    // Given: A script with issues that can't be fixed
    const tempDir = await createTempDir();
    workspace = {
      tempDir,
      cleanup: async () => {
        const { cleanupTempDir } = await import('../../helpers/temp-fs.js');
        await cleanupTempDir(tempDir);
      },
    };

    const filePath = await createFile(
      tempDir,
      'complex_error.sh',
      '#!/bin/bash\nif [ $VAR\necho "no fi"'
    );

    // When: Running shellcheck-apply
    const result = await runShellcheckApply(['--verbose', filePath], { cwd: tempDir });

    // Then: Should show remaining issues
    matchOutputPatterns(result.stderr, ['Failed to fix all issues', 'Remaining issues:']);
  });

  test('should handle dry-run mode', async () => {
    // Given: A script with issues
    const tempDir = await createTempDir();
    workspace = {
      tempDir,
      cleanup: async () => {
        const { cleanupTempDir } = await import('../../helpers/temp-fs.js');
        await cleanupTempDir(tempDir);
      },
    };

    const originalContent = '#!/bin/bash\nif [ $VAR ]; then\n  echo "test"\nfi';
    const filePath = await createFile(tempDir, 'dryrun.sh', originalContent);

    // When: Running with --dry-run
    const result = await runShellcheckApply(['--dry-run', filePath], { cwd: tempDir });

    // Then: Should show dry run mode
    matchOutputPatterns(result.stderr, ['DRY RUN MODE', 'No changes will be made']);

    // And: File should be unchanged
    const finalContent = await readFile(filePath);
    assert.strictEqual(
      finalContent,
      originalContent,
      'File should not be modified in dry-run mode'
    );
  });
});
