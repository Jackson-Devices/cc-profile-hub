/**
 * Integration tests for shellcheck-apply.sh - Strategy Escalation
 */

import { test, describe, afterEach } from 'node:test';
import assert from 'node:assert';
import { runShellcheckApply, shellcheckPasses } from '../../helpers/shell-runner.js';
import { createTempWorkspace, getFixturePath } from '../../helpers/temp-fs.js';
import { matchOutputPatterns } from '../../helpers/snapshot-matcher.js';

describe('shellcheck-apply.sh - Strategy Escalation', () => {
  let workspace;

  afterEach(async () => {
    if (workspace) {
      await workspace.cleanup();
    }
  });

  test('should escalate from conservative to balanced when enabled', async () => {
    // Given: A script that conservative can't fully fix but balanced can
    workspace = await createTempWorkspace(getFixturePath('broken_script_sc2086.sh'));

    // When: Running with conservative + escalation
    const result = await runShellcheckApply(
      ['--strategy=conservative', '--escalate', '--verbose', workspace.filePath],
      { cwd: workspace.tempDir }
    );

    // Then: Should try conservative first
    matchOutputPatterns(result.stderr, [/strategy: conservative/]);

    // And: Should escalate to balanced
    matchOutputPatterns(result.stderr, ['Conservative strategy failed, trying balanced']);

    // And: Should show balanced strategy attempt
    matchOutputPatterns(result.stderr, [/strategy: balanced/]);
  });

  test('should escalate from balanced to aggressive when enabled', async () => {
    // Given: A script that might need aggressive fixes
    workspace = await createTempWorkspace(getFixturePath('intentional_word_splitting.sh'));

    // When: Running with balanced + escalation
    const result = await runShellcheckApply(
      ['--strategy=balanced', '--escalate', '--verbose', workspace.filePath],
      { cwd: workspace.tempDir }
    );

    // Then: May escalate to aggressive if balanced fails
    // (depends on whether balanced succeeds)
    if (result.stderr.includes('Balanced strategy failed')) {
      matchOutputPatterns(result.stderr, [
        'Balanced strategy failed, trying aggressive',
        /strategy: aggressive/,
      ]);
    }
  });

  test('should escalate from conservative through balanced to aggressive', async () => {
    // Given: A complex script
    workspace = await createTempWorkspace(getFixturePath('mixed_errors.sh'));

    // When: Running conservative with escalation
    const result = await runShellcheckApply(
      ['--strategy=conservative', '--escalate', '--verbose', workspace.filePath],
      { cwd: workspace.tempDir }
    );

    // Then: Should eventually succeed through escalation
    // The exact escalation path depends on what each strategy can fix
    const hasConservative = result.stderr.includes('strategy: conservative');
    assert.ok(hasConservative, 'Should start with conservative');

    // And: Should succeed eventually
    assert.strictEqual(result.exitCode, 0, 'Should succeed through escalation');

    // And: File should pass shellcheck
    const passes = await shellcheckPasses(workspace.filePath);
    assert.ok(passes, 'File should pass shellcheck after escalation');
  });

  test('should not escalate when escalation is disabled', async () => {
    // Given: A script that conservative might not fully fix
    workspace = await createTempWorkspace(getFixturePath('broken_script_sc2086.sh'));

    // When: Running conservative WITHOUT escalation
    const result = await runShellcheckApply(
      ['--strategy=conservative', '--verbose', workspace.filePath],
      { cwd: workspace.tempDir }
    );

    // Then: Should NOT escalate
    const hasBalanced = result.stderr.includes('trying balanced');
    const hasAggressive = result.stderr.includes('trying aggressive');

    assert.strictEqual(hasBalanced, false, 'Should not escalate to balanced');
    assert.strictEqual(hasAggressive, false, 'Should not escalate to aggressive');
  });

  test('should show success with escalated strategy', async () => {
    // Given: A script needing aggressive fixes
    workspace = await createTempWorkspace(getFixturePath('broken_script_sc2086.sh'));

    // When: Running with escalation
    const result = await runShellcheckApply(
      ['--strategy=conservative', '--escalate', workspace.filePath],
      { cwd: workspace.tempDir }
    );

    // Then: Should succeed
    assert.strictEqual(result.exitCode, 0, 'Should succeed');

    // And: Should indicate which strategy succeeded
    const hasSuccessMessage = result.stderr.includes('Success');
    assert.ok(hasSuccessMessage, 'Should show success message');

    // And: Should pass shellcheck
    const passes = await shellcheckPasses(workspace.filePath);
    assert.ok(passes, 'File should pass shellcheck');
  });

  test('should reset passes when escalating', async () => {
    // Given: A script for escalation testing
    workspace = await createTempWorkspace(getFixturePath('mixed_errors.sh'));

    // When: Running with escalation and max-passes
    const result = await runShellcheckApply(
      ['--strategy=conservative', '--escalate', '--max-passes=2', '--verbose', workspace.filePath],
      { cwd: workspace.tempDir }
    );

    // Then: Each strategy should get its own passes
    // (implementation detail: passes counter resets on escalation)

    // And: Should eventually succeed or fail gracefully
    assert.ok(
      result.exitCode === 0 || result.exitCode === 1,
      'Should exit with 0 (success) or 1 (failure after all attempts)'
    );
  });
});
