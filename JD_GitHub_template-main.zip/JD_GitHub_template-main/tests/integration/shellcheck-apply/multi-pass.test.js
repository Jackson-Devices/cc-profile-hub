/**
 * Integration tests for shellcheck-apply.sh - Multi-pass Logic
 */

import { test, describe, afterEach } from 'node:test';
import assert from 'node:assert';
import { runShellcheckApply } from '../../helpers/shell-runner.js';
import { createTempWorkspace, getFixturePath } from '../../helpers/temp-fs.js';
import { matchOutputPatterns } from '../../helpers/snapshot-matcher.js';

describe('shellcheck-apply.sh - Multi-pass Logic', () => {
  let workspace;

  afterEach(async () => {
    if (workspace) {
      await workspace.cleanup();
    }
  });

  test('should perform multiple passes if needed', async () => {
    // Given: A script with multiple issues that might need multiple passes
    workspace = await createTempWorkspace(getFixturePath('mixed_errors.sh'));

    // When: Running with verbose output
    const result = await runShellcheckApply(
      ['--strategy=balanced', '--verbose', workspace.filePath],
      { cwd: workspace.tempDir }
    );

    // Then: Should show pass information
    matchOutputPatterns(result.stderr, [/=== Pass 1/]);

    // And: May show additional passes if needed
    // (depends on whether issues can be fixed in one pass)
  });

  test('should stop after max passes', async () => {
    // Given: A script with issues
    workspace = await createTempWorkspace(getFixturePath('broken_script_sc2086.sh'));

    // When: Running with max-passes=2
    const result = await runShellcheckApply(['--max-passes=2', '--verbose', workspace.filePath], {
      cwd: workspace.tempDir,
    });

    // Then: Should not exceed 2 passes
    const passCount = (result.stderr.match(/=== Pass \d+/g) || []).length;
    assert.ok(passCount <= 2, `Should not exceed 2 passes (got ${passCount})`);
  });

  test('should stop when no more fixes are applied', async () => {
    // Given: A script with issues that can be fixed in one pass
    workspace = await createTempWorkspace(getFixturePath('broken_script_sc2006.sh'));

    // When: Running with high max-passes but fixable in fewer
    const result = await runShellcheckApply(['--max-passes=10', '--verbose', workspace.filePath], {
      cwd: workspace.tempDir,
    });

    // Then: Should stop before max when no more fixes are needed
    const passCount = (result.stderr.match(/=== Pass \d+/g) || []).length;
    assert.ok(passCount < 10, `Should stop before max passes when done (got ${passCount})`);

    // And: Should exit successfully
    assert.strictEqual(result.exitCode, 0, 'Should succeed');
  });

  test('should show progress for each pass', async () => {
    // Given: A script needing fixes
    workspace = await createTempWorkspace(getFixturePath('mixed_errors.sh'));

    // When: Running with verbose output
    const result = await runShellcheckApply(['--verbose', workspace.filePath], {
      cwd: workspace.tempDir,
    });

    // Then: Should show detailed pass information
    matchOutputPatterns(result.stderr, [
      /=== Pass \d+ \(strategy: balanced\) ===/,
      /Attempting to fix SC\d+/,
    ]);
  });

  test('should handle max-passes=1 edge case', async () => {
    // Given: A script with issues
    workspace = await createTempWorkspace(getFixturePath('broken_script_sc2086.sh'));

    // When: Running with max-passes=1
    const result = await runShellcheckApply(['--max-passes=1', '--verbose', workspace.filePath], {
      cwd: workspace.tempDir,
    });

    // Then: Should only do one pass
    const passMatches = result.stderr.match(/=== Pass \d+/g) || [];
    assert.strictEqual(passMatches.length, 1, 'Should only perform 1 pass');
  });
});
