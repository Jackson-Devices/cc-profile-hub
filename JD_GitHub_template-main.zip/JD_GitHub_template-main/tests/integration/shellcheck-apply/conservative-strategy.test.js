/**
 * Integration tests for shellcheck-apply.sh - Conservative Strategy
 */

import { test, describe, afterEach } from 'node:test';
import assert from 'node:assert';
import {
  runShellcheckApply,
  shellcheckPasses,
  countViolations,
} from '../../helpers/shell-runner.js';
import { createTempWorkspace, getFixturePath, readFile } from '../../helpers/temp-fs.js';
import { matchOutputPatterns } from '../../helpers/snapshot-matcher.js';

describe('shellcheck-apply.sh - Conservative Strategy', () => {
  let workspace;

  afterEach(async () => {
    if (workspace) {
      await workspace.cleanup();
    }
  });

  test('should quote variables in test contexts only', async () => {
    // Given: A script with SC2086 violations in test contexts
    workspace = await createTempWorkspace(getFixturePath('broken_script_sc2086.sh'));

    const initialViolations = await countViolations(workspace.filePath, 2086);
    assert.ok(initialViolations > 0, 'Fixture should have SC2086 violations');

    // When: Running with conservative strategy
    const result = await runShellcheckApply(
      ['--strategy=conservative', '--verbose', workspace.filePath],
      { cwd: workspace.tempDir }
    );

    // Then: Should fix test context variables
    matchOutputPatterns(result.stderr, [
      'Conservative strategy',
      /Attempting to fix SC2086/,
      /Pass 1/,
    ]);

    // And: Some violations should be fixed (conservative fixes fewer issues)
    const finalViolations = await countViolations(workspace.filePath, 2086);
    assert.ok(
      finalViolations < initialViolations,
      'Should fix some SC2086 violations conservatively'
    );

    // And: File content should have quoted test variables
    const content = await readFile(workspace.filePath);
    assert.match(content, /if \[ "\$USER_INPUT" \]/, 'Should quote variables in test contexts');
  });

  test('should not break intentional word splitting', async () => {
    // Given: A script with intentional word splitting
    workspace = await createTempWorkspace(getFixturePath('intentional_word_splitting.sh'));

    // When: Running with conservative strategy
    const _result = await runShellcheckApply(['--strategy=conservative', workspace.filePath], {
      cwd: workspace.tempDir,
    });

    // Then: Should preserve intentional word splitting in for loops
    const content = await readFile(workspace.filePath);
    assert.match(content, /for file in \$FILES/, 'Should preserve intentional word splitting');
  });

  test('should handle already clean scripts', async () => {
    // Given: A script that already passes shellcheck
    workspace = await createTempWorkspace(getFixturePath('already_clean.sh'));

    // When: Running conservative strategy
    const result = await runShellcheckApply(['--strategy=conservative', workspace.filePath], {
      cwd: workspace.tempDir,
    });

    // Then: Should exit successfully without changes
    assert.strictEqual(result.exitCode, 0, 'Should exit with code 0');
    matchOutputPatterns(result.stderr, ['File already passes shellcheck']);

    // And: File should still pass shellcheck
    const passes = await shellcheckPasses(workspace.filePath);
    assert.ok(passes, 'File should still pass shellcheck');
  });

  test('should create and remove backup on success', async () => {
    // Given: A script with fixable issues
    workspace = await createTempWorkspace(getFixturePath('broken_script_sc2086.sh'));

    const backupPath = `${workspace.filePath}.shellcheck-backup`;

    // When: Running conservative strategy
    await runShellcheckApply(['--strategy=conservative', '--verbose', workspace.filePath], {
      cwd: workspace.tempDir,
    });

    // Then: Backup should be removed after successful fix
    const { fileExists } = await import('../../helpers/temp-fs.js');
    const backupExists = await fileExists(backupPath);
    assert.strictEqual(backupExists, false, 'Backup should be removed on success');
  });

  test('should respect max-passes limit', async () => {
    // Given: A script with multiple issues
    workspace = await createTempWorkspace(getFixturePath('mixed_errors.sh'));

    // When: Running with max-passes=1
    const result = await runShellcheckApply(
      ['--strategy=conservative', '--max-passes=1', '--verbose', workspace.filePath],
      { cwd: workspace.tempDir }
    );

    // Then: Should only perform 1 pass
    matchOutputPatterns(result.stderr, ['=== Pass 1']);

    // And: Should NOT have Pass 2
    const hasPass2 = result.stderr.includes('=== Pass 2');
    assert.strictEqual(hasPass2, false, 'Should not perform Pass 2');
  });
});
