/**
 * Integration tests for shellcheck-apply.sh - Balanced Strategy
 */

import { test, describe, afterEach } from 'node:test';
import assert from 'node:assert';
import {
  runShellcheckApply,
  shellcheckPasses,
  countViolations,
} from '../../helpers/shell-runner.js';
import { createTempWorkspace, getFixturePath, readFile } from '../../helpers/temp-fs.js';
import { matchOutputPatterns } from '../../helpers/snapshot-matcher.js';

describe('shellcheck-apply.sh - Balanced Strategy', () => {
  let workspace;

  afterEach(async () => {
    if (workspace) {
      await workspace.cleanup();
    }
  });

  test('should fix SC2086 violations in common contexts', async () => {
    // Given: A script with SC2086 violations
    workspace = await createTempWorkspace(getFixturePath('broken_script_sc2086.sh'));

    const initialViolations = await countViolations(workspace.filePath, 2086);
    assert.ok(initialViolations > 0, 'Fixture should have SC2086 violations');

    // When: Running with balanced strategy (default)
    const result = await runShellcheckApply(['--verbose', workspace.filePath], {
      cwd: workspace.tempDir,
    });

    // Then: Should fix violations
    matchOutputPatterns(result.stderr, [/strategy: balanced/, /Attempting to fix SC2086/]);

    // And: Should fix GitHub Actions variable violations
    const content = await readFile(workspace.filePath);
    assert.match(content, />> "\$GITHUB_OUTPUT"/, 'Should quote $GITHUB_OUTPUT');
    assert.match(content, />> "\$GITHUB_STEP_SUMMARY"/, 'Should quote $GITHUB_STEP_SUMMARY');
    assert.match(content, />> "\$GITHUB_ENV"/, 'Should quote $GITHUB_ENV');
    assert.match(content, />> "\$GITHUB_PATH"/, 'Should quote $GITHUB_PATH');
  });

  test('should fix multiple SC code types', async () => {
    // Given: A script with mixed SC codes
    workspace = await createTempWorkspace(getFixturePath('mixed_errors.sh'));

    // When: Running balanced strategy
    const result = await runShellcheckApply(
      ['--strategy=balanced', '--verbose', workspace.filePath],
      { cwd: workspace.tempDir }
    );

    // Then: Should attempt to fix multiple SC codes
    matchOutputPatterns(result.stderr, [/Attempting to fix SC/]);

    const content = await readFile(workspace.filePath);

    // And: Should fix SC2086 (unquoted variables)
    assert.match(content, />> "\$GITHUB_OUTPUT"/, 'Should fix SC2086');

    // And: Should fix SC2006 (backticks)
    assert.match(content, /\$\(pwd\)/, 'Should fix SC2006 backticks');

    // And: Should fix SC2164 (cd without error handling)
    assert.match(content, /cd .* \|\| exit/, 'Should fix SC2164 cd');
  });

  test('should succeed and pass shellcheck after fixes', async () => {
    // Given: A script with fixable issues
    workspace = await createTempWorkspace(getFixturePath('broken_script_sc2006.sh'));

    const initiallyPasses = await shellcheckPasses(workspace.filePath);
    assert.strictEqual(initiallyPasses, false, 'Fixture should initially fail shellcheck');

    // When: Running balanced strategy
    const result = await runShellcheckApply(['--strategy=balanced', workspace.filePath], {
      cwd: workspace.tempDir,
    });

    // Then: Should exit successfully
    assert.strictEqual(result.exitCode, 0, 'Should exit with code 0');

    // And: File should pass shellcheck
    const passes = await shellcheckPasses(workspace.filePath);
    assert.ok(passes, 'File should pass shellcheck after fixes');

    // And: Should show success message
    matchOutputPatterns(result.stderr, ['Success', 'File passes shellcheck']);
  });

  test('should report total fixes applied', async () => {
    // Given: A script with multiple violations
    workspace = await createTempWorkspace(getFixturePath('mixed_errors.sh'));

    // When: Running balanced strategy
    const result = await runShellcheckApply(
      ['--strategy=balanced', '--verbose', workspace.filePath],
      { cwd: workspace.tempDir }
    );

    // Then: Should report total fixes
    matchOutputPatterns(result.stderr, [/Total fixes applied:/]);
  });

  test('should handle SC2164 violations', async () => {
    // Given: A script with cd commands without error handling
    workspace = await createTempWorkspace(getFixturePath('broken_script_sc2164.sh'));

    const initialViolations = await countViolations(workspace.filePath, 2164);
    assert.ok(initialViolations > 0, 'Fixture should have SC2164 violations');

    // When: Running balanced strategy
    const _result = await runShellcheckApply(['--strategy=balanced', workspace.filePath], {
      cwd: workspace.tempDir,
    });

    // Then: Should fix cd commands
    const content = await readFile(workspace.filePath);
    assert.match(content, /cd \/tmp \|\| exit/, 'Should add error handling to cd');
    assert.match(content, /cd \/some\/directory \|\| exit/, 'Should add error handling to cd');

    // And: Should preserve already-fixed cd commands
    assert.match(
      content,
      /cd \/another\/path \|\| exit 1/,
      'Should preserve existing error handling'
    );
  });
});
