/**
 * Tests for Python Module
 *
 * TDD Approach: These tests are written FIRST, before implementation
 */

import { describe, it, beforeEach, afterEach } from 'node:test';
import assert from 'node:assert';
import { mkdtemp, rm, writeFile } from 'node:fs/promises';
import { join } from 'node:path';
import { tmpdir } from 'node:os';

// Import the module we're testing (will fail initially - that's TDD!)
import PythonModule from '../../../.github/scripts/orchestrator/modules/python-module.mjs';

describe('PythonModule', () => {
  let tmpDir;
  let pythonModule;

  beforeEach(async () => {
    tmpDir = await mkdtemp(join(tmpdir(), 'python-test-'));
    pythonModule = new PythonModule();
  });

  afterEach(async () => {
    await rm(tmpDir, { recursive: true, force: true });
  });

  describe('constructor', () => {
    it('should create instance with default config', () => {
      const module = new PythonModule();
      assert.ok(module);
      assert.strictEqual(module.name, 'python');
    });

    it('should accept custom config', () => {
      const module = new PythonModule({
        enableBlack: true,
        enableMypy: true
      });
      assert.ok(module);
      assert.strictEqual(module.config.enableBlack, true);
      assert.strictEqual(module.config.enableMypy, true);
    });
  });

  describe('canHandle()', () => {
    it('should handle .py files', () => {
      assert.strictEqual(pythonModule.canHandle('test.py'), true);
      assert.strictEqual(pythonModule.canHandle('script.py'), true);
      assert.strictEqual(pythonModule.canHandle('module.py'), true);
    });

    it('should handle Python files in subdirectories', () => {
      assert.strictEqual(pythonModule.canHandle('src/main.py'), true);
      assert.strictEqual(pythonModule.canHandle('lib/utils.py'), true);
    });

    it('should not handle non-Python files', () => {
      assert.strictEqual(pythonModule.canHandle('test.js'), false);
      assert.strictEqual(pythonModule.canHandle('test.txt'), false);
      assert.strictEqual(pythonModule.canHandle('README.md'), false);
    });

    it('should handle __init__.py', () => {
      assert.strictEqual(pythonModule.canHandle('__init__.py'), true);
      assert.strictEqual(pythonModule.canHandle('src/__init__.py'), true);
    });
  });

  describe('check()', () => {
    it('should detect syntax errors', async () => {
      const file = join(tmpDir, 'syntax_error.py');
      await writeFile(file, 'def foo(\n  print("missing closing paren")\n');

      const result = await pythonModule.check([file]);

      assert.strictEqual(result.valid, false);
      assert.ok(result.issues.length > 0);
      assert.ok(result.issues[0].message.toLowerCase().includes('syntax'));
    });

    it('should pass for valid Python code', async () => {
      const file = join(tmpDir, 'valid.py');
      await writeFile(file, 'def hello():\n    print("Hello, World!")\n');

      const result = await pythonModule.check([file]);

      assert.strictEqual(result.valid, true);
      assert.strictEqual(result.issues.length, 0);
    });

    it('should detect undefined variables', async () => {
      const file = join(tmpDir, 'undefined_var.py');
      await writeFile(file, 'def foo():\n    return undefined_variable\n');

      const result = await pythonModule.check([file]);

      // Note: This requires static analysis tools like pylint
      // If tools aren't available, should gracefully skip
      assert.ok(result);
    });

    it('should detect style issues with available linters', async () => {
      const file = join(tmpDir, 'style.py');
      // Multiple style violations
      await writeFile(file, 'def   foo(  ):  # extra spaces\n    x=1+2  # no spaces around operators\n    return x\n');

      const result = await pythonModule.check([file]);

      assert.ok(result);
      // If linters available, should detect issues
    });

    it('should handle multiple files', async () => {
      const file1 = join(tmpDir, 'file1.py');
      const file2 = join(tmpDir, 'file2.py');

      await writeFile(file1, 'print("file1")\n');
      await writeFile(file2, 'print("file2")\n');

      const result = await pythonModule.check([file1, file2]);

      assert.ok(result);
      assert.strictEqual(result.filesChecked, 2);
    });

    it('should include file path in issues', async () => {
      const file = join(tmpDir, 'error.py');
      await writeFile(file, 'def foo(\n  print("error")\n');

      const result = await pythonModule.check([file]);

      assert.strictEqual(result.valid, false);
      assert.ok(result.issues[0].file);
      assert.ok(result.issues[0].file.includes('error.py'));
    });
  });

  describe('fix()', () => {
    it('should format code with black if available', async () => {
      const file = join(tmpDir, 'unformatted.py');
      // Unformatted code
      await writeFile(file, 'def   foo(  x,y,z  ):  \n    return x+y+z\n');

      const result = await pythonModule.fix([file]);

      // Should attempt to fix if black is available
      assert.ok(result);
    });

    it('should fix import order with isort if available', async () => {
      const file = join(tmpDir, 'imports.py');
      await writeFile(file, 'import sys\nimport os\nimport asyncio\n');

      const result = await pythonModule.fix([file]);

      assert.ok(result);
    });

    it('should not break valid code', async () => {
      const file = join(tmpDir, 'valid.py');
      const validCode = 'def hello(name: str) -> str:\n    """Say hello."""\n    return f"Hello, {name}!"\n';
      await writeFile(file, validCode);

      const result = await pythonModule.fix([file]);

      assert.ok(result);
      assert.strictEqual(result.valid, true);
    });

    it('should respect conservative strategy', async () => {
      const file = join(tmpDir, 'test.py');
      await writeFile(file, 'def foo():\n    pass\n');

      const result = await pythonModule.fix([file], 'conservative');

      assert.ok(result);
      // Conservative should only apply safe fixes
    });

    it('should apply more fixes with aggressive strategy', async () => {
      const file = join(tmpDir, 'test.py');
      await writeFile(file, 'def foo():\n    pass\n');

      const result = await pythonModule.fix([file], 'aggressive');

      assert.ok(result);
    });
  });

  describe('validate()', () => {
    it('should check for Python interpreter', async () => {
      const result = await pythonModule.validate();

      assert.ok(result);
      assert.ok(result.pythonAvailable !== undefined);
    });

    it('should check for linting tools', async () => {
      const result = await pythonModule.validate();

      assert.ok(result);
      // Should report which tools are available
      assert.ok('blackAvailable' in result || 'pylintAvailable' in result);
    });

    it('should return tool versions when available', async () => {
      const result = await pythonModule.validate();

      assert.ok(result);
      if (result.pythonAvailable) {
        assert.ok(result.pythonVersion);
      }
    });
  });

  describe('getSupportedStrategies()', () => {
    it('should return available strategies', () => {
      const strategies = pythonModule.getSupportedStrategies();

      assert.ok(Array.isArray(strategies));
      assert.ok(strategies.includes('default'));
    });

    it('should include conservative and aggressive', () => {
      const strategies = pythonModule.getSupportedStrategies();

      assert.ok(strategies.includes('conservative'));
      assert.ok(strategies.includes('aggressive'));
    });
  });

  describe('getInfo()', () => {
    it('should return module information', () => {
      const info = pythonModule.getInfo();

      assert.ok(info);
      assert.strictEqual(info.name, 'python');
      assert.ok(info.description);
      assert.ok(Array.isArray(info.supportedExtensions));
      assert.ok(info.supportedExtensions.includes('.py'));
    });

    it('should list capabilities', () => {
      const info = pythonModule.getInfo();

      assert.ok(info.capabilities);
      assert.ok(Array.isArray(info.capabilities));
    });
  });

  describe('Integration with tools', () => {
    it('should use black for formatting if available', async () => {
      const file = join(tmpDir, 'format.py');
      await writeFile(file, 'x={"a":1,"b":2}\n');

      const result = await pythonModule.fix([file]);

      assert.ok(result);
      // If black available, formatting should be applied
    });

    it('should use pylint for linting if available', async () => {
      const file = join(tmpDir, 'lint.py');
      await writeFile(file, 'def foo():\n    unused_var = 42\n    pass\n');

      const result = await pythonModule.check([file]);

      assert.ok(result);
      // If pylint available, should detect unused variable
    });

    it('should use mypy for type checking if configured', async () => {
      const file = join(tmpDir, 'types.py');
      await writeFile(file, 'def add(a: int, b: int) -> int:\n    return a + b\n\nadd("not", "ints")\n');

      const typeModule = new PythonModule({ enableMypy: true });
      const result = await typeModule.check([file]);

      assert.ok(result);
      // If mypy available and enabled, should detect type error
    });
  });

  describe('Error handling', () => {
    it('should handle missing files gracefully', async () => {
      const result = await pythonModule.check(['/nonexistent/file.py']);

      assert.ok(result);
      assert.strictEqual(result.valid, false);
    });

    it('should handle binary files gracefully', async () => {
      const file = join(tmpDir, 'binary.py');
      // Write binary data
      await writeFile(file, Buffer.from([0x00, 0x01, 0x02, 0xFF]));

      const result = await pythonModule.check([file]);

      assert.ok(result);
      // Should handle gracefully, not crash
    });

    it('should handle empty files', async () => {
      const file = join(tmpDir, 'empty.py');
      await writeFile(file, '');

      const result = await pythonModule.check([file]);

      assert.ok(result);
      assert.strictEqual(result.valid, true);
    });

    it('should handle very large files', async () => {
      const file = join(tmpDir, 'large.py');
      // Create a large but valid Python file
      const largeCode = 'def func():\n    pass\n'.repeat(10000);
      await writeFile(file, largeCode);

      const result = await pythonModule.check([file]);

      assert.ok(result);
    });
  });

  describe('Python-specific features', () => {
    it('should detect improper indentation', async () => {
      const file = join(tmpDir, 'indent.py');
      await writeFile(file, 'def foo():\nprint("wrong indent")\n');

      const result = await pythonModule.check([file]);

      assert.strictEqual(result.valid, false);
      assert.ok(result.issues.some(i =>
        i.message.toLowerCase().includes('indent')
      ));
    });

    it('should validate docstrings in strict mode', async () => {
      const strictModule = new PythonModule({ requireDocstrings: true });
      const file = join(tmpDir, 'nodoc.py');
      await writeFile(file, 'def foo():\n    pass\n');

      const result = await strictModule.check([file]);

      // Should warn about missing docstring if strict mode enabled
      assert.ok(result);
    });

    it('should check for security issues if bandit available', async () => {
      const file = join(tmpDir, 'security.py');
      // Potential security issue
      await writeFile(file, 'import pickle\ndata = pickle.loads(user_input)\n');

      const result = await pythonModule.check([file]);

      assert.ok(result);
      // If bandit available, might detect security issue
    });
  });
});
