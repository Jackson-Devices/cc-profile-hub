/**
 * Tests for Mermaid Module - TDD First
 */

import { describe, it, beforeEach, afterEach } from 'node:test';
import assert from 'node:assert';
import { mkdtemp, rm, writeFile } from 'node:fs/promises';
import { join } from 'node:path';
import { tmpdir } from 'node:os';

import MermaidModule from '../../../.github/scripts/orchestrator/modules/mermaid-module.mjs';

describe('MermaidModule', () => {
  let tmpDir;
  let module;

  beforeEach(async () => {
    tmpDir = await mkdtemp(join(tmpdir(), 'mermaid-test-'));
    module = new MermaidModule();
  });

  afterEach(async () => {
    await rm(tmpDir, { recursive: true, force: true });
  });

  it('should handle .mmd and .mermaid files', () => {
    assert.strictEqual(module.canHandle('diagram.mmd'), true);
    assert.strictEqual(module.canHandle('chart.mermaid'), true);
    assert.strictEqual(module.canHandle('test.md'), false);
  });

  it('should validate flowchart syntax', async () => {
    const file = join(tmpDir, 'flow.mmd');
    await writeFile(file, 'flowchart TD\n  A-->B\n');

    const result = await module.check([file]);
    assert.strictEqual(result.valid, true);
  });

  it('should detect invalid syntax', async () => {
    const file = join(tmpDir, 'invalid.mmd');
    await writeFile(file, 'invalid mermaid syntax');

    const result = await module.check([file]);
    assert.ok(result);
  });

  it('should return module info', () => {
    const info = module.getInfo();
    assert.strictEqual(info.name, 'mermaid');
    assert.ok(info.supportedExtensions.includes('.mmd'));
  });
});
