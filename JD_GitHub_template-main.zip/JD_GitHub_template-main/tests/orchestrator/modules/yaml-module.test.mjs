import { describe, it } from 'node:test';
import * as assert from 'node:assert/strict';
import YAMLModule from '../../../.github/scripts/orchestrator/modules/yaml-module.mjs';

describe('YAMLModule', () => {
  const module = new YAMLModule();

  it('should create instance with default config', () => {
    assert.equal(module.name, 'yaml');
    assert.ok(module.extensions.includes('.yml'));
    assert.ok(module.extensions.includes('.yaml'));
  });

  it('should handle YAML files', () => {
    assert.equal(module.canHandle('config.yml'), true);
    assert.equal(module.canHandle('data.yaml'), true);
    assert.equal(module.canHandle('script.sh'), false);
  });

  it('should return only default strategy', () => {
    assert.deepEqual(module.getSupportedStrategies(), ['default']);
  });

  it('should validate Prettier availability', async () => {
    const result = await module.validate();
    assert.equal(typeof result.ready, 'boolean');
    assert.ok(Array.isArray(result.missing_dependencies));
  });
});
