/**
 * Tests for CSS Module
 *
 * TDD Approach: These tests are written FIRST, before implementation
 */

import { describe, it, beforeEach, afterEach } from 'node:test';
import assert from 'node:assert';
import { mkdtemp, rm, writeFile, readFile } from 'node:fs/promises';
import { join } from 'node:path';
import { tmpdir } from 'node:os';

// Import the module we're testing (will fail initially - that's TDD!)
import CSSModule from '../../../.github/scripts/orchestrator/modules/css-module.mjs';

describe('CSSModule', () => {
  let tmpDir;
  let cssModule;

  beforeEach(async () => {
    tmpDir = await mkdtemp(join(tmpdir(), 'css-test-'));
    cssModule = new CSSModule();
  });

  afterEach(async () => {
    await rm(tmpDir, { recursive: true, force: true });
  });

  describe('constructor', () => {
    it('should create instance with default config', () => {
      const module = new CSSModule();
      assert.ok(module);
      assert.strictEqual(module.name, 'css');
    });

    it('should accept custom config', () => {
      const module = new CSSModule({
        enableStylelint: true,
        enablePrettier: false
      });
      assert.ok(module);
      assert.strictEqual(module.config.enableStylelint, true);
      assert.strictEqual(module.config.enablePrettier, false);
    });
  });

  describe('canHandle()', () => {
    it('should handle .css files', () => {
      assert.strictEqual(cssModule.canHandle('styles.css'), true);
      assert.strictEqual(cssModule.canHandle('main.css'), true);
    });

    it('should handle CSS files in subdirectories', () => {
      assert.strictEqual(cssModule.canHandle('src/styles/main.css'), true);
      assert.strictEqual(cssModule.canHandle('dist/bundle.css'), true);
    });

    it('should not handle non-CSS files', () => {
      assert.strictEqual(cssModule.canHandle('test.js'), false);
      assert.strictEqual(cssModule.canHandle('test.scss'), false);
      assert.strictEqual(cssModule.canHandle('test.less'), false);
    });

    it('should handle minified CSS', () => {
      assert.strictEqual(cssModule.canHandle('styles.min.css'), true);
    });
  });

  describe('check()', () => {
    it('should detect syntax errors', async () => {
      const file = join(tmpDir, 'syntax_error.css');
      await writeFile(file, '.class { color: red; missing-brace');

      const result = await cssModule.check([file]);

      assert.strictEqual(result.valid, false);
      assert.ok(result.issues.length > 0);
    });

    it('should pass for valid CSS', async () => {
      const file = join(tmpDir, 'valid.css');
      await writeFile(file, '.class {\n  color: red;\n  background: blue;\n}\n');

      const result = await cssModule.check([file]);

      assert.strictEqual(result.valid, true);
      assert.strictEqual(result.issues.length, 0);
    });

    it('should detect invalid property values', async () => {
      const file = join(tmpDir, 'invalid_value.css');
      await writeFile(file, '.class {\n  color: invalidcolor;\n}\n');

      const result = await cssModule.check([file]);

      // Should detect invalid color value
      assert.ok(result);
    });

    it('should detect unknown properties', async () => {
      const file = join(tmpDir, 'unknown_prop.css');
      await writeFile(file, '.class {\n  unknown-property: value;\n}\n');

      const result = await cssModule.check([file]);

      assert.ok(result);
      // May warn about unknown property
    });

    it('should detect missing semicolons', async () => {
      const file = join(tmpDir, 'missing_semi.css');
      await writeFile(file, '.class {\n  color: red\n  background: blue;\n}\n');

      const result = await cssModule.check([file]);

      assert.ok(result);
    });

    it('should handle multiple files', async () => {
      const file1 = join(tmpDir, 'file1.css');
      const file2 = join(tmpDir, 'file2.css');

      await writeFile(file1, '.class1 { color: red; }\n');
      await writeFile(file2, '.class2 { color: blue; }\n');

      const result = await cssModule.check([file1, file2]);

      assert.ok(result);
      assert.strictEqual(result.filesChecked, 2);
    });

    it('should include file path in issues', async () => {
      const file = join(tmpDir, 'error.css');
      await writeFile(file, '.class { color: ');

      const result = await cssModule.check([file]);

      assert.strictEqual(result.valid, false);
      assert.ok(result.issues[0].file);
      assert.ok(result.issues[0].file.includes('error.css'));
    });
  });

  describe('fix()', () => {
    it('should format CSS with prettier if available', async () => {
      const file = join(tmpDir, 'unformatted.css');
      await writeFile(file, '.class{color:red;background:blue;}');

      const result = await cssModule.fix([file]);

      assert.ok(result);

      const content = await readFile(file, 'utf8');
      // Should be formatted if prettier is available
      assert.ok(content);
    });

    it('should fix fixable linting issues', async () => {
      const file = join(tmpDir, 'lint.css');
      await writeFile(file, '.class {\n  color: #ff0000;\n}\n');

      const result = await cssModule.fix([file]);

      assert.ok(result);
    });

    it('should not break valid CSS', async () => {
      const file = join(tmpDir, 'valid.css');
      const validCSS = '.class {\n  color: red;\n  background: blue;\n}\n';
      await writeFile(file, validCSS);

      const result = await cssModule.fix([file]);

      assert.ok(result);
      assert.strictEqual(result.valid, true);
    });

    it('should respect conservative strategy', async () => {
      const file = join(tmpDir, 'test.css');
      await writeFile(file, '.class { color: red; }\n');

      const result = await cssModule.fix([file], 'conservative');

      assert.ok(result);
    });

    it('should apply more fixes with aggressive strategy', async () => {
      const file = join(tmpDir, 'test.css');
      await writeFile(file, '.class { color: red; }\n');

      const result = await cssModule.fix([file], 'aggressive');

      assert.ok(result);
    });
  });

  describe('validate()', () => {
    it('should return validation result', async () => {
      const result = await cssModule.validate();

      assert.ok(result);
      assert.ok('stylelintAvailable' in result || 'prettierAvailable' in result);
    });

    it('should check for CSS linting tools', async () => {
      const result = await cssModule.validate();

      assert.ok(result);
    });
  });

  describe('getSupportedStrategies()', () => {
    it('should return available strategies', () => {
      const strategies = cssModule.getSupportedStrategies();

      assert.ok(Array.isArray(strategies));
      assert.ok(strategies.includes('default'));
    });

    it('should include conservative and aggressive', () => {
      const strategies = cssModule.getSupportedStrategies();

      assert.ok(strategies.includes('conservative'));
      assert.ok(strategies.includes('aggressive'));
    });
  });

  describe('getInfo()', () => {
    it('should return module information', () => {
      const info = cssModule.getInfo();

      assert.ok(info);
      assert.strictEqual(info.name, 'css');
      assert.ok(info.description);
      assert.ok(Array.isArray(info.supportedExtensions));
      assert.ok(info.supportedExtensions.includes('.css'));
    });

    it('should list capabilities', () => {
      const info = cssModule.getInfo();

      assert.ok(info.capabilities);
      assert.ok(Array.isArray(info.capabilities));
    });
  });

  describe('CSS-specific validations', () => {
    it('should detect vendor prefix issues', async () => {
      const file = join(tmpDir, 'prefix.css');
      await writeFile(file, '.class {\n  -webkit-transform: rotate(45deg);\n}\n');

      const result = await cssModule.check([file]);

      assert.ok(result);
      // May suggest autoprefixer
    });

    it('should detect duplicate selectors', async () => {
      const file = join(tmpDir, 'duplicate.css');
      await writeFile(file, '.class { color: red; }\n.class { color: blue; }\n');

      const result = await cssModule.check([file]);

      assert.ok(result);
    });

    it('should detect empty rules', async () => {
      const file = join(tmpDir, 'empty.css');
      await writeFile(file, '.class {}\n');

      const result = await cssModule.check([file]);

      assert.ok(result);
    });

    it('should validate color formats', async () => {
      const file = join(tmpDir, 'color.css');
      await writeFile(file, '.class {\n  color: #f00;\n  background: rgb(255, 0, 0);\n}\n');

      const result = await cssModule.check([file]);

      assert.ok(result);
    });

    it('should detect shorthand property conflicts', async () => {
      const file = join(tmpDir, 'shorthand.css');
      await writeFile(file, '.class {\n  margin: 10px;\n  margin-top: 20px;\n}\n');

      const result = await cssModule.check([file]);

      assert.ok(result);
    });
  });

  describe('Error handling', () => {
    it('should handle missing files gracefully', async () => {
      const result = await cssModule.check(['/nonexistent/file.css']);

      assert.ok(result);
      assert.strictEqual(result.valid, false);
    });

    it('should handle binary files gracefully', async () => {
      const file = join(tmpDir, 'binary.css');
      await writeFile(file, Buffer.from([0x00, 0x01, 0x02, 0xFF]));

      const result = await cssModule.check([file]);

      assert.ok(result);
    });

    it('should handle empty files', async () => {
      const file = join(tmpDir, 'empty.css');
      await writeFile(file, '');

      const result = await cssModule.check([file]);

      assert.ok(result);
      assert.strictEqual(result.valid, true);
    });

    it('should handle very large CSS files', async () => {
      const file = join(tmpDir, 'large.css');
      const largeCSS = '.class { color: red; }\n'.repeat(10000);
      await writeFile(file, largeCSS);

      const result = await cssModule.check([file]);

      assert.ok(result);
    });
  });

  describe('Advanced CSS features', () => {
    it('should handle CSS Grid', async () => {
      const file = join(tmpDir, 'grid.css');
      await writeFile(file, `.container {
  display: grid;
  grid-template-columns: repeat(3, 1fr);
  grid-gap: 10px;
}
`);

      const result = await cssModule.check([file]);

      assert.ok(result);
      assert.strictEqual(result.valid, true);
    });

    it('should handle CSS custom properties', async () => {
      const file = join(tmpDir, 'custom-props.css');
      await writeFile(file, `:root {
  --main-color: #06c;
}

.class {
  color: var(--main-color);
}
`);

      const result = await cssModule.check([file]);

      assert.ok(result);
      assert.strictEqual(result.valid, true);
    });

    it('should handle modern selectors', async () => {
      const file = join(tmpDir, 'modern.css');
      await writeFile(file, `.class:not(.excluded) {
  color: red;
}

.parent > .child {
  color: blue;
}
`);

      const result = await cssModule.check([file]);

      assert.ok(result);
      assert.strictEqual(result.valid, true);
    });

    it('should handle media queries', async () => {
      const file = join(tmpDir, 'media.css');
      await writeFile(file, `@media (min-width: 768px) {
  .class {
    font-size: 16px;
  }
}
`);

      const result = await cssModule.check([file]);

      assert.ok(result);
      assert.strictEqual(result.valid, true);
    });
  });
});
