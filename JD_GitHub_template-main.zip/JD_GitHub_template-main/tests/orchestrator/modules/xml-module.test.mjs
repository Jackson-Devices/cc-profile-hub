/**
 * Tests for XML Module
 *
 * TDD Approach: These tests are written FIRST, before implementation
 */

import { describe, it, beforeEach, afterEach } from 'node:test';
import assert from 'node:assert';
import { mkdtemp, rm, writeFile, readFile } from 'node:fs/promises';
import { join } from 'node:path';
import { tmpdir } from 'node:os';

// Import the module we're testing (will fail initially - that's TDD!)
import XMLModule from '../../../.github/scripts/orchestrator/modules/xml-module.mjs';

describe('XMLModule', () => {
  let tmpDir;
  let xmlModule;

  beforeEach(async () => {
    tmpDir = await mkdtemp(join(tmpdir(), 'xml-test-'));
    xmlModule = new XMLModule();
  });

  afterEach(async () => {
    await rm(tmpDir, { recursive: true, force: true });
  });

  describe('canHandle()', () => {
    it('should handle .xml files', () => {
      assert.strictEqual(xmlModule.canHandle('data.xml'), true);
      assert.strictEqual(xmlModule.canHandle('config.xml'), true);
    });

    it('should not handle non-XML files', () => {
      assert.strictEqual(xmlModule.canHandle('test.json'), false);
      assert.strictEqual(xmlModule.canHandle('test.html'), false);
    });
  });

  describe('check()', () => {
    it('should detect malformed XML', async () => {
      const file = join(tmpDir, 'malformed.xml');
      await writeFile(file, '<root><unclosed>');

      const result = await xmlModule.check([file]);

      assert.strictEqual(result.valid, false);
      assert.ok(result.issues.length > 0);
    });

    it('should pass for well-formed XML', async () => {
      const file = join(tmpDir, 'valid.xml');
      await writeFile(file, '<?xml version="1.0"?>\n<root>\n  <element>content</element>\n</root>\n');

      const result = await xmlModule.check([file]);

      assert.strictEqual(result.valid, true);
      assert.strictEqual(result.issues.length, 0);
    });

    it('should detect mismatched tags', async () => {
      const file = join(tmpDir, 'mismatch.xml');
      await writeFile(file, '<root><element></wrong></root>');

      const result = await xmlModule.check([file]);

      assert.strictEqual(result.valid, false);
    });

    it('should handle XML with namespaces', async () => {
      const file = join(tmpDir, 'namespace.xml');
      await writeFile(file, '<root xmlns="http://example.com"><element/></root>');

      const result = await xmlModule.check([file]);

      assert.strictEqual(result.valid, true);
    });
  });

  describe('fix()', () => {
    it('should format XML', async () => {
      const file = join(tmpDir, 'unformatted.xml');
      await writeFile(file, '<root><element>content</element></root>');

      await xmlModule.fix([file]);

      const content = await readFile(file, 'utf8');
      assert.ok(content.includes('\n')); // Should be formatted
    });
  });

  describe('getInfo()', () => {
    it('should return module information', () => {
      const info = xmlModule.getInfo();

      assert.strictEqual(info.name, 'xml');
      assert.ok(info.supportedExtensions.includes('.xml'));
    });
  });
});
