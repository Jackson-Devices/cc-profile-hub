/**
 * Tests for n8n Module - TDD First
 */

import { describe, it, beforeEach, afterEach } from 'node:test';
import assert from 'node:assert';
import { mkdtemp, rm, writeFile } from 'node:fs/promises';
import { join } from 'node:path';
import { tmpdir } from 'node:os';

import N8nModule from '../../../.github/scripts/orchestrator/modules/n8n-module.mjs';

describe('N8nModule', () => {
  let tmpDir;
  let module;

  beforeEach(async () => {
    tmpDir = await mkdtemp(join(tmpdir(), 'n8n-test-'));
    module = new N8nModule();
  });

  afterEach(async () => {
    await rm(tmpDir, { recursive: true, force: true });
  });

  it('should handle n8n workflow files', () => {
    assert.strictEqual(module.canHandle('workflow.json'), true);
    assert.strictEqual(module.canHandle('test.txt'), false);
  });

  it('should validate n8n workflow structure', async () => {
    const file = join(tmpDir, 'workflow.json');
    await writeFile(file, JSON.stringify({
      name: 'Test Workflow',
      nodes: [],
      connections: {}
    }));

    const result = await module.check([file]);
    assert.strictEqual(result.valid, true);
  });

  it('should detect invalid workflow', async () => {
    const file = join(tmpDir, 'invalid.json');
    await writeFile(file, '{"invalid": "structure"}');

    const result = await module.check([file]);
    assert.ok(result);
  });

  it('should return module info', () => {
    const info = module.getInfo();
    assert.strictEqual(info.name, 'n8n');
  });
});
