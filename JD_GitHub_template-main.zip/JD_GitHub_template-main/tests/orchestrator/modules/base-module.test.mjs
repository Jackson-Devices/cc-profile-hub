/**
 * Tests for BaseModule interface
 *
 * @module base-module.test
 */

import { describe, it, before } from 'node:test';
import * as assert from 'node:assert/strict';
import BaseModule from '../../../.github/scripts/orchestrator/modules/base-module.mjs';

/**
 * Concrete implementation for testing
 * This class implements the required abstract methods
 */
class ConcreteModule extends BaseModule {
  constructor(name = 'test-module', config = {}) {
    super(name, config);
    this.checkCalls = [];
    this.fixCalls = [];
  }

  async check(files, options = {}) {
    this.checkCalls.push({ files, options });
    return this.formatCheckResult(true, [], {
      tool_version: '1.0.0',
      duration_ms: 100,
    });
  }

  async fix(files, strategy = 'balanced', options = {}) {
    this.fixCalls.push({ files, strategy, options });
    return this.formatFixResult(true, files, files.length, strategy, {
      duration_ms: 200,
    });
  }
}

/**
 * Incomplete module that doesn't implement required methods
 */
class IncompleteModule extends BaseModule {
  // Missing check() and fix() implementations
}

describe('BaseModule', () => {
  describe('Constructor', () => {
    it('should require a name', () => {
      assert.throws(
        () => new BaseModule(),
        /Module name is required/,
        'Should throw error when name is missing'
      );
    });

    it('should create instance with valid name', () => {
      const module = new ConcreteModule('test');
      assert.equal(module.name, 'test');
    });

    it('should store config', () => {
      const config = {
        extensions: ['.sh'],
        enabled: true,
      };
      const module = new ConcreteModule('test', config);
      assert.deepEqual(module.config, config);
    });

    it('should extract extensions from config', () => {
      const module = new ConcreteModule('test', {
        extensions: ['.sh', '.bash'],
      });
      assert.deepEqual(module.extensions, ['.sh', '.bash']);
    });

    it('should default to empty extensions array', () => {
      const module = new ConcreteModule('test');
      assert.deepEqual(module.extensions, []);
    });

    it('should default enabled to true', () => {
      const module = new ConcreteModule('test');
      assert.equal(module.enabled, true);
    });

    it('should respect enabled: false in config', () => {
      const module = new ConcreteModule('test', { enabled: false });
      assert.equal(module.enabled, false);
    });
  });

  describe('Abstract Methods', () => {
    it('should throw error if check() not implemented', async () => {
      const module = new IncompleteModule('incomplete');
      await assert.rejects(
        async () => await module.check(['file.txt']),
        /check\(\) must be implemented/,
        'Should throw error when check() is not implemented'
      );
    });

    it('should throw error if fix() not implemented', async () => {
      const module = new IncompleteModule('incomplete');
      await assert.rejects(
        async () => await module.fix(['file.txt']),
        /fix\(\) must be implemented/,
        'Should throw error when fix() is not implemented'
      );
    });

    it('should include class name in error message', async () => {
      const module = new IncompleteModule('incomplete');
      try {
        await module.check(['file.txt']);
        assert.fail('Should have thrown error');
      } catch (error) {
        assert.match(error.message, /IncompleteModule/);
      }
    });
  });

  describe('check() method', () => {
    it('should accept files and options', async () => {
      const module = new ConcreteModule('test');
      const files = ['file1.sh', 'file2.sh'];
      const options = { verbose: true };

      await module.check(files, options);

      assert.equal(module.checkCalls.length, 1);
      assert.deepEqual(module.checkCalls[0].files, files);
      assert.deepEqual(module.checkCalls[0].options, options);
    });

    it('should return CheckResult structure', async () => {
      const module = new ConcreteModule('test');
      const result = await module.check(['file.sh']);

      assert.equal(typeof result, 'object');
      assert.equal(typeof result.success, 'boolean');
      assert.ok(Array.isArray(result.issues));
      assert.equal(typeof result.metadata, 'object');
    });

    it('should include metadata in result', async () => {
      const module = new ConcreteModule('test');
      const result = await module.check(['file.sh']);

      assert.equal(result.metadata.tool_version, '1.0.0');
      assert.equal(result.metadata.duration_ms, 100);
    });
  });

  describe('fix() method', () => {
    it('should accept files, strategy, and options', async () => {
      const module = new ConcreteModule('test');
      const files = ['file1.sh', 'file2.sh'];
      const strategy = 'aggressive';
      const options = { dry_run: true };

      await module.fix(files, strategy, options);

      assert.equal(module.fixCalls.length, 1);
      assert.deepEqual(module.fixCalls[0].files, files);
      assert.equal(module.fixCalls[0].strategy, 'aggressive');
      assert.deepEqual(module.fixCalls[0].options, options);
    });

    it('should default to balanced strategy', async () => {
      const module = new ConcreteModule('test');
      await module.fix(['file.sh']);

      assert.equal(module.fixCalls[0].strategy, 'balanced');
    });

    it('should return FixResult structure', async () => {
      const module = new ConcreteModule('test');
      const result = await module.fix(['file.sh']);

      assert.equal(typeof result, 'object');
      assert.equal(typeof result.success, 'boolean');
      assert.ok(Array.isArray(result.files_modified));
      assert.equal(typeof result.fixes_applied, 'number');
      assert.equal(typeof result.metadata, 'object');
    });

    it('should include strategy in metadata', async () => {
      const module = new ConcreteModule('test');
      const result = await module.fix(['file.sh'], 'conservative');

      assert.equal(result.metadata.strategy, 'conservative');
    });
  });

  describe('validate() method', () => {
    it('should return ready by default', async () => {
      const module = new ConcreteModule('test');
      const result = await module.validate();

      assert.equal(result.ready, true);
      assert.deepEqual(result.missing_dependencies, []);
    });

    it('can be overridden by subclass', async () => {
      class CustomModule extends ConcreteModule {
        async validate() {
          return {
            ready: false,
            missing_dependencies: ['shellcheck'],
            error: 'shellcheck not installed',
          };
        }
      }

      const module = new CustomModule('custom');
      const result = await module.validate();

      assert.equal(result.ready, false);
      assert.deepEqual(result.missing_dependencies, ['shellcheck']);
      assert.equal(result.error, 'shellcheck not installed');
    });
  });

  describe('getSupportedStrategies() method', () => {
    it('should return default strategies', () => {
      const module = new ConcreteModule('test');
      const strategies = module.getSupportedStrategies();

      assert.deepEqual(strategies, ['conservative', 'balanced', 'aggressive']);
    });

    it('can be overridden by subclass', () => {
      class CustomModule extends ConcreteModule {
        getSupportedStrategies() {
          return ['default'];
        }
      }

      const module = new CustomModule('custom');
      const strategies = module.getSupportedStrategies();

      assert.deepEqual(strategies, ['default']);
    });
  });

  describe('canHandle() method', () => {
    it('should return true for matching extension', () => {
      const module = new ConcreteModule('test', {
        extensions: ['.sh', '.bash'],
      });

      assert.equal(module.canHandle('script.sh'), true);
      assert.equal(module.canHandle('script.bash'), true);
    });

    it('should return false for non-matching extension', () => {
      const module = new ConcreteModule('test', {
        extensions: ['.sh', '.bash'],
      });

      assert.equal(module.canHandle('script.js'), false);
      assert.equal(module.canHandle('script.py'), false);
    });

    it('should handle files with no extension', () => {
      const module = new ConcreteModule('test', {
        extensions: ['.sh'],
      });

      assert.equal(module.canHandle('Makefile'), false);
    });

    it('should handle empty filename', () => {
      const module = new ConcreteModule('test', {
        extensions: ['.sh'],
      });

      assert.equal(module.canHandle(''), false);
      assert.equal(module.canHandle(null), false);
      assert.equal(module.canHandle(undefined), false);
    });

    it('should handle files with multiple dots', () => {
      const module = new ConcreteModule('test', {
        extensions: ['.test.js'],
      });

      assert.equal(module.canHandle('script.test.js'), true);
    });

    it('should handle paths with directories', () => {
      const module = new ConcreteModule('test', {
        extensions: ['.sh'],
      });

      assert.equal(module.canHandle('path/to/script.sh'), true);
      assert.equal(module.canHandle('/absolute/path/script.sh'), true);
    });
  });

  describe('getInfo() method', () => {
    it('should return module information', () => {
      const module = new ConcreteModule('test', {
        extensions: ['.sh', '.bash'],
        enabled: true,
      });

      const info = module.getInfo();

      assert.equal(info.name, 'test');
      assert.equal(info.enabled, true);
      assert.deepEqual(info.extensions, ['.sh', '.bash']);
      assert.deepEqual(info.strategies, ['conservative', 'balanced', 'aggressive']);
    });
  });

  describe('withTimeout() utility', () => {
    it('should execute function without timeout', async () => {
      const module = new ConcreteModule('test');
      const result = await module.withTimeout(async () => 'success', 0);

      assert.equal(result, 'success');
    });

    it('should execute function within timeout', async () => {
      const module = new ConcreteModule('test');
      const result = await module.withTimeout(
        async () => {
          await new Promise((resolve) => setTimeout(resolve, 10));
          return 'success';
        },
        1000
      );

      assert.equal(result, 'success');
    });

    it('should reject on timeout', async () => {
      const module = new ConcreteModule('test');

      await assert.rejects(
        async () =>
          await module.withTimeout(
            async () => {
              await new Promise((resolve) => setTimeout(resolve, 200));
              return 'success';
            },
            50
          ),
        /Operation timed out after 50ms/,
        'Should timeout after specified duration'
      );
    });

    it('should include timeout duration in error message', async () => {
      const module = new ConcreteModule('test');

      try {
        await module.withTimeout(
          async () => {
            await new Promise((resolve) => setTimeout(resolve, 200));
          },
          100
        );
        assert.fail('Should have thrown timeout error');
      } catch (error) {
        assert.match(error.message, /100ms/);
      }
    });
  });

  describe('formatCheckResult() utility', () => {
    it('should format check result with all fields', () => {
      const module = new ConcreteModule('test');
      const issues = [
        {
          file: 'test.sh',
          line: 10,
          code: 'SC2086',
          severity: 'warning',
          message: 'Quote variable',
        },
      ];

      const result = module.formatCheckResult(false, issues, {
        tool_version: '1.2.3',
        duration_ms: 500,
      });

      assert.equal(result.success, false);
      assert.deepEqual(result.issues, issues);
      assert.equal(result.metadata.tool_version, '1.2.3');
      assert.equal(result.metadata.duration_ms, 500);
    });

    it('should handle missing issues array', () => {
      const module = new ConcreteModule('test');
      const result = module.formatCheckResult(true, null);

      assert.equal(result.success, true);
      assert.deepEqual(result.issues, []);
    });

    it('should provide default metadata values', () => {
      const module = new ConcreteModule('test');
      const result = module.formatCheckResult(true, []);

      assert.equal(result.metadata.tool_version, 'unknown');
      assert.equal(result.metadata.duration_ms, 0);
    });

    it('should allow custom metadata fields', () => {
      const module = new ConcreteModule('test');
      const result = module.formatCheckResult(true, [], {
        tool_version: '2.0.0',
        custom_field: 'custom_value',
      });

      assert.equal(result.metadata.custom_field, 'custom_value');
    });
  });

  describe('formatFixResult() utility', () => {
    it('should format fix result with all fields', () => {
      const module = new ConcreteModule('test');
      const files = ['test1.sh', 'test2.sh'];

      const result = module.formatFixResult(true, files, 5, 'aggressive', {
        duration_ms: 1000,
      });

      assert.equal(result.success, true);
      assert.deepEqual(result.files_modified, files);
      assert.equal(result.fixes_applied, 5);
      assert.equal(result.metadata.strategy, 'aggressive');
      assert.equal(result.metadata.duration_ms, 1000);
    });

    it('should handle missing files array', () => {
      const module = new ConcreteModule('test');
      const result = module.formatFixResult(true, null, 0, 'balanced');

      assert.equal(result.success, true);
      assert.deepEqual(result.files_modified, []);
    });

    it('should provide default values', () => {
      const module = new ConcreteModule('test');
      const result = module.formatFixResult(true);

      assert.equal(result.success, true);
      assert.deepEqual(result.files_modified, []);
      assert.equal(result.fixes_applied, 0);
      assert.equal(result.metadata.strategy, 'balanced');
      assert.equal(result.metadata.duration_ms, 0);
    });

    it('should allow custom metadata fields', () => {
      const module = new ConcreteModule('test');
      const result = module.formatFixResult(true, [], 0, 'balanced', {
        custom_field: 'custom_value',
      });

      assert.equal(result.metadata.custom_field, 'custom_value');
    });
  });
});
