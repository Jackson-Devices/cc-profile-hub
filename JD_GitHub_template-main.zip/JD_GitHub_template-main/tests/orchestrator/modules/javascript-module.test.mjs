import { describe, it } from 'node:test';
import * as assert from 'node:assert/strict';
import JavaScriptModule from '../../../.github/scripts/orchestrator/modules/javascript-module.mjs';

describe('JavaScriptModule', () => {
  const module = new JavaScriptModule();

  it('should create instance with default config', () => {
    assert.equal(module.name, 'javascript');
    assert.ok(module.extensions.includes('.js'));
    assert.ok(module.extensions.includes('.mjs'));
    assert.ok(module.extensions.includes('.ts'));
  });

  it('should handle JavaScript files', () => {
    assert.equal(module.canHandle('index.js'), true);
    assert.equal(module.canHandle('module.mjs'), true);
    assert.equal(module.canHandle('App.tsx'), true);
    assert.equal(module.canHandle('script.sh'), false);
  });

  it('should return only default strategy', () => {
    assert.deepEqual(module.getSupportedStrategies(), ['default']);
  });

  it('should parse ESLint JSON output', () => {
    const json = JSON.stringify([{
      filePath: 'test.js',
      messages: [{
        line: 1,
        column: 5,
        ruleId: 'no-unused-vars',
        severity: 2,
        message: 'unused variable'
      }]
    }]);

    const issues = module.parseESLintOutput(json);
    assert.equal(issues.length, 1);
    assert.equal(issues[0].code, 'no-unused-vars');
    assert.equal(issues[0].severity, 'error');
  });

  it('should map severity correctly', () => {
    assert.equal(module.mapSeverity(1), 'warning');
    assert.equal(module.mapSeverity(2), 'error');
  });

  it('should validate ESLint availability', async () => {
    const result = await module.validate();
    assert.equal(typeof result.ready, 'boolean');
    assert.ok(Array.isArray(result.missing_dependencies));
  });
});
