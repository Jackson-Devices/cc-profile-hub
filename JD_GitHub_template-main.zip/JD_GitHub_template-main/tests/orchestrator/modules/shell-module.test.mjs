/**
 * Tests for Shell Module
 *
 * @module shell-module.test
 */

import { describe, it, before, after } from 'node:test';
import * as assert from 'node:assert/strict';
import * as fs from 'node:fs/promises';
import * as path from 'node:path';
import ShellModule from '../../../.github/scripts/orchestrator/modules/shell-module.mjs';

describe('ShellModule', () => {
  let module;
  const fixturesDir = path.join(process.cwd(), 'tests/fixtures/orchestrator/shell');

  before(() => {
    module = new ShellModule('shell', {
      extensions: ['.sh', '.bash'],
    });
  });

  describe('Constructor', () => {
    it('should create instance with default config', () => {
      const shellModule = new ShellModule();

      assert.equal(shellModule.name, 'shell');
      assert.ok(shellModule.extensions.includes('.sh'));
    });

    it('should accept custom config', () => {
      const shellModule = new ShellModule('custom-shell', {
        extensions: ['.sh', '.bash', '.zsh'],
        checker: { command: 'custom-shellcheck' },
      });

      assert.equal(shellModule.name, 'custom-shell');
      assert.equal(shellModule.shellcheckPath, 'custom-shellcheck');
    });

    it('should have default extensions', () => {
      const shellModule = new ShellModule();

      assert.ok(shellModule.extensions.includes('.sh'));
      assert.ok(shellModule.extensions.includes('.bash'));
      assert.ok(shellModule.extensions.includes('.zsh'));
      assert.ok(shellModule.extensions.includes('.ksh'));
    });
  });

  describe('canHandle()', () => {
    it('should handle .sh files', () => {
      assert.equal(module.canHandle('script.sh'), true);
    });

    it('should handle .bash files', () => {
      assert.equal(module.canHandle('script.bash'), true);
    });

    it('should not handle non-shell files', () => {
      assert.equal(module.canHandle('script.js'), false);
      assert.equal(module.canHandle('script.py'), false);
    });
  });

  describe('check()', () => {
    it('should return CheckResult structure', async () => {
      const goodScript = path.join(fixturesDir, 'good/proper-script.sh');

      try {
        const result = await module.check([goodScript]);

        assert.equal(typeof result, 'object');
        assert.equal(typeof result.success, 'boolean');
        assert.ok(Array.isArray(result.issues));
        assert.equal(typeof result.metadata, 'object');
      } catch (error) {
        // Shellcheck not installed, skip test
        if (error.message.includes('shellcheck: not found')) {
          return; // Skip test
        }
        throw error;
      }
    });

    it('should find no issues in good script', async () => {
      const goodScript = path.join(fixturesDir, 'good/proper-script.sh');

      try {
        const result = await module.check([goodScript]);

        assert.equal(result.success, true);
        assert.equal(result.issues.length, 0);
      } catch (error) {
        // Shellcheck not installed, skip test
        if (error.message.includes('shellcheck: not found')) {
          return; // Skip test
        }
        throw error;
      }
    });

    it('should find issues in bad script', async () => {
      const badScript = path.join(fixturesDir, 'bad/unquoted-vars.sh');

      try {
        const result = await module.check([badScript]);

        assert.equal(result.success, false);
        assert.ok(result.issues.length > 0);

        // Check issue structure
        const issue = result.issues[0];
        assert.ok('file' in issue);
        assert.ok('line' in issue);
        assert.ok('code' in issue);
        assert.ok('severity' in issue);
        assert.ok('message' in issue);
      } catch (error) {
        // Shellcheck might not be installed, skip test
        if (!error.message.includes('shellcheck')) {
          throw error;
        }
      }
    });

    it('should include metadata', async () => {
      const goodScript = path.join(fixturesDir, 'good/proper-script.sh');

      try {
        const result = await module.check([goodScript]);

        assert.ok('tool_version' in result.metadata);
        assert.ok('duration_ms' in result.metadata);
        assert.equal(typeof result.metadata.duration_ms, 'number');
      } catch (error) {
        if (!error.message.includes('shellcheck')) {
          throw error;
        }
      }
    });

    it('should handle timeout option', async () => {
      const goodScript = path.join(fixturesDir, 'good/proper-script.sh');

      try {
        const result = await module.check([goodScript], { timeout: 5000 });

        assert.ok(result);
      } catch (error) {
        if (!error.message.includes('shellcheck') && !error.message.includes('timeout')) {
          throw error;
        }
      }
    });
  });

  describe('fix()', () => {
    it('should return FixResult structure', async () => {
      const testFile = path.join(fixturesDir, 'good/proper-script.sh');

      try {
        const result = await module.fix([testFile], 'balanced', { dry_run: true });

        assert.equal(typeof result, 'object');
        assert.equal(typeof result.success, 'boolean');
        assert.ok(Array.isArray(result.files_modified));
        assert.equal(typeof result.fixes_applied, 'number');
        assert.equal(typeof result.metadata, 'object');
      } catch (error) {
        // Fixer script might not exist, skip test
        if (!error.message.includes('shellcheck-apply')) {
          throw error;
        }
      }
    });

    it('should use correct strategy', async () => {
      const testFile = path.join(fixturesDir, 'good/proper-script.sh');

      try {
        const result = await module.fix([testFile], 'conservative', { dry_run: true });

        assert.equal(result.metadata.strategy, 'conservative');
      } catch (error) {
        if (!error.message.includes('shellcheck-apply')) {
          throw error;
        }
      }
    });

    it('should respect dry_run option', async () => {
      const testFile = path.join(fixturesDir, 'good/proper-script.sh');

      try {
        const result = await module.fix([testFile], 'balanced', { dry_run: true });

        // In dry-run mode, no files should be modified
        assert.equal(result.files_modified.length, 0);
      } catch (error) {
        if (!error.message.includes('shellcheck-apply')) {
          throw error;
        }
      }
    });
  });

  describe('parseShellcheckOutput()', () => {
    it('should parse JSON output correctly', () => {
      const jsonOutput = JSON.stringify([
        {
          file: 'test.sh',
          line: 10,
          column: 5,
          code: 2086,
          level: 'warning',
          message: 'Quote to prevent word splitting',
        },
      ]);

      const issues = module.parseShellcheckOutput(jsonOutput);

      assert.equal(issues.length, 1);
      assert.equal(issues[0].file, 'test.sh');
      assert.equal(issues[0].line, 10);
      assert.equal(issues[0].code, 'SC2086');
      assert.equal(issues[0].severity, 'warning');
    });

    it('should handle empty output', () => {
      const issues = module.parseShellcheckOutput('');

      assert.deepEqual(issues, []);
    });

    it('should handle multiple issues', () => {
      const jsonOutput = JSON.stringify([
        {
          file: 'test.sh',
          line: 10,
          code: 2086,
          level: 'warning',
          message: 'Issue 1',
        },
        {
          file: 'test.sh',
          line: 15,
          code: 2164,
          level: 'error',
          message: 'Issue 2',
        },
      ]);

      const issues = module.parseShellcheckOutput(jsonOutput);

      assert.equal(issues.length, 2);
    });

    it('should handle invalid JSON gracefully', () => {
      const issues = module.parseShellcheckOutput('not valid json');

      assert.deepEqual(issues, []);
    });
  });

  describe('mapSeverity()', () => {
    it('should map error correctly', () => {
      assert.equal(module.mapSeverity('error'), 'error');
    });

    it('should map warning correctly', () => {
      assert.equal(module.mapSeverity('warning'), 'warning');
    });

    it('should map info correctly', () => {
      assert.equal(module.mapSeverity('info'), 'info');
    });

    it('should map style to info', () => {
      assert.equal(module.mapSeverity('style'), 'info');
    });

    it('should default to warning for unknown levels', () => {
      assert.equal(module.mapSeverity('unknown'), 'warning');
    });
  });

  describe('countFixesFromOutput()', () => {
    it('should count fixes from "Applied N fixes"', () => {
      const output = 'Applied 5 fixes to script.sh';
      assert.equal(module.countFixesFromOutput(output), 5);
    });

    it('should count fixes from "Fixed N issues"', () => {
      const output = 'Fixed 3 issues in script.sh';
      assert.equal(module.countFixesFromOutput(output), 3);
    });

    it('should return 0 for no fixes', () => {
      const output = 'No issues found';
      assert.equal(module.countFixesFromOutput(output), 0);
    });

    it('should handle empty output', () => {
      assert.equal(module.countFixesFromOutput(''), 0);
    });
  });

  describe('validate()', () => {
    it('should return validation result', async () => {
      const result = await module.validate();

      assert.equal(typeof result, 'object');
      assert.equal(typeof result.ready, 'boolean');
      assert.ok(Array.isArray(result.missing_dependencies));
    });

    it('should check for shellcheck', async () => {
      const result = await module.validate();

      // Either shellcheck is installed or it's in missing_dependencies
      if (!result.ready) {
        assert.ok(
          result.missing_dependencies.includes('shellcheck') ||
            result.missing_dependencies.includes('shellcheck-apply.sh')
        );
      }
    });
  });

  describe('getSupportedStrategies()', () => {
    it('should return shell-specific strategies', () => {
      const strategies = module.getSupportedStrategies();

      assert.deepEqual(strategies, ['conservative', 'balanced', 'aggressive']);
    });

    it('should return array', () => {
      const strategies = module.getSupportedStrategies();

      assert.ok(Array.isArray(strategies));
      assert.ok(strategies.length > 0);
    });
  });

  describe('getInfo()', () => {
    it('should return module information', () => {
      const info = module.getInfo();

      assert.equal(info.name, 'shell');
      assert.ok(info.extensions.includes('.sh'));
      assert.deepEqual(info.strategies, ['conservative', 'balanced', 'aggressive']);
    });
  });
});
