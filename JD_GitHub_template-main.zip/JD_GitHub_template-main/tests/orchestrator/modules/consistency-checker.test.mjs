/**
 * Tests for Consistency Checker Module
 *
 * TDD Approach: These tests are written FIRST, before implementation
 */

import { describe, it, beforeEach, afterEach } from 'node:test';
import assert from 'node:assert';
import { mkdtemp, rm, writeFile, readFile, mkdir } from 'node:fs/promises';
import { join } from 'node:path';
import { tmpdir } from 'node:os';

// Import the module we're testing (will fail initially - that's TDD!)
import ConsistencyChecker from '../../../.github/scripts/orchestrator/modules/consistency-checker.mjs';

describe('ConsistencyChecker', () => {
  let tmpDir;
  let checker;

  beforeEach(async () => {
    // Create temp directory for test files
    tmpDir = await mkdtemp(join(tmpdir(), 'consistency-test-'));
    checker = new ConsistencyChecker();
  });

  afterEach(async () => {
    // Cleanup
    await rm(tmpDir, { recursive: true, force: true });
  });

  describe('check - detect issues', () => {
    it('should detect trailing spaces in markdown', async () => {
      const file = join(tmpDir, 'test.md');
      await writeFile(file, 'Line 1   \nLine 2\n');

      const result = await checker.check([file]);

      assert.strictEqual(result.passed, false);
      assert.strictEqual(result.issues.length, 1);
      assert.strictEqual(result.issues[0].code, 'trim-trailing-spaces');
      assert.strictEqual(result.issues[0].file, file);
    });

    it('should detect multiple blank lines', async () => {
      const file = join(tmpDir, 'test.js');
      await writeFile(file, 'const x = 1;\n\n\n\nconst y = 2;\n');

      const result = await checker.check([file]);

      assert.strictEqual(result.passed, false);
      assert.strictEqual(result.issues.length, 1);
      assert.strictEqual(result.issues[0].code, 'no-multiple-blank-lines');
    });

    it('should detect missing blank line after heading in markdown', async () => {
      const file = join(tmpDir, 'test.md');
      await writeFile(file, '# Heading\nContent immediately after\n');

      const result = await checker.check([file]);

      assert.strictEqual(result.passed, false);
      const blankLineIssue = result.issues.find(i => i.code === 'blank-line-after-heading');
      assert.ok(blankLineIssue, 'Should detect missing blank line after heading');
    });

    it('should pass when file is already formatted correctly', async () => {
      const file = join(tmpDir, 'test.md');
      await writeFile(file, '# Heading\n\nContent with proper spacing.\n');

      const result = await checker.check([file]);

      assert.strictEqual(result.passed, true);
      assert.strictEqual(result.issues.length, 0);
    });

    it('should check multiple files', async () => {
      const file1 = join(tmpDir, 'file1.md');
      const file2 = join(tmpDir, 'file2.js');
      await writeFile(file1, 'Line 1   \n'); // trailing space
      await writeFile(file2, 'const x = 1;\n');

      const result = await checker.check([file1, file2]);

      assert.strictEqual(result.passed, false);
      assert.strictEqual(result.issues.length, 1);
      assert.strictEqual(result.issues[0].file, file1);
    });

    it('should include timing metadata', async () => {
      const file = join(tmpDir, 'test.md');
      await writeFile(file, 'Content\n');

      const result = await checker.check([file]);

      assert.ok(result.metadata);
      assert.ok(typeof result.metadata.duration_ms === 'number');
      assert.ok(result.metadata.duration_ms >= 0);
    });
  });

  describe('fix - apply fixes', () => {
    it('should fix trailing spaces', async () => {
      const file = join(tmpDir, 'test.md');
      await writeFile(file, 'Line 1   \nLine 2\t\nLine 3\n');

      const result = await checker.fix([file]);

      assert.strictEqual(result.success, true);
      assert.strictEqual(result.filesModified.length, 1);
      assert.strictEqual(result.filesModified[0], file);

      const content = await readFile(file, 'utf8');
      assert.strictEqual(content, 'Line 1\nLine 2\nLine 3\n');
    });

    it('should fix multiple blank lines', async () => {
      const file = join(tmpDir, 'test.js');
      await writeFile(file, 'const x = 1;\n\n\n\nconst y = 2;\n');

      const result = await checker.fix([file]);

      assert.strictEqual(result.success, true);
      assert.strictEqual(result.filesModified.length, 1);

      const content = await readFile(file, 'utf8');
      assert.strictEqual(content, 'const x = 1;\n\nconst y = 2;\n');
    });

    it('should ensure single final newline', async () => {
      const file = join(tmpDir, 'test.md');
      await writeFile(file, 'Content\n\n\n');

      const result = await checker.fix([file]);

      const content = await readFile(file, 'utf8');
      assert.strictEqual(content, 'Content\n');
    });

    it('should fix blank line after heading in markdown', async () => {
      const file = join(tmpDir, 'test.md');
      await writeFile(file, '# Heading\nContent\n');

      const result = await checker.fix([file]);

      const content = await readFile(file, 'utf8');
      assert.strictEqual(content, '# Heading\n\nContent\n');
    });

    it('should not modify already-formatted files', async () => {
      const file = join(tmpDir, 'test.md');
      const correctContent = '# Heading\n\nContent with proper formatting.\n';
      await writeFile(file, correctContent);

      const result = await checker.fix([file]);

      assert.strictEqual(result.filesModified.length, 0);
      assert.strictEqual(result.fixesApplied, 0);

      const content = await readFile(file, 'utf8');
      assert.strictEqual(content, correctContent);
    });

    it('should track number of fixes applied', async () => {
      const file = join(tmpDir, 'test.md');
      // Multiple issues: trailing spaces AND multiple blank lines
      await writeFile(file, 'Line 1   \n\n\n\nLine 2\n');

      const result = await checker.fix([file]);

      assert.strictEqual(result.success, true);
      assert.ok(result.fixesApplied >= 2, 'Should apply at least 2 fixes');
    });

    it('should fix multiple files', async () => {
      const file1 = join(tmpDir, 'file1.md');
      const file2 = join(tmpDir, 'file2.js');
      await writeFile(file1, 'Line 1   \n');
      await writeFile(file2, 'const x = 1;   \n');

      const result = await checker.fix([file1, file2]);

      assert.strictEqual(result.filesModified.length, 2);
      assert.ok(result.filesModified.includes(file1));
      assert.ok(result.filesModified.includes(file2));
    });

    it('should include timing metadata', async () => {
      const file = join(tmpDir, 'test.md');
      await writeFile(file, 'Content\n');

      const result = await checker.fix([file]);

      assert.ok(result.metadata);
      assert.ok(typeof result.metadata.duration_ms === 'number');
    });
  });

  describe('fix strategies', () => {
    it('should apply conservative strategy (only safe rules)', async () => {
      const file = join(tmpDir, 'test.md');
      // Has trailing space (safe) AND missing blank after heading (potentially unsafe)
      await writeFile(file, '# Heading\nContent   \n');

      const result = await checker.fix([file], 'conservative');

      const content = await readFile(file, 'utf8');
      // Should fix trailing space but NOT add blank line after heading
      assert.strictEqual(content, '# Heading\nContent\n');
    });

    it('should apply balanced strategy (default)', async () => {
      const file = join(tmpDir, 'test.md');
      await writeFile(file, '# Heading\nContent   \n');

      const result = await checker.fix([file], 'balanced');

      const content = await readFile(file, 'utf8');
      // Should fix both issues
      assert.strictEqual(content, '# Heading\n\nContent\n');
    });

    it('should apply aggressive strategy (all rules)', async () => {
      const file = join(tmpDir, 'test.md');
      await writeFile(file, '# Heading\nContent   \n\n\n');

      const result = await checker.fix([file], 'aggressive');

      const content = await readFile(file, 'utf8');
      // Should fix all issues
      assert.strictEqual(content, '# Heading\n\nContent\n');
    });
  });

  describe('getRulesForFile', () => {
    it('should return markdown rules for .md files', () => {
      const rules = checker.getRulesForFile('test.md');

      const ruleIds = rules.map(r => r.id);
      assert.ok(ruleIds.includes('blank-line-after-heading'));
      assert.ok(ruleIds.includes('blank-line-before-list'));
      assert.ok(ruleIds.includes('trim-trailing-spaces'));
      assert.ok(ruleIds.includes('single-final-newline'));
    });

    it('should return javascript rules for .js files', () => {
      const rules = checker.getRulesForFile('test.js');

      const ruleIds = rules.map(r => r.id);
      assert.ok(ruleIds.includes('no-multiple-blank-lines'));
      assert.ok(ruleIds.includes('trim-trailing-spaces'));
      // Should NOT include markdown-specific rules
      assert.ok(!ruleIds.includes('blank-line-after-heading'));
    });

    it('should return javascript rules for .mjs files', () => {
      const rules = checker.getRulesForFile('test.mjs');

      const ruleIds = rules.map(r => r.id);
      assert.ok(ruleIds.includes('no-multiple-blank-lines'));
    });

    it('should return yaml rules for .yml files', () => {
      const rules = checker.getRulesForFile('test.yml');

      const ruleIds = rules.map(r => r.id);
      assert.ok(ruleIds.includes('trim-trailing-spaces'));
    });

    it('should always include universal rules', () => {
      const mdRules = checker.getRulesForFile('test.md');
      const jsRules = checker.getRulesForFile('test.js');

      const mdIds = mdRules.map(r => r.id);
      const jsIds = jsRules.map(r => r.id);

      // Universal rules should be in both
      assert.ok(mdIds.includes('trim-trailing-spaces'));
      assert.ok(jsIds.includes('trim-trailing-spaces'));
    });
  });

  describe('checkFile - single file', () => {
    it('should check a single file and return issues', async () => {
      const file = join(tmpDir, 'test.md');
      await writeFile(file, 'Line 1   \n');

      const issues = await checker.checkFile(file);

      assert.ok(Array.isArray(issues));
      assert.strictEqual(issues.length, 1);
      assert.strictEqual(issues[0].file, file);
      assert.strictEqual(issues[0].code, 'trim-trailing-spaces');
      assert.strictEqual(issues[0].severity, 'warning');
    });

    it('should return empty array for properly formatted file', async () => {
      const file = join(tmpDir, 'test.md');
      await writeFile(file, 'Properly formatted content.\n');

      const issues = await checker.checkFile(file);

      assert.strictEqual(issues.length, 0);
    });

    it('should include line numbers in issues', async () => {
      const file = join(tmpDir, 'test.md');
      await writeFile(file, 'Line 1\nLine 2   \n');

      const issues = await checker.checkFile(file);

      assert.ok(issues.length > 0);
      assert.ok(typeof issues[0].line === 'number');
      assert.ok(issues[0].line >= 1);
    });
  });

  describe('fixFile - single file', () => {
    it('should fix a single file and return modification status', async () => {
      const file = join(tmpDir, 'test.md');
      await writeFile(file, 'Line 1   \n');

      const result = await checker.fixFile(file, 'balanced');

      assert.strictEqual(result.modified, true);
      assert.ok(result.fixCount >= 1);

      const content = await readFile(file, 'utf8');
      assert.strictEqual(content, 'Line 1\n');
    });

    it('should not modify already-formatted file', async () => {
      const file = join(tmpDir, 'test.md');
      await writeFile(file, 'Properly formatted.\n');

      const result = await checker.fixFile(file, 'balanced');

      assert.strictEqual(result.modified, false);
      assert.strictEqual(result.fixCount, 0);
    });
  });

  describe('integration - realistic scenarios', () => {
    it('should handle markdown document with multiple issues', async () => {
      const file = join(tmpDir, 'README.md');
      const problematic = `# Title
Content immediately after heading

- List item 1

- List item 2



Another paragraph

`;
      await writeFile(file, problematic);

      const checkResult = await checker.check([file]);
      assert.strictEqual(checkResult.passed, false);

      const fixResult = await checker.fix([file]);
      assert.strictEqual(fixResult.success, true);

      const fixed = await readFile(file, 'utf8');
      // Should have:
      // - Blank line after heading
      // - No trailing spaces
      // - No multiple blank lines
      // - Single final newline
      assert.ok(!fixed.includes('   \n'), 'Should not have trailing spaces');
      assert.ok(!fixed.includes('\n\n\n'), 'Should not have multiple blank lines');
      assert.ok(fixed.includes('# Title\n\nContent'), 'Should have blank after heading');
    });

    it('should handle JavaScript file with mixed issues', async () => {
      const file = join(tmpDir, 'script.js');
      const problematic = `function test() {
  const x = 1;


  return x;
}


`;
      await writeFile(file, problematic);

      const fixResult = await checker.fix([file]);
      assert.strictEqual(fixResult.success, true);

      const fixed = await readFile(file, 'utf8');
      assert.ok(!fixed.includes('   \n'));
      assert.ok(!fixed.includes('\n\n\n'));
      assert.strictEqual(fixed.endsWith('\n'), true);
      assert.strictEqual(fixed.endsWith('\n\n'), false);
    });
  });
});
