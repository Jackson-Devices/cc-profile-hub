/**
 * Tests for Merge Conflict Analyzer Module
 *
 * TDD Approach: These tests are written FIRST, before implementation
 */

import { describe, it, beforeEach, afterEach } from 'node:test';
import assert from 'node:assert';
import { mkdtemp, rm, writeFile, mkdir } from 'node:fs/promises';
import { join } from 'node:path';
import { tmpdir } from 'node:os';
import { exec } from 'node:child_process';
import { promisify } from 'node:util';

const execAsync = promisify(exec);

// Import the module we're testing (will fail initially - that's TDD!)
import MergeConflictAnalyzer from '../../../.github/scripts/orchestrator/modules/merge-conflict-analyzer.mjs';

describe('MergeConflictAnalyzer', () => {
  let tmpDir;
  let analyzer;

  beforeEach(async () => {
    // Create temp directory for test git repo
    tmpDir = await mkdtemp(join(tmpdir(), 'merge-test-'));
    analyzer = new MergeConflictAnalyzer();

    // Initialize git repo with 'main' as default branch
    await execAsync('git init -b main', { cwd: tmpDir });
    await execAsync('git config user.email "test@test.com"', { cwd: tmpDir });
    await execAsync('git config user.name "Test User"', { cwd: tmpDir });
    // Disable git commit signing for tests
    await execAsync('git config commit.gpgsign false', { cwd: tmpDir });
    await execAsync('git config gpg.ssh.program ""', { cwd: tmpDir });
  });

  afterEach(async () => {
    // Cleanup
    await rm(tmpDir, { recursive: true, force: true });
  });

  describe('findOverlappingFiles', () => {
    it('should return empty array when no files overlap', async () => {
      // Create base branch
      await writeFile(join(tmpDir, 'file-a.txt'), 'content a\n');
      await execAsync('git add .', { cwd: tmpDir });
      await execAsync('git commit -m "initial"', { cwd: tmpDir });

      // Create branch A with file-a.txt
      await execAsync('git checkout -b branch-a', { cwd: tmpDir });
      await writeFile(join(tmpDir, 'file-a.txt'), 'modified a\n');
      await execAsync('git add .', { cwd: tmpDir });
      await execAsync('git commit -m "modify a"', { cwd: tmpDir });

      // Create branch B with file-b.txt (different file)
      await execAsync('git checkout main', { cwd: tmpDir });
      await execAsync('git checkout -b branch-b', { cwd: tmpDir });
      await writeFile(join(tmpDir, 'file-b.txt'), 'content b\n');
      await execAsync('git add .', { cwd: tmpDir });
      await execAsync('git commit -m "add b"', { cwd: tmpDir });

      // Change to tmp dir for git operations
      process.chdir(tmpDir);

      const result = await analyzer.findOverlappingFiles('branch-a', 'branch-b', 'main');

      assert.strictEqual(result.files.length, 0);
      assert.strictEqual(result.totalA, 1);
      assert.strictEqual(result.totalB, 1);
    });

    it('should detect overlapping files', async () => {
      // Create base
      await writeFile(join(tmpDir, 'shared.txt'), 'original\n');
      await execAsync('git add .', { cwd: tmpDir });
      await execAsync('git commit -m "initial"', { cwd: tmpDir });

      // Branch A modifies shared.txt
      await execAsync('git checkout -b branch-a', { cwd: tmpDir });
      await writeFile(join(tmpDir, 'shared.txt'), 'modified by A\n');
      await execAsync('git add .', { cwd: tmpDir });
      await execAsync('git commit -m "modify shared"', { cwd: tmpDir });

      // Branch B also modifies shared.txt
      await execAsync('git checkout main', { cwd: tmpDir });
      await execAsync('git checkout -b branch-b', { cwd: tmpDir });
      await writeFile(join(tmpDir, 'shared.txt'), 'modified by B\n');
      await execAsync('git add .', { cwd: tmpDir });
      await execAsync('git commit -m "modify shared"', { cwd: tmpDir });

      process.chdir(tmpDir);

      const result = await analyzer.findOverlappingFiles('branch-a', 'branch-b', 'main');

      assert.strictEqual(result.files.length, 1);
      assert.strictEqual(result.files[0], 'shared.txt');
    });
  });

  describe('analyzeFile - identical changes', () => {
    it('should detect identical changes and auto-resolve', async () => {
      // Create base
      await writeFile(join(tmpDir, 'test.md'), '# Heading\n\n\n\nContent\n');
      await execAsync('git add .', { cwd: tmpDir });
      await execAsync('git commit -m "initial"', { cwd: tmpDir });

      // Both branches remove blank lines identically
      const fixedContent = '# Heading\n\nContent\n';

      await execAsync('git checkout -b branch-a', { cwd: tmpDir });
      await writeFile(join(tmpDir, 'test.md'), fixedContent);
      await execAsync('git add .', { cwd: tmpDir });
      await execAsync('git commit -m "fix formatting"', { cwd: tmpDir });

      await execAsync('git checkout main', { cwd: tmpDir });
      await execAsync('git checkout -b branch-b', { cwd: tmpDir });
      await writeFile(join(tmpDir, 'test.md'), fixedContent);
      await execAsync('git add .', { cwd: tmpDir });
      await execAsync('git commit -m "fix formatting"', { cwd: tmpDir });

      process.chdir(tmpDir);

      const result = await analyzer.analyzeFile('test.md', 'branch-a', 'branch-b', 'main');

      assert.strictEqual(result.type, 'identical-changes');
      assert.strictEqual(result.canAutoResolve, true);
      assert.strictEqual(result.resolution, 'use-either');
      assert.strictEqual(result.confidence, 1.0);
    });
  });

  describe('analyzeFile - formatting-only differences', () => {
    it('should detect formatting-only differences', async () => {
      // Create base
      await writeFile(join(tmpDir, 'test.js'), 'const x = 1;\n');
      await execAsync('git add .', { cwd: tmpDir });
      await execAsync('git commit -m "initial"', { cwd: tmpDir });

      // Branch A: adds trailing spaces
      await execAsync('git checkout -b branch-a', { cwd: tmpDir });
      await writeFile(join(tmpDir, 'test.js'), 'const x = 1;   \n');
      await execAsync('git add .', { cwd: tmpDir });
      await execAsync('git commit -m "modify a"', { cwd: tmpDir });

      // Branch B: uses tabs instead of spaces
      await execAsync('git checkout main', { cwd: tmpDir });
      await execAsync('git checkout -b branch-b', { cwd: tmpDir });
      await writeFile(join(tmpDir, 'test.js'), 'const x = 1;\t\n');
      await execAsync('git add .', { cwd: tmpDir });
      await execAsync('git commit -m "modify b"', { cwd: tmpDir });

      process.chdir(tmpDir);

      const result = await analyzer.analyzeFile('test.js', 'branch-a', 'branch-b', 'main');

      assert.strictEqual(result.type, 'formatting-only-difference');
      assert.strictEqual(result.canAutoResolve, true);
    });
  });

  describe('analyzeFile - non-overlapping changes', () => {
    it('should detect non-overlapping line changes', async () => {
      // Create base with multiple lines
      await writeFile(join(tmpDir, 'test.txt'), 'Line 1\nLine 2\nLine 3\nLine 4\nLine 5\n');
      await execAsync('git add .', { cwd: tmpDir });
      await execAsync('git commit -m "initial"', { cwd: tmpDir });

      // Branch A modifies line 1
      await execAsync('git checkout -b branch-a', { cwd: tmpDir });
      await writeFile(join(tmpDir, 'test.txt'), 'Modified Line 1\nLine 2\nLine 3\nLine 4\nLine 5\n');
      await execAsync('git add .', { cwd: tmpDir });
      await execAsync('git commit -m "modify line 1"', { cwd: tmpDir });

      // Branch B modifies line 5
      await execAsync('git checkout main', { cwd: tmpDir });
      await execAsync('git checkout -b branch-b', { cwd: tmpDir });
      await writeFile(join(tmpDir, 'test.txt'), 'Line 1\nLine 2\nLine 3\nLine 4\nModified Line 5\n');
      await execAsync('git add .', { cwd: tmpDir });
      await execAsync('git commit -m "modify line 5"', { cwd: tmpDir });

      process.chdir(tmpDir);

      const result = await analyzer.analyzeFile('test.txt', 'branch-a', 'branch-b', 'main');

      assert.strictEqual(result.type, 'non-overlapping-lines');
      assert.strictEqual(result.canAutoResolve, true);
      assert.strictEqual(result.resolution, 'merge-both');
    });
  });

  describe('analyzeFile - semantic conflicts', () => {
    it('should detect semantic conflict when same line modified differently', async () => {
      // Create base
      await writeFile(join(tmpDir, 'test.txt'), 'original content\n');
      await execAsync('git add .', { cwd: tmpDir });
      await execAsync('git commit -m "initial"', { cwd: tmpDir });

      // Branch A changes to one thing
      await execAsync('git checkout -b branch-a', { cwd: tmpDir });
      await writeFile(join(tmpDir, 'test.txt'), 'content from A\n');
      await execAsync('git add .', { cwd: tmpDir });
      await execAsync('git commit -m "modify"', { cwd: tmpDir });

      // Branch B changes to different thing
      await execAsync('git checkout main', { cwd: tmpDir });
      await execAsync('git checkout -b branch-b', { cwd: tmpDir });
      await writeFile(join(tmpDir, 'test.txt'), 'content from B\n');
      await execAsync('git add .', { cwd: tmpDir });
      await execAsync('git commit -m "modify"', { cwd: tmpDir });

      process.chdir(tmpDir);

      const result = await analyzer.analyzeFile('test.txt', 'branch-a', 'branch-b', 'main');

      assert.strictEqual(result.canAutoResolve, false);
      assert.strictEqual(result.needsManualReview, true);
    });
  });

  describe('JSON semantic analysis', () => {
    it('should detect compatible JSON changes (different keys)', async () => {
      // Create base JSON
      const baseJson = { name: 'test', version: '1.0.0' };
      await writeFile(join(tmpDir, 'package.json'), JSON.stringify(baseJson, null, 2) + '\n');
      await execAsync('git add .', { cwd: tmpDir });
      await execAsync('git commit -m "initial"', { cwd: tmpDir });

      // Branch A adds "author"
      await execAsync('git checkout -b branch-a', { cwd: tmpDir });
      const jsonA = { ...baseJson, author: 'Alice' };
      await writeFile(join(tmpDir, 'package.json'), JSON.stringify(jsonA, null, 2) + '\n');
      await execAsync('git add .', { cwd: tmpDir });
      await execAsync('git commit -m "add author"', { cwd: tmpDir });

      // Branch B adds "description"
      await execAsync('git checkout main', { cwd: tmpDir });
      await execAsync('git checkout -b branch-b', { cwd: tmpDir });
      const jsonB = { ...baseJson, description: 'A test package' };
      await writeFile(join(tmpDir, 'package.json'), JSON.stringify(jsonB, null, 2) + '\n');
      await execAsync('git add .', { cwd: tmpDir });
      await execAsync('git commit -m "add description"', { cwd: tmpDir });

      process.chdir(tmpDir);

      const result = await analyzer.analyzeFile('package.json', 'branch-a', 'branch-b', 'main');

      assert.strictEqual(result.type, 'compatible-structural');
      assert.strictEqual(result.canAutoResolve, true);
      assert.ok(result.confidence >= 0.9);
    });

    it('should detect JSON conflict when same key modified differently', async () => {
      // Create base JSON
      const baseJson = { name: 'test', version: '1.0.0' };
      await writeFile(join(tmpDir, 'package.json'), JSON.stringify(baseJson, null, 2) + '\n');
      await execAsync('git add .', { cwd: tmpDir });
      await execAsync('git commit -m "initial"', { cwd: tmpDir });

      // Branch A changes version to 2.0.0
      await execAsync('git checkout -b branch-a', { cwd: tmpDir });
      const jsonA = { ...baseJson, version: '2.0.0' };
      await writeFile(join(tmpDir, 'package.json'), JSON.stringify(jsonA, null, 2) + '\n');
      await execAsync('git add .', { cwd: tmpDir });
      await execAsync('git commit -m "bump version"', { cwd: tmpDir });

      // Branch B changes version to 3.0.0
      await execAsync('git checkout main', { cwd: tmpDir });
      await execAsync('git checkout -b branch-b', { cwd: tmpDir });
      const jsonB = { ...baseJson, version: '3.0.0' };
      await writeFile(join(tmpDir, 'package.json'), JSON.stringify(jsonB, null, 2) + '\n');
      await execAsync('git add .', { cwd: tmpDir });
      await execAsync('git commit -m "bump version"', { cwd: tmpDir });

      process.chdir(tmpDir);

      const result = await analyzer.analyzeFile('package.json', 'branch-a', 'branch-b', 'main');

      assert.strictEqual(result.type, 'semantic-conflict');
      assert.strictEqual(result.canAutoResolve, false);
      assert.strictEqual(result.needsManualReview, true);
      assert.ok(result.details.conflictingElements);
    });
  });

  describe('Markdown semantic analysis', () => {
    it('should detect compatible markdown changes (different sections)', async () => {
      const baseMd = `# Title

## Section A
Content A

## Section B
Content B
`;
      await writeFile(join(tmpDir, 'README.md'), baseMd);
      await execAsync('git add .', { cwd: tmpDir });
      await execAsync('git commit -m "initial"', { cwd: tmpDir });

      // Branch A modifies Section A
      await execAsync('git checkout -b branch-a', { cwd: tmpDir });
      const mdA = `# Title

## Section A
Modified content A

## Section B
Content B
`;
      await writeFile(join(tmpDir, 'README.md'), mdA);
      await execAsync('git add .', { cwd: tmpDir });
      await execAsync('git commit -m "modify section a"', { cwd: tmpDir });

      // Branch B modifies Section B
      await execAsync('git checkout main', { cwd: tmpDir });
      await execAsync('git checkout -b branch-b', { cwd: tmpDir });
      const mdB = `# Title

## Section A
Content A

## Section B
Modified content B
`;
      await writeFile(join(tmpDir, 'README.md'), mdB);
      await execAsync('git add .', { cwd: tmpDir });
      await execAsync('git commit -m "modify section b"', { cwd: tmpDir });

      process.chdir(tmpDir);

      const result = await analyzer.analyzeFile('README.md', 'branch-a', 'branch-b', 'main');

      assert.strictEqual(result.type, 'compatible-structural');
      assert.strictEqual(result.canAutoResolve, true);
    });
  });

  describe('summarizeAnalyses', () => {
    it('should correctly summarize analysis results', () => {
      const analyses = [
        { file: 'file1.txt', canAutoResolve: true, type: 'identical-changes', needsManualReview: false },
        { file: 'file2.json', canAutoResolve: true, type: 'compatible-structural', needsManualReview: false },
        { file: 'file3.md', canAutoResolve: false, type: 'semantic-conflict', needsManualReview: true }
      ];

      const summary = analyzer.summarizeAnalyses(analyses);

      assert.strictEqual(summary.totalFiles, 3);
      assert.strictEqual(summary.canAutoMerge, false); // One needs manual review
      assert.strictEqual(summary.autoResolvable, 2);
      assert.strictEqual(summary.needsManualReview, 1);
      assert.strictEqual(summary.breakdown['identical-changes'], 1);
      assert.strictEqual(summary.breakdown['compatible-structural'], 1);
      assert.strictEqual(summary.breakdown['semantic-conflict'], 1);
    });

    it('should indicate can auto-merge when all files auto-resolvable', () => {
      const analyses = [
        { file: 'file1.txt', canAutoResolve: true, type: 'identical-changes', needsManualReview: false },
        { file: 'file2.txt', canAutoResolve: true, type: 'non-overlapping', needsManualReview: false }
      ];

      const summary = analyzer.summarizeAnalyses(analyses);

      assert.strictEqual(summary.canAutoMerge, true);
      assert.strictEqual(summary.needsManualReview, 0);
    });
  });

  describe('normalizeWhitespace', () => {
    it('should remove trailing spaces', () => {
      const input = 'line 1   \nline 2  \n';
      const expected = 'line 1\nline 2\n';

      const result = analyzer.normalizeWhitespace(input);

      assert.strictEqual(result, expected);
    });

    it('should normalize line endings', () => {
      const input = 'line 1\r\nline 2\r\n';
      const expected = 'line 1\nline 2\n';

      const result = analyzer.normalizeWhitespace(input);

      assert.strictEqual(result, expected);
    });

    it('should collapse multiple blank lines', () => {
      const input = 'line 1\n\n\n\nline 2\n';
      const expected = 'line 1\n\nline 2\n';

      const result = analyzer.normalizeWhitespace(input);

      assert.strictEqual(result, expected);
    });

    it('should ensure single final newline', () => {
      const input = 'line 1\nline 2';
      const expected = 'line 1\nline 2\n';

      const result = analyzer.normalizeWhitespace(input);

      assert.strictEqual(result, expected);
    });
  });
});
