/**
 * Tests for Obsidian Module - TDD First
 */

import { describe, it, beforeEach, afterEach } from 'node:test';
import assert from 'node:assert';
import { mkdtemp, rm, writeFile } from 'node:fs/promises';
import { join } from 'node:path';
import { tmpdir } from 'node:os';

import ObsidianModule from '../../../.github/scripts/orchestrator/modules/obsidian-module.mjs';

describe('ObsidianModule', () => {
  let tmpDir;
  let module;

  beforeEach(async () => {
    tmpDir = await mkdtemp(join(tmpdir(), 'obsidian-test-'));
    module = new ObsidianModule();
  });

  afterEach(async () => {
    await rm(tmpDir, { recursive: true, force: true });
  });

  it('should handle .md files in Obsidian vault', () => {
    const obsModule = new ObsidianModule({ vaultPath: '/vault' });
    assert.strictEqual(obsModule.canHandle('/vault/note.md'), true);
    assert.strictEqual(obsModule.canHandle('/other/note.md'), false);
  });

  it('should validate frontmatter', async () => {
    const file = join(tmpDir, 'note.md');
    await writeFile(file, '---\ntitle: Test\ntags: [test]\n---\n# Content\n');

    const result = await module.check([file]);
    assert.strictEqual(result.valid, true);
  });

  it('should detect invalid wikilinks', async () => {
    const file = join(tmpDir, 'links.md');
    await writeFile(file, '[[broken link with spaces  ]]');

    const result = await module.check([file]);
    assert.ok(result);
  });

  it('should return module info', () => {
    const info = module.getInfo();
    assert.strictEqual(info.name, 'obsidian');
  });
});
