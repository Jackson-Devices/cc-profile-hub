/**
 * Tests for FileDiscovery service
 *
 * @module file-discovery.test
 */

import { describe, it, before, after, mock } from 'node:test';
import * as assert from 'node:assert/strict';
import * as fs from 'node:fs/promises';
import * as path from 'node:path';
import * as os from 'node:os';
import FileDiscovery from '../../.github/scripts/orchestrator/file-discovery.mjs';

describe('FileDiscovery', () => {
  describe('Constructor', () => {
    it('should create instance with default options', () => {
      const discovery = new FileDiscovery();

      assert.equal(discovery.cwd, process.cwd());
      assert.ok(Array.isArray(discovery.excludePatterns));
      assert.ok(discovery.excludePatterns.length > 0);
    });

    it('should accept custom cwd', () => {
      const discovery = new FileDiscovery({ cwd: '/custom/path' });

      assert.equal(discovery.cwd, '/custom/path');
    });

    it('should accept custom exclude patterns', () => {
      const excludePatterns = ['*.test.js', 'dist/**'];
      const discovery = new FileDiscovery({ exclude_patterns: excludePatterns });

      assert.deepEqual(discovery.excludePatterns, excludePatterns);
    });

    it('should have default exclude patterns', () => {
      const discovery = new FileDiscovery();

      assert.ok(discovery.excludePatterns.includes('node_modules/**'));
      assert.ok(discovery.excludePatterns.includes('.git/**'));
    });
  });

  describe('discoverFiles()', () => {
    it('should throw error for unknown mode', async () => {
      const discovery = new FileDiscovery();

      await assert.rejects(
        async () => await discovery.discoverFiles({ mode: 'unknown' }),
        /Unknown discovery mode/
      );
    });

    it('should handle manual mode', async () => {
      const discovery = new FileDiscovery();
      const files = ['file1.sh', 'file2.js'];

      const result = await discovery.discoverFiles({
        mode: 'manual',
        files,
      });

      assert.deepEqual(result, files);
    });

    it('should throw error when manual mode missing files', async () => {
      const discovery = new FileDiscovery();

      await assert.rejects(
        async () => await discovery.discoverFiles({ mode: 'manual' }),
        /files array is required/
      );
    });
  });

  describe('discoverFromManualList()', () => {
    it('should return provided files', () => {
      const discovery = new FileDiscovery();
      const files = ['file1.sh', 'file2.js', 'file3.yml'];

      const result = discovery.discoverFromManualList({ files });

      assert.deepEqual(result, files);
    });

    it('should filter excluded files', () => {
      const discovery = new FileDiscovery({
        exclude_patterns: ['node_modules/**'],
      });

      const files = ['src/file1.sh', 'node_modules/package/file2.js', 'file3.yml'];

      const result = discovery.discoverFromManualList({ files });

      assert.deepEqual(result, ['src/file1.sh', 'file3.yml']);
    });

    it('should throw error when files is not array', () => {
      const discovery = new FileDiscovery();

      assert.throws(
        () => discovery.discoverFromManualList({ files: 'not-an-array' }),
        /files array is required/
      );
    });

    it('should handle empty array', () => {
      const discovery = new FileDiscovery();

      const result = discovery.discoverFromManualList({ files: [] });

      assert.deepEqual(result, []);
    });
  });

  describe('filterFiles()', () => {
    it('should filter files matching exclude patterns', () => {
      const discovery = new FileDiscovery({
        exclude_patterns: ['*.min.js', 'dist/**'],
      });

      const files = ['src/index.js', 'dist/bundle.js', 'index.min.js', 'lib/util.js'];

      const result = discovery.filterFiles(files);

      assert.deepEqual(result, ['src/index.js', 'lib/util.js']);
    });

    it('should handle ** pattern (match any depth)', () => {
      const discovery = new FileDiscovery({
        exclude_patterns: ['node_modules/**'],
      });

      const files = [
        'src/file.js',
        'node_modules/pkg/file.js',
        'node_modules/pkg/sub/file.js',
      ];

      const result = discovery.filterFiles(files);

      assert.deepEqual(result, ['src/file.js']);
    });

    it('should handle * pattern (match single level)', () => {
      const discovery = new FileDiscovery({
        exclude_patterns: ['*.min.js'],
      });

      const files = ['index.js', 'bundle.min.js', 'src/app.min.js'];

      const result = discovery.filterFiles(files);

      assert.deepEqual(result, ['index.js', 'src/app.min.js']);
    });

    it('should handle multiple patterns', () => {
      const discovery = new FileDiscovery({
        exclude_patterns: ['*.min.js', '*.min.css', 'dist/**', '.git/**'],
      });

      const files = [
        'src/index.js',
        'bundle.min.js',
        'styles.min.css',
        'dist/output.js',
        '.git/config',
      ];

      const result = discovery.filterFiles(files);

      assert.deepEqual(result, ['src/index.js']);
    });

    it('should return all files when no patterns match', () => {
      const discovery = new FileDiscovery({
        exclude_patterns: ['*.test.js'],
      });

      const files = ['src/index.js', 'lib/util.js'];

      const result = discovery.filterFiles(files);

      assert.deepEqual(result, files);
    });
  });

  describe('matchesPattern()', () => {
    let discovery;

    before(() => {
      discovery = new FileDiscovery();
    });

    it('should match exact file name', () => {
      assert.equal(discovery.matchesPattern('file.js', 'file.js'), true);
    });

    it('should match * wildcard', () => {
      assert.equal(discovery.matchesPattern('file.js', '*.js'), true);
      assert.equal(discovery.matchesPattern('test.js', '*.js'), true);
      assert.equal(discovery.matchesPattern('file.txt', '*.js'), false);
    });

    it('should match ** wildcard (any depth)', () => {
      assert.equal(discovery.matchesPattern('node_modules/pkg/file.js', 'node_modules/**'), true);
      assert.equal(
        discovery.matchesPattern('node_modules/pkg/sub/file.js', 'node_modules/**'),
        true
      );
      assert.equal(discovery.matchesPattern('src/file.js', 'node_modules/**'), false);
    });

    it('should match patterns with directory separators', () => {
      assert.equal(discovery.matchesPattern('src/components/App.tsx', 'src/**/*.tsx'), true);
      assert.equal(discovery.matchesPattern('lib/utils.tsx', 'src/**/*.tsx'), false);
    });

    it('should handle patterns without wildcards', () => {
      assert.equal(discovery.matchesPattern('exact-file.js', 'exact-file.js'), true);
      assert.equal(discovery.matchesPattern('other-file.js', 'exact-file.js'), false);
    });

    it('should handle dots in patterns', () => {
      assert.equal(discovery.matchesPattern('file.min.js', '*.min.js'), true);
      assert.equal(discovery.matchesPattern('file.test.js', '*.test.js'), true);
    });
  });

  describe('classifyFiles()', () => {
    let discovery;

    before(() => {
      discovery = new FileDiscovery();
    });

    it('should classify shell files', () => {
      const files = ['script.sh', 'script.bash', 'script.zsh'];

      const result = discovery.classifyFiles(files);

      assert.deepEqual(result.classified.shell, files);
      assert.equal(result.total, 3);
    });

    it('should classify JavaScript files', () => {
      const files = ['index.js', 'module.mjs', 'config.cjs', 'App.tsx'];

      const result = discovery.classifyFiles(files);

      assert.deepEqual(result.classified.javascript, files);
    });

    it('should classify YAML files', () => {
      const files = ['config.yml', 'workflow.yaml'];

      const result = discovery.classifyFiles(files);

      assert.deepEqual(result.classified.yaml, files);
    });

    it('should classify multiple file types', () => {
      const files = ['script.sh', 'index.js', 'config.yml', 'test.py'];

      const result = discovery.classifyFiles(files);

      assert.deepEqual(result.classified.shell, ['script.sh']);
      assert.deepEqual(result.classified.javascript, ['index.js']);
      assert.deepEqual(result.classified.yaml, ['config.yml']);
      assert.deepEqual(result.classified.python, ['test.py']);
      assert.equal(result.total, 4);
    });

    it('should handle unknown file types', () => {
      const files = ['unknown.xyz', 'another.abc'];

      const result = discovery.classifyFiles(files);

      assert.deepEqual(result.unknown, files);
      assert.equal(result.total, 2);
    });

    it('should handle mix of known and unknown files', () => {
      const files = ['script.sh', 'unknown.xyz', 'index.js'];

      const result = discovery.classifyFiles(files);

      assert.deepEqual(result.classified.shell, ['script.sh']);
      assert.deepEqual(result.classified.javascript, ['index.js']);
      assert.deepEqual(result.unknown, ['unknown.xyz']);
      assert.equal(result.total, 3);
    });

    it('should handle empty array', () => {
      const result = discovery.classifyFiles([]);

      assert.deepEqual(result.classified, {});
      assert.deepEqual(result.unknown, []);
      assert.equal(result.total, 0);
    });

    it('should handle files with paths', () => {
      const files = ['src/script.sh', 'lib/index.js', '.github/workflows/ci.yml'];

      const result = discovery.classifyFiles(files);

      assert.deepEqual(result.classified.shell, ['src/script.sh']);
      assert.deepEqual(result.classified.javascript, ['lib/index.js']);
      assert.deepEqual(result.classified.yaml, ['.github/workflows/ci.yml']);
    });

    it('should classify C++ files', () => {
      const files = ['main.cpp', 'header.h', 'class.hpp', 'arduino.ino'];

      const result = discovery.classifyFiles(files);

      assert.deepEqual(result.classified.cpp, files);
    });

    it('should classify multiple file types correctly', () => {
      const files = [
        'script.sh',
        'index.js',
        'config.yml',
        'test.py',
        'main.cpp',
        'styles.css',
        'index.html',
        'README.md',
        'package.json',
      ];

      const result = discovery.classifyFiles(files);

      assert.equal(result.classified.shell[0], 'script.sh');
      assert.equal(result.classified.javascript[0], 'index.js');
      assert.equal(result.classified.yaml[0], 'config.yml');
      assert.equal(result.classified.python[0], 'test.py');
      assert.equal(result.classified.cpp[0], 'main.cpp');
      assert.equal(result.classified.css[0], 'styles.css');
      assert.equal(result.classified.html[0], 'index.html');
      assert.equal(result.classified.markdown[0], 'README.md');
      assert.equal(result.classified.json[0], 'package.json');
      assert.equal(result.total, 9);
    });
  });

  describe('getStatistics()', () => {
    let discovery;

    before(() => {
      discovery = new FileDiscovery();
    });

    it('should generate statistics from classification', () => {
      const classification = {
        classified: {
          shell: ['script.sh'],
          javascript: ['index.js', 'module.mjs'],
          yaml: ['config.yml'],
        },
        unknown: ['unknown.xyz'],
        total: 5,
      };

      const stats = discovery.getStatistics(classification);

      assert.equal(stats.total, 5);
      assert.equal(stats.by_type.shell, 1);
      assert.equal(stats.by_type.javascript, 2);
      assert.equal(stats.by_type.yaml, 1);
      assert.equal(stats.unknown, 1);
    });

    it('should handle empty classification', () => {
      const classification = {
        classified: {},
        unknown: [],
        total: 0,
      };

      const stats = discovery.getStatistics(classification);

      assert.equal(stats.total, 0);
      assert.deepEqual(stats.by_type, {});
      assert.equal(stats.unknown, 0);
    });

    it('should handle all unknown files', () => {
      const classification = {
        classified: {},
        unknown: ['file1.xyz', 'file2.abc'],
        total: 2,
      };

      const stats = discovery.getStatistics(classification);

      assert.equal(stats.total, 2);
      assert.deepEqual(stats.by_type, {});
      assert.equal(stats.unknown, 2);
    });
  });

  describe('verifyFilesExist()', () => {
    let tempDir;
    let discovery;

    before(async () => {
      // Create temporary directory
      tempDir = await fs.mkdtemp(path.join(os.tmpdir(), 'file-discovery-test-'));

      // Create some test files
      await fs.writeFile(path.join(tempDir, 'existing1.js'), '// test');
      await fs.writeFile(path.join(tempDir, 'existing2.sh'), '#!/bin/bash');

      discovery = new FileDiscovery({ cwd: tempDir });
    });

    after(async () => {
      // Clean up temp directory
      try {
        await fs.rm(tempDir, { recursive: true, force: true });
      } catch (error) {
        // Ignore cleanup errors
      }
    });

    it('should identify existing files', async () => {
      const result = await discovery.verifyFilesExist(['existing1.js', 'existing2.sh']);

      assert.deepEqual(result.existing, ['existing1.js', 'existing2.sh']);
      assert.deepEqual(result.missing, []);
    });

    it('should identify missing files', async () => {
      const result = await discovery.verifyFilesExist(['missing1.js', 'missing2.sh']);

      assert.deepEqual(result.existing, []);
      assert.deepEqual(result.missing, ['missing1.js', 'missing2.sh']);
    });

    it('should handle mix of existing and missing files', async () => {
      const result = await discovery.verifyFilesExist([
        'existing1.js',
        'missing1.js',
        'existing2.sh',
        'missing2.sh',
      ]);

      assert.deepEqual(result.existing, ['existing1.js', 'existing2.sh']);
      assert.deepEqual(result.missing, ['missing1.js', 'missing2.sh']);
    });

    it('should handle empty array', async () => {
      const result = await discovery.verifyFilesExist([]);

      assert.deepEqual(result.existing, []);
      assert.deepEqual(result.missing, []);
    });

    it('should handle absolute paths', async () => {
      const absolutePath = path.join(tempDir, 'existing1.js');
      const result = await discovery.verifyFilesExist([absolutePath]);

      assert.deepEqual(result.existing, [absolutePath]);
      assert.deepEqual(result.missing, []);
    });
  });
});
