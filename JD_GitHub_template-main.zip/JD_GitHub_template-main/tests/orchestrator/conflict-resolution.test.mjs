#!/usr/bin/env node
/* eslint-env mocha */

/**
 * Tests for Conflict Resolution Analyzer
 *
 * Following TDD principles - these tests define the expected behavior
 * before implementation.
 *
 * Detects and analyzes merge conflicts:
 * - Parses conflict markers (<<<<<<, =======, >>>>>>)
 * - Analyzes conflict types (both modified, added/deleted, etc.)
 * - Suggests resolution strategies
 * - Provides human-readable reports
 */

import { describe, it } from 'node:test';
import assert from 'node:assert/strict';
import {
  conflictDetector,
  conflictParser,
  conflictAnalyzer,
  reportGenerator,
} from '../../scripts/conflict-resolution-analyzer.mjs';

// Create consistent interface for tests
const mockAnalyzer = {
  hasConflicts: conflictDetector.hasConflicts,
  parseConflicts: conflictParser.parseConflicts,
  analyzeConflict: conflictAnalyzer.analyzeConflict,
  generateReport: reportGenerator.generateReport,
};

describe('Conflict Detection', () => {
  it('should detect files with conflict markers', () => {
    const fileContent = `
function hello() {
<<<<<<< HEAD
  console.log('Hello from main');
=======
  console.log('Hello from feature');
>>>>>>> feature-branch
}
`;

    const result = mockAnalyzer.hasConflicts(fileContent);
    assert.ok(result.hasConflicts, 'Should detect conflict markers');
    assert.equal(result.conflictCount, 1, 'Should count 1 conflict');
  });

  it('should detect multiple conflicts in one file', () => {
    const fileContent = `
<<<<<<< HEAD
const version = '1.0.0';
=======
const version = '2.0.0';
>>>>>>> feature

<<<<<<< HEAD
const author = 'Alice';
=======
const author = 'Bob';
>>>>>>> feature
`;

    const result = mockAnalyzer.hasConflicts(fileContent);
    assert.ok(result.hasConflicts);
    assert.equal(result.conflictCount, 2, 'Should count 2 conflicts');
  });

  it('should return false for files without conflicts', () => {
    const fileContent = `
function hello() {
  console.log('No conflicts here');
}
`;

    const result = mockAnalyzer.hasConflicts(fileContent);
    assert.ok(!result.hasConflicts, 'Should not detect conflicts');
    assert.equal(result.conflictCount, 0);
  });

  it('should handle incomplete conflict markers', () => {
    const fileContent = `
<<<<<<< HEAD
This is incomplete
// Missing middle and end markers
`;

    const result = mockAnalyzer.hasConflicts(fileContent);
    assert.ok(result.hasConflicts, 'Should detect incomplete conflict');
    assert.ok(result.incompleteMarkers, 'Should flag incomplete markers');
  });
});

describe('Conflict Parsing', () => {
  it('should parse simple conflict blocks', () => {
    const fileContent = `
<<<<<<< HEAD
const value = 'from-main';
=======
const value = 'from-feature';
>>>>>>> feature-branch
`;

    const conflicts = mockAnalyzer.parseConflicts(fileContent);

    assert.equal(conflicts.length, 1);
    assert.equal(conflicts[0].ours, "const value = 'from-main';");
    assert.equal(conflicts[0].theirs, "const value = 'from-feature';");
    assert.equal(conflicts[0].base, null); // No base in simple conflict
  });

  it('should parse conflicts with diff3 format', () => {
    const fileContent = `
<<<<<<< HEAD
const value = 'from-main';
||||||| base
const value = 'original';
=======
const value = 'from-feature';
>>>>>>> feature-branch
`;

    const conflicts = mockAnalyzer.parseConflicts(fileContent);

    assert.equal(conflicts.length, 1);
    assert.equal(conflicts[0].ours, "const value = 'from-main';");
    assert.equal(conflicts[0].theirs, "const value = 'from-feature';");
    assert.equal(conflicts[0].base, "const value = 'original';");
  });

  it('should extract line numbers for conflicts', () => {
    const fileContent = `line 1
line 2
<<<<<<< HEAD
conflict line
=======
other line
>>>>>>> feature
line 8`;

    const conflicts = mockAnalyzer.parseConflicts(fileContent);

    assert.equal(conflicts[0].startLine, 3);
    assert.equal(conflicts[0].endLine, 7);
  });

  it('should preserve surrounding context', () => {
    const fileContent = `function test() {
<<<<<<< HEAD
  return true;
=======
  return false;
>>>>>>> feature
}`;

    const conflicts = mockAnalyzer.parseConflicts(fileContent);

    assert.ok(conflicts[0].beforeContext.includes('function test()'));
    assert.ok(conflicts[0].afterContext.includes('}'));
  });
});

describe('Conflict Analysis', () => {
  it('should identify "both modified" conflicts', () => {
    const conflict = {
      ours: "const value = 'main';",
      theirs: "const value = 'feature';",
      base: "const value = 'original';",
    };

    const analysis = mockAnalyzer.analyzeConflict(conflict);

    assert.equal(analysis.type, 'both_modified');
    assert.ok(analysis.suggestion, 'Should provide a suggestion');
  });

  it('should identify "both added" conflicts', () => {
    const conflict = {
      ours: 'new line from main',
      theirs: 'new line from feature',
      base: null,
    };

    const analysis = mockAnalyzer.analyzeConflict(conflict);

    assert.equal(analysis.type, 'both_added');
  });

  it('should identify "modified vs deleted" conflicts', () => {
    const conflict = {
      ours: '',
      theirs: 'const value = "kept";',
      base: 'const value = "original";',
    };

    const analysis = mockAnalyzer.analyzeConflict(conflict);

    assert.equal(analysis.type, 'modified_deleted');
  });

  it('should detect whitespace-only differences', () => {
    const conflict = {
      ours: 'const value = "test";',
      theirs: '  const value = "test";  ',
      base: null,
    };

    const analysis = mockAnalyzer.analyzeConflict(conflict);

    assert.equal(analysis.type, 'whitespace_only');
    assert.equal(analysis.autoResolvable, true);
  });

  it('should detect identical changes', () => {
    const conflict = {
      ours: 'const value = "same";',
      theirs: 'const value = "same";',
      base: 'const value = "original";',
    };

    const analysis = mockAnalyzer.analyzeConflict(conflict);

    assert.equal(analysis.type, 'identical_change');
    assert.equal(analysis.autoResolvable, true);
  });

  it('should suggest keeping both for non-conflicting additions', () => {
    const conflict = {
      ours: 'import moduleA;',
      theirs: 'import moduleB;',
      base: null,
    };

    const analysis = mockAnalyzer.analyzeConflict(conflict);

    assert.ok(analysis.suggestion.includes('both'), 'Should suggest keeping both');
  });
});

describe('Resolution Strategies', () => {
  it('should provide resolution options for conflicts', () => {
    const conflict = {
      ours: "const value = 'main';",
      theirs: "const value = 'feature';",
      base: null,
    };

    const analysis = mockAnalyzer.analyzeConflict(conflict);

    assert.ok(Array.isArray(analysis.resolutionOptions));
    assert.ok(analysis.resolutionOptions.length >= 2);

    const options = analysis.resolutionOptions.map((o) => o.value);
    assert.ok(options.includes('keep_ours'));
    assert.ok(options.includes('keep_theirs'));
  });

  it('should provide merge option for compatible changes', () => {
    const conflict = {
      ours: 'function test() { doA(); }',
      theirs: 'function test() { doB(); }',
      base: 'function test() {}',
    };

    const analysis = mockAnalyzer.analyzeConflict(conflict);

    const options = analysis.resolutionOptions.map((o) => o.value);
    assert.ok(options.includes('merge_both'));
  });

  it('should provide custom edit option', () => {
    const conflict = {
      ours: 'complex change',
      theirs: 'other complex change',
      base: null,
    };

    const analysis = mockAnalyzer.analyzeConflict(conflict);

    const options = analysis.resolutionOptions.map((o) => o.value);
    assert.ok(options.includes('custom_edit'));
  });
});

describe('Report Generation', () => {
  it('should generate human-readable conflict report', () => {
    const conflicts = [
      {
        startLine: 5,
        endLine: 9,
        ours: "const x = 'main';",
        theirs: "const x = 'feature';",
      },
    ];

    const report = mockAnalyzer.generateReport(conflicts);

    assert.ok(typeof report === 'string');
    assert.ok(report.includes('1 conflict'));
    assert.ok(report.includes('Line 5-9'));
  });

  it('should summarize conflict types', () => {
    const conflicts = [
      { type: 'both_modified' },
      { type: 'both_modified' },
      { type: 'both_added' },
    ];

    const report = mockAnalyzer.generateReport(conflicts);

    assert.ok(report.includes('2 both_modified'));
    assert.ok(report.includes('1 both_added'));
  });

  it('should highlight auto-resolvable conflicts', () => {
    const conflicts = [
      { type: 'identical_change', autoResolvable: true },
      { type: 'both_modified', autoResolvable: false },
    ];

    const report = mockAnalyzer.generateReport(conflicts);

    assert.ok(report.includes('1 auto-resolvable'));
  });

  it('should provide actionable next steps', () => {
    const conflicts = [{ type: 'both_modified' }];

    const report = mockAnalyzer.generateReport(conflicts);

    assert.ok(report.includes('next step') || report.includes('action'));
  });
});

describe('Edge Cases', () => {
  it('should handle conflicts in binary file markers', () => {
    const fileContent = `
Binary files differ
<<<<<<< HEAD
(binary content representation)
=======
(different binary content)
>>>>>>> feature
`;

    const result = mockAnalyzer.hasConflicts(fileContent);
    assert.ok(result.hasConflicts);
    assert.ok(result.binaryConflict);
  });

  it('should handle very large conflict blocks', () => {
    const largeBlock = 'line\n'.repeat(1000);
    const fileContent = `
<<<<<<< HEAD
${largeBlock}
=======
${largeBlock}different
>>>>>>> feature
`;

    const conflicts = mockAnalyzer.parseConflicts(fileContent);
    assert.equal(conflicts.length, 1);
    assert.ok(conflicts[0].large, 'Should flag large conflicts');
  });

  it('should handle nested-looking markers in strings', () => {
    const fileContent = `
const example = \`
This is not a real conflict marker:
<<<<<<< HEAD
Just a string literal
=======
\`;
`;

    const result = mockAnalyzer.hasConflicts(fileContent);
    assert.ok(!result.hasConflicts, 'Should not detect false positives in strings');
  });

  it('should handle conflicts with special characters', () => {
    const fileContent = `
<<<<<<< HEAD
const emoji = '🎉';
=======
const emoji = '🚀';
>>>>>>> feature
`;

    const conflicts = mockAnalyzer.parseConflicts(fileContent);
    assert.equal(conflicts.length, 1);
    assert.ok(conflicts[0].ours.includes('🎉'));
  });
});
