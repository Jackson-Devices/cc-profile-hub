#!/usr/bin/env node
/* eslint-env mocha */

/**
 * Tests for Naming Convention Checker
 *
 * Following TDD principles - these tests define the expected behavior
 * before implementation.
 *
 * Conventions to enforce:
 * - Branch names: type/description (e.g., feature/user-auth, fix/login-bug)
 * - Commit messages: Conventional Commits (e.g., feat: add login, fix(auth): resolve token issue)
 * - Issue titles: [TYPE] Description (e.g., [BUG] Login fails, [FEATURE] Add dark mode)
 */

import { describe, it } from 'node:test';
import assert from 'node:assert/strict';
import {
  branchValidation,
  commitValidation,
  issueValidation,
} from '../../scripts/naming-convention-checker.mjs';

// Create consistent interface for tests
const mockValidate = {
  branch: branchValidation.validate,
  commit: commitValidation.validate,
  issue: issueValidation.validate,
};

const mockSuggest = {
  branch: branchValidation.suggest,
  commit: commitValidation.suggest,
  issue: issueValidation.suggest,
};

const mockExtract = {
  branchType: branchValidation.extractType,
  commitType: commitValidation.extractType,
  issueType: issueValidation.extractType,
};

describe('Branch Naming Convention', () => {
  it('should validate conventional branch names', () => {
    // Valid branch names
    const validNames = [
      'feature/user-auth',
      'fix/login-bug',
      'docs/api-guide',
      'refactor/cleanup-code',
      'test/add-unit-tests',
      'chore/update-deps',
      'perf/optimize-query',
      'ci/update-workflow',
    ];

    for (const name of validNames) {
      const result = mockValidate.branch(name);
      // This will fail until implementation
      assert.ok(result.valid, `Expected "${name}" to be valid`);
    }
  });

  it('should reject invalid branch names', () => {
    const invalidNames = [
      'my_random_branch', // underscores
      'FEATURE-123', // uppercase
      'feature', // no slash
      'Feature/test', // capitalized type
      'feat/MY_BRANCH', // underscores in description
      'random-stuff', // no type
      '123-branch', // starts with number
    ];

    for (const name of invalidNames) {
      const result = mockValidate.branch(name);
      // This will fail until implementation
      assert.ok(!result.valid, `Expected "${name}" to be invalid`);
    }
  });

  it('should suggest corrections for invalid branch names', () => {
    const testCases = [
      { input: 'my_branch', expected: 'feature/my-branch' },
      { input: 'FIX_BUG', expected: 'fix/bug' },
      { input: 'UpdateDocs', expected: 'docs/update-docs' },
      { input: 'feature_user_auth', expected: 'feature/user-auth' },
    ];

    for (const { input, expected } of testCases) {
      const suggestion = mockSuggest.branch(input);
      // This will fail until implementation
      assert.equal(suggestion, expected, `Expected suggestion for "${input}" to be "${expected}"`);
    }
  });

  it('should extract type from branch name', () => {
    const testCases = [
      { input: 'feature/auth', expected: 'feature' },
      { input: 'fix/bug', expected: 'fix' },
      { input: 'docs/readme', expected: 'docs' },
      { input: 'invalid', expected: null },
      { input: 'no-slash-here', expected: null },
    ];

    for (const { input, expected } of testCases) {
      const type = mockExtract.branchType(input);
      // This will fail until implementation
      assert.equal(type, expected, `Expected type of "${input}" to be "${expected}"`);
    }
  });

  it('should handle special cases', () => {
    // Main/master/develop should always be valid
    const protectedBranches = ['main', 'master', 'develop', 'development'];

    for (const branch of protectedBranches) {
      const result = mockValidate.branch(branch);
      // This will fail until implementation
      assert.ok(result.valid, `Protected branch "${branch}" should always be valid`);
    }
  });

  it('should allow hyphens in description', () => {
    const validNames = [
      'feature/add-user-authentication',
      'fix/resolve-login-token-issue',
      'docs/update-api-documentation',
    ];

    for (const name of validNames) {
      const result = mockValidate.branch(name);
      // This will fail until implementation
      assert.ok(result.valid, `Expected "${name}" with multiple hyphens to be valid`);
    }
  });
});

describe('Commit Message Convention', () => {
  it('should validate conventional commits', () => {
    const validMessages = [
      'feat: add login',
      'fix: resolve token issue',
      'docs: update README',
      'style: format code',
      'refactor: simplify auth logic',
      'test: add unit tests',
      'chore: update dependencies',
      'perf: optimize database query',
      'ci: update workflow',
      'build: update build script',
    ];

    for (const message of validMessages) {
      const result = mockValidate.commit(message);
      // This will fail until implementation
      assert.ok(result.valid, `Expected "${message}" to be valid`);
    }
  });

  it('should validate commits with scope', () => {
    const validMessages = [
      'feat(auth): add login',
      'fix(api): resolve endpoint issue',
      'docs(readme): update installation steps',
      'refactor(ui): simplify component',
    ];

    for (const message of validMessages) {
      const result = mockValidate.commit(message);
      // This will fail until implementation
      assert.ok(result.valid, `Expected "${message}" with scope to be valid`);
    }
  });

  it('should validate commits with breaking change', () => {
    const validMessages = [
      'feat!: change API interface',
      'fix(auth)!: remove deprecated method',
    ];

    for (const message of validMessages) {
      const result = mockValidate.commit(message);
      // This will fail until implementation
      assert.ok(result.valid, `Expected "${message}" with breaking change to be valid`);
    }
  });

  it('should reject invalid commits', () => {
    const invalidMessages = [
      'fixed stuff', // no type
      'Fix: login bug', // capitalized type
      'feat add feature', // missing colon
      'feat:', // no description
      'random commit message', // no convention
      'FEAT: add feature', // uppercase type
    ];

    for (const message of invalidMessages) {
      const result = mockValidate.commit(message);
      // This will fail until implementation
      assert.ok(!result.valid, `Expected "${message}" to be invalid`);
    }
  });

  it('should suggest corrections', () => {
    const testCases = [
      { input: 'fixed login bug', expected: 'fix: resolve login bug' },
      { input: 'Added new feature', expected: 'feat: add new feature' },
      { input: 'Update docs', expected: 'docs: update docs' },
      { input: 'refactored code', expected: 'refactor: refactor code' },
    ];

    for (const { input, expected } of testCases) {
      const suggestion = mockSuggest.commit(input);
      // This will fail until implementation
      assert.equal(suggestion, expected, `Expected suggestion for "${input}" to be "${expected}"`);
    }
  });

  it('should extract commit type', () => {
    const testCases = [
      { input: 'feat: add login', expected: 'feat' },
      { input: 'fix(auth): resolve issue', expected: 'fix' },
      { input: 'docs!: breaking docs change', expected: 'docs' },
      { input: 'invalid message', expected: null },
    ];

    for (const { input, expected } of testCases) {
      const type = mockExtract.commitType(input);
      // This will fail until implementation
      assert.equal(type, expected, `Expected type of "${input}" to be "${expected}"`);
    }
  });
});

describe('Issue Title Convention', () => {
  it('should validate issue titles', () => {
    const validTitles = [
      '[BUG] Login fails',
      '[FEATURE] Add dark mode',
      '[DOCS] Update API documentation',
      '[ENHANCEMENT] Improve performance',
      '[QUESTION] How to use feature X?',
      '[TASK] Refactor authentication',
    ];

    for (const title of validTitles) {
      const result = mockValidate.issue(title);
      // This will fail until implementation
      assert.ok(result.valid, `Expected "${title}" to be valid`);
    }
  });

  it('should reject invalid issue titles', () => {
    const invalidTitles = [
      'need to fix this', // no type tag
      '[bug] Login fails', // lowercase type
      'Bug: Login fails', // wrong format
      '[BUG]', // no description
      '[] Empty type', // empty type
      '[RANDOM] Invalid type', // invalid type
    ];

    for (const title of invalidTitles) {
      const result = mockValidate.issue(title);
      // This will fail until implementation
      assert.ok(!result.valid, `Expected "${title}" to be invalid`);
    }
  });

  it('should suggest corrections', () => {
    const testCases = [
      { input: 'Login is broken', expected: '[BUG] Login is broken' },
      { input: 'Add new feature', expected: '[FEATURE] Add new feature' },
      { input: 'Update documentation', expected: '[DOCS] Update documentation' },
    ];

    for (const { input, expected } of testCases) {
      const suggestion = mockSuggest.issue(input);
      // This will fail until implementation
      assert.equal(suggestion, expected, `Expected suggestion for "${input}" to be "${expected}"`);
    }
  });

  it('should extract issue type', () => {
    const testCases = [
      { input: '[BUG] Login fails', expected: 'BUG' },
      { input: '[FEATURE] Add dark mode', expected: 'FEATURE' },
      { input: '[DOCS] Update README', expected: 'DOCS' },
      { input: 'Invalid title', expected: null },
    ];

    for (const { input, expected } of testCases) {
      const type = mockExtract.issueType(input);
      // This will fail until implementation
      assert.equal(type, expected, `Expected type of "${input}" to be "${expected}"`);
    }
  });

  it('should handle titles with special characters', () => {
    const validTitles = [
      '[BUG] Login fails with 500 error',
      '[FEATURE] Add support for OAuth 2.0',
      '[DOCS] Update API docs (v2.0)',
      '[ENHANCEMENT] Improve UX/UI performance',
    ];

    for (const title of validTitles) {
      const result = mockValidate.issue(title);
      // This will fail until implementation
      assert.ok(result.valid, `Expected "${title}" with special chars to be valid`);
    }
  });
});

describe('Convention Enforcement', () => {
  it('should provide detailed validation results', () => {
    const result = mockValidate.branch('my_invalid_branch');

    // This will fail until implementation
    assert.ok(Object.hasOwn(result, 'valid'), 'Result should have valid property');
    assert.ok(Object.hasOwn(result, 'reason'), 'Result should have reason property');

    if (!result.valid) {
      assert.ok(typeof result.reason === 'string', 'Reason should be a string');
      assert.ok(result.reason.length > 0, 'Reason should not be empty');
    }
  });

  it('should provide actionable suggestions', () => {
    const suggestion = mockSuggest.branch('my_invalid_branch');

    // This will fail until implementation
    assert.ok(typeof suggestion === 'string', 'Suggestion should be a string');
    assert.ok(suggestion.length > 0, 'Suggestion should not be empty');

    // Suggestion should be valid
    const validationResult = mockValidate.branch(suggestion);
    assert.ok(validationResult.valid, 'Suggested name should be valid');
  });
});
