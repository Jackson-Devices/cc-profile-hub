/**
 * Tests for Recipe System
 *
 * TDD Approach: These tests are written FIRST, before implementation
 */

import { describe, it, beforeEach, afterEach } from 'node:test';
import assert from 'node:assert';
import { mkdtemp, rm, writeFile, readFile, mkdir } from 'node:fs/promises';
import { join } from 'node:path';
import { tmpdir } from 'node:os';
import { existsSync } from 'node:fs';

// Import the modules we're testing (will fail initially - that's TDD!)
import { Recipe, RecipeRegistry } from '../../.github/scripts/orchestrator/recipe-system.mjs';

describe('Recipe System', () => {
  let tmpDir;

  beforeEach(async () => {
    // Create temp directory for test files
    tmpDir = await mkdtemp(join(tmpdir(), 'recipe-test-'));
  });

  afterEach(async () => {
    // Cleanup
    await rm(tmpDir, { recursive: true, force: true });
  });

  describe('Recipe - template rendering', () => {
    it('should render simple template with inputs', () => {
      const recipe = new Recipe({
        name: 'test-recipe',
        inputs: [
          { name: 'project_name', type: 'string', required: true }
        ],
        actions: []
      });

      const template = 'Project: {{project_name}}';
      const inputs = { project_name: 'MyProject' };

      const result = recipe.renderTemplate(template, inputs);

      assert.strictEqual(result, 'Project: MyProject');
    });

    it('should render template with multiple variables', () => {
      const recipe = new Recipe({
        name: 'test-recipe',
        inputs: [],
        actions: []
      });

      const template = '# {{title}}\n\n{{description}}\n\nAuthor: {{author}}';
      const inputs = {
        title: 'Test Project',
        description: 'A test project',
        author: 'John Doe'
      };

      const result = recipe.renderTemplate(template, inputs);

      assert.strictEqual(result, '# Test Project\n\nA test project\n\nAuthor: John Doe');
    });

    it('should handle missing variables gracefully', () => {
      const recipe = new Recipe({
        name: 'test-recipe',
        inputs: [],
        actions: []
      });

      const template = 'Hello {{name}}';
      const inputs = {};

      const result = recipe.renderTemplate(template, inputs);

      // Should leave placeholder if no value provided
      assert.strictEqual(result, 'Hello {{name}}');
    });
  });

  describe('Recipe - input validation', () => {
    it('should validate required inputs', () => {
      const recipe = new Recipe({
        name: 'test-recipe',
        inputs: [
          { name: 'project_name', type: 'string', required: true }
        ],
        actions: []
      });

      assert.throws(
        () => recipe.validateInputs({}),
        /Required input missing: project_name/
      );
    });

    it('should use default values for optional inputs', () => {
      const recipe = new Recipe({
        name: 'test-recipe',
        inputs: [
          { name: 'author', type: 'string', default: 'Anonymous' }
        ],
        actions: []
      });

      const result = recipe.validateInputs({});

      assert.strictEqual(result.author, 'Anonymous');
    });

    it('should override defaults when value provided', () => {
      const recipe = new Recipe({
        name: 'test-recipe',
        inputs: [
          { name: 'author', type: 'string', default: 'Anonymous' }
        ],
        actions: []
      });

      const result = recipe.validateInputs({ author: 'John Doe' });

      assert.strictEqual(result.author, 'John Doe');
    });

    it('should validate all required inputs', () => {
      const recipe = new Recipe({
        name: 'test-recipe',
        inputs: [
          { name: 'name', type: 'string', required: true },
          { name: 'version', type: 'string', required: true },
          { name: 'description', type: 'string', default: '' }
        ],
        actions: []
      });

      const valid = recipe.validateInputs({
        name: 'test',
        version: '1.0.0'
      });

      assert.strictEqual(valid.name, 'test');
      assert.strictEqual(valid.version, '1.0.0');
      assert.strictEqual(valid.description, '');
    });
  });

  describe('Recipe - create_file action', () => {
    it('should create file with rendered template', async () => {
      const recipe = new Recipe({
        name: 'readme-recipe',
        inputs: [
          { name: 'project_name', type: 'string', required: true },
          { name: 'description', type: 'string', required: true }
        ],
        actions: [
          {
            type: 'create_file',
            path: join(tmpDir, 'README.md'),
            template: '# {{project_name}}\n\n{{description}}\n'
          }
        ]
      });

      const result = await recipe.execute({
        project_name: 'TestProject',
        description: 'A test project'
      });

      assert.strictEqual(result.success, true);
      assert.ok(existsSync(join(tmpDir, 'README.md')));

      const content = await readFile(join(tmpDir, 'README.md'), 'utf8');
      assert.strictEqual(content, '# TestProject\n\nA test project\n');
    });

    it('should create multiple files', async () => {
      const recipe = new Recipe({
        name: 'project-setup',
        inputs: [
          { name: 'name', type: 'string', required: true }
        ],
        actions: [
          {
            type: 'create_file',
            path: join(tmpDir, 'README.md'),
            template: '# {{name}}\n'
          },
          {
            type: 'create_file',
            path: join(tmpDir, 'package.json'),
            template: '{"name": "{{name}}"}\n'
          }
        ]
      });

      const result = await recipe.execute({ name: 'my-project' });

      assert.strictEqual(result.success, true);
      assert.strictEqual(result.results.length, 2);
      assert.ok(existsSync(join(tmpDir, 'README.md')));
      assert.ok(existsSync(join(tmpDir, 'package.json')));
    });

    it('should create nested directory structure', async () => {
      const recipe = new Recipe({
        name: 'nested-recipe',
        inputs: [],
        actions: [
          {
            type: 'create_file',
            path: join(tmpDir, 'src', 'index.js'),
            template: 'console.log("Hello");\n'
          }
        ]
      });

      const result = await recipe.execute({});

      assert.strictEqual(result.success, true);
      assert.ok(existsSync(join(tmpDir, 'src', 'index.js')));
    });
  });

  describe('Recipe - modify_file action', () => {
    it('should merge JSON data into existing file', async () => {
      // Create initial file
      const pkgPath = join(tmpDir, 'package.json');
      await writeFile(pkgPath, JSON.stringify({
        name: 'test-project',
        version: '1.0.0'
      }, null, 2));

      const recipe = new Recipe({
        name: 'add-scripts',
        inputs: [],
        actions: [
          {
            type: 'modify_file',
            path: pkgPath,
            operation: 'merge',
            data: {
              scripts: {
                test: 'node test.js',
                build: 'node build.js'
              }
            }
          }
        ]
      });

      const result = await recipe.execute({});

      assert.strictEqual(result.success, true);

      const content = JSON.parse(await readFile(pkgPath, 'utf8'));
      assert.strictEqual(content.name, 'test-project');
      assert.strictEqual(content.version, '1.0.0');
      assert.strictEqual(content.scripts.test, 'node test.js');
      assert.strictEqual(content.scripts.build, 'node build.js');
    });

    it('should append text to file', async () => {
      const filePath = join(tmpDir, 'notes.txt');
      await writeFile(filePath, 'Initial content\n');

      const recipe = new Recipe({
        name: 'append-note',
        inputs: [
          { name: 'note', type: 'string', required: true }
        ],
        actions: [
          {
            type: 'modify_file',
            path: filePath,
            operation: 'append',
            template: '{{note}}\n'
          }
        ]
      });

      const result = await recipe.execute({ note: 'New note' });

      assert.strictEqual(result.success, true);

      const content = await readFile(filePath, 'utf8');
      assert.strictEqual(content, 'Initial content\nNew note\n');
    });
  });

  describe('RecipeRegistry', () => {
    it('should register and retrieve recipes', () => {
      const registry = new RecipeRegistry();
      const recipe = new Recipe({
        name: 'test-recipe',
        inputs: [],
        actions: []
      });

      registry.register('test-recipe', recipe);

      const retrieved = registry.get('test-recipe');
      assert.strictEqual(retrieved, recipe);
    });

    it('should return undefined for non-existent recipe', () => {
      const registry = new RecipeRegistry();

      const result = registry.get('non-existent');

      assert.strictEqual(result, undefined);
    });

    it('should list all registered recipes', () => {
      const registry = new RecipeRegistry();

      registry.register('recipe1', new Recipe({ name: 'recipe1', inputs: [], actions: [] }));
      registry.register('recipe2', new Recipe({ name: 'recipe2', inputs: [], actions: [] }));

      const names = registry.list();

      assert.strictEqual(names.length, 2);
      assert.ok(names.includes('recipe1'));
      assert.ok(names.includes('recipe2'));
    });

    it('should apply recipe by name', async () => {
      const registry = new RecipeRegistry();
      const recipe = new Recipe({
        name: 'test-recipe',
        inputs: [
          { name: 'value', type: 'string', required: true }
        ],
        actions: [
          {
            type: 'create_file',
            path: join(tmpDir, 'output.txt'),
            template: '{{value}}\n'
          }
        ]
      });

      registry.register('test-recipe', recipe);

      const result = await registry.apply('test-recipe', { value: 'Hello' });

      assert.strictEqual(result.success, true);
      assert.ok(existsSync(join(tmpDir, 'output.txt')));
    });

    it('should throw error when applying non-existent recipe', async () => {
      const registry = new RecipeRegistry();

      await assert.rejects(
        async () => await registry.apply('non-existent', {}),
        /Recipe not found: non-existent/
      );
    });
  });

  describe('RecipeRegistry - loading from config', () => {
    it('should load recipes from YAML config', async () => {
      const configPath = join(tmpDir, 'recipes.yml');
      const yamlContent = `
recipes:
  readme-template:
    name: "README Template"
    description: "Generates a README"
    inputs:
      - name: project_name
        type: string
        required: true
      - name: description
        type: string
        required: true
    actions:
      - type: create_file
        path: "README.md"
        template: |
          # {{project_name}}

          {{description}}
`;

      await writeFile(configPath, yamlContent);

      const registry = new RecipeRegistry();
      await registry.loadFromFile(configPath);

      const recipe = registry.get('readme-template');
      assert.ok(recipe);
      assert.strictEqual(recipe.name, 'README Template');
      assert.strictEqual(recipe.inputs.length, 2);
      assert.strictEqual(recipe.actions.length, 1);
    });
  });

  describe('Integration - realistic recipes', () => {
    it('should create complete project structure', async () => {
      const recipe = new Recipe({
        name: 'nodejs-project',
        inputs: [
          { name: 'name', type: 'string', required: true },
          { name: 'author', type: 'string', default: 'Anonymous' }
        ],
        actions: [
          {
            type: 'create_file',
            path: join(tmpDir, 'package.json'),
            template: JSON.stringify({
              name: '{{name}}',
              version: '1.0.0',
              author: '{{author}}'
            }, null, 2)
          },
          {
            type: 'create_file',
            path: join(tmpDir, 'README.md'),
            template: '# {{name}}\n\nAuthor: {{author}}\n'
          },
          {
            type: 'create_file',
            path: join(tmpDir, 'src', 'index.js'),
            template: '// {{name}}\nconsole.log("Hello from {{name}}");\n'
          }
        ]
      });

      const result = await recipe.execute({
        name: 'my-awesome-project',
        author: 'John Doe'
      });

      assert.strictEqual(result.success, true);
      assert.ok(existsSync(join(tmpDir, 'package.json')));
      assert.ok(existsSync(join(tmpDir, 'README.md')));
      assert.ok(existsSync(join(tmpDir, 'src', 'index.js')));

      const pkg = JSON.parse(await readFile(join(tmpDir, 'package.json'), 'utf8'));
      assert.strictEqual(pkg.name, 'my-awesome-project');
      assert.strictEqual(pkg.author, 'John Doe');

      const readme = await readFile(join(tmpDir, 'README.md'), 'utf8');
      assert.ok(readme.includes('my-awesome-project'));
      assert.ok(readme.includes('John Doe'));
    });

    it('should handle Obsidian daily note template', async () => {
      const recipe = new Recipe({
        name: 'obsidian-daily',
        inputs: [
          { name: 'date', type: 'string', default: '2024-01-01' }
        ],
        actions: [
          {
            type: 'create_file',
            path: join(tmpDir, '.obsidian', 'templates', 'daily-note.md'),
            template: `---
date: {{date}}
tags: [daily]
---

# {{date}}

## Tasks
- [ ]

## Notes

## Links
`
          }
        ]
      });

      const result = await recipe.execute({ date: '2024-01-15' });

      assert.strictEqual(result.success, true);

      const content = await readFile(
        join(tmpDir, '.obsidian', 'templates', 'daily-note.md'),
        'utf8'
      );
      assert.ok(content.includes('date: 2024-01-15'));
      assert.ok(content.includes('# 2024-01-15'));
    });
  });

  describe('Error handling', () => {
    it('should report failure if file creation fails', async () => {
      // Create a file first, then try to create a file where that file exists (treating file as directory)
      const existingFile = join(tmpDir, 'existing-file.txt');
      await writeFile(existingFile, 'content');

      const recipe = new Recipe({
        name: 'bad-recipe',
        inputs: [],
        actions: [
          {
            type: 'create_file',
            // Try to create a file using an existing file as a directory path
            path: join(existingFile, 'nested-file.txt'),
            template: 'content'
          }
        ]
      });

      const result = await recipe.execute({});

      assert.strictEqual(result.success, false);
      assert.ok(result.results[0].error);
    });

    it('should handle unknown action type gracefully', async () => {
      const recipe = new Recipe({
        name: 'unknown-action',
        inputs: [],
        actions: [
          {
            type: 'unknown_action_type',
            data: 'test'
          }
        ]
      });

      const result = await recipe.execute({});

      assert.strictEqual(result.success, false);
    });
  });
});
