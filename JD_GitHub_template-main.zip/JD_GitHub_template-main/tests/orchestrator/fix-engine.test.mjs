/**
 * Tests for MultiPassFixEngine
 *
 * The MultiPassFixEngine executes the check → fix → check loop
 * with intelligent retry logic and strategy escalation.
 */

import { describe, it } from 'node:test';
import assert from 'node:assert';
import MultiPassFixEngine from '../../.github/scripts/orchestrator/fix-engine.mjs';

// Mock module for testing
class MockModule {
  constructor(checkResults = [], fixResults = []) {
    this.checkResults = checkResults;
    this.fixResults = fixResults;
    this.checkIndex = 0;
    this.fixIndex = 0;
    this.checkCalls = [];
    this.fixCalls = [];
  }

  async check(files) {
    this.checkCalls.push({ files });
    const result = this.checkResults[this.checkIndex] || { success: true, issues: [] };
    this.checkIndex++;
    return result;
  }

  async fix(files, strategy) {
    this.fixCalls.push({ files, strategy });
    const result = this.fixResults[this.fixIndex] || { success: true, files_modified: files, fixes_applied: 1 };
    this.fixIndex++;
    return result;
  }

  getSupportedStrategies() {
    return ['conservative', 'balanced', 'aggressive'];
  }
}

describe('MultiPassFixEngine', () => {
  describe('constructor', () => {
    it('should create engine', () => {
      const engine = new MultiPassFixEngine();
      assert.ok(engine);
    });
  });

  describe('fixWithRetries - success cases (IB)', () => {
    it('should succeed on first check if no issues', async () => {
      const module = new MockModule(
        [{ success: true, issues: [] }], // First check succeeds
        []
      );

      const engine = new MultiPassFixEngine();
      const result = await engine.fixWithRetries(module, ['test.sh']);

      assert.strictEqual(result.success, true);
      assert.strictEqual(result.attempts, 1);
      assert.strictEqual(module.checkCalls.length, 1);
      assert.strictEqual(module.fixCalls.length, 0); // No fix needed
    });

    it('should fix issues on first attempt', async () => {
      const module = new MockModule(
        [
          { success: false, issues: [{ file: 'test.sh', line: 1 }] }, // First check finds issue
          { success: true, issues: [] }, // Second check succeeds
        ],
        [{ success: true, files_modified: ['test.sh'], fixes_applied: 1 }]
      );

      const engine = new MultiPassFixEngine();
      const result = await engine.fixWithRetries(module, ['test.sh']);

      assert.strictEqual(result.success, true);
      assert.strictEqual(result.attempts, 3); // check + fix + check = 3 operations
      assert.strictEqual(module.checkCalls.length, 2);
      assert.strictEqual(module.fixCalls.length, 1);
      assert.strictEqual(module.fixCalls[0].strategy, 'conservative'); // First attempt uses conservative
    });

    it('should succeed after multiple attempts', async () => {
      const module = new MockModule(
        [
          { success: false, issues: [1, 2, 3] }, // Check 1: 3 issues
          { success: false, issues: [1, 2] }, // Check 2: 2 issues (progress)
          { success: false, issues: [1] }, // Check 3: 1 issue (progress)
          { success: true, issues: [] }, // Check 4: success
        ],
        [
          { success: true, files_modified: ['test.sh'], fixes_applied: 1 },
          { success: true, files_modified: ['test.sh'], fixes_applied: 1 },
          { success: true, files_modified: ['test.sh'], fixes_applied: 1 },
        ]
      );

      const engine = new MultiPassFixEngine();
      const result = await engine.fixWithRetries(module, ['test.sh']);

      assert.strictEqual(result.success, true);
      assert.strictEqual(result.attempts, 7); // 4 checks + 3 fixes
      assert.strictEqual(module.checkCalls.length, 4);
      assert.strictEqual(module.fixCalls.length, 3);
    });
  });

  describe('fixWithRetries - strategy escalation (IB)', () => {
    it('should escalate strategy on retries', async () => {
      const module = new MockModule(
        [
          { success: false, issues: [1, 2, 3] }, // Check 1
          { success: false, issues: [1, 2, 3] }, // Check 2 (no progress)
          { success: false, issues: [1, 2, 3] }, // Check 3 (no progress)
          { success: false, issues: [1, 2, 3] }, // Check 4 (no progress)
          { success: true, issues: [] }, // Check 5: success
        ],
        [
          { success: true, files_modified: ['test.sh'], fixes_applied: 0 },
          { success: true, files_modified: ['test.sh'], fixes_applied: 0 },
          { success: true, files_modified: ['test.sh'], fixes_applied: 0 },
          { success: true, files_modified: ['test.sh'], fixes_applied: 1 },
        ]
      );

      const engine = new MultiPassFixEngine();
      const result = await engine.fixWithRetries(module, ['test.sh']);

      assert.strictEqual(result.success, true);

      // Check strategy escalation
      assert.strictEqual(module.fixCalls[0].strategy, 'conservative'); // Attempt 1
      assert.strictEqual(module.fixCalls[1].strategy, 'conservative'); // Attempt 2
      assert.strictEqual(module.fixCalls[2].strategy, 'balanced'); // Attempt 3
      assert.strictEqual(module.fixCalls[3].strategy, 'balanced'); // Attempt 4
    });
  });

  describe('fixWithRetries - failure cases (IB)', () => {
    it('should fail after max attempts', async () => {
      const module = new MockModule(
        [
          { success: false, issues: [1] }, // All checks fail
          { success: false, issues: [1] },
          { success: false, issues: [1] },
          { success: false, issues: [1] },
          { success: false, issues: [1] },
          { success: false, issues: [1] },
        ],
        [
          { success: true, files_modified: ['test.sh'], fixes_applied: 0 },
          { success: true, files_modified: ['test.sh'], fixes_applied: 0 },
          { success: true, files_modified: ['test.sh'], fixes_applied: 0 },
          { success: true, files_modified: ['test.sh'], fixes_applied: 0 },
          { success: true, files_modified: ['test.sh'], fixes_applied: 0 },
        ]
      );

      const engine = new MultiPassFixEngine();
      const result = await engine.fixWithRetries(module, ['test.sh'], {
        maxAttempts: 3,
      });

      assert.strictEqual(result.success, false);
      assert.ok(result.message.includes('Failed after'));
      assert.ok(result.remainingIssues);
      assert.strictEqual(result.remainingIssues.length, 1);
    });

    it('should fail if fix operation fails', async () => {
      const module = new MockModule(
        [
          { success: false, issues: [1] },
          { success: false, issues: [1] },
        ],
        [
          { success: false, files_modified: [], fixes_applied: 0 }, // Fix fails
          { success: false, files_modified: [], fixes_applied: 0 },
        ]
      );

      const engine = new MultiPassFixEngine();
      const result = await engine.fixWithRetries(module, ['test.sh'], {
        maxAttempts: 2,
      });

      assert.strictEqual(result.success, false);
    });
  });

  describe('fixWithRetries - options (IB)', () => {
    it('should respect maxAttempts option', async () => {
      const module = new MockModule(
        [
          { success: false, issues: [1] },
          { success: false, issues: [1] },
          { success: false, issues: [1] },
        ],
        [
          { success: true, files_modified: ['test.sh'], fixes_applied: 0 },
          { success: true, files_modified: ['test.sh'], fixes_applied: 0 },
        ]
      );

      const engine = new MultiPassFixEngine();
      const result = await engine.fixWithRetries(module, ['test.sh'], {
        maxAttempts: 2,
      });

      assert.strictEqual(result.success, false);
      assert.strictEqual(module.checkCalls.length, 2); // Max 2 checks
    });

    it('should use custom strategies if provided', async () => {
      const module = new MockModule(
        [
          { success: false, issues: [1] },
          { success: false, issues: [1] },
          { success: true, issues: [] },
        ],
        [
          { success: true, files_modified: ['test.sh'], fixes_applied: 0 },
          { success: true, files_modified: ['test.sh'], fixes_applied: 1 },
        ]
      );

      // Override getSupportedStrategies
      module.getSupportedStrategies = () => ['strict', 'lenient'];

      const engine = new MultiPassFixEngine();
      const result = await engine.fixWithRetries(module, ['test.sh']);

      assert.strictEqual(result.success, true);
      assert.strictEqual(module.fixCalls[0].strategy, 'strict'); // First strategy
    });
  });

  describe('fixWithRetries - log (IB)', () => {
    it('should return detailed log', async () => {
      const module = new MockModule(
        [
          { success: false, issues: [1] },
          { success: true, issues: [] },
        ],
        [{ success: true, files_modified: ['test.sh'], fixes_applied: 1 }]
      );

      const engine = new MultiPassFixEngine();
      const result = await engine.fixWithRetries(module, ['test.sh']);

      assert.ok(result.log);
      assert.strictEqual(result.log.length, 3); // check + fix + check
      assert.strictEqual(result.log[0].phase, 'check');
      assert.strictEqual(result.log[1].phase, 'fix');
      assert.strictEqual(result.log[2].phase, 'check');
    });

    it('should include strategy in log', async () => {
      const module = new MockModule(
        [
          { success: false, issues: [1] },
          { success: true, issues: [] },
        ],
        [{ success: true, files_modified: ['test.sh'], fixes_applied: 1 }]
      );

      const engine = new MultiPassFixEngine();
      const result = await engine.fixWithRetries(module, ['test.sh']);

      const fixEntry = result.log.find((e) => e.phase === 'fix');
      assert.ok(fixEntry);
      assert.strictEqual(fixEntry.strategy, 'conservative');
    });
  });

  describe('fixWithRetries - edge cases (OOB)', () => {
    it('should handle empty file list', async () => {
      const module = new MockModule(
        [{ success: true, issues: [] }],
        []
      );

      const engine = new MultiPassFixEngine();
      const result = await engine.fixWithRetries(module, []);

      assert.strictEqual(result.success, true);
      assert.strictEqual(module.checkCalls.length, 1);
      assert.strictEqual(module.fixCalls.length, 0);
    });

    it('should handle null files', async () => {
      const module = new MockModule(
        [{ success: true, issues: [] }],
        []
      );

      const engine = new MultiPassFixEngine();
      const result = await engine.fixWithRetries(module, null);

      assert.strictEqual(result.success, true);
    });

    it('should handle maxAttempts = 0 (OOB)', async () => {
      const module = new MockModule(
        [{ success: false, issues: [1] }],
        []
      );

      const engine = new MultiPassFixEngine();
      const result = await engine.fixWithRetries(module, ['test.sh'], {
        maxAttempts: 0,
      });

      // Should fail immediately or use default maxAttempts
      assert.ok(result);
    });

    it('should handle negative maxAttempts (OOB)', async () => {
      const module = new MockModule(
        [{ success: false, issues: [1] }],
        []
      );

      const engine = new MultiPassFixEngine();
      const result = await engine.fixWithRetries(module, ['test.sh'], {
        maxAttempts: -1,
      });

      // Should use default or handle gracefully
      assert.ok(result);
    });

    it('should handle module with no strategies', async () => {
      const module = new MockModule(
        [{ success: true, issues: [] }],
        []
      );
      module.getSupportedStrategies = () => [];

      const engine = new MultiPassFixEngine();
      const result = await engine.fixWithRetries(module, ['test.sh']);

      assert.strictEqual(result.success, true);
    });
  });

  describe('timeout handling (IB)', () => {
    it('should timeout long-running check', async () => {
      const module = new MockModule();
      module.check = async () => {
        await new Promise((resolve) => setTimeout(resolve, 200)); // 200ms delay
        return { success: true, issues: [] };
      };

      const engine = new MultiPassFixEngine();

      try {
        await engine.fixWithRetries(module, ['test.sh'], {
          timeout: 50, // 50ms timeout
        });
        assert.fail('Should have timed out');
      } catch (error) {
        assert.ok(error.message.includes('timeout') || error.message.includes('timed out'));
      }
    });

    it('should complete within timeout', async () => {
      const module = new MockModule(
        [{ success: true, issues: [] }],
        []
      );

      const engine = new MultiPassFixEngine();
      const result = await engine.fixWithRetries(module, ['test.sh'], {
        timeout: 5000, // 5s timeout - plenty of time
      });

      assert.strictEqual(result.success, true);
    });
  });
});
