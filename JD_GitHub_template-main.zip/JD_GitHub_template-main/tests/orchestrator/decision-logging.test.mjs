/**
 * Tests for Decision Logging System
 *
 * TDD Approach: These tests are written FIRST, before implementation
 *
 * The Decision Logging System implements BMAD (Build-Measure-Analyze-Decide) methodology
 * to track all orchestrator decisions with context and metrics
 */

import { describe, it, beforeEach, afterEach } from 'node:test';
import assert from 'node:assert';
import { mkdtemp, rm, writeFile, readFile } from 'node:fs/promises';
import { join } from 'node:path';
import { tmpdir } from 'node:os';

// Import the modules we're testing (will fail initially - that's TDD!)
import {
  DecisionLogger,
  Decision,
  DecisionQuery
} from '../../.github/scripts/orchestrator/decision-logging.mjs';

describe('Decision Logging System', () => {
  let tmpDir;
  let logger;

  beforeEach(async () => {
    // Create temp directory for test files
    tmpDir = await mkdtemp(join(tmpdir(), 'decision-log-test-'));
    logger = new DecisionLogger({
      logDir: tmpDir
    });
  });

  afterEach(async () => {
    // Cleanup
    await rm(tmpDir, { recursive: true, force: true });
  });

  describe('Decision - basic structure', () => {
    it('should create decision with required fields', () => {
      const decision = new Decision({
        id: 'test-decision-1',
        type: 'file_selection',
        context: 'Choosing files to format',
        action: 'selected 3 markdown files',
        outcome: 'success'
      });

      assert.strictEqual(decision.id, 'test-decision-1');
      assert.strictEqual(decision.type, 'file_selection');
      assert.strictEqual(decision.context, 'Choosing files to format');
      assert.strictEqual(decision.action, 'selected 3 markdown files');
      assert.strictEqual(decision.outcome, 'success');
    });

    it('should auto-generate ID if not provided', () => {
      const decision = new Decision({
        type: 'module_selection',
        context: 'test',
        action: 'test',
        outcome: 'success'
      });

      assert.ok(decision.id);
      assert.ok(decision.id.length > 0);
    });

    it('should include timestamp', () => {
      const decision = new Decision({
        type: 'test',
        context: 'test',
        action: 'test',
        outcome: 'success'
      });

      assert.ok(decision.timestamp);
      assert.ok(decision.timestamp instanceof Date);
    });

    it('should support BMAD metrics', () => {
      const decision = new Decision({
        type: 'format_fix',
        context: 'Fixing markdown formatting',
        action: 'Applied balanced strategy',
        outcome: 'success',
        metrics: {
          build: { duration_ms: 150, files_processed: 5 },
          measure: { issues_found: 12, issues_fixed: 10 },
          analyze: { success_rate: 0.83, confidence: 'high' },
          decide: { strategy: 'balanced', reason: 'Most issues are safe to fix' }
        }
      });

      assert.ok(decision.metrics);
      assert.strictEqual(decision.metrics.build.duration_ms, 150);
      assert.strictEqual(decision.metrics.measure.issues_found, 12);
      assert.strictEqual(decision.metrics.analyze.success_rate, 0.83);
      assert.strictEqual(decision.metrics.decide.strategy, 'balanced');
    });

    it('should support related decisions', () => {
      const decision = new Decision({
        type: 'fix_application',
        context: 'Applying fixes',
        action: 'Fixed 10 issues',
        outcome: 'success',
        relatedDecisions: ['decision-1', 'decision-2']
      });

      assert.ok(Array.isArray(decision.relatedDecisions));
      assert.strictEqual(decision.relatedDecisions.length, 2);
    });
  });

  describe('DecisionLogger - logging decisions', () => {
    it('should log a decision', async () => {
      const decision = new Decision({
        type: 'test',
        context: 'Test context',
        action: 'Test action',
        outcome: 'success'
      });

      const result = await logger.log(decision);

      assert.strictEqual(result.success, true);
      assert.ok(result.id);
    });

    it('should persist decisions to file', async () => {
      const decision = new Decision({
        type: 'module_selection',
        context: 'Selecting module for .js files',
        action: 'Selected javascript-module',
        outcome: 'success'
      });

      await logger.log(decision);

      // Check that log file was created
      const logFiles = await readFile(join(tmpDir, 'decisions.jsonl'), 'utf8');
      const lines = logFiles.trim().split('\n');
      assert.strictEqual(lines.length, 1);

      const logged = JSON.parse(lines[0]);
      assert.strictEqual(logged.type, 'module_selection');
      assert.strictEqual(logged.action, 'Selected javascript-module');
    });

    it('should append multiple decisions', async () => {
      await logger.log(new Decision({
        type: 'test1',
        context: 'ctx1',
        action: 'act1',
        outcome: 'success'
      }));

      await logger.log(new Decision({
        type: 'test2',
        context: 'ctx2',
        action: 'act2',
        outcome: 'success'
      }));

      await logger.log(new Decision({
        type: 'test3',
        context: 'ctx3',
        action: 'act3',
        outcome: 'success'
      }));

      const logFiles = await readFile(join(tmpDir, 'decisions.jsonl'), 'utf8');
      const lines = logFiles.trim().split('\n');
      assert.strictEqual(lines.length, 3);
    });

    it('should support different log levels', async () => {
      await logger.log(new Decision({
        type: 'test',
        context: 'test',
        action: 'test',
        outcome: 'success',
        level: 'info'
      }));

      await logger.log(new Decision({
        type: 'test',
        context: 'test',
        action: 'test',
        outcome: 'failure',
        level: 'error'
      }));

      const logFiles = await readFile(join(tmpDir, 'decisions.jsonl'), 'utf8');
      const lines = logFiles.trim().split('\n');

      const decision1 = JSON.parse(lines[0]);
      const decision2 = JSON.parse(lines[1]);

      assert.strictEqual(decision1.level, 'info');
      assert.strictEqual(decision2.level, 'error');
    });

    it('should include session ID if configured', async () => {
      const sessionLogger = new DecisionLogger({
        logDir: tmpDir,
        sessionId: 'test-session-123'
      });

      await sessionLogger.log(new Decision({
        type: 'test',
        context: 'test',
        action: 'test',
        outcome: 'success'
      }));

      const logFiles = await readFile(join(tmpDir, 'decisions.jsonl'), 'utf8');
      const logged = JSON.parse(logFiles.trim());

      assert.strictEqual(logged.sessionId, 'test-session-123');
    });
  });

  describe('DecisionLogger - querying decisions', () => {
    beforeEach(async () => {
      // Log some test decisions
      await logger.log(new Decision({
        id: 'dec-1',
        type: 'module_selection',
        context: 'Selecting module',
        action: 'Selected javascript-module',
        outcome: 'success'
      }));

      await logger.log(new Decision({
        id: 'dec-2',
        type: 'format_fix',
        context: 'Fixing format',
        action: 'Applied balanced strategy',
        outcome: 'success'
      }));

      await logger.log(new Decision({
        id: 'dec-3',
        type: 'module_selection',
        context: 'Selecting module',
        action: 'Selected yaml-module',
        outcome: 'success'
      }));

      await logger.log(new Decision({
        id: 'dec-4',
        type: 'validation',
        context: 'Validating files',
        action: 'Validated 5 files',
        outcome: 'failure'
      }));
    });

    it('should query all decisions', async () => {
      const decisions = await logger.query();

      assert.strictEqual(decisions.length, 4);
    });

    it('should filter by type', async () => {
      const decisions = await logger.query({ type: 'module_selection' });

      assert.strictEqual(decisions.length, 2);
      assert.strictEqual(decisions[0].type, 'module_selection');
      assert.strictEqual(decisions[1].type, 'module_selection');
    });

    it('should filter by outcome', async () => {
      const decisions = await logger.query({ outcome: 'failure' });

      assert.strictEqual(decisions.length, 1);
      assert.strictEqual(decisions[0].outcome, 'failure');
    });

    it('should filter by ID', async () => {
      const decisions = await logger.query({ id: 'dec-2' });

      assert.strictEqual(decisions.length, 1);
      assert.strictEqual(decisions[0].id, 'dec-2');
      assert.strictEqual(decisions[0].type, 'format_fix');
    });

    it('should support multiple filters', async () => {
      const decisions = await logger.query({
        type: 'module_selection',
        outcome: 'success'
      });

      assert.strictEqual(decisions.length, 2);
    });

    it('should return empty array when no matches', async () => {
      const decisions = await logger.query({ type: 'nonexistent' });

      assert.strictEqual(decisions.length, 0);
    });
  });

  describe('DecisionLogger - statistics', () => {
    beforeEach(async () => {
      // Log decisions with metrics
      await logger.log(new Decision({
        type: 'format_fix',
        context: 'Fix 1',
        action: 'Fixed',
        outcome: 'success',
        metrics: {
          measure: { issues_found: 10, issues_fixed: 10 }
        }
      }));

      await logger.log(new Decision({
        type: 'format_fix',
        context: 'Fix 2',
        action: 'Fixed',
        outcome: 'success',
        metrics: {
          measure: { issues_found: 5, issues_fixed: 3 }
        }
      }));

      await logger.log(new Decision({
        type: 'validation',
        context: 'Validation',
        action: 'Validated',
        outcome: 'failure'
      }));
    });

    it('should calculate success rate', async () => {
      const stats = await logger.getStatistics();

      assert.ok(stats.successRate);
      assert.strictEqual(stats.successRate, 2 / 3);
    });

    it('should count decisions by type', async () => {
      const stats = await logger.getStatistics();

      assert.ok(stats.byType);
      assert.strictEqual(stats.byType.format_fix, 2);
      assert.strictEqual(stats.byType.validation, 1);
    });

    it('should count decisions by outcome', async () => {
      const stats = await logger.getStatistics();

      assert.ok(stats.byOutcome);
      assert.strictEqual(stats.byOutcome.success, 2);
      assert.strictEqual(stats.byOutcome.failure, 1);
    });

    it('should aggregate BMAD metrics', async () => {
      const stats = await logger.getStatistics();

      assert.ok(stats.totalDecisions);
      assert.strictEqual(stats.totalDecisions, 3);
    });
  });

  describe('DecisionLogger - log rotation', () => {
    it('should create new log file when max size exceeded', async () => {
      const smallLogger = new DecisionLogger({
        logDir: tmpDir,
        maxLogSize: 500 // Small size for testing
      });

      // Log many decisions to exceed size
      for (let i = 0; i < 10; i++) {
        await smallLogger.log(new Decision({
          type: 'test',
          context: `Context ${i}`,
          action: `Action ${i}`,
          outcome: 'success'
        }));
      }

      // Should have rotated logs
      const files = await readFile(join(tmpDir, 'decisions.jsonl'), 'utf8');
      const lines = files.trim().split('\n');

      // With small max size, should have rotated
      assert.ok(lines.length < 10);
    });
  });

  describe('DecisionQuery - advanced queries', () => {
    beforeEach(async () => {
      const now = Date.now();

      await logger.log(new Decision({
        type: 'test',
        context: 'Old decision',
        action: 'test',
        outcome: 'success',
        timestamp: new Date(now - 3600000) // 1 hour ago
      }));

      await logger.log(new Decision({
        type: 'test',
        context: 'Recent decision',
        action: 'test',
        outcome: 'success',
        timestamp: new Date(now - 60000) // 1 minute ago
      }));
    });

    it('should filter by time range', async () => {
      const thirtyMinutesAgo = new Date(Date.now() - 1800000);

      const decisions = await logger.query({
        afterTimestamp: thirtyMinutesAgo
      });

      assert.strictEqual(decisions.length, 1);
      assert.ok(decisions[0].context.includes('Recent'));
    });

    it('should support custom filter functions', async () => {
      const query = new DecisionQuery({
        customFilter: (decision) => decision.context.includes('Old')
      });

      const decisions = await logger.query(query);

      assert.strictEqual(decisions.length, 1);
      assert.ok(decisions[0].context.includes('Old'));
    });
  });

  describe('Integration - realistic orchestrator scenarios', () => {
    it('should log full file processing workflow', async () => {
      // Simulate orchestrator workflow
      const fileDiscoveryDecision = await logger.log(new Decision({
        type: 'file_discovery',
        context: 'Discovering files to process',
        action: 'Found 15 files',
        outcome: 'success',
        metrics: {
          measure: { total_files: 15, matched_files: 15 }
        }
      }));

      const classificationDecision = await logger.log(new Decision({
        type: 'file_classification',
        context: 'Classifying files by type',
        action: 'Classified into 3 modules',
        outcome: 'success',
        relatedDecisions: [fileDiscoveryDecision.id],
        metrics: {
          measure: {
            javascript: 5,
            yaml: 8,
            markdown: 2
          }
        }
      }));

      const validationDecision = await logger.log(new Decision({
        type: 'validation',
        context: 'Validating files',
        action: 'Validated 15 files, found 23 issues',
        outcome: 'success',
        relatedDecisions: [classificationDecision.id],
        metrics: {
          measure: { files_validated: 15, issues_found: 23 }
        }
      }));

      await logger.log(new Decision({
        type: 'fix_strategy',
        context: 'Deciding fix strategy',
        action: 'Selected balanced strategy',
        outcome: 'success',
        relatedDecisions: [validationDecision.id],
        metrics: {
          analyze: { risk_level: 'medium', confidence: 'high' },
          decide: { strategy: 'balanced', reason: 'Most issues are safe' }
        }
      }));

      // Query the workflow
      const workflow = await logger.query();
      assert.strictEqual(workflow.length, 4);

      // Verify decision chain
      assert.strictEqual(workflow[1].relatedDecisions[0], workflow[0].id);
      assert.strictEqual(workflow[2].relatedDecisions[0], workflow[1].id);
      assert.strictEqual(workflow[3].relatedDecisions[0], workflow[2].id);
    });

    it('should track BMAD metrics across workflow', async () => {
      await logger.log(new Decision({
        type: 'build',
        context: 'Building file list',
        action: 'Built list of 10 files',
        outcome: 'success',
        metrics: {
          build: { duration_ms: 45, files_scanned: 100, files_matched: 10 }
        }
      }));

      await logger.log(new Decision({
        type: 'measure',
        context: 'Measuring code quality',
        action: 'Measured quality metrics',
        outcome: 'success',
        metrics: {
          measure: {
            linting_issues: 15,
            formatting_issues: 8,
            complexity_issues: 3
          }
        }
      }));

      await logger.log(new Decision({
        type: 'analyze',
        context: 'Analyzing fix safety',
        action: 'Analyzed fix risks',
        outcome: 'success',
        metrics: {
          analyze: {
            safe_fixes: 20,
            risky_fixes: 6,
            risk_score: 0.23
          }
        }
      }));

      await logger.log(new Decision({
        type: 'decide',
        context: 'Deciding on actions',
        action: 'Decided to apply safe fixes only',
        outcome: 'success',
        metrics: {
          decide: {
            strategy: 'conservative',
            fixes_to_apply: 20,
            reason: 'Risk score above threshold'
          }
        }
      }));

      const stats = await logger.getStatistics();
      assert.strictEqual(stats.totalDecisions, 4);
      assert.strictEqual(stats.byType.build, 1);
      assert.strictEqual(stats.byType.measure, 1);
      assert.strictEqual(stats.byType.analyze, 1);
      assert.strictEqual(stats.byType.decide, 1);
    });
  });

  describe('Error handling', () => {
    it('should handle missing required fields', () => {
      assert.throws(
        () => new Decision({
          type: 'test'
          // Missing context, action, outcome
        }),
        /Missing required field/
      );
    });

    it('should handle corrupted log file gracefully', async () => {
      // Create a valid decision
      const validDecision = new Decision({
        id: 'valid-1',
        type: 'test',
        context: 'test',
        action: 'test',
        outcome: 'success'
      });

      // Write corrupted data with one valid decision
      await writeFile(
        join(tmpDir, 'decisions.jsonl'),
        `This is not JSON\n${JSON.stringify(validDecision.toJSON())}\nMore invalid data\n`
      );

      const decisions = await logger.query();

      // Should only return valid decision line
      assert.strictEqual(decisions.length, 1);
      assert.strictEqual(decisions[0].id, 'valid-1');
    });

    it('should handle query errors gracefully', async () => {
      // Log a decision first so the filter gets called
      await logger.log(new Decision({
        type: 'test',
        context: 'test',
        action: 'test',
        outcome: 'success'
      }));

      const query = new DecisionQuery({
        customFilter: () => {
          throw new Error('Filter error');
        }
      });

      await assert.rejects(
        async () => await logger.query(query),
        /Filter error/
      );
    });
  });
});
