/**
 * Tests for AttemptTracker
 *
 * The AttemptTracker records each check and fix attempt during
 * the multi-pass fix engine execution.
 *
 * Tracks:
 * - Attempt number
 * - Phase (check or fix)
 * - Strategy used
 * - Result
 * - Timestamp
 */

import { describe, it } from 'node:test';
import assert from 'node:assert';
import AttemptTracker from '../../.github/scripts/orchestrator/attempt-tracker.mjs';

describe('AttemptTracker', () => {
  describe('constructor', () => {
    it('should create empty tracker', () => {
      const tracker = new AttemptTracker();
      assert.ok(tracker);
      assert.strictEqual(tracker.getAttemptCount(), 0);
    });
  });

  describe('recordCheck', () => {
    it('should record a check result', () => {
      const tracker = new AttemptTracker();
      const result = {
        success: false,
        issues: [{ file: 'test.sh', line: 1, message: 'error' }],
      };

      tracker.recordCheck(1, result);
      assert.strictEqual(tracker.getAttemptCount(), 1);
    });

    it('should record multiple checks', () => {
      const tracker = new AttemptTracker();
      tracker.recordCheck(1, { success: false, issues: [] });
      tracker.recordCheck(2, { success: false, issues: [] });
      tracker.recordCheck(3, { success: true, issues: [] });

      assert.strictEqual(tracker.getAttemptCount(), 3);
    });

    it('should store check result', () => {
      const tracker = new AttemptTracker();
      const result = { success: true, issues: [] };

      tracker.recordCheck(1, result);
      const log = tracker.getLog();

      assert.strictEqual(log.length, 1);
      assert.strictEqual(log[0].phase, 'check');
      assert.strictEqual(log[0].attempt, 1);
      assert.deepStrictEqual(log[0].result, result);
    });

    it('should include timestamp', () => {
      const tracker = new AttemptTracker();
      const before = Date.now();
      tracker.recordCheck(1, { success: true, issues: [] });
      const after = Date.now();

      const log = tracker.getLog();
      assert.ok(log[0].timestamp >= before);
      assert.ok(log[0].timestamp <= after);
    });
  });

  describe('recordFix', () => {
    it('should record a fix result with strategy', () => {
      const tracker = new AttemptTracker();
      const result = {
        success: true,
        files_modified: ['test.sh'],
        fixes_applied: 1,
      };

      tracker.recordFix(1, 'conservative', result);
      assert.strictEqual(tracker.getAttemptCount(), 1);
    });

    it('should store fix result and strategy', () => {
      const tracker = new AttemptTracker();
      const result = { success: true, files_modified: [], fixes_applied: 0 };

      tracker.recordFix(2, 'balanced', result);
      const log = tracker.getLog();

      assert.strictEqual(log.length, 1);
      assert.strictEqual(log[0].phase, 'fix');
      assert.strictEqual(log[0].attempt, 2);
      assert.strictEqual(log[0].strategy, 'balanced');
      assert.deepStrictEqual(log[0].result, result);
    });

    it('should handle missing strategy (OOB)', () => {
      const tracker = new AttemptTracker();
      tracker.recordFix(1, null, { success: true });

      const log = tracker.getLog();
      assert.strictEqual(log[0].strategy, null);
    });
  });

  describe('getLog', () => {
    it('should return empty array initially', () => {
      const tracker = new AttemptTracker();
      assert.deepStrictEqual(tracker.getLog(), []);
    });

    it('should return all recorded attempts', () => {
      const tracker = new AttemptTracker();
      tracker.recordCheck(1, { success: false, issues: [] });
      tracker.recordFix(1, 'conservative', { success: true, files_modified: [] });
      tracker.recordCheck(2, { success: true, issues: [] });

      const log = tracker.getLog();
      assert.strictEqual(log.length, 3);
      assert.strictEqual(log[0].phase, 'check');
      assert.strictEqual(log[1].phase, 'fix');
      assert.strictEqual(log[2].phase, 'check');
    });

    it('should return copy of log (not reference)', () => {
      const tracker = new AttemptTracker();
      tracker.recordCheck(1, { success: true, issues: [] });

      const log1 = tracker.getLog();
      const log2 = tracker.getLog();

      assert.notStrictEqual(log1, log2);
      assert.deepStrictEqual(log1, log2);
    });
  });

  describe('getAttemptCount', () => {
    it('should count unique attempt numbers', () => {
      const tracker = new AttemptTracker();
      tracker.recordCheck(1, { success: false, issues: [] });
      tracker.recordFix(1, 'conservative', { success: true, files_modified: [] });
      tracker.recordCheck(2, { success: false, issues: [] });
      tracker.recordFix(2, 'balanced', { success: true, files_modified: [] });

      // 4 records but only 2 unique attempts
      assert.strictEqual(tracker.getAttemptCount(), 4);
    });

    it('should return 0 for empty tracker', () => {
      const tracker = new AttemptTracker();
      assert.strictEqual(tracker.getAttemptCount(), 0);
    });
  });

  describe('getLastCheck', () => {
    it('should return last check result', () => {
      const tracker = new AttemptTracker();
      const result1 = { success: false, issues: [{ file: 'test.sh' }] };
      const result2 = { success: true, issues: [] };

      tracker.recordCheck(1, result1);
      tracker.recordFix(1, 'conservative', { success: true, files_modified: [] });
      tracker.recordCheck(2, result2);

      const lastCheck = tracker.getLastCheck();
      assert.strictEqual(lastCheck.attempt, 2);
      assert.deepStrictEqual(lastCheck.result, result2);
    });

    it('should return null if no checks recorded', () => {
      const tracker = new AttemptTracker();
      assert.strictEqual(tracker.getLastCheck(), null);
    });

    it('should return null if only fixes recorded', () => {
      const tracker = new AttemptTracker();
      tracker.recordFix(1, 'conservative', { success: true, files_modified: [] });

      assert.strictEqual(tracker.getLastCheck(), null);
    });
  });

  describe('getLastFix', () => {
    it('should return last fix result', () => {
      const tracker = new AttemptTracker();
      const fix1 = { success: true, files_modified: ['a.sh'] };
      const fix2 = { success: true, files_modified: ['b.sh'] };

      tracker.recordFix(1, 'conservative', fix1);
      tracker.recordCheck(2, { success: false, issues: [] });
      tracker.recordFix(2, 'balanced', fix2);

      const lastFix = tracker.getLastFix();
      assert.strictEqual(lastFix.attempt, 2);
      assert.strictEqual(lastFix.strategy, 'balanced');
      assert.deepStrictEqual(lastFix.result, fix2);
    });

    it('should return null if no fixes recorded', () => {
      const tracker = new AttemptTracker();
      assert.strictEqual(tracker.getLastFix(), null);
    });

    it('should return null if only checks recorded', () => {
      const tracker = new AttemptTracker();
      tracker.recordCheck(1, { success: true, issues: [] });

      assert.strictEqual(tracker.getLastFix(), null);
    });
  });

  describe('getIssueCount', () => {
    it('should return issue count from last check', () => {
      const tracker = new AttemptTracker();
      tracker.recordCheck(1, {
        success: false,
        issues: [{ file: 'test.sh' }, { file: 'test2.sh' }],
      });

      assert.strictEqual(tracker.getIssueCount(), 2);
    });

    it('should return 0 if no issues', () => {
      const tracker = new AttemptTracker();
      tracker.recordCheck(1, { success: true, issues: [] });

      assert.strictEqual(tracker.getIssueCount(), 0);
    });

    it('should return 0 if no checks recorded', () => {
      const tracker = new AttemptTracker();
      assert.strictEqual(tracker.getIssueCount(), 0);
    });

    it('should handle missing issues array (OOB)', () => {
      const tracker = new AttemptTracker();
      tracker.recordCheck(1, { success: false });

      // Should return 0 as fallback
      assert.strictEqual(tracker.getIssueCount(), 0);
    });
  });

  describe('hasProgress', () => {
    it('should return true if issues decreased', () => {
      const tracker = new AttemptTracker();
      tracker.recordCheck(1, { success: false, issues: [1, 2, 3] });
      tracker.recordFix(1, 'conservative', { success: true, files_modified: [] });
      tracker.recordCheck(2, { success: false, issues: [1] });

      assert.strictEqual(tracker.hasProgress(), true);
    });

    it('should return false if issues stayed same', () => {
      const tracker = new AttemptTracker();
      tracker.recordCheck(1, { success: false, issues: [1, 2] });
      tracker.recordFix(1, 'conservative', { success: true, files_modified: [] });
      tracker.recordCheck(2, { success: false, issues: [1, 2] });

      assert.strictEqual(tracker.hasProgress(), false);
    });

    it('should return false if issues increased', () => {
      const tracker = new AttemptTracker();
      tracker.recordCheck(1, { success: false, issues: [1] });
      tracker.recordFix(1, 'conservative', { success: true, files_modified: [] });
      tracker.recordCheck(2, { success: false, issues: [1, 2, 3] });

      assert.strictEqual(tracker.hasProgress(), false);
    });

    it('should return false if only one check', () => {
      const tracker = new AttemptTracker();
      tracker.recordCheck(1, { success: false, issues: [1, 2] });

      assert.strictEqual(tracker.hasProgress(), false);
    });

    it('should return false if no checks', () => {
      const tracker = new AttemptTracker();
      assert.strictEqual(tracker.hasProgress(), false);
    });
  });

  describe('getSummary', () => {
    it('should return comprehensive summary', () => {
      const tracker = new AttemptTracker();
      tracker.recordCheck(1, { success: false, issues: [1, 2, 3] });
      tracker.recordFix(1, 'conservative', { success: true, files_modified: ['test.sh'] });
      tracker.recordCheck(2, { success: false, issues: [1] });
      tracker.recordFix(2, 'balanced', { success: true, files_modified: ['test.sh'] });
      tracker.recordCheck(3, { success: true, issues: [] });

      const summary = tracker.getSummary();

      assert.strictEqual(summary.total_attempts, 5);
      assert.strictEqual(summary.total_checks, 3);
      assert.strictEqual(summary.total_fixes, 2);
      assert.strictEqual(summary.final_success, true);
      assert.strictEqual(summary.final_issue_count, 0);
      assert.strictEqual(summary.initial_issue_count, 3);
    });

    it('should handle empty tracker', () => {
      const tracker = new AttemptTracker();
      const summary = tracker.getSummary();

      assert.strictEqual(summary.total_attempts, 0);
      assert.strictEqual(summary.total_checks, 0);
      assert.strictEqual(summary.total_fixes, 0);
      assert.strictEqual(summary.final_success, false);
    });
  });
});
