/**
 * Tests for FileRouter
 *
 * @module file-router.test
 */

import { describe, it, before, after, mock } from 'node:test';
import * as assert from 'node:assert/strict';
import * as fs from 'node:fs/promises';
import * as path from 'node:path';
import * as os from 'node:os';
import FileRouter from '../../.github/scripts/orchestrator/file-router.mjs';

// Sample configuration for testing
const testConfig = {
  modules: {
    shell: {
      name: 'Shell Module',
      extensions: ['.sh', '.bash'],
      patterns: [],
      enabled: true,
      priority: 10,
    },
    javascript: {
      name: 'JavaScript Module',
      extensions: ['.js', '.mjs', '.ts'],
      patterns: [],
      enabled: true,
      priority: 20,
    },
    yaml: {
      name: 'YAML Module',
      extensions: ['.yml', '.yaml'],
      patterns: [],
      enabled: true,
      priority: 5,
    },
    disabled: {
      name: 'Disabled Module',
      extensions: ['.disabled'],
      enabled: false,
    },
  },
  routing: {
    unknown_files: {
      action: 'warn',
    },
  },
};

describe('FileRouter', () => {
  describe('Constructor', () => {
    it('should create instance with default config path', () => {
      const router = new FileRouter();

      assert.equal(router.configPath, '.github/orchestrator-modules.yml');
    });

    it('should accept custom config path', () => {
      const router = new FileRouter({
        config_path: '/custom/config.yml',
      });

      assert.equal(router.configPath, '/custom/config.yml');
    });

    it('should accept pre-loaded config', () => {
      const config = { modules: {} };
      const router = new FileRouter({ config });

      assert.equal(router.config, config);
    });
  });

  describe('loadConfig()', () => {
    it('should load config from provided object', async () => {
      const router = new FileRouter({ config: testConfig });
      await router.loadConfig();

      assert.equal(router.modules.size, 3); // 3 enabled modules
    });

    it('should throw error if config has no modules section', async () => {
      const router = new FileRouter({ config: {} });

      await assert.rejects(
        async () => await router.loadConfig(),
        /Configuration must have "modules" section/
      );
    });

    it('should skip disabled modules', async () => {
      const router = new FileRouter({ config: testConfig });
      await router.loadConfig();

      assert.equal(router.modules.has('disabled'), false);
    });

    it('should store enabled modules', async () => {
      const router = new FileRouter({ config: testConfig });
      await router.loadConfig();

      assert.equal(router.modules.has('shell'), true);
      assert.equal(router.modules.has('javascript'), true);
      assert.equal(router.modules.has('yaml'), true);
    });

    it('should store routing rules', async () => {
      const router = new FileRouter({ config: testConfig });
      await router.loadConfig();

      assert.equal(typeof router.routingRules, 'object');
      assert.equal(router.routingRules.unknown_files.action, 'warn');
    });

    it('should handle missing routing rules', async () => {
      const config = {
        modules: {
          test: { enabled: true, extensions: ['.test'] },
        },
      };

      const router = new FileRouter({ config });
      await router.loadConfig();

      assert.equal(typeof router.routingRules, 'object');
    });
  });

  describe('getModuleConfig()', () => {
    let router;

    before(async () => {
      router = new FileRouter({ config: testConfig });
      await router.loadConfig();
    });

    it('should return module config by name', () => {
      const config = router.getModuleConfig('shell');

      assert.equal(config.name, 'shell'); // name is the key identifier
      assert.deepEqual(config.extensions, ['.sh', '.bash']);
    });

    it('should return null for non-existent module', () => {
      const config = router.getModuleConfig('nonexistent');

      assert.equal(config, null);
    });

    it('should return null for disabled module', () => {
      const config = router.getModuleConfig('disabled');

      assert.equal(config, null);
    });
  });

  describe('getEnabledModules()', () => {
    let router;

    before(async () => {
      router = new FileRouter({ config: testConfig });
      await router.loadConfig();
    });

    it('should return all enabled modules', () => {
      const modules = router.getEnabledModules();

      assert.equal(modules.length, 3);
    });

    it('should not include disabled modules', () => {
      const modules = router.getEnabledModules();

      const hasDisabled = modules.some((m) => m.name === 'Disabled Module');
      assert.equal(hasDisabled, false);
    });

    it('should return array of module configs', () => {
      const modules = router.getEnabledModules();

      modules.forEach((module) => {
        assert.equal(typeof module, 'object');
        assert.ok('name' in module);
        assert.ok('extensions' in module);
      });
    });
  });

  describe('findModuleForFile()', () => {
    let router;

    before(async () => {
      router = new FileRouter({ config: testConfig });
      await router.loadConfig();
    });

    it('should find module for shell file', () => {
      const module = router.findModuleForFile('script.sh');

      assert.equal(module.name, 'shell');
    });

    it('should find module for bash file', () => {
      const module = router.findModuleForFile('script.bash');

      assert.equal(module.name, 'shell');
    });

    it('should find module for javascript file', () => {
      const module = router.findModuleForFile('index.js');

      assert.equal(module.name, 'javascript');
    });

    it('should find module for typescript file', () => {
      const module = router.findModuleForFile('App.ts');

      assert.equal(module.name, 'javascript');
    });

    it('should find module for yaml file', () => {
      const module = router.findModuleForFile('config.yml');

      assert.equal(module.name, 'yaml');
    });

    it('should return null for unknown file type', () => {
      const module = router.findModuleForFile('unknown.xyz');

      assert.equal(module, null);
    });

    it('should handle files with paths', () => {
      const module = router.findModuleForFile('src/components/App.ts');

      assert.equal(module.name, 'javascript');
    });

    it('should handle empty filename', () => {
      const module = router.findModuleForFile('');

      assert.equal(module, null);
    });

    it('should handle null filename', () => {
      const module = router.findModuleForFile(null);

      assert.equal(module, null);
    });
  });

  describe('Priority handling', () => {
    let router;

    before(async () => {
      // Create config with overlapping extensions but different priorities
      const config = {
        modules: {
          low_priority: {
            extensions: ['.js'],
            enabled: true,
            priority: 5,
          },
          high_priority: {
            extensions: ['.js'],
            enabled: true,
            priority: 10,
          },
        },
        routing: {},
      };

      router = new FileRouter({ config });
      await router.loadConfig();
    });

    it('should prefer higher priority module', () => {
      const module = router.findModuleForFile('test.js');

      assert.equal(module.name, 'high_priority');
    });
  });

  describe('Pattern matching', () => {
    let router;

    before(async () => {
      const config = {
        modules: {
          workflow: {
            extensions: [],
            patterns: ['.github/workflows/*.yml'],
            enabled: true,
          },
        },
        routing: {},
      };

      router = new FileRouter({ config });
      await router.loadConfig();
    });

    it('should match file by pattern', () => {
      const module = router.findModuleForFile('.github/workflows/ci.yml');

      assert.equal(module.name, 'workflow');
    });

    it('should not match files outside pattern', () => {
      const module = router.findModuleForFile('config/ci.yml');

      assert.equal(module, null);
    });
  });

  describe('routeFiles()', () => {
    let router;

    before(async () => {
      router = new FileRouter({ config: testConfig });
      await router.loadConfig();
    });

    it('should route files to appropriate modules', () => {
      const result = router.routeFiles(['script.sh', 'index.js', 'config.yml']);

      assert.deepEqual(result.routes.shell, ['script.sh']);
      assert.deepEqual(result.routes.javascript, ['index.js']);
      assert.deepEqual(result.routes.yaml, ['config.yml']);
      assert.equal(result.total, 3);
    });

    it('should handle unrouted files', () => {
      const result = router.routeFiles(['script.sh', 'unknown.xyz']);

      assert.deepEqual(result.routes.shell, ['script.sh']);
      assert.deepEqual(result.unrouted, ['unknown.xyz']);
      assert.equal(result.total, 2);
    });

    it('should handle empty array', () => {
      const result = router.routeFiles([]);

      assert.deepEqual(result.routes, {});
      assert.deepEqual(result.unrouted, []);
      assert.equal(result.total, 0);
    });

    it('should group files by module', () => {
      const result = router.routeFiles([
        'script1.sh',
        'script2.sh',
        'index.js',
        'module.mjs',
      ]);

      assert.equal(result.routes.shell.length, 2);
      assert.equal(result.routes.javascript.length, 2);
    });

    it('should handle all unknown files', () => {
      const result = router.routeFiles(['file1.xyz', 'file2.abc']);

      assert.deepEqual(result.routes, {});
      assert.equal(result.unrouted.length, 2);
    });
  });

  describe('handleUnrouted()', () => {
    it('should warn by default', async () => {
      const router = new FileRouter({ config: testConfig });
      await router.loadConfig();

      // Mock console.warn
      const warnings = [];
      const originalWarn = console.warn;
      console.warn = (...args) => warnings.push(args.join(' '));

      router.handleUnrouted(['file1.xyz', 'file2.abc']);

      console.warn = originalWarn;

      assert.ok(warnings.length > 0);
      // Check that warnings contain the file name (might be in any warning message)
      const allWarnings = warnings.join(' ');
      assert.ok(allWarnings.includes('file1.xyz'));
    });

    it('should ignore when action is ignore', async () => {
      const config = {
        ...testConfig,
        routing: { unknown_files: { action: 'ignore' } },
      };

      const router = new FileRouter({ config });
      await router.loadConfig();

      // Should not throw or warn
      router.handleUnrouted(['file.xyz']);
    });

    it('should throw when action is error', async () => {
      const config = {
        ...testConfig,
        routing: { unknown_files: { action: 'error' } },
      };

      const router = new FileRouter({ config });
      await router.loadConfig();

      assert.throws(
        () => router.handleUnrouted(['file.xyz']),
        /Unknown file types detected/
      );
    });
  });

  describe('matchesPattern()', () => {
    let router;

    before(async () => {
      router = new FileRouter({ config: testConfig });
      await router.loadConfig();
    });

    it('should match exact patterns', () => {
      assert.equal(router.matchesPattern('file.js', 'file.js'), true);
    });

    it('should match * wildcard', () => {
      assert.equal(router.matchesPattern('file.js', '*.js'), true);
      assert.equal(router.matchesPattern('test.js', '*.js'), true);
      assert.equal(router.matchesPattern('file.txt', '*.js'), false);
    });

    it('should match ** wildcard', () => {
      assert.equal(router.matchesPattern('src/file.js', 'src/**'), true);
      assert.equal(router.matchesPattern('src/sub/file.js', 'src/**'), true);
      assert.equal(router.matchesPattern('lib/file.js', 'src/**'), false);
    });

    it('should handle complex patterns', () => {
      assert.equal(
        router.matchesPattern('.github/workflows/ci.yml', '.github/workflows/*.yml'),
        true
      );
      assert.equal(router.matchesPattern('workflows/ci.yml', '.github/workflows/*.yml'), false);
    });
  });

  describe('getStatistics()', () => {
    let router;

    before(async () => {
      router = new FileRouter({ config: testConfig });
      await router.loadConfig();
    });

    it('should generate statistics from routing result', () => {
      const result = {
        routes: {
          shell: ['file1.sh', 'file2.sh'],
          javascript: ['file1.js'],
        },
        unrouted: ['file.xyz'],
        total: 4,
      };

      const stats = router.getStatistics(result);

      assert.equal(stats.total, 4);
      assert.equal(stats.routed, 3);
      assert.equal(stats.unrouted, 1);
      assert.equal(stats.by_module.shell, 2);
      assert.equal(stats.by_module.javascript, 1);
    });

    it('should handle empty result', () => {
      const result = {
        routes: {},
        unrouted: [],
        total: 0,
      };

      const stats = router.getStatistics(result);

      assert.equal(stats.total, 0);
      assert.equal(stats.routed, 0);
      assert.equal(stats.unrouted, 0);
    });
  });

  describe('validate()', () => {
    it('should validate successfully with proper config', async () => {
      const router = new FileRouter({ config: testConfig });
      await router.loadConfig();

      const result = router.validate();

      assert.equal(result.ready, true);
      assert.equal(result.issues.length, 0);
    });

    it('should fail validation with no modules', async () => {
      const config = { modules: {}, routing: {} };
      const router = new FileRouter({ config });
      await router.loadConfig();

      const result = router.validate();

      assert.equal(result.ready, false);
      assert.ok(result.issues.length > 0);
    });

    it('should report missing routing rules', async () => {
      const router = new FileRouter({
        config: { modules: { test: { enabled: true } } },
      });
      await router.loadConfig();

      // Note: current implementation allows missing routing rules
      const result = router.validate();

      // This test documents current behavior
      assert.equal(typeof result, 'object');
      assert.ok('ready' in result);
      assert.ok('issues' in result);
    });
  });

  describe('Integration with real config file', () => {
    let tempDir;
    let configPath;

    before(async () => {
      // Create temporary directory
      tempDir = await fs.mkdtemp(path.join(os.tmpdir(), 'router-test-'));
      configPath = path.join(tempDir, 'config.yml');

      // Write test config to file
      const yamlContent = `
modules:
  test:
    name: "Test Module"
    extensions: ['.test']
    enabled: true

routing:
  unknown_files:
    action: 'warn'
`;

      await fs.writeFile(configPath, yamlContent);
    });

    after(async () => {
      // Clean up
      try {
        await fs.rm(tempDir, { recursive: true, force: true });
      } catch (error) {
        // Ignore cleanup errors
      }
    });

    it('should load config from file', async () => {
      const router = new FileRouter({ config_path: configPath });
      await router.loadConfig();

      assert.equal(router.modules.has('test'), true);
    });

    it('should throw error for missing file', async () => {
      const router = new FileRouter({
        config_path: '/nonexistent/config.yml',
      });

      await assert.rejects(
        async () => await router.loadConfig(),
        /Failed to load configuration/
      );
    });
  });
});
