/**
 * Tests for Orchestrator Main Controller
 *
 * The Orchestrator coordinates all components:
 * - FileDiscovery: Find and classify files
 * - FileRouter: Route files to appropriate modules
 * - MultiPassFixEngine: Fix files with retry logic
 * - Reporting: Generate summaries and GitHub outputs
 */

import { describe, it } from 'node:test';
import assert from 'node:assert';
import Orchestrator from '../../.github/scripts/orchestrator/orchestrator.mjs';
import { OrchestratorError } from '../../.github/scripts/orchestrator/orchestrator.mjs';

// Mock FileDiscovery
class MockFileDiscovery {
  constructor(files = []) {
    this.files = files;
  }

  async getChangedFiles(context) {
    return this.files;
  }

  classifyFiles(files) {
    // Group by extension
    const classified = {};
    files.forEach((file) => {
      const ext = file.substring(file.lastIndexOf('.'));
      if (!classified[ext]) {
        classified[ext] = [];
      }
      classified[ext].push(file);
    });
    return classified;
  }
}

// Mock FileRouter
class MockFileRouter {
  constructor(routing = {}) {
    this.routing = routing; // { moduleName: { module, files } }
  }

  routeFiles(classified) {
    const routes = new Map();
    for (const [moduleName, config] of Object.entries(this.routing)) {
      routes.set(config.module, config.files);
    }
    return routes;
  }
}

// Mock Module
class MockModule {
  constructor(name, checkResults = [], fixResults = []) {
    this.name = name;
    this.checkResults = checkResults;
    this.fixResults = fixResults;
    this.checkIndex = 0;
    this.fixIndex = 0;
  }

  async check(files) {
    const result = this.checkResults[this.checkIndex] || { success: true, issues: [] };
    this.checkIndex++;
    return result;
  }

  async fix(files, strategy) {
    const result = this.fixResults[this.fixIndex] || { success: true, files_modified: files, fixes_applied: 1 };
    this.fixIndex++;
    return result;
  }

  getSupportedStrategies() {
    return ['conservative', 'balanced', 'aggressive'];
  }
}

// Mock MultiPassFixEngine
class MockFixEngine {
  constructor(results = {}) {
    this.results = results; // { moduleName: result }
    this.calls = [];
  }

  async fixWithRetries(module, files, options) {
    this.calls.push({ module: module.name, files, options });
    const result = this.results[module.name] || {
      success: true,
      attempts: 1,
      log: [],
      summary: { total_attempts: 1, final_success: true },
    };
    return result;
  }
}

describe('Orchestrator', () => {
  describe('constructor', () => {
    it('should create orchestrator with default config', () => {
      const orchestrator = new Orchestrator();
      assert.ok(orchestrator);
    });

    it('should accept custom components (DI)', () => {
      const mockDiscovery = new MockFileDiscovery();
      const mockRouter = new MockFileRouter();
      const mockEngine = new MockFixEngine();

      const orchestrator = new Orchestrator({
        fileDiscovery: mockDiscovery,
        fileRouter: mockRouter,
        fixEngine: mockEngine,
      });

      assert.ok(orchestrator);
    });
  });

  describe('run - success cases (IB)', () => {
    it('should successfully process files with no issues', async () => {
      const shellModule = new MockModule('shell', [{ success: true, issues: [] }]);

      const orchestrator = new Orchestrator({
        fileDiscovery: new MockFileDiscovery(['test.sh']),
        fileRouter: new MockFileRouter({
          shell: { module: shellModule, files: ['test.sh'] },
        }),
        fixEngine: new MockFixEngine({
          shell: { success: true, attempts: 1, log: [], summary: { final_success: true } },
        }),
      });

      const result = await orchestrator.run({ type: 'git_diff' });

      assert.strictEqual(result.success, true);
      assert.ok(result.summary);
    });

    it('should fix files and succeed', async () => {
      const shellModule = new MockModule('shell');

      const orchestrator = new Orchestrator({
        fileDiscovery: new MockFileDiscovery(['test.sh', 'script.sh']),
        fileRouter: new MockFileRouter({
          shell: { module: shellModule, files: ['test.sh', 'script.sh'] },
        }),
        fixEngine: new MockFixEngine({
          shell: {
            success: true,
            attempts: 3,
            log: [{ phase: 'check' }, { phase: 'fix' }, { phase: 'check' }],
            summary: { total_attempts: 3, final_success: true, initial_issue_count: 2, final_issue_count: 0 },
          },
        }),
      });

      const result = await orchestrator.run({ type: 'git_diff' });

      assert.strictEqual(result.success, true);
      assert.ok(result.summary);
      assert.ok(result.summary.modules);
    });

    it('should process multiple modules', async () => {
      const shellModule = new MockModule('shell');
      const jsModule = new MockModule('javascript');

      const orchestrator = new Orchestrator({
        fileDiscovery: new MockFileDiscovery(['test.sh', 'app.js']),
        fileRouter: new MockFileRouter({
          shell: { module: shellModule, files: ['test.sh'] },
          javascript: { module: jsModule, files: ['app.js'] },
        }),
        fixEngine: new MockFixEngine({
          shell: { success: true, attempts: 1, log: [], summary: { final_success: true } },
          javascript: { success: true, attempts: 1, log: [], summary: { final_success: true } },
        }),
      });

      const result = await orchestrator.run({ type: 'git_diff' });

      assert.strictEqual(result.success, true);
      assert.strictEqual(result.summary.modules.length, 2);
    });

    it('should handle empty file list', async () => {
      const orchestrator = new Orchestrator({
        fileDiscovery: new MockFileDiscovery([]),
        fileRouter: new MockFileRouter({}),
        fixEngine: new MockFixEngine({}),
      });

      const result = await orchestrator.run({ type: 'git_diff' });

      assert.strictEqual(result.success, true);
      assert.strictEqual(result.summary.total_files, 0);
      assert.strictEqual(result.summary.modules.length, 0);
    });
  });

  describe('run - failure cases (IB)', () => {
    it('should throw OrchestratorError on module failure', async () => {
      const shellModule = new MockModule('shell');

      const orchestrator = new Orchestrator({
        fileDiscovery: new MockFileDiscovery(['test.sh']),
        fileRouter: new MockFileRouter({
          shell: { module: shellModule, files: ['test.sh'] },
        }),
        fixEngine: new MockFixEngine({
          shell: {
            success: false,
            attempts: 5,
            log: [],
            summary: { final_success: false },
            remainingIssues: [{ file: 'test.sh', line: 1, message: 'unfixable error' }],
            message: 'Failed after 5 attempts',
          },
        }),
      });

      try {
        await orchestrator.run({ type: 'git_diff' });
        assert.fail('Should have thrown OrchestratorError');
      } catch (error) {
        assert.ok(error instanceof OrchestratorError);
        assert.ok(error.message.includes('Failed to fix all issues'));
        assert.ok(error.details);
        assert.ok(error.details.failures);
        assert.strictEqual(error.details.failures.length, 1);
      }
    });

    it('should throw OrchestratorError on partial failure', async () => {
      const shellModule = new MockModule('shell');
      const jsModule = new MockModule('javascript');

      const orchestrator = new Orchestrator({
        fileDiscovery: new MockFileDiscovery(['test.sh', 'app.js']),
        fileRouter: new MockFileRouter({
          shell: { module: shellModule, files: ['test.sh'] },
          javascript: { module: jsModule, files: ['app.js'] },
        }),
        fixEngine: new MockFixEngine({
          shell: { success: true, attempts: 1, log: [], summary: { final_success: true } },
          javascript: {
            success: false,
            attempts: 5,
            log: [],
            summary: { final_success: false },
            remainingIssues: [{ file: 'app.js' }],
          },
        }),
      });

      try {
        await orchestrator.run({ type: 'git_diff' });
        assert.fail('Should have thrown OrchestratorError');
      } catch (error) {
        assert.ok(error instanceof OrchestratorError);
        assert.strictEqual(error.details.failures.length, 1);
        assert.strictEqual(error.details.failures[0].module, 'javascript');
      }
    });
  });

  describe('generateSummary', () => {
    it('should generate comprehensive summary', () => {
      const orchestrator = new Orchestrator();

      const results = [
        {
          module: 'shell',
          files: ['test.sh', 'script.sh'],
          success: true,
          attempts: 3,
          summary: { total_attempts: 3, initial_issue_count: 2, final_issue_count: 0 },
        },
        {
          module: 'javascript',
          files: ['app.js'],
          success: true,
          attempts: 1,
          summary: { total_attempts: 1, initial_issue_count: 0, final_issue_count: 0 },
        },
      ];

      const summary = orchestrator.generateSummary(results);

      assert.strictEqual(summary.total_files, 3);
      assert.strictEqual(summary.total_modules, 2);
      assert.strictEqual(summary.successful_modules, 2);
      assert.strictEqual(summary.failed_modules, 0);
      assert.strictEqual(summary.modules.length, 2);
    });

    it('should include failure details in summary', () => {
      const orchestrator = new Orchestrator();

      const results = [
        {
          module: 'shell',
          files: ['test.sh'],
          success: false,
          attempts: 5,
          summary: { final_success: false },
          remainingIssues: [{ file: 'test.sh', line: 1 }],
        },
      ];

      const summary = orchestrator.generateSummary(results);

      assert.strictEqual(summary.successful_modules, 0);
      assert.strictEqual(summary.failed_modules, 1);
      assert.ok(summary.modules[0].remaining_issues);
    });

    it('should handle empty results', () => {
      const orchestrator = new Orchestrator();
      const summary = orchestrator.generateSummary([]);

      assert.strictEqual(summary.total_files, 0);
      assert.strictEqual(summary.total_modules, 0);
      assert.strictEqual(summary.successful_modules, 0);
      assert.strictEqual(summary.failed_modules, 0);
    });
  });

  describe('generateMarkdownSummary', () => {
    it('should generate markdown summary', () => {
      const orchestrator = new Orchestrator();

      const summary = {
        total_files: 3,
        total_modules: 2,
        successful_modules: 2,
        failed_modules: 0,
        modules: [
          {
            module: 'shell',
            files: ['test.sh', 'script.sh'],
            success: true,
            attempts: 3,
          },
          {
            module: 'javascript',
            files: ['app.js'],
            success: true,
            attempts: 1,
          },
        ],
      };

      const markdown = orchestrator.generateMarkdownSummary(summary);

      assert.ok(markdown.includes('## 🔄 Orchestrator V2 Results'));
      assert.ok(markdown.includes('**Total Files:**'));
      assert.ok(markdown.includes('shell'));
      assert.ok(markdown.includes('javascript'));
    });

    it('should include failure details in markdown', () => {
      const orchestrator = new Orchestrator();

      const summary = {
        total_files: 1,
        total_modules: 1,
        successful_modules: 0,
        failed_modules: 1,
        modules: [
          {
            module: 'shell',
            files: ['test.sh'],
            success: false,
            remaining_issues: [{ file: 'test.sh', line: 1, message: 'error' }],
          },
        ],
      };

      const markdown = orchestrator.generateMarkdownSummary(summary);

      assert.ok(markdown.includes('❌'));
      assert.ok(markdown.includes('Remaining Issues'));
    });
  });

  describe('run - options (IB)', () => {
    it('should pass maxAttempts option to fix engine', async () => {
      const shellModule = new MockModule('shell');
      const mockEngine = new MockFixEngine({
        shell: { success: true, attempts: 1, log: [], summary: { final_success: true } },
      });

      const orchestrator = new Orchestrator({
        fileDiscovery: new MockFileDiscovery(['test.sh']),
        fileRouter: new MockFileRouter({
          shell: { module: shellModule, files: ['test.sh'] },
        }),
        fixEngine: mockEngine,
      });

      await orchestrator.run({ type: 'git_diff' }, { maxAttempts: 10 });

      assert.strictEqual(mockEngine.calls.length, 1);
      assert.strictEqual(mockEngine.calls[0].options.maxAttempts, 10);
    });

    it('should pass timeout option to fix engine', async () => {
      const shellModule = new MockModule('shell');
      const mockEngine = new MockFixEngine({
        shell: { success: true, attempts: 1, log: [], summary: { final_success: true } },
      });

      const orchestrator = new Orchestrator({
        fileDiscovery: new MockFileDiscovery(['test.sh']),
        fileRouter: new MockFileRouter({
          shell: { module: shellModule, files: ['test.sh'] },
        }),
        fixEngine: mockEngine,
      });

      await orchestrator.run({ type: 'git_diff' }, { timeout: 120000 });

      assert.strictEqual(mockEngine.calls[0].options.timeout, 120000);
    });
  });

  describe('OrchestratorError', () => {
    it('should create error with message and details', () => {
      const error = new OrchestratorError('Test error', { foo: 'bar' });

      assert.strictEqual(error.message, 'Test error');
      assert.deepStrictEqual(error.details, { foo: 'bar' });
      assert.ok(error instanceof Error);
    });

    it('should work with instanceof check', () => {
      const error = new OrchestratorError('Test');
      assert.ok(error instanceof OrchestratorError);
      assert.ok(error instanceof Error);
    });
  });
});
