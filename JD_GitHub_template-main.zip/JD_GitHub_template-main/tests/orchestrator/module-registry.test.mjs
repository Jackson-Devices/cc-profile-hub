/**
 * Tests for Module Registry
 *
 * @module module-registry.test
 */

import { describe, it, before, beforeEach, after, afterEach } from 'node:test';
import * as assert from 'node:assert/strict';
import registry from '../../.github/scripts/orchestrator/module-registry.mjs';
import BaseModule from '../../.github/scripts/orchestrator/modules/base-module.mjs';

// Mock module classes for testing
class MockShellModule extends BaseModule {
  async check() {
    return this.formatCheckResult(true, []);
  }

  async fix() {
    return this.formatFixResult(true, [], 0, 'balanced');
  }
}

class MockJavaScriptModule extends BaseModule {
  async check() {
    return this.formatCheckResult(true, []);
  }

  async fix() {
    return this.formatFixResult(true, [], 0, 'default');
  }
}

describe('ModuleRegistry', () => {
  // Clear registry before each test to ensure isolation
  beforeEach(() => {
    registry.clear();
  });

  describe('Singleton pattern', () => {
    it('should return same instance', async () => {
      // Import the module again to test singleton
      const { default: registry2 } = await import(
        '../../.github/scripts/orchestrator/module-registry.mjs'
      );

      assert.equal(registry, registry2);
    });
  });

  describe('register()', () => {
    it('should register a module class', () => {
      registry.register('shell', MockShellModule);

      assert.equal(registry.has('shell'), true);
    });

    it('should allow multiple modules', () => {
      registry.register('shell', MockShellModule);
      registry.register('javascript', MockJavaScriptModule);

      assert.equal(registry.count(), 2);
    });

    it('should throw error for empty name', () => {
      assert.throws(
        () => registry.register('', MockShellModule),
        /Module name must be a non-empty string/
      );
    });

    it('should throw error for null name', () => {
      assert.throws(
        () => registry.register(null, MockShellModule),
        /Module name must be a non-empty string/
      );
    });

    it('should throw error for non-string name', () => {
      assert.throws(
        () => registry.register(123, MockShellModule),
        /Module name must be a non-empty string/
      );
    });

    it('should throw error for non-function moduleClass', () => {
      assert.throws(
        () => registry.register('shell', 'not-a-class'),
        /Module class must be a constructor function/
      );
    });

    it('should throw error for null moduleClass', () => {
      assert.throws(
        () => registry.register('shell', null),
        /Module class must be a constructor function/
      );
    });

    it('should allow overwriting existing module', () => {
      registry.register('shell', MockShellModule);
      registry.register('shell', MockJavaScriptModule); // Overwrite

      const ModuleClass = registry.get('shell');
      assert.equal(ModuleClass, MockJavaScriptModule);
    });
  });

  describe('get()', () => {
    beforeEach(() => {
      registry.register('shell', MockShellModule);
      registry.register('javascript', MockJavaScriptModule);
    });

    it('should return registered module class', () => {
      const ShellModule = registry.get('shell');

      assert.equal(ShellModule, MockShellModule);
    });

    it('should return correct module class for each name', () => {
      assert.equal(registry.get('shell'), MockShellModule);
      assert.equal(registry.get('javascript'), MockJavaScriptModule);
    });

    it('should return undefined for non-existent module', () => {
      const module = registry.get('nonexistent');

      assert.equal(module, undefined);
    });

    it('should return class that can be instantiated', () => {
      const ShellModule = registry.get('shell');
      const instance = new ShellModule('shell', {
        extensions: ['.sh'],
      });

      assert.ok(instance instanceof BaseModule);
      assert.equal(instance.name, 'shell');
    });
  });

  describe('has()', () => {
    beforeEach(() => {
      registry.register('shell', MockShellModule);
    });

    it('should return true for registered module', () => {
      assert.equal(registry.has('shell'), true);
    });

    it('should return false for non-existent module', () => {
      assert.equal(registry.has('nonexistent'), false);
    });

    it('should return false after module is unregistered', () => {
      registry.unregister('shell');

      assert.equal(registry.has('shell'), false);
    });
  });

  describe('list()', () => {
    it('should return empty array when no modules registered', () => {
      const names = registry.list();

      assert.deepEqual(names, []);
    });

    it('should return array of registered module names', () => {
      registry.register('shell', MockShellModule);
      registry.register('javascript', MockJavaScriptModule);

      const names = registry.list();

      assert.ok(names.includes('shell'));
      assert.ok(names.includes('javascript'));
      assert.equal(names.length, 2);
    });

    it('should update when modules are added', () => {
      registry.register('shell', MockShellModule);
      assert.equal(registry.list().length, 1);

      registry.register('javascript', MockJavaScriptModule);
      assert.equal(registry.list().length, 2);
    });

    it('should update when modules are removed', () => {
      registry.register('shell', MockShellModule);
      registry.register('javascript', MockJavaScriptModule);
      assert.equal(registry.list().length, 2);

      registry.unregister('shell');
      assert.equal(registry.list().length, 1);
      assert.ok(!registry.list().includes('shell'));
    });
  });

  describe('unregister()', () => {
    beforeEach(() => {
      registry.register('shell', MockShellModule);
      registry.register('javascript', MockJavaScriptModule);
    });

    it('should remove registered module', () => {
      const removed = registry.unregister('shell');

      assert.equal(removed, true);
      assert.equal(registry.has('shell'), false);
    });

    it('should return false for non-existent module', () => {
      const removed = registry.unregister('nonexistent');

      assert.equal(removed, false);
    });

    it('should not affect other modules', () => {
      registry.unregister('shell');

      assert.equal(registry.has('javascript'), true);
    });

    it('should allow re-registering after unregistering', () => {
      registry.unregister('shell');
      registry.register('shell', MockShellModule);

      assert.equal(registry.has('shell'), true);
    });
  });

  describe('clear()', () => {
    beforeEach(() => {
      registry.register('shell', MockShellModule);
      registry.register('javascript', MockJavaScriptModule);
    });

    it('should remove all modules', () => {
      registry.clear();

      assert.equal(registry.count(), 0);
      assert.deepEqual(registry.list(), []);
    });

    it('should allow registering after clearing', () => {
      registry.clear();
      registry.register('shell', MockShellModule);

      assert.equal(registry.has('shell'), true);
      assert.equal(registry.count(), 1);
    });
  });

  describe('count()', () => {
    it('should return 0 when no modules registered', () => {
      assert.equal(registry.count(), 0);
    });

    it('should return correct count', () => {
      registry.register('shell', MockShellModule);
      assert.equal(registry.count(), 1);

      registry.register('javascript', MockJavaScriptModule);
      assert.equal(registry.count(), 2);
    });

    it('should decrement when module removed', () => {
      registry.register('shell', MockShellModule);
      registry.register('javascript', MockJavaScriptModule);
      assert.equal(registry.count(), 2);

      registry.unregister('shell');
      assert.equal(registry.count(), 1);
    });

    it('should be 0 after clear', () => {
      registry.register('shell', MockShellModule);
      registry.register('javascript', MockJavaScriptModule);

      registry.clear();
      assert.equal(registry.count(), 0);
    });
  });
});
