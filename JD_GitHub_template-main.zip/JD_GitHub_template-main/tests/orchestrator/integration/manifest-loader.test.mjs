#!/usr/bin/env node
/* eslint-env mocha */

/**
 * Integration Tests for Manifest-Based Tool System
 *
 * Validates that all tool manifests can be loaded and properly integrated
 * into the orchestration framework.
 */

import { describe, it } from 'node:test';
import assert from 'node:assert/strict';
import { readFileSync, readdirSync } from 'node:fs';
import { join } from 'node:path';

// Path to manifest directory
const MANIFEST_DIR = '.orchestrator/tools';

describe('Manifest Loading Integration', () => {
  it('should discover all manifest files', () => {
    const files = readdirSync(MANIFEST_DIR).filter((f) => f.endsWith('.manifest.json'));

    assert.ok(files.length > 0, 'Should find at least one manifest file');
    assert.ok(files.includes('conflict-resolution.manifest.json'));
    assert.ok(files.includes('naming-convention.manifest.json'));
    assert.ok(files.includes('prettier.manifest.json'));
    assert.ok(files.includes('eslint.manifest.json'));
    assert.ok(files.includes('shellcheck.manifest.json'));
  });

  it('should load all manifests as valid JSON', () => {
    const files = readdirSync(MANIFEST_DIR).filter((f) => f.endsWith('.manifest.json'));

    for (const file of files) {
      const path = join(MANIFEST_DIR, file);
      const content = readFileSync(path, 'utf8');

      // Should parse without error
      const manifest = JSON.parse(content);

      assert.ok(manifest, `Manifest ${file} should parse as valid JSON`);
      assert.ok(manifest.id, `Manifest ${file} should have an id`);
      assert.ok(manifest.version, `Manifest ${file} should have a version`);
      assert.ok(manifest.name, `Manifest ${file} should have a name`);
    }
  });

  it('should have required manifest fields', () => {
    const files = readdirSync(MANIFEST_DIR).filter((f) => f.endsWith('.manifest.json'));

    const requiredTopLevel = ['id', 'version', 'name', 'description', 'type'];
    const requiredSections = ['inputs', 'outputs', 'execution', 'capabilities'];

    for (const file of files) {
      const path = join(MANIFEST_DIR, file);
      const manifest = JSON.parse(readFileSync(path, 'utf8'));

      // Check top-level required fields
      for (const field of requiredTopLevel) {
        assert.ok(
          manifest[field],
          `Manifest ${file} should have ${field} field`
        );
      }

      // Check required sections
      for (const section of requiredSections) {
        assert.ok(
          manifest[section],
          `Manifest ${file} should have ${section} section`
        );
      }
    }
  });

  it('should have valid exit codes', () => {
    const files = readdirSync(MANIFEST_DIR).filter((f) => f.endsWith('.manifest.json'));

    for (const file of files) {
      const path = join(MANIFEST_DIR, file);
      const manifest = JSON.parse(readFileSync(path, 'utf8'));

      assert.ok(manifest.outputs.exit_codes, `${file} should have exit_codes`);

      const exitCodes = manifest.outputs.exit_codes;
      assert.ok(exitCodes['0'], `${file} should have exit code 0 defined`);

      // Validate each exit code has required fields
      for (const [code, config] of Object.entries(exitCodes)) {
        assert.ok(config.meaning, `${file} exit code ${code} should have meaning`);
        assert.ok(config.action, `${file} exit code ${code} should have action`);
      }
    }
  });

  it('should have valid execution configuration', () => {
    const files = readdirSync(MANIFEST_DIR).filter((f) => f.endsWith('.manifest.json'));

    for (const file of files) {
      const path = join(MANIFEST_DIR, file);
      const manifest = JSON.parse(readFileSync(path, 'utf8'));

      const { execution } = manifest;

      assert.ok(execution.command, `${file} should have execution command`);
      assert.ok(execution.working_directory, `${file} should have working_directory`);
      assert.ok(
        typeof execution.timeout_ms === 'number',
        `${file} should have numeric timeout_ms`
      );
    }
  });

  it('should have valid human approval configuration', () => {
    const files = readdirSync(MANIFEST_DIR).filter((f) => f.endsWith('.manifest.json'));

    for (const file of files) {
      const path = join(MANIFEST_DIR, file);
      const manifest = JSON.parse(readFileSync(path, 'utf8'));

      if (manifest.human_approval) {
        const { human_approval } = manifest;

        assert.ok(
          Array.isArray(human_approval.approval_prompts),
          `${file} should have approval_prompts array`
        );

        for (const prompt of human_approval.approval_prompts) {
          assert.ok(prompt.trigger, `${file} prompt should have trigger`);
          assert.ok(prompt.message, `${file} prompt should have message`);
          assert.ok(
            Array.isArray(prompt.options),
            `${file} prompt should have options array`
          );

          for (const option of prompt.options) {
            assert.ok(option.value, `${file} option should have value`);
            assert.ok(option.label, `${file} option should have label`);
            assert.ok(option.action, `${file} option should have action`);
          }
        }
      }
    }
  });
});

describe('Tool Type Coverage', () => {
  it('should have manifests for different tool types', () => {
    const files = readdirSync(MANIFEST_DIR).filter((f) => f.endsWith('.manifest.json'));

    const types = new Set();

    for (const file of files) {
      const path = join(MANIFEST_DIR, file);
      const manifest = JSON.parse(readFileSync(path, 'utf8'));
      types.add(manifest.type);
    }

    assert.ok(types.has('linter'), 'Should have at least one linter');
    assert.ok(types.has('formatter'), 'Should have at least one formatter');
    assert.ok(types.has('analyzer'), 'Should have at least one analyzer');
    assert.ok(types.has('validator'), 'Should have at least one validator');
  });

  it('should have appropriate capabilities for each tool type', () => {
    const files = readdirSync(MANIFEST_DIR).filter((f) => f.endsWith('.manifest.json'));

    for (const file of files) {
      const path = join(MANIFEST_DIR, file);
      const manifest = JSON.parse(readFileSync(path, 'utf8'));

      const { capabilities } = manifest;

      assert.ok(
        typeof capabilities.auto_fix === 'boolean',
        `${file} should have auto_fix capability defined`
      );
      assert.ok(
        typeof capabilities.dry_run === 'boolean',
        `${file} should have dry_run capability defined`
      );
      assert.ok(
        typeof capabilities.idempotent === 'boolean',
        `${file} should have idempotent capability defined`
      );
    }
  });
});

describe('Manifest Consistency', () => {
  it('should use consistent exit code patterns', () => {
    const files = readdirSync(MANIFEST_DIR).filter((f) => f.endsWith('.manifest.json'));

    const validActions = ['continue', 'fail', 'human_approval', 'skip', 'abort'];

    for (const file of files) {
      const path = join(MANIFEST_DIR, file);
      const manifest = JSON.parse(readFileSync(path, 'utf8'));

      for (const [code, config] of Object.entries(manifest.outputs.exit_codes)) {
        assert.ok(
          validActions.includes(config.action),
          `${file} exit code ${code} has invalid action: ${config.action}`
        );
      }
    }
  });

  it('should use consistent approval prompt actions', () => {
    const files = readdirSync(MANIFEST_DIR).filter((f) => f.endsWith('.manifest.json'));

    const validActions = ['continue', 'retry', 'abort', 'custom'];

    for (const file of files) {
      const path = join(MANIFEST_DIR, file);
      const manifest = JSON.parse(readFileSync(path, 'utf8'));

      if (manifest.human_approval?.approval_prompts) {
        for (const prompt of manifest.human_approval.approval_prompts) {
          for (const option of prompt.options) {
            assert.ok(
              validActions.includes(option.action),
              `${file} prompt option has invalid action: ${option.action}`
            );
          }
        }
      }
    }
  });

  it('should use consistent retry strategies', () => {
    const files = readdirSync(MANIFEST_DIR).filter((f) => f.endsWith('.manifest.json'));

    const validStrategies = ['immediate', 'exponential_backoff', 'human_intervention'];

    for (const file of files) {
      const path = join(MANIFEST_DIR, file);
      const manifest = JSON.parse(readFileSync(path, 'utf8'));

      if (manifest.error_recovery?.strategies) {
        for (const strategy of manifest.error_recovery.strategies) {
          if (strategy.retry_strategy) {
            assert.ok(
              validStrategies.includes(strategy.retry_strategy),
              `${file} has invalid retry strategy: ${strategy.retry_strategy}`
            );
          }
        }
      }
    }
  });
});
