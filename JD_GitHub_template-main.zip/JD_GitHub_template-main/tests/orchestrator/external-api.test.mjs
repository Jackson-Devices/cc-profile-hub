/**
 * Tests for External Orchestration API
 *
 * TDD Approach: These tests are written FIRST, before implementation
 *
 * Enables LLMs and external systems to interact with the orchestrator
 */

import { describe, it, beforeEach } from 'node:test';
import assert from 'node:assert';

// Import the modules we're testing (will fail initially - that's TDD!)
import { OrchestratorAPI, JSONRPCHandler } from '../../.github/scripts/orchestrator/external-api.mjs';
import { RecipeRegistry } from '../../.github/scripts/orchestrator/recipe-system.mjs';

describe('External Orchestration API', () => {
  let api;
  let recipeRegistry;

  beforeEach(() => {
    recipeRegistry = new RecipeRegistry();
    api = new OrchestratorAPI({ recipeRegistry });
  });

  describe('JSON-RPC protocol', () => {
    it('should handle valid JSON-RPC request', async () => {
      const request = {
        jsonrpc: '2.0',
        method: 'ping',
        id: 1
      };

      const response = await api.handleRequest(request);

      assert.strictEqual(response.jsonrpc, '2.0');
      assert.strictEqual(response.id, 1);
      assert.strictEqual(response.result, 'pong');
    });

    it('should return error for invalid JSON-RPC version', async () => {
      const request = {
        jsonrpc: '1.0',
        method: 'ping',
        id: 1
      };

      const response = await api.handleRequest(request);

      assert.strictEqual(response.error.code, -32600);
      assert.ok(response.error.message.includes('Invalid Request'));
    });

    it('should return error for unknown method', async () => {
      const request = {
        jsonrpc: '2.0',
        method: 'unknown_method',
        id: 1
      };

      const response = await api.handleRequest(request);

      assert.strictEqual(response.error.code, -32601);
      assert.ok(response.error.message.includes('Method not found'));
    });

    it('should handle notification (no id)', async () => {
      const request = {
        jsonrpc: '2.0',
        method: 'ping'
      };

      const response = await api.handleRequest(request);

      // Notifications should not return a response
      assert.strictEqual(response, null);
    });

    it('should return error for malformed request', async () => {
      const request = {
        method: 'ping'
        // Missing jsonrpc field
      };

      const response = await api.handleRequest(request);

      assert.strictEqual(response.error.code, -32600);
    });
  });

  describe('get_status method', () => {
    it('should return orchestrator status', async () => {
      const request = {
        jsonrpc: '2.0',
        method: 'get_status',
        id: 1
      };

      const response = await api.handleRequest(request);

      assert.strictEqual(response.jsonrpc, '2.0');
      assert.ok(response.result);
      assert.ok(response.result.status);
      assert.ok(response.result.version);
      assert.ok(Array.isArray(response.result.modules));
    });

    it('should include recipe count in status', async () => {
      // Add some recipes
      const { Recipe } = await import('../../.github/scripts/orchestrator/recipe-system.mjs');
      recipeRegistry.register('test1', new Recipe({ name: 'test1', inputs: [], actions: [] }));
      recipeRegistry.register('test2', new Recipe({ name: 'test2', inputs: [], actions: [] }));

      const request = {
        jsonrpc: '2.0',
        method: 'get_status',
        id: 1
      };

      const response = await api.handleRequest(request);

      assert.strictEqual(response.result.recipeCount, 2);
    });
  });

  describe('list_recipes method', () => {
    it('should list all available recipes', async () => {
      const { Recipe } = await import('../../.github/scripts/orchestrator/recipe-system.mjs');
      recipeRegistry.register('readme', new Recipe({
        name: 'README Generator',
        description: 'Creates README.md',
        inputs: [{ name: 'project_name', type: 'string', required: true }],
        actions: []
      }));
      recipeRegistry.register('package-json', new Recipe({
        name: 'Package.json',
        description: 'Creates package.json',
        inputs: [],
        actions: []
      }));

      const request = {
        jsonrpc: '2.0',
        method: 'list_recipes',
        id: 1
      };

      const response = await api.handleRequest(request);

      assert.strictEqual(response.result.recipes.length, 2);
      assert.strictEqual(response.result.recipes[0].id, 'readme');
      assert.strictEqual(response.result.recipes[0].name, 'README Generator');
      assert.strictEqual(response.result.recipes[0].description, 'Creates README.md');
      assert.strictEqual(response.result.recipes[1].id, 'package-json');
    });

    it('should return empty array when no recipes registered', async () => {
      const request = {
        jsonrpc: '2.0',
        method: 'list_recipes',
        id: 1
      };

      const response = await api.handleRequest(request);

      assert.strictEqual(response.result.recipes.length, 0);
    });
  });

  describe('get_recipe method', () => {
    it('should get detailed recipe information', async () => {
      const { Recipe } = await import('../../.github/scripts/orchestrator/recipe-system.mjs');
      recipeRegistry.register('test-recipe', new Recipe({
        name: 'Test Recipe',
        description: 'A test recipe',
        inputs: [
          { name: 'name', type: 'string', required: true },
          { name: 'version', type: 'string', default: '1.0.0' }
        ],
        actions: [
          { type: 'create_file', path: 'test.txt', template: '{{name}}' }
        ]
      }));

      const request = {
        jsonrpc: '2.0',
        method: 'get_recipe',
        params: { recipe_id: 'test-recipe' },
        id: 1
      };

      const response = await api.handleRequest(request);

      assert.strictEqual(response.result.id, 'test-recipe');
      assert.strictEqual(response.result.name, 'Test Recipe');
      assert.strictEqual(response.result.inputs.length, 2);
      assert.strictEqual(response.result.inputs[0].name, 'name');
      assert.strictEqual(response.result.inputs[0].required, true);
      assert.strictEqual(response.result.actions.length, 1);
    });

    it('should return error for non-existent recipe', async () => {
      const request = {
        jsonrpc: '2.0',
        method: 'get_recipe',
        params: { recipe_id: 'non-existent' },
        id: 1
      };

      const response = await api.handleRequest(request);

      assert.ok(response.error);
      assert.strictEqual(response.error.code, -32602);
      assert.ok(response.error.message.includes('Recipe not found'));
    });
  });

  describe('apply_recipe method', () => {
    it('should apply recipe with provided inputs', async () => {
      const { Recipe } = await import('../../.github/scripts/orchestrator/recipe-system.mjs');
      const recipe = new Recipe({
        name: 'Test Recipe',
        inputs: [
          { name: 'value', type: 'string', required: true }
        ],
        actions: []
      });

      recipeRegistry.register('test', recipe);

      const request = {
        jsonrpc: '2.0',
        method: 'apply_recipe',
        params: {
          recipe_id: 'test',
          inputs: { value: 'hello' }
        },
        id: 1
      };

      const response = await api.handleRequest(request);

      assert.ok(response.result);
      assert.strictEqual(response.result.success, true);
      assert.ok(Array.isArray(response.result.results));
    });

    it('should return error for missing required inputs', async () => {
      const { Recipe } = await import('../../.github/scripts/orchestrator/recipe-system.mjs');
      const recipe = new Recipe({
        name: 'Test Recipe',
        inputs: [
          { name: 'required_field', type: 'string', required: true }
        ],
        actions: []
      });

      recipeRegistry.register('test', recipe);

      const request = {
        jsonrpc: '2.0',
        method: 'apply_recipe',
        params: {
          recipe_id: 'test',
          inputs: {}
        },
        id: 1
      };

      const response = await api.handleRequest(request);

      assert.ok(response.error);
      assert.ok(response.error.message.includes('Required input missing'));
    });
  });

  describe('suggest_fix method', () => {
    it('should provide suggestions for common issues', async () => {
      const request = {
        jsonrpc: '2.0',
        method: 'suggest_fix',
        params: {
          issue_type: 'missing_readme',
          context: {
            has_package_json: true,
            project_type: 'nodejs'
          }
        },
        id: 1
      };

      const response = await api.handleRequest(request);

      assert.ok(response.result);
      assert.ok(response.result.suggestion);
      assert.ok(response.result.recipe_id);
      assert.strictEqual(response.result.recipe_id, 'readme-template');
    });

    it('should return generic suggestion for unknown issue', async () => {
      const request = {
        jsonrpc: '2.0',
        method: 'suggest_fix',
        params: {
          issue_type: 'unknown_issue',
          context: {}
        },
        id: 1
      };

      const response = await api.handleRequest(request);

      assert.ok(response.result);
      assert.ok(response.result.suggestion);
      assert.strictEqual(response.result.recipe_id, null);
    });
  });

  describe('get_project_context method', () => {
    it('should return project context information', async () => {
      const request = {
        jsonrpc: '2.0',
        method: 'get_project_context',
        id: 1
      };

      const response = await api.handleRequest(request);

      assert.ok(response.result);
      assert.ok(response.result.project_type);
      assert.ok(Array.isArray(response.result.languages));
      assert.ok(typeof response.result.has_package_json === 'boolean');
    });
  });

  describe('validate_dependencies method', () => {
    it('should validate contextual dependencies', async () => {
      const request = {
        jsonrpc: '2.0',
        method: 'validate_dependencies',
        params: {
          rules: [
            {
              condition: 'file_exists',
              file: 'package.json',
              requires: ['README.md', '.gitignore']
            }
          ]
        },
        id: 1
      };

      const response = await api.handleRequest(request);

      assert.ok(response.result);
      assert.ok(Array.isArray(response.result.violations));
      assert.ok(typeof response.result.valid === 'boolean');
    });
  });

  describe('JSONRPCHandler - stdin/stdout communication', () => {
    it('should parse JSON-RPC from string', () => {
      const handler = new JSONRPCHandler(api);
      const input = '{"jsonrpc":"2.0","method":"ping","id":1}\n';

      const request = handler.parseRequest(input);

      assert.strictEqual(request.jsonrpc, '2.0');
      assert.strictEqual(request.method, 'ping');
      assert.strictEqual(request.id, 1);
    });

    it('should format response as JSON string', () => {
      const handler = new JSONRPCHandler(api);
      const response = {
        jsonrpc: '2.0',
        result: 'pong',
        id: 1
      };

      const output = handler.formatResponse(response);

      assert.ok(output.endsWith('\n'));
      const parsed = JSON.parse(output.trim());
      assert.strictEqual(parsed.jsonrpc, '2.0');
      assert.strictEqual(parsed.result, 'pong');
    });

    it('should handle multiple requests (batch)', async () => {
      const handler = new JSONRPCHandler(api);
      const input = '[{"jsonrpc":"2.0","method":"ping","id":1},{"jsonrpc":"2.0","method":"ping","id":2}]\n';

      const requests = handler.parseRequest(input);

      assert.ok(Array.isArray(requests));
      assert.strictEqual(requests.length, 2);
      assert.strictEqual(requests[0].id, 1);
      assert.strictEqual(requests[1].id, 2);
    });
  });

  describe('Error handling', () => {
    it('should handle internal errors gracefully', async () => {
      // Override a method to throw an error
      const originalMethod = api.handlers.get('ping');
      api.handlers.set('ping', () => {
        throw new Error('Internal error');
      });

      const request = {
        jsonrpc: '2.0',
        method: 'ping',
        id: 1
      };

      const response = await api.handleRequest(request);

      assert.ok(response.error);
      assert.strictEqual(response.error.code, -32603);
      assert.ok(response.error.message.includes('Internal error'));

      // Restore original method
      api.handlers.set('ping', originalMethod);
    });

    it('should validate params structure', async () => {
      const request = {
        jsonrpc: '2.0',
        method: 'get_recipe',
        params: 'invalid', // should be object or array
        id: 1
      };

      const response = await api.handleRequest(request);

      assert.ok(response.error);
      assert.strictEqual(response.error.code, -32602);
    });
  });

  describe('Integration - LLM workflow', () => {
    it('should support complete LLM-assisted recipe creation workflow', async () => {
      // 1. LLM gets project context
      const contextRequest = {
        jsonrpc: '2.0',
        method: 'get_project_context',
        id: 1
      };
      const contextResponse = await api.handleRequest(contextRequest);
      assert.ok(contextResponse.result);

      // 2. LLM lists available recipes
      const listRequest = {
        jsonrpc: '2.0',
        method: 'list_recipes',
        id: 2
      };
      const listResponse = await api.handleRequest(listRequest);
      assert.ok(Array.isArray(listResponse.result.recipes));

      // 3. LLM suggests a fix
      const suggestRequest = {
        jsonrpc: '2.0',
        method: 'suggest_fix',
        params: {
          issue_type: 'missing_readme',
          context: contextResponse.result
        },
        id: 3
      };
      const suggestResponse = await api.handleRequest(suggestRequest);
      assert.ok(suggestResponse.result.suggestion);
    });
  });
});
