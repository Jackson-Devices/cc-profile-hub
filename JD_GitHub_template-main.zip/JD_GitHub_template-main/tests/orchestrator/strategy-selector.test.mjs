/**
 * Tests for StrategySelector
 *
 * The StrategySelector determines which fix strategy to use based on:
 * - Current attempt number
 * - Available strategies for the module
 *
 * Strategy escalation:
 * - Attempts 1-2: Use first strategy (conservative)
 * - Attempts 3-4: Use second strategy (balanced)
 * - Attempts 5+: Use third strategy (aggressive)
 */

import { describe, it } from 'node:test';
import assert from 'node:assert';
import StrategySelector from '../../.github/scripts/orchestrator/strategy-selector.mjs';

describe('StrategySelector', () => {
  describe('constructor', () => {
    it('should create selector with default strategies', () => {
      const selector = new StrategySelector();
      assert.ok(selector);
    });

    it('should accept custom strategies', () => {
      const strategies = ['conservative', 'balanced', 'aggressive'];
      const selector = new StrategySelector(strategies);
      assert.deepStrictEqual(selector.strategies, strategies);
    });

    it('should handle single strategy', () => {
      const selector = new StrategySelector(['default']);
      assert.deepStrictEqual(selector.strategies, ['default']);
    });

    it('should handle empty strategies (OOB)', () => {
      const selector = new StrategySelector([]);
      assert.deepStrictEqual(selector.strategies, []);
    });
  });

  describe('selectStrategy - normal cases (IB)', () => {
    it('should use first strategy for attempt 1', () => {
      const selector = new StrategySelector(['conservative', 'balanced', 'aggressive']);
      assert.strictEqual(selector.selectStrategy(1), 'conservative');
    });

    it('should use first strategy for attempt 2', () => {
      const selector = new StrategySelector(['conservative', 'balanced', 'aggressive']);
      assert.strictEqual(selector.selectStrategy(2), 'conservative');
    });

    it('should use second strategy for attempt 3', () => {
      const selector = new StrategySelector(['conservative', 'balanced', 'aggressive']);
      assert.strictEqual(selector.selectStrategy(3), 'balanced');
    });

    it('should use second strategy for attempt 4', () => {
      const selector = new StrategySelector(['conservative', 'balanced', 'aggressive']);
      assert.strictEqual(selector.selectStrategy(4), 'balanced');
    });

    it('should use third strategy for attempt 5', () => {
      const selector = new StrategySelector(['conservative', 'balanced', 'aggressive']);
      assert.strictEqual(selector.selectStrategy(5), 'aggressive');
    });

    it('should use third strategy for attempt 6+', () => {
      const selector = new StrategySelector(['conservative', 'balanced', 'aggressive']);
      assert.strictEqual(selector.selectStrategy(6), 'aggressive');
      assert.strictEqual(selector.selectStrategy(10), 'aggressive');
    });
  });

  describe('selectStrategy - single strategy (IB)', () => {
    it('should always use the only strategy available', () => {
      const selector = new StrategySelector(['default']);
      assert.strictEqual(selector.selectStrategy(1), 'default');
      assert.strictEqual(selector.selectStrategy(3), 'default');
      assert.strictEqual(selector.selectStrategy(5), 'default');
    });
  });

  describe('selectStrategy - two strategies (IB)', () => {
    it('should alternate between two strategies', () => {
      const selector = new StrategySelector(['basic', 'advanced']);
      assert.strictEqual(selector.selectStrategy(1), 'basic');
      assert.strictEqual(selector.selectStrategy(2), 'basic');
      assert.strictEqual(selector.selectStrategy(3), 'advanced');
      assert.strictEqual(selector.selectStrategy(4), 'advanced');
      assert.strictEqual(selector.selectStrategy(5), 'advanced');
    });
  });

  describe('selectStrategy - edge cases (OOB)', () => {
    it('should handle attempt 0 (OOB)', () => {
      const selector = new StrategySelector(['conservative', 'balanced', 'aggressive']);
      // Should return first strategy as fallback
      const result = selector.selectStrategy(0);
      assert.ok(result); // Should return something valid
    });

    it('should handle negative attempt (OOB)', () => {
      const selector = new StrategySelector(['conservative', 'balanced', 'aggressive']);
      // Should return first strategy as fallback
      const result = selector.selectStrategy(-1);
      assert.ok(result); // Should return something valid
    });

    it('should handle very large attempt number (OOB)', () => {
      const selector = new StrategySelector(['conservative', 'balanced', 'aggressive']);
      assert.strictEqual(selector.selectStrategy(100), 'aggressive');
      assert.strictEqual(selector.selectStrategy(999999), 'aggressive');
    });

    it('should handle empty strategies (OOB)', () => {
      const selector = new StrategySelector([]);
      const result = selector.selectStrategy(1);
      // Should return null or undefined when no strategies available
      assert.strictEqual(result, null);
    });

    it('should handle null strategies (OOB)', () => {
      const selector = new StrategySelector(null);
      const result = selector.selectStrategy(1);
      assert.strictEqual(result, null);
    });

    it('should handle undefined strategies (OOB)', () => {
      const selector = new StrategySelector(undefined);
      const result = selector.selectStrategy(1);
      assert.strictEqual(result, null);
    });

    it('should handle non-array strategies (OOB)', () => {
      const selector = new StrategySelector('not-an-array');
      const result = selector.selectStrategy(1);
      assert.strictEqual(result, null);
    });
  });

  describe('getStrategyIndex', () => {
    it('should return correct index for each attempt', () => {
      const selector = new StrategySelector(['conservative', 'balanced', 'aggressive']);
      assert.strictEqual(selector.getStrategyIndex(1), 0);
      assert.strictEqual(selector.getStrategyIndex(2), 0);
      assert.strictEqual(selector.getStrategyIndex(3), 1);
      assert.strictEqual(selector.getStrategyIndex(4), 1);
      assert.strictEqual(selector.getStrategyIndex(5), 2);
      assert.strictEqual(selector.getStrategyIndex(10), 2);
    });
  });

  describe('hasMoreStrategies', () => {
    it('should return true when more strategies available', () => {
      const selector = new StrategySelector(['conservative', 'balanced', 'aggressive']);
      assert.strictEqual(selector.hasMoreStrategies(1), true); // Can escalate to balanced
      assert.strictEqual(selector.hasMoreStrategies(3), true); // Can escalate to aggressive
    });

    it('should return false when on last strategy', () => {
      const selector = new StrategySelector(['conservative', 'balanced', 'aggressive']);
      assert.strictEqual(selector.hasMoreStrategies(5), false); // Already on aggressive
      assert.strictEqual(selector.hasMoreStrategies(10), false);
    });

    it('should return false for single strategy', () => {
      const selector = new StrategySelector(['default']);
      assert.strictEqual(selector.hasMoreStrategies(1), false);
      assert.strictEqual(selector.hasMoreStrategies(5), false);
    });
  });
});
