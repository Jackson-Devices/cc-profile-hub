/**
 * Tests for Contextual Dependency System
 *
 * TDD Approach: These tests are written FIRST, before implementation
 *
 * Implements "if A is present then so should B and C" requirements
 */

import { describe, it, beforeEach, afterEach } from 'node:test';
import assert from 'node:assert';
import { mkdtemp, rm, writeFile, mkdir } from 'node:fs/promises';
import { join } from 'node:path';
import { tmpdir } from 'node:os';

// Import the modules we're testing (will fail initially - that's TDD!)
import { DependencyValidator, DependencyRule } from '../../.github/scripts/orchestrator/contextual-dependency-system.mjs';

describe('Contextual Dependency System', () => {
  let tmpDir;
  let validator;

  beforeEach(async () => {
    // Create temp directory for test files
    tmpDir = await mkdtemp(join(tmpdir(), 'dependency-test-'));
    validator = new DependencyValidator();
  });

  afterEach(async () => {
    // Cleanup
    await rm(tmpDir, { recursive: true, force: true });
  });

  describe('DependencyRule - basic rules', () => {
    it('should create simple file existence rule', () => {
      const rule = new DependencyRule({
        id: 'package-requires-readme',
        condition: {
          type: 'file_exists',
          path: 'package.json'
        },
        requires: [
          { type: 'file_exists', path: 'README.md' }
        ]
      });

      assert.strictEqual(rule.id, 'package-requires-readme');
      assert.strictEqual(rule.condition.type, 'file_exists');
      assert.strictEqual(rule.requires.length, 1);
    });

    it('should support multiple dependencies', () => {
      const rule = new DependencyRule({
        id: 'package-standard-files',
        condition: {
          type: 'file_exists',
          path: 'package.json'
        },
        requires: [
          { type: 'file_exists', path: 'README.md' },
          { type: 'file_exists', path: '.gitignore' },
          { type: 'file_exists', path: 'LICENSE' }
        ]
      });

      assert.strictEqual(rule.requires.length, 3);
    });

    it('should include severity level', () => {
      const rule = new DependencyRule({
        id: 'test-rule',
        condition: { type: 'file_exists', path: 'test.js' },
        requires: [{ type: 'file_exists', path: 'test.spec.js' }],
        severity: 'error'
      });

      assert.strictEqual(rule.severity, 'error');
    });

    it('should include helpful message', () => {
      const rule = new DependencyRule({
        id: 'test-rule',
        condition: { type: 'file_exists', path: 'package.json' },
        requires: [{ type: 'file_exists', path: 'README.md' }],
        message: 'Projects with package.json should have a README.md'
      });

      assert.strictEqual(rule.message, 'Projects with package.json should have a README.md');
    });
  });

  describe('DependencyValidator - file_exists validation', () => {
    it('should pass when all dependencies exist', async () => {
      // Create files
      await writeFile(join(tmpDir, 'package.json'), '{}');
      await writeFile(join(tmpDir, 'README.md'), '# Test');

      const rule = new DependencyRule({
        id: 'test-rule',
        condition: { type: 'file_exists', path: join(tmpDir, 'package.json') },
        requires: [{ type: 'file_exists', path: join(tmpDir, 'README.md') }]
      });

      const result = await validator.validate([rule]);

      assert.strictEqual(result.valid, true);
      assert.strictEqual(result.violations.length, 0);
    });

    it('should fail when dependency is missing', async () => {
      // Create only package.json, not README.md
      await writeFile(join(tmpDir, 'package.json'), '{}');

      const rule = new DependencyRule({
        id: 'test-rule',
        condition: { type: 'file_exists', path: join(tmpDir, 'package.json') },
        requires: [{ type: 'file_exists', path: join(tmpDir, 'README.md') }]
      });

      const result = await validator.validate([rule]);

      assert.strictEqual(result.valid, false);
      assert.strictEqual(result.violations.length, 1);
      assert.strictEqual(result.violations[0].rule_id, 'test-rule');
      assert.ok(result.violations[0].message.includes('README.md'));
    });

    it('should detect multiple missing dependencies', async () => {
      await writeFile(join(tmpDir, 'package.json'), '{}');

      const rule = new DependencyRule({
        id: 'test-rule',
        condition: { type: 'file_exists', path: join(tmpDir, 'package.json') },
        requires: [
          { type: 'file_exists', path: join(tmpDir, 'README.md') },
          { type: 'file_exists', path: join(tmpDir, '.gitignore') },
          { type: 'file_exists', path: join(tmpDir, 'LICENSE') }
        ]
      });

      const result = await validator.validate([rule]);

      assert.strictEqual(result.valid, false);
      assert.strictEqual(result.violations.length, 3);
    });

    it('should not trigger rule when condition is not met', async () => {
      // No package.json, so rule should not apply
      const rule = new DependencyRule({
        id: 'test-rule',
        condition: { type: 'file_exists', path: join(tmpDir, 'package.json') },
        requires: [{ type: 'file_exists', path: join(tmpDir, 'README.md') }]
      });

      const result = await validator.validate([rule]);

      // Should pass because condition not met (no package.json)
      assert.strictEqual(result.valid, true);
      assert.strictEqual(result.violations.length, 0);
    });
  });

  describe('DependencyValidator - file_pattern validation', () => {
    it('should validate dependencies based on file patterns', async () => {
      // Create TypeScript files
      await writeFile(join(tmpDir, 'index.ts'), 'export {}');
      await writeFile(join(tmpDir, 'utils.ts'), 'export {}');

      const rule = new DependencyRule({
        id: 'typescript-requires-config',
        condition: {
          type: 'file_pattern',
          pattern: '**/*.ts',
          basePath: tmpDir
        },
        requires: [
          { type: 'file_exists', path: join(tmpDir, 'tsconfig.json') }
        ]
      });

      const result = await validator.validate([rule]);

      assert.strictEqual(result.valid, false);
      assert.strictEqual(result.violations.length, 1);
      assert.ok(result.violations[0].message.includes('tsconfig.json'));
    });

    it('should pass when pattern matches and dependencies exist', async () => {
      await writeFile(join(tmpDir, 'index.ts'), 'export {}');
      await writeFile(join(tmpDir, 'tsconfig.json'), '{}');

      const rule = new DependencyRule({
        id: 'typescript-requires-config',
        condition: {
          type: 'file_pattern',
          pattern: '**/*.ts',
          basePath: tmpDir
        },
        requires: [
          { type: 'file_exists', path: join(tmpDir, 'tsconfig.json') }
        ]
      });

      const result = await validator.validate([rule]);

      assert.strictEqual(result.valid, true);
    });
  });

  describe('DependencyValidator - content_contains validation', () => {
    it('should validate based on file content', async () => {
      await writeFile(join(tmpDir, 'package.json'), JSON.stringify({
        scripts: {
          test: 'jest'
        }
      }));

      const rule = new DependencyRule({
        id: 'jest-requires-config',
        condition: {
          type: 'content_contains',
          path: join(tmpDir, 'package.json'),
          pattern: 'jest'
        },
        requires: [
          { type: 'file_exists', path: join(tmpDir, 'jest.config.js') }
        ]
      });

      const result = await validator.validate([rule]);

      assert.strictEqual(result.valid, false);
      assert.ok(result.violations[0].message.includes('jest.config.js'));
    });

    it('should not trigger when content does not match', async () => {
      await writeFile(join(tmpDir, 'package.json'), JSON.stringify({
        scripts: {
          test: 'mocha'
        }
      }));

      const rule = new DependencyRule({
        id: 'jest-requires-config',
        condition: {
          type: 'content_contains',
          path: join(tmpDir, 'package.json'),
          pattern: 'jest'
        },
        requires: [
          { type: 'file_exists', path: join(tmpDir, 'jest.config.js') }
        ]
      });

      const result = await validator.validate([rule]);

      assert.strictEqual(result.valid, true);
    });
  });

  describe('DependencyValidator - multiple rules', () => {
    it('should validate multiple rules', async () => {
      await writeFile(join(tmpDir, 'package.json'), '{}');
      await writeFile(join(tmpDir, 'index.ts'), 'export {}');

      const rules = [
        new DependencyRule({
          id: 'rule1',
          condition: { type: 'file_exists', path: join(tmpDir, 'package.json') },
          requires: [{ type: 'file_exists', path: join(tmpDir, 'README.md') }]
        }),
        new DependencyRule({
          id: 'rule2',
          condition: { type: 'file_exists', path: join(tmpDir, 'index.ts') },
          requires: [{ type: 'file_exists', path: join(tmpDir, 'tsconfig.json') }]
        })
      ];

      const result = await validator.validate(rules);

      assert.strictEqual(result.valid, false);
      assert.strictEqual(result.violations.length, 2);
      assert.ok(result.violations.find(v => v.rule_id === 'rule1'));
      assert.ok(result.violations.find(v => v.rule_id === 'rule2'));
    });

    it('should collect violations from all rules', async () => {
      await writeFile(join(tmpDir, 'package.json'), '{}');

      const rules = [
        new DependencyRule({
          id: 'rule1',
          condition: { type: 'file_exists', path: join(tmpDir, 'package.json') },
          requires: [
            { type: 'file_exists', path: join(tmpDir, 'README.md') },
            { type: 'file_exists', path: join(tmpDir, '.gitignore') }
          ]
        }),
        new DependencyRule({
          id: 'rule2',
          condition: { type: 'file_exists', path: join(tmpDir, 'package.json') },
          requires: [
            { type: 'file_exists', path: join(tmpDir, 'LICENSE') }
          ]
        })
      ];

      const result = await validator.validate(rules);

      assert.strictEqual(result.violations.length, 3);
    });
  });

  describe('DependencyValidator - severity levels', () => {
    it('should categorize violations by severity', async () => {
      await writeFile(join(tmpDir, 'package.json'), '{}');

      const rules = [
        new DependencyRule({
          id: 'error-rule',
          condition: { type: 'file_exists', path: join(tmpDir, 'package.json') },
          requires: [{ type: 'file_exists', path: join(tmpDir, 'LICENSE') }],
          severity: 'error'
        }),
        new DependencyRule({
          id: 'warning-rule',
          condition: { type: 'file_exists', path: join(tmpDir, 'package.json') },
          requires: [{ type: 'file_exists', path: join(tmpDir, 'README.md') }],
          severity: 'warning'
        })
      ];

      const result = await validator.validate(rules);

      const errors = result.violations.filter(v => v.severity === 'error');
      const warnings = result.violations.filter(v => v.severity === 'warning');

      assert.strictEqual(errors.length, 1);
      assert.strictEqual(warnings.length, 1);
    });
  });

  describe('DependencyValidator - auto-fix suggestions', () => {
    it('should provide fix suggestions for violations', async () => {
      await writeFile(join(tmpDir, 'package.json'), '{}');

      const rule = new DependencyRule({
        id: 'test-rule',
        condition: { type: 'file_exists', path: join(tmpDir, 'package.json') },
        requires: [{ type: 'file_exists', path: join(tmpDir, 'README.md') }],
        autoFix: {
          enabled: true,
          action: 'create_from_recipe',
          recipe: 'readme-template'
        }
      });

      const result = await validator.validate([rule]);

      assert.strictEqual(result.violations.length, 1);
      assert.ok(result.violations[0].autoFix);
      assert.strictEqual(result.violations[0].autoFix.action, 'create_from_recipe');
      assert.strictEqual(result.violations[0].autoFix.recipe, 'readme-template');
    });
  });

  describe('DependencyValidator - loading from YAML config', () => {
    it('should load rules from YAML configuration', async () => {
      const configPath = join(tmpDir, 'dependency-rules.yml');
      const yamlContent = `
rules:
  - id: package-requires-readme
    condition:
      type: file_exists
      path: package.json
    requires:
      - type: file_exists
        path: README.md
    severity: warning
    message: "Projects should have a README"

  - id: typescript-requires-config
    condition:
      type: file_pattern
      pattern: "**/*.ts"
    requires:
      - type: file_exists
        path: tsconfig.json
    severity: error
`;

      await writeFile(configPath, yamlContent);

      const validator2 = new DependencyValidator();
      await validator2.loadFromFile(configPath);

      const rules = validator2.getRules();
      assert.strictEqual(rules.length, 2);
      assert.strictEqual(rules[0].id, 'package-requires-readme');
      assert.strictEqual(rules[1].id, 'typescript-requires-config');
    });
  });

  describe('Integration - realistic scenarios', () => {
    it('should validate Node.js project structure', async () => {
      // Create typical Node.js project with missing files
      await writeFile(join(tmpDir, 'package.json'), JSON.stringify({
        name: 'test-project',
        version: '1.0.0'
      }));
      await writeFile(join(tmpDir, 'index.js'), 'console.log("hello")');

      const rules = [
        new DependencyRule({
          id: 'nodejs-standard-files',
          condition: { type: 'file_exists', path: join(tmpDir, 'package.json') },
          requires: [
            { type: 'file_exists', path: join(tmpDir, 'README.md') },
            { type: 'file_exists', path: join(tmpDir, '.gitignore') },
            { type: 'file_exists', path: join(tmpDir, 'LICENSE') }
          ],
          severity: 'warning',
          message: 'Node.js projects should include README, .gitignore, and LICENSE'
        })
      ];

      const result = await validator.validate(rules);

      assert.strictEqual(result.valid, false);
      assert.strictEqual(result.violations.length, 3);
      assert.ok(result.violations.every(v => v.severity === 'warning'));
    });

    it('should validate TypeScript project dependencies', async () => {
      await mkdir(join(tmpDir, 'src'), { recursive: true });
      await writeFile(join(tmpDir, 'src', 'index.ts'), 'export {}');
      await writeFile(join(tmpDir, 'package.json'), JSON.stringify({
        devDependencies: {
          typescript: '^5.0.0'
        }
      }));

      const rules = [
        new DependencyRule({
          id: 'typescript-project',
          condition: {
            type: 'file_pattern',
            pattern: '**/*.ts',
            basePath: tmpDir
          },
          requires: [
            { type: 'file_exists', path: join(tmpDir, 'tsconfig.json') },
            { type: 'file_exists', path: join(tmpDir, 'package.json') }
          ],
          severity: 'error'
        })
      ];

      const result = await validator.validate(rules);

      assert.strictEqual(result.valid, false);
      const tsconfigViolation = result.violations.find(v => v.message.includes('tsconfig.json'));
      assert.ok(tsconfigViolation);
    });

    it('should validate test file dependencies', async () => {
      await mkdir(join(tmpDir, 'src'), { recursive: true });
      await writeFile(join(tmpDir, 'src', 'utils.js'), 'export function add() {}');

      const rules = [
        new DependencyRule({
          id: 'source-requires-test',
          condition: {
            type: 'file_pattern',
            pattern: 'src/**/*.js',
            basePath: tmpDir
          },
          requires: [
            {
              type: 'file_pattern',
              pattern: 'tests/**/*.test.js',
              basePath: tmpDir
            }
          ],
          severity: 'warning',
          message: 'Source files should have corresponding test files'
        })
      ];

      const result = await validator.validate(rules);

      assert.strictEqual(result.valid, false);
    });
  });

  describe('Error handling', () => {
    it('should handle invalid rule gracefully', async () => {
      const rule = new DependencyRule({
        id: 'invalid-rule',
        condition: { type: 'unknown_type', path: 'test.js' },
        requires: []
      });

      const result = await validator.validate([rule]);

      // Should not crash, should report as skipped or invalid
      assert.ok(result);
    });

    it('should handle file read errors', async () => {
      const rule = new DependencyRule({
        id: 'test-rule',
        condition: {
          type: 'content_contains',
          path: join(tmpDir, 'nonexistent.json'),
          pattern: 'test'
        },
        requires: []
      });

      const result = await validator.validate([rule]);

      // Should not crash on missing file
      assert.strictEqual(result.valid, true);
    });
  });
});
