/**
 * Unit Tests for Test Case Checklist Parsing Functions
 * TDD-First: These tests are written BEFORE implementation
 *
 * Tests checklist extraction, parsing, ordering, and manipulation
 * Expected to FAIL initially (RED phase)
 */

import { describe, it } from 'node:test';
import assert from 'node:assert';
import {
  parseRunChecklist,
  extractChecklistItems,
  countChecklistProgress,
  hasRunChecklist,
  buildRunChecklist,
  orderTestCases,
  updateChecklistItem,
  extractCompletedTestCases,
  validateChecklistFormat
} from '../../../.github/scripts/utils/checklist-parsing.mjs';

describe('Checklist Parsing - hasRunChecklist', () => {
  it('should return true when Run checklist exists', () => {
    const body = `## Test Cases
IB-01: Test case
IB-02: Another test

### Run checklist
- [ ] OOB-01
- [ ] IB-01`;

    assert.strictEqual(hasRunChecklist(body), true);
  });

  it('should return true for "Run checklist" with different heading levels', () => {
    const body = `## Run checklist
- [ ] IB-01`;

    assert.strictEqual(hasRunChecklist(body), true);
  });

  it('should return false when no Run checklist present', () => {
    const body = `## Test Cases
IB-01: Test case`;

    assert.strictEqual(hasRunChecklist(body), false);
  });

  it('should be case-insensitive for "Run checklist"', () => {
    const body = `### run CHECKLIST
- [ ] IB-01`;

    assert.strictEqual(hasRunChecklist(body), true);
  });

  it('should handle empty body', () => {
    assert.strictEqual(hasRunChecklist(''), false);
  });
});

describe('Checklist Parsing - parseRunChecklist', () => {
  it('should parse unchecked items', () => {
    const body = `### Run checklist
- [ ] OOB-01
- [ ] IB-01
- [ ] OOB-02`;

    const result = parseRunChecklist(body);

    assert.deepStrictEqual(result, [
      { id: 'OOB-01', checked: false },
      { id: 'IB-01', checked: false },
      { id: 'OOB-02', checked: false }
    ]);
  });

  it('should parse checked items', () => {
    const body = `### Run checklist
- [x] OOB-01
- [ ] IB-01
- [X] OOB-02`;

    const result = parseRunChecklist(body);

    assert.strictEqual(result[0].checked, true);
    assert.strictEqual(result[1].checked, false);
    assert.strictEqual(result[2].checked, true);
  });

  it('should extract test case IDs', () => {
    const body = `### Run checklist
- [ ] OOB-01
- [ ] IB-01: Some description
- [ ] OOB-02`;

    const result = parseRunChecklist(body);

    assert.strictEqual(result[0].id, 'OOB-01');
    assert.strictEqual(result[1].id, 'IB-01');
    assert.strictEqual(result[2].id, 'OOB-02');
  });

  it('should return empty array when no checklist', () => {
    const body = `## Test Cases
No checklist here`;

    const result = parseRunChecklist(body);

    assert.deepStrictEqual(result, []);
  });

  it('should handle checklist with mixed content', () => {
    const body = `### Run checklist
- [ ] OOB-01
Some text here
- [x] IB-01
More text
- [ ] OOB-02`;

    const result = parseRunChecklist(body);

    assert.strictEqual(result.length, 3);
    assert.strictEqual(result[1].checked, true);
  });

  it('should stop parsing at next heading', () => {
    const body = `### Run checklist
- [ ] OOB-01
- [ ] IB-01

## Another Section
- [ ] OOB-02`;

    const result = parseRunChecklist(body);

    assert.strictEqual(result.length, 2);
    assert.ok(!result.some(item => item.id === 'OOB-02'));
  });

  it('should handle indented checklist items', () => {
    const body = `### Run checklist
  - [ ] OOB-01
  - [x] IB-01`;

    const result = parseRunChecklist(body);

    assert.strictEqual(result.length, 2);
    assert.strictEqual(result[0].id, 'OOB-01');
  });
});

describe('Checklist Parsing - extractChecklistItems', () => {
  it('should extract all checkbox items from text', () => {
    const text = `- [ ] Item 1
- [x] Item 2
- [ ] Item 3`;

    const result = extractChecklistItems(text);

    assert.strictEqual(result.length, 3);
    assert.strictEqual(result[0].checked, false);
    assert.strictEqual(result[1].checked, true);
    assert.strictEqual(result[0].text, 'Item 1');
  });

  it('should handle checkboxes without space after dash', () => {
    const text = `-[ ] Item 1
-[x] Item 2`;

    const result = extractChecklistItems(text);

    assert.strictEqual(result.length, 2);
  });

  it('should extract text after checkbox', () => {
    const text = `- [ ] OOB-01: Test description here`;

    const result = extractChecklistItems(text);

    assert.strictEqual(result[0].text, 'OOB-01: Test description here');
  });

  it('should return empty array for no checkboxes', () => {
    const text = `Just regular text
No checkboxes here`;

    const result = extractChecklistItems(text);

    assert.deepStrictEqual(result, []);
  });
});

describe('Checklist Parsing - countChecklistProgress', () => {
  it('should count completed and total items', () => {
    const items = [
      { id: 'OOB-01', checked: true },
      { id: 'IB-01', checked: false },
      { id: 'OOB-02', checked: true }
    ];

    const result = countChecklistProgress(items);

    assert.deepStrictEqual(result, {
      completed: 2,
      total: 3,
      percentage: 67
    });
  });

  it('should handle all completed', () => {
    const items = [
      { id: 'OOB-01', checked: true },
      { id: 'IB-01', checked: true }
    ];

    const result = countChecklistProgress(items);

    assert.strictEqual(result.completed, 2);
    assert.strictEqual(result.total, 2);
    assert.strictEqual(result.percentage, 100);
  });

  it('should handle none completed', () => {
    const items = [
      { id: 'OOB-01', checked: false },
      { id: 'IB-01', checked: false }
    ];

    const result = countChecklistProgress(items);

    assert.strictEqual(result.completed, 0);
    assert.strictEqual(result.percentage, 0);
  });

  it('should handle empty array', () => {
    const result = countChecklistProgress([]);

    assert.deepStrictEqual(result, {
      completed: 0,
      total: 0,
      percentage: 0
    });
  });

  it('should round percentage to nearest integer', () => {
    const items = [
      { checked: true },
      { checked: false },
      { checked: false }
    ];

    const result = countChecklistProgress(items);

    assert.strictEqual(result.percentage, 33); // 33.33... → 33
  });
});

describe('Checklist Parsing - orderTestCases', () => {
  it('should order cases per OOB-01 → IB-01 → OOB-02 rule', () => {
    const testCases = ['IB-01', 'IB-02', 'OOB-01', 'OOB-02', 'OOB-03'];

    const result = orderTestCases(testCases);

    assert.strictEqual(result[0], 'OOB-01');
    assert.strictEqual(result[1], 'IB-01');
    assert.strictEqual(result[2], 'OOB-02');
  });

  it('should append remaining OOBs then IBs ascending', () => {
    const testCases = ['IB-01', 'IB-02', 'IB-03', 'OOB-01', 'OOB-02', 'OOB-03', 'OOB-04'];

    const result = orderTestCases(testCases);

    // After OOB-01, IB-01, OOB-02: should have OOB-03, OOB-04, IB-02, IB-03
    assert.deepStrictEqual(result.slice(3), ['OOB-03', 'OOB-04', 'IB-02', 'IB-03']);
  });

  it('should handle minimum requirements (1 IB, 2 OOB)', () => {
    const testCases = ['IB-01', 'OOB-01', 'OOB-02'];

    const result = orderTestCases(testCases);

    assert.deepStrictEqual(result, ['OOB-01', 'IB-01', 'OOB-02']);
  });

  it('should fallback to OOBs then IBs when missing required cases', () => {
    const testCases = ['IB-01', 'OOB-01'];

    const result = orderTestCases(testCases);

    // Not enough OOBs - fallback ordering
    assert.deepStrictEqual(result, ['OOB-01', 'IB-01']);
  });

  it('should sort by numeric value, not string', () => {
    const testCases = ['OOB-10', 'OOB-02', 'IB-05', 'IB-01', 'OOB-01'];

    const result = orderTestCases(testCases);

    // After first 3: OOB-10, IB-05
    assert.ok(result.indexOf('OOB-10') > result.indexOf('OOB-02'));
    assert.ok(result.indexOf('IB-05') > result.indexOf('IB-01'));
  });

  it('should handle empty array', () => {
    const result = orderTestCases([]);

    assert.deepStrictEqual(result, []);
  });
});

describe('Checklist Parsing - buildRunChecklist', () => {
  it('should build markdown checklist from ordered cases', () => {
    const orderedCases = ['OOB-01', 'IB-01', 'OOB-02'];

    const result = buildRunChecklist(orderedCases);

    assert.ok(result.includes('### Run checklist'));
    assert.ok(result.includes('- [ ] OOB-01'));
    assert.ok(result.includes('- [ ] IB-01'));
    assert.ok(result.includes('- [ ] OOB-02'));
  });

  it('should create unchecked checkboxes by default', () => {
    const orderedCases = ['OOB-01'];

    const result = buildRunChecklist(orderedCases);

    assert.ok(result.includes('- [ ]'));
    assert.ok(!result.includes('- [x]'));
  });

  it('should include heading and newlines', () => {
    const orderedCases = ['OOB-01', 'IB-01'];

    const result = buildRunChecklist(orderedCases);

    assert.ok(result.startsWith('### Run checklist\n'));
    assert.ok(result.includes('\n- [ ] OOB-01\n'));
  });

  it('should handle empty array', () => {
    const result = buildRunChecklist([]);

    assert.strictEqual(result, '### Run checklist\n');
  });

  it('should preserve test case order', () => {
    const orderedCases = ['OOB-03', 'IB-02', 'OOB-01'];

    const result = buildRunChecklist(orderedCases);

    const oob03Pos = result.indexOf('OOB-03');
    const ib02Pos = result.indexOf('IB-02');
    const oob01Pos = result.indexOf('OOB-01');

    assert.ok(oob03Pos < ib02Pos);
    assert.ok(ib02Pos < oob01Pos);
  });
});

describe('Checklist Parsing - updateChecklistItem', () => {
  it('should check an unchecked item', () => {
    const body = `### Run checklist
- [ ] OOB-01
- [ ] IB-01`;

    const result = updateChecklistItem(body, 'OOB-01', true);

    assert.ok(result.includes('- [x] OOB-01'));
    assert.ok(result.includes('- [ ] IB-01')); // Other item unchanged
  });

  it('should uncheck a checked item', () => {
    const body = `### Run checklist
- [x] OOB-01
- [ ] IB-01`;

    const result = updateChecklistItem(body, 'OOB-01', false);

    assert.ok(result.includes('- [ ] OOB-01'));
  });

  it('should handle item with description', () => {
    const body = `### Run checklist
- [ ] OOB-01: Test description`;

    const result = updateChecklistItem(body, 'OOB-01', true);

    assert.ok(result.includes('- [x] OOB-01: Test description'));
  });

  it('should only update matching test case ID', () => {
    const body = `### Run checklist
- [ ] OOB-01
- [ ] OOB-10`;

    const result = updateChecklistItem(body, 'OOB-01', true);

    assert.ok(result.includes('- [x] OOB-01'));
    assert.ok(result.includes('- [ ] OOB-10')); // Not updated
  });

  it('should return unchanged body if ID not found', () => {
    const body = `### Run checklist
- [ ] OOB-01`;

    const result = updateChecklistItem(body, 'IB-01', true);

    assert.strictEqual(result, body);
  });

  it('should handle uppercase X in checkbox', () => {
    const body = `### Run checklist
- [X] OOB-01`;

    const result = updateChecklistItem(body, 'OOB-01', false);

    assert.ok(result.includes('- [ ] OOB-01'));
  });
});

describe('Checklist Parsing - extractCompletedTestCases', () => {
  it('should extract IDs of checked items', () => {
    const body = `### Run checklist
- [x] OOB-01
- [ ] IB-01
- [x] OOB-02`;

    const result = extractCompletedTestCases(body);

    assert.deepStrictEqual(result, ['OOB-01', 'OOB-02']);
  });

  it('should return empty array when nothing checked', () => {
    const body = `### Run checklist
- [ ] OOB-01
- [ ] IB-01`;

    const result = extractCompletedTestCases(body);

    assert.deepStrictEqual(result, []);
  });

  it('should handle uppercase X', () => {
    const body = `### Run checklist
- [X] OOB-01`;

    const result = extractCompletedTestCases(body);

    assert.deepStrictEqual(result, ['OOB-01']);
  });

  it('should return empty array when no checklist', () => {
    const body = `No checklist here`;

    const result = extractCompletedTestCases(body);

    assert.deepStrictEqual(result, []);
  });

  it('should extract only test case ID, not description', () => {
    const body = `### Run checklist
- [x] OOB-01: Some description here`;

    const result = extractCompletedTestCases(body);

    assert.deepStrictEqual(result, ['OOB-01']);
  });
});

describe('Checklist Parsing - validateChecklistFormat', () => {
  it('should validate proper checklist format', () => {
    const body = `### Run checklist
- [ ] OOB-01
- [ ] IB-01`;

    const result = validateChecklistFormat(body);

    assert.strictEqual(result.valid, true);
    assert.deepStrictEqual(result.errors, []);
  });

  it('should detect missing heading', () => {
    const body = `- [ ] OOB-01
- [ ] IB-01`;

    const result = validateChecklistFormat(body);

    assert.strictEqual(result.valid, false);
    assert.ok(result.errors.some(e => e.includes('heading')));
  });

  it('should detect empty checklist', () => {
    const body = `### Run checklist
`;

    const result = validateChecklistFormat(body);

    assert.strictEqual(result.valid, false);
    assert.ok(result.errors.some(e => e.includes('empty')));
  });

  it('should detect invalid test case IDs', () => {
    const body = `### Run checklist
- [ ] INVALID-01
- [ ] IB-01`;

    const result = validateChecklistFormat(body);

    assert.strictEqual(result.valid, false);
    assert.ok(result.errors.some(e => e.includes('INVALID-01')));
  });

  it('should detect duplicate test cases', () => {
    const body = `### Run checklist
- [ ] OOB-01
- [ ] OOB-01`;

    const result = validateChecklistFormat(body);

    assert.strictEqual(result.valid, false);
    assert.ok(result.errors.some(e => e.includes('duplicate')));
  });

  it('should validate when no checklist present', () => {
    const body = `No checklist`;

    const result = validateChecklistFormat(body);

    // No checklist is valid (it's optional)
    assert.strictEqual(result.valid, true);
  });
});

describe('Checklist Parsing - Integration Tests', () => {
  it('should parse, order, and build checklist from test cases', () => {
    // Given: Test case IDs
    const testCases = ['IB-01', 'IB-02', 'OOB-01', 'OOB-02', 'OOB-03'];

    // When: Order and build checklist
    const ordered = orderTestCases(testCases);
    const checklist = buildRunChecklist(ordered);

    // Then: Should have proper order
    assert.ok(checklist.indexOf('OOB-01') < checklist.indexOf('IB-01'));
    assert.ok(checklist.indexOf('IB-01') < checklist.indexOf('OOB-02'));

    // And: Should be unchecked by default
    assert.ok(checklist.includes('- [ ] OOB-01'));
  });

  it('should parse existing checklist and track progress', () => {
    // Given: Issue body with checklist
    const body = `### Run checklist
- [x] OOB-01
- [x] IB-01
- [ ] OOB-02`;

    // When: Parse and count progress
    const items = parseRunChecklist(body);
    const progress = countChecklistProgress(items);

    // Then: Should show 2/3 complete
    assert.strictEqual(progress.completed, 2);
    assert.strictEqual(progress.total, 3);
    assert.strictEqual(progress.percentage, 67);

    // And: Should extract completed IDs
    const completed = extractCompletedTestCases(body);
    assert.deepStrictEqual(completed, ['OOB-01', 'IB-01']);
  });

  it('should update checklist items after test execution', () => {
    // Given: Initial checklist
    let body = `### Run checklist
- [ ] OOB-01
- [ ] IB-01
- [ ] OOB-02`;

    // When: Mark OOB-01 complete
    body = updateChecklistItem(body, 'OOB-01', true);

    // And: Mark IB-01 complete
    body = updateChecklistItem(body, 'IB-01', true);

    // Then: Should have 2 checked
    const completed = extractCompletedTestCases(body);
    assert.deepStrictEqual(completed, ['OOB-01', 'IB-01']);

    // And: Progress should be 67%
    const items = parseRunChecklist(body);
    const progress = countChecklistProgress(items);
    assert.strictEqual(progress.percentage, 67);
  });
});
