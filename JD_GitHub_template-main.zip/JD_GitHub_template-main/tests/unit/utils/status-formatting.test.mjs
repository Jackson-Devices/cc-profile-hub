/**
 * Unit Tests for Status Message Formatting Functions
 * TDD-First: These tests are written BEFORE implementation
 *
 * Tests status message creation, error formatting, and summary generation
 * Expected to FAIL initially (RED phase)
 */

import { describe, it } from 'node:test';
import assert from 'node:assert';
import {
  formatSuccess,
  formatError,
  formatWarning,
  formatInfo,
  formatSummary,
  formatErrorList,
  formatValidationResults,
  formatProgress,
  formatCheckmark,
  formatBulletList,
  formatCodeBlock,
  formatBadge,
  escapeMarkdown
} from '../../../.github/scripts/utils/status-formatting.mjs';

describe('Status Formatting - formatSuccess', () => {
  it('should format success message with checkmark', () => {
    const result = formatSuccess('Operation completed');

    assert.ok(result.includes('✅'));
    assert.ok(result.includes('Operation completed'));
  });

  it('should handle multi-line messages', () => {
    const result = formatSuccess('First line\nSecond line');

    assert.ok(result.includes('First line'));
    assert.ok(result.includes('Second line'));
  });

  it('should handle empty message', () => {
    const result = formatSuccess('');

    assert.ok(result.includes('✅'));
  });
});

describe('Status Formatting - formatError', () => {
  it('should format error message with cross mark', () => {
    const result = formatError('Operation failed');

    assert.ok(result.includes('❌'));
    assert.ok(result.includes('Operation failed'));
  });

  it('should handle error objects', () => {
    const error = new Error('Something went wrong');
    const result = formatError('Failed', error);

    assert.ok(result.includes('❌'));
    assert.ok(result.includes('Failed'));
    assert.ok(result.includes('Something went wrong'));
  });

  it('should handle null error', () => {
    const result = formatError('Failed', null);

    assert.ok(result.includes('❌'));
    assert.ok(result.includes('Failed'));
  });
});

describe('Status Formatting - formatWarning', () => {
  it('should format warning message with warning sign', () => {
    const result = formatWarning('Potential issue detected');

    assert.ok(result.includes('⚠️'));
    assert.ok(result.includes('Potential issue detected'));
  });

  it('should handle warnings with details', () => {
    const result = formatWarning('Warning', 'Additional context here');

    assert.ok(result.includes('⚠️'));
    assert.ok(result.includes('Warning'));
    assert.ok(result.includes('Additional context here'));
  });
});

describe('Status Formatting - formatInfo', () => {
  it('should format info message with info icon', () => {
    const result = formatInfo('For your information');

    assert.ok(result.includes('ℹ️'));
    assert.ok(result.includes('For your information'));
  });

  it('should handle info with code blocks', () => {
    const result = formatInfo('Current value', 'value: 42');

    assert.ok(result.includes('ℹ️'));
    assert.ok(result.includes('value: 42'));
  });
});

describe('Status Formatting - formatSummary', () => {
  it('should format summary with title and sections', () => {
    const sections = {
      'Tests': '10 passed',
      'Coverage': '95%'
    };

    const result = formatSummary('Test Results', sections);

    assert.ok(result.includes('Test Results'));
    assert.ok(result.includes('Tests'));
    assert.ok(result.includes('10 passed'));
    assert.ok(result.includes('Coverage'));
    assert.ok(result.includes('95%'));
  });

  it('should handle empty sections', () => {
    const result = formatSummary('Empty Summary', {});

    assert.ok(result.includes('Empty Summary'));
  });

  it('should format sections as bullet points', () => {
    const sections = {
      'Item 1': 'Value 1',
      'Item 2': 'Value 2'
    };

    const result = formatSummary('Summary', sections);

    // Should have bullet formatting
    assert.ok(result.includes('-') || result.includes('*'));
  });
});

describe('Status Formatting - formatErrorList', () => {
  it('should format array of errors', () => {
    const errors = [
      'Error 1: Something failed',
      'Error 2: Another issue',
      'Error 3: Third problem'
    ];

    const result = formatErrorList(errors);

    assert.ok(result.includes('Error 1'));
    assert.ok(result.includes('Error 2'));
    assert.ok(result.includes('Error 3'));
  });

  it('should number errors', () => {
    const errors = ['First', 'Second', 'Third'];

    const result = formatErrorList(errors);

    // Should have numbering like "1." or "1)"
    assert.ok(/[1-3][.)]/.test(result));
  });

  it('should handle empty error list', () => {
    const result = formatErrorList([]);

    assert.ok(result.length > 0); // Should return something (e.g., "No errors")
  });

  it('should handle single error', () => {
    const result = formatErrorList(['Single error']);

    assert.ok(result.includes('Single error'));
  });
});

describe('Status Formatting - formatValidationResults', () => {
  it('should format validation with passed and failed checks', () => {
    const passed = ['Check 1', 'Check 2'];
    const failed = ['Check 3', 'Check 4'];

    const result = formatValidationResults(passed, failed);

    assert.ok(result.includes('Check 1'));
    assert.ok(result.includes('Check 2'));
    assert.ok(result.includes('Check 3'));
    assert.ok(result.includes('Check 4'));
    assert.ok(result.includes('✅') || result.includes('Passed'));
    assert.ok(result.includes('❌') || result.includes('Failed'));
  });

  it('should show summary counts', () => {
    const passed = ['A', 'B'];
    const failed = ['C'];

    const result = formatValidationResults(passed, failed);

    // Should show counts like "2 passed, 1 failed"
    assert.ok(result.includes('2') || result.includes('3'));
  });

  it('should handle all passed', () => {
    const passed = ['Check 1', 'Check 2'];
    const failed = [];

    const result = formatValidationResults(passed, failed);

    assert.ok(result.includes('✅'));
    assert.ok(!result.includes('❌') || result.includes('0 failed'));
  });

  it('should handle all failed', () => {
    const passed = [];
    const failed = ['Check 1', 'Check 2'];

    const result = formatValidationResults(passed, failed);

    assert.ok(result.includes('❌'));
  });
});

describe('Status Formatting - formatProgress', () => {
  it('should format progress with percentage', () => {
    const result = formatProgress(7, 10);

    assert.ok(result.includes('7'));
    assert.ok(result.includes('10'));
    assert.ok(result.includes('70') || result.includes('%'));
  });

  it('should handle 100% completion', () => {
    const result = formatProgress(10, 10);

    assert.ok(result.includes('100'));
    assert.ok(result.includes('✅') || result.includes('complete'));
  });

  it('should handle 0% completion', () => {
    const result = formatProgress(0, 10);

    assert.ok(result.includes('0'));
  });

  it('should handle division by zero', () => {
    const result = formatProgress(0, 0);

    // Should not throw, should return something sensible
    assert.ok(typeof result === 'string');
    assert.ok(result.length > 0);
  });

  it('should show progress bar', () => {
    const result = formatProgress(5, 10);

    // Should have some visual progress indicator
    assert.ok(result.includes('█') || result.includes('▓') || result.includes('[') || result.includes('●'));
  });
});

describe('Status Formatting - formatCheckmark', () => {
  it('should return checkmark for true', () => {
    const result = formatCheckmark(true);

    assert.strictEqual(result, '✅');
  });

  it('should return cross for false', () => {
    const result = formatCheckmark(false);

    assert.strictEqual(result, '❌');
  });

  it('should handle custom symbols', () => {
    const result = formatCheckmark(true, '✓', '✗');

    assert.strictEqual(result, '✓');
  });

  it('should handle custom symbols for false', () => {
    const result = formatCheckmark(false, '✓', '✗');

    assert.strictEqual(result, '✗');
  });
});

describe('Status Formatting - formatBulletList', () => {
  it('should format array as bullet list', () => {
    const items = ['Item 1', 'Item 2', 'Item 3'];

    const result = formatBulletList(items);

    assert.ok(result.includes('Item 1'));
    assert.ok(result.includes('Item 2'));
    assert.ok(result.includes('Item 3'));
    assert.ok(result.includes('-') || result.includes('*') || result.includes('•'));
  });

  it('should handle empty array', () => {
    const result = formatBulletList([]);

    assert.strictEqual(result, '');
  });

  it('should handle single item', () => {
    const result = formatBulletList(['Only one']);

    assert.ok(result.includes('Only one'));
  });

  it('should indent nested lists', () => {
    const items = [
      'Parent 1',
      ['Child 1.1', 'Child 1.2'],
      'Parent 2'
    ];

    const result = formatBulletList(items);

    // Should have indentation for nested items
    assert.ok(result.includes('  ') || result.includes('\t'));
  });
});

describe('Status Formatting - formatCodeBlock', () => {
  it('should wrap code in markdown code block', () => {
    const result = formatCodeBlock('console.log("hello")');

    assert.ok(result.includes('```'));
    assert.ok(result.includes('console.log("hello")'));
  });

  it('should support language specification', () => {
    const result = formatCodeBlock('const x = 5;', 'javascript');

    assert.ok(result.includes('```javascript'));
    assert.ok(result.includes('const x = 5;'));
  });

  it('should handle multi-line code', () => {
    const code = `function test() {
  return true;
}`;

    const result = formatCodeBlock(code);

    assert.ok(result.includes('function test'));
    assert.ok(result.includes('return true'));
  });

  it('should handle empty code', () => {
    const result = formatCodeBlock('');

    assert.ok(result.includes('```'));
  });
});

describe('Status Formatting - formatBadge', () => {
  it('should format badge with label and value', () => {
    const result = formatBadge('Status', 'Passing');

    assert.ok(result.includes('Status'));
    assert.ok(result.includes('Passing'));
  });

  it('should format badge with color', () => {
    const result = formatBadge('Build', 'Success', 'green');

    assert.ok(result.includes('Build'));
    assert.ok(result.includes('Success'));
    assert.ok(result.includes('green'));
  });

  it('should handle shields.io format', () => {
    const result = formatBadge('Coverage', '95%', 'brightgreen');

    // Should be a valid shields.io URL or markdown badge
    assert.ok(result.includes('Coverage') || result.includes('shields.io'));
  });
});

describe('Status Formatting - escapeMarkdown', () => {
  it('should escape special markdown characters', () => {
    const result = escapeMarkdown('Text with *asterisks* and _underscores_');

    assert.ok(result.includes('\\*') || !result.includes('*'));
    assert.ok(result.includes('\\_') || !result.includes('_'));
  });

  it('should escape brackets and parentheses', () => {
    const result = escapeMarkdown('[link](url)');

    assert.ok(result.includes('\\[') || result.includes('\\('));
  });

  it('should handle already escaped text', () => {
    const result = escapeMarkdown('Already \\* escaped');

    // Should not double-escape
    assert.ok(!result.includes('\\\\\\*'));
  });

  it('should handle empty string', () => {
    const result = escapeMarkdown('');

    assert.strictEqual(result, '');
  });

  it('should handle text without special characters', () => {
    const result = escapeMarkdown('Plain text');

    assert.strictEqual(result, 'Plain text');
  });
});

describe('Status Formatting - Integration Tests', () => {
  it('should format complete validation report', () => {
    // Given: Validation results
    const passed = ['IB/OOB format valid', 'YAML valid'];
    const failed = ['Missing required field'];

    // When: Format validation results
    const result = formatValidationResults(passed, failed);

    // Then: Should include both sections
    assert.ok(result.includes('IB/OOB format valid'));
    assert.ok(result.includes('Missing required field'));
  });

  it('should format error summary with details', () => {
    // Given: Multiple errors
    const errors = [
      'Line 10: Invalid format',
      'Line 25: Missing semicolon',
      'Line 40: Undefined variable'
    ];

    // When: Format error list
    const errorList = formatErrorList(errors);
    const errorMsg = formatError('Validation failed', { message: errorList });

    // Then: Should have complete error report
    assert.ok(errorMsg.includes('❌'));
    assert.ok(errorMsg.includes('Line 10'));
    assert.ok(errorMsg.includes('Line 25'));
    assert.ok(errorMsg.includes('Line 40'));
  });

  it('should create formatted summary with progress', () => {
    // Given: Progress data
    const progress = formatProgress(7, 10);
    const summary = formatSummary('Test Execution', {
      'Progress': progress,
      'Status': 'Running',
      'Failures': '0'
    });

    // Then: Should have complete summary
    assert.ok(summary.includes('Test Execution'));
    assert.ok(summary.includes('70') || summary.includes('7'));
    assert.ok(summary.includes('Running'));
  });
});
