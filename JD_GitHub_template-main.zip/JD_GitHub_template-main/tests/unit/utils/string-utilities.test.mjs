/**
 * Unit Tests for String Utility Functions
 * TDD-First: These tests are written BEFORE implementation
 *
 * Tests URL parsing, markdown extraction, text manipulation
 * Expected to FAIL initially (RED phase)
 */

import { describe, it } from 'node:test';
import assert from 'node:assert';
import {
  parseGitHubURL,
  extractMarkdownSection,
  truncateText,
  countLines,
  sanitizeFilename,
  normalizeWhitespace,
  removeMarkdownFormatting,
  extractUrls,
  isValidUrl,
  joinPaths,
  getFileExtension,
  removeFileExtension,
  toKebabCase,
  toCamelCase,
  capitalize
} from '../../../.github/scripts/utils/string-utilities.mjs';

describe('String Utilities - parseGitHubURL', () => {
  it('should parse issue URL', () => {
    const url = 'https://github.com/owner/repo/issues/123';
    const result = parseGitHubURL(url);

    assert.deepStrictEqual(result, {
      owner: 'owner',
      repo: 'repo',
      type: 'issue',
      number: 123,
      valid: true
    });
  });

  it('should parse pull request URL', () => {
    const url = 'https://github.com/owner/repo/pull/456';
    const result = parseGitHubURL(url);

    assert.strictEqual(result.type, 'pull');
    assert.strictEqual(result.number, 456);
  });

  it('should parse repository URL', () => {
    const url = 'https://github.com/owner/repo';
    const result = parseGitHubURL(url);

    assert.strictEqual(result.type, 'repo');
    assert.strictEqual(result.owner, 'owner');
    assert.strictEqual(result.repo, 'repo');
  });

  it('should return invalid for non-GitHub URL', () => {
    const url = 'https://example.com/test';
    const result = parseGitHubURL(url);

    assert.strictEqual(result.valid, false);
  });

  it('should handle URLs with trailing slash', () => {
    const url = 'https://github.com/owner/repo/issues/123/';
    const result = parseGitHubURL(url);

    assert.strictEqual(result.number, 123);
    assert.strictEqual(result.valid, true);
  });
});

describe('String Utilities - extractMarkdownSection', () => {
  it('should extract section by heading', () => {
    const markdown = `# Title
Some content

## Section 1
Section 1 content

## Section 2
Section 2 content`;

    const result = extractMarkdownSection(markdown, 'Section 1');

    assert.ok(result.includes('Section 1 content'));
    assert.ok(!result.includes('Section 2 content'));
  });

  it('should handle section with nested headings', () => {
    const markdown = `## Parent
Parent content

### Child
Child content

## Next Section`;

    const result = extractMarkdownSection(markdown, 'Parent');

    assert.ok(result.includes('Parent content'));
    assert.ok(result.includes('Child content'));
  });

  it('should return null for non-existent section', () => {
    const markdown = '## Section 1\nContent';
    const result = extractMarkdownSection(markdown, 'Section 2');

    assert.strictEqual(result, null);
  });

  it('should handle section at end of document', () => {
    const markdown = `## Section 1
Content 1

## Section 2
Content 2`;

    const result = extractMarkdownSection(markdown, 'Section 2');

    assert.ok(result.includes('Content 2'));
  });
});

describe('String Utilities - truncateText', () => {
  it('should truncate long text', () => {
    const text = 'This is a very long text that needs to be truncated';
    const result = truncateText(text, 20);

    assert.ok(result.length <= 23); // 20 + '...'
    assert.ok(result.endsWith('...'));
  });

  it('should not truncate short text', () => {
    const text = 'Short';
    const result = truncateText(text, 20);

    assert.strictEqual(result, 'Short');
  });

  it('should handle custom suffix', () => {
    const text = 'Long text here';
    const result = truncateText(text, 8, '…');

    assert.ok(result.endsWith('…'));
  });

  it('should handle zero length', () => {
    const text = 'Text';
    const result = truncateText(text, 0);

    assert.strictEqual(result, '...');
  });
});

describe('String Utilities - countLines', () => {
  it('should count lines in text', () => {
    const text = 'Line 1\nLine 2\nLine 3';
    const result = countLines(text);

    assert.strictEqual(result, 3);
  });

  it('should count single line', () => {
    const text = 'Single line';
    const result = countLines(text);

    assert.strictEqual(result, 1);
  });

  it('should handle empty string', () => {
    const result = countLines('');

    assert.strictEqual(result, 0);
  });

  it('should handle different line endings', () => {
    const text = 'Line 1\r\nLine 2\rLine 3\n';
    const result = countLines(text);

    assert.ok(result >= 3);
  });
});

describe('String Utilities - sanitizeFilename', () => {
  it('should remove invalid characters', () => {
    const filename = 'file<name>:with?invalid*chars';
    const result = sanitizeFilename(filename);

    assert.ok(!result.includes('<'));
    assert.ok(!result.includes('>'));
    assert.ok(!result.includes(':'));
    assert.ok(!result.includes('?'));
    assert.ok(!result.includes('*'));
  });

  it('should replace spaces with underscores', () => {
    const filename = 'file name with spaces';
    const result = sanitizeFilename(filename);

    assert.ok(result.includes('_'));
    assert.ok(!result.includes(' '));
  });

  it('should handle already valid filename', () => {
    const filename = 'valid_filename.txt';
    const result = sanitizeFilename(filename);

    assert.strictEqual(result, 'valid_filename.txt');
  });

  it('should handle empty string', () => {
    const result = sanitizeFilename('');

    assert.ok(result.length > 0); // Should return something like 'file'
  });
});

describe('String Utilities - normalizeWhitespace', () => {
  it('should collapse multiple spaces', () => {
    const text = 'Text  with    multiple   spaces';
    const result = normalizeWhitespace(text);

    assert.strictEqual(result, 'Text with multiple spaces');
  });

  it('should trim leading/trailing whitespace', () => {
    const text = '  Text with spaces  ';
    const result = normalizeWhitespace(text);

    assert.strictEqual(result, 'Text with spaces');
  });

  it('should handle tabs and newlines', () => {
    const text = 'Text\t\twith\n\ntabs\nand\nnewlines';
    const result = normalizeWhitespace(text);

    assert.ok(!result.includes('\t\t'));
    assert.ok(!result.includes('\n\n'));
  });
});

describe('String Utilities - removeMarkdownFormatting', () => {
  it('should remove bold formatting', () => {
    const text = 'This is **bold** text';
    const result = removeMarkdownFormatting(text);

    assert.strictEqual(result, 'This is bold text');
  });

  it('should remove italic formatting', () => {
    const text = 'This is *italic* text';
    const result = removeMarkdownFormatting(text);

    assert.strictEqual(result, 'This is italic text');
  });

  it('should remove links', () => {
    const text = 'Click [here](https://example.com)';
    const result = removeMarkdownFormatting(text);

    assert.ok(result.includes('here'));
    assert.ok(!result.includes('['));
    assert.ok(!result.includes(']('));
  });

  it('should remove code blocks', () => {
    const text = 'Code: `inline code` here';
    const result = removeMarkdownFormatting(text);

    assert.ok(!result.includes('`'));
  });

  it('should remove headings', () => {
    const text = '## Heading\nContent';
    const result = removeMarkdownFormatting(text);

    assert.ok(!result.includes('##'));
  });
});

describe('String Utilities - extractUrls', () => {
  it('should extract URLs from text', () => {
    const text = 'Visit https://example.com and http://test.org';
    const result = extractUrls(text);

    assert.strictEqual(result.length, 2);
    assert.ok(result.includes('https://example.com'));
    assert.ok(result.includes('http://test.org'));
  });

  it('should handle text with no URLs', () => {
    const text = 'No URLs here';
    const result = extractUrls(text);

    assert.deepStrictEqual(result, []);
  });

  it('should extract GitHub URLs', () => {
    const text = 'See https://github.com/owner/repo/issues/123';
    const result = extractUrls(text);

    assert.strictEqual(result.length, 1);
    assert.strictEqual(result[0], 'https://github.com/owner/repo/issues/123');
  });
});

describe('String Utilities - isValidUrl', () => {
  it('should validate HTTP URL', () => {
    assert.strictEqual(isValidUrl('http://example.com'), true);
  });

  it('should validate HTTPS URL', () => {
    assert.strictEqual(isValidUrl('https://example.com'), true);
  });

  it('should reject invalid URL', () => {
    assert.strictEqual(isValidUrl('not a url'), false);
  });

  it('should reject empty string', () => {
    assert.strictEqual(isValidUrl(''), false);
  });

  it('should handle URL with path', () => {
    assert.strictEqual(isValidUrl('https://example.com/path/to/resource'), true);
  });
});

describe('String Utilities - joinPaths', () => {
  it('should join path segments', () => {
    const result = joinPaths('path', 'to', 'file.txt');

    assert.strictEqual(result, 'path/to/file.txt');
  });

  it('should handle leading slashes', () => {
    const result = joinPaths('/root', 'sub', 'file.txt');

    assert.ok(result.startsWith('/'));
    assert.strictEqual(result, '/root/sub/file.txt');
  });

  it('should handle trailing slashes', () => {
    const result = joinPaths('path/', 'to/', 'file.txt');

    assert.strictEqual(result, 'path/to/file.txt');
  });

  it('should handle empty segments', () => {
    const result = joinPaths('path', '', 'file.txt');

    assert.strictEqual(result, 'path/file.txt');
  });

  it('should handle single segment', () => {
    const result = joinPaths('file.txt');

    assert.strictEqual(result, 'file.txt');
  });
});

describe('String Utilities - getFileExtension', () => {
  it('should get extension from filename', () => {
    const result = getFileExtension('file.txt');

    assert.strictEqual(result, '.txt');
  });

  it('should handle multiple dots', () => {
    const result = getFileExtension('file.test.js');

    assert.strictEqual(result, '.js');
  });

  it('should handle no extension', () => {
    const result = getFileExtension('README');

    assert.strictEqual(result, '');
  });

  it('should handle path with extension', () => {
    const result = getFileExtension('/path/to/file.mjs');

    assert.strictEqual(result, '.mjs');
  });

  it('should handle hidden files', () => {
    const result = getFileExtension('.gitignore');

    assert.strictEqual(result, '');
  });
});

describe('String Utilities - removeFileExtension', () => {
  it('should remove extension', () => {
    const result = removeFileExtension('file.txt');

    assert.strictEqual(result, 'file');
  });

  it('should handle multiple dots', () => {
    const result = removeFileExtension('file.test.js');

    assert.strictEqual(result, 'file.test');
  });

  it('should handle no extension', () => {
    const result = removeFileExtension('README');

    assert.strictEqual(result, 'README');
  });

  it('should handle full path', () => {
    const result = removeFileExtension('/path/to/file.mjs');

    assert.strictEqual(result, '/path/to/file');
  });
});

describe('String Utilities - toKebabCase', () => {
  it('should convert to kebab-case', () => {
    const result = toKebabCase('HelloWorld');

    assert.strictEqual(result, 'hello-world');
  });

  it('should handle spaces', () => {
    const result = toKebabCase('Hello World Test');

    assert.strictEqual(result, 'hello-world-test');
  });

  it('should handle underscores', () => {
    const result = toKebabCase('hello_world_test');

    assert.strictEqual(result, 'hello-world-test');
  });

  it('should handle already kebab-case', () => {
    const result = toKebabCase('already-kebab-case');

    assert.strictEqual(result, 'already-kebab-case');
  });
});

describe('String Utilities - toCamelCase', () => {
  it('should convert to camelCase', () => {
    const result = toCamelCase('hello-world');

    assert.strictEqual(result, 'helloWorld');
  });

  it('should handle spaces', () => {
    const result = toCamelCase('hello world test');

    assert.strictEqual(result, 'helloWorldTest');
  });

  it('should handle underscores', () => {
    const result = toCamelCase('hello_world_test');

    assert.strictEqual(result, 'helloWorldTest');
  });

  it('should handle already camelCase', () => {
    const result = toCamelCase('alreadyCamelCase');

    assert.strictEqual(result, 'alreadyCamelCase');
  });
});

describe('String Utilities - capitalize', () => {
  it('should capitalize first letter', () => {
    const result = capitalize('hello');

    assert.strictEqual(result, 'Hello');
  });

  it('should handle already capitalized', () => {
    const result = capitalize('Hello');

    assert.strictEqual(result, 'Hello');
  });

  it('should handle empty string', () => {
    const result = capitalize('');

    assert.strictEqual(result, '');
  });

  it('should only capitalize first letter', () => {
    const result = capitalize('hello world');

    assert.strictEqual(result, 'Hello world');
  });
});

describe('String Utilities - Integration Tests', () => {
  it('should parse and validate GitHub issue URL', () => {
    // Given: A GitHub issue URL in text
    const text = 'See issue at https://github.com/owner/repo/issues/123';

    // When: Extract URLs and parse
    const urls = extractUrls(text);
    const parsed = parseGitHubURL(urls[0]);

    // Then: Should parse correctly
    assert.strictEqual(parsed.type, 'issue');
    assert.strictEqual(parsed.number, 123);
    assert.strictEqual(parsed.valid, true);
  });

  it('should extract and clean markdown section', () => {
    // Given: Markdown with formatted section
    const markdown = `## **Test Cases**
- Case 1: *Description*
- Case 2: [Link](url)

## Next Section`;

    // When: Extract section and remove formatting
    const section = extractMarkdownSection(markdown, 'Test Cases');
    const cleaned = removeMarkdownFormatting(section);

    // Then: Should have clean text
    assert.ok(cleaned.includes('Case 1'));
    assert.ok(cleaned.includes('Description'));
    assert.ok(!cleaned.includes('*'));
    assert.ok(!cleaned.includes('['));
  });

  it('should sanitize and join file paths', () => {
    // Given: User input for filename
    const userInput = 'My Test File?.txt';

    // When: Sanitize and create path
    const sanitized = sanitizeFilename(userInput);
    const path = joinPaths('output', 'tests', sanitized);

    // Then: Should have valid path
    assert.ok(!path.includes('?'));
    assert.ok(path.includes('output/tests/'));
  });
});
