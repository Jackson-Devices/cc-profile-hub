/**
 * Unit Tests for Parent Issue Fetching Functions
 * TDD-First: These tests are written BEFORE implementation
 *
 * Tests parent issue URL parsing, validation, and relationship checking
 * Expected to FAIL initially (RED phase)
 */

import { describe, it } from 'node:test';
import assert from 'node:assert';
import {
  parseParentIssueURL,
  validateParentIssueURL,
  extractParentIssueURL,
  validateParentChildRelationship,
  isValidGitHubIssueURL,
  formatParentIssueURL
} from '../../../.github/scripts/utils/parent-issue.mjs';

describe('Parent Issue - parseParentIssueURL', () => {
  it('should parse valid GitHub issue URL', () => {
    const url = 'https://github.com/owner/repo/issues/123';
    const result = parseParentIssueURL(url);

    assert.deepStrictEqual(result, {
      owner: 'owner',
      repo: 'repo',
      issue_number: 123,
      valid: true
    });
  });

  it('should parse GitHub issue URL with trailing slash', () => {
    const url = 'https://github.com/owner/repo/issues/456/';
    const result = parseParentIssueURL(url);

    assert.strictEqual(result.issue_number, 456);
    assert.strictEqual(result.valid, true);
  });

  it('should handle URL with query parameters', () => {
    const url = 'https://github.com/owner/repo/issues/789?ref=main';
    const result = parseParentIssueURL(url);

    assert.strictEqual(result.issue_number, 789);
    assert.strictEqual(result.valid, true);
  });

  it('should return invalid for non-GitHub URL', () => {
    const url = 'https://gitlab.com/owner/repo/issues/123';
    const result = parseParentIssueURL(url);

    assert.strictEqual(result.valid, false);
  });

  it('should return invalid for GitHub URL without issue number', () => {
    const url = 'https://github.com/owner/repo/issues';
    const result = parseParentIssueURL(url);

    assert.strictEqual(result.valid, false);
  });

  it('should return invalid for malformed issue number', () => {
    const url = 'https://github.com/owner/repo/issues/abc';
    const result = parseParentIssueURL(url);

    assert.strictEqual(result.valid, false);
  });

  it('should return invalid for empty string', () => {
    const result = parseParentIssueURL('');
    assert.strictEqual(result.valid, false);
  });

  it('should return invalid for non-string input', () => {
    const result = parseParentIssueURL(null);
    assert.strictEqual(result.valid, false);
  });

  it('should handle GitHub enterprise URLs', () => {
    const url = 'https://github.company.com/owner/repo/issues/123';
    const result = parseParentIssueURL(url);

    // Default implementation should handle github.com only
    // Enterprise support can be added later
    assert.strictEqual(result.valid, false);
  });

  it('should parse URL with hyphenated owner and repo names', () => {
    const url = 'https://github.com/my-org/my-repo/issues/999';
    const result = parseParentIssueURL(url);

    assert.strictEqual(result.owner, 'my-org');
    assert.strictEqual(result.repo, 'my-repo');
    assert.strictEqual(result.issue_number, 999);
    assert.strictEqual(result.valid, true);
  });
});

describe('Parent Issue - validateParentIssueURL', () => {
  it('should return true for valid GitHub issue URL', () => {
    const url = 'https://github.com/owner/repo/issues/123';
    assert.strictEqual(validateParentIssueURL(url), true);
  });

  it('should return false for invalid URL', () => {
    const url = 'not a url';
    assert.strictEqual(validateParentIssueURL(url), false);
  });

  it('should return false for non-GitHub URL', () => {
    const url = 'https://example.com/issues/123';
    assert.strictEqual(validateParentIssueURL(url), false);
  });

  it('should return false for GitHub URL without issue number', () => {
    const url = 'https://github.com/owner/repo';
    assert.strictEqual(validateParentIssueURL(url), false);
  });

  it('should return false for pull request URL', () => {
    const url = 'https://github.com/owner/repo/pull/123';
    assert.strictEqual(validateParentIssueURL(url), false);
  });
});

describe('Parent Issue - extractParentIssueURL', () => {
  it('should extract parent_issue URL from YAML frontmatter', () => {
    const issueBody = `---
ai_pass_count: 0
parent_issue: https://github.com/owner/repo/issues/1
max_ai_passes: 5
---

## Description
Child issue content`;

    const result = extractParentIssueURL(issueBody);
    assert.strictEqual(result, 'https://github.com/owner/repo/issues/1');
  });

  it('should return null when no parent_issue field present', () => {
    const issueBody = `---
ai_pass_count: 0
max_ai_passes: 5
---

Content`;

    const result = extractParentIssueURL(issueBody);
    assert.strictEqual(result, null);
  });

  it('should return null when no YAML frontmatter present', () => {
    const issueBody = 'Just regular content';
    const result = extractParentIssueURL(issueBody);
    assert.strictEqual(result, null);
  });

  it('should handle parent_issue with whitespace', () => {
    const issueBody = `---
parent_issue:  https://github.com/owner/repo/issues/999
---
Content`;

    const result = extractParentIssueURL(issueBody);
    assert.strictEqual(result, 'https://github.com/owner/repo/issues/999');
  });

  it('should return null for invalid parent_issue URL format', () => {
    const issueBody = `---
parent_issue: not a url
---
Content`;

    const result = extractParentIssueURL(issueBody);
    // extractParentIssueURL returns the value as-is, validation happens separately
    assert.strictEqual(result, 'not a url');
  });

  it('should handle empty parent_issue field', () => {
    const issueBody = `---
parent_issue:
---
Content`;

    const result = extractParentIssueURL(issueBody);
    assert.strictEqual(result, null);
  });
});

describe('Parent Issue - validateParentChildRelationship', () => {
  it('should pass when child pass count is below parent max', () => {
    const parentYAML = {
      max_ai_passes: 5,
      ai_pass_count: 2
    };

    const childYAML = {
      ai_pass_count: 0,
      parent_issue: 'https://github.com/owner/repo/issues/1'
    };

    const result = validateParentChildRelationship(parentYAML, childYAML);
    assert.strictEqual(result.valid, true);
    assert.deepStrictEqual(result.errors, []);
  });

  it('should fail when parent has reached max passes', () => {
    const parentYAML = {
      max_ai_passes: 5,
      ai_pass_count: 5
    };

    const childYAML = {
      ai_pass_count: 0,
      parent_issue: 'https://github.com/owner/repo/issues/1'
    };

    const result = validateParentChildRelationship(parentYAML, childYAML);
    assert.strictEqual(result.valid, false);
    assert.ok(result.errors.some(e => e.includes('max_ai_passes')));
  });

  it('should fail when parent is missing max_ai_passes', () => {
    const parentYAML = {
      ai_pass_count: 2
      // Missing max_ai_passes
    };

    const childYAML = {
      ai_pass_count: 0,
      parent_issue: 'https://github.com/owner/repo/issues/1'
    };

    const result = validateParentChildRelationship(parentYAML, childYAML);
    assert.strictEqual(result.valid, false);
    assert.ok(result.errors.some(e => e.includes('max_ai_passes')));
  });

  it('should calculate total child passes correctly', () => {
    const parentYAML = {
      max_ai_passes: 10,
      ai_pass_count: 3
    };

    const childYAML = {
      ai_pass_count: 2,
      parent_issue: 'https://github.com/owner/repo/issues/1'
    };

    const result = validateParentChildRelationship(parentYAML, childYAML);
    // Total passes = parent 3 + child 2 = 5, which is < 10
    assert.strictEqual(result.valid, true);
    assert.strictEqual(result.total_passes, 5);
  });

  it('should fail when combined passes exceed parent max', () => {
    const parentYAML = {
      max_ai_passes: 5,
      ai_pass_count: 3
    };

    const childYAML = {
      ai_pass_count: 3,
      parent_issue: 'https://github.com/owner/repo/issues/1'
    };

    const result = validateParentChildRelationship(parentYAML, childYAML);
    // Total passes = 3 + 3 = 6, which exceeds 5
    assert.strictEqual(result.valid, false);
    assert.ok(result.errors.some(e => e.includes('exceeds')));
  });

  it('should handle parent with no ai_pass_count (defaults to 0)', () => {
    const parentYAML = {
      max_ai_passes: 5
      // Missing ai_pass_count
    };

    const childYAML = {
      ai_pass_count: 2,
      parent_issue: 'https://github.com/owner/repo/issues/1'
    };

    const result = validateParentChildRelationship(parentYAML, childYAML);
    assert.strictEqual(result.valid, true);
    assert.strictEqual(result.total_passes, 2); // 0 + 2
  });

  it('should handle child with no ai_pass_count (defaults to 0)', () => {
    const parentYAML = {
      max_ai_passes: 5,
      ai_pass_count: 2
    };

    const childYAML = {
      parent_issue: 'https://github.com/owner/repo/issues/1'
      // Missing ai_pass_count
    };

    const result = validateParentChildRelationship(parentYAML, childYAML);
    assert.strictEqual(result.valid, true);
    assert.strictEqual(result.total_passes, 2); // 2 + 0
  });
});

describe('Parent Issue - isValidGitHubIssueURL', () => {
  it('should return true for valid GitHub issue URL', () => {
    const url = 'https://github.com/owner/repo/issues/123';
    assert.strictEqual(isValidGitHubIssueURL(url), true);
  });

  it('should return true for http GitHub URL (will be upgraded to https)', () => {
    const url = 'http://github.com/owner/repo/issues/123';
    assert.strictEqual(isValidGitHubIssueURL(url), true);
  });

  it('should return false for non-URL string', () => {
    assert.strictEqual(isValidGitHubIssueURL('not a url'), false);
  });

  it('should return false for null', () => {
    assert.strictEqual(isValidGitHubIssueURL(null), false);
  });

  it('should return false for undefined', () => {
    assert.strictEqual(isValidGitHubIssueURL(undefined), false);
  });

  it('should return false for number', () => {
    assert.strictEqual(isValidGitHubIssueURL(123), false);
  });

  it('should return false for pull request URL', () => {
    const url = 'https://github.com/owner/repo/pull/123';
    assert.strictEqual(isValidGitHubIssueURL(url), false);
  });
});

describe('Parent Issue - formatParentIssueURL', () => {
  it('should format parent issue URL from components', () => {
    const result = formatParentIssueURL('owner', 'repo', 123);
    assert.strictEqual(result, 'https://github.com/owner/repo/issues/123');
  });

  it('should handle numeric strings', () => {
    const result = formatParentIssueURL('owner', 'repo', '456');
    assert.strictEqual(result, 'https://github.com/owner/repo/issues/456');
  });

  it('should throw error for invalid issue number', () => {
    assert.throws(() => formatParentIssueURL('owner', 'repo', 'abc'), {
      message: /Invalid issue number/i
    });
  });

  it('should throw error for missing owner', () => {
    assert.throws(() => formatParentIssueURL('', 'repo', 123), {
      message: /owner.*required/i
    });
  });

  it('should throw error for missing repo', () => {
    assert.throws(() => formatParentIssueURL('owner', '', 123), {
      message: /repo.*required/i
    });
  });

  it('should throw error for negative issue number', () => {
    assert.throws(() => formatParentIssueURL('owner', 'repo', -1), {
      message: /Invalid issue number/i
    });
  });

  it('should throw error for zero issue number', () => {
    assert.throws(() => formatParentIssueURL('owner', 'repo', 0), {
      message: /Invalid issue number/i
    });
  });
});

describe('Parent Issue - Integration Tests', () => {
  it('should extract and validate parent issue URL from child issue', () => {
    // Given: A child issue with parent_issue in YAML
    const childIssueBody = `---
ai_pass_count: 1
parent_issue: https://github.com/org/repo/issues/100
max_ai_passes: 3
---

## Child Issue
This is a child issue`;

    // When: Extract parent URL
    const parentURL = extractParentIssueURL(childIssueBody);

    // Then: Should be valid
    assert.strictEqual(parentURL, 'https://github.com/org/repo/issues/100');
    assert.strictEqual(validateParentIssueURL(parentURL), true);

    // And: Should parse correctly
    const parsed = parseParentIssueURL(parentURL);
    assert.strictEqual(parsed.owner, 'org');
    assert.strictEqual(parsed.repo, 'repo');
    assert.strictEqual(parsed.issue_number, 100);
  });

  it('should validate parent-child relationship for max passes', () => {
    // Given: Parent issue with max_ai_passes
    const parentIssueBody = `---
ai_pass_count: 2
max_ai_passes: 5
---

## Parent Issue`;

    // And: Child issue with parent reference
    const childIssueBody = `---
ai_pass_count: 2
parent_issue: https://github.com/org/repo/issues/1
---

## Child Issue`;

    // When: Extract YAML from both
    const parentYAML = {
      ai_pass_count: 2,
      max_ai_passes: 5
    };

    const childYAML = {
      ai_pass_count: 2,
      parent_issue: 'https://github.com/org/repo/issues/1'
    };

    // And: Validate relationship
    const validation = validateParentChildRelationship(parentYAML, childYAML);

    // Then: Should be valid (2 + 2 = 4 < 5)
    assert.strictEqual(validation.valid, true);
    assert.strictEqual(validation.total_passes, 4);
  });

  it('should detect when parent-child would exceed max passes', () => {
    // Given: Parent close to max
    const parentYAML = {
      ai_pass_count: 4,
      max_ai_passes: 5
    };

    // And: Child with additional passes
    const childYAML = {
      ai_pass_count: 2,
      parent_issue: 'https://github.com/org/repo/issues/1'
    };

    // When: Validate relationship
    const validation = validateParentChildRelationship(parentYAML, childYAML);

    // Then: Should fail (4 + 2 = 6 > 5)
    assert.strictEqual(validation.valid, false);
    assert.ok(validation.errors.length > 0);
  });

  it('should handle workflow of creating formatted parent URL', () => {
    // Given: Repository information
    const owner = 'my-org';
    const repo = 'my-repo';
    const issueNumber = 42;

    // When: Format parent URL
    const formattedURL = formatParentIssueURL(owner, repo, issueNumber);

    // Then: Should be valid GitHub issue URL
    assert.strictEqual(formattedURL, 'https://github.com/my-org/my-repo/issues/42');
    assert.strictEqual(isValidGitHubIssueURL(formattedURL), true);

    // And: Should parse back to original components
    const parsed = parseParentIssueURL(formattedURL);
    assert.strictEqual(parsed.owner, owner);
    assert.strictEqual(parsed.repo, repo);
    assert.strictEqual(parsed.issue_number, issueNumber);
  });
});
