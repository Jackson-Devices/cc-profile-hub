/**
 * Unit Tests for YAML Parsing Functions
 * TDD-First: These tests are written BEFORE implementation
 *
 * Tests YAML frontmatter operations for GitHub issue bodies
 * Expected to FAIL initially (RED phase)
 */

import { describe, it } from 'node:test';
import assert from 'node:assert';
import {
  extractYAMLFromIssue,
  validateYAMLSchema,
  updateYAMLInIssue,
  hasYAMLFrontmatter,
  parseYAML,
  stringifyYAML
} from '../../../.github/scripts/utils/yaml-parser.mjs';

describe('YAML Parsing - extractYAMLFromIssue', () => {
  it('should extract YAML frontmatter from issue body', () => {
    const issueBody = `---
ai_pass_count: 3
max_ai_passes: 5
parent_issue: https://github.com/org/repo/issues/1
---

## Description
Issue body content here`;

    const result = extractYAMLFromIssue(issueBody);

    assert.deepStrictEqual(result, {
      ai_pass_count: 3,
      max_ai_passes: 5,
      parent_issue: 'https://github.com/org/repo/issues/1'
    });
  });

  it('should return empty object when no YAML present', () => {
    const issueBody = 'No YAML frontmatter here';
    const result = extractYAMLFromIssue(issueBody);
    assert.deepStrictEqual(result, {});
  });

  it('should handle YAML with arrays', () => {
    const issueBody = `---
labels:
  - bug
  - urgent
tags: [test, validation]
---
Content`;

    const result = extractYAMLFromIssue(issueBody);
    assert.deepStrictEqual(result.labels, ['bug', 'urgent']);
    assert.deepStrictEqual(result.tags, ['test', 'validation']);
  });

  it('should handle YAML with nested objects', () => {
    const issueBody = `---
metadata:
  author: alice
  created: 2025-01-01
  status:
    state: open
    priority: 1
---
Content`;

    const result = extractYAMLFromIssue(issueBody);
    assert.strictEqual(result.metadata.author, 'alice');
    assert.strictEqual(result.metadata.status.state, 'open');
    assert.strictEqual(result.metadata.status.priority, 1);
  });

  it('should throw error for malformed YAML', () => {
    const issueBody = `---
invalid: yaml: here: too: many: colons
---
Content`;

    assert.throws(() => extractYAMLFromIssue(issueBody), {
      message: /Invalid YAML|bad indentation/i
    });
  });

  it('should handle YAML with special characters', () => {
    const issueBody = `---
description: "Contains: colons and, commas"
url: "https://example.com/path?query=value"
code: |
  function test() {
    return true;
  }
---
Content`;

    const result = extractYAMLFromIssue(issueBody);
    assert.ok(result.description.includes('colons'));
    assert.ok(result.url.includes('query=value'));
    assert.ok(result.code.includes('function test'));
  });

  it('should handle empty YAML section', () => {
    const issueBody = `---
---
Content`;

    const result = extractYAMLFromIssue(issueBody);
    assert.deepStrictEqual(result, {});
  });

  it('should preserve content after YAML', () => {
    const issueBody = `---
field: value
---

## Content
This should not be included in YAML parsing`;

    const result = extractYAMLFromIssue(issueBody);
    assert.deepStrictEqual(result, { field: 'value' });
  });

  it('should handle YAML with boolean and null values', () => {
    const issueBody = `---
enabled: true
disabled: false
empty: null
missing:
---
Content`;

    const result = extractYAMLFromIssue(issueBody);
    assert.strictEqual(result.enabled, true);
    assert.strictEqual(result.disabled, false);
    assert.strictEqual(result.empty, null);
    assert.strictEqual(result.missing, null);
  });
});

describe('YAML Parsing - validateYAMLSchema', () => {
  it('should validate required fields are present', () => {
    const yaml = {
      ai_pass_count: 0,
      max_ai_passes: 5
    };

    const schema = {
      required: ['ai_pass_count', 'max_ai_passes']
    };

    const result = validateYAMLSchema(yaml, schema);
    assert.strictEqual(result.valid, true);
    assert.deepStrictEqual(result.errors, []);
  });

  it('should fail when required field is missing', () => {
    const yaml = {
      ai_pass_count: 0
    };

    const schema = {
      required: ['ai_pass_count', 'max_ai_passes']
    };

    const result = validateYAMLSchema(yaml, schema);
    assert.strictEqual(result.valid, false);
    assert.ok(result.errors.some(e => e.includes('max_ai_passes')));
  });

  it('should validate field types', () => {
    const yaml = {
      ai_pass_count: 'not a number',
      max_ai_passes: 5
    };

    const schema = {
      required: ['ai_pass_count', 'max_ai_passes'],
      types: {
        ai_pass_count: 'number',
        max_ai_passes: 'number'
      }
    };

    const result = validateYAMLSchema(yaml, schema);
    assert.strictEqual(result.valid, false);
    assert.ok(result.errors.some(e => e.includes('ai_pass_count') && e.includes('number')));
  });

  it('should validate allowed values', () => {
    const yaml = {
      status: 'invalid_status'
    };

    const schema = {
      required: ['status'],
      allowed: {
        status: ['open', 'closed', 'pending']
      }
    };

    const result = validateYAMLSchema(yaml, schema);
    assert.strictEqual(result.valid, false);
    assert.ok(result.errors.some(e => e.includes('status')));
  });

  it('should pass when value is in allowed list', () => {
    const yaml = {
      status: 'open'
    };

    const schema = {
      required: ['status'],
      allowed: {
        status: ['open', 'closed', 'pending']
      }
    };

    const result = validateYAMLSchema(yaml, schema);
    assert.strictEqual(result.valid, true);
  });

  it('should validate URL format', () => {
    const yaml = {
      parent_issue: 'not a url'
    };

    const schema = {
      required: ['parent_issue'],
      formats: {
        parent_issue: 'url'
      }
    };

    const result = validateYAMLSchema(yaml, schema);
    assert.strictEqual(result.valid, false);
    assert.ok(result.errors.some(e => e.includes('parent_issue') && e.includes('URL')));
  });

  it('should accept valid URL', () => {
    const yaml = {
      parent_issue: 'https://github.com/org/repo/issues/123'
    };

    const schema = {
      required: ['parent_issue'],
      formats: {
        parent_issue: 'url'
      }
    };

    const result = validateYAMLSchema(yaml, schema);
    assert.strictEqual(result.valid, true);
  });

  it('should handle optional fields', () => {
    const yaml = {
      required_field: 'value'
    };

    const schema = {
      required: ['required_field'],
      optional: ['optional_field']
    };

    const result = validateYAMLSchema(yaml, schema);
    assert.strictEqual(result.valid, true);
  });
});

describe('YAML Parsing - updateYAMLInIssue', () => {
  it('should update existing YAML field', () => {
    const issueBody = `---
ai_pass_count: 3
max_ai_passes: 5
---

Content`;

    const updates = { ai_pass_count: 4 };
    const result = updateYAMLInIssue(issueBody, updates);

    assert.ok(result.includes('ai_pass_count: 4'));
    assert.ok(result.includes('max_ai_passes: 5'));
    assert.ok(result.includes('Content'));
  });

  it('should add new YAML field', () => {
    const issueBody = `---
ai_pass_count: 3
---

Content`;

    const updates = { max_ai_passes: 5 };
    const result = updateYAMLInIssue(issueBody, updates);

    assert.ok(result.includes('ai_pass_count: 3'));
    assert.ok(result.includes('max_ai_passes: 5'));
  });

  it('should create YAML section if missing', () => {
    const issueBody = 'Content without YAML';

    const updates = { ai_pass_count: 0 };
    const result = updateYAMLInIssue(issueBody, updates);

    assert.ok(result.startsWith('---\n'));
    assert.ok(result.includes('ai_pass_count: 0'));
    assert.ok(result.includes('Content without YAML'));
  });

  it('should preserve content after YAML', () => {
    const issueBody = `---
field: old
---

## Important Content
Do not lose this!`;

    const updates = { field: 'new' };
    const result = updateYAMLInIssue(issueBody, updates);

    assert.ok(result.includes('field: new'));
    assert.ok(result.includes('## Important Content'));
    assert.ok(result.includes('Do not lose this!'));
  });

  it('should handle multiple field updates', () => {
    const issueBody = `---
field1: old1
field2: old2
field3: old3
---

Content`;

    const updates = {
      field1: 'new1',
      field2: 'new2',
      field4: 'new4'
    };

    const result = updateYAMLInIssue(issueBody, updates);

    assert.ok(result.includes('field1: new1'));
    assert.ok(result.includes('field2: new2'));
    assert.ok(result.includes('field3: old3')); // Unchanged
    assert.ok(result.includes('field4: new4')); // New field
  });

  it('should handle special characters in values', () => {
    const issueBody = `---
url: old
---
Content`;

    const updates = {
      url: 'https://example.com/path?query=value&key=val'
    };

    const result = updateYAMLInIssue(issueBody, updates);
    // js-yaml may quote or not quote based on content - just verify URL is present
    assert.ok(result.includes('https://example.com/path?query=value&key=val'));
  });

  it('should preserve YAML formatting', () => {
    const issueBody = `---
simple: value
nested:
  key: value
list:
  - item1
  - item2
---
Content`;

    const updates = { simple: 'updated' };
    const result = updateYAMLInIssue(issueBody, updates);

    // Should preserve nested and list formatting
    assert.ok(result.includes('simple: updated'));
    assert.ok(result.includes('nested:') || result.includes('nested'));
    assert.ok(result.includes('list:') || result.includes('list'));
  });
});

describe('YAML Parsing - hasYAMLFrontmatter', () => {
  it('should return true when YAML frontmatter exists', () => {
    const issueBody = `---
field: value
---
Content`;

    assert.strictEqual(hasYAMLFrontmatter(issueBody), true);
  });

  it('should return false when no YAML frontmatter', () => {
    const issueBody = 'Just content, no YAML';
    assert.strictEqual(hasYAMLFrontmatter(issueBody), false);
  });

  it('should return false for incomplete YAML markers', () => {
    const issueBody = `---
field: value
Content without closing marker`;

    assert.strictEqual(hasYAMLFrontmatter(issueBody), false);
  });

  it('should handle empty YAML section', () => {
    const issueBody = `---
---
Content`;

    // Empty YAML section is technically valid but returns empty object
    const result = extractYAMLFromIssue(issueBody);
    assert.deepStrictEqual(result, {});
  });

  it('should handle YAML not at start of document', () => {
    const issueBody = `Some content first

---
field: value
---

More content`;

    // Should return false because YAML must be at start
    assert.strictEqual(hasYAMLFrontmatter(issueBody), false);
  });
});

describe('YAML Parsing - parseYAML', () => {
  it('should parse valid YAML string', () => {
    const yaml = `
ai_pass_count: 3
max_ai_passes: 5
enabled: true
`;

    const result = parseYAML(yaml);
    assert.strictEqual(result.ai_pass_count, 3);
    assert.strictEqual(result.max_ai_passes, 5);
    assert.strictEqual(result.enabled, true);
  });

  it('should throw error for invalid YAML', () => {
    const yaml = 'invalid: yaml: syntax:';
    assert.throws(() => parseYAML(yaml), {
      message: /Invalid YAML|bad indentation/i
    });
  });

  it('should handle empty string', () => {
    const result = parseYAML('');
    assert.deepStrictEqual(result, {});
  });
});

describe('YAML Parsing - stringifyYAML', () => {
  it('should convert object to YAML string', () => {
    const obj = {
      ai_pass_count: 3,
      max_ai_passes: 5
    };

    const result = stringifyYAML(obj);
    assert.ok(result.includes('ai_pass_count: 3'));
    assert.ok(result.includes('max_ai_passes: 5'));
  });

  it('should handle nested objects', () => {
    const obj = {
      metadata: {
        author: 'alice',
        status: 'open'
      }
    };

    const result = stringifyYAML(obj);
    assert.ok(result.includes('metadata:'));
    assert.ok(result.includes('author: alice'));
    assert.ok(result.includes('status: open'));
  });

  it('should handle arrays', () => {
    const obj = {
      tags: ['test', 'validation']
    };

    const result = stringifyYAML(obj);
    assert.ok(result.includes('tags:'));
    assert.ok(result.includes('test'));
    assert.ok(result.includes('validation'));
  });

  it('should handle empty object', () => {
    const result = stringifyYAML({});
    assert.strictEqual(result.trim(), '{}');
  });
});

describe('YAML Parsing - Integration Tests', () => {
  it('should extract, modify, and update YAML in workflow', () => {
    // Given: An issue with YAML frontmatter
    const originalBody = `---
ai_pass_count: 0
max_ai_passes: 5
status: pending
---

## Test Cases
IB-01: Test case`;

    // When: Extract YAML
    const yaml = extractYAMLFromIssue(originalBody);
    assert.strictEqual(yaml.ai_pass_count, 0);

    // And: Validate schema
    const schema = {
      required: ['ai_pass_count', 'max_ai_passes'],
      types: {
        ai_pass_count: 'number',
        max_ai_passes: 'number'
      }
    };
    const validation = validateYAMLSchema(yaml, schema);
    assert.strictEqual(validation.valid, true);

    // And: Increment pass count
    const updates = { ai_pass_count: yaml.ai_pass_count + 1 };

    // And: Update issue body
    const updatedBody = updateYAMLInIssue(originalBody, updates);

    // Then: YAML should be updated
    const newYaml = extractYAMLFromIssue(updatedBody);
    assert.strictEqual(newYaml.ai_pass_count, 1);
    assert.strictEqual(newYaml.max_ai_passes, 5);

    // And: Content should be preserved
    assert.ok(updatedBody.includes('## Test Cases'));
    assert.ok(updatedBody.includes('IB-01: Test case'));
  });

  it('should handle max pass enforcement workflow', () => {
    const issueBody = `---
ai_pass_count: 4
max_ai_passes: 5
---
Content`;

    const yaml = extractYAMLFromIssue(issueBody);

    // Check if at max passes
    const atMaxPasses = yaml.ai_pass_count >= yaml.max_ai_passes - 1;
    assert.strictEqual(atMaxPasses, true);

    // Should escalate to human
    const updates = {
      ai_pass_count: yaml.ai_pass_count + 1,
      needs_human: true
    };

    const updatedBody = updateYAMLInIssue(issueBody, updates);
    const newYaml = extractYAMLFromIssue(updatedBody);

    assert.strictEqual(newYaml.ai_pass_count, 5);
    assert.strictEqual(newYaml.needs_human, true);
  });
});
