/**
 * Unit Tests for Label Operations Functions
 * TDD-First: These tests are written BEFORE implementation
 *
 * Tests label manipulation, validation, and calculation functions
 * Expected to FAIL initially (RED phase)
 */

import { describe, it } from 'node:test';
import assert from 'node:assert';
import {
  calculateLabelChanges,
  validateLabelName,
  hasLabel,
  addLabels,
  removeLabels,
  toggleLabel,
  normalizeLabelName,
  getLabelsByPrefix,
  validateLabelArray
} from '../../../.github/scripts/utils/label-operations.mjs';

describe('Label Operations - calculateLabelChanges', () => {
  it('should add new labels while keeping existing ones', () => {
    const currentLabels = ['bug', 'priority: high'];
    const labelsToAdd = ['needs-review'];
    const labelsToRemove = [];

    const result = calculateLabelChanges(currentLabels, labelsToAdd, labelsToRemove);

    assert.deepStrictEqual(result, ['bug', 'priority: high', 'needs-review']);
  });

  it('should remove labels from current list', () => {
    const currentLabels = ['bug', 'priority: high', 'needs-review'];
    const labelsToAdd = [];
    const labelsToRemove = ['needs-review'];

    const result = calculateLabelChanges(currentLabels, labelsToAdd, labelsToRemove);

    assert.deepStrictEqual(result, ['bug', 'priority: high']);
  });

  it('should add and remove labels in single operation', () => {
    const currentLabels = ['Validation: Pending', 'bug'];
    const labelsToAdd = ['Validation: Passed'];
    const labelsToRemove = ['Validation: Pending'];

    const result = calculateLabelChanges(currentLabels, labelsToAdd, labelsToRemove);

    assert.deepStrictEqual(result, ['bug', 'Validation: Passed']);
  });

  it('should not add duplicate labels', () => {
    const currentLabels = ['bug', 'priority: high'];
    const labelsToAdd = ['bug', 'needs-review'];
    const labelsToRemove = [];

    const result = calculateLabelChanges(currentLabels, labelsToAdd, labelsToRemove);

    assert.deepStrictEqual(result, ['bug', 'priority: high', 'needs-review']);
  });

  it('should handle empty current labels', () => {
    const currentLabels = [];
    const labelsToAdd = ['bug', 'needs-review'];
    const labelsToRemove = [];

    const result = calculateLabelChanges(currentLabels, labelsToAdd, labelsToRemove);

    assert.deepStrictEqual(result, ['bug', 'needs-review']);
  });

  it('should handle removing non-existent labels gracefully', () => {
    const currentLabels = ['bug'];
    const labelsToAdd = [];
    const labelsToRemove = ['non-existent'];

    const result = calculateLabelChanges(currentLabels, labelsToAdd, labelsToRemove);

    assert.deepStrictEqual(result, ['bug']);
  });

  it('should preserve label order when only removing', () => {
    const currentLabels = ['a', 'b', 'c', 'd'];
    const labelsToAdd = [];
    const labelsToRemove = ['b', 'd'];

    const result = calculateLabelChanges(currentLabels, labelsToAdd, labelsToRemove);

    assert.deepStrictEqual(result, ['a', 'c']);
  });

  it('should handle removing then re-adding same label', () => {
    const currentLabels = ['bug', 'priority: high'];
    const labelsToAdd = ['bug'];
    const labelsToRemove = ['bug'];

    const result = calculateLabelChanges(currentLabels, labelsToAdd, labelsToRemove);

    // Remove first, then add - should end up with bug
    assert.ok(result.includes('bug'));
    assert.strictEqual(result.filter(l => l === 'bug').length, 1);
  });

  it('should handle case-sensitive label names', () => {
    const currentLabels = ['Bug'];
    const labelsToAdd = ['bug'];
    const labelsToRemove = [];

    const result = calculateLabelChanges(currentLabels, labelsToAdd, labelsToRemove);

    // Both 'Bug' and 'bug' should be present (case-sensitive)
    assert.ok(result.includes('Bug'));
    assert.ok(result.includes('bug'));
  });
});

describe('Label Operations - validateLabelName', () => {
  it('should return true for valid label name', () => {
    assert.strictEqual(validateLabelName('bug'), true);
  });

  it('should return true for label with colon', () => {
    assert.strictEqual(validateLabelName('priority: high'), true);
  });

  it('should return true for label with spaces', () => {
    assert.strictEqual(validateLabelName('needs review'), true);
  });

  it('should return true for label with hyphens', () => {
    assert.strictEqual(validateLabelName('needs-review'), true);
  });

  it('should return false for empty string', () => {
    assert.strictEqual(validateLabelName(''), false);
  });

  it('should return false for whitespace-only string', () => {
    assert.strictEqual(validateLabelName('   '), false);
  });

  it('should return false for non-string', () => {
    assert.strictEqual(validateLabelName(null), false);
    assert.strictEqual(validateLabelName(undefined), false);
    assert.strictEqual(validateLabelName(123), false);
  });

  it('should return false for label exceeding max length (50 chars)', () => {
    const longLabel = 'a'.repeat(51);
    assert.strictEqual(validateLabelName(longLabel), false);
  });

  it('should return true for label at max length (50 chars)', () => {
    const maxLabel = 'a'.repeat(50);
    assert.strictEqual(validateLabelName(maxLabel), true);
  });
});

describe('Label Operations - hasLabel', () => {
  it('should return true when label exists', () => {
    const labels = ['bug', 'priority: high'];
    assert.strictEqual(hasLabel(labels, 'bug'), true);
  });

  it('should return false when label does not exist', () => {
    const labels = ['bug', 'priority: high'];
    assert.strictEqual(hasLabel(labels, 'enhancement'), false);
  });

  it('should be case-sensitive', () => {
    const labels = ['Bug'];
    assert.strictEqual(hasLabel(labels, 'bug'), false);
    assert.strictEqual(hasLabel(labels, 'Bug'), true);
  });

  it('should handle empty label array', () => {
    assert.strictEqual(hasLabel([], 'bug'), false);
  });

  it('should handle labels with special characters', () => {
    const labels = ['status: in-progress'];
    assert.strictEqual(hasLabel(labels, 'status: in-progress'), true);
  });
});

describe('Label Operations - addLabels', () => {
  it('should add single label', () => {
    const currentLabels = ['bug'];
    const result = addLabels(currentLabels, ['enhancement']);

    assert.deepStrictEqual(result, ['bug', 'enhancement']);
  });

  it('should add multiple labels', () => {
    const currentLabels = ['bug'];
    const result = addLabels(currentLabels, ['enhancement', 'needs-review']);

    assert.deepStrictEqual(result, ['bug', 'enhancement', 'needs-review']);
  });

  it('should not add duplicate labels', () => {
    const currentLabels = ['bug'];
    const result = addLabels(currentLabels, ['bug', 'enhancement']);

    assert.deepStrictEqual(result, ['bug', 'enhancement']);
  });

  it('should not modify original array', () => {
    const currentLabels = ['bug'];
    const original = [...currentLabels];
    addLabels(currentLabels, ['enhancement']);

    assert.deepStrictEqual(currentLabels, original);
  });

  it('should handle empty labels to add', () => {
    const currentLabels = ['bug'];
    const result = addLabels(currentLabels, []);

    assert.deepStrictEqual(result, ['bug']);
  });

  it('should handle empty current labels', () => {
    const result = addLabels([], ['bug', 'enhancement']);

    assert.deepStrictEqual(result, ['bug', 'enhancement']);
  });
});

describe('Label Operations - removeLabels', () => {
  it('should remove single label', () => {
    const currentLabels = ['bug', 'enhancement'];
    const result = removeLabels(currentLabels, ['bug']);

    assert.deepStrictEqual(result, ['enhancement']);
  });

  it('should remove multiple labels', () => {
    const currentLabels = ['bug', 'enhancement', 'needs-review'];
    const result = removeLabels(currentLabels, ['bug', 'needs-review']);

    assert.deepStrictEqual(result, ['enhancement']);
  });

  it('should handle removing non-existent label', () => {
    const currentLabels = ['bug'];
    const result = removeLabels(currentLabels, ['enhancement']);

    assert.deepStrictEqual(result, ['bug']);
  });

  it('should not modify original array', () => {
    const currentLabels = ['bug', 'enhancement'];
    const original = [...currentLabels];
    removeLabels(currentLabels, ['bug']);

    assert.deepStrictEqual(currentLabels, original);
  });

  it('should handle empty labels to remove', () => {
    const currentLabels = ['bug', 'enhancement'];
    const result = removeLabels(currentLabels, []);

    assert.deepStrictEqual(result, ['bug', 'enhancement']);
  });

  it('should handle removing all labels', () => {
    const currentLabels = ['bug'];
    const result = removeLabels(currentLabels, ['bug']);

    assert.deepStrictEqual(result, []);
  });
});

describe('Label Operations - toggleLabel', () => {
  it('should add label when not present', () => {
    const currentLabels = ['bug'];
    const result = toggleLabel(currentLabels, 'enhancement');

    assert.deepStrictEqual(result, ['bug', 'enhancement']);
  });

  it('should remove label when present', () => {
    const currentLabels = ['bug', 'enhancement'];
    const result = toggleLabel(currentLabels, 'enhancement');

    assert.deepStrictEqual(result, ['bug']);
  });

  it('should not modify original array', () => {
    const currentLabels = ['bug'];
    const original = [...currentLabels];
    toggleLabel(currentLabels, 'enhancement');

    assert.deepStrictEqual(currentLabels, original);
  });

  it('should be case-sensitive', () => {
    const currentLabels = ['Bug'];
    const result = toggleLabel(currentLabels, 'bug');

    // 'bug' not present, should be added
    assert.deepStrictEqual(result, ['Bug', 'bug']);
  });
});

describe('Label Operations - normalizeLabelName', () => {
  it('should trim whitespace', () => {
    assert.strictEqual(normalizeLabelName('  bug  '), 'bug');
  });

  it('should preserve internal whitespace', () => {
    assert.strictEqual(normalizeLabelName('needs review'), 'needs review');
  });

  it('should preserve case', () => {
    assert.strictEqual(normalizeLabelName('Bug'), 'Bug');
  });

  it('should handle already normalized label', () => {
    assert.strictEqual(normalizeLabelName('bug'), 'bug');
  });

  it('should return empty string for whitespace-only input', () => {
    assert.strictEqual(normalizeLabelName('   '), '');
  });

  it('should handle labels with special characters', () => {
    assert.strictEqual(normalizeLabelName('  priority: high  '), 'priority: high');
  });
});

describe('Label Operations - getLabelsByPrefix', () => {
  it('should get labels matching prefix', () => {
    const labels = ['Validation: Passed', 'Validation: Pending', 'bug'];
    const result = getLabelsByPrefix(labels, 'Validation:');

    assert.deepStrictEqual(result, ['Validation: Passed', 'Validation: Pending']);
  });

  it('should return empty array when no matches', () => {
    const labels = ['bug', 'enhancement'];
    const result = getLabelsByPrefix(labels, 'Validation:');

    assert.deepStrictEqual(result, []);
  });

  it('should be case-sensitive', () => {
    const labels = ['Validation: Passed', 'validation: pending'];
    const result = getLabelsByPrefix(labels, 'Validation:');

    assert.deepStrictEqual(result, ['Validation: Passed']);
  });

  it('should handle empty label array', () => {
    const result = getLabelsByPrefix([], 'Validation:');

    assert.deepStrictEqual(result, []);
  });

  it('should match exact prefix only', () => {
    const labels = ['priority: high', 'prior: low', 'bug'];
    const result = getLabelsByPrefix(labels, 'priority:');

    assert.deepStrictEqual(result, ['priority: high']);
  });

  it('should handle prefix with spaces', () => {
    const labels = ['status: in progress', 'status: done', 'bug'];
    const result = getLabelsByPrefix(labels, 'status:');

    assert.deepStrictEqual(result, ['status: in progress', 'status: done']);
  });
});

describe('Label Operations - validateLabelArray', () => {
  it('should return valid for valid label array', () => {
    const labels = ['bug', 'priority: high', 'needs-review'];
    const result = validateLabelArray(labels);

    assert.strictEqual(result.valid, true);
    assert.deepStrictEqual(result.errors, []);
  });

  it('should detect empty label names', () => {
    const labels = ['bug', '', 'enhancement'];
    const result = validateLabelArray(labels);

    assert.strictEqual(result.valid, false);
    assert.ok(result.errors.some(e => e.includes('empty')));
  });

  it('should detect invalid label types', () => {
    const labels = ['bug', 123, 'enhancement'];
    const result = validateLabelArray(labels);

    assert.strictEqual(result.valid, false);
    assert.ok(result.errors.some(e => e.includes('string')));
  });

  it('should detect duplicate labels', () => {
    const labels = ['bug', 'enhancement', 'bug'];
    const result = validateLabelArray(labels);

    assert.strictEqual(result.valid, false);
    assert.ok(result.errors.some(e => e.includes('duplicate') && e.includes('bug')));
  });

  it('should detect labels exceeding max length', () => {
    const longLabel = 'a'.repeat(51);
    const labels = ['bug', longLabel];
    const result = validateLabelArray(labels);

    assert.strictEqual(result.valid, false);
    assert.ok(result.errors.some(e => e.includes('50 characters')));
  });

  it('should validate empty array', () => {
    const result = validateLabelArray([]);

    assert.strictEqual(result.valid, true);
    assert.deepStrictEqual(result.errors, []);
  });

  it('should detect multiple errors', () => {
    const labels = ['bug', '', 'bug', 'valid'];
    const result = validateLabelArray(labels);

    assert.strictEqual(result.valid, false);
    assert.ok(result.errors.length >= 2); // empty + duplicate
  });

  it('should handle labels with whitespace', () => {
    const labels = ['  bug  ', 'enhancement'];
    const result = validateLabelArray(labels);

    // Whitespace-padded labels should be flagged or normalized
    // For this test, we'll consider them invalid as written
    assert.strictEqual(result.valid, false);
    assert.ok(result.errors.some(e => e.includes('whitespace')));
  });
});

describe('Label Operations - Integration Tests', () => {
  it('should handle validation workflow label swap', () => {
    // Given: Current labels from a pending validation
    const currentLabels = ['Validation: Pending', 'bug', 'priority: high'];

    // When: Validation passes, swap Pending for Passed
    const result = calculateLabelChanges(
      currentLabels,
      ['Validation: Passed'],
      ['Validation: Pending']
    );

    // Then: Should have Passed, not Pending
    assert.ok(result.includes('Validation: Passed'));
    assert.ok(!result.includes('Validation: Pending'));
    assert.ok(result.includes('bug'));
    assert.ok(result.includes('priority: high'));
  });

  it('should handle removing all validation labels', () => {
    // Given: Multiple validation labels
    const currentLabels = [
      'Validation: Passed',
      'Validation: Pending',
      'Validation: Blocked',
      'bug'
    ];

    // When: Get all validation labels
    const validationLabels = getLabelsByPrefix(currentLabels, 'Validation:');

    // And: Remove them all
    const result = removeLabels(currentLabels, validationLabels);

    // Then: Only non-validation labels remain
    assert.deepStrictEqual(result, ['bug']);
  });

  it('should validate labels before applying changes', () => {
    // Given: Proposed label changes
    const labelsToAdd = ['bug', 'enhancement', ''];

    // When: Validate the labels
    const validation = validateLabelArray(labelsToAdd);

    // Then: Should detect empty label
    assert.strictEqual(validation.valid, false);

    // And: Should not proceed with invalid labels
    if (!validation.valid) {
      // Would throw error or return validation result
      assert.ok(validation.errors.length > 0);
    }
  });

  it('should handle complex label management workflow', () => {
    // Given: Initial issue labels
    let labels = ['bug', 'needs-triage'];

    // When: Triage happens
    labels = removeLabels(labels, ['needs-triage']);
    labels = addLabels(labels, ['priority: high', 'Validation: Pending']);

    // And: Validation completes
    labels = calculateLabelChanges(
      labels,
      ['Validation: Passed'],
      ['Validation: Pending']
    );

    // Then: Should have correct final state
    assert.ok(labels.includes('bug'));
    assert.ok(labels.includes('priority: high'));
    assert.ok(labels.includes('Validation: Passed'));
    assert.ok(!labels.includes('needs-triage'));
    assert.ok(!labels.includes('Validation: Pending'));
  });
});
