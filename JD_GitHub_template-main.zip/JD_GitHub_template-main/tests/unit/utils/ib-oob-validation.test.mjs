/**
 * Unit Tests for IB/OOB Validation Functions
 * TDD-First: These tests are written BEFORE implementation
 *
 * Expected to FAIL initially (RED phase)
 */

import { describe, it } from 'node:test';
import assert from 'node:assert';
import {
  validateIBFormat,
  validateOOBFormat,
  countIBCases,
  countOOBCases,
  checkMinimumRequirements,
  extractTestCases,
  parseTestCase
} from '../../../.github/scripts/utils/validators.mjs';

describe('IB/OOB Validation - validateIBFormat', () => {
  it('should return true for valid IB-01 format', () => {
    assert.strictEqual(validateIBFormat('IB-01: Valid test case'), true);
  });

  it('should return true for valid IB-99 format', () => {
    assert.strictEqual(validateIBFormat('IB-99: Edge case'), true);
  });

  it('should return false for single-digit IB-1 format', () => {
    assert.strictEqual(validateIBFormat('IB-1: Invalid'), false);
  });

  it('should return false for triple-digit IB-001 format', () => {
    assert.strictEqual(validateIBFormat('IB-001: Invalid'), false);
  });

  it('should return false for missing colon', () => {
    assert.strictEqual(validateIBFormat('IB-01 Missing colon'), false);
  });

  it('should return false for missing description', () => {
    assert.strictEqual(validateIBFormat('IB-01:'), false);
    assert.strictEqual(validateIBFormat('IB-01: '), false);
  });

  it('should return false for non-string input', () => {
    assert.strictEqual(validateIBFormat(null), false);
    assert.strictEqual(validateIBFormat(undefined), false);
    assert.strictEqual(validateIBFormat(123), false);
  });

  it('should handle whitespace variations', () => {
    assert.strictEqual(validateIBFormat('IB-01:  Test with spaces'), true);
    assert.strictEqual(validateIBFormat('  IB-01: Leading space'), false);
  });
});

describe('IB/OOB Validation - validateOOBFormat', () => {
  it('should return true for valid OOB-01 format', () => {
    assert.strictEqual(validateOOBFormat('OOB-01: Valid edge case'), true);
  });

  it('should return true for valid OOB-99 format', () => {
    assert.strictEqual(validateOOBFormat('OOB-99: Another edge case'), true);
  });

  it('should return false for single-digit OOB-1 format', () => {
    assert.strictEqual(validateOOBFormat('OOB-1: Invalid'), false);
  });

  it('should return false for triple-digit OOB-001 format', () => {
    assert.strictEqual(validateOOBFormat('OOB-001: Invalid'), false);
  });

  it('should return false for missing description', () => {
    assert.strictEqual(validateOOBFormat('OOB-01:'), false);
  });
});

describe('IB/OOB Validation - countIBCases', () => {
  it('should count single IB case', () => {
    const body = 'IB-01: Test case one';
    assert.strictEqual(countIBCases(body), 1);
  });

  it('should count multiple IB cases', () => {
    const body = `
      IB-01: Test case one
      IB-02: Test case two
      IB-03: Test case three
    `;
    assert.strictEqual(countIBCases(body), 3);
  });

  it('should not count invalid IB formats', () => {
    const body = `
      IB-01: Valid
      IB-1: Invalid (single digit)
      IB-001: Invalid (triple digit)
    `;
    assert.strictEqual(countIBCases(body), 1);
  });

  it('should return 0 for empty string', () => {
    assert.strictEqual(countIBCases(''), 0);
  });

  it('should return 0 when no IB cases present', () => {
    const body = 'Some text without IB cases';
    assert.strictEqual(countIBCases(body), 0);
  });

  it('should not double-count same IB number', () => {
    const body = `
      IB-01: First occurrence
      IB-01: Duplicate (should not be counted)
      IB-02: Second case
    `;
    // Should count unique IB numbers only
    assert.strictEqual(countIBCases(body), 2);
  });
});

describe('IB/OOB Validation - countOOBCases', () => {
  it('should count single OOB case', () => {
    const body = 'OOB-01: Edge case one';
    assert.strictEqual(countOOBCases(body), 1);
  });

  it('should count multiple OOB cases', () => {
    const body = `
      OOB-01: Edge case one
      OOB-02: Edge case two
      OOB-03: Edge case three
    `;
    assert.strictEqual(countOOBCases(body), 3);
  });

  it('should not count invalid OOB formats', () => {
    const body = `
      OOB-01: Valid
      OOB-1: Invalid
      OOB-001: Invalid
    `;
    assert.strictEqual(countOOBCases(body), 1);
  });

  it('should return 0 for empty string', () => {
    assert.strictEqual(countOOBCases(''), 0);
  });
});

describe('IB/OOB Validation - checkMinimumRequirements', () => {
  it('should pass with 1 IB and 1 OOB', () => {
    const result = checkMinimumRequirements(1, 1);
    assert.strictEqual(result.valid, true);
    assert.deepStrictEqual(result.errors, []);
  });

  it('should pass with more than minimum', () => {
    const result = checkMinimumRequirements(5, 3);
    assert.strictEqual(result.valid, true);
  });

  it('should fail with 0 IB cases', () => {
    const result = checkMinimumRequirements(0, 1);
    assert.strictEqual(result.valid, false);
    assert.ok(result.errors.some(e => e.includes('IB')));
  });

  it('should fail with 0 OOB cases', () => {
    const result = checkMinimumRequirements(1, 0);
    assert.strictEqual(result.valid, false);
    assert.ok(result.errors.some(e => e.includes('OOB')));
  });

  it('should fail with both 0', () => {
    const result = checkMinimumRequirements(0, 0);
    assert.strictEqual(result.valid, false);
    assert.strictEqual(result.errors.length, 2);
  });

  it('should include count information in errors', () => {
    const result = checkMinimumRequirements(0, 0);
    assert.ok(result.errors[0].includes('0'));
  });
});

describe('IB/OOB Validation - extractTestCases', () => {
  it('should extract IB and OOB cases', () => {
    const body = `
## Test Cases

IB-01: Valid input test
IB-02: Another valid test

OOB-01: Edge case test
OOB-02: Boundary test
    `;

    const result = extractTestCases(body);
    assert.strictEqual(result.ib.length, 2);
    assert.strictEqual(result.oob.length, 2);
  });

  it('should extract with full case details', () => {
    const body = 'IB-01: Test description here';
    const result = extractTestCases(body);

    assert.strictEqual(result.ib[0].id, 'IB-01');
    assert.strictEqual(result.ib[0].description, 'Test description here');
    assert.strictEqual(result.ib[0].fullText, 'IB-01: Test description here');
  });

  it('should return empty arrays when no cases found', () => {
    const body = 'No test cases here';
    const result = extractTestCases(body);

    assert.deepStrictEqual(result.ib, []);
    assert.deepStrictEqual(result.oob, []);
  });

  it('should extract cases in order', () => {
    const body = `
IB-03: Third
IB-01: First
IB-02: Second
    `;

    const result = extractTestCases(body);
    assert.strictEqual(result.ib[0].id, 'IB-03');
    assert.strictEqual(result.ib[1].id, 'IB-01');
    assert.strictEqual(result.ib[2].id, 'IB-02');
  });
});

describe('IB/OOB Validation - parseTestCase', () => {
  it('should parse IB case correctly', () => {
    const text = 'IB-05: Valid test case description';
    const result = parseTestCase(text);

    assert.strictEqual(result.type, 'IB');
    assert.strictEqual(result.number, '05');
    assert.strictEqual(result.id, 'IB-05');
    assert.strictEqual(result.description, 'Valid test case description');
    assert.strictEqual(result.fullText, text);
  });

  it('should parse OOB case correctly', () => {
    const text = 'OOB-10: Edge case description';
    const result = parseTestCase(text);

    assert.strictEqual(result.type, 'OOB');
    assert.strictEqual(result.number, '10');
    assert.strictEqual(result.id, 'OOB-10');
    assert.strictEqual(result.description, 'Edge case description');
  });

  it('should return null for invalid format', () => {
    assert.strictEqual(parseTestCase('Invalid format'), null);
    assert.strictEqual(parseTestCase('IB-1: Wrong'), null);
    assert.strictEqual(parseTestCase('IB-001: Wrong'), null);
  });

  it('should handle multiline descriptions', () => {
    const text = 'IB-01: First line\nSecond line';
    const result = parseTestCase(text);

    assert.strictEqual(result.description, 'First line\nSecond line');
  });
});

describe('IB/OOB Validation - Integration Tests', () => {
  it('should validate complete issue body', () => {
    const issueBody = `
## Test Cases

### In-Bounds (IB)

IB-01: User can login with valid credentials
IB-02: User can view dashboard after login
IB-03: User can logout successfully

### Out-of-Bounds (OOB)

OOB-01: System rejects invalid email format
OOB-02: System handles missing password gracefully
OOB-03: System rate-limits failed login attempts
    `;

    const ibCount = countIBCases(issueBody);
    const oobCount = countOOBCases(issueBody);
    const validation = checkMinimumRequirements(ibCount, oobCount);

    assert.strictEqual(ibCount, 3);
    assert.strictEqual(oobCount, 3);
    assert.strictEqual(validation.valid, true);
  });

  it('should fail validation for insufficient test cases', () => {
    const issueBody = `
## Test Cases

IB-01: Only one IB case

No OOB cases!
    `;

    const ibCount = countIBCases(issueBody);
    const oobCount = countOOBCases(issueBody);
    const validation = checkMinimumRequirements(ibCount, oobCount);

    assert.strictEqual(ibCount, 1);
    assert.strictEqual(oobCount, 0);
    assert.strictEqual(validation.valid, false);
    assert.ok(validation.errors.length > 0);
  });
});
