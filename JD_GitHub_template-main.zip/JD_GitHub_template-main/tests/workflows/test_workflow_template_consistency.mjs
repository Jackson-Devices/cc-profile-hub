#!/usr/bin/env node
/**
 * Workflow-Template Consistency Test
 *
 * Purpose: Catch issue #59-type problems early by verifying that:
 * 1. Every label auto-applied by a template has at least one workflow that handles it
 * 2. Every workflow that filters by label has at least one template that creates that label
 * 3. No orphaned issue types (templates without workflows) or orphaned workflows (workflows without templates)
 *
 * This test prevents the bug where Function issues got "Type: Function" labels
 * but no workflow was configured to handle them.
 */

import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';
import yaml from 'js-yaml';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
const repoRoot = path.resolve(__dirname, '../..');

// ANSI color codes for terminal output
const colors = {
  reset: '\x1b[0m',
  red: '\x1b[31m',
  green: '\x1b[32m',
  yellow: '\x1b[33m',
  blue: '\x1b[34m',
  cyan: '\x1b[36m',
  bold: '\x1b[1m',
};

/**
 * Extract all labels auto-applied by issue templates
 * @returns {Map<string, string[]>} Map of label -> template names that create it
 */
function extractTemplateLabels() {
  const templateDir = path.join(repoRoot, '.github/ISSUE_TEMPLATE');
  const templates = fs
    .readdirSync(templateDir)
    .filter((f) => f.endsWith('.yml') && f !== 'config.yml');

  const labelMap = new Map();

  for (const templateFile of templates) {
    const content = fs.readFileSync(path.join(templateDir, templateFile), 'utf8');
    const template = yaml.load(content);

    if (template.labels && Array.isArray(template.labels)) {
      for (const label of template.labels) {
        if (!labelMap.has(label)) {
          labelMap.set(label, []);
        }
        labelMap.get(label).push(templateFile);
      }
    }
  }

  return labelMap;
}

/**
 * Extract all labels that workflows filter on
 * @returns {Map<string, string[]>} Map of label -> workflow names that filter on it
 */
function extractWorkflowLabels() {
  const workflowDir = path.join(repoRoot, '.github/workflows');
  const workflows = fs.readdirSync(workflowDir).filter((f) => f.endsWith('.yml'));

  const labelMap = new Map();

  for (const workflowFile of workflows) {
    const content = fs.readFileSync(path.join(workflowDir, workflowFile), 'utf8');

    // Look for label checks in 'if' conditions
    // Pattern: contains(join(github.event.issue.labels.*.name, ','), 'Label Name')
    const labelPattern =
      /contains\(join\(github\.event\.issue\.labels\.\*\.name[^)]*\),\s*['"]([^'"]+)['"]\)/g;
    let match;

    while ((match = labelPattern.exec(content)) !== null) {
      const label = match[1];
      if (!labelMap.has(label)) {
        labelMap.set(label, []);
      }
      if (!labelMap.get(label).includes(workflowFile)) {
        labelMap.get(label).push(workflowFile);
      }
    }
  }

  return labelMap;
}

/**
 * Run consistency checks and report findings
 */
function runConsistencyChecks() {
  console.log(`${colors.bold}${colors.cyan}Workflow-Template Consistency Test${colors.reset}\n`);

  const templateLabels = extractTemplateLabels();
  const workflowLabels = extractWorkflowLabels();

  let passed = 0;
  let failed = 0;
  const issues = [];

  // Check 1: Every template label has at least one workflow
  console.log(`${colors.bold}Check 1: Template labels have workflows${colors.reset}`);
  for (const [label, templates] of templateLabels.entries()) {
    const hasWorkflow = workflowLabels.has(label);

    if (hasWorkflow) {
      console.log(
        `  ${colors.green}✓${colors.reset} "${label}" (${templates.join(', ')}) → ${workflowLabels.get(label).join(', ')}`
      );
      passed++;
    } else {
      console.log(
        `  ${colors.red}✗${colors.reset} "${label}" (${templates.join(', ')}) → ${colors.red}NO WORKFLOW${colors.reset}`
      );
      failed++;
      issues.push({
        severity: 'ERROR',
        type: 'orphaned_label',
        label,
        templates,
        message: `Label "${label}" is created by templates ${templates.join(', ')} but NO workflow handles it`,
      });
    }
  }

  console.log();

  // Check 2: Every workflow label has at least one template (warning only)
  console.log(`${colors.bold}Check 2: Workflow labels have templates${colors.reset}`);
  for (const [label, workflows] of workflowLabels.entries()) {
    const hasTemplate = templateLabels.has(label);

    if (hasTemplate) {
      console.log(
        `  ${colors.green}✓${colors.reset} "${label}" (${workflows.join(', ')}) ← ${templateLabels.get(label).join(', ')}`
      );
      passed++;
    } else {
      console.log(
        `  ${colors.yellow}⚠${colors.reset} "${label}" (${workflows.join(', ')}) ← ${colors.yellow}NO TEMPLATE${colors.reset}`
      );
      issues.push({
        severity: 'WARNING',
        type: 'manual_label',
        label,
        workflows,
        message: `Workflow ${workflows.join(', ')} filters on "${label}" but no template auto-applies it (requires manual labeling)`,
      });
    }
  }

  console.log();

  // Summary
  console.log(`${colors.bold}Summary:${colors.reset}`);
  console.log(`  Checks passed: ${colors.green}${passed}${colors.reset}`);
  console.log(`  Checks failed: ${colors.red}${failed}${colors.reset}`);
  console.log();

  if (issues.length > 0) {
    console.log(`${colors.bold}${colors.red}Issues Found:${colors.reset}`);
    for (const issue of issues) {
      const severityColor = issue.severity === 'ERROR' ? colors.red : colors.yellow;
      console.log(`  ${severityColor}[${issue.severity}]${colors.reset} ${issue.message}`);
    }
    console.log();
  }

  // Coverage report
  console.log(`${colors.bold}Coverage Report:${colors.reset}`);
  console.log(
    `  Templates with workflows: ${[...templateLabels.entries()].filter(([label]) => workflowLabels.has(label)).length}/${templateLabels.size}`
  );
  console.log(
    `  Workflows with templates: ${[...workflowLabels.entries()].filter(([label]) => templateLabels.has(label)).length}/${workflowLabels.size}`
  );
  console.log();

  // Exit code
  const errorCount = issues.filter((i) => i.severity === 'ERROR').length;
  if (errorCount > 0) {
    console.log(
      `${colors.red}${colors.bold}TEST FAILED${colors.reset} - ${errorCount} error(s) found`
    );
    process.exit(1);
  } else {
    console.log(
      `${colors.green}${colors.bold}TEST PASSED${colors.reset} - All templates have corresponding workflows`
    );
    process.exit(0);
  }
}

// Run the test
runConsistencyChecks();
