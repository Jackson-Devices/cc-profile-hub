#!/usr/bin/env node

/**
 * Integration Tests for Intelligent Commit Splitting
 *
 * These tests use REAL git operations to validate the splitter
 * works correctly with actual commit histories.
 *
 * IMPORTANT: These are critical safety tests for a dangerous operation
 */

import { describe, it, before, after } from 'node:test';
import assert from 'node:assert/strict';
import { execSync } from 'child_process';
import { mkdtempSync, rmSync, writeFileSync, mkdirSync } from 'fs';
import { join } from 'path';
import { tmpdir } from 'os';

// Helper to execute git commands in test repo
function gitExec(command, cwd) {
  return execSync(command, { cwd, encoding: 'utf8' }).trim();
}

// Helper to run the splitter script
function runSplitter(cwd) {
  try {
    const scriptPath = join(process.cwd(), 'scripts/split-commits-intelligently.mjs');
    execSync(`node ${scriptPath}`, { cwd, encoding: 'utf8' });
    return { exitCode: 0, output: '' };
  } catch (error) {
    return { exitCode: error.status, output: error.stdout || error.stderr };
  }
}

describe('Integration Tests - Real Git Scenarios', () => {
  let testRepoPath;

  before(() => {
    // Create a temporary test repository
    testRepoPath = mkdtempSync(join(tmpdir(), 'git-test-'));

    // Initialize git repo
    gitExec('git init', testRepoPath);
    gitExec('git config user.name "Test User"', testRepoPath);
    gitExec('git config user.email "test@example.com"', testRepoPath);
    // Disable GPG signing for test commits
    gitExec('git config commit.gpgsign false', testRepoPath);
    gitExec('git config tag.gpgsign false', testRepoPath);
    // Set default branch to main
    gitExec('git config init.defaultBranch main', testRepoPath);

    // Create main branch with initial commit
    writeFileSync(join(testRepoPath, 'README.md'), '# Test Repo\n');
    gitExec('git add .', testRepoPath);
    gitExec('git commit -m "chore: initial commit"', testRepoPath);
    // Rename master to main if needed
    gitExec('git branch -M main', testRepoPath);
  });

  after(() => {
    // Cleanup test repository
    if (testRepoPath) {
      rmSync(testRepoPath, { recursive: true, force: true });
    }
  });

  it('should handle single commit correctly', () => {
    // Create a feature branch with single commit
    gitExec('git checkout -b test-single-commit', testRepoPath);

    writeFileSync(join(testRepoPath, 'feature.js'), 'console.log("feature");');
    gitExec('git add .', testRepoPath);
    gitExec('git commit -m "feat: add feature"', testRepoPath);

    const result = runSplitter(testRepoPath);

    assert.equal(result.exitCode, 0, 'should exit with code 0 for single commit');

    // Cleanup
    gitExec('git checkout main', testRepoPath);
    gitExec('git branch -D test-single-commit', testRepoPath);
  });

  it('should detect related commits in same directory', () => {
    gitExec('git checkout -b test-related-commits', testRepoPath);

    // Create directory structure
    mkdirSync(join(testRepoPath, 'src', 'auth'), { recursive: true });

    // Commit 1: Add login
    writeFileSync(join(testRepoPath, 'src/auth/login.js'), 'export function login() {}');
    gitExec('git add .', testRepoPath);
    gitExec('git commit -m "feat: add login functionality"', testRepoPath);

    // Commit 2: Add logout (related to auth)
    writeFileSync(join(testRepoPath, 'src/auth/logout.js'), 'export function logout() {}');
    gitExec('git add .', testRepoPath);
    gitExec('git commit -m "feat: add logout functionality"', testRepoPath);

    // Commit 3: Add tests (related to auth)
    mkdirSync(join(testRepoPath, 'tests'), { recursive: true });
    writeFileSync(join(testRepoPath, 'tests/auth.test.js'), 'test("auth works", () => {});');
    gitExec('git add .', testRepoPath);
    gitExec('git commit -m "test: add auth tests"', testRepoPath);

    const result = runSplitter(testRepoPath);

    // Should recommend squash (all related to auth feature)
    assert.equal(result.exitCode, 1, 'should exit with code 1 (needs squash)');

    // Cleanup
    gitExec('git checkout main', testRepoPath);
    gitExec('git branch -D test-related-commits', testRepoPath);
  });

  it('should detect multiple unrelated features', () => {
    gitExec('git checkout -b test-unrelated-features', testRepoPath);

    // Create directory structure
    mkdirSync(join(testRepoPath, 'src', 'auth'), { recursive: true });
    mkdirSync(join(testRepoPath, 'src', 'dashboard'), { recursive: true });
    mkdirSync(join(testRepoPath, 'src', 'payments'), { recursive: true });

    // Commit 1: Auth feature
    writeFileSync(join(testRepoPath, 'src/auth/login.js'), 'export function login() {}');
    gitExec('git add .', testRepoPath);
    gitExec('git commit -m "feat: add user authentication"', testRepoPath);

    // Commit 2: Dashboard feature (unrelated)
    writeFileSync(join(testRepoPath, 'src/dashboard/Dashboard.js'), 'export function Dashboard() {}');
    gitExec('git add .', testRepoPath);
    gitExec('git commit -m "feat: add dashboard component"', testRepoPath);

    // Commit 3: Payments feature (unrelated)
    writeFileSync(join(testRepoPath, 'src/payments/checkout.js'), 'export function checkout() {}');
    gitExec('git add .', testRepoPath);
    gitExec('git commit -m "feat: add payment processing"', testRepoPath);

    const result = runSplitter(testRepoPath);

    // Should recommend split (multiple unrelated features)
    assert.equal(result.exitCode, 2, 'should exit with code 2 (needs split)');

    // Cleanup
    gitExec('git checkout main', testRepoPath);
    gitExec('git branch -D test-unrelated-features', testRepoPath);
  });

  it('should group feature with its fix commits', () => {
    gitExec('git checkout -b test-feature-with-fixes', testRepoPath);

    mkdirSync(join(testRepoPath, 'src'), { recursive: true });

    // Commit 1: Feature
    writeFileSync(join(testRepoPath, 'src/feature.js'), 'function buggy() { return ture; }');
    gitExec('git add .', testRepoPath);
    gitExec('git commit -m "feat: add new feature"', testRepoPath);

    // Commit 2: Fix typo
    writeFileSync(join(testRepoPath, 'src/feature.js'), 'function fixed() { return true; }');
    gitExec('git add .', testRepoPath);
    gitExec('git commit -m "fix: correct typo in feature"', testRepoPath);

    // Commit 3: Style fix
    writeFileSync(join(testRepoPath, 'src/feature.js'), 'function fixed() {\n  return true;\n}');
    gitExec('git add .', testRepoPath);
    gitExec('git commit -m "style: format feature code"', testRepoPath);

    const result = runSplitter(testRepoPath);

    // Should recommend squash (all related to same feature)
    assert.equal(result.exitCode, 1, 'should exit with code 1 (needs squash)');

    // Cleanup
    gitExec('git checkout main', testRepoPath);
    gitExec('git branch -D test-feature-with-fixes', testRepoPath);
  });

  it('should handle docs commits appropriately', () => {
    gitExec('git checkout -b test-docs-commits', testRepoPath);

    mkdirSync(join(testRepoPath, 'src'), { recursive: true });
    mkdirSync(join(testRepoPath, 'docs'), { recursive: true });

    // Commit 1: Feature
    writeFileSync(join(testRepoPath, 'src/api.js'), 'export function api() {}');
    gitExec('git add .', testRepoPath);
    gitExec('git commit -m "feat: add API endpoint"', testRepoPath);

    // Commit 2: Documentation for the feature
    writeFileSync(join(testRepoPath, 'docs/API.md'), '# API Documentation');
    gitExec('git add .', testRepoPath);
    gitExec('git commit -m "docs: add API documentation"', testRepoPath);

    const result = runSplitter(testRepoPath);

    // Should recommend squash (docs related to feature)
    assert.equal(result.exitCode, 1, 'should exit with code 1 (needs squash)');

    // Cleanup
    gitExec('git checkout main', testRepoPath);
    gitExec('git branch -D test-docs-commits', testRepoPath);
  });

  it('should preserve large refactoring commits', () => {
    gitExec('git checkout -b test-large-refactor', testRepoPath);

    mkdirSync(join(testRepoPath, 'src'), { recursive: true });

    // Create a large refactoring commit (many files, many changes)
    for (let i = 0; i < 20; i++) {
      const content = Array(50).fill(`function fn${i}() { return ${i}; }`).join('\n');
      writeFileSync(join(testRepoPath, `src/file${i}.js`), content);
    }
    gitExec('git add .', testRepoPath);
    gitExec('git commit -m "refactor: restructure entire codebase"', testRepoPath);

    const result = runSplitter(testRepoPath);

    // Should recognize as single commit, no action needed
    assert.equal(result.exitCode, 0, 'should exit with code 0 (no action needed)');

    // Cleanup
    gitExec('git checkout main', testRepoPath);
    gitExec('git branch -D test-large-refactor', testRepoPath);
  });

  it('should skip merge commits', () => {
    // Create a branch to merge
    gitExec('git checkout -b feature-branch', testRepoPath);
    writeFileSync(join(testRepoPath, 'feature.txt'), 'feature content');
    gitExec('git add .', testRepoPath);
    gitExec('git commit -m "feat: add feature"', testRepoPath);

    // Create another branch
    gitExec('git checkout main', testRepoPath);
    gitExec('git checkout -b test-merge-commit', testRepoPath);

    // Merge the feature branch
    gitExec('git merge --no-ff feature-branch -m "Merge feature-branch into test"', testRepoPath);

    const result = runSplitter(testRepoPath);

    // Should handle merge commits gracefully
    assert.ok(result.exitCode === 0 || result.exitCode === 1, 'should not error on merge commits');

    // Cleanup
    gitExec('git checkout main', testRepoPath);
    gitExec('git branch -D feature-branch', testRepoPath);
    gitExec('git branch -D test-merge-commit', testRepoPath);
  });
});

describe('Integration Tests - Edge Cases and Safety', () => {
  let testRepoPath;

  before(() => {
    testRepoPath = mkdtempSync(join(tmpdir(), 'git-test-edge-'));
    gitExec('git init', testRepoPath);
    gitExec('git config user.name "Test User"', testRepoPath);
    gitExec('git config user.email "test@example.com"', testRepoPath);
    // Disable GPG signing for test commits
    gitExec('git config commit.gpgsign false', testRepoPath);
    gitExec('git config tag.gpgsign false', testRepoPath);
    // Set default branch to main
    gitExec('git config init.defaultBranch main', testRepoPath);
    writeFileSync(join(testRepoPath, 'README.md'), '# Test\n');
    gitExec('git add .', testRepoPath);
    gitExec('git commit -m "chore: init"', testRepoPath);
    // Rename master to main if needed
    gitExec('git branch -M main', testRepoPath);
  });

  after(() => {
    if (testRepoPath) {
      rmSync(testRepoPath, { recursive: true, force: true });
    }
  });

  it('should handle empty commits gracefully', () => {
    gitExec('git checkout -b test-empty', testRepoPath);

    // Create an empty commit
    gitExec('git commit --allow-empty -m "chore: empty commit"', testRepoPath);

    const result = runSplitter(testRepoPath);

    // Should handle without crashing
    assert.ok([0, 1, 2].includes(result.exitCode), 'should exit with valid code');

    gitExec('git checkout main', testRepoPath);
    gitExec('git branch -D test-empty', testRepoPath);
  });

  it('should handle commits with special characters in messages', () => {
    gitExec('git checkout -b test-special-chars', testRepoPath);

    writeFileSync(join(testRepoPath, 'file.txt'), 'content');
    gitExec('git add .', testRepoPath);
    gitExec('git commit -m "feat: add \\"quotes\\" and \'apostrophes\' and $variables"', testRepoPath);

    const result = runSplitter(testRepoPath);

    assert.ok([0, 1, 2].includes(result.exitCode), 'should handle special chars');

    gitExec('git checkout main', testRepoPath);
    gitExec('git branch -D test-special-chars', testRepoPath);
  });

  it('should handle binary files', () => {
    gitExec('git checkout -b test-binary', testRepoPath);

    // Create a binary file (simulate with random bytes)
    const buffer = Buffer.from([0x00, 0xFF, 0xAB, 0xCD]);
    writeFileSync(join(testRepoPath, 'binary.bin'), buffer);
    gitExec('git add .', testRepoPath);
    gitExec('git commit -m "chore: add binary file"', testRepoPath);

    const result = runSplitter(testRepoPath);

    assert.ok([0, 1, 2].includes(result.exitCode), 'should handle binary files');

    gitExec('git checkout main', testRepoPath);
    gitExec('git branch -D test-binary', testRepoPath);
  });

  it('should handle commits with many files', () => {
    gitExec('git checkout -b test-many-files', testRepoPath);

    mkdirSync(join(testRepoPath, 'many'), { recursive: true });

    // Create commit with 50 files
    for (let i = 0; i < 50; i++) {
      writeFileSync(join(testRepoPath, 'many', `file${i}.txt`), `content ${i}`);
    }
    gitExec('git add .', testRepoPath);
    gitExec('git commit -m "chore: add many files"', testRepoPath);

    const result = runSplitter(testRepoPath);

    assert.ok([0, 1, 2].includes(result.exitCode), 'should handle many files');

    gitExec('git checkout main', testRepoPath);
    gitExec('git branch -D test-many-files', testRepoPath);
  });

  it('should handle deeply nested directories', () => {
    gitExec('git checkout -b test-deep-dirs', testRepoPath);

    const deepPath = join(testRepoPath, 'a/b/c/d/e/f/g/h/i/j');
    mkdirSync(deepPath, { recursive: true });
    writeFileSync(join(deepPath, 'deep.txt'), 'deep content');
    gitExec('git add .', testRepoPath);
    gitExec('git commit -m "feat: add deeply nested file"', testRepoPath);

    const result = runSplitter(testRepoPath);

    assert.ok([0, 1, 2].includes(result.exitCode), 'should handle deep directories');

    gitExec('git checkout main', testRepoPath);
    gitExec('git branch -D test-deep-dirs', testRepoPath);
  });
});

describe('Integration Tests - Real-World Scenarios', () => {
  let testRepoPath;

  before(() => {
    testRepoPath = mkdtempSync(join(tmpdir(), 'git-test-realworld-'));
    gitExec('git init', testRepoPath);
    gitExec('git config user.name "Test User"', testRepoPath);
    gitExec('git config user.email "test@example.com"', testRepoPath);
    // Disable GPG signing for test commits
    gitExec('git config commit.gpgsign false', testRepoPath);
    gitExec('git config tag.gpgsign false', testRepoPath);
    // Set default branch to main
    gitExec('git config init.defaultBranch main', testRepoPath);
    writeFileSync(join(testRepoPath, 'README.md'), '# Project\n');
    gitExec('git add .', testRepoPath);
    gitExec('git commit -m "chore: initial commit"', testRepoPath);
    // Rename master to main if needed
    gitExec('git branch -M main', testRepoPath);
  });

  after(() => {
    if (testRepoPath) {
      rmSync(testRepoPath, { recursive: true, force: true });
    }
  });

  it('should handle typical feature development workflow', () => {
    gitExec('git checkout -b feature/user-auth', testRepoPath);

    mkdirSync(join(testRepoPath, 'src', 'auth'), { recursive: true });
    mkdirSync(join(testRepoPath, 'tests'), { recursive: true });

    // Step 1: Initial implementation
    writeFileSync(join(testRepoPath, 'src/auth/login.js'), 'export function login() {}');
    gitExec('git add .', testRepoPath);
    gitExec('git commit -m "feat(auth): implement login"', testRepoPath);

    // Step 2: Add tests
    writeFileSync(join(testRepoPath, 'tests/login.test.js'), 'test("login", () => {})');
    gitExec('git add .', testRepoPath);
    gitExec('git commit -m "test(auth): add login tests"', testRepoPath);

    // Step 3: Fix failing test
    writeFileSync(join(testRepoPath, 'src/auth/login.js'), 'export function login() { return true; }');
    gitExec('git add .', testRepoPath);
    gitExec('git commit -m "fix(auth): fix login return value"', testRepoPath);

    // Step 4: Documentation
    writeFileSync(join(testRepoPath, 'README.md'), '# Project\n## Auth\n');
    gitExec('git add .', testRepoPath);
    gitExec('git commit -m "docs: document auth feature"', testRepoPath);

    const result = runSplitter(testRepoPath);

    // All related to auth feature - should recommend squash
    assert.equal(result.exitCode, 1, 'should recommend squash for related feature work');

    gitExec('git checkout main', testRepoPath);
    gitExec('git branch -D feature/user-auth', testRepoPath);
  });

  it('should detect when developer switches features mid-branch', () => {
    gitExec('git checkout -b accidental-multi-feature', testRepoPath);

    mkdirSync(join(testRepoPath, 'src', 'auth'), { recursive: true });
    mkdirSync(join(testRepoPath, 'src', 'billing'), { recursive: true });

    // Started working on auth
    writeFileSync(join(testRepoPath, 'src/auth/login.js'), 'export function login() {}');
    gitExec('git add .', testRepoPath);
    gitExec('git commit -m "feat: add login"', testRepoPath);

    // Oops, switched to billing feature
    writeFileSync(join(testRepoPath, 'src/billing/invoice.js'), 'export function invoice() {}');
    gitExec('git add .', testRepoPath);
    gitExec('git commit -m "feat: add invoice generation"', testRepoPath);

    const result = runSplitter(testRepoPath);

    // Should detect multiple features and recommend split
    assert.equal(result.exitCode, 2, 'should detect accidental multi-feature branch');

    gitExec('git checkout main', testRepoPath);
    gitExec('git branch -D accidental-multi-feature', testRepoPath);
  });

  it('should handle monorepo structure with scoped commits', () => {
    gitExec('git checkout -b monorepo-feature', testRepoPath);

    mkdirSync(join(testRepoPath, 'packages/frontend/src'), { recursive: true });
    mkdirSync(join(testRepoPath, 'packages/backend/src'), { recursive: true });

    // Frontend change
    writeFileSync(join(testRepoPath, 'packages/frontend/src/App.js'), 'export function App() {}');
    gitExec('git add .', testRepoPath);
    gitExec('git commit -m "feat(frontend): add App component"', testRepoPath);

    // Backend change for same feature
    writeFileSync(join(testRepoPath, 'packages/backend/src/api.js'), 'export function api() {}');
    gitExec('git add .', testRepoPath);
    gitExec('git commit -m "feat(backend): add API endpoint"', testRepoPath);

    const result = runSplitter(testRepoPath);

    // Both have same scope (related feature) - could squash or split depending on scope interpretation
    assert.ok([1, 2].includes(result.exitCode), 'should handle monorepo structure');

    gitExec('git checkout main', testRepoPath);
    gitExec('git branch -D monorepo-feature', testRepoPath);
  });
});
