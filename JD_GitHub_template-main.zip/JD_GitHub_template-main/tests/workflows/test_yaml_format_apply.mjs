#!/usr/bin/env node

/**
 * Test YAML Format Apply Workflow
 *
 * Purpose: Validate that workflow-yaml-format-apply.yml correctly:
 * 1. Detects improperly formatted YAML files
 * 2. Applies Prettier formatting to workflow YAML files
 * 3. Handles edge cases (quotes, multi-line strings, indentation)
 * 4. Produces valid, well-formatted YAML output
 *
 * This test ensures the workflow catches YAML formatting issues early,
 * reducing manual fixes and ensuring consistent code style.
 */

import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';
import { execSync } from 'child_process';
import { tmpdir } from 'os';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
const repoRoot = path.resolve(__dirname, '../..');

// ANSI color codes
const colors = {
  reset: '\x1b[0m',
  red: '\x1b[31m',
  green: '\x1b[32m',
  yellow: '\x1b[33m',
  cyan: '\x1b[36m',
  bold: '\x1b[1m',
};

/**
 * Test cases for YAML formatting
 */
const testCases = [
  {
    name: 'Properly formatted YAML should pass',
    input: `name: Test Workflow

on:
  push:
    branches:
      - main

jobs:
  test:
    runs-on: ubuntu-latest
    steps:
      - name: Checkout
        uses: actions/checkout@v4
`,
    shouldNeedFormatting: false,
  },

  {
    name: 'Inconsistent indentation should be fixed',
    input: `name: Test Workflow
on:
 push:
   branches:
    - main
jobs:
  test:
     runs-on: ubuntu-latest
`,
    shouldNeedFormatting: true,
  },

  {
    name: 'Special characters with colons require quotes',
    input: `name: Test Workflow
on:
  push:
    branches:
      - main
jobs:
  test:
    runs-on: ubuntu-latest
    steps:
      - name: "Test with special: characters"
        run: echo "test"
`,
    shouldNeedFormatting: false, // Already properly quoted
  },

  {
    name: 'Multi-line strings should be formatted consistently',
    input: `name: Test Workflow
on: [push]
jobs:
  test:
    runs-on: ubuntu-latest
    steps:
      - name: Multi-line command
        run: |
          echo "line 1"
          echo "line 2"
`,
    shouldNeedFormatting: false, // Already properly formatted
  },

  {
    name: 'Compact arrays should be expanded if needed',
    input: `name: Test
on: [push, pull_request]
jobs:
  test:
    runs-on: ubuntu-latest
`,
    shouldNeedFormatting: false, // Prettier allows compact arrays
  },

  {
    name: 'Mixed quotes should be normalized',
    input: `name: 'Test Workflow'
on:
  push:
    branches:
      - "main"
jobs:
  test:
    runs-on: 'ubuntu-latest'
`,
    shouldNeedFormatting: true, // YAML should use consistent quotes
  },
];

/**
 * Create a temporary YAML file and check if Prettier would format it
 * @param {string} content - YAML content to test
 * @returns {boolean} - True if formatting is needed
 */
function needsFormatting(content) {
  const tempDir = fs.mkdtempSync(path.join(tmpdir(), 'yaml-test-'));
  const tempFile = path.join(tempDir, 'test.yml');

  try {
    fs.writeFileSync(tempFile, content);

    // Run prettier --check (exits with 1 if formatting needed)
    try {
      execSync(`npx prettier --check "${tempFile}"`, {
        cwd: repoRoot,
        stdio: 'pipe',
      });
      return false; // No formatting needed
    } catch {
      return true; // Formatting needed
    }
  } finally {
    // Cleanup
    fs.rmSync(tempDir, { recursive: true, force: true });
  }
}

/**
 * Apply Prettier formatting to YAML content
 * @param {string} content - YAML content to format
 * @returns {string} - Formatted YAML content
 */
function applyFormatting(content) {
  const tempDir = fs.mkdtempSync(path.join(tmpdir(), 'yaml-format-'));
  const tempFile = path.join(tempDir, 'test.yml');

  try {
    fs.writeFileSync(tempFile, content);

    // Run prettier --write
    execSync(`npx prettier --write "${tempFile}"`, {
      cwd: repoRoot,
      stdio: 'pipe',
    });

    return fs.readFileSync(tempFile, 'utf8');
  } finally {
    // Cleanup
    fs.rmSync(tempDir, { recursive: true, force: true });
  }
}

/**
 * Validate that formatted YAML is still valid YAML
 * @param {string} content - YAML content to validate
 * @returns {boolean} - True if valid
 */
function isValidYAML(content) {
  const tempDir = fs.mkdtempSync(path.join(tmpdir(), 'yaml-validate-'));
  const tempFile = path.join(tempDir, 'test.yml');

  try {
    fs.writeFileSync(tempFile, content);

    // Use js-yaml to validate (it will be imported dynamically)
    try {
      execSync(
        `node -e "import('js-yaml').then(y => y.default.load(require('fs').readFileSync('${tempFile}', 'utf8')))"`,
        {
          cwd: repoRoot,
          stdio: 'pipe',
        }
      );
      return true;
    } catch {
      return false;
    }
  } finally {
    // Cleanup
    fs.rmSync(tempDir, { recursive: true, force: true });
  }
}

/**
 * Run all tests
 */
function runTests() {
  let passed = 0;
  let failed = 0;
  const failures = [];

  console.log(`${colors.bold}${colors.cyan}Testing YAML Format Apply Workflow${colors.reset}\n`);

  for (const testCase of testCases) {
    const actualNeedsFormatting = needsFormatting(testCase.input);
    const formatDetectionCorrect = actualNeedsFormatting === testCase.shouldNeedFormatting;

    if (formatDetectionCorrect) {
      console.log(`${colors.green}✅${colors.reset} ${testCase.name}`);
      passed++;

      // If formatting is needed, verify it produces valid YAML
      if (actualNeedsFormatting) {
        const formatted = applyFormatting(testCase.input);
        const isValid = isValidYAML(formatted);

        if (isValid) {
          console.log(`   ${colors.green}→${colors.reset} Formatting produces valid YAML`);
        } else {
          console.log(`   ${colors.red}→${colors.reset} Formatting produces INVALID YAML`);
          failed++;
          failures.push({
            name: `${testCase.name} (validation)`,
            reason: 'Formatted YAML is invalid',
            formatted,
          });
        }
      }
    } else {
      console.log(`${colors.red}❌${colors.reset} ${testCase.name}`);
      failed++;
      failures.push({
        name: testCase.name,
        expected: testCase.shouldNeedFormatting ? 'needs formatting' : 'no formatting needed',
        actual: actualNeedsFormatting ? 'needs formatting' : 'no formatting needed',
      });
    }
  }

  console.log(`\n${colors.bold}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━${colors.reset}`);
  console.log(`${colors.bold}📊 Test Results:${colors.reset}`);
  console.log(`  Passed: ${colors.green}${passed}${colors.reset}`);
  console.log(`  Failed: ${colors.red}${failed}${colors.reset}`);
  console.log(`${colors.bold}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━${colors.reset}\n`);

  if (failures.length > 0) {
    console.log(`${colors.red}${colors.bold}Failed Tests:${colors.reset}\n`);
    failures.forEach(({ name, expected, actual, reason, formatted }) => {
      console.log(`  ${colors.red}✗${colors.reset} ${name}`);
      if (reason) {
        console.log(`    Reason: ${reason}`);
        if (formatted) {
          console.log(
            `    Output:\n${formatted
              .split('\n')
              .map((l) => `      ${l}`)
              .join('\n')}`
          );
        }
      } else {
        console.log(`    Expected: ${expected}`);
        console.log(`    Actual: ${actual}`);
      }
      console.log();
    });
    console.log(`${colors.red}${colors.bold}TEST FAILED${colors.reset}\n`);
    process.exit(1);
  }

  console.log(`${colors.green}${colors.bold}✅ ALL TESTS PASSED${colors.reset}\n`);
  process.exit(0);
}

// Verify workflow file exists
const workflowPath = path.join(repoRoot, '.github/workflows/workflow-yaml-format-apply.yml');
if (!fs.existsSync(workflowPath)) {
  console.log(
    `${colors.red}${colors.bold}ERROR:${colors.reset} workflow-yaml-format-apply.yml not found`
  );
  console.log(`Expected at: ${workflowPath}`);
  process.exit(1);
}

console.log(`${colors.cyan}Workflow file found:${colors.reset} ${workflowPath}\n`);

// Run the tests
runTests();
