#!/usr/bin/env node

/**
 * Tests for Intelligent Commit Splitting
 *
 * Following TDD principles - these tests define the expected behavior
 * of the intelligent commit splitter before implementation.
 */

import { describe, it, mock } from 'node:test';
import assert from 'node:assert/strict';

// Mock git commands for testing
const mockGitCommands = {
  getCommitCount: mock.fn(() => 3),
  getCommitShas: mock.fn(() => ['abc123', 'def456', 'ghi789']),
  getCommitMessage: mock.fn((sha) => {
    const messages = {
      abc123: 'feat: add user authentication',
      def456: 'docs: update README with installation steps',
      ghi789: 'feat: add dashboard component',
    };
    return messages[sha] || '';
  }),
  getCommitDiff: mock.fn((sha) => {
    const diffs = {
      abc123: {
        files: ['src/auth/login.js', 'src/auth/register.js', 'tests/auth.test.js'],
        insertions: 120,
        deletions: 5,
      },
      def456: {
        files: ['README.md', 'docs/INSTALLATION.md'],
        insertions: 45,
        deletions: 2,
      },
      ghi789: {
        files: ['src/components/Dashboard.js', 'src/styles/dashboard.css'],
        insertions: 200,
        deletions: 0,
      },
    };
    return diffs[sha] || { files: [], insertions: 0, deletions: 0 };
  }),
};

describe('Intelligent Commit Splitting - Commit Analysis', () => {
  it('should analyze file changes for each commit', () => {
    const commitDiff = mockGitCommands.getCommitDiff('abc123');

    assert.ok(Array.isArray(commitDiff.files), 'should return array of files');
    assert.equal(commitDiff.files.length, 3, 'should count all changed files');
    assert.ok(
      typeof commitDiff.insertions === 'number',
      'should count insertions'
    );
    assert.ok(typeof commitDiff.deletions === 'number', 'should count deletions');
  });

  it('should extract commit metadata', () => {
    const message = mockGitCommands.getCommitMessage('abc123');

    assert.ok(message.includes('feat:'), 'should identify conventional commit type');
    assert.ok(
      message.includes('authentication'),
      'should extract feature description'
    );
  });

  it('should detect conventional commit types', () => {
    const testCases = [
      { msg: 'feat: new feature', type: 'feat' },
      { msg: 'fix: bug fix', type: 'fix' },
      { msg: 'docs: documentation', type: 'docs' },
      { msg: 'chore: maintenance', type: 'chore' },
      { msg: 'test: add tests', type: 'test' },
      { msg: 'refactor: code improvement', type: 'refactor' },
      { msg: 'style: formatting', type: 'style' },
    ];

    testCases.forEach(({ msg, type }) => {
      const extractedType = msg.split(':')[0];
      assert.equal(extractedType, type, `should extract type ${type}`);
    });
  });
});

describe('Intelligent Commit Splitting - Feature Grouping', () => {
  it('should group commits by directory/component', () => {
    const commit1Files = ['src/auth/login.js', 'src/auth/register.js'];
    const commit2Files = ['src/components/Dashboard.js'];

    const getDirectory = (file) => file.split('/').slice(0, -1).join('/');

    const commit1Dirs = [...new Set(commit1Files.map(getDirectory))];
    const commit2Dirs = [...new Set(commit2Files.map(getDirectory))];

    assert.equal(commit1Dirs.length, 1, 'commit1 should touch one directory');
    assert.equal(commit2Dirs.length, 1, 'commit2 should touch one directory');
    assert.notEqual(
      commit1Dirs[0],
      commit2Dirs[0],
      'commits should touch different directories'
    );
  });

  it('should identify related file types', () => {
    const testFile = 'src/components/Dashboard.js';
    const styleFile = 'src/styles/dashboard.css';
    const testFileForComponent = 'tests/components/Dashboard.test.js';

    const getBaseName = (file) => file.split('/').pop().split('.')[0];

    const baseName = getBaseName(testFile);

    assert.ok(
      styleFile.toLowerCase().includes(baseName.toLowerCase()),
      'style file should match component name'
    );
    assert.ok(
      testFileForComponent.toLowerCase().includes(baseName.toLowerCase()),
      'test file should match component name'
    );
  });

  it('should group documentation commits separately', () => {
    const docFiles = ['README.md', 'docs/INSTALLATION.md', 'docs/API.md'];
    const codeFiles = ['src/index.js', 'src/utils.js'];

    const isDocFile = (file) =>
      file.endsWith('.md') || file.startsWith('docs/');

    const allDocsFilesAreDoc = docFiles.every(isDocFile);
    const noCodeFilesAreDoc = codeFiles.every((f) => !isDocFile(f));

    assert.ok(allDocsFilesAreDoc, 'should identify all doc files');
    assert.ok(noCodeFilesAreDoc, 'should distinguish code from docs');
  });

  it('should recognize test files as part of feature', () => {
    const featureFiles = [
      'src/auth/login.js',
      'tests/auth/login.test.js',
      'tests/integration/auth.test.js',
    ];

    const hasTests = featureFiles.some(
      (f) => f.includes('test') || f.startsWith('tests/')
    );
    const hasImplementation = featureFiles.some(
      (f) => f.startsWith('src/') && !f.includes('test')
    );

    assert.ok(hasTests, 'should identify test files');
    assert.ok(hasImplementation, 'should identify implementation files');
  });
});

describe('Intelligent Commit Splitting - Similarity Analysis', () => {
  it('should calculate path similarity between commits', () => {
    const commit1Paths = ['src/auth/login.js', 'src/auth/register.js'];
    const commit2Paths = ['src/auth/logout.js', 'src/auth/session.js'];
    const commit3Paths = ['src/components/Dashboard.js'];

    // Calculate common prefix depth
    const getCommonPrefix = (path1, path2) => {
      const parts1 = path1.split('/');
      const parts2 = path2.split('/');
      let common = 0;
      for (let i = 0; i < Math.min(parts1.length, parts2.length); i++) {
        if (parts1[i] === parts2[i]) common++;
        else break;
      }
      return common;
    };

    const similarity1_2 = getCommonPrefix(commit1Paths[0], commit2Paths[0]);
    const similarity1_3 = getCommonPrefix(commit1Paths[0], commit3Paths[0]);

    assert.ok(
      similarity1_2 > similarity1_3,
      'auth commits should be more similar than auth vs components'
    );
    assert.equal(
      similarity1_2,
      2,
      'auth commits should share src/auth prefix'
    );
  });

  it('should detect conventional commit type similarity', () => {
    const commits = [
      { type: 'feat', scope: 'auth' },
      { type: 'feat', scope: 'dashboard' },
      { type: 'docs', scope: null },
      { type: 'test', scope: 'auth' },
    ];

    const typeGroups = {};
    commits.forEach((c, i) => {
      if (!typeGroups[c.type]) typeGroups[c.type] = [];
      typeGroups[c.type].push(i);
    });

    assert.equal(
      typeGroups.feat.length,
      2,
      'should group two feat commits together'
    );
    assert.equal(typeGroups.docs.length, 1, 'docs commit should be separate');
    assert.equal(typeGroups.test.length, 1, 'test commit should be separate');
  });

  it('should calculate change size for splitting decisions', () => {
    const smallChange = { insertions: 5, deletions: 2 };
    const mediumChange = { insertions: 50, deletions: 20 };
    const largeChange = { insertions: 500, deletions: 100 };

    const getChangeSize = (change) => change.insertions + change.deletions;

    assert.ok(getChangeSize(smallChange) < 50, 'small change threshold');
    assert.ok(
      getChangeSize(mediumChange) >= 50 && getChangeSize(mediumChange) < 200,
      'medium change threshold'
    );
    assert.ok(getChangeSize(largeChange) >= 200, 'large change threshold');
  });
});

describe('Intelligent Commit Splitting - Decision Logic', () => {
  it('should recommend squashing highly related commits', () => {
    const commits = [
      {
        type: 'feat',
        files: ['src/auth/login.js'],
        directories: ['src/auth'],
      },
      {
        type: 'fix',
        files: ['src/auth/login.js'],
        directories: ['src/auth'],
      },
      {
        type: 'test',
        files: ['tests/auth/login.test.js'],
        directories: ['tests/auth'],
      },
    ];

    // All commits touch the same feature area (auth)
    const allTouchAuth = commits.every((c) =>
      c.directories.some((d) => d.includes('auth'))
    );
    const hasFeatureAndTest = commits.some((c) => c.type === 'feat') &&
      commits.some((c) => c.type === 'test');

    assert.ok(allTouchAuth, 'all commits should touch auth area');
    assert.ok(
      hasFeatureAndTest,
      'should have both implementation and tests'
    );

    // Decision: SQUASH (all related to same feature)
    const decision = 'squash';
    assert.equal(decision, 'squash', 'should recommend squashing');
  });

  it('should recommend splitting unrelated feature commits', () => {
    const commits = [
      {
        type: 'feat',
        files: ['src/auth/login.js'],
        directories: ['src/auth'],
      },
      {
        type: 'feat',
        files: ['src/dashboard/Dashboard.js'],
        directories: ['src/dashboard'],
      },
      {
        type: 'feat',
        files: ['src/payments/checkout.js'],
        directories: ['src/payments'],
      },
    ];

    // All different feature commits
    const uniqueDirs = new Set(commits.flatMap((c) => c.directories));
    const allFeatures = commits.every((c) => c.type === 'feat');

    assert.ok(uniqueDirs.size >= 3, 'should touch multiple distinct areas');
    assert.ok(allFeatures, 'all should be feature commits');

    // Decision: SPLIT (multiple unrelated features)
    const decision = 'split';
    assert.equal(decision, 'split', 'should recommend splitting');
  });

  it('should handle docs-only commits appropriately', () => {
    const commits = [
      {
        type: 'feat',
        files: ['src/auth/login.js'],
        directories: ['src/auth'],
      },
      {
        type: 'docs',
        files: ['README.md', 'docs/AUTH.md'],
        directories: ['docs'],
      },
    ];

    const hasDocsCommit = commits.some((c) => c.type === 'docs');
    const hasFeatureCommit = commits.some((c) => c.type === 'feat');
    const docsCommit = commits.find((c) => c.type === 'docs');
    const docFilesOnly = docsCommit.files.every(
      (f) => f.endsWith('.md') || f.startsWith('docs/')
    );

    assert.ok(hasDocsCommit && hasFeatureCommit, 'mixed commit types');
    assert.ok(docFilesOnly, 'docs commit should only touch doc files');

    // Decision: Can squash if docs relate to the feature, or keep separate
    // For this test, if docs are about the same feature, squash is OK
    const decision = 'squash_or_keep_separate';
    assert.ok(decision, 'should have a decision strategy');
  });

  it('should respect fix commits following failures', () => {
    const commits = [
      {
        type: 'feat',
        files: ['src/auth/login.js'],
        hadFailure: false,
      },
      {
        type: 'fix',
        files: ['src/auth/login.js'],
        hadFailure: true,
      },
    ];

    const hasFailedCommit = commits.some((c) => c.hadFailure);
    const hasFixCommit = commits.some((c) => c.type === 'fix');

    assert.ok(hasFailedCommit, 'should detect failed commit');
    assert.ok(hasFixCommit, 'should detect fix commit');

    // Decision: SQUASH (fix is related to previous commit)
    const decision = 'squash';
    assert.equal(
      decision,
      'squash',
      'should squash fix with original commit'
    );
  });
});

describe('Intelligent Commit Splitting - Edge Cases', () => {
  it('should handle single commit gracefully', () => {
    const commitCount = 1;

    assert.equal(commitCount, 1, 'single commit detected');

    // Decision: NO ACTION NEEDED
    const decision = 'no_action';
    assert.equal(decision, 'no_action', 'should not process single commit');
  });

  it('should handle empty commits', () => {
    const commit = {
      files: [],
      insertions: 0,
      deletions: 0,
    };

    assert.equal(commit.files.length, 0, 'no files changed');

    // Decision: SKIP or WARN
    const decision = 'skip';
    assert.equal(decision, 'skip', 'should skip empty commits');
  });

  it('should handle very large refactoring commits', () => {
    const commit = {
      type: 'refactor',
      files: Array(100).fill('src/file.js'),
      insertions: 2000,
      deletions: 1500,
    };

    const isLargeRefactor = commit.type === 'refactor' &&
      commit.files.length > 50 &&
      commit.insertions + commit.deletions > 1000;

    assert.ok(isLargeRefactor, 'should detect large refactor');

    // Decision: KEEP AS IS (large refactors shouldn't be auto-split)
    const decision = 'keep_as_is';
    assert.equal(decision, 'keep_as_is', 'should preserve large refactors');
  });

  it('should handle merge commits', () => {
    const commitMessage = 'Merge branch feature/auth into main';

    const isMergeCommit = commitMessage.toLowerCase().includes('merge');

    assert.ok(isMergeCommit, 'should detect merge commit');

    // Decision: SKIP (don't process merge commits)
    const decision = 'skip';
    assert.equal(decision, 'skip', 'should skip merge commits');
  });
});

describe('Intelligent Commit Splitting - Output Format', () => {
  it('should provide actionable recommendations', () => {
    const result = {
      action: 'squash',
      reason: 'All commits relate to auth feature',
      confidence: 0.95,
      groups: [
        {
          commits: ['abc123', 'def456'],
          feature: 'authentication',
          recommendedMessage: 'feat: implement user authentication',
        },
      ],
    };

    assert.ok(result.action, 'should specify action');
    assert.ok(result.reason, 'should explain reasoning');
    assert.ok(result.confidence >= 0, 'should provide confidence score');
    assert.ok(Array.isArray(result.groups), 'should group commits');
  });

  it('should suggest split boundaries when needed', () => {
    const result = {
      action: 'split',
      reason: 'Multiple unrelated features detected',
      confidence: 0.88,
      groups: [
        {
          commits: ['abc123'],
          feature: 'authentication',
          suggestedBranch: 'feature/auth',
        },
        {
          commits: ['def456'],
          feature: 'dashboard',
          suggestedBranch: 'feature/dashboard',
        },
      ],
    };

    assert.equal(result.action, 'split', 'should recommend splitting');
    assert.equal(result.groups.length, 2, 'should identify 2 feature groups');
    assert.ok(
      result.groups.every((g) => g.suggestedBranch),
      'should suggest branch names'
    );
  });

  it('should provide clear exit codes', () => {
    const exitCodes = {
      SUCCESS: 0,
      NEEDS_SQUASH: 1,
      NEEDS_SPLIT: 2,
      ERROR: 3,
    };

    assert.equal(exitCodes.SUCCESS, 0, 'success should be 0');
    assert.ok(exitCodes.NEEDS_SQUASH > 0, 'needs squash should be non-zero');
    assert.ok(exitCodes.NEEDS_SPLIT > 0, 'needs split should be non-zero');
    assert.ok(exitCodes.ERROR > 0, 'error should be non-zero');
  });
});
