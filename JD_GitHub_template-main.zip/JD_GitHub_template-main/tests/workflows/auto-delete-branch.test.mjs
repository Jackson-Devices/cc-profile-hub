import { describe, test } from 'node:test';
import assert from 'node:assert';

/**
 * Test suite for auto-delete-branch.yml workflow
 *
 * Tests the automatic branch deletion after PR merge with proper safety guards
 */

describe('Auto-Delete Branch Workflow', () => {
  describe('Branch Safety Validation', () => {
    test('should reject protected branch names', () => {
      const protectedBranches = ['main', 'master', 'develop', 'staging', 'production'];

      protectedBranches.forEach((branch) => {
        const isProtected = /^(main|master|develop|staging|production)$/.test(branch);
        assert.strictEqual(
          isProtected,
          true,
          `Branch "${branch}" should be recognized as protected`
        );
      });
    });

    test('should allow feature branch names', () => {
      const featureBranches = [
        'claude/fix-bug-123',
        'feature/add-new-component',
        'bugfix/resolve-issue-456',
        'test/add-unit-tests',
      ];

      featureBranches.forEach((branch) => {
        const isProtected = /^(main|master|develop|staging|production)$/.test(branch);
        assert.strictEqual(
          isProtected,
          false,
          `Branch "${branch}" should NOT be recognized as protected`
        );
      });
    });

    test('should identify base branch same as head branch', () => {
      const headBranch = 'feature/test';
      const baseBranch = 'feature/test';

      assert.strictEqual(
        headBranch === baseBranch,
        true,
        'Should detect when head and base are the same'
      );
    });

    test('should allow deletion when head differs from base', () => {
      const headBranch = 'feature/test';
      const baseBranch = 'main';

      assert.strictEqual(
        headBranch !== baseBranch,
        true,
        'Should allow deletion when head differs from base'
      );
    });
  });

  describe('PR Event Validation', () => {
    test('should process merged PRs', () => {
      const prEvent = {
        action: 'closed',
        pull_request: {
          merged: true,
          head: { ref: 'feature/test', repo: { full_name: 'owner/repo' } },
          base: { ref: 'main' },
        },
      };

      assert.strictEqual(prEvent.pull_request.merged, true, 'Should detect merged PR');
    });

    test('should skip closed but not merged PRs', () => {
      const prEvent = {
        action: 'closed',
        pull_request: {
          merged: false,
          head: { ref: 'feature/test', repo: { full_name: 'owner/repo' } },
          base: { ref: 'main' },
        },
      };

      assert.strictEqual(prEvent.pull_request.merged, false, 'Should skip unmerged PR');
    });

    test('should detect fork PRs', () => {
      const prEvent = {
        action: 'closed',
        pull_request: {
          merged: true,
          head: {
            ref: 'feature/test',
            repo: { full_name: 'fork-owner/repo' },
          },
          base: { ref: 'main' },
        },
      };

      const repository = 'owner/repo';
      const isFork = prEvent.pull_request.head.repo.full_name !== repository;

      assert.strictEqual(isFork, true, 'Should detect fork PR');
    });

    test('should allow same-repo PRs', () => {
      const prEvent = {
        action: 'closed',
        pull_request: {
          merged: true,
          head: {
            ref: 'feature/test',
            repo: { full_name: 'owner/repo' },
          },
          base: { ref: 'main' },
        },
      };

      const repository = 'owner/repo';
      const isFork = prEvent.pull_request.head.repo.full_name !== repository;

      assert.strictEqual(isFork, false, 'Should allow same-repo PR');
    });
  });

  describe('Check Status Validation', () => {
    test('should identify all checks passed', () => {
      const checkRuns = [
        { name: 'lint', conclusion: 'success', status: 'completed' },
        { name: 'test', conclusion: 'success', status: 'completed' },
        { name: 'build', conclusion: 'success', status: 'completed' },
      ];

      const failedChecks = checkRuns.filter(
        (check) => check.conclusion !== 'success' && check.conclusion !== 'skipped'
      );

      assert.strictEqual(failedChecks.length, 0, 'Should have no failed checks');
    });

    test('should identify failed checks', () => {
      const checkRuns = [
        { name: 'lint', conclusion: 'success', status: 'completed' },
        { name: 'test', conclusion: 'failure', status: 'completed' },
        { name: 'build', conclusion: 'success', status: 'completed' },
      ];

      const failedChecks = checkRuns.filter(
        (check) => check.conclusion !== 'success' && check.conclusion !== 'skipped'
      );

      assert.strictEqual(failedChecks.length, 1, 'Should identify 1 failed check');
      assert.strictEqual(failedChecks[0].name, 'test', 'Should identify "test" as failed');
    });

    test('should allow skipped checks', () => {
      const checkRuns = [
        { name: 'lint', conclusion: 'success', status: 'completed' },
        { name: 'optional-test', conclusion: 'skipped', status: 'completed' },
        { name: 'build', conclusion: 'success', status: 'completed' },
      ];

      const failedChecks = checkRuns.filter(
        (check) => check.conclusion !== 'success' && check.conclusion !== 'skipped'
      );

      assert.strictEqual(failedChecks.length, 0, 'Should allow skipped checks');
    });

    test('should ignore in-progress checks', () => {
      const checkRuns = [
        { name: 'lint', conclusion: 'success', status: 'completed' },
        { name: 'test', conclusion: null, status: 'in_progress' },
        { name: 'build', conclusion: 'success', status: 'completed' },
      ];

      const completedChecks = checkRuns.filter(
        (check) => check.conclusion !== null && check.status === 'completed'
      );

      assert.strictEqual(completedChecks.length, 2, 'Should only count completed checks');
    });
  });

  describe('Integration Scenarios', () => {
    test('Scenario: Merged PR, all checks passed, feature branch → DELETE', () => {
      const scenario = {
        pr: {
          merged: true,
          head: { ref: 'feature/new-feature', repo: { full_name: 'owner/repo' } },
          base: { ref: 'main' },
        },
        checks: [
          { name: 'lint', conclusion: 'success', status: 'completed' },
          { name: 'test', conclusion: 'success', status: 'completed' },
        ],
        repository: 'owner/repo',
      };

      const isProtected = /^(main|master|develop|staging|production)$/.test(scenario.pr.head.ref);
      const isMerged = scenario.pr.merged;
      const isFork = scenario.pr.head.repo.full_name !== scenario.repository;
      const allChecksPassed =
        scenario.checks.filter((c) => c.conclusion !== 'success' && c.conclusion !== 'skipped')
          .length === 0;

      assert.strictEqual(isProtected, false, 'Branch should not be protected');
      assert.strictEqual(isMerged, true, 'PR should be merged');
      assert.strictEqual(isFork, false, 'Should not be a fork');
      assert.strictEqual(allChecksPassed, true, 'All checks should pass');

      const shouldDelete = !isProtected && isMerged && !isFork && allChecksPassed;
      assert.strictEqual(shouldDelete, true, 'Should delete branch');
    });

    test('Scenario: Merged PR, checks failed, feature branch → NO DELETE', () => {
      const scenario = {
        pr: {
          merged: true,
          head: { ref: 'feature/new-feature', repo: { full_name: 'owner/repo' } },
          base: { ref: 'main' },
        },
        checks: [
          { name: 'lint', conclusion: 'success', status: 'completed' },
          { name: 'test', conclusion: 'failure', status: 'completed' },
        ],
        repository: 'owner/repo',
      };

      const isProtected = /^(main|master|develop|staging|production)$/.test(scenario.pr.head.ref);
      const isMerged = scenario.pr.merged;
      const isFork = scenario.pr.head.repo.full_name !== scenario.repository;
      const allChecksPassed =
        scenario.checks.filter((c) => c.conclusion !== 'success' && c.conclusion !== 'skipped')
          .length === 0;

      assert.strictEqual(allChecksPassed, false, 'Checks should have failures');

      const shouldDelete = !isProtected && isMerged && !isFork && allChecksPassed;
      assert.strictEqual(shouldDelete, false, 'Should NOT delete branch');
    });

    test('Scenario: Closed but not merged PR → NO DELETE', () => {
      const scenario = {
        pr: {
          merged: false,
          head: { ref: 'feature/new-feature', repo: { full_name: 'owner/repo' } },
          base: { ref: 'main' },
        },
        checks: [
          { name: 'lint', conclusion: 'success', status: 'completed' },
          { name: 'test', conclusion: 'success', status: 'completed' },
        ],
        repository: 'owner/repo',
      };

      const isMerged = scenario.pr.merged;
      assert.strictEqual(isMerged, false, 'PR should not be merged');

      const shouldDelete = isMerged; // Simplified - would fail other checks anyway
      assert.strictEqual(shouldDelete, false, 'Should NOT delete branch');
    });

    test('Scenario: Merged PR, protected branch → NO DELETE', () => {
      const scenario = {
        pr: {
          merged: true,
          head: { ref: 'main', repo: { full_name: 'owner/repo' } },
          base: { ref: 'develop' },
        },
        checks: [
          { name: 'lint', conclusion: 'success', status: 'completed' },
          { name: 'test', conclusion: 'success', status: 'completed' },
        ],
        repository: 'owner/repo',
      };

      const isProtected = /^(main|master|develop|staging|production)$/.test(scenario.pr.head.ref);

      assert.strictEqual(isProtected, true, 'Branch should be protected');

      const shouldDelete = !isProtected; // Simplified
      assert.strictEqual(shouldDelete, false, 'Should NOT delete protected branch');
    });

    test('Scenario: Merged fork PR, all checks passed → NO DELETE', () => {
      const scenario = {
        pr: {
          merged: true,
          head: { ref: 'feature/new-feature', repo: { full_name: 'fork/repo' } },
          base: { ref: 'main' },
        },
        checks: [
          { name: 'lint', conclusion: 'success', status: 'completed' },
          { name: 'test', conclusion: 'success', status: 'completed' },
        ],
        repository: 'owner/repo',
      };

      const isFork = scenario.pr.head.repo.full_name !== scenario.repository;
      assert.strictEqual(isFork, true, 'Should detect fork PR');

      const shouldDelete = !isFork; // Simplified
      assert.strictEqual(shouldDelete, false, 'Should NOT delete fork branch');
    });
  });
});
