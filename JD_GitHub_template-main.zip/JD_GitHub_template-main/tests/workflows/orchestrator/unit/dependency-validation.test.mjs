/**
 * @file dependency-validation.test.mjs
 * @description Unit tests for orchestrator workflow dependency management
 *
 * Test Categories (per TESTING_STRATEGY_DECISION_LOG.md):
 * - test-type: simple, simple-edge
 * - technique: unit, regression
 * - security: validation
 */

import { describe, test } from 'node:test';
import assert from 'node:assert/strict';
import { readFile } from 'node:fs/promises';
import YAML from 'yaml';

describe('Orchestrator Workflow - Dependency Validation', () => {
  describe('Issue #202: Dependency Conflict Detection', () => {
    test('should not install @octokit/plugin-retry (unused dependency)', async () => {
      // Given: Read the orchestrator workflow file
      const workflowContent = await readFile('.github/workflows/orchestrator.yml', 'utf8');
      const workflow = YAML.parse(workflowContent);

      // When: Extract all npm install commands
      const installCommands = [];
      for (const [jobName, job] of Object.entries(workflow.jobs)) {
        if (job.steps) {
          for (const step of job.steps) {
            if (step.run && step.run.includes('npm install')) {
              installCommands.push({
                job: jobName,
                stepName: step.name,
                command: step.run,
              });
            }
          }
        }
      }

      // Then: Verify @octokit/plugin-retry is not installed
      for (const cmd of installCommands) {
        assert.ok(
          !cmd.command.includes('@octokit/plugin-retry'),
          `Found @octokit/plugin-retry in ${cmd.job} -> "${cmd.stepName}": ${cmd.command}`
        );
      }
    });

    test('should only install required dependencies', async () => {
      // Given: Read the orchestrator workflow file
      const workflowContent = await readFile('.github/workflows/orchestrator.yml', 'utf8');
      const workflow = YAML.parse(workflowContent);

      // When: Find the execute job's install step
      const executeJob = workflow.jobs.execute;
      assert.ok(executeJob, 'Execute job should exist');

      const installStep = executeJob.steps.find((step) => step.name === 'Install dependencies');
      assert.ok(installStep, 'Install dependencies step should exist');

      // Then: Verify it only installs required packages
      const allowedPackages = ['yaml', '@octokit/core'];
      const installCommand = installStep.run;

      // Check that install command doesn't contain forbidden packages
      const forbiddenPackages = ['@octokit/plugin-retry', '@octokit/plugin-paginate-rest'];
      for (const pkg of forbiddenPackages) {
        assert.ok(!installCommand.includes(pkg), `Install command should not include ${pkg}`);
      }

      // Verify only allowed packages are present (flexible check)
      if (installCommand.includes('npm install')) {
        const match = installCommand.match(/npm install\s+([^\n]+)/);
        if (match) {
          const packages = match[1].trim().split(/\s+/);
          for (const pkg of packages) {
            if (pkg && !pkg.startsWith('-')) {
              // Skip flags
              assert.ok(
                allowedPackages.includes(pkg),
                `Unexpected package in install command: ${pkg}`
              );
            }
          }
        }
      }
    });

    test('should use composite action for Node.js setup (future enhancement)', async () => {
      // This test documents the recommended approach for future refactoring
      // Currently expected to fail, but shows the target state

      const workflowContent = await readFile('.github/workflows/orchestrator.yml', 'utf8');
      const workflow = YAML.parse(workflowContent);

      // Check if ANY job uses the composite action
      let usesCompositeAction = false;

      for (const [_jobName, job] of Object.entries(workflow.jobs)) {
        if (job.steps) {
          for (const step of job.steps) {
            if (step.uses && step.uses.includes('.github/actions/setup-node-deps')) {
              usesCompositeAction = true;
              break;
            }
          }
        }
        if (usesCompositeAction) break;
      }

      // Document current state (not enforcing yet, just documenting)
      if (!usesCompositeAction) {
        console.log(
          'ℹ️  Note: Workflow could be refactored to use .github/actions/setup-node-deps'
        );
        console.log('   This would centralize dependency management and prevent conflicts');
      }

      // This assertion is intentionally lenient - we document the recommendation
      // but don't force it yet
      assert.ok(true, 'Test passes - composite action usage is recommended but not required');
    });
  });

  describe('Dependency Compatibility Matrix', () => {
    test('should verify package.json dependencies match workflow requirements', async () => {
      // Given: Read package.json and workflow file
      const pkgContent = await readFile('package.json', 'utf8');
      const pkg = JSON.parse(pkgContent);

      const workflowContent = await readFile('.github/workflows/orchestrator.yml', 'utf8');

      // When: Check for @octokit/core in both files
      const hasOctokitInPkg = pkg.devDependencies && '@octokit/core' in pkg.devDependencies;
      const hasOctokitInWorkflow = workflowContent.includes('@octokit/core');

      // Then: If workflow uses @octokit/core, it should be in package.json
      if (hasOctokitInWorkflow) {
        assert.ok(
          hasOctokitInPkg,
          '@octokit/core used in workflow but not in package.json devDependencies'
        );

        // Verify version compatibility
        const version = pkg.devDependencies['@octokit/core'];
        assert.ok(version, '@octokit/core version should be specified in package.json');
      }
    });

    test('should not have peer dependency conflicts in package.json', async () => {
      // Given: Read package.json
      const pkgContent = await readFile('package.json', 'utf8');
      const pkg = JSON.parse(pkgContent);

      // When: Check for known conflicting packages
      const hasCoreV6 =
        pkg.devDependencies &&
        pkg.devDependencies['@octokit/core'] &&
        pkg.devDependencies['@octokit/core'].includes('6.');

      const hasRetryV8 =
        pkg.devDependencies &&
        pkg.devDependencies['@octokit/plugin-retry'] &&
        pkg.devDependencies['@octokit/plugin-retry'].includes('8.');

      // Then: Should not have conflicting versions together
      if (hasCoreV6 && hasRetryV8) {
        assert.fail(
          'package.json has conflicting versions: @octokit/core@6.x with @octokit/plugin-retry@8.x ' +
            '(@octokit/plugin-retry@8.x requires @octokit/core >= 7)'
        );
      }

      assert.ok(true, 'No peer dependency conflicts in package.json');
    });
  });

  describe('Node.js Version Consistency', () => {
    test('should use Node.js v20 in all jobs', async () => {
      // Given: Read the orchestrator workflow file
      const workflowContent = await readFile('.github/workflows/orchestrator.yml', 'utf8');
      const workflow = YAML.parse(workflowContent);

      // When: Extract all Node.js setup steps
      const nodeSetups = [];
      for (const [jobName, job] of Object.entries(workflow.jobs)) {
        if (job.steps) {
          for (const step of job.steps) {
            if (step.uses && step.uses.includes('actions/setup-node')) {
              nodeSetups.push({
                job: jobName,
                version: step.with?.['node-version'],
              });
            }
          }
        }
      }

      // Then: Verify all use version 20
      assert.ok(nodeSetups.length > 0, 'Should have at least one Node.js setup step');

      for (const setup of nodeSetups) {
        assert.strictEqual(
          setup.version,
          '20',
          `Job "${setup.job}" should use Node.js v20, got: ${setup.version}`
        );
      }
    });
  });
});
