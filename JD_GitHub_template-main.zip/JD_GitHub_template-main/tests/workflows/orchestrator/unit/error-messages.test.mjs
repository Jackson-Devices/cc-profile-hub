/**
 * @file error-messages.test.mjs
 * @description Unit tests for orchestrator workflow error message quality
 *
 * Test Categories (per TESTING_STRATEGY_DECISION_LOG.md):
 * - test-type: simple, complex
 * - technique: unit, regression
 * - security: validation
 * - artifact: error-taxonomy
 *
 * Requirements from Issue #202:
 * - Error messages must be actionable and specific
 * - No "computer says no" type generic errors
 * - Error messages should include:
 *   - What failed (which stage/job/step)
 *   - Why it failed (actual error message)
 *   - How to debug (logs location, relevant context)
 */

import { describe, test } from 'node:test';
import assert from 'node:assert/strict';
import { readFile } from 'node:fs/promises';
import YAML from 'yaml';

describe('Orchestrator Workflow - Error Message Quality', () => {
  describe('Issue #202: Generic Error Messages', () => {
    test('should not use generic "did not complete successfully" error message', async () => {
      // Given: Read the orchestrator workflow file
      const workflowContent = await readFile('.github/workflows/orchestrator.yml', 'utf8');

      // When: Search for generic error messages
      const _genericErrors = [
        'did not complete successfully',
        'Orchestration did not complete successfully',
        'failed', // Without context
        'error occurred', // Without details
      ];

      // Then: Verify specific error messages are used instead
      // We check that IF a generic message exists, it's accompanied by detailed context
      if (workflowContent.includes('did not complete successfully')) {
        // Check if there's detailed error handling nearby
        const hasDetailedErrorHandling =
          workflowContent.includes('executeResult') ||
          workflowContent.includes('needs.') ||
          workflowContent.includes('result}}');

        if (hasDetailedErrorHandling) {
          // Good: Generic message is used with context variables
          assert.ok(
            true,
            'Generic message is acceptable when combined with detailed context from job results'
          );
        } else {
          assert.fail(
            'Generic error message "did not complete successfully" found without detailed context. ' +
              'Error messages should include what failed, why it failed, and how to debug.'
          );
        }
      }
    });

    test('should include job/stage context in error messages', async () => {
      // Given: Read the orchestrator workflow file
      const workflowContent = await readFile('.github/workflows/orchestrator.yml', 'utf8');
      const workflow = YAML.parse(workflowContent);

      // When: Find all core.setFailed() calls in github-script actions
      const githubScriptSteps = [];
      for (const [jobName, job] of Object.entries(workflow.jobs)) {
        if (job.steps) {
          for (const step of job.steps) {
            if (step.uses && step.uses.includes('github-script')) {
              githubScriptSteps.push({
                job: jobName,
                stepName: step.name,
                script: step.with?.script || '',
              });
            }
          }
        }
      }

      // Then: Verify error messages include context
      for (const step of githubScriptSteps) {
        if (step.script.includes('setFailed')) {
          // Extract setFailed calls
          const setFailedCalls = step.script.match(/core\.setFailed\([^)]+\)/g) || [];

          for (const call of setFailedCalls) {
            // Check if the error message includes context variables or descriptive text
            const hasContext =
              call.includes('${') || // Template literals with variables
              call.includes('phase') || // Phase context
              call.includes('workflow') || // Workflow context
              call.includes('job') || // Job context
              call.includes('step') || // Step context
              call.match(/\b\w+Result\b/) || // Result variables
              call.includes('Failed to'); // Specific failure description

            if (!hasContext) {
              console.warn(
                `⚠️  Potentially generic error in ${step.job} -> "${step.stepName}": ${call}`
              );
            }

            // We log warnings but don't fail - this helps identify areas for improvement
            // In future iterations, we can make this stricter
          }
        }
      }

      assert.ok(true, 'Error message context check complete');
    });

    test('should include error details when workflow execution fails', async () => {
      // Given: Read the orchestrator workflow file
      const workflowContent = await readFile('.github/workflows/orchestrator.yml', 'utf8');

      // When: Check finalize job (which reports overall results)
      const workflow = YAML.parse(workflowContent);
      const finalizeJob = workflow.jobs.finalize;

      assert.ok(finalizeJob, 'Finalize job should exist for error reporting');

      // Then: Verify it checks job results and provides details
      const finalizeScript = finalizeJob.steps.find(
        (step) => step.uses && step.uses.includes('github-script')
      )?.with?.script;

      if (finalizeScript) {
        // Should reference job results
        assert.ok(
          finalizeScript.includes('needs.'),
          'Finalize script should reference job results using needs.'
        );

        assert.ok(finalizeScript.includes('result'), 'Finalize script should check result status');

        // Should have conditional logic for different failure scenarios
        const hasConditionalLogic =
          finalizeScript.includes('if') ||
          finalizeScript.includes('===') ||
          finalizeScript.includes('!==');

        assert.ok(
          hasConditionalLogic,
          'Finalize script should have conditional logic for different scenarios'
        );
      }
    });
  });

  describe('Error Message Best Practices', () => {
    test('should follow error message structure: WHAT + WHY + HOW', async () => {
      // This test documents the expected error message structure
      // Format: "Failed to [WHAT] because [WHY]. To debug: [HOW]"

      const goodExamples = [
        {
          message:
            'Failed to acquire lock for phase validation because another workflow is running. Check workflow runs in the Actions tab.',
          what: 'acquire lock',
          why: 'another workflow is running',
          how: 'Check workflow runs in the Actions tab',
        },
        {
          message:
            'Failed to parse configuration: Invalid YAML syntax at line 10. Review .github/workflow-orchestration.yml',
          what: 'parse configuration',
          why: 'Invalid YAML syntax at line 10',
          how: 'Review .github/workflow-orchestration.yml',
        },
      ];

      const badExamples = [
        'Orchestration did not complete successfully', // No WHAT, WHY, or HOW
        'Failed', // Only WHAT
        'Error occurred', // No details
      ];

      // Document the pattern (this is a specification test)
      assert.ok(goodExamples.length > 0, 'Good error message examples defined');
      assert.ok(badExamples.length > 0, 'Bad error message examples defined for comparison');

      console.log('\n📋 Error Message Pattern Guidelines:');
      console.log('Good examples:');
      goodExamples.forEach((ex) => console.log(`  ✓ ${ex.message}`));
      console.log('\nBad examples:');
      badExamples.forEach((ex) => console.log(`  ✗ ${ex}`));
    });

    test('should have try/catch blocks around critical operations', async () => {
      // Given: Read the orchestrator workflow file
      const workflowContent = await readFile('.github/workflows/orchestrator.yml', 'utf8');

      // When: Check for error handling in github-script actions
      const workflow = YAML.parse(workflowContent);

      let scriptsWithoutErrorHandling = [];

      for (const [jobName, job] of Object.entries(workflow.jobs)) {
        if (job.steps) {
          for (const step of job.steps) {
            if (step.uses && step.uses.includes('github-script')) {
              const script = step.with?.script || '';

              // Check if script has try/catch
              const hasTryCatch = script.includes('try') && script.includes('catch');

              // Check if script has error variable usage (e.g., e.message, error.stack)
              const hasErrorVariable = script.match(/catch\s*\(\s*(\w+)\s*\)/);

              if (hasTryCatch) {
                // Verify error details are logged
                if (hasErrorVariable) {
                  const errorVar = hasErrorVariable[1];
                  const logsErrorDetails =
                    script.includes(`${errorVar}.message`) ||
                    script.includes(`${errorVar}.stack`) ||
                    script.includes(`${errorVar}.toString()`);

                  if (!logsErrorDetails) {
                    scriptsWithoutErrorHandling.push({
                      job: jobName,
                      step: step.name,
                      issue: 'Has try/catch but does not log error details',
                    });
                  }
                }
              } else {
                // Critical operations that should have try/catch
                const isCriticalOperation =
                  script.includes('fs.readFileSync') ||
                  script.includes('YAML.parse') ||
                  script.includes('github.rest.') ||
                  script.includes('fetch(');

                if (isCriticalOperation) {
                  scriptsWithoutErrorHandling.push({
                    job: jobName,
                    step: step.name,
                    issue: 'Critical operation without try/catch',
                  });
                }
              }
            }
          }
        }
      }

      // Report findings
      if (scriptsWithoutErrorHandling.length > 0) {
        console.log('\n⚠️  Scripts needing improved error handling:');
        scriptsWithoutErrorHandling.forEach((item) => {
          console.log(`  - ${item.job} -> "${item.step}": ${item.issue}`);
        });
      }

      // This test documents current state and recommendations
      // We don't fail the test yet, but we highlight areas for improvement
      assert.ok(true, 'Error handling audit complete');
    });
  });

  describe('Error Taxonomy', () => {
    test('should categorize errors by type', async () => {
      // Define error categories per Issue #202 and best practices
      const errorCategories = {
        configuration: [
          'Configuration file not found',
          'Invalid YAML syntax',
          'Missing required configuration key',
        ],
        dependency: [
          'Failed to install dependencies',
          'Peer dependency conflict',
          'Package not found',
        ],
        execution: ['Failed to acquire lock', 'Workflow dispatch failed', 'API call failed'],
        validation: ['Invalid phase name', 'Invalid workflow file', 'Missing required field'],
      };

      // This is a specification test - documents expected error categories
      assert.ok(
        Object.keys(errorCategories).length >= 4,
        'Should define multiple error categories'
      );

      console.log('\n📋 Error Taxonomy:');
      for (const [category, errors] of Object.entries(errorCategories)) {
        console.log(`\n${category.toUpperCase()}:`);
        errors.forEach((err) => console.log(`  - ${err}`));
      }

      assert.ok(true, 'Error taxonomy documented');
    });
  });

  describe('Observability - Error Logging', () => {
    test('should use core.error() for error details before core.setFailed()', async () => {
      // Given: Read the orchestrator workflow file
      const workflowContent = await readFile('.github/workflows/orchestrator.yml', 'utf8');

      // When: Check if error details are logged
      const hasErrorLogging =
        workflowContent.includes('core.error') ||
        workflowContent.includes('core.warning') ||
        workflowContent.includes('console.error');

      // Then: Document current logging approach
      if (!hasErrorLogging) {
        console.log(
          '\nℹ️  Recommendation: Use core.error() to log error details before core.setFailed()'
        );
        console.log('   Example:');
        console.log('     core.error(`Failed to execute workflow: ${e.message}`);');
        console.log('     core.error(`Stack trace: ${e.stack}`);');
        console.log('     core.setFailed(`Failed to execute phase ${phase}: ${e.message}`);');
      }

      assert.ok(true, 'Error logging practices documented');
    });

    test('should write error summary to GITHUB_STEP_SUMMARY', async () => {
      // Given: Read the orchestrator workflow file
      const workflowContent = await readFile('.github/workflows/orchestrator.yml', 'utf8');

      // When: Check if workflow uses GITHUB_STEP_SUMMARY
      const usesSummary = workflowContent.includes('core.summary');

      assert.ok(usesSummary, 'Workflow should use core.summary for user-facing output');

      // Then: Verify it's used in error scenarios (not just success)
      // This is a best practice recommendation
      if (usesSummary) {
        console.log('✓ Workflow uses core.summary for output');
        console.log('  Recommendation: Ensure summary includes error details when failures occur');
      }
    });
  });
});
