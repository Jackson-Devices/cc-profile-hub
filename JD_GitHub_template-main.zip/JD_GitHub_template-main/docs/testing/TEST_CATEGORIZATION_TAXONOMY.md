# Test Categorization Taxonomy

**Version:** 1.0
**Date:** 2025-11-10
**Purpose:** Complete taxonomy for classifying and organizing all tests in the system

---

## Overview

This document defines a comprehensive, multi-dimensional taxonomy for test classification. Tests are categorized across multiple orthogonal dimensions to enable precise filtering, execution planning, and analytics.

---

## Dimension 1: Test Scope (IB/OOB)

**Purpose:** Distinguishes between tests of valid vs. invalid behavior

| Category | Full Name     | Description                                       | Examples                                              |
| -------- | ------------- | ------------------------------------------------- | ----------------------------------------------------- |
| `IB`     | In-Bounds     | Valid inputs that should produce correct behavior | Valid email, buffer within limits, authenticated user |
| `OOB`    | Out-of-Bounds | Invalid/edge inputs that should fail gracefully   | NULL pointer, buffer overflow, unauthenticated access |

**Naming Convention:** `IB-01` through `IB-99`, `OOB-01` through `OOB-99`

**Minimum Requirements:**

- Every test issue must have ≥1 IB case
- Every test issue must have ≥2 OOB cases

**Execution Order:** OOB-01 → IB-01 → OOB-02 → (remaining)

**Rationale:**

- OOB-01: Test boundary at minimum (e.g., empty input)
- IB-01: Test valid baseline (e.g., single valid item)
- OOB-02: Test boundary at maximum (e.g., overflow)

---

## Dimension 2: Test Complexity (test-type labels)

**Purpose:** Classifies behavioral complexity and setup requirements

| Label                     | Description                              | Characteristics                                                                                       |
| ------------------------- | ---------------------------------------- | ----------------------------------------------------------------------------------------------------- |
| `test-type: simple`       | Single behavior, minimal branching       | • One assertion path<br/>• Simple setup<br/>• No dependencies<br/>• Fast execution                    |
| `test-type: simple-edge`  | Narrow edge case, straightforward setup  | • Hard-to-trigger condition<br/>• Simple reproduction<br/>• Clear pass/fail<br/>• Isolated edge       |
| `test-type: complex`      | Multiple assertions, layered setup       | • Combines several checks<br/>• Multi-step setup<br/>• Coordinated components<br/>• Longer execution  |
| `test-type: complex-edge` | Multi-step edge, intricate orchestration | • Unlikely scenarios<br/>• Complex reproduction<br/>• Chained conditions<br/>• High-impact regression |

**Usage Rules:**

- Apply exactly one test-type label per test issue
- Default: `test-type: simple` unless scope clearly advances
- Promote to complex when test relies on chained setups or nested flows
- Reserve edge variants for low-probability triggers or difficult reproduction

**Examples:**

**Simple:**

```
Test: validateEmail("user@example.com") returns SUCCESS
- Single function call
- One assertion
- No setup required
```

**Simple-Edge:**

```
Test: validateEmail with exactly 254 characters (RFC max)
- Edge case: maximum length
- Simple setup: generate 254-char string
- Clear boundary condition
```

**Complex:**

```
Test: User registration flow (email validation + password hash + DB insert + verification email)
- Multiple functions coordinated
- Database setup required
- Email queue verification
- Multi-step assertion chain
```

**Complex-Edge:**

```
Test: Concurrent user registration with same email (race condition)
- Requires thread orchestration
- Timing-dependent
- Database transaction isolation
- Multiple failure scenarios
```

---

## Dimension 3: Test Execution Environment

**Purpose:** Defines isolation level and dependencies

| Category        | Description                              | Characteristics                                                                                    | Examples                   |
| --------------- | ---------------------------------------- | -------------------------------------------------------------------------------------------------- | -------------------------- |
| **Unit**        | Single function/module in isolation      | • No external dependencies<br/>• Mocked I/O<br/>• Fast (<100ms)<br/>• Deterministic                | Function contract tests    |
| **Integration** | Multiple components working together     | • Real dependencies (DB, network)<br/>• Moderate speed (100ms-1s)<br/>• May require setup/teardown | API endpoint + database    |
| **End-to-End**  | Full system from user perspective        | • Real system environment<br/>• Slow (1s+)<br/>• External services                                 | User login flow in browser |
| **Synthetic**   | Simulated environment (no real hardware) | • GitHub Actions compatible<br/>• Mock HAL/hardware<br/>• Compile-time validation                  | Firmware tests without MCU |
| **Hardware**    | Requires actual physical hardware        | • Real MCU/board<br/>• Flash and execute<br/>• Cannot run in CI                                    | GPIO toggle on real STM32  |

**Test Issue Classification:**

- Add to test issue body: `**Environment:** Unit / Integration / E2E / Synthetic / Hardware`
- Enables filtering: "Run all unit tests" vs "Run all E2E tests"

---

## Dimension 4: Test Determinism

**Purpose:** Identifies potential flakiness sources

| Category               | Description                               | Mitigation                      |
| ---------------------- | ----------------------------------------- | ------------------------------- |
| **Deterministic**      | Same input → same output always           | None required                   |
| **Time-Dependent**     | Involves timestamps, timeouts, delays     | Mock clock, fixed timestamps    |
| **Random-Dependent**   | Uses randomness or probabilistic behavior | Fixed seed, determinism kit     |
| **Network-Dependent**  | Makes real network calls                  | Mock network, fixture responses |
| **Hardware-Dependent** | Behavior varies by physical device        | Synthetic testing, mocks        |

**Determinism Kit Requirements:**

- Fixed seed: `0x12345678`
- Mocked timestamps: `2025-01-01T00:00:00Z`
- No real network calls (use mocks)
- No real file I/O (use in-memory FS)

**Test Issue Classification:**

- Add to dependencies section: "Determinism: Fixed seed 0x12345678, mocked DNS"

---

## Dimension 5: Advanced Testing Techniques

**Purpose:** Tracks use of sophisticated testing methodologies

| Technique                        | Description                                              | When to Use                               | Label                   |
| -------------------------------- | -------------------------------------------------------- | ----------------------------------------- | ----------------------- |
| **Property-Based Testing (PBT)** | Generates random inputs, verifies properties always hold | Mathematical invariants, general behavior | `technique: pbt`        |
| **Mutation Testing**             | Alters code, confirms tests detect changes               | Validate test suite strength              | `technique: mutation`   |
| **Contract Testing**             | Validates interface agreements between services          | API integrations, microservices           | `technique: contract`   |
| **Fuzz Testing**                 | Generates malformed inputs to find crashes               | Security, robustness                      | `technique: fuzz`       |
| **Regression Testing**           | Prevents previously fixed bugs from returning            | After bug fixes                           | `technique: regression` |

**Test Issue Classification:**

- Add technique label if using advanced method
- Document in Validation Method section

**Example:**

```markdown
### Validation Method

**Technique:** Property-Based Testing

**Tool:** Hypothesis (Python)

**Property:** For all valid email strings, validateEmail returns SUCCESS
```

---

## Dimension 6: Test Resource Requirements

**Purpose:** Enables smart test scheduling and resource allocation

| Resource    | Category                                   | Description           |
| ----------- | ------------------------------------------ | --------------------- |
| **CPU**     | Low / Medium / High                        | Computation intensity |
| **Memory**  | Low (<100MB) / Medium (<1GB) / High (>1GB) | Memory footprint      |
| **Time**    | Fast (<1s) / Medium (1-10s) / Slow (>10s)  | Execution duration    |
| **Network** | None / Local / External                    | Network dependency    |
| **Storage** | None / Temp / Persistent                   | Disk usage            |

**Test Issue Classification:**

- Add to Dependencies section: "Resources: CPU=Low, Memory=Low, Time=Fast, Network=None"

---

## Dimension 7: Test Coverage Type

**Purpose:** Tracks quality of test coverage

| Coverage Type          | Description                    | Target % |
| ---------------------- | ------------------------------ | -------- |
| **Statement Coverage** | % of code lines executed       | ≥95%     |
| **Branch Coverage**    | % of decision branches tested  | ≥90%     |
| **Path Coverage**      | % of execution paths tested    | ≥80%     |
| **Mutation Coverage**  | % of mutations killed by tests | ≥75%     |

**Test Issue Classification:**

- Add to Validation Method section: "Coverage Target: Statement ≥95%, Branch ≥90%"

---

## Dimension 8: Security Test Classification

**Purpose:** Identifies security-critical tests

| Category             | Description                      | Examples                         |
| -------------------- | -------------------------------- | -------------------------------- |
| **Injection**        | SQL, command, code injection     | Malicious input sanitization     |
| **Authentication**   | Login, session, token validation | JWT verification, session expiry |
| **Authorization**    | Access control, permissions      | RBAC, resource ownership         |
| **Cryptography**     | Encryption, hashing, signatures  | Password hashing, TLS            |
| **Input Validation** | Boundary checks, type validation | Buffer overflow, format strings  |

**Test Issue Classification:**

- Add label: `security: [category]` (e.g., `security: injection`)
- Mandatory for any test validating security properties

---

## Dimension 9: Test Data Classification

**Purpose:** Tracks test data requirements and sensitivity

| Data Type      | Description             | Handling                       |
| -------------- | ----------------------- | ------------------------------ |
| **Synthetic**  | Fake data, no real PII  | Fixtures, generated            |
| **Anonymized** | Real data, scrubbed PII | Secure storage, access control |
| **Production** | Real production data    | NEVER use in tests             |

**Test Issue Classification:**

- Add to Dependencies section: "Test Data: Synthetic (fixtures/valid_emails.txt)"

---

## Complete Test Classification Example

```markdown
### Test ID

T-042

### Purpose

Verify validateEmail correctly handles concurrent calls with same input (thread-safety)

### Test Classification

**Scope:** IB-01 (valid concurrent access)
**Complexity:** Complex-edge (requires thread orchestration)
**Environment:** Integration (real threading, mocked DNS)
**Determinism:** Deterministic (fixed seed, no real network)
**Technique:** Property-Based Testing (verify thread-safety property)
**Resources:** CPU=Medium, Memory=Low, Time=Medium (5s), Network=None
**Coverage:** Statement ≥95%, Branch ≥90%, Mutex coverage 100%
**Security:** N/A
**Data:** Synthetic (generated email strings)

### In-Bounds Case(s) (IB≥1)

- IB-01: 100 concurrent calls with same valid email returns SUCCESS for all threads
  - Input(s): "test@example.com" called by 100 threads simultaneously
  - Steps:
    1. Spawn 100 threads
    2. Each thread calls validateEmail("test@example.com")
    3. Barrier synchronization to maximize concurrency
    4. Collect all return values
  - Expected: All 100 threads return SUCCESS, no race conditions, no data corruption

### Out-of-Bounds Case(s) (OOB≥2 required)

- OOB-01: Concurrent calls with NULL input handled safely
  - Input(s): NULL pointer from 50 threads
  - Steps: 50 threads call validateEmail(NULL) concurrently
  - Expected failure/guard: All return ERROR_NULL_POINTER, no crashes

- OOB-02: Concurrent mixed valid/invalid calls maintain correctness
  - Input(s): Mix of valid emails and invalid formats across 100 threads
  - Steps: 50 threads with valid, 50 with invalid, synchronized start
  - Expected failure/guard: Correct return codes, no cross-contamination

### Validation Method

**Technique:** Property-Based Testing + Concurrency Testing

**Tools:**

- ThreadSanitizer (TSAN) for race detection
- Helgrind (Valgrind tool) for mutex/lock analysis
- Hypothesis for property generation

**Property Under Test:**
```

∀ input, threads: validateEmail(input) is thread-safe
→ No race conditions
→ No data corruption
→ Return value depends only on input, not execution order

````

**Commands:**
```bash
# Compile with ThreadSanitizer
gcc -fsanitize=thread -g -o test_concurrent test_concurrent.c

# Run with TSAN
./test_concurrent

# Run with Helgrind
valgrind --tool=helgrind ./test_concurrent
````

**Determinism:**

- Fixed thread spawn order (deterministic scheduler)
- Fixed input set (no random generation during test)
- Mocked DNS (no real network variability)

**Pass Thresholds:**

- All assertions pass (100/100 threads correct)
- TSAN reports zero data races
- Helgrind reports zero lock-order violations
- No mutex deadlocks
- Execution time <10s (performance requirement)

````

---

## Label Integration Summary

### Existing Labels (from LABEL_DESIGN_SPEC.md)

**Currently Applied:**
- `type: test` - Individual test case
- `test-type: simple | simple-edge | complex | complex-edge` - Complexity
- `validation: pending | passed | failed` - Validation state
- `difficulty: trivial | easy | medium | hard | complex` - Implementation difficulty
- `ai: autonomous | supervised | human+ai | human-only` - AI capability
- `workflow: backlog | ready | in-progress | review | testing | blocked` - Status

### Proposed Additional Labels

**New Security Labels:**
- `security: injection`
- `security: authentication`
- `security: authorization`
- `security: cryptography`
- `security: input-validation`

**New Technique Labels:**
- `technique: pbt` (Property-Based Testing)
- `technique: mutation`
- `technique: contract`
- `technique: fuzz`
- `technique: regression`

**New Environment Labels:**
- `env: unit`
- `env: integration`
- `env: e2e`
- `env: synthetic`
- `env: hardware`

**New Resource Labels** (optional, could use issue body instead):
- `resource: cpu-high`
- `resource: memory-high`
- `resource: slow` (execution >10s)

---

## Usage Guidelines

### Creating a New Test Issue

**1. Choose Work Type** (parent issue)
- Feature, Bug, Improvement, Refactor, Tooling → Create parent issue first

**2. Define Test Classification** (when creating test issue)
- **Required:** Scope (IB/OOB), Complexity (test-type)
- **Recommended:** Environment, Determinism
- **Optional:** Advanced technique, Security category

**3. Apply Labels**
- Auto-applied: `type: test`, `validation: pending`
- Manual: `test-type: [complexity]`
- Conditional: `security: [category]` if security test
- Conditional: `technique: [method]` if using advanced technique

**4. Document Classification**
- Add classification block to test issue body (see example above)
- Ensures searchability and analytics

### Filtering Tests

**By Scope:**
```bash
# Find all IB cases
grep -r "IB-" .github/issues/

# Find all OOB cases
grep -r "OOB-" .github/issues/
````

**By Complexity:**

```bash
# GitHub CLI: Find all simple tests
gh issue list --label "test-type: simple"

# Find all complex-edge tests
gh issue list --label "test-type: complex-edge"
```

**By Environment:**

```bash
# Find all unit tests (requires env labels)
gh issue list --label "env: unit"
```

**By Security:**

```bash
# Find all injection tests
gh issue list --label "security: injection"
```

---

## Analytics and Metrics

### Test Distribution

**Ideal Distribution:**

- IB:OOB ratio = 1:2 (minimum requirement)
- Simple:Complex ratio = 70:30 (most tests should be simple)
- Unit:Integration:E2E ratio = 70:20:10 (test pyramid)

**Query Examples:**

```bash
# Count tests by complexity
gh issue list --label "type: test" --label "test-type: simple" --json number | jq length
gh issue list --label "type: test" --label "test-type: complex" --json number | jq length

# Find slow tests
grep -l "Time=Slow" .github/issues/*/body.md | wc -l

# Find tests requiring hardware
grep -l "Environment: Hardware" .github/issues/*/body.md
```

### Coverage Analysis

**Per Function:**

- Aggregate all tests for a function
- Calculate IB/OOB counts
- Verify minimum requirements met
- Check coverage targets achieved

**Per Feature:**

- Roll up from function → sub-feature → feature
- Report overall coverage percentage
- Identify coverage gaps

---

## Integration with Existing Systems

### Issue Templates

**Current Status:**

- `test.yml` - Exists, but doesn't collect all classification dimensions
- **Needed:** Dropdown fields for environment, technique, security category

### Validation Workflows

**Current Status:**

- `validate-issue.yml` - Validates IB/OOB format and counts
- **Needed:** Validate classification completeness, suggest labels

### Decision Logging

**Current Status:**

- Logs validation attempts and results
- **Needed:** Include test classification in decision logs for analytics

---

## Future Enhancements

### Phase 1: Label Expansion (Immediate)

- Add security labels to LABEL_DESIGN_SPEC.md
- Add technique labels to LABEL_DESIGN_SPEC.md
- Add environment labels to LABEL_DESIGN_SPEC.md

### Phase 2: Template Enhancement (Short-term)

- Add dropdown fields to test.yml for classification
- Create post-creation workflow to apply labels from dropdowns

### Phase 3: Analytics Dashboard (Medium-term)

- Build test analytics using classification data
- Visualize test distribution (complexity, environment, etc.)
- Track coverage trends over time

### Phase 4: Smart Test Execution (Long-term)

- Use resource classification to schedule tests optimally
- Parallelize unit tests, serialize hardware tests
- Skip slow tests in pre-commit, run all in CI

---

**Document Version:** 1.0
**Last Updated:** 2025-11-10
**Author:** Claude (AI)
**Status:** Draft - Ready for Human Review
