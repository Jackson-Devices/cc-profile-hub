# Workflow Testing Framework

**Created:** 2025-11-11
**Purpose:** Prevent workflow-template mismatches (like issue #59) through automated testing

---

## Overview

This document describes the testing framework designed to catch configuration errors in GitHub Actions workflows and issue templates at the earliest possible point.

### The Problem (Issue #59)

**Symptom:** Function issues (labeled `Type: Function`) had no workflows to validate them, resulting in silent failures.

**Root Cause:**

- Issue template `function.yml` auto-applies label `Type: Function`
- BUT no workflow was configured to trigger on that label
- Similarly for `Role: Test-Suite` and `Role: Sub-Feature`

**Impact:** Users creating Function, Test-Suite, or Sub-Feature issues had no automated validation, quality gates, or workflow support.

---

## The Solution: Multi-Layered Testing

### Layer 1: Workflow-Template Consistency Test

**File:** `tests/workflows/test_workflow_template_consistency.mjs`
**Run:** `npm run test:workflow-consistency`

**What it checks:**

1. **Template → Workflow Coverage**
   - Every label auto-applied by an issue template must have at least one workflow that handles it
   - Catches orphaned labels (templates without workflows)

2. **Workflow → Template Coverage** (informational)
   - Reports workflows that filter on labels not auto-applied by templates
   - These are often dynamic labels (like `Validation: Passed`) and are warnings, not errors

**Output:**

```
Check 1: Template labels have workflows
  ✓ "Type: Function" (function.yml) → validate-function.yml
  ✓ "Role: Sub-Feature" (sub-feature.yml) → validate-sub-feature.yml
  ✓ "Role: Test-Suite" (test-suite.yml) → validate-test-suite.yml
  ✓ "Type: Test" (test.yml) → validate-issue.yml, enforce_test_gate.yml, ...

Coverage Report:
  Templates with workflows: 5/5
  Workflows with templates: 5/10

TEST PASSED - All templates have corresponding workflows
```

**How it works:**

1. **Extract template labels** - Parses all `*.yml` files in `.github/ISSUE_TEMPLATE/`
2. **Extract workflow labels** - Searches for `contains(join(github.event.issue.labels.*.name, ','), 'Label Name')` patterns in workflow files
3. **Cross-reference** - Ensures every template label has a workflow handler
4. **Report** - Fails with exit code 1 if any template labels are orphaned

**Prevention:**

- Runs in CI on every PR (TODO: add to CI workflow)
- Catches configuration drift immediately
- Forces developers to either:
  - Add a workflow for new issue types, OR
  - Explicitly document why no workflow is needed

---

## The Fix: Validation Workflows for All Issue Types

### Before (Broken)

| Template        | Label Applied       | Workflow           | Status    |
| --------------- | ------------------- | ------------------ | --------- |
| test.yml        | `Type: Test`        | validate-issue.yml | ✅ Works  |
| function.yml    | `Type: Function`    | _none_             | ❌ Broken |
| test-suite.yml  | `Role: Test-Suite`  | _none_             | ❌ Broken |
| sub-feature.yml | `Role: Sub-Feature` | _none_             | ❌ Broken |

### After (Fixed)

| Template        | Label Applied       | Workflow                 | Status     |
| --------------- | ------------------- | ------------------------ | ---------- |
| test.yml        | `Type: Test`        | validate-issue.yml       | ✅ Works   |
| function.yml    | `Type: Function`    | validate-function.yml    | ✅ **NEW** |
| test-suite.yml  | `Role: Test-Suite`  | validate-test-suite.yml  | ✅ **NEW** |
| sub-feature.yml | `Role: Sub-Feature` | validate-sub-feature.yml | ✅ **NEW** |

---

## New Validation Workflows

### validate-function.yml

**Triggers:** Issues with `Type: Function` label (open, edit, `/validate` command)

**Validates:**

- All required sections present (function name, parent, contract sections)
- Parent Sub-Feature issue is accessible
- Test Suite issue is accessible (if provided)
- Function name includes parameters (e.g., `validate_email(email)`)
- Contract sections have sufficient detail (inputs, outputs, invariants, pre/post conditions)
- Function Ready Gate checkbox tracking

**Output:** Posts validation report with errors, warnings, and passed checks

---

### validate-test-suite.yml

**Triggers:** Issues with `Role: Test-Suite` label (open, edit, `/validate` command)

**Validates:**

- All required sections present (name, parent function, contract summary, test cases)
- Parent Function issue is accessible
- Test case references present (IB ≥ 1, OOB ≥ 2 format)
- Coverage targets documented
- Test strategy defined
- Test Suite Completion Gate tracking

**Output:** Posts validation report

---

### validate-sub-feature.yml

**Triggers:** Issues with `Role: Sub-Feature` label (open, edit, `/validate` command)

**Validates:**

- All required sections present (name, parent feature, acceptance criterion, functions)
- Parent Feature issue is accessible
- Acceptance criterion copied from parent
- Function contracts listed (FN: function_name() format)
- Test coverage requirements defined
- Sub-Feature Ready Gate tracking

**Output:** Posts validation report

---

## Testing Philosophy: Fail Fast, Fail Loud

### Principle 1: Catch Errors at Build Time, Not Runtime

**Bad:**

```
User creates Function issue
  → No workflow runs
  → User waits
  → No validation feedback
  → User doesn't realize issue is orphaned
  → Issue sits incomplete, blocking work
```

**Good:**

```
Developer adds function.yml template
  → npm test runs
  → Test fails: "Type: Function has no workflow"
  → Developer adds validate-function.yml
  → npm test passes
  → PR approved
  → Users get validation from day 1
```

### Principle 2: Automated Tests Prevent Regressions

**Without tests:**

- Someone renames a label in a template
- Forgets to update workflows
- Issue #59 happens again

**With tests:**

- Someone renames a label
- `npm test` fails immediately
- Developer updates workflows or reverts change
- Problem caught before PR merge

### Principle 3: Tests Document Intent

The consistency test serves as **executable documentation**:

- Shows which issue types have workflows
- Shows which labels are auto-applied vs. manual
- Coverage report gives instant visibility into system completeness

---

## Running Tests

### Locally (during development)

```bash
# Run all tests
npm test

# Run only workflow consistency test
npm run test:workflow-consistency

# Run only formatter tests
npm run test:formatters
```

### In CI/CD (TODO)

Add to `.github/workflows/ci.yml`:

```yaml
name: CI Tests

on:
  pull_request:
    branches: [main]
  push:
    branches: [main]

jobs:
  test:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v4
      - uses: actions/setup-node@v4
        with:
          node-version: '20'
      - run: npm install
      - run: npm test
```

**Benefit:** Every PR is automatically checked for workflow-template consistency

---

## Adding New Issue Types: Checklist

When adding a new issue template, follow this checklist to avoid issue #59-type problems:

1. **Create the template** (e.g., `.github/ISSUE_TEMPLATE/new-type.yml`)
2. **Define labels** in template's `labels:` field
3. **Run test:** `npm run test:workflow-consistency`
4. **Test should FAIL** with error: `Label "Your Label" has no workflow`
5. **Create validation workflow** (e.g., `.github/workflows/validate-new-type.yml`)
6. **Add label filter** in workflow: `if: contains(join(github.event.issue.labels.*.name, ','), 'Your Label')`
7. **Run test again:** `npm run test:workflow-consistency`
8. **Test should PASS**
9. **Commit both** template and workflow together

**Golden Rule:** If `npm test` doesn't pass, the PR doesn't get merged.

---

## Test Coverage

### What's Tested

✅ **Template-Workflow Consistency**

- Every template label has a workflow ← **Prevents issue #59**
- Coverage metrics reported

✅ **Formatter Consistency**

- YAML, Markdown, JSON formatting
- House style enforcement

### What's NOT Tested (Yet)

❌ **Workflow Logic** (P2.1 in TODO.md)

- JavaScript code in `github-script` blocks
- State machine transitions
- Label application logic

❌ **Integration Tests** (P2.2 in TODO.md)

- End-to-end workflow chains
- Validation → Enforce → Seed pipeline

❌ **Workflow YAML Syntax** (P2.1 in TODO.md)

- actionlint for workflow syntax
- yamllint for template syntax

---

## Future Enhancements

### Phase 1: CI Integration (Week 1)

- Add `npm test` to GitHub Actions CI
- Block PRs that fail tests
- Add status badge to README

### Phase 2: Workflow Logic Tests (Week 2)

- Extract JavaScript from workflows to modules
- Write unit tests for validation logic
- Test label state machines

### Phase 3: Integration Tests (Week 3)

- Test full workflow chains
- Create test fixtures (valid/invalid issues)
- Verify label transitions

### Phase 4: Mutation Testing (Week 4)

- Introduce intentional bugs
- Verify tests catch them
- Measure test effectiveness

---

## Related Documents

- **TODO.md P2.1:** Unit Test Framework Setup (includes actionlint/yamllint)
- **TODO.md P2.2:** Integration Tests
- **REVIEW_FINDINGS.md Section 6:** GitHub Actions Testing Infrastructure Gaps
- **.github/workflows/validate-\*.yml:** Implementation of validation workflows

---

## Lessons Learned from Issue #59

### What Went Wrong

1. Templates and workflows were created independently
2. No automated check for template-workflow consistency
3. Issue type was added without considering validation needs
4. Problem wasn't discovered until users tried to use the feature

### What We Fixed

1. ✅ Created automated consistency test
2. ✅ Added validation workflows for all issue types
3. ✅ Integrated tests into `npm test`
4. ✅ Documented the testing framework
5. 🔄 TODO: Add to CI pipeline

### Prevention Strategy

- **Never** add a template without a corresponding workflow
- **Always** run `npm test` before committing template changes
- **Require** test passage for PR approval
- **Document** the relationship between templates and workflows

---

## Conclusion

The Workflow Testing Framework ensures that configuration errors like issue #59 are caught immediately during development, not discovered by users in production. By making `npm test` a required step in the development workflow, we prevent workflow-template mismatches from ever reaching main.

**Key Principle:** If a test doesn't exist to catch a class of bugs, those bugs WILL happen. Issue #59 is proof. The testing framework is our insurance policy.

---

**Last Updated:** 2025-11-11
**Maintainer:** Claude (AI)
**Status:** Active, integrated into `npm test`
