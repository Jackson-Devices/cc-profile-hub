# GitHub Actions Testing & Synthetic Testing Research Report

**Date:** 2025-11-09
**Project:** JD_GitHub_template
**Focus:** Testing automation infrastructure, workflows, and validation systems

---

## Executive Summary

This report compiles best practices for testing GitHub Actions workflows and automation infrastructure based on current industry standards (2024-2025). The research covers local testing frameworks, synthetic testing strategies, minimal test rig patterns, and AI-assisted testing approaches.

**Key Findings:**

- **act** is the industry-standard tool for local GitHub Actions testing
- **actionlint** provides comprehensive workflow validation with security checks
- **Bats** offers robust bash script testing for workflow scripts
- Progressive test enhancement is preferred over comprehensive up-front testing
- AI-assisted testing focuses on context-aware, self-documenting patterns

---

## 1. GitHub Actions Testing Frameworks

### 1.1 act - Local GitHub Actions Runner

**Repository:** https://github.com/nektos/act
**Purpose:** Run GitHub Actions workflows locally using Docker containers
**Status:** Industry standard, actively maintained, 50k+ stars

#### Key Features

- Simulates GitHub Actions runner environment using Docker
- Supports multiple runner images:
  - **Micro** (~200MB): Basic Alpine-based image
  - **Medium** (~500MB): catthehacker/ubuntu:act-latest (recommended)
  - **Large** (~20GB): Full GitHub-hosted runner equivalent
- No dependency on GitHub API for basic workflow execution
- Immediate feedback without commit-push cycles
- Zero GitHub Actions minutes consumed

#### Installation

```bash
# macOS/Linux
brew install act

# Windows (via Chocolatey)
choco install act-cli

# Or download from GitHub releases
```

#### Basic Usage

```bash
# Run default workflow
act

# Run specific event
act push
act pull_request
act issue_comment

# Run specific job
act -j test

# Dry run (list what would run)
act -n

# Use specific workflow
act -W .github/workflows/validate-issue.yml
```

#### Advanced Features

```bash
# Pass secrets
act -s GITHUB_TOKEN=<token>

# Use secrets file
act --secret-file .secrets

# Pass environment variables
act --env VAR_NAME=value

# Use specific runner image
act -P ubuntu-latest=catthehacker/ubuntu:act-latest

# Verbose output
act -v

# Bind workspace to specific directory
act --bind
```

#### Limitations

- Some GitHub-specific features not fully supported:
  - GitHub API rate limits may apply for API calls
  - Some Actions marketplace actions may behave differently
  - OIDC token generation not available
  - Some context variables may differ

#### Documentation

- **Official Docs:** https://nektosact.com/
- **GitHub Repo:** https://github.com/nektos/act
- **Tutorial:** https://www.infralovers.com/blog/2024-08-14-github-actions-locally/
- **VS Code Extension:** GitHub Local Actions (leverages act)

---

### 1.2 actionlint - Workflow Static Analysis

**Repository:** https://github.com/rhysd/actionlint
**Official Site:** https://rhysd.github.io/actionlint/
**Purpose:** Static checker specifically for GitHub Actions workflows

#### Key Features

- **Type checking for expressions:** Validates `${{ }}` expressions for type safety
- **Actions validation:** Checks inputs at `with:` and outputs in steps
- **Shell script integration:** Built-in shellcheck and pyflakes for `run:` scripts
- **Security scanning:**
  - Script injection detection from untrusted inputs
  - Hard-coded credentials detection
  - Permission misconfigurations
- **Semantic validation:** Context-aware checks beyond YAML syntax
- **Fast execution:** Designed for CI/CD pipelines

#### Installation

```bash
# macOS
brew install actionlint

# Linux
bash <(curl https://raw.githubusercontent.com/rhysd/actionlint/main/scripts/download-actionlint.bash)

# Windows
choco install actionlint

# Go install
go install github.com/rhysd/actionlint/cmd/actionlint@latest
```

#### Usage

```bash
# Check all workflows
actionlint

# Check specific workflow
actionlint .github/workflows/validate-issue.yml

# Output in specific format
actionlint -format '{{range $err := .}}{{$err.Message}}{{end}}'

# JSON output for tooling integration
actionlint -format '{{json .}}'

# Ignore specific rules
actionlint -ignore 'SC2086:' # Ignore shellcheck SC2086
```

#### Example Checks

```yaml
# actionlint will catch these issues:

# 1. Type mismatch
steps:
  - run: echo ${{ needs.build.outputs.count + 'hello' }}
    # Error: Cannot add number and string

# 2. Invalid action input
- uses: actions/checkout@v4
  with:
    invalid_input: value
    # Error: Unknown input 'invalid_input'

# 3. Script injection risk
- run: echo "${{ github.event.issue.title }}"
  # Warning: Potential script injection from untrusted input

# 4. Missing required input
- uses: actions/upload-artifact@v3
  # Error: Missing required input 'name'
```

#### GitHub Action Integration

```yaml
name: Lint Workflows
on: [push, pull_request]

jobs:
  actionlint:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v4

      - name: Run actionlint
        uses: ryo-rm/actionlint-action@v1
        # or use direct installation

      - name: actionlint (manual)
        run: |
          bash <(curl https://raw.githubusercontent.com/rhysd/actionlint/main/scripts/download-actionlint.bash)
          ./actionlint -color
```

#### Configuration

Create `.github/actionlint.yml`:

```yaml
# Configuration file for actionlint
self-hosted-runner:
  labels:
    - my-runner-*

  # Disable specific checks
  shellcheck:
    enable: true
    exclude:
      - SC2086
      - SC2002
```

---

### 1.3 yamllint - YAML Validation

**Repository:** https://github.com/adrienverge/yamllint
**Purpose:** General YAML syntax and style validation

#### Key Features

- Pre-installed on GitHub-hosted Ubuntu runners
- Validates YAML syntax
- Enforces style consistency
- Configurable rules

#### Usage

```bash
# Validate all YAML files
yamllint .

# Validate specific directory
yamllint .github/workflows/

# Use custom config
yamllint -c .yamllint.yml .
```

#### GitHub Actions Integration

```yaml
name: YAML Lint
on: [push, pull_request]

jobs:
  yamllint:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v4

      - name: Validate YAML
        run: yamllint .github/workflows/
```

#### Configuration (.yamllint.yml)

```yaml
extends: default

rules:
  line-length:
    max: 120
    level: warning
  indentation:
    spaces: 2
    indent-sequences: true
  comments:
    min-spaces-from-content: 1
```

---

### 1.4 action-validator

**Repository:** https://github.com/mpalmer/action-validator
**Purpose:** Schema-based validation for GitHub Actions

#### Key Features

- Validates against official JSON schemas
- Checks glob patterns in `paths`/`paths-ignore`
- Ensures globs match at least one file
- Ideal for pre-commit hooks

#### Usage

```bash
# Validate all workflows
action-validator

# Use in pre-commit hook
# .pre-commit-config.yaml
repos:
  - repo: https://github.com/mpalmer/action-validator
    rev: v0.5.3
    hooks:
      - id: action-validator
```

---

### 1.5 wrkflw - Workflow Execution Tool

**Features:**

- Validates workflows without Docker dependency
- Executes workflows locally
- Lightweight alternative to act for validation-only use cases

---

### 1.6 github-action-ts-run-api

**Repository:** Multiple TypeScript testing libraries
**Purpose:** Unit testing for JavaScript/TypeScript actions
**Documentation:** https://cardinalby.github.io/blog/post/github-actions/testing/

#### Features

- JavaScript/TypeScript API for running actions
- Works with any JS test framework (Jest, Mocha, etc.)
- Mock GitHub context and events
- Stub external API calls
- Integration test support

#### Example

```typescript
import { runAction } from 'github-action-ts-run-api';

describe('My Action', () => {
  it('should process issue correctly', async () => {
    const result = await runAction({
      actionPath: './action.yml',
      inputs: {
        token: 'fake-token',
      },
      env: {
        GITHUB_EVENT_NAME: 'issues',
        GITHUB_EVENT_PATH: './test-events/issue-opened.json',
      },
    });

    expect(result.exitCode).toBe(0);
    expect(result.outputs.status).toBe('success');
  });
});
```

---

## 2. Synthetic Testing Strategies

### 2.1 Mock/Stub Strategies for GitHub API

#### 2.1.1 mock-github Library

**Repository:** https://github.com/kiegroup/mock-github
**Purpose:** Create local GitHub environment for testing custom actions

#### Features

- Configurable local GitHub environment
- Mock octokit using octokit-like interface
- Avoid API rate limits
- No test repository clutter
- Full control over responses

#### Example

```javascript
const { MockGitHub } = require('mock-github');

const mockGH = new MockGitHub({
  repo: {
    owner: 'test-org',
    repo: 'test-repo',
  },
});

// Mock issue creation
mockGH.mockEndpoint('POST /repos/:owner/:repo/issues', {
  status: 201,
  data: {
    number: 123,
    title: 'Test Issue',
    labels: [{ name: 'type: test' }],
  },
});

// Run your action/workflow logic
const result = await createIssue('Test Issue');
expect(result.number).toBe(123);
```

---

#### 2.1.2 Nock for HTTP Mocking

**Repository:** https://github.com/nock/nock
**Purpose:** HTTP request mocking for Node.js

```javascript
const nock = require('nock');

// Mock GitHub API responses
nock('https://api.github.com')
  .get('/repos/owner/repo/issues/123')
  .reply(200, {
    number: 123,
    title: 'Test Issue',
    body: 'Test body',
    labels: [{ name: 'type: test' }],
  });

// Your workflow logic using octokit
const issue = await octokit.issues.get({
  owner: 'owner',
  repo: 'repo',
  issue_number: 123,
});

expect(issue.data.title).toBe('Test Issue');
```

---

### 2.2 Testing Label Validation Logic

#### Strategy: Extract and Unit Test

For workflows like `validate-issue.yml`, extract validation logic into testable modules:

**Structure:**

```
.github/
  actions/
    validate-issue/
      action.yml
      src/
        validators/
          labelValidator.js
          formatValidator.js
          yamlValidator.js
        index.js
      tests/
        validators/
          labelValidator.test.js
          formatValidator.test.js
          yamlValidator.test.js
```

**Example Test:**

```javascript
// tests/validators/labelValidator.test.js
const { validateLabels } = require('../../src/validators/labelValidator');

describe('Label Validator', () => {
  test('should require type: test label', () => {
    const labels = ['priority: high', 'status: open'];
    const result = validateLabels(labels);

    expect(result.valid).toBe(false);
    expect(result.errors).toContain('Missing required label: type: test');
  });

  test('should accept valid label combination', () => {
    const labels = ['type: test', 'priority: high'];
    const result = validateLabels(labels);

    expect(result.valid).toBe(true);
    expect(result.errors).toHaveLength(0);
  });

  test('should reject invalid label format', () => {
    const labels = ['type:test']; // Missing space after colon
    const result = validateLabels(labels);

    expect(result.valid).toBe(false);
    expect(result.errors).toContain('Invalid label format: type:test');
  });
});
```

---

### 2.3 Testing Workflow Orchestration

#### Strategy: Integration Tests with Self-Testing Workflows

**Approach:** Use GitHub Actions to test GitHub Actions

```yaml
name: Test Validate Issue Workflow

on:
  pull_request:
    paths:
      - '.github/workflows/validate-issue.yml'
      - '.github/actions/validate-issue/**'

jobs:
  test-validation:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v4

      # Create test issue
      - name: Create test issue
        id: create-issue
        uses: actions/github-script@v7
        with:
          script: |
            const { data: issue } = await github.rest.issues.create({
              owner: context.repo.owner,
              repo: context.repo.repo,
              title: '[TEST] Validation test',
              body: '${{ steps.load-template.outputs.body }}',
              labels: ['type: test', 'test-automation']
            });
            return issue.number;

      # Run validation workflow
      - name: Trigger validation
        uses: ./.github/workflows/validate-issue.yml
        with:
          issue_number: ${{ steps.create-issue.outputs.result }}

      # Verify results
      - name: Check validation results
        uses: actions/github-script@v7
        with:
          script: |
            const issue = await github.rest.issues.get({
              owner: context.repo.owner,
              repo: context.repo.repo,
              issue_number: ${{ steps.create-issue.outputs.result }}
            });

            const hasBlockedLabel = issue.data.labels.some(
              l => l.name === 'validation: blocked'
            );

            if (hasBlockedLabel) {
              core.setFailed('Expected validation to pass, but found blocked label');
            }

      # Cleanup
      - name: Close test issue
        if: always()
        uses: actions/github-script@v7
        with:
          script: |
            await github.rest.issues.update({
              owner: context.repo.owner,
              repo: context.repo.repo,
              issue_number: ${{ steps.create-issue.outputs.result }},
              state: 'closed'
            });
```

---

### 2.4 Testing Logging and Decision Recording

**Strategy:** Validate log file structure and content

```javascript
// tests/logging/decisionLogger.test.js
const fs = require('fs').promises;
const { logDecision } = require('../../src/logging/decisionLogger');

describe('Decision Logger', () => {
  const testLogPath = './__test_logs__/test_decision_log.md';

  beforeEach(async () => {
    await fs.mkdir('./__test_logs__', { recursive: true });
  });

  afterEach(async () => {
    await fs.rm('./__test_logs__', { recursive: true, force: true });
  });

  test('should create new log file with correct structure', async () => {
    await logDecision({
      logPath: testLogPath,
      issueNumber: 123,
      passNumber: 1,
      status: 'Success',
      workflowName: 'Test Workflow',
      triggerEvent: 'issues',
      committerName: 'test-user',
    });

    const content = await fs.readFile(testLogPath, 'utf8');

    expect(content).toContain('# Decision Log: Issue #123');
    expect(content).toContain('## Pass 1:');
    expect(content).toContain('**Status:** Success');
    expect(content).toContain('**Workflow:** Test Workflow');
  });

  test('should append to existing log file', async () => {
    // First pass
    await logDecision({
      logPath: testLogPath,
      issueNumber: 123,
      passNumber: 1,
      status: 'Failed',
    });

    // Second pass
    await logDecision({
      logPath: testLogPath,
      issueNumber: 123,
      passNumber: 2,
      status: 'Success',
    });

    const content = await fs.readFile(testLogPath, 'utf8');

    expect(content).toContain('## Pass 1:');
    expect(content).toContain('## Pass 2:');
  });

  test('should sanitize committer name', async () => {
    await logDecision({
      logPath: testLogPath,
      issueNumber: 123,
      passNumber: 1,
      committerName: '../../../malicious',
    });

    const content = await fs.readFile(testLogPath, 'utf8');

    expect(content).not.toContain('../../../');
  });
});
```

---

### 2.5 Testing Code Formatters and Linters

#### Strategy: Snapshot Testing

```javascript
// tests/formatters/yamlFormatter.test.js
const { formatYaml } = require('../../src/formatters/yamlFormatter');

describe('YAML Formatter', () => {
  test('should format workflow correctly', () => {
    const input = `
name: Test
on:push
jobs:test:runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v4
    `;

    const result = formatYaml(input);

    expect(result).toMatchSnapshot();
  });

  test('should preserve comments', () => {
    const input = `
# Important comment
name: Test
# Another comment
on: push
    `;

    const result = formatYaml(input);

    expect(result).toContain('# Important comment');
    expect(result).toContain('# Another comment');
  });

  test('should fix indentation', () => {
    const input = `
jobs:
 test:
   runs-on: ubuntu-latest
       steps:
     - run: echo test
    `;

    const result = formatYaml(input);

    expect(result).toContain('  test:');
    expect(result).toContain('    runs-on: ubuntu-latest');
    expect(result).toContain('    steps:');
    expect(result).toContain('      - run: echo test');
  });
});
```

---

### 2.6 Datadog Synthetic Testing Integration

**Reference:** https://www.datadoghq.com/blog/datadog-github-action-synthetics-ci-visibility/

For production-grade synthetic testing of deployed workflows:

```yaml
name: Synthetic Tests

on:
  schedule:
    - cron: '0 */6 * * *' # Every 6 hours
  workflow_dispatch:

jobs:
  synthetic-tests:
    runs-on: ubuntu-latest
    steps:
      - name: Run Datadog Synthetic Tests
        uses: DataDog/synthetics-ci-github-action@v1
        with:
          api_key: ${{ secrets.DATADOG_API_KEY }}
          app_key: ${{ secrets.DATADOG_APP_KEY }}
          public_ids: 'abc-def-ghi' # Your synthetic test IDs


      # Tests execute against live environment
      # Results appear in Datadog CI Results Explorer
```

---

## 3. Minimal Test Rig Patterns

### 3.1 Progressive Test Enhancement Strategy

**Philosophy:** Start small, build confidence, scale gradually

#### Phase 1: Static Analysis Only (Week 1)

**Goal:** Catch syntax errors and basic issues

```yaml
name: Minimal Test Rig - Phase 1

on: [push, pull_request]

jobs:
  static-analysis:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v4

      # YAML syntax validation
      - name: Validate YAML
        run: yamllint .github/workflows/

      # GitHub Actions specific validation
      - name: Run actionlint
        run: |
          bash <(curl https://raw.githubusercontent.com/rhysd/actionlint/main/scripts/download-actionlint.bash)
          ./actionlint -color
```

**Benefits:**

- Zero infrastructure setup
- Fast feedback (< 1 minute)
- Catches 60-70% of common errors
- No test data needed

---

#### Phase 2: Add Unit Tests (Week 2-3)

**Goal:** Test extracted logic in isolation

```
tests/
  unit/
    validators.test.js
    formatters.test.js
    parsers.test.js
  package.json
```

```yaml
name: Minimal Test Rig - Phase 2

on: [push, pull_request]

jobs:
  static-analysis:
    # ... same as Phase 1 ...

  unit-tests:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v4

      - name: Setup Node.js
        uses: actions/setup-node@v4
        with:
          node-version: '20'
          cache: 'npm'
          cache-dependency-path: tests/package-lock.json

      - name: Install dependencies
        run: npm ci
        working-directory: tests

      - name: Run unit tests
        run: npm test
        working-directory: tests
```

**Test Organization:**

```json
// tests/package.json
{
  "name": "workflow-tests",
  "scripts": {
    "test": "jest --coverage",
    "test:watch": "jest --watch",
    "test:ci": "jest --ci --coverage --maxWorkers=2"
  },
  "devDependencies": {
    "jest": "^29.7.0",
    "@actions/core": "^1.10.1",
    "@actions/github": "^6.0.0",
    "nock": "^13.5.0"
  }
}
```

---

#### Phase 3: Local Workflow Testing (Week 3-4)

**Goal:** Run workflows locally before pushing

```bash
# Install act
brew install act

# Create act configuration
cat > .actrc << EOF
-P ubuntu-latest=catthehacker/ubuntu:act-latest
--secret-file .secrets.local
--env-file .env.local
EOF

# Create minimal test secrets
cat > .secrets.local << EOF
GITHUB_TOKEN=test_token_12345
EOF

# Test workflow locally
act -j validate-issue -n  # Dry run first
act -j validate-issue     # Actually run
```

**Add to workflow:**

```yaml
local-test-validation:
  runs-on: ubuntu-latest
  steps:
    - uses: actions/checkout@v4

    - name: Test with act
      run: |
        curl -s https://raw.githubusercontent.com/nektos/act/master/install.sh | bash
        ./bin/act -j static-analysis -n
```

---

#### Phase 4: Integration Tests (Week 4-6)

**Goal:** Test workflow interactions and orchestration

```yaml
integration-tests:
  runs-on: ubuntu-latest
  steps:
    - uses: actions/checkout@v4

    # Create test fixtures
    - name: Setup test environment
      run: |
        mkdir -p test-fixtures/issues
        cp tests/fixtures/valid-issue.md test-fixtures/issues/

    # Run actual workflow against test data
    - name: Test validation workflow
      uses: ./.github/workflows/validate-issue.yml
      with:
        issue_number: 1
        dry_run: true

    # Verify outputs
    - name: Verify results
      run: |
        test -f .ai_logs/issue_0001_decision_log.md
        grep -q "Validation Passed" .ai_logs/issue_0001_decision_log.md
```

---

#### Phase 5: Continuous Monitoring (Ongoing)

**Goal:** Detect regressions and performance issues

```yaml
name: Continuous Testing

on:
  schedule:
    - cron: '0 0 * * *' # Daily
  workflow_dispatch:

jobs:
  regression-suite:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v4

      - name: Run full test suite
        run: |
          npm test -- --testPathPattern=tests/integration
          npm test -- --testPathPattern=tests/e2e

      - name: Performance benchmarks
        run: |
          time act -j validate-issue
          time act -j seed-test-runlist

      - name: Generate test report
        if: always()
        uses: actions/upload-artifact@v4
        with:
          name: test-results
          path: |
            test-results/
            coverage/
```

---

### 3.2 Barebones CI Test Setup

**Minimal starter for any project:**

```yaml
# .github/workflows/test.yml
name: Test

on: [push, pull_request]

jobs:
  test:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v4
      - run: yamllint .github/ || true
      - run: |
          bash <(curl https://raw.githubusercontent.com/rhysd/actionlint/main/scripts/download-actionlint.bash)
          ./actionlint || true
```

**Characteristics:**

- Single file
- No external dependencies (uses curl)
- Non-blocking (uses `|| true` initially)
- Can be enhanced incrementally

---

### 3.3 Test Organization for Growing Projects

**Recommended structure:**

```
.github/
  workflows/
    test-workflows.yml          # Main test orchestrator
    test-unit.yml               # Unit tests only
    test-integration.yml        # Integration tests
    test-validation.yml         # Static analysis
  actions/
    test-helpers/               # Reusable test actions
      setup-test-env/
      create-test-issue/
      verify-logs/

tests/
  unit/                         # Fast, isolated tests
    validators/
    formatters/
    parsers/
  integration/                  # Workflow interaction tests
    validate-issue.test.js
    decision-logging.test.js
  e2e/                          # Full workflow tests
    complete-test-cycle.test.js
  fixtures/                     # Test data
    issues/
      valid-test.md
      invalid-test.md
      edge-cases/
    workflows/
      minimal.yml
      complex.yml
  helpers/                      # Test utilities
    github-mock.js
    fixture-loader.js

  package.json                  # Test dependencies
  jest.config.js                # Test configuration
  .testenv                      # Test environment vars
```

**Key principles:**

1. **Separate by speed:** Unit tests run in seconds, integration in minutes
2. **Fixtures as documentation:** Test data shows expected formats
3. **Helpers reduce duplication:** Shared utilities across tests
4. **Clear naming:** `*.test.js` for tests, `*.fixture.md` for data

---

## 4. Bash Script Testing with Bats

### 4.1 Bats Overview

**Repository:** https://github.com/bats-core/bats-core
**Documentation:** https://bats-core.readthedocs.io
**Purpose:** Bash Automated Testing System

#### Installation

```bash
# macOS
brew install bats-core

# Linux
git clone https://github.com/bats-core/bats-core.git
cd bats-core
sudo ./install.sh /usr/local

# npm
npm install -g bats
```

---

### 4.2 Basic Bats Syntax

```bash
#!/usr/bin/env bats

# tests/validation.bats

@test "issue body contains required sections" {
  run grep "### Test ID" fixtures/valid-issue.md
  [ "$status" -eq 0 ]
}

@test "IB cases have correct format" {
  run grep -E "- IB-[0-9]{2}" fixtures/valid-issue.md
  [ "$status" -eq 0 ]
  [ "${#lines[@]}" -ge 1 ]
}

@test "validation script detects missing sections" {
  run bash scripts/validate.sh fixtures/invalid-issue.md
  [ "$status" -eq 1 ]
  [[ "$output" =~ "Missing required section" ]]
}
```

---

### 4.3 Bats Helper Libraries

```bash
# tests/test_helper.bash
load '/usr/local/lib/bats-support/load.bash'
load '/usr/local/lib/bats-assert/load.bash'
load '/usr/local/lib/bats-file/load.bash'

setup() {
  # Run before each test
  TEST_TEMP_DIR="$(temp_make)"
  export GITHUB_WORKSPACE="$TEST_TEMP_DIR"
}

teardown() {
  # Run after each test
  temp_del "$TEST_TEMP_DIR"
}
```

```bash
#!/usr/bin/env bats

load test_helper

@test "creates decision log file" {
  run bash scripts/create-decision-log.sh 123

  assert_success
  assert_file_exists "$GITHUB_WORKSPACE/.ai_logs/issue_0123_decision_log.md"
  assert_file_contains "$GITHUB_WORKSPACE/.ai_logs/issue_0123_decision_log.md" "# Decision Log: Issue #123"
}

@test "validates YAML frontmatter" {
  run bash scripts/validate-yaml.sh fixtures/test-with-yaml.md

  assert_success
  assert_output --partial "YAML valid"
}

@test "rejects malformed YAML" {
  run bash scripts/validate-yaml.sh fixtures/malformed-yaml.md

  assert_failure
  assert_output --partial "YAML parse error"
}
```

---

### 4.4 Bats with GitHub Actions

```yaml
name: Bash Script Tests

on: [push, pull_request]

jobs:
  bats-tests:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v4

      - name: Install Bats
        run: |
          git clone https://github.com/bats-core/bats-core.git
          cd bats-core
          sudo ./install.sh /usr/local

      - name: Install Bats helpers
        run: |
          git clone https://github.com/bats-core/bats-support test/test_helper/bats-support
          git clone https://github.com/bats-core/bats-assert test/test_helper/bats-assert
          git clone https://github.com/bats-core/bats-file test/test_helper/bats-file

      - name: Run Bats tests
        run: bats tests/**/*.bats

      # Alternative: Use pre-built action
      - name: Run Bats (alternative)
        uses: ffurrer2/bats-action@v2
        with:
          bats-args: tests
```

---

### 4.5 Testing Workflow Scripts

**Example: Test a workflow helper script**

```bash
# .github/scripts/parse-issue-body.sh
#!/bin/bash
set -euo pipefail

# Extract Test ID from issue body
extract_test_id() {
  local body="$1"
  echo "$body" | grep -oP '### Test ID\s*\n+\K.+' | head -1
}

# Extract IB cases
extract_ib_cases() {
  local body="$1"
  echo "$body" | grep -oP '- \K(IB-\d{2})' | sort -u
}

# Main
if [ $# -eq 0 ]; then
  echo "Usage: $0 <issue-body-file>"
  exit 1
fi

BODY=$(cat "$1")
TEST_ID=$(extract_test_id "$BODY")
IB_CASES=$(extract_ib_cases "$BODY")

echo "Test ID: $TEST_ID"
echo "IB Cases: $IB_CASES"
```

**Bats test:**

```bash
#!/usr/bin/env bats

load test_helper

setup() {
  SCRIPT=".github/scripts/parse-issue-body.sh"
  FIXTURE_DIR="tests/fixtures/issues"
}

@test "extract_test_id: valid test ID" {
  run bash "$SCRIPT" "$FIXTURE_DIR/valid-issue.md"

  assert_success
  assert_line --partial "Test ID: T-001"
}

@test "extract_test_id: missing test ID" {
  run bash "$SCRIPT" "$FIXTURE_DIR/missing-test-id.md"

  assert_success
  assert_line --partial "Test ID: "
}

@test "extract_ib_cases: finds all IB cases" {
  run bash "$SCRIPT" "$FIXTURE_DIR/multiple-ib-cases.md"

  assert_success
  assert_line --partial "IB Cases: IB-01"
  assert_line --partial "IB-02"
  assert_line --partial "IB-03"
}

@test "extract_ib_cases: deduplicates IB cases" {
  cat > "$TEST_TEMP_DIR/duplicate-ib.md" << 'EOF'
### In-Bounds Case(s) (IB≥1)

- IB-01: Test case
- IB-01: Same test case again
- IB-02: Different case
EOF

  run bash "$SCRIPT" "$TEST_TEMP_DIR/duplicate-ib.md"

  assert_success
  [ $(echo "$output" | grep -c "IB-01") -eq 1 ]
}

@test "script fails with no arguments" {
  run bash "$SCRIPT"

  assert_failure
  assert_output --partial "Usage:"
}

@test "script handles missing file gracefully" {
  run bash "$SCRIPT" "/nonexistent/file.md"

  assert_failure
}
```

---

## 5. AI-Assisted Testing Best Practices

### 5.1 Context-Aware Test Generation

**Key Principle:** Provide rich context for AI to understand intent

#### Good Example: Self-Documenting Test

```javascript
/**
 * Issue Validation Tests
 *
 * Context: The validate-issue workflow checks GitHub issue bodies against
 * the test.yml template. It must verify:
 * - All required sections present
 * - Test ID format: T-XXX (3+ digits)
 * - IB cases: IB-01 to IB-99 (≥1 required)
 * - OOB cases: OOB-01 to OOB-99 (≥2 required)
 * - Validation gate checkbox present
 *
 * Failure modes to test:
 * - Missing sections
 * - Invalid formats
 * - Insufficient test cases
 * - Inaccessible parent/suite issues
 */

describe('Issue Validation', () => {
  /**
   * Test: Required sections must all be present
   *
   * Given: Issue body from test.yml template
   * When: Body is missing the "Purpose" section
   * Then: Validation should fail with specific error message
   */
  test('should reject issue missing required section', async () => {
    const issueBody = loadFixture('issues/missing-purpose.md');

    const result = await validateIssue(issueBody);

    expect(result.valid).toBe(false);
    expect(result.errors).toContainEqual(
      expect.objectContaining({
        code: 'MISSING_SECTION',
        section: 'Purpose',
      })
    );
  });

  /**
   * Test: Test ID must match T-XXX format
   *
   * Edge cases:
   * - T-1 (too short) → invalid
   * - T-001 (valid minimum) → valid
   * - T-999 (valid) → valid
   * - T-1234 (4+ digits) → valid
   * - TEST-001 (wrong prefix) → invalid
   * - T-01A (non-numeric) → invalid
   */
  test.each([
    ['T-1', false, 'too short'],
    ['T-001', true, 'valid minimum'],
    ['T-999', true, 'valid 3-digit'],
    ['T-1234', true, 'valid 4-digit'],
    ['TEST-001', false, 'wrong prefix'],
    ['T-01A', false, 'non-numeric'],
  ])('Test ID format: %s should be %s (%s)', async (testId, shouldBeValid, reason) => {
    const issueBody = createIssueWithTestId(testId);

    const result = await validateTestId(issueBody);

    expect(result.valid).toBe(shouldBeValid);
  });
});
```

**Why this works for AI:**

- Clear purpose statement at top
- Explicit context about workflow behavior
- Edge cases enumerated with rationale
- Given-When-Then structure
- Descriptive test names
- Inline documentation

---

### 5.2 Test Organization for AI Understanding

#### Pattern: Feature-Based Organization with Context

```
tests/
  issue-validation/
    README.md                 # Workflow purpose, dependencies, edge cases
    validators/
      section-validator/
        README.md             # What sections are required and why
        section-validator.test.js
        fixtures.json
      test-id-validator/
        README.md             # Test ID format rules and rationale
        test-id-validator.test.js
        edge-cases.json
      case-validator/
        README.md             # IB/OOB format requirements
        case-validator.test.js
        valid-cases.json
        invalid-cases.json
```

**Each README.md provides:**

```markdown
# Test ID Validator

## Purpose

Validates that issue Test IDs follow the format T-XXX where XXX is a number
with 3 or more digits.

## Rules

- Prefix: Must be "T-" (uppercase)
- Number: Must be 3+ digits (001, 042, 123, 1234 all valid)
- Leading zeros: Required for numbers < 100
- Examples:
  - ✅ T-001, T-042, T-999, T-1234
  - ❌ T-1, T-01, TEST-001, T-01A

## Dependencies

- Used by: `.github/workflows/validate-issue.yml`
- Validates: `### Test ID` section of issue body

## Edge Cases

1. Single digit (T-1): Should reject - too short
2. Two digits (T-01): Should reject - minimum is 3 digits
3. Three digits with leading zero (T-001): Should accept
4. Four+ digits (T-1234): Should accept
5. Non-numeric suffix (T-01A): Should reject
6. Wrong prefix (TEST-001): Should reject

## Related Tests

- `tests/issue-validation/section-validator/` - Checks section presence
- `tests/issue-validation/case-validator/` - Checks IB/OOB format
```

**Benefits:**

- AI can read README to understand context
- Tests become self-documenting
- New team members (human or AI) understand intent
- Changes are safer (AI knows what might break)

---

### 5.3 Minimal Context Pattern

**Goal:** Reduce tokens while maintaining clarity

```javascript
// tests/validators/compact-tests.js

/**
 * Compact Test Suite for Issue Validation
 * See: .github/workflows/validate-issue.yml
 * Template: .github/ISSUE_TEMPLATE/test.yml
 */

const { validate } = require('../../src/validators');
const { fixtures } = require('../fixtures');

describe('Validation', () => {
  // Valid cases - should all pass
  test.each(fixtures.valid)('✅ $name', ({ body }) => {
    expect(validate(body).valid).toBe(true);
  });

  // Invalid cases - should all fail with specific errors
  test.each(fixtures.invalid)('❌ $name → $expectedError', ({ body, expectedError }) => {
    const result = validate(body);
    expect(result.valid).toBe(false);
    expect(result.errors).toContain(expectedError);
  });
});
```

```javascript
// tests/fixtures/index.js

module.exports = {
  valid: [
    {
      name: 'Complete test issue',
      body: require('./valid/complete-issue.md'),
    },
    {
      name: 'Minimum required fields',
      body: require('./valid/minimal-issue.md'),
    },
  ],

  invalid: [
    {
      name: 'Missing Test ID',
      body: require('./invalid/missing-test-id.md'),
      expectedError: 'Missing required section: Test ID',
    },
    {
      name: 'Insufficient IB cases',
      body: require('./invalid/no-ib-cases.md'),
      expectedError: 'Insufficient IB cases: found 0, need ≥1',
    },
    {
      name: 'Invalid Test ID format',
      body: require('./invalid/short-test-id.md'),
      expectedError: 'Invalid Test ID format: "T-1"',
    },
  ],
};
```

**Characteristics:**

- Fixture-driven: Data separate from test logic
- Tabular format: Easy to scan and extend
- Explicit expectations: `expectedError` documents behavior
- Compact: 20 lines covers many scenarios
- AI-friendly: Clear structure, predictable patterns

---

### 5.4 Progressive Disclosure Pattern

**Concept:** Start simple, reveal complexity only when needed

```javascript
// Level 1: Basic smoke test (always run)
describe('Validation (smoke)', () => {
  test('accepts valid issue', () => {
    expect(validate(fixtures.validIssue).valid).toBe(true);
  });

  test('rejects invalid issue', () => {
    expect(validate(fixtures.invalidIssue).valid).toBe(false);
  });
});

// Level 2: Edge cases (run in CI)
describe('Validation (edge cases)', () => {
  test.each(edgeCases)('handles $scenario', ({ input, expected }) => {
    expect(validate(input)).toEqual(expected);
  });
});

// Level 3: Integration (run less frequently)
describe('Validation (integration)', () => {
  test('validates against live GitHub API', async () => {
    const issue = await github.issues.get({ issue_number: 123 });
    expect(validate(issue.body).valid).toBe(true);
  });
});

// Level 4: Performance (run on demand)
describe('Validation (performance)', () => {
  test('validates 1000 issues in < 1s', () => {
    const start = Date.now();
    for (let i = 0; i < 1000; i++) {
      validate(fixtures.validIssue);
    }
    expect(Date.now() - start).toBeLessThan(1000);
  });
});
```

**Benefits:**

- Fast feedback: Level 1 runs in milliseconds
- Controlled cost: Expensive tests run less often
- Clear signal: Failures at different levels indicate different problems
- AI can understand: Hierarchical organization

---

### 5.5 Self-Documenting Assertion Pattern

```javascript
// Instead of:
expect(result.errors.length).toBe(2);

// Use:
expect(result.errors).toHaveLength(2); // Clearer intent

// Instead of:
expect(result.valid === true && result.errors.length === 0).toBe(true);

// Use:
expect(result).toMatchObject({
  valid: true,
  errors: [],
}); // Documents expected structure

// Custom matchers for domain concepts:
expect(issueBody).toHaveRequiredSections();
expect(testId).toMatchTestIdFormat();
expect(ibCases).toSatisfyMinimumCount(1);
```

**Custom matcher example:**

```javascript
// tests/matchers.js
expect.extend({
  toHaveRequiredSections(issueBody) {
    const requiredSections = [
      'Test ID',
      'Purpose',
      'In-Bounds Case(s)',
      'Out-of-Bounds Case(s)',
      'Expected Behavior',
      'Validation Method',
    ];

    const missingSections = requiredSections.filter(
      (section) => !issueBody.includes(`### ${section}`)
    );

    if (missingSections.length > 0) {
      return {
        pass: false,
        message: () => `Expected issue to have sections: ${missingSections.join(', ')}`,
      };
    }

    return { pass: true };
  },

  toMatchTestIdFormat(testId) {
    const pattern = /^T-\d{3,}$/;
    const pass = pattern.test(testId);

    return {
      pass,
      message: () =>
        pass
          ? `Expected ${testId} NOT to match Test ID format`
          : `Expected ${testId} to match format T-XXX (3+ digits)`,
    };
  },
});
```

**Why AI loves this:**

- Domain concepts in test language
- Failure messages are explanatory
- Tests read like specifications
- Easy to extend with new matchers

---

## 6. Recommendations for JD_GitHub_template

### 6.1 Immediate Actions (This Week)

#### 1. Add Static Analysis

```yaml
# .github/workflows/test-workflows.yml
name: Test Workflows

on:
  push:
    branches: [main]
  pull_request:
    paths:
      - '.github/workflows/**'
      - '.github/actions/**'

jobs:
  lint:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v4

      - name: YAML Lint
        run: yamllint .github/

      - name: actionlint
        run: |
          bash <(curl https://raw.githubusercontent.com/rhysd/actionlint/main/scripts/download-actionlint.bash)
          ./actionlint -color
```

#### 2. Install act for Local Testing

```bash
# macOS
brew install act

# Windows
choco install act-cli

# Test locally
act -l  # List workflows
act -j lint -n  # Dry run lint job
```

#### 3. Create Test Fixtures Directory

```bash
mkdir -p tests/fixtures/issues
cp .github/ISSUE_TEMPLATE/test.yml tests/fixtures/issues/template.yml

# Create valid example
cat > tests/fixtures/issues/valid-complete.md << 'EOF'
### Test ID
T-001

### Suite (c1) Issue URL
https://github.com/example/repo/issues/10

### Parent feature/bug (p) URL
https://github.com/example/repo/issues/5

### Purpose
This test validates the basic functionality of the issue validation workflow.

### In-Bounds Case(s) (IB≥1)

- IB-01: Valid test case with all required fields
  - Input: Complete issue body
  - Steps: Submit issue
  - Expected: Validation passes

### Out-of-Bounds Case(s) (OOB≥2 required)

- OOB-01: Missing Test ID section
  - Input: Issue without Test ID
  - Expected: Validation fails

- OOB-02: Invalid Test ID format
  - Input: Test ID = "T-1"
  - Expected: Validation fails

### Expected Behavior (authoritative)
Validation should pass for properly formatted issues and fail with specific
error messages for invalid issues.

### Validation Method
Automated testing with Jest and manual verification.

### Validation Gate
- [ ] ✅ test.validated = true
EOF
```

---

### 6.2 Short-term Improvements (Next 2-4 Weeks)

#### 1. Extract Validation Logic into Testable Module

**Current state:** Logic embedded in workflow YAML
**Goal:** Extract to JavaScript module for unit testing

```
.github/
  actions/
    validate-issue/
      action.yml
      src/
        index.js
        validators/
          sectionValidator.js
          testIdValidator.js
          caseValidator.js
          yamlValidator.js
        utils/
          issueParser.js
          labelManager.js
      package.json
      tests/
        validators/
          sectionValidator.test.js
          testIdValidator.test.js
          caseValidator.test.js
        utils/
          issueParser.test.js
        integration/
          full-validation.test.js
```

**Example extraction:**

```javascript
// .github/actions/validate-issue/src/validators/testIdValidator.js

/**
 * Validates Test ID format: T-XXX where XXX is 3+ digits
 *
 * @param {string} testId - The test ID to validate
 * @returns {Object} { valid: boolean, error?: string }
 */
function validateTestId(testId) {
  const pattern = /^T-\d{3,}$/;

  if (!testId || typeof testId !== 'string') {
    return {
      valid: false,
      error: 'Test ID is required',
    };
  }

  if (!pattern.test(testId)) {
    return {
      valid: false,
      error: `Invalid Test ID format: "${testId}" (expected format: T-XXX where XXX is a number with 3+ digits)`,
    };
  }

  return { valid: true };
}

module.exports = { validateTestId };
```

```javascript
// .github/actions/validate-issue/tests/validators/testIdValidator.test.js

const { validateTestId } = require('../../src/validators/testIdValidator');

describe('testIdValidator', () => {
  describe('valid Test IDs', () => {
    test.each(['T-001', 'T-042', 'T-999', 'T-1234', 'T-99999'])('should accept %s', (testId) => {
      const result = validateTestId(testId);
      expect(result.valid).toBe(true);
      expect(result.error).toBeUndefined();
    });
  });

  describe('invalid Test IDs', () => {
    test.each([
      ['T-1', 'too short (1 digit)'],
      ['T-01', 'too short (2 digits)'],
      ['TEST-001', 'wrong prefix'],
      ['T-01A', 'non-numeric'],
      ['t-001', 'lowercase prefix'],
      ['', 'empty string'],
      [null, 'null'],
      [undefined, 'undefined'],
    ])('should reject %s (%s)', (testId, reason) => {
      const result = validateTestId(testId);
      expect(result.valid).toBe(false);
      expect(result.error).toBeDefined();
    });
  });
});
```

**Update workflow to use action:**

```yaml
# .github/workflows/validate-issue.yml (simplified)
jobs:
  validate:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v4

      - name: Validate Issue
        uses: ./.github/actions/validate-issue
        with:
          issue-number: ${{ github.event.issue.number }}
          github-token: ${{ secrets.GITHUB_TOKEN }}
```

---

#### 2. Add Integration Test Workflow

```yaml
# .github/workflows/test-integration.yml
name: Integration Tests

on:
  pull_request:
    paths:
      - '.github/workflows/validate-issue.yml'
      - '.github/actions/validate-issue/**'

jobs:
  test-validation:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v4

      - name: Setup Node.js
        uses: actions/setup-node@v4
        with:
          node-version: '20'

      - name: Install dependencies
        run: |
          cd .github/actions/validate-issue
          npm ci

      - name: Run integration tests
        run: |
          cd .github/actions/validate-issue
          npm test -- --testPathPattern=integration
        env:
          GITHUB_TOKEN: ${{ secrets.GITHUB_TOKEN }}
          TEST_REPO: ${{ github.repository }}
```

---

#### 3. Create Bash Script Tests with Bats

**For any existing shell scripts in `.github/scripts/`:**

```bash
# Install Bats
brew install bats-core

# Create test directory
mkdir -p tests/scripts

# Create first test
cat > tests/scripts/helpers.bats << 'EOF'
#!/usr/bin/env bats

# Test helper functions used in workflows

@test "extract_issue_number from URL" {
  source .github/scripts/helpers.sh

  result=$(extract_issue_number "https://github.com/owner/repo/issues/123")
  [ "$result" = "123" ]
}

@test "format_log_filename pads with zeros" {
  source .github/scripts/helpers.sh

  result=$(format_log_filename 42)
  [ "$result" = "issue_0042_decision_log.md" ]
}
EOF

# Run tests
bats tests/scripts/
```

---

### 6.3 Medium-term Goals (1-2 Months)

#### 1. Comprehensive Test Suite

**Target coverage:**

- **Static analysis:** 100% of workflows validated
- **Unit tests:** 80%+ code coverage for extracted logic
- **Integration tests:** All workflow interactions tested
- **E2E tests:** Critical paths tested end-to-end

**Test pyramid:**

```
         /\
        /E2\      5-10 E2E tests (slow, expensive)
       /----\
      / Intg \    20-30 integration tests (moderate)
     /--------\
    /   Unit   \  100+ unit tests (fast, cheap)
   /------------\
  / Static Anal  \ actionlint, yamllint, shellcheck (instant)
 /----------------\
```

---

#### 2. CI/CD Test Pipeline

```yaml
# .github/workflows/ci.yml
name: Continuous Integration

on: [push, pull_request]

jobs:
  # Fast feedback (< 1 minute)
  quick-checks:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v4
      - name: Static analysis
        run: |
          yamllint .github/
          ./actionlint

  # Unit tests (1-3 minutes)
  unit-tests:
    runs-on: ubuntu-latest
    needs: quick-checks
    steps:
      - uses: actions/checkout@v4
      - uses: actions/setup-node@v4
        with:
          node-version: '20'
          cache: 'npm'
      - run: npm ci
      - run: npm test -- --coverage
      - uses: codecov/codecov-action@v3

  # Integration tests (3-5 minutes)
  integration-tests:
    runs-on: ubuntu-latest
    needs: unit-tests
    steps:
      - uses: actions/checkout@v4
      - uses: actions/setup-node@v4
      - run: npm ci
      - run: npm test -- --testPathPattern=integration

  # E2E tests (5-10 minutes, only on main)
  e2e-tests:
    if: github.ref == 'refs/heads/main'
    runs-on: ubuntu-latest
    needs: integration-tests
    steps:
      - uses: actions/checkout@v4
      - name: Run E2E suite
        run: npm test -- --testPathPattern=e2e
        env:
          GITHUB_TOKEN: ${{ secrets.GITHUB_TOKEN }}
```

---

#### 3. Local Development Workflow

**Goal:** Enable developers to run full test suite locally

```bash
# Create helper script
cat > scripts/test-local.sh << 'EOF'
#!/bin/bash
set -euo pipefail

echo "🔍 Running static analysis..."
yamllint .github/
actionlint

echo "✅ Static analysis passed"
echo ""

echo "🧪 Running unit tests..."
npm test -- --testPathPattern=unit

echo "✅ Unit tests passed"
echo ""

echo "🔗 Running integration tests..."
npm test -- --testPathPattern=integration

echo "✅ Integration tests passed"
echo ""

echo "🎯 Testing workflows locally with act..."
act -j lint -n
act -j validate -n

echo "✅ All tests passed!"
EOF

chmod +x scripts/test-local.sh

# Run before committing
./scripts/test-local.sh
```

---

### 6.4 Long-term Vision (3-6 Months)

#### 1. Continuous Testing & Monitoring

```yaml
# .github/workflows/continuous-testing.yml
name: Continuous Testing

on:
  schedule:
    - cron: '0 */6 * * *' # Every 6 hours
  workflow_dispatch:

jobs:
  regression-suite:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v4

      - name: Full regression suite
        run: npm test -- --testPathPattern=regression

      - name: Performance benchmarks
        run: npm run benchmark

      - name: Generate test report
        run: npm run test:report

      - name: Upload results
        uses: actions/upload-artifact@v4
        with:
          name: test-results-${{ github.run_id }}
          path: test-results/
```

---

#### 2. Test Documentation System

**Auto-generate test documentation:**

```javascript
// scripts/generate-test-docs.js

const fs = require('fs');
const path = require('path');

// Parse all test files
const testFiles = glob.sync('tests/**/*.test.js');

const documentation = testFiles.map((file) => {
  const content = fs.readFileSync(file, 'utf8');

  // Extract test descriptions
  const describes = content.match(/describe\(['"](.+?)['"]/g);
  const tests = content.match(/test\(['"](.+?)['"]/g);

  return {
    file,
    describes,
    tests,
  };
});

// Generate markdown
const markdown = `
# Test Documentation

Auto-generated from test files

${documentation
  .map(
    (doc) => `
## ${doc.file}

${doc.describes.join('\n')}

${doc.tests.join('\n')}
`
  )
  .join('\n---\n')}
`;

fs.writeFileSync('docs/TESTS.md', markdown);
```

---

## 7. Tool Comparison Matrix

| Tool                         | Purpose               | Speed              | Complexity  | Best For                 |
| ---------------------------- | --------------------- | ------------------ | ----------- | ------------------------ |
| **yamllint**                 | YAML syntax           | Instant            | Low         | Basic syntax checking    |
| **actionlint**               | GHA validation        | Fast (< 1s)        | Low         | Workflow linting         |
| **act**                      | Local execution       | Moderate (10s-60s) | Medium      | Pre-commit testing       |
| **action-validator**         | Schema validation     | Fast (< 1s)        | Low         | Pre-commit hooks         |
| **Bats**                     | Bash testing          | Fast               | Low-Medium  | Shell script tests       |
| **Jest + Nock**              | Unit/Integration      | Fast-Moderate      | Medium      | JavaScript logic         |
| **github-action-ts-run-api** | Action testing        | Fast               | Medium-High | TypeScript actions       |
| **mock-github**              | API mocking           | Fast               | Medium      | Complex API interactions |
| **Datadog Synthetics**       | Production monitoring | Slow (minutes)     | High        | Live environment testing |

---

## 8. Key Takeaways & Action Items

### Must-Have (Do Immediately)

1. **Install act:** Local workflow testing (`brew install act`)
2. **Add actionlint:** Workflow validation in CI
3. **Create test fixtures:** Example valid/invalid issues
4. **Configure yamllint:** Basic YAML validation

### Should-Have (Next 2-4 Weeks)

1. **Extract validation logic:** Make it unit-testable
2. **Add Bats tests:** For any bash scripts
3. **Create integration tests:** Test workflow interactions
4. **Set up local test script:** One command to run all tests

### Nice-to-Have (1-3 Months)

1. **E2E test suite:** Full workflow testing
2. **Continuous monitoring:** Regression detection
3. **Performance benchmarks:** Track workflow speed
4. **Test documentation:** Auto-generated from tests

---

## 9. References & Resources

### Official Documentation

- **act:** https://github.com/nektos/act
- **actionlint:** https://rhysd.github.io/actionlint/
- **Bats:** https://bats-core.readthedocs.io
- **GitHub Actions:** https://docs.github.com/en/actions

### Tutorials & Guides

- **Testing GitHub Actions (2024):** https://blog.codacy.com/how-to-test-github-actions
- **act Guide:** https://www.infralovers.com/blog/2024-08-14-github-actions-locally/
- **Bats Practical Guide:** https://www.pullrequest.com/blog/testing-bash-scripts-with-bats-a-practical-guide/
- **GitHub Actions Testing Series:** https://cardinalby.github.io/blog/post/github-actions/testing/

### Tools & Libraries

- **mock-github:** https://github.com/kiegroup/mock-github
- **Nock (HTTP mocking):** https://github.com/nock/nock
- **Jest:** https://jestjs.io
- **Bats helpers:**
  - https://github.com/bats-core/bats-assert
  - https://github.com/bats-core/bats-support
  - https://github.com/bats-core/bats-file

### Best Practices

- **CI/CD Best Practices 2025:** https://www.kellton.com/kellton-tech-blog/continuous-integration-deployment-best-practices-2025
- **AI in Testing 2025:** https://aqua-cloud.io/ai-in-software-testing/
- **Test Automation Patterns:** https://abstracta.us/blog/test-automation/test-automation-patterns-good-practices/

---

## 10. Project-Specific Implementation Plan

### Current State Analysis

**Existing workflows in JD_GitHub_template:**

- `validate-issue.yml` (20KB, 441 lines) - Complex validation logic
- `decision_log_writer.yml` - Logging system
- `enforce_test_gate.yml` - Test gate enforcement
- `seed-test-runlist.yml` (19KB) - Test checklist generation
- `format-apply.yml` - Code formatting
- `format-check.yml` - Format validation
- `context-commands.yml` - Context management
- `apply_settings.yml` - Settings application

**Testing priorities (by risk/complexity):**

1. **High Priority:**
   - `validate-issue.yml` - Core validation, complex logic, many edge cases
   - `seed-test-runlist.yml` - Large, complex, critical for test execution

2. **Medium Priority:**
   - `decision_log_writer.yml` - Data integrity important
   - `enforce_test_gate.yml` - Workflow orchestration
   - `format-apply.yml` - Can introduce bugs

3. **Low Priority:**
   - `format-check.yml` - Read-only validation
   - `context-commands.yml` - Simple logic
   - `apply_settings.yml` - Infrequent changes

---

### Week 1: Foundation

**Day 1-2: Static Analysis**

```bash
# Install tools
brew install actionlint yamllint act

# Create config
cat > .yamllint.yml << EOF
extends: default
rules:
  line-length:
    max: 120
  indentation:
    spaces: 2
EOF

# Test locally
yamllint .github/workflows/
actionlint
```

**Day 3-4: Add to CI**

```yaml
# .github/workflows/test-static.yml
name: Static Analysis
on: [push, pull_request]
jobs:
  lint:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v4
      - run: yamllint .github/
      - run: |
          bash <(curl https://raw.githubusercontent.com/rhysd/actionlint/main/scripts/download-actionlint.bash)
          ./actionlint
```

**Day 5: Create Test Fixtures**

```bash
mkdir -p tests/fixtures/issues
# Copy template and create test cases
```

---

### Week 2-3: Unit Tests for validate-issue.yml

**Extract validation logic:**

1. Create `.github/actions/validate-issue/`
2. Move validation functions to `src/validators/`
3. Add unit tests with Jest
4. Update workflow to use new action

**Target: 80% code coverage for validation logic**

---

### Week 4: Integration Tests

**Test workflow interactions:**

1. Validate-issue → Decision-log-writer
2. Validate-issue → Enforce-test-gate
3. Seed-test-runlist → File generation

**Use self-testing approach:**

- Create test issues programmatically
- Run workflows
- Verify outputs
- Clean up

---

### Month 2: Expand Coverage

1. Add tests for `seed-test-runlist.yml`
2. Test `decision_log_writer.yml`
3. Add Bats tests for any shell scripts
4. Create E2E test for full issue lifecycle

---

### Month 3: Polish & Automation

1. Continuous testing setup
2. Performance benchmarks
3. Test documentation
4. Developer tooling (pre-commit hooks, local test script)

---

## Conclusion

This research provides a comprehensive foundation for testing GitHub Actions workflows and automation infrastructure. The key is to **start small** with static analysis, build **confidence** with unit tests, and **scale gradually** to integration and E2E testing.

**Next steps for JD_GitHub_template:**

1. Install `act`, `actionlint`, and `yamllint`
2. Add static analysis to CI
3. Extract validation logic for unit testing
4. Build test suite progressively over 2-3 months

**Success metrics:**

- All workflows pass actionlint
- 80%+ code coverage for extracted logic
- < 5 minute feedback loop for changes
- Zero production failures from untested code changes

---

**Generated:** 2025-11-09
**Research conducted by:** Claude (AI Assistant)
**Project:** Jackson-Devices/JD_GitHub_template
