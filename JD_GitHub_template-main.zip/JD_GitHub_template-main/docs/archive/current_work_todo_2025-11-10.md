# Current Work TODO - Atomically Defined for Parallel AI Execution

**Generated:** 2025-11-09
**Updated:** 2025-11-10 (Enhanced tracking system applied)
**Purpose:** Consolidated, dependency-ordered todo list for parallel AI implementation with minimal context windows

---

## 🔧 Git Worktree Workflow (CRITICAL - READ FIRST)

**Each phase in this document should use a separate git worktree to prevent commit pileup.**

### Quick Start for AI

```bash
# Starting Phase 3? Create new worktree:
cd /home/user/JD_GitHub_template
git worktree add ../JD_GitHub_template-worktrees/p0.2-phase3 -b claude/p0.2-phase3-[session-id]
cd ../JD_GitHub_template-worktrees/p0.2-phase3

# Work, commit, push
# Human merges PR independently - AI doesn't wait
```

**Why:** Prevents multiple commits piling up on one branch (garbled descriptions, lost audit trail)

**Full Documentation:** See [TASK_REFERENCE_INDEX.md](./TASK_REFERENCE_INDEX.md#git-worktree-workflow-for-atomic-tasks-required-for-ai) for complete workflow

---

**Task Status Legend:**

- ✅ **COMPLETED:** `YYYY-MM-DD | By: [AI/Human] | Commit: [SHA]` - Task fully finished
- ⏳ **PENDING:** Task defined, not yet started
- 🔄 **IN PROGRESS:** Task currently being worked on
- ❌ **SKIPPED:** `YYYY-MM-DD | Reason: [explanation]` - Intentionally not done
- ⏸️ **DEFERRED:** `YYYY-MM-DD | Reason: [why] | Until: [condition]` - Postponed

**Dependency Notation:**

- ⬆️ UPSTREAM DEPENDENCY: Task cannot start until specified dependency completes
- Tasks without upstream dependencies CAN run in parallel
- Tasks with same upstream dependency CAN run in parallel after that dependency completes

**Important:** Tasks are NEVER deleted. Completed tasks move to archive at bottom. Skipped tasks documented with reason.

**Detailed Subtasks:** For granular task details (e.g., formatter steps 1-10), see `TASK_REFERENCE_INDEX.md` which maps to archived documents.

---

## 🔴 P0 - CRITICAL FOUNDATION (Must Complete First)

These tasks establish the atomic framework foundation. **Nothing else can proceed without these.**

### P0.1: Label Taxonomy Finalization & Implementation

**Why P0:** All issues, workflows, and hierarchy depend on correct labels existing in GitHub.

**Atomic Tasks** (Sequential - must be done in order):

1. **Update LABEL_DESIGN_SPEC.md**
   - Add `type: function` - Brown #292524
   - Add `type: tooling` - Gray #6b7280 (for internal tools/infrastructure)
   - Change `type: improvement` from Blue (#3b82f6) to Tan (#78716c)
   - Update `type: test` definition - clarify it's ONLY for IB/OOB test cases
   - Update `type: tooling` definition - internal tools, testing infrastructure, workflow automation
   - Document work type hierarchy rules (parent only, children don't inherit)
   - File: `LABEL_DESIGN_SPEC.md:173-183`
   - Context: even_more_todo.md lines 214-329
   - Estimated: 20 minutes

2. **Update .github/settings.yml**
   - Add `type: function` label with Brown color
   - Add `type: tooling` label with Gray color
   - Update `type: improvement` color to Tan
   - File: `.github/settings.yml`
   - ⬆️ UPSTREAM DEPENDENCY: Task 1 complete
   - Estimated: 5 minutes

3. **Run Label Sync (Dry Run)**
   - Execute: `gh workflow run apply_settings.yml -f mode=dry_run`
   - Verify output shows correct changes
   - ⬆️ UPSTREAM DEPENDENCY: Task 2 complete
   - Estimated: 2 minutes

4. **Run Label Sync (Apply)**
   - Execute: `gh workflow run apply_settings.yml -f mode=apply`
   - Verify labels created/updated in GitHub
   - ⬆️ UPSTREAM DEPENDENCY: Task 3 passed validation
   - Estimated: 2 minutes

5. **Fix Issue #26 Labels**
   - Remove `type: test` label from #26
   - Add `type: tooling` label to #26
   - Keep: `type: feature`, `difficulty: complex`, `ai: human+ai`, `needs-human`, `workflow: backlog`
   - Rationale: #26 is testing infrastructure work (tooling), not a test case
   - ⬆️ UPSTREAM DEPENDENCY: Tasks 1-4 complete
   - Estimated: 1 minute

**Total P0.1:** ~30 minutes | **Parallelizable:** No (sequential dependencies)

---

### P0.2: Issue Template Framework - Feature Hierarchy

**Why P0:** Templates define the atomic structure for all future work. Must exist before creating issues.

**Atomic Tasks** (3 phases with mixed parallelization):

#### Phase 1: Design Template Schemas (Sequential)

1. **Review Existing Template Structure**
   - Read existing `.github/ISSUE_TEMPLATE/test.yml` to understand GitHub template YAML format
   - Document required template fields (name, description, title, body)
   - Note field types available (textarea, dropdown, input, checkboxes)
   - Estimated: 5 minutes

2. **Define Feature Template Schema**
   - Design body fields: User Outcome, Acceptance Criteria, Success Metrics, Dependencies
   - Specify field types (textarea, dropdown, input)
   - Define labels to auto-apply: `type: feature` (or bug/improvement/refactor/tooling)
   - Document that NO role label should be applied
   - ⬆️ UPSTREAM DEPENDENCY: Task 1 complete
   - Estimated: 5 minutes

3. **Define Sub-Feature Template Schema**
   - Design body fields: Parent Feature link, AC from parent, Function Contracts, Test Coverage
   - Specify parent issue number field type (input, number validation)
   - Define role label application: `role: sub-feature`
   - Document that NO work type label should be applied
   - ⬆️ UPSTREAM DEPENDENCY: Task 2 complete
   - Estimated: 5 minutes

4. **Define Function Template Schema**
   - Design Contract Definition section: Inputs, Outputs, Invariants, Pre/Post-conditions
   - Design Test Suite Link field (parent test suite)
   - Define label application: `type: function`
   - Document that NO role label should be applied
   - ⬆️ UPSTREAM DEPENDENCY: Task 3 complete
   - Estimated: 5 minutes

5. **Define Test-Suite Template Schema**
   - Design Test Cases field (list of IB/OOB test IDs)
   - Design Coverage Target field (minimum IB≥1, OOB≥2)
   - Define role label application: `role: test suite`
   - Document that NO work type label should be applied
   - ⬆️ UPSTREAM DEPENDENCY: Task 4 complete
   - Estimated: 5 minutes

#### Phase 2A: Create Template Files (Parallel - 4 agents)

6. **Create Feature Template File**
   - Create `.github/ISSUE_TEMPLATE/feature.yml`
   - Implement schema from Task 2
   - Add template name and description
   - Include all required GitHub template fields
   - ⬆️ UPSTREAM DEPENDENCY: Task 2 complete
   - Estimated: 7 minutes

7. **Create Sub-Feature Template File**
   - Create `.github/ISSUE_TEMPLATE/sub-feature.yml`
   - Implement schema from Task 3
   - Add template name and description
   - Include parent issue link field
   - ⬆️ UPSTREAM DEPENDENCY: Task 3 complete
   - Estimated: 7 minutes

8. **Create Function Template File**
   - Create `.github/ISSUE_TEMPLATE/function.yml`
   - Implement schema from Task 4
   - Add Contract Definition structured fields
   - Include test suite link field
   - ⬆️ UPSTREAM DEPENDENCY: Task 4 complete
   - Estimated: 10 minutes

9. **Create Test-Suite Template File**
   - Create `.github/ISSUE_TEMPLATE/test-suite.yml`
   - Implement schema from Task 5
   - Add coverage target fields
   - Include parent function link field
   - ⬆️ UPSTREAM DEPENDENCY: Task 5 complete
   - Estimated: 7 minutes

**Parallelization Note:** Tasks 6-9 CAN run in parallel AFTER their respective schema design tasks (2-5) complete.

#### Phase 2B: Verify Template Files (Parallel - 4 agents)

10. **Verify Feature Template**
    - Check YAML syntax with yamllint
    - Verify all required fields present
    - Test that labels auto-apply correctly
    - ⬆️ UPSTREAM DEPENDENCY: Task 6 complete
    - Estimated: 3 minutes

11. **Verify Sub-Feature Template**
    - Check YAML syntax with yamllint
    - Verify parent link field works correctly
    - Test role label application
    - ⬆️ UPSTREAM DEPENDENCY: Task 7 complete
    - Estimated: 3 minutes

12. **Verify Function Template**
    - Check YAML syntax with yamllint
    - Verify all contract fields are present
    - Test type:function label application
    - ⬆️ UPSTREAM DEPENDENCY: Task 8 complete
    - Estimated: 3 minutes

13. **Verify Test-Suite Template**
    - Check YAML syntax with yamllint
    - Verify test case list field works
    - Test role:test suite label application
    - ⬆️ UPSTREAM DEPENDENCY: Task 9 complete
    - Estimated: 3 minutes

**Parallelization Note:** Tasks 10-13 CAN run in parallel AFTER their respective creation tasks (6-9) complete.

#### Phase 3: Integration & Documentation (Sequential)

14. **Update config.yml**
    - Add all 4 new templates to `.github/ISSUE_TEMPLATE/config.yml` (if it exists)
    - Set appropriate ordering and descriptions
    - Ensure templates appear in correct order in GitHub UI
    - ⬆️ UPSTREAM DEPENDENCY: Tasks 6, 8, 10, 12 complete (all creation tasks)
    - Estimated: 5 minutes

15. **Create Template Usage Documentation**
    - Create `docs/templates/` directory
    - Create `docs/templates/template_usage.md` explaining which template to use when
    - Document the 5-level hierarchy with examples
    - Add decision tree for choosing template type
    - ⬆️ UPSTREAM DEPENDENCY: Tasks 7, 9, 11, 13 complete (all verification tasks)
    - Estimated: 10 minutes

16. **Test Complete Template Workflow**
    - Create test issues using each template (can be closed immediately)
    - Verify labels auto-apply correctly
    - Verify all fields render properly in GitHub UI
    - Document any issues found
    - ⬆️ UPSTREAM DEPENDENCY: Tasks 14, 15 complete
    - Estimated: 10 minutes

**Total P0.2:** ~93 minutes sequential, ~58 minutes with optimal parallelization
**Parallelization Strategy:**

- Phase 1 (Tasks 1-5): Sequential, 25 minutes (t=0-25)
- Phase 2A (Tasks 6,8,10,12): Parallel after Phase 1, 10 minutes (t=25-35)
- Phase 2B (Tasks 7,9,11,13): Parallel after Phase 2A, 3 minutes (t=35-38)
- Phase 3: Task 14 starts at t=35 (5 min), Task 15 starts at t=38 (10 min), Task 16 starts at t=48 (10 min)
- Total with parallelization: 58 minutes

---

## 🟡 P1 - CORE INFRASTRUCTURE (Enables All Workflows)

These tasks enable the atomic workflow. Complete after P0.

---

### P1.0: Environment Setup - Install Dependencies

**Why P1.0:** Prettier and other dev dependencies must be installed before formatter work (P1.2) can begin.

**Atomic Tasks** (Sequential):

1. **Verify package.json Dependencies**
   - Check that prettier and prettier-plugin-sh are listed in devDependencies
   - Verify versions are specified correctly (prettier ^3.6.2, prettier-plugin-sh ^0.18.0)
   - File: `package.json`
   - Estimated: 2 minutes

2. **Run npm install**
   - Execute: `npm install`
   - Verify node_modules/ directory created
   - Verify package-lock.json created/updated
   - Check for any npm warnings or errors
   - ⬆️ UPSTREAM DEPENDENCY: Task 1 complete
   - Estimated: 3 minutes

3. **Verify Prettier Installation**
   - Execute: `npm list prettier` - check version matches package.json
   - Execute: `npx prettier --version` - verify CLI works
   - Execute: `npm run format:check` - test against current files
   - ⬆️ UPSTREAM DEPENDENCY: Task 2 complete
   - Estimated: 2 minutes

4. **Verify Git Ignore Configuration**
   - Check .gitignore includes node_modules/
   - Verify package-lock.json is NOT ignored (should be committed)
   - Verify no unintended files will be committed
   - ⬆️ UPSTREAM DEPENDENCY: Task 2 complete (can run parallel with Task 3)
   - Estimated: 1 minute

**Total P1.0:** ~8 minutes | **Parallelizable:** Partial (Tasks 3-4 can run parallel after Task 2)

---

### P1.1: Documentation Structure Refactoring

**Why P1:** Atomic design requires clear, minimal-context documentation.

**Atomic Tasks** (Mixed parallelization):

**Task 1: Create docs/ Directory Structure**

- Create directories:
  - `docs/`
  - `docs/examples/`
  - `docs/workflows/`
  - `docs/ai_work/`
  - `docs/diagrams/`
  - `docs/templates/`
  - `docs/formatters/` (verify exists, create if missing)
- Add `docs/README.md` with directory map
- Estimated: 10 minutes

**Task 2: Extract Test Naming Examples**

- Source: README.md (search for "IB-", "OOB-", "T-")
- Destination: `docs/examples/test_naming_examples.md`
- Sections:
  - IB naming rules + 5 examples
  - OOB naming rules + 5 examples
  - T-ID format + 5 examples
  - Namespace rules (issue number = namespace)
- Remove from README, add link
- ⬆️ UPSTREAM DEPENDENCY: Task 1 complete
- Estimated: 20 minutes

**Task 3: Extract Hierarchy Examples**

- Source: README.md (Feature → Suite → Test)
- Destination: `docs/examples/hierarchy_examples.md`
- NEW hierarchy: Feature → Sub-Feature → Function → Test-Suite → Test-Case
- Sections:
  - Full 5-level hierarchy with examples
  - Work type hierarchy rules (parent only)
  - Role label usage
  - Label combinations table
- Remove from README, add link
- ⬆️ UPSTREAM DEPENDENCY: Task 1 complete
- Context: even_more_todo.md lines 231-292
- Estimated: 25 minutes

**Task 4: Create Decision Log Full Example**

- Destination: `docs/examples/decision_log_example_full.md`
- Create realistic scenario:
  - Pass 1: GPT-4 attempt, failure analysis
  - Pass 2: Claude 3.5 attempt, partial success
  - Pass 3: Final attempt, escalation to human
  - Complete change logs, test execution, failure analysis
- ⬆️ UPSTREAM DEPENDENCY: Task 1 complete
- Context: TODO_REVIEW_AND_LOGGING_PLAN.md lines 99-109
- Estimated: 25 minutes

**Task 5: Workflow Detail Documentation**

- Destination: `docs/workflows/test_workflow_detailed.md`
- Document: validate-issue.yml, enforce_test_gate.yml, seed-test-runlist.yml
- Sections:
  - Triggers, concurrency, state machine
  - IB/OOB gate logic with examples
  - Checklist generation algorithm
  - Error handling and retry logic
- ⬆️ UPSTREAM DEPENDENCY: Task 1 complete
- Context: `.github/workflows/validate-issue.yml`, `.github/WORKFLOW_BEHAVIOR.md`
- Estimated: 30 minutes

**Task 6: AI Work Documentation - Decision Log Format**

- Destination: `docs/ai_work/decision_log_format.md`
- Sections:
  - YAML frontmatter structure
  - Pass header fields (model, timestamp, status, commit SHA)
  - Change log entry schema
  - Test execution schema
  - Failure analysis schema
  - Next actions schema
- ⬆️ UPSTREAM DEPENDENCY: Task 1 complete
- Context: TODO_REVIEW_AND_LOGGING_PLAN.md lines 129-136
- Estimated: 25 minutes

**Task 7: AI Work Documentation - Max Pass Enforcement**

- Destination: `docs/ai_work/max_pass_enforcement.md`
- Sections:
  - Default max pass value (5) and override
  - Pass counting logic
  - Escalation workflow
  - needs-human label auto-application
  - Human notification template
  - Reset conditions
- ⬆️ UPSTREAM DEPENDENCY: Task 1 complete
- Context: TODO_REVIEW_AND_LOGGING_PLAN.md lines 137-142
- Estimated: 20 minutes

**Task 8: Update Cross-References**

- Update README.md with pointers to all docs/ files
- Update issues_rules.md with workflow docs
- Verify LABEL_DESIGN_SPEC.md doesn't need updates
- Add "Documentation Map" section to README.md
- ⬆️ UPSTREAM DEPENDENCY: Tasks 2, 3, 4, 5, 6, 7 complete
- Estimated: 20 minutes

**Total P1.1:** ~175 minutes sequential, ~60 minutes with optimal parallelization
**Parallelization Strategy:**

- Task 1: Sequential, 10 minutes (t=0-10)
- Tasks 2-7: Parallel after Task 1, 30 minutes (t=10-40, longest is Task 5)
- Task 8: Sequential after Tasks 2-7, 20 minutes (t=40-60)

---

### P1.2: Code Formatter Remaining Tasks

**Why P1:** Prevents AI from introducing formatting errors.

**Atomic Tasks** (Parallel - 3 agents after P1.0 complete):

**Task 1: Formatter Documentation**

- Files to create:
  - `docs/formatters/README.md` - Overview, installation, usage
  - `docs/formatters/INTEGRATION.md` - GitHub Actions integration guide
  - `docs/formatters/TROUBLESHOOTING.md` - Common issues and fixes
- Files already exist (verify completeness):
  - `docs/formatters/HOUSE_STYLE.md`
  - `claude_mods/FORMATTER_README.md`
- Update cross-references
- ⬆️ UPSTREAM DEPENDENCY: P1.0 complete (Prettier installed)
- Context: TODO.md lines 307-332
- Estimated: 25 minutes

**Task 2: Formatter Testing Suite**

- Create `tests/formatters/` directory
- Add sample broken files:
  - `broken.yaml` (malformed strings, incorrect indentation)
  - `broken.md` (nested lists, tables issues)
  - `broken.json` (comments that need removal)
- Add expected formatted output files
- Write test script: `claude_mods/scripts/test_formatters.mjs`
- Verify tests pass with current formatter setup
- ⬆️ UPSTREAM DEPENDENCY: P1.0 complete (Prettier installed)
- Context: TODO.md lines 334-369
- Estimated: 30 minutes

**Task 3: Formatter Rollout Plan**

- Document incremental rollout phases in `docs/formatters/ROLLOUT_PLAN.md`:
  - Phase 1: Local dev only (current)
  - Phase 2: Optional pre-commit hook
  - Phase 3: GitHub Actions format check (report only)
  - Phase 4: GitHub Actions auto-fix
  - Phase 5: Mandatory pre-commit hook
- Define success criteria for each phase
- Document rollback procedures
- ⬆️ UPSTREAM DEPENDENCY: P1.0 complete (Prettier installed)
- Context: TODO.md lines 371-416
- Estimated: 20 minutes

**Total P1.2:** ~30 minutes with parallelization (all 3 tasks can run in parallel after P1.0)

---

### P1.3: Decision Logging Infrastructure (GitHub Actions Only)

**Why P1.3:** Provides audit trail for all AI work. Client-side logging comes later.

**Atomic Tasks** (Sequential):

1. **Verify Decision Log Writer Integration**
   - Check: `.github/workflows/decision_log_writer.yml` exists ✅
   - Check: Integrated with validate-issue.yml, enforce_test_gate.yml, seed-test-runlist.yml ✅
   - Verify: `.ai_logs/` directory exists
   - Action: Create `.ai_logs/README.md` explaining purpose and structure
   - Context: TODO.md lines 812-859
   - Estimated: 10 minutes

2. **Test Decision Logging End-to-End**
   - Create test issue with `type: test` label
   - Trigger `/validate` command
   - Verify decision log created in `.ai_logs/issue_NNNN_decision_log.md`
   - Verify pass numbering works
   - Verify Prettier formatting applied
   - Delete test issue after verification
   - ⬆️ UPSTREAM DEPENDENCY: Task 1 complete, P1.0 complete (Prettier for formatting)
   - Estimated: 10 minutes

**Total P1.3:** ~20 minutes | **Parallelizable:** No (sequential)

---

### P1.5: Issue #26 Atomic Breakdown

**Why P1.5:** Issue #26 (Build comprehensive synthetic testing infrastructure) is a complex feature that must be broken down into the atomic hierarchy before implementation begins in P2.

**Atomic Tasks** (Sequential):

1. **Analyze Issue #26 Current State**
   - Read issue #26 body and comments
   - Identify all stated requirements
   - List all subtasks mentioned
   - Verify current labels: `type: feature`, `type: tooling`, `difficulty: complex`, `ai: human+ai`, `needs-human`, `workflow: backlog`
   - Estimated: 10 minutes

2. **Define Acceptance Criteria for Testing Infrastructure**
   - Extract/write clear acceptance criteria from issue #26
   - Each AC should map to one sub-feature
   - Expected ACs (adjust based on actual issue content):
     - AC1: Unit test framework operational (actionlint, yamllint, node tests)
     - AC2: Integration test framework operational (workflow state machine tests)
     - AC3: Validation logic extracted to testable modules
     - AC4: Test coverage reporting implemented
     - AC5: CI pipeline running tests on all PRs
     - (Add more as needed based on issue content)
   - ⬆️ UPSTREAM DEPENDENCY: Task 1 complete
   - Estimated: 15 minutes

3. **Create Sub-Feature Issues**
   - Use sub-feature.yml template from P0.2
   - Create one sub-feature issue per AC
   - Link each to parent issue #26
   - Apply `role: sub-feature` label
   - Define function contracts needed for each (high-level)
   - Define test coverage requirements (IB/OOB counts)
   - ⬆️ UPSTREAM DEPENDENCY: Task 2 complete, P0.2 complete (templates exist)
   - Estimated: 30 minutes (5 min per sub-feature × ~6 sub-features)

4. **Update Issue #26 Body**
   - Add "Acceptance Criteria" section with clear ACs
   - Add "Sub-Features" section linking all child issues
   - Add success metrics (test count, coverage %, CI pass rate)
   - Update estimated effort based on breakdown
   - ⬆️ UPSTREAM DEPENDENCY: Task 3 complete
   - Estimated: 10 minutes

5. **Verify Hierarchy Structure**
   - Check that all sub-features link back to #26
   - Verify labels are correct on all issues
   - Confirm no circular dependencies
   - Document in capability_ledger.md (create if doesn't exist)
   - ⬆️ UPSTREAM DEPENDENCY: Task 4 complete
   - Estimated: 5 minutes

**Total P1.5:** ~70 minutes | **Parallelizable:** No (sequential - each step builds on previous)

**Note:** This task must be completed before P2 begins, as P2 implements the work defined here.

---

## 🔵 P2 - TESTING INFRASTRUCTURE (Validates Everything Works)

These tasks ensure atomic components work correctly. Complete after P1 AND P1.5.

### P2.1: Unit Test Framework Setup

**Why P2:** Need tests before building complex features.

**Atomic Tasks** (Mixed parallelization):

1. **Install Testing Tools**
   - Install actionlint (workflow validation)
   - Install yamllint (YAML syntax checking)
   - Add to package.json: test scripts
   - Verify installations work
   - ⬆️ UPSTREAM DEPENDENCY: P1.0 complete (npm available)
   - Context: Issue #26 (testing infrastructure)
   - Estimated: 20 minutes

2. **Create tests/ Directory Structure**
   - Create directories:
     - `tests/unit/workflows/`
     - `tests/unit/scripts/`
     - `tests/integration/`
     - `tests/fixtures/issues/`
     - `tests/mocks/`
   - Add `tests/README.md` explaining test structure
   - ⬆️ UPSTREAM DEPENDENCY: Task 1 complete
   - Estimated: 10 minutes

3. **Extract Test ID Validation Logic**
   - Create `scripts/validators/` directory
   - Create `scripts/validators/test-id-validator.mjs`
   - Implement IB/OOB regex validation functions
   - Write JSDoc documentation for all exported functions
   - Add basic error handling
   - ⬆️ UPSTREAM DEPENDENCY: Task 2 complete
   - Context: Issue #26, Phase 1 tasks
   - Estimated: 25 minutes

4. **Extract YAML Validation Logic**
   - Create `scripts/validators/yaml-validator.mjs`
   - Implement YAML parsing functions
   - Implement section detection logic (9 required sections)
   - Write JSDoc documentation for all exported functions
   - Add error handling for malformed YAML
   - ⬆️ UPSTREAM DEPENDENCY: Task 2 complete (can run parallel with Task 3)
   - Context: Issue #26, validate-issue.yml workflow
   - Estimated: 25 minutes

5. **Extract Issue Fetcher API Logic**
   - Create `scripts/api/` directory
   - Create `scripts/api/issue-fetcher.mjs`
   - Implement GitHub API parent issue fetch
   - Add caching for API responses
   - Write JSDoc documentation
   - ⬆️ UPSTREAM DEPENDENCY: Task 2 complete (can run parallel with Tasks 3-4)
   - Context: Issue #26, test suite validation
   - Estimated: 25 minutes

**Parallelization Note:** Tasks 3, 4, 5 CAN run in parallel AFTER Task 2 completes.

6. **Update Workflows to Use New Modules**
   - Update validate-issue.yml to import validator modules
   - Update enforce_test_gate.yml to import issue-fetcher
   - Test workflow syntax with actionlint
   - Verify imports work correctly
   - ⬆️ UPSTREAM DEPENDENCY: Tasks 3, 4, 5 complete (all extraction tasks)
   - Estimated: 15 minutes

7. **Write Test ID Validator Unit Tests**
   - Create `tests/unit/validators/test-id-validator.test.mjs`
   - Test IB-XX format validation (valid/invalid cases)
   - Test OOB-XX format validation (valid/invalid cases)
   - Test T-ID format validation
   - Test namespace extraction
   - Target: 100% coverage for test-id-validator
   - ⬆️ UPSTREAM DEPENDENCY: Task 6 complete
   - Context: Issue #26, `claude_mods/tests/squash_hook.test.mjs` for pattern
   - Estimated: 20 minutes

8. **Write YAML Validator Unit Tests**
   - Create `tests/unit/validators/yaml-validator.test.mjs`
   - Test section detection (9 required sections)
   - Test YAML parsing (valid/malformed inputs)
   - Test error handling
   - Target: 100% coverage for yaml-validator
   - ⬆️ UPSTREAM DEPENDENCY: Task 6 complete (can run parallel with Task 7)
   - Context: Issue #26
   - Estimated: 20 minutes

9. **Write Issue Fetcher Unit Tests**
   - Create `tests/unit/api/issue-fetcher.test.mjs`
   - Test GitHub API mocking
   - Test caching behavior
   - Test error handling (network failures, 404s)
   - Target: 90%+ coverage for issue-fetcher
   - ⬆️ UPSTREAM DEPENDENCY: Task 6 complete (can run parallel with Tasks 7-8)
   - Context: Issue #26
   - Estimated: 25 minutes

**Parallelization Note:** Tasks 7, 8, 9 CAN run in parallel AFTER Task 6 completes.

10. **Create Basic CI Workflow**
    - Create `.github/workflows/test.yml`
    - Run actionlint on all workflows
    - Run yamllint on all YAML files
    - Run unit tests (node --test)
    - Matrix strategy: Node 20, 22
    - ⬆️ UPSTREAM DEPENDENCY: Tasks 7, 8, 9 complete (all test tasks)
    - Estimated: 20 minutes

**Total P2.1:** ~225 minutes sequential, ~115 minutes with optimal parallelization
**Parallelization Strategy:**

- Tasks 1-2: Sequential, 30 minutes (t=0-30)
- Tasks 3-5: Parallel after Task 2, 25 minutes (t=30-55)
- Task 6: Sequential after Tasks 3-5, 15 minutes (t=55-70)
- Tasks 7-9: Parallel after Task 6, 25 minutes (t=70-95, longest is Task 9)
- Task 10: Sequential after Tasks 7-9, 20 minutes (t=95-115)

---

### P2.2: Integration Tests (After P2.1)

**Atomic Tasks** (Can be parallelized after P2.1 complete - 4 AI agents):

**Agent 1: Validation State Machine Integration Test**

- File: `tests/integration/validation-flow.test.mjs`
- Test flow: Issue opened → validation → blocked → fixed → pending → passed
- Mock GitHub API (issues, labels, comments)
- ⬆️ UPSTREAM DEPENDENCY: P2.1 complete
- Context: Issue #26 task 16
- Estimated: 30 minutes

**Agent 2: Label Sync Integration Test**

- File: `tests/integration/label-sync.test.mjs`
- Test: Parse settings.yml → validate → diff → apply
- Test error scenarios (duplicates, invalid colors, missing from_name)
- Mock Octokit
- ⬆️ UPSTREAM DEPENDENCY: P2.1 complete (can run parallel with Agent 1)
- Context: Issue #26 task 17
- Estimated: 30 minutes

**Agent 3: Decision Logging Integration Test**

- File: `tests/integration/decision-logging.test.mjs`
- Test multi-workflow decision logging with pass numbering
- Test append-only integrity
- Test concurrent logging
- ⬆️ UPSTREAM DEPENDENCY: P2.1 complete (can run parallel with Agents 1-2)
- Context: Issue #26 task 18
- Estimated: 30 minutes

**Agent 4: Formatter Pipeline Integration Test**

- File: `tests/integration/formatter-pipeline.test.mjs`
- Test complete formatting workflow (detect → diff → apply → stage)
- Test GitHub Actions integration
- ⬆️ UPSTREAM DEPENDENCY: P2.1 complete (can run parallel with Agents 1-3)
- Context: Issue #26 task 19
- Estimated: 30 minutes

**Total P2.2:** ~30 minutes with parallelization (all 4 agents can run in parallel) | **Parallelizable:** Yes (4 agents)

---

## 🟢 P3 - ENHANCEMENT & EXPANSION (After Core Works)

These tasks improve and expand the system. Complete after P2.

### P3.1: Formatter Enhancements

**Atomic Tasks** (Can be parallelized - 3 AI agents):

**Agent 1: Additional Language Support**

- Add Rust formatting (rustfmt integration)
- Add Python formatting (Black/Ruff integration)
- Update dprint.json configuration
- Test with sample files
- ⬆️ UPSTREAM DEPENDENCY: P1.2 complete
- Context: TODO.md lines 418-445
- Estimated: 30 minutes

**Agent 2: IDE Integration**

- Create VS Code extension config (.vscode/settings.json)
- Add formatter to recommended extensions (.vscode/extensions.json)
- Document IDE setup in docs/formatters/IDE_SETUP.md
- ⬆️ UPSTREAM DEPENDENCY: P1.2 complete (can run parallel with Agent 1)
- Estimated: 25 minutes

**Agent 3: Formatting Metrics**

- Track which files need formatting most often
- Generate formatting reports (weekly summaries)
- Identify AI error patterns
- Create dashboard in docs/formatters/METRICS.md
- ⬆️ UPSTREAM DEPENDENCY: P1.2 complete (can run parallel with Agents 1-2)
- Estimated: 30 minutes

**Total P3.1:** ~30 minutes with parallelization (all 3 agents can run in parallel) | **Parallelizable:** Yes (3 agents)

---

### P3.2: Workflow Enhancements

**Atomic Tasks** (Sequential - build on each other):

1. **Max Pass Enforcement Design**
   - Define pass count storage location (issue body YAML)
   - Define increment trigger (validation: failed label)
   - Define reset conditions (validation: passed OR /reset-passes command)
   - Document edge cases
   - ⬆️ UPSTREAM DEPENDENCY: P1.1 complete (AI work docs exist)
   - Context: TODO_REVIEW_AND_LOGGING_PLAN.md lines 234-283
   - Estimated: 25 minutes

2. **Read AI Pass Count from Issue Body**
   - Add github-script action to validate-issue.yml
   - Parse issue body YAML to extract ai_pass_count
   - Default to 0 if missing
   - Store in workflow variable
   - ⬆️ UPSTREAM DEPENDENCY: Task 1 complete
   - Estimated: 20 minutes

3. **Read Max AI Passes from Issue Body**
   - Extend github-script action from Task 2
   - Parse issue body YAML to extract max_ai_passes
   - Default to 5 if missing
   - Add repository variable DEFAULT_MAX_AI_PASSES
   - ⬆️ UPSTREAM DEPENDENCY: Task 2 complete (SEQUENTIAL - modifies same workflow file)
   - Estimated: 15 minutes

4. **Implement Pass Count Increment Logic**
   - Add condition: validation: failed label present
   - Increment AI_PASS_COUNT by 1
   - Update issue body YAML
   - Add audit comment
   - ⬆️ UPSTREAM DEPENDENCY: Tasks 2-3 complete
   - Estimated: 25 minutes

5. **Implement Max Pass Check**
   - Add condition: AI_PASS_COUNT >= MAX_AI_PASSES
   - Auto-apply needs-human label
   - Post escalation comment with decision log link
   - ⬆️ UPSTREAM DEPENDENCY: Task 4 complete
   - Estimated: 20 minutes

6. **Implement Specific IB/OOB Failure Tracking**
   - Parse run checklist state
   - Extract checked/unchecked items
   - Identify failed cases
   - Generate failure detail comment
   - ⬆️ UPSTREAM DEPENDENCY: Task 5 complete
   - Estimated: 30 minutes

**Total P3.2:** ~135 minutes | **Parallelizable:** No (sequential)

---

### P3.3: Issue Template AI Metadata Fields

**Atomic Tasks** (Sequential):

1. **Design AI Metadata Fields**
   - Review current test.yml structure
   - Design field schema for: AI Model(s) Used, AI Pass Count, Max AI Passes
   - Define field types, defaults, validation rules
   - ⬆️ UPSTREAM DEPENDENCY: P0.2 complete (templates exist)
   - Context: TODO_REVIEW_AND_LOGGING_PLAN.md lines 184-201
   - Estimated: 20 minutes

2. **Add Fields to test.yml Template**
   - Add "AI Metadata" section to test.yml
   - Insert fields with correct YAML structure
   - Add validation rules
   - Test template rendering in GitHub UI
   - ⬆️ UPSTREAM DEPENDENCY: Task 1 complete
   - Estimated: 15 minutes

3. **Update Validation Gate Description**
   - Add max pass behavior note to validation gate checkbox
   - Link to max pass documentation
   - ⬆️ UPSTREAM DEPENDENCY: Task 2 complete, P1.1 complete (docs exist)
   - Estimated: 10 minutes

4. **Add Decision Log Pointer**
   - Add "Decision Log" section to template
   - Link to format spec and example
   - Explain append behavior
   - ⬆️ UPSTREAM DEPENDENCY: Task 2 complete, P1.1 complete (docs exist, can run parallel with Task 3)
   - Estimated: 10 minutes

**Total P3.3:** ~55 minutes sequential, ~45 minutes with partial parallelization | **Parallelizable:** Partial (Tasks 3-4 can run in parallel)

---

## 🟣 P4 - FUTURE RESEARCH & ADVANCED FEATURES

These are placeholders for future work. **Do NOT start until P0-P3 complete.**

### P4.1: Cloudflare Workers Offloading (Research Phase)

- See TODO.md lines 1071-1174
- **Do not implement yet** - research only

### P4.2: PlatformIO/LLVM Firmware Validation (Research Phase)

- See TODO.md lines 949-1069
- **Do not implement yet** - research only

### P4.3: Slack Integration (Research Phase)

- See TODO.md lines 887-910
- **Do not implement yet** - research only

### P4.4: Specialized GitHub Issue Agents (Design Phase)

- See TODO.md lines 1188-1205
- **Do not implement yet** - design only

---

## 📊 Summary & Parallel Execution Strategy

### Work Breakdown by Priority

| Priority | Total Time | With Parallelization | Max Concurrent Agents | Atomic Compliance    |
| -------- | ---------- | -------------------- | --------------------- | -------------------- |
| P0.1     | ~30 min    | ~30 min              | 1                     | ✅ All tasks ≤20 min |
| P0.2     | ~93 min    | ~58 min              | 4                     | ✅ All tasks ≤10 min |
| P1.0     | ~8 min     | ~6 min               | 2                     | ✅ All tasks ≤3 min  |
| P1.1     | ~175 min   | ~60 min              | 6                     | ✅ All tasks ≤30 min |
| P1.2     | ~75 min    | ~30 min              | 3                     | ✅ All tasks ≤30 min |
| P1.3     | ~20 min    | ~20 min              | 1                     | ✅ All tasks ≤10 min |
| P1.5     | ~70 min    | ~70 min              | 1                     | ✅ All tasks ≤30 min |
| P2.1     | ~225 min   | ~115 min             | 3                     | ✅ All tasks ≤25 min |
| P2.2     | ~120 min   | ~30 min              | 4                     | ✅ All tasks ≤30 min |
| P3.1     | ~85 min    | ~30 min              | 3                     | ✅ All tasks ≤30 min |
| P3.2     | ~135 min   | ~135 min             | 1                     | ✅ All tasks ≤30 min |
| P3.3     | ~55 min    | ~45 min              | 2                     | ✅ All tasks ≤20 min |

### Optimal Parallel Execution Plan

**Session 1: Foundation (P0)**

- Sequential: P0.1 tasks 1-5 - 30 min
- Mixed: P0.2 tasks 1-16 - 58 min with 4-agent parallelization
- **Total:** ~88 minutes (1.5 hours)

**Session 2: Core Infrastructure (P1)**

- Sequential/Parallel: P1.0 tasks 1-4 - 6 min with partial parallelization
- Mixed: P1.1 tasks 1-8 - 60 min with 6-agent parallelization
- Parallel: P1.2 tasks 1-3 - 30 min with 3-agent parallelization
- Sequential: P1.3 tasks 1-2 - 20 min
- Sequential: P1.5 tasks 1-5 - 70 min
- **Total:** ~186 minutes (3.1 hours)

**Session 3: Testing Infrastructure (P2)**

- Mixed: P2.1 tasks 1-10 - 115 min with 3-agent parallelization
- Parallel: P2.2 agents 1-4 - 30 min with 4-agent parallelization
- **Total:** ~145 minutes (2.4 hours)

**Session 4: Enhancements (P3)**

- Parallel: P3.1 agents 1-3 - 30 min with 3-agent parallelization
- Sequential: P3.2 tasks 1-6 - 135 min
- Partial: P3.3 tasks 1-4 - 45 min with 2-agent parallelization
- **Total:** ~210 minutes (3.5 hours)

### Critical Success Factors

1. ✅ **All tasks ≤30 minutes** - Meets AI capability threshold
2. ✅ **Upstream dependencies clearly marked** - Prevents parallel execution errors
3. ✅ **Verification steps included** - P0.2, P1.0, P1.2, P1.3, P1.5, P2.1 have explicit verification
4. ✅ **Parallelization opportunities documented** - Each section specifies which tasks can run in parallel
5. ✅ **Context windows minimized** - Tasks reference specific files and line numbers

---

## 🎯 Next Actions

### ✅ COMPLETED: P0.1 - Label Taxonomy Finalization & Implementation

**Completed:** 2025-11-10 | **By:** AI (Claude) | **Commits:** 811616a, d5f84bf, 3e9f177, 2aa69c3 (merge)
**Estimated:** ~30 minutes | **Actual:** ~45 minutes

**Tasks Completed:**

1. ✅ **COMPLETED:** 2025-11-10 | By: AI | Commit: 811616a | Updated LABEL_DESIGN_SPEC.md (v1.3)
   - Added `type: function` - Brown #292524
   - Added `type: tooling` - Gray #6b7280
   - Changed `type: improvement` color to Tan #78716c
   - Updated hierarchy rules documentation
   - File: `LABEL_DESIGN_SPEC.md:173-183`

2. ✅ **COMPLETED:** 2025-11-10 | By: AI | Commit: 811616a | Updated .github/settings.yml
   - Added new label definitions
   - Updated existing label colors
   - File: `.github/settings.yml`

3. ✅ **COMPLETED:** 2025-11-10 | By: AI | N/A | Ran label sync dry run
   - Discovered need to commit changes first
   - Validated configuration syntax

4. ✅ **COMPLETED:** 2025-11-10 | By: AI | Commit: 811616a | Committed and pushed changes
   - Pushed to branch: `claude/review-commit-and-todos-011CUyLg3uqtfCCq4D8NrEpW`
   - Changes verified on GitHub

5. ✅ **COMPLETED:** 2025-11-10 | By: AI | N/A | Ran label sync (apply mode)
   - Workflow: `apply_settings.yml`
   - Mode: `apply`
   - Result: 2 labels created, 1 label updated

6. ✅ **COMPLETED:** 2025-11-10 | By: AI | N/A | Fixed issue #26 labels
   - Removed: `type: test` (incorrect)
   - Added: `type: tooling` (correct)
   - Kept: `type: feature`, `difficulty: complex`, `ai: human+ai`, `needs-human`, `workflow: backlog`
   - Reason: #26 is testing infrastructure (tooling), not a test case

**Results:**

- 2 new labels created: `type: function`, `type: tooling`
- 1 label color updated: `type: improvement`
- Issue #26 correctly labeled
- Total label count: 34 → 36
- LABEL_DESIGN_SPEC.md updated to v1.3

---

### 🚀 NEXT: P0.2 - Issue Template Framework

Ready to start P0.2 (16 tasks across 3 phases)

### ⚠️ URGENT ADDITION: P0.0

**P0.0 URGENT: Create Hook/Reminder for Workflow Monitoring**

- Problem: Using `sleep + gh run list` instead of `gh run watch --exit-status`
- Solution: Create hook or configuration to remind/prevent incorrect workflow monitoring pattern
- Priority: Before next workflow trigger
- Estimated: 30 minutes

---

## 📜 COMPLETED TASKS ARCHIVE

This section contains all completed work with full attribution and timestamps. Tasks are NEVER deleted.

### P0.1 - Label Taxonomy Finalization & Implementation

**Completed:** 2025-11-10 | **By:** AI (Claude) | **Commits:** 811616a, d5f84bf, 3e9f177, 2aa69c3 (merge)
**Estimated:** ~30 minutes | **Actual:** ~45 minutes

**Tasks:**

1. ✅ **COMPLETED:** 2025-11-10 | By: AI | Commit: 811616a | Updated LABEL_DESIGN_SPEC.md (v1.3) - Added `type: function`, `type: tooling`, updated `type: improvement` color
2. ✅ **COMPLETED:** 2025-11-10 | By: AI | Commit: 811616a | Updated .github/settings.yml with new labels
3. ✅ **COMPLETED:** 2025-11-10 | By: AI | N/A | Ran label sync dry run - validated configuration
4. ✅ **COMPLETED:** 2025-11-10 | By: AI | Commit: 811616a | Committed and pushed to branch
5. ✅ **COMPLETED:** 2025-11-10 | By: AI | N/A | Ran label sync (apply mode) - 2 created, 1 updated
6. ✅ **COMPLETED:** 2025-11-10 | By: AI | N/A | Fixed issue #26 labels (removed `type: test`, added `type: tooling`)

**Results:** 2 new labels created, 1 updated, issue #26 fixed, total 34→36 labels, LABEL_DESIGN_SPEC.md v1.3

### Previous Work (Pre-Tracking System)

**Source:** See `docs/archive/TODO_2025-11-10.md:1220-1467` for detailed history

**Major Completions:**

- ✅ **COMPLETED:** 2025-11-09 | By: AI | Multiple commits | Formatter Diff & Review UI (Step 6) - Interactive pre-commit hook with merge/replace/cancel
- ✅ **COMPLETED:** 2025-11-10 | By: AI | Multiple commits | Atomic TDD Framework Documentation - Complete 5-level hierarchy specification
- ✅ **COMPLETED:** 2025-11-08 | By: AI | Multiple commits | Pre-Push Commit Squashing Hook - Enhanced with advanced features
- ✅ **COMPLETED:** 2025-11-08 | By: AI | Multiple commits | Workflow Improvements - Multiple sessions covering validation, state machine, error handling
- ✅ **COMPLETED:** 2025-11-08 | By: AI | Commit 6369e47 | Label Design Spec apply_settings.mjs fixes
- ✅ **COMPLETED:** 2025-11-08 | By: AI | Multiple commits | Workflow Behavior Documentation (.github/WORKFLOW_BEHAVIOR.md) - 23KB comprehensive guide
- ✅ **COMPLETED:** 2025-11-08 | By: AI | Multiple commits | .gitattributes for cross-platform compatibility
- ✅ **COMPLETED:** 2025-11-08 | By: AI | Multiple commits | Repository variables documentation (.github/REPO_VARIABLES.md)

---

## 📚 Reference Documents

### Active Documents

- **TASK_REFERENCE_INDEX.md** - Complete task mapping, shows where every task is referenced
- **ATOMIC_TDD_FRAMEWORK.md** (was even_more_todo.md) - TDD framework specification
- **LABEL_DESIGN_SPEC.md** - Label taxonomy v1.3 (single source of truth)
- **README.md** - System overview, hierarchy, naming conventions
- **.github/WORKFLOW_BEHAVIOR.md** - Workflow documentation

### Archived Documents (Historical Reference)

- **docs/archive/TODO_2025-11-10.md** - Original comprehensive TODO with completed tasks (1545 lines)
- **docs/archive/TODO_REVIEW_AND_LOGGING_PLAN_2025-11-10.md** - Logging infrastructure design and audit (1112 lines)

---

**Last Updated:** 2025-11-10
**Tracking System Version:** 1.0 (Enhanced with timestamps, attribution, never-delete policy)
**Source Files:** current_work_todo.md (primary), TASK_REFERENCE_INDEX.md (mapping), archived TODOs (historical detail)
