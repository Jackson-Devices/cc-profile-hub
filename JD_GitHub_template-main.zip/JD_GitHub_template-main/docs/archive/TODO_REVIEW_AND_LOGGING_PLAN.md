# TODO.md Comprehensive Review & Logging Infrastructure Plan

**Generated:** 2025-11-08
**Purpose:** Full audit of TODO.md accuracy + Comprehensive logging infrastructure design

---

## Part 1: TODO.md Accuracy Audit

### ❌ INCORRECTLY MARKED AS INCOMPLETE

**Line 120-124: Create workflow behavior documentation**

```markdown
- [ ] Create workflow behavior documentation (`.github/WORKFLOW_BEHAVIOR.md`)
  - [ ] Document triggers, concurrency model, failure modes
  - [ ] Provide examples of all commands
  - [ ] Document validation label state machine (blocked → pending → passed)
```

**STATUS:** ✅ **ACTUALLY COMPLETE**
**EVIDENCE:** `.github/WORKFLOW_BEHAVIOR.md` exists (23,113 bytes, modified 2025-11-08)
**ACTION:** Mark as [x] and verify content includes all sub-items

---

**Line 151-153: Create/update .gitattributes**

```markdown
- [ ] Create/update `.gitattributes` for line ending normalization
  - [ ] Define rules for `.yml`, `.yaml`, `.md`, `.mjs`, `.js` files
  - [ ] Test on Windows and Linux (or Docker)
```

**STATUS:** ✅ **PARTIALLY COMPLETE**
**EVIDENCE:** `.gitattributes` exists (2,605 bytes, modified 2025-11-08)
**ACTION:** Mark first two sub-items as [x], keep testing sub-item as [ ]

---

### ✅ CORRECTLY MARKED BUT NEEDS VERIFICATION

**Line 57-59: Repository variables documentation**

```markdown
- [x] Create repository variables documentation (`.github/REPO_VARIABLES.md`)
  - [x] Document all configurable variables with descriptions and defaults
  - [x] Include which workflows use each variable
```

**STATUS:** ✅ **CONFIRMED COMPLETE**
**EVIDENCE:** `.github/REPO_VARIABLES.md` exists (4,011 bytes)

---

### 🔍 POORLY DEFINED TASKS (Need Breakdown)

**Line 127-146: Documentation Refactoring (Next Session)**

**PROBLEM:** Tasks are too large and vague. "Create docs/ directory structure" could mean many things.

**IMPROVED BREAKDOWN:**

```markdown
### Documentation Refactoring (Next Session)

**Step 1: Directory Structure Setup**

- [ ] Create `docs/` directory in repository root
- [ ] Create `docs/examples/` subdirectory
- [ ] Create `docs/workflows/` subdirectory
- [ ] Create `docs/ai_work/` subdirectory
- [ ] Create `docs/diagrams/` subdirectory (for mermaid sources)
- [ ] Add `docs/.gitkeep` or `docs/README.md` to ensure directory commits

**Step 2: Extract and Move Test Naming Examples**

- [ ] Identify all test naming examples in README.md (search for "IB-", "OOB-", "T-")
- [ ] Create `docs/examples/test_naming_examples.md` with structure:
  - [ ] IB (In-Bounds) test naming rules with 5+ examples
  - [ ] OOB (Out-Of-Bounds) test naming rules with 5+ examples
  - [ ] T-ID naming convention with 5+ examples
  - [ ] Namespace examples (issue #100 vs #101)
- [ ] Remove extracted content from README.md
- [ ] Add link in README.md: "See [Test Naming Examples](docs/examples/test_naming_examples.md)"

**Step 3: Extract and Move Hierarchy Examples**

- [ ] Identify hierarchy explanations in README.md (Feature → Suite → Test)
- [ ] Create `docs/examples/hierarchy_examples.md` with structure:
  - [ ] Parent Feature (p) level explanation
  - [ ] Child Suite (c1) level explanation
  - [ ] Leaf Test level explanation
  - [ ] Full hierarchy tree example with 3 features × 2 suites × 5 tests
  - [ ] Cross-references between hierarchy levels
- [ ] Remove extracted content from README.md
- [ ] Add link in README.md: "See [Hierarchy Examples](docs/examples/hierarchy_examples.md)"

**Step 4: Create Decision Log Full Example**

- [ ] Design realistic decision log scenario (test failure, 3 AI passes, escalation)
- [ ] Create `docs/examples/decision_log_example_full.md` with:
  - [ ] Pass 1: Initial attempt with GPT-4, failure analysis
  - [ ] Pass 2: Refinement with Claude, partial success
  - [ ] Pass 3: Final attempt, escalation to human
  - [ ] Complete change log for each pass (file, line, code, why)
  - [ ] Test execution details (commands, seeds, results)
  - [ ] Failure analysis for each failed attempt
- [ ] Reference this example from issue template

**Step 5: Create Workflow Detail Documentation**

- [ ] Create `docs/workflows/test_workflow_detailed.md`:
  - [ ] Trigger conditions (issue events, labels, commands)
  - [ ] Step-by-step execution flow with decision trees
  - [ ] Label state transitions (blocked → pending → passed)
  - [ ] IB/OOB gate logic with examples
  - [ ] Checklist generation algorithm
  - [ ] Error handling and retry logic
- [ ] Create `docs/workflows/ai_self_correction.md`:
  - [ ] Max pass enforcement logic
  - [ ] Escalation trigger conditions
  - [ ] Decision log requirements per pass
  - [ ] Human handoff procedure
  - [ ] Re-entry conditions after human intervention

**Step 6: Create AI Work Documentation**

- [ ] Create `docs/ai_work/decision_log_format.md`:
  - [ ] Required sections specification (YAML frontmatter structure)
  - [ ] Pass header fields (model, timestamp, status, commit SHA)
  - [ ] Change log entry schema (file, line range, old code, new code, rationale)
  - [ ] Test execution schema (command, environment vars, seeds, stdout/stderr)
  - [ ] Failure analysis schema (error type, root cause, attempted fixes)
  - [ ] Next actions schema (blocking issues, human questions, plan)
- [ ] Create `docs/ai_work/max_pass_enforcement.md`:
  - [ ] Default max pass value (5) and override mechanism
  - [ ] Pass counting logic (when does counter increment?)
  - [ ] Escalation workflow (what happens at max+1?)
  - [ ] needs-human label auto-application
  - [ ] Human notification comment template
  - [ ] Reset conditions (when does counter reset?)
- [ ] Create `docs/ai_work/performance_metrics.md`:
  - [ ] Token usage tracking (prompt tokens, completion tokens, total)
  - [ ] Time tracking (start, end, elapsed per pass, total)
  - [ ] Model selection tracking (which model used when and why)
  - [ ] Success rate metrics (pass count, failure count, success on first try)
  - [ ] Code churn metrics (lines added, deleted, modified per pass)

**Step 7: Add Mermaid Diagrams to README**

- [ ] Create mermaid diagram: Label sync workflow
  - [ ] Source in `docs/diagrams/label_sync_flow.mmd`
  - [ ] Embed in README.md showing: settings.yml → validation → GitHub API → label updates
- [ ] Create mermaid diagram: Test validation gate
  - [ ] Source in `docs/diagrams/test_gate_flow.mmd`
  - [ ] Show: Issue → IB/OOB check → Gate pass/fail → Label update → Block/Allow
- [ ] Create mermaid diagram: Seed-test-runlist workflow
  - [ ] Source in `docs/diagrams/seed_runlist_flow.mmd`
  - [ ] Show: Parse IB/OOB → Sort (OOB-01 → IB-01 → OOB-02) → Generate checklist → Detect conflicts
- [ ] Create mermaid diagram: Context-commands workflow
  - [ ] Source in `docs/diagrams/context_commands_flow.mmd`
  - [ ] Show: Command dispatch → YAML parse → Validate → Update context → Sync hierarchy

**Step 8: Update Cross-References**

- [ ] Update README.md with pointers to all docs/ files
- [ ] Update issues_rules.md with pointers to workflow docs
- [ ] Verify LABEL_DESIGN_SPEC.md doesn't need updates
- [ ] Add "Documentation Map" section to README.md listing all docs/ files
```

---

**Line 159-165: Issue Template Enhancements**

**PROBLEM:** "Add AI metadata fields" is too vague. What fields? Where? What format?

**IMPROVED BREAKDOWN:**

```markdown
### Issue Template Enhancements

**Step 1: Design AI Metadata Fields**

- [ ] Review `.github/ISSUE_TEMPLATE/test.yml` current structure
- [ ] Design field schema for AI Model(s) Used:
  - [ ] Field type: textarea or dropdown?
  - [ ] Options: GPT-4, Claude 3.5 Sonnet, Claude 3 Opus, Other (specify)
  - [ ] Required or optional?
- [ ] Design field schema for AI Pass Count:
  - [ ] Field type: number input
  - [ ] Default value: 0
  - [ ] Min: 0, Max: 99
  - [ ] Description: "How many AI attempts so far (auto-incremented by workflow)"
- [ ] Design field schema for Max AI Passes:
  - [ ] Field type: number input
  - [ ] Default value: 5
  - [ ] Min: 1, Max: 20
  - [ ] Description: "Escalate to human after this many attempts"

**Step 2: Add Fields to test.yml Template**

- [ ] Add "AI Metadata" section to `.github/ISSUE_TEMPLATE/test.yml`
- [ ] Insert fields in correct YAML structure (after Test ID, before Test Cases)
- [ ] Add validation rules (required fields, number ranges)
- [ ] Test template rendering in GitHub UI (create test issue)

**Step 3: Update Validation Gate Description**

- [ ] Add note about max pass behavior in validation gate checkbox description
- [ ] Example: "When AI passes exceed {Max AI Passes}, issue auto-escalates to human"
- [ ] Link to max pass documentation: `docs/ai_work/max_pass_enforcement.md`

**Step 4: Add Decision Log Pointer**

- [ ] Add "Decision Log" section to template
- [ ] Link to format spec: `docs/ai_work/decision_log_format.md`
- [ ] Add example: `docs/examples/decision_log_example_full.md`
- [ ] Explain append behavior (one file per issue, grows over time)
```

---

**Line 167-177: Workflow Enhancements**

**PROBLEM:** "Create max pass enforcement" is complex, needs detailed steps.

**IMPROVED BREAKDOWN:**

```markdown
### Workflow Enhancements

**Step 1: Design Max Pass Enforcement Logic**

- [ ] Define where pass count is stored (issue body YAML? label? comment metadata?)
- [ ] Define increment trigger (when does count go up? On validation: failed label? On new decision log entry?)
- [ ] Define reset conditions (when does count go back to 0? On validation: passed? On human intervention comment?)
- [ ] Document edge cases (concurrent workflows, manual label changes, count tampering)

**Step 2: Read AI Pass Count from Issue Body**

- [ ] Add github-script action to enforce_test_gate.yml
- [ ] Parse issue body YAML to extract `ai_pass_count` field
- [ ] Default to 0 if field missing or malformed
- [ ] Store in workflow variable: `AI_PASS_COUNT`

**Step 3: Read Max AI Passes from Issue Body**

- [ ] Parse issue body YAML to extract `max_ai_passes` field
- [ ] Default to 5 if field missing or malformed
- [ ] Store in workflow variable: `MAX_AI_PASSES`
- [ ] Add repository variable override: `DEFAULT_MAX_AI_PASSES=5`

**Step 4: Implement Pass Count Increment Logic**

- [ ] Add condition: `if: contains(github.event.issue.labels.*.name, 'validation: failed')`
- [ ] Increment `AI_PASS_COUNT` by 1
- [ ] Update issue body YAML with new count
- [ ] Add audit comment: "AI Pass {count}/{max} - validation failed, incrementing counter"

**Step 5: Implement Max Pass Check**

- [ ] Add condition: `if: env.AI_PASS_COUNT >= env.MAX_AI_PASSES`
- [ ] Auto-apply `needs-human` label via GitHub API
- [ ] Post escalation comment template:
```

🚨 **AI Pass Limit Reached ({count}/{max})**

This test has failed validation {count} times. Automatic escalation to human review.

**Next Steps:**

1. Review decision log: `.ai_logs/issue_{number}_decision_log.md`
2. Analyze failure patterns across all {count} attempts
3. Determine if issue requires human intervention or model adjustment

**To reset counter:** Add comment `/reset-passes` (requires human approval)

```

**Step 6: Implement Specific IB/OOB Failure Tracking**
- [ ] Parse run checklist state from issue body
- [ ] Extract checked/unchecked items: `- [x] OOB-01`, `- [ ] IB-02`
- [ ] Identify which specific cases failed (unchecked items)
- [ ] Generate failure detail comment:
```

❌ **Validation Gate Blocked**

**Failed Cases:**

- IB-02: Description from issue body
- OOB-05: Description from issue body

**Passed Cases:**

- OOB-01: Description from issue body
- IB-01: Description from issue body

See decision log for failure analysis: `.ai_logs/issue_{number}_decision_log.md#pass-{count}`

```
- [ ] Link to decision log file (create anchor links per pass)

**Step 7: Test All Workflows**
- [ ] Test label sync with new taxonomy (dry_run mode first)
- [ ] Test max pass enforcement (manually increment count to trigger)
- [ ] Test specific failure tracking (create test issue with failing cases)
- [ ] Verify label state machine works correctly
- [ ] Test edge cases (concurrent runs, manual edits, missing fields)
```

---

**Line 179-189: Decision Log Infrastructure**

**PROBLEM:** Missing critical details about log format, storage, and automation.

**IMPROVED BREAKDOWN:**

`````markdown
### Decision Log Infrastructure

**Step 1: Design Directory Structure**

- [ ] Create `.ai_logs/` directory in repository root
- [ ] Add `.ai_logs/.gitignore` to exclude sensitive data (API keys, tokens in logs)
- [ ] Add `.ai_logs/README.md` explaining purpose and structure
- [ ] Decision: Per-issue files vs per-pass files? (Answer: per-issue, append mode)

**Step 2: Define Log File Naming Convention**

- [ ] Format: `issue_{number}_decision_log.md`
- [ ] Examples:
  - Issue #42 → `.ai_logs/issue_0042_decision_log.md` (zero-padded for sorting)
  - Issue #123 → `.ai_logs/issue_0123_decision_log.md`
- [ ] Add index file: `.ai_logs/INDEX.md` linking all decision logs

**Step 3: Create Decision Log Template**

- [ ] Create `.ai_logs/TEMPLATE.md` with structure:

  ````markdown
  # Decision Log - Issue #{number}: {title}

  **Issue URL:** {url}
  **Test ID:** {test_id}
  **Created:** {timestamp}
  **Status:** {In Progress | Passed | Failed | Escalated}

  ---

  ## Pass {N}: {Status}

  ### Metadata

  - **Model:** {model_name} ({model_id})
  - **Timestamp:** {ISO 8601 timestamp}
  - **Commit:** {SHA before changes} → {SHA after changes}
  - **Status:** {Attempted | Success | Failed}
  - **Elapsed Time:** {seconds}
  - **Token Usage:** {prompt_tokens} prompt + {completion_tokens} completion = {total_tokens} total

  ### Changes Made

  #### File: {path/to/file.ext}

  **Lines {start}-{end}**

  **Before:**

  ```{language}
  {old code}
  ```
  ````
`````

````

**After:**

```{language}
{new code}
```

**Rationale:** {why this change}
**Reasoning:** {how AI decided this was the right approach}
**Alternatives Considered:** {what else was evaluated}

### Test Execution

**Command:** `{command with all flags}`
**Working Directory:** `{pwd}`
**Environment:**

- `{VAR1}={value1}`
- `{VAR2}={value2}`
  **Seed/Determinism:** {random seeds used for reproducibility}

**Exit Code:** {0 = success, non-zero = failure}

**stdout:**

```
{standard output}
```

**stderr:**

```
{standard error}
```

**Results:**

- ✅ OOB-01: Passed - {brief description}
- ✅ IB-01: Passed - {brief description}
- ❌ IB-02: FAILED - {error message}

### Failure Analysis (if failed)

**Error Type:** {Syntax | Semantic | Hardware Mismatch | Logic Error}
**Root Cause:** {analysis of why it failed}
**Attempted Fixes:** {what was tried to fix it}
**Why Fixes Failed:** {analysis of unsuccessful attempts}

### Next Actions

**Blocking Issues:**

- {issue 1}
- {issue 2}

**Questions for Human:**

- {question 1}
- {question 2}

**Plan for Next Pass:**

- {approach for next attempt}

---

```

**Step 4: Implement Client-Side Logging Hook**
- [ ] Add hook placeholder in Claude Code settings (`.claude/hooks.json`)
- [ ] Hook triggers on every tool call, command execution, file edit
- [ ] Hook appends to decision log file (NO additional token usage)
- [ ] Hook captures:
- [ ] All Read/Write/Edit operations (file path, operation type, timestamp)
- [ ] All Bash command executions (command, exit code, stdout/stderr)
- [ ] All API calls (endpoint, method, status code, response time)
- [ ] All AI tool uses (tool name, parameters, result)
- [ ] Timestamp for every event (microsecond precision)

**Step 5: Document Append Behavior**
- [ ] Explain one file per issue (grows over time, never reset)
- [ ] Explain pass numbering (Pass 1, Pass 2, ..., Pass N)
- [ ] Explain how to find specific pass (anchor links: `#pass-3`)
- [ ] Explain file size management (when to split? Archive old passes?)
- [ ] Add to `docs/ai_work/decision_log_format.md`
```

---

## Part 2: Implementation Order (Dependency-Aware)

**Priority 1: LOGGING INFRASTRUCTURE (Prerequisite for everything else)**

```
ORDER: L1 → L2 → L3 → L4 → L5
```

**L1. Design Logging System Architecture**

- Line 514-519: Custom Decision Logging section
- Line 179-189: Decision Log Infrastructure
- **WHY FIRST:** All subsequent work depends on logging to learn from mistakes

**L2. Implement Client-Side (Claude Code) Logging**

- Client-side hook implementation (zero token overhead)
- **BLOCKS:** L3, L4, L5 (need local logging working first)

**L3. Implement GitHub Actions Logging**

- Workflow-based decision log appending
- **DEPENDS ON:** L2 (need log format defined)
- **BLOCKS:** L4 (need GitHub logging before adding Workers)

**L4. Implement Cloudflare Workers Logging**

- Workers telemetry and audit trails
- **DEPENDS ON:** L3 (need centralized log aggregation strategy)

**L5. Implement Log Analysis & Learning**

- Parse logs to identify patterns, optimize prompts, choose models
- **DEPENDS ON:** L2, L3, L4 (need data to analyze)

---

**Priority 2: DOCUMENTATION (Makes AI work easier)**

```
ORDER: D1 → D2 → D3
```

**D1. Fix Incorrectly Marked Items**

- Line 120-124: Mark WORKFLOW_BEHAVIOR.md as complete
- Line 151-153: Mark .gitattributes as partially complete

**D2. Break Down Poorly Defined Tasks**

- Line 127-146: Documentation Refactoring (use improved breakdown above)
- Line 159-165: Issue Template Enhancements (use improved breakdown above)
- Line 167-177: Workflow Enhancements (use improved breakdown above)

**D3. Complete Remaining Docs**

- Line 124: Update README.md links
- Line 145-146: Update issues_rules.md, verify LABEL_DESIGN_SPEC.md

---

**Priority 3: WORKFLOW VALIDATION & TESTING**

```
ORDER: V1 → V2 → V3
```

**V1. Test Existing Workflows**

- Line 193-214: Testing & Validation section
- **DEPENDS ON:** L2, L3 (need logging to capture test results)

**V2. Implement Max Pass Enforcement**

- Line 167-177: Workflow Enhancements (use improved breakdown)
- **DEPENDS ON:** V1 (need tested workflows before adding complexity)

**V3. Validate Label Taxonomy**

- Line 210-214: Validate Label Taxonomy
- **DEPENDS ON:** V1, V2 (need working workflows)

---

**Priority 4: PLATFORM/ENVIRONMENT SETUP**

```
ORDER: P1 → P2
```

**P1. Complete .gitattributes Testing**

- Line 151-153: Test on Windows and Linux
- **DEPENDS ON:** V3 (need validated workflows on both platforms)

**P2. Audit Cross-Platform Compatibility**

- Line 154-157: Platform/Environment Setup
- **DEPENDS ON:** P1 (need .gitattributes tested first)

---

**Priority 5: FUTURE ENHANCEMENTS (Lower Priority)**

```
ORDER: F1 → F2 → F3 → F4
```

**F1. Slack Integration**

- Line 218-238: Slack Integration
- **DEPENDS ON:** L5 (need logging to notify Slack)

**F2. GitHub Actions Synthetic Testing**

- Line 253-271: Synthetic Testing Research
- **DEPENDS ON:** V3 (need validated workflows)

**F3. PlatformIO/LLVM Validation**

- Line 273-385: PlatformIO/LLVM section
- **DEPENDS ON:** F2 (synthetic testing is prerequisite)

**F4. Cloudflare Workers Offloading**

- Line 387-482: Cloudflare Workers section
- **DEPENDS ON:** L4, F3 (need Workers logging + validation workloads)

---

## Part 3: Comprehensive Logging Infrastructure Design

### Overview

**Goal:** AI learns from mistakes, optimizes prompts, chooses models wisely, tracks token efficiency.

**Three-Tier Logging System:**

1. **Client-Side (Claude Code):** Zero-token verbose logging via hooks
2. **GitHub Actions:** Workflow execution logging in decision logs
3. **Cloudflare Workers:** Edge compute logging with centralized aggregation

**Key Principle:** NO ADDITIONAL TOKEN USAGE for logging. Hooks capture all data passively.

---

### Tier 1: Client-Side Logging (Claude Code Hooks)

**Implementation Location:** `.claude/hooks.json` (local, not committed)

**Hook Events to Capture:**

```json
{
  "hooks": {
    "pre-tool-call": {
      "enabled": true,
      "script": ".claude/scripts/log_tool_call.sh",
      "log_file": ".ai_logs/local_session_{timestamp}.jsonl"
    },
    "post-tool-call": {
      "enabled": true,
      "script": ".claude/scripts/log_tool_result.sh",
      "log_file": ".ai_logs/local_session_{timestamp}.jsonl"
    },
    "pre-command": {
      "enabled": true,
      "script": ".claude/scripts/log_command.sh",
      "log_file": ".ai_logs/local_session_{timestamp}.jsonl"
    },
    "post-command": {
      "enabled": true,
      "script": ".claude/scripts/log_command_result.sh",
      "log_file": ".ai_logs/local_session_{timestamp}.jsonl"
    },
    "file-edit": {
      "enabled": true,
      "script": ".claude/scripts/log_file_edit.sh",
      "log_file": ".ai_logs/local_session_{timestamp}.jsonl"
    }
  }
}
```

**Data Captured Per Event:**

```jsonl
{"event":"pre_tool_call","timestamp":"2025-11-08T14:23:45.123456Z","tool":"Read","params":{"file_path":"TODO.md","offset":100,"limit":50},"context":{"session_id":"sess_123","conversation_turn":5}}
{"event":"post_tool_call","timestamp":"2025-11-08T14:23:45.456789Z","tool":"Read","result_size":2048,"success":true,"duration_ms":123}
{"event":"pre_command","timestamp":"2025-11-08T14:24:00.000000Z","command":"git status","cwd":"/path/to/repo"}
{"event":"post_command","timestamp":"2025-11-08T14:24:00.234567Z","command":"git status","exit_code":0,"stdout_lines":12,"stderr_lines":0,"duration_ms":234}
{"event":"file_edit","timestamp":"2025-11-08T14:25:00.000000Z","file":"TODO.md","operation":"edit","line_start":120,"line_end":124,"old_content_hash":"abc123","new_content_hash":"def456","reason":"Mark WORKFLOW_BEHAVIOR.md as complete"}
```

**Log Aggregation:**

- Each Claude Code session creates a new JSONL file
- File named: `.ai_logs/local_session_{ISO8601_timestamp}.jsonl`
- Never committed to git (`.ai_logs/*.jsonl` in .gitignore)
- Analyzed locally to generate insights

**Analysis Scripts:**

```bash
# .claude/scripts/analyze_session.sh

#!/bin/bash
SESSION_LOG="$1"

# Extract token usage per tool
jq -r 'select(.event=="post_tool_call") | "\(.tool) \(.result_size)"' "$SESSION_LOG" | \
  awk '{tool[$1]+=$2} END {for (t in tool) print t, tool[t]}' | \
  sort -k2 -rn

# Extract command execution times
jq -r 'select(.event=="post_command") | "\(.command) \(.duration_ms)"' "$SESSION_LOG" | \
  awk '{cmd[$1]; times[$1]+=$2; count[$1]++} END {for (c in cmd) print c, times[c]/count[c] "ms avg"}' | \
  sort -k2 -rn

# Identify most edited files
jq -r 'select(.event=="file_edit") | .file' "$SESSION_LOG" | \
  sort | uniq -c | sort -rn

# Calculate total session time
START=$(jq -r 'select(.event=="pre_tool_call") | .timestamp' "$SESSION_LOG" | head -1)
END=$(jq -r '.timestamp' "$SESSION_LOG" | tail -1)
DURATION=$(( $(date -d "$END" +%s) - $(date -d "$START" +%s) ))
echo "Total session duration: ${DURATION}s"
```

**Learning Insights:**

1. **Token Efficiency:**
   - Which tools use most tokens? (Read with large offsets? Grep with broad patterns?)
   - Optimize: Use Glob before Read, narrow Grep patterns

2. **Command Performance:**
   - Which commands are slowest? (git operations? npm install?)
   - Optimize: Cache npm dependencies, use shallow git clones

3. **Edit Patterns:**
   - Which files edited most frequently? (sign of unclear requirements?)
   - Optimize: Front-load clarification questions

4. **Session Duration:**
   - How long to complete similar tasks?
   - Optimize: Identify compounding vs repetitive tasks

---

### Tier 2: GitHub Actions Logging

**Implementation:** Workflow steps append to decision log files

**Workflow: `.github/workflows/decision_log_writer.yml`**

```yaml
name: Decision Log Writer

on:
  workflow_call:
    inputs:
      issue_number:
        required: true
        type: number
      pass_number:
        required: true
        type: number
      status:
        required: true
        type: string
      model_used:
        required: true
        type: string
      changes_json:
        required: true
        type: string
      test_results_json:
        required: true
        type: string

jobs:
  append_log:
    runs-on: ubuntu-latest
    steps:
      - name: Checkout repository
        uses: actions/checkout@v4
        with:
          token: ${{ secrets.GITHUB_TOKEN }}

      - name: Create .ai_logs directory if needed
        run: mkdir -p .ai_logs

      - name: Generate decision log entry
        id: generate
        uses: actions/github-script@v7
        with:
          script: |
            const issueNumber = ${{ inputs.issue_number }};
            const passNumber = ${{ inputs.pass_number }};
            const status = '${{ inputs.status }}';
            const model = '${{ inputs.model_used }}';
            const changes = JSON.parse('${{ inputs.changes_json }}');
            const testResults = JSON.parse('${{ inputs.test_results_json }}');

            const logFile = `.ai_logs/issue_${String(issueNumber).padStart(4, '0')}_decision_log.md`;

            // Generate log entry (see template in Part 1, Step 3)
            const entry = `
## Pass ${passNumber}: ${status}

### Metadata
- **Model:** ${model}
- **Timestamp:** ${new Date().toISOString()}
- **Commit:** ${context.sha}
- **Status:** ${status}

### Changes Made
${changes.map(c => `
#### File: ${c.file}
**Lines ${c.lineStart}-${c.lineEnd}**

**Before:**
\`\`\`${c.language}
${c.oldCode}
\`\`\`

**After:**
\`\`\`${c.language}
${c.newCode}
\`\`\`

**Rationale:** ${c.rationale}
`).join('\n')}

### Test Results
${testResults.map(t => `- ${t.passed ? '✅' : '❌'} ${t.id}: ${t.description}`).join('\n')}

---
`;

            // Append to log file
            const fs = require('fs');
            fs.appendFileSync(logFile, entry);

            return logFile;

      - name: Commit decision log
        run: |
          git config user.name "github-actions[bot]"
          git config user.email "github-actions[bot]@users.noreply.github.com"
          git add .ai_logs/
          git commit -m "Append decision log for issue #${{ inputs.issue_number }} pass ${{ inputs.pass_number }}"
          git push
```

**Integration Points:**

- `enforce_test_gate.yml`: Call after validation fails, pass failure details
- `seed-test-runlist.yml`: Call after checklist generation with IB/OOB parsing results
- `validate-issue.yml`: Call after validation with error/warning details

**Guardrails:**

1. **Prevent Tampering:**
   - Decision logs are append-only (workflow never deletes/modifies past entries)
   - Git history preserves all changes (audit trail)

2. **Prevent Information Leakage:**
   - Sensitive data (API keys, tokens) filtered before logging
   - Use secrets for credentials, never log raw secrets

3. **Prevent Excessive File Size:**
   - Limit log entry size (max 10KB per entry)
   - Archive logs after 100 passes (move to `.ai_logs/archive/`)

---

### Tier 3: Cloudflare Workers Logging

**Implementation:** Workers Durable Objects for centralized log aggregation

**Worker: `log-aggregator`**

```typescript
// src/log-aggregator.ts

export class LogAggregator {
  state: DurableObjectState;

  constructor(state: DurableObjectState, env: Env) {
    this.state = state;
  }

  async fetch(request: Request): Promise<Response> {
    const url = new URL(request.url);

    if (url.pathname === '/log') {
      return this.appendLog(request);
    } else if (url.pathname === '/query') {
      return this.queryLogs(request);
    }

    return new Response('Not found', { status: 404 });
  }

  async appendLog(request: Request): Promise<Response> {
    const log = await request.json();

    // Validate log schema
    if (!log.timestamp || !log.source || !log.event) {
      return new Response('Invalid log format', { status: 400 });
    }

    // Store in Durable Object storage (persistent)
    const key = `log:${log.timestamp}:${log.source}`;
    await this.state.storage.put(key, log);

    // Also send to analytics (for aggregation)
    await this.state.storage.put('last_log_timestamp', log.timestamp);

    return new Response('Log appended', { status: 200 });
  }

  async queryLogs(request: Request): Promise<Response> {
    const url = new URL(request.url);
    const source = url.searchParams.get('source');
    const startTime = url.searchParams.get('start');
    const endTime = url.searchParams.get('end');

    // Query logs by time range and source
    const logs = await this.state.storage.list({
      prefix: `log:`,
      start: startTime ? `log:${startTime}` : undefined,
      end: endTime ? `log:${endTime}` : undefined,
    });

    const results = [];
    for (const [key, value] of logs) {
      if (!source || value.source === source) {
        results.push(value);
      }
    }

    return new Response(JSON.stringify(results), {
      headers: { 'Content-Type': 'application/json' },
    });
  }
}
```

**Integration with GitHub Actions:**

```yaml
# In any workflow
- name: Send telemetry to Workers
  run: |
    curl -X POST https://log-aggregator.your-domain.workers.dev/log \
      -H "Content-Type: application/json" \
      -d '{
        "timestamp": "'$(date -u +%Y-%m-%dT%H:%M:%SZ)'",
        "source": "github_actions",
        "event": "workflow_run",
        "workflow": "${{ github.workflow }}",
        "job": "${{ github.job }}",
        "duration_ms": 12345,
        "status": "success"
      }'
```

**Analysis Dashboard:**

- Query logs by time range: `/query?start=2025-11-08T00:00:00Z&end=2025-11-08T23:59:59Z`
- Filter by source: `/query?source=github_actions`
- Aggregate metrics:
  - Workflow success rate over time
  - Average workflow duration
  - Most common failure reasons
  - GitHub Actions minutes usage trends

---

### Log Integration & Learning Loops

**Goal:** AI uses logs to improve decision-making

**Learning Loop 1: Model Selection**

```
INPUT: Historical logs showing model performance per task type
ANALYSIS:
  - GPT-4: Fast, good for simple tasks, 50K token limit
  - Claude 3.5 Sonnet: Balanced, handles complex tasks, 200K tokens
  - Claude 3 Opus: Slow, best for very complex tasks, 200K tokens
OUTPUT: Prompt to AI: "Based on {task_complexity} and {required_context}, use {recommended_model}"
```

**Learning Loop 2: Prompt Engineering**

```
INPUT: Logs showing task success rate per prompt structure
ANALYSIS:
  - "Do X" → 60% success rate
  - "Step 1: Read Y, Step 2: Do X" → 85% success rate
  - "Read Y, then analyze Z, then do X with rationale" → 95% success rate
OUTPUT: Update TODO.md task descriptions to use high-success prompt patterns
```

**Learning Loop 3: Token Efficiency**

```
INPUT: Logs showing token usage per tool and task
ANALYSIS:
  - Reading entire 10K line file → 50K tokens
  - Reading file with offset/limit (100 lines) → 2K tokens
  - Using Glob then targeted Read → 1K tokens
OUTPUT: Prompt to AI: "For large files, use Glob to identify target, then Read with offset"
```

**Learning Loop 4: Failure Pattern Recognition**

```
INPUT: Decision logs showing repeated failure modes
ANALYSIS:
  - 80% of IB-02 failures are due to missing HAL initialization
  - 60% of OOB-01 failures are due to off-by-one errors
OUTPUT: Update test templates with common failure warnings and prevention tips
```

---

### Guardrails for Logging System

**Prevent AI Manipulation:**

1. **Append-Only Logs:**
   - Workflows can only append, never delete or modify
   - Git history preserves all changes (audit trail)

2. **Tamper Detection:**
   - Hash each log entry (SHA256)
   - Store hash in separate file (`.ai_logs/checksums.txt`)
   - Verify hashes before analysis

3. **Human Verification:**
   - Critical decisions (escalation, model choice) require human approval
   - Logs flag when AI deviates from recommendations

**Prevent Information Leakage:**

1. **Secret Filtering:**
   - Pre-process all log data through secret detector
   - Redact API keys, tokens, passwords before logging
   - Use regex patterns: `/(sk-[A-Za-z0-9]+|ghp_[A-Za-z0-9]+)/g` → `[REDACTED]`

2. **PII Protection:**
   - Never log user emails, names, or identifiers
   - Hash user IDs before logging: `SHA256(user_id)` → `user_abc123...`

3. **Access Control:**
   - Cloudflare Workers logs require authentication
   - GitHub Actions secrets for Workers API keys
   - Read-only public logs, write-only for workflows

---

## Part 4: Implementation Checklist

**Phase 1: Logging Foundation (Week 1)**

- [ ] Create `.ai_logs/` directory structure
- [ ] Implement client-side hooks (`.claude/hooks.json`)
- [ ] Write log analysis scripts (`.claude/scripts/analyze_session.sh`)
- [ ] Test local logging with sample session
- [ ] Verify zero token overhead (compare sessions with/without logging)

**Phase 2: GitHub Actions Integration (Week 2)**

- [ ] Create `decision_log_writer.yml` workflow
- [ ] Integrate with `enforce_test_gate.yml`
- [ ] Integrate with `seed-test-runlist.yml`
- [ ] Integrate with `validate-issue.yml`
- [ ] Test full workflow with test issue
- [ ] Verify decision logs are created and appended correctly

**Phase 3: Cloudflare Workers Logging (Week 3)**

- [ ] Set up Cloudflare Workers account
- [ ] Deploy `log-aggregator` Durable Object
- [ ] Implement `/log` endpoint
- [ ] Implement `/query` endpoint
- [ ] Integrate GitHub Actions → Workers telemetry
- [ ] Test log aggregation and querying

**Phase 4: Analysis & Learning (Week 4)**

- [ ] Build log analysis dashboard (Workers → HTML/JSON)
- [ ] Implement Learning Loop 1 (Model Selection)
- [ ] Implement Learning Loop 2 (Prompt Engineering)
- [ ] Implement Learning Loop 3 (Token Efficiency)
- [ ] Implement Learning Loop 4 (Failure Pattern Recognition)
- [ ] Document all findings in `docs/ai_work/learning_insights.md`

---

## Summary

### TODO.md Accuracy Issues Found:

1. ❌ Line 120-124: WORKFLOW_BEHAVIOR.md marked incomplete, actually complete
2. ❌ Line 151-153: .gitattributes marked incomplete, actually partial complete

### Poorly Defined Tasks Fixed:

1. 📋 Documentation Refactoring → 8 detailed steps
2. 📋 Issue Template Enhancements → 4 detailed steps
3. 📋 Workflow Enhancements → 7 detailed steps
4. 📋 Decision Log Infrastructure → 5 detailed steps

### Implementation Order:

```
L1 → L2 → L3 → L4 → L5  (Logging: 5 steps)
D1 → D2 → D3            (Documentation: 3 steps)
V1 → V2 → V3            (Validation: 3 steps)
P1 → P2                 (Platform: 2 steps)
F1 → F2 → F3 → F4       (Future: 4 steps)
```

### Logging Infrastructure:

- **Tier 1:** Client-side hooks (zero-token verbose logging)
- **Tier 2:** GitHub Actions (decision log appending)
- **Tier 3:** Cloudflare Workers (centralized aggregation)
- **Learning Loops:** 4 feedback mechanisms for AI improvement

**Next Steps:**

1. Review this document with user
2. User approves implementation order
3. Start Phase 1: Logging Foundation
4. Iterate and improve based on learnings
````
