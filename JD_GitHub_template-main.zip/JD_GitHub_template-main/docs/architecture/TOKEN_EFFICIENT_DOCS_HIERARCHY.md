# Token-Efficient Documentation System - Issue Hierarchy

**Created:** 2025-11-11
**Status:** Planning Phase - Ready for issue creation

---

## Overview

This document outlines the complete issue hierarchy for implementing the Token-Efficient Documentation System following the atomic TDD framework and house style of this repository.

---

## Issue Files Created

1. ✅ `FEATURE_token_efficient_docs_system.md` - Parent Feature
2. ✅ `SUB_FEATURE_01_doc_card_infrastructure.md`
3. ✅ `SUB_FEATURE_02_tasks_map_system.md`
4. ✅ `SUB_FEATURE_03_issue_mirroring.md`
5. ✅ `SUB_FEATURE_04_drift_detection.md`
6. ✅ `SUB_FEATURE_05_validation_cli.md`
7. ✅ `SUB_FEATURE_06_helper_automations.md`

---

## Complete Hierarchy

```
FEATURE: Token-Efficient Documentation System
│
├── SUB-FEATURE #1: Doc Card Infrastructure (AC1)
│   │
│   ├── FUNCTION #1.1: Card Metadata Schema
│   │   └── TEST-SUITE #1.1.1: Schema Validation Suite
│   │       ├── TEST IB-01: Valid card metadata passes validation
│   │       ├── TEST IB-02: All required fields present
│   │       ├── TEST IB-03: Enum values validate correctly
│   │       ├── TEST OOB-01: Missing required field fails validation
│   │       ├── TEST OOB-02: Invalid enum value fails validation
│   │       └── TEST OOB-03: Malformed YAML front-matter fails validation
│   │
│   ├── FUNCTION #1.2: Card Storage Structure
│   │   └── TEST-SUITE #1.2.1: Directory Organization Suite
│   │       ├── TEST IB-01: Quick cards stored in docs/cards/quick/
│   │       ├── TEST IB-02: Task cards stored in docs/cards/task/
│   │       ├── TEST IB-03: Deep cards stored in docs/cards/deep/
│   │       ├── TEST OOB-01: Card in wrong directory detected
│   │       └── TEST OOB-02: Duplicate card filenames detected
│   │
│   └── FUNCTION #1.3: Card Linking System
│       └── TEST-SUITE #1.3.1: Link Resolution Suite
│           ├── TEST IB-01: Relative markdown links resolve correctly
│           ├── TEST IB-02: Anchor links resolve to valid headings
│           ├── TEST IB-03: Task references resolve via tasks.map.yaml
│           ├── TEST OOB-01: Broken file links detected
│           ├── TEST OOB-02: Broken anchor links detected
│           └── TEST OOB-03: Circular link references detected
│
├── SUB-FEATURE #2: Tasks Map System (AC2)
│   │
│   ├── FUNCTION #2.1: Tasks Map Parser
│   │   └── TEST-SUITE #2.1.1: YAML Parsing Suite
│   │       ├── TEST IB-01: Valid tasks.map.yaml parses successfully
│   │       ├── TEST IB-02: Task attributes extracted correctly
│   │       ├── TEST IB-03: Card sequences preserved in order
│   │       ├── TEST OOB-01: Malformed YAML fails gracefully
│   │       ├── TEST OOB-02: Missing required fields detected
│   │       └── TEST OOB-03: Invalid references flagged
│   │
│   ├── FUNCTION #2.2: Task Selection Engine
│   │   └── TEST-SUITE #2.2.1: Card Resolution Suite
│   │       ├── TEST IB-01: Task ID resolves to card sequence
│   │       ├── TEST IB-02: Card IDs resolve to file paths
│   │       ├── TEST IB-03: Level suffixes select correct variants
│   │       ├── TEST OOB-01: Unknown task ID returns error
│   │       ├── TEST OOB-02: Missing card file detected
│   │       └── TEST OOB-03: Circular task references detected
│   │
│   └── FUNCTION #2.3: Budget Management
│       └── TEST-SUITE #2.3.1: Budget Enforcement Suite
│           ├── TEST IB-01: Selection within budget returns success
│           ├── TEST IB-02: Token calculation accurate
│           ├── TEST IB-03: Subtopic grouping works correctly
│           ├── TEST OOB-01: Budget exceeded generates menu
│           ├── TEST OOB-02: Zero budget handled gracefully
│           └── TEST OOB-03: Negative tokens detected as error
│
├── SUB-FEATURE #3: Issue Mirroring System (AC3)
│   │
│   ├── FUNCTION #3.1: Mirror Label Trigger
│   │   └── TEST-SUITE #3.1.1: Trigger Detection Suite
│   │       ├── TEST IB-01: Issue create event triggers sync
│   │       ├── TEST IB-02: Issue edit event triggers sync
│   │       ├── TEST IB-03: Issue label event triggers sync
│   │       ├── TEST OOB-01: Invalid event type handled
│   │       └── TEST OOB-02: Missing issue number detected
│   │
│   ├── FUNCTION #3.2: Mirror Sync Automation
│   │   └── TEST-SUITE #3.2.1: Sync Logic Suite
│   │       ├── TEST IB-01: Issue metadata synced to front-matter
│   │       ├── TEST IB-02: Issue body rendered as markdown
│   │       ├── TEST IB-03: File naming follows convention
│   │       ├── TEST IB-04: Token estimate calculated
│   │       ├── TEST OOB-01: Malformed issue handled gracefully
│   │       ├── TEST OOB-02: Very large issues (>10k tokens) handled
│   │       └── TEST OOB-03: Sync failures logged and retried
│   │
│   └── FUNCTION #3.3: Mirror Freshness Check
│       └── TEST-SUITE #3.3.1: Freshness Validation Suite
│           ├── TEST IB-01: Fresh mirrors (<24h) pass check
│           ├── TEST IB-02: last_synced_commit recorded correctly
│           ├── TEST OOB-01: Stale mirrors (>24h) flagged
│           └── TEST OOB-02: Missing last_synced_commit detected
│
├── SUB-FEATURE #4: Drift Detection System (AC4)
│   │
│   ├── FUNCTION #4.1: Source Path Monitoring
│   │   └── TEST-SUITE #4.1.1: File Change Detection Suite
│   │       ├── TEST IB-01: Changed files detected in PR
│   │       ├── TEST IB-02: Changed files detected in direct commit
│   │       ├── TEST IB-03: source_paths parsed from cards
│   │       ├── TEST OOB-01: Empty changeset handled
│   │       ├── TEST OOB-02: Binary file changes handled
│   │       └── TEST OOB-03: Deleted files detected
│   │
│   ├── FUNCTION #4.2: Change Impact Analysis
│   │   └── TEST-SUITE #4.2.1: Impact Calculation Suite
│   │       ├── TEST IB-01: Affected cards identified correctly
│   │       ├── TEST IB-02: Related issues found via metadata
│   │       ├── TEST IB-03: Staleness calculated (last_verified_commit age)
│   │       ├── TEST OOB-01: No affected cards returns empty result
│   │       ├── TEST OOB-02: Card without related issue triggers tracking issue
│   │       └── TEST OOB-03: Multiple affected cards aggregated
│   │
│   └── FUNCTION #4.3: Warning Label Application
│       └── TEST-SUITE #4.3.1: Label Management Suite
│           ├── TEST IB-01: Docs: Needed label applied to affected issues
│           ├── TEST IB-02: PR comment posted with impact summary
│           ├── TEST IB-03: Tracking issue created for orphaned drift
│           ├── TEST OOB-01: Label application failure handled gracefully
│           ├── TEST OOB-02: Duplicate labels avoided
│           └── TEST OOB-03: Workflow always exits success (warn-only)
│
├── SUB-FEATURE #5: Validation CLI Tool (AC5)
│   │
│   ├── FUNCTION #5.1: CLI Argument Parser
│   │   └── TEST-SUITE #5.1.1: Argument Parsing Suite
│   │       ├── TEST IB-01: --help displays usage
│   │       ├── TEST IB-02: --format=json produces JSON output
│   │       ├── TEST IB-03: --checks filters validation types
│   │       ├── TEST IB-04: --card validates single card
│   │       ├── TEST OOB-01: Invalid arguments show error
│   │       ├── TEST OOB-02: Conflicting options detected
│   │       └── TEST OOB-03: Missing required path handled
│   │
│   ├── FUNCTION #5.2: Validation Runner
│   │   └── TEST-SUITE #5.2.1: Validation Execution Suite
│   │       ├── TEST IB-01: All 8 checks execute successfully
│   │       ├── TEST IB-02: Schema validation uses ajv correctly
│   │       ├── TEST IB-03: Token estimate recalculated accurately
│   │       ├── TEST IB-04: Links resolved and verified
│   │       ├── TEST IB-05: Near-duplicates detected with threshold
│   │       ├── TEST OOB-01: Missing card files handled
│   │       ├── TEST OOB-02: Corrupted card front-matter handled
│   │       └── TEST OOB-03: Validation completes in <30s
│   │
│   └── FUNCTION #5.3: Report Generator
│       └── TEST-SUITE #5.3.1: Report Formatting Suite
│           ├── TEST IB-01: Console output color-coded correctly
│           ├── TEST IB-02: File:line references included
│           ├── TEST IB-03: Summary statistics accurate
│           ├── TEST IB-04: JSON output valid and complete
│           ├── TEST OOB-01: No findings produces clean output
│           └── TEST OOB-02: Exit code always 0 (warn-only)
│
└── SUB-FEATURE #6: Helper Automations (AC6)
    │
    ├── FUNCTION #6.1: Card Bundle Generator
    │   └── TEST-SUITE #6.1.1: Bundle Generation Suite
    │       ├── TEST IB-01: Bundle created from task selection
    │       ├── TEST IB-02: Card order preserved from tasks map
    │       ├── TEST IB-03: Bundle metadata complete and accurate
    │       ├── TEST IB-04: Checksum calculated correctly
    │       ├── TEST OOB-01: Missing card in sequence handled
    │       ├── TEST OOB-02: Bundle generation timeout handled
    │       └── TEST OOB-03: Bundle exceeds budget flagged
    │
    ├── FUNCTION #6.2: Near-Duplicate Detector
    │   └── TEST-SUITE #6.2.1: Similarity Detection Suite
    │       ├── TEST IB-01: Identical cards detected (100% similar)
    │       ├── TEST IB-02: Similar cards detected (>80% threshold)
    │       ├── TEST IB-03: Dissimilar cards ignored (<80%)
    │       ├── TEST OOB-01: Very large cards handled efficiently
    │       ├── TEST OOB-02: Empty cards handled
    │       └── TEST OOB-03: Similarity calculation performant
    │
    └── FUNCTION #6.3: Token Budget Menu
        └── TEST-SUITE #6.3.1: Menu Generation Suite
            ├── TEST IB-01: Subtopics grouped correctly
            ├── TEST IB-02: Token counts per subtopic accurate
            ├── TEST IB-03: Menu options clear and actionable
            ├── TEST OOB-01: No subtopics available handled
            ├── TEST OOB-02: All subtopics required (cannot exclude) handled
            └── TEST OOB-03: Budget exactly met (no overrun) handled
```

---

## Label Application by Level

### Level 1: Feature (Parent)

- **Required:** `Type: Feature`, `Workflow: Backlog`
- **Forbidden:** All others (Difficulty, AI, Role, Validation, etc.)

### Level 2: Sub-Feature

- **Required:** `Role: Sub-Feature`, `Type: Feature` (inherited), `Workflow: Backlog`
- **Forbidden:** Difficulty, AI, Validation, Test-Type, etc.

### Level 3: Function

- **Required:** `Type: Function`, `Type: Feature` (inherited), `Workflow: Backlog`, `Difficulty: [TBD]`, `AI: [TBD]`
- **Auto-applied:** `Needs-Human` (if AI is Supervised/Human+AI/Human-Only)
- **Forbidden:** Role, Validation, Test-Type, etc.

### Level 4: Test-Suite

- **Required:** `Role: Test-Suite`, `Type: Feature` (inherited), `Workflow: Backlog`
- **Forbidden:** Type: Test, Difficulty, AI, Validation, Test-Type, etc.

### Level 5: Test (Leaf)

- **Required:** `Type: Test`, `Type: Feature` (inherited), `Workflow: Backlog`, `Validation: Pending`, `Difficulty: [TBD]`, `AI: [TBD]`, `Env: Synthetic`, `Test-Type: [TBD]`, `Technique: [TBD]`
- **Auto-applied:** `Needs-Human` (if AI is Supervised/Human+AI/Human-Only)
- **Optional:** Security, Artifact, Resource labels

---

## Next Steps

1. **Review Issue Files:** Review all 7 markdown files for accuracy and completeness
2. **Create GitHub Issues:** Use `gh issue create` or manual creation following templates
3. **Link Hierarchy:** Update parent issues with child issue numbers after creation
4. **Prioritize Functions:** Assign Difficulty and AI labels to Function-level issues
5. **Begin Test Suite Planning:** For each Function, create Test-Suite issues following IB/OOB format

---

## Estimated Timeline

**Total Effort:** L (2-4 weeks)

**By Sub-Feature:**

- AC1 (Doc Card Infrastructure): M (1 week)
- AC2 (Tasks Map System): S (1-3 days)
- AC3 (Issue Mirroring): S (1-3 days)
- AC4 (Drift Detection): M (1 week)
- AC5 (Validation CLI): M (1 week)
- AC6 (Helper Automations): S (1-3 days)

**Critical Path:**
AC1 → AC2 → AC5 (sequential dependencies)
AC3, AC4, AC6 can progress in parallel once AC1 is complete

---

## Success Criteria

- [ ] All 73 labels updated in GitHub (including 8 new Docs: labels)
- [ ] LABEL_DESIGN_SPEC.md updated to v1.6
- [ ] Parent Feature issue created
- [ ] All 6 Sub-Feature issues created and linked
- [ ] 18 Function issues created (3 per Sub-Feature)
- [ ] 18 Test-Suite issues created (1 per Function)
- [ ] ~100 Test issues created (IB/OOB format)

---

**Maintained by:** Jackson-Devices
**Last Updated:** 2025-11-11
