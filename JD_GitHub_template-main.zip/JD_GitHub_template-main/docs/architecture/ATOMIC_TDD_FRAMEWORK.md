### 1.4 Ready / Done Gates

- **Feature READY:** AC defined, SF children created.
- **Sub-Feature READY:** contracts + ≥ 1 IB + ≥ 2 OOB cases defined.
- **Function READY:** pre / post / invariants listed; no missing TS links.
- **DONE:** all lower-level issues closed; CI passing; metrics green.

### 1.5 Compounding Engineering Requirements

Each merged PR must:

1. Add or improve at least one reusable generator, fixture, or invariant.
2. Update the central **Capability Ledger** (`capability_ledger.md`) mapping AC → SF → FN → TS coverage.
3. Use deterministic seeds, standard error taxonomy, and shared logging macros.
4. Maintain contract compatibility unless flagged `status:breaking`.

---

## 2. DETAILED DESCRIPTION

### Purpose

This framework defines a structured, traceable method for designing, building, and validating every feature of a system.  
By enforcing atomic planning and test-first design, it guarantees that each piece of work can be individually proven correct and reused.  
The result is faster development, higher reliability, and effortless auditability.

### Why It Matters

1. **Reliability:** Tests come before code, ensuring every behaviour is intentional and verified.
2. **Traceability:** Every outcome can be linked from user goal to single line of code.
3. **Reusability:** Shared tests and fixtures become the foundation for future work.
4. **AI-Friendly:** Small, clearly specified units prevent model hallucination and allow parallel automation.
5. **Governance:** Labels and gates make quality control automatic and objective.

### How It Works

Each **Feature** defines a user outcome.  
It splits into **Sub-Features**, each tied to one acceptance criterion.  
Sub-Features are realised through **Function Contracts** that describe exact inputs, outputs, and rules.  
Before any implementation begins, **Test-Suites** and **Test-Cases** declare what must be true for success or failure.  
Developers or AI assistants then write only the minimal code required for those tests to pass.  
Success rolls upward: when tests for a Function pass, its Sub-Feature completes; when all Sub-Features complete, the Feature closes.

---

### Extra Engineering Layers — Detailed Explanations

#### RFC (“Request for Comments”)

An RFC is a lightweight proposal document created before significant technical or design work.  
It records the problem, possible solutions, the chosen approach, and any rejected alternatives.  
Writing an RFC clarifies reasoning, enables discussion, and prevents repeating old debates later.

#### ADR (Architecture Decision Record)

An ADR captures each irreversible or high-impact architectural choice: the context, the decision, and its consequences.  
It becomes the permanent memory of why the system looks the way it does.  
Future contributors can read ADRs to understand trade-offs instead of re-learning them through mistakes.

#### Spike

A spike is a short, time-boxed experiment used to explore uncertainty—such as testing a new library, protocol, or toolchain.  
It intentionally produces learning, not production code.  
By isolating risk early, spikes stop unexpected complexity from derailing main development.

#### Property-Based Testing (PBT)

PBT automatically generates many random inputs to verify that certain properties always hold (e.g., “output length = input length + 1”).  
Instead of checking single examples, it mathematically validates general behaviour.  
This finds edge cases that human-written examples would miss and ensures logical soundness.

#### Mutation Testing

Mutation testing deliberately alters (“mutates”) existing code—flipping operators or constants—to confirm that tests fail when behaviour changes.  
If a mutant survives, the test suite is too weak.  
Running this occasionally exposes false confidence and strengthens overall coverage.

#### Contract Testing

Contract testing ensures that two interacting modules or services agree on how they communicate.  
Each side has a “contract” describing expected inputs and outputs.  
If one side changes, tests fail before integration breaks.  
This preserves compatibility across teams and systems.

#### Observability Specification

An observability spec defines what metrics, logs, and traces each component must emit.  
Tests confirm these signals exist and are meaningful.  
It guarantees that once deployed, behaviour can be measured and diagnosed quickly without guessing.

#### Threat Model Lite

A threat model identifies ways a feature could be misused or fail under hostile conditions—input abuse, resource exhaustion, or data leakage.  
Running a lightweight threat review per Sub-Feature creates awareness and prompts security test cases early rather than after incidents.

#### Determinism Kit

A determinism kit standardises seeds, clocks, and environments so tests produce the same results every run.  
By fixing random numbers and timestamps, it removes flaky tests and allows AI or CI systems to reason about outcomes with full reproducibility.

#### Error Taxonomy

An error taxonomy is a unified list of error types with consistent codes and meanings.  
Tests reference these codes directly, so when failures occur they are predictable, searchable, and easy to handle in automation or UI layers.

#### Observability in Testing

Beyond simple logs, observability tests assert that metrics increase or events emit exactly once under known conditions.  
This couples quality control with runtime insight: if telemetry passes tests, production debugging becomes simpler.

---

### Compounding Benefits

The framework’s “compounding” rule means every completed task must leave behind something reusable—new generators, fixtures, metrics, or documentation.  
Each improvement reduces friction for the next engineer or AI agent.  
Over time, the project becomes faster, safer, and more self-validating.  
Quality increases not by adding more rules but because every rule now reinforces all others.

### Outcome

After adoption:

- All work becomes measurable and traceable.
- Errors surface early through automated tests.
- New contributors, human or AI, onboard rapidly.
- Continuous improvement happens naturally: the system grows stronger with every change.

### Recommended First Steps

1. Add these templates and labels to `.github/ISSUE_TEMPLATE/`.
2. Create `capability_ledger.md` mapping AC → SF → FN → TS.
3. Pilot on one small feature.
4. Measure outcomes: mean tests per FN, reuse ratio, average review time.
5. Refine gates and templates until enforcement is smooth and automatic.

---

_End of Document_

# Atomic Test-Driven Development Framework (TDD-ATF)

_(Sections 1–2 unchanged up to “Extra Engineering Layers.”)_

---

## Refactoring Protocol (No Behavioural Change)

### Purpose

A refactor changes how the system achieves its results without altering what those results are.  
Its goal is to improve clarity, efficiency, maintainability, or compatibility while leaving user-visible behaviour and all acceptance criteria untouched.  
Refactors verify that the existing tests describe the system’s behaviour completely and accurately; when those tests continue to pass after structural changes, the refactor is proven safe.

### Readiness

Before any refactor begins, the existing test suites must be fully trusted.  
All current tests must pass, and coverage must be adequate to capture every intended behaviour.  
If gaps exist, new tests are added **before** any production code is changed.  
New tests are always run against the original implementation first to confirm that they reflect current behaviour, not future expectations.  
Tests should be independent of specific library or framework versions wherever possible so that they remain stable as dependencies evolve.

### Scope

Refactors never create new features or sub-features.  
They belong to the same function contracts that already exist.  
No acceptance criteria, user outcomes, or public interfaces change.  
If the change alters behaviour, it ceases to be a refactor and must be re-classified as a feature, bug fix, or breaking revision.

### Workflow

1. **Establish a clean baseline.**  
   Ensure all suites pass, dependencies are fixed, and the environment is recorded so results are reproducible.

2. **Strengthen the tests if needed.**  
   Add any missing in-bounds, out-of-bounds, or property-based checks.  
   Run these against the old implementation to verify they express current behaviour correctly.

3. **Perform the internal change.**  
   Modify structure, algorithms, or style without touching external contracts.  
   Avoid introducing new dependencies unless they are already covered by existing tests.

4. **Validate equivalence.**  
   Rerun all tests.  
   Identical pass results confirm that behaviour has not changed.  
   Where performance or efficiency motivated the change, compare quantitative metrics using the same datasets and environment.

5. **Record measurable improvement.**  
   A refactor must contribute something that compounds future work—simpler architecture, reduced duplication, shared utilities, or improved performance.  
   Even though behaviour is unchanged, the system should now be easier to extend or maintain.

### Interaction with the Compounding Rule

Each refactor contributes to long-term momentum:

- **Simplified code** reduces future cognitive load.
- **Shared abstractions** remove duplication.
- **Updated dependencies** prevent later breakage.
- **Improved performance** provides headroom for new features.
- **Enhanced clarity** helps humans and AI reason about intent.

No refactor is complete unless it leaves at least one reusable improvement behind.

### Refactors in External or Forked Projects

When working on code that lacks this project’s structure or tests, begin by creating **characterization tests** that capture what the existing system currently does.  
Run these on the unmodified version first to establish the baseline.  
Only then perform internal improvements.  
If the original project has no issue tracking or uses different conventions, create a mirror issue that references the original source and describes the mapping.  
If uncertainty remains about intended behaviour, the AI or automation must stop and request clarification before proceeding.  
Behavioural assumptions may never be guessed.

### When Tests Fail

If any test that previously passed now fails, the change is no longer a refactor.  
It indicates either a hidden defect in the old code (a legitimate bug fix) or an unintended behavioural modification.  
In that case the work should be paused and re-classified before continuing.

### Outcomes

A correctly executed refactor demonstrates that:

- The test suite fully captures behaviour.
- Implementation details can evolve safely.
- The system gains maintainability, performance, or clarity.
- Future work starts from a cleaner foundation.

Refactoring therefore acts as both a validation of the testing discipline and a mechanism for continuous structural improvement without functional risk.

---

_(The remainder of the TDD-ATF document continues unchanged.)_

And a few extra things I havent fleshed out - versioning. If this is a template that I might be updating then I should probably use versioning which would allow both pinning and updating as and when.
Must do full security check of any claude code cli additions but especially hooks before deployment.If a flaw is found can it be fixed or must it insteaad be ringfenced as its flaw is a key part of its function that cannot be removed.
Plan git worktreees for task splitting, allowing parallel work provided each chunk of work is well defined,which with this spec it surelu will be.
LABELS!This whole template stemmed from plannning out labels-it amazes me how far down the garden path I can take something!I DO want to keep my current labels.I am willing to add to a category occasionally.Even willing to add categories where it makes sense.But all labels must make sense to me.No label changes to be made without explicit agreement from me first
Minor change,colour not unique in type so please change`type: improvement`to the previously used tan
Of course we also need to discuss the hierachy of remaining work types too.Bug,improvement and docs are all work hierachy I havent defined yet(help me,discuss)and I think you have expanded the plans for this too!To be clear we are defining the structure now but making the templates for bug fix and for improvement and for blah blah dont matter right now,those templates can come later they are just in the todo,way down the line!.
So the way to fix your latest github problem is to still not use labels for these yet as we havent fully defined them yet - fair enough? and whatever issue you do create top of that list is to fully define the labels so in the near future we can do as planned.

---

## LABEL AND HIERARCHY DEFINITIONS (Confirmed 2025-11-09, Implemented 2025-11-10)

### ✅ Label Changes COMPLETED (2025-11-10)

**New Labels Created:**

- ✅ `type: function` - Brown #292524
  - Used for function contract level in hierarchy
  - Defines inputs, outputs, invariants
- ✅ `type: tooling` - Gray #6b7280
  - Used for internal tools and infrastructure work
  - Distinguishes testing infrastructure from actual test cases
  - Does not trigger test validation workflows

**Color Change Applied:**

- ✅ `type: improvement` - Changed from Blue (#3b82f6) to Tan (#78716c)
  - Ensures color uniqueness within type category
  - Note: Tan is already used for `test-type: complex` but that's in different category

**Role Labels (No Changes):**

- Kept existing: `role: test suite`, `role: sub-feature`
- No new role labels needed

### Complete Issue Hierarchy (Applies to ALL Work Types)

All work types (feature, bug, improvement, refactor, docs, test) follow this structure:

```
type: [work-type] ← PARENT ONLY (children do NOT inherit work type label)
  └─ role: sub-feature ← One per Acceptance Criterion (AC)
      └─ type: function ← Contract definition (inputs, outputs, invariants)
          └─ role: test suite ← Groups related tests
              └─ type: test ← Individual test cases (IB-01, OOB-01 format)
```

### Work Type Definitions & Hierarchy Behavior

**`type: feature`** - New functionality

- Full hierarchy: Feature → Sub-Features → Functions → Test-Suites → Test-Cases
- Each sub-feature addresses one acceptance criterion
- Example: "Add user authentication system"

**`type: bug`** - Broken behavior (something isn't working)

- Full hierarchy: Bug → Sub-Features → Functions → Test-Suites → Test-Cases
- Bug describes **observed broken behavior**, not necessarily known root cause
- Investigation identifies which sub-features/functions need fixing
- Example: "Login fails with special characters in password"
  - Sub-feature: "Password input validation" (scope of fix)
  - Function: validatePassword (specific function once identified)
  - Test-suite: Regression tests
  - Test-cases: IB/OOB proving bug + fix

**`type: improvement`** - Incremental change to existing feature (user-visible)

- Full hierarchy: Improvement → Sub-Features → Functions → Test-Suites → Test-Cases
- Enhancement that's not substantial enough to be a new feature
- Examples:
  - "Support 5 concurrent clients instead of 3"
  - "Add new provider to existing integration"
- User experiences a change, but core feature already existed

**`type: refactor`** - Internal change only (zero user-facing difference)

- Full hierarchy: Refactor → Sub-Features → Functions → Test-Suites → Test-Cases
- **Brand new issue tree** - can copy desired behaviors/tests from existing issues but creates fresh hierarchy
- No new features, no behavior changes from user perspective
- Examples:
  - "Restructure authentication module for better maintainability"
  - "Replace deprecated library with modern equivalent"
- User sees/experiences absolutely nothing different

**`type: docs`** - Documentation updates

- Full hierarchy: Docs → Sub-Features → Functions → Test-Suites → Test-Cases
- (Hierarchy behavior to be further defined based on documentation needs)

**`type: test`** - Individual test cases (IB/OOB format)

- Full hierarchy: Test → (parent test suite via role: test suite)
- Triggers validation workflows expecting IB-01, OOB-01 format with 9 required sections
- Used ONLY for actual test case issues, not testing infrastructure
- Examples: "Test user login with valid credentials (IB-01)", "Test login with empty password (OOB-03)"

**`type: tooling`** - Internal tools and infrastructure work

- Full hierarchy: Tooling → Sub-Features → Functions → Test-Suites → Test-Cases
- Used for building/improving internal systems: testing infrastructure, workflow automation, CI/CD pipelines, development tools
- Does NOT trigger test validation workflows
- Examples: "Build synthetic testing infrastructure for GitHub Actions", "Create pre-commit formatting hooks", "Implement decision logging system"
- This is what issue #26 should use instead of `type: test`

### Critical Rules

1. **Work type labels ONLY on parent** - Children never inherit the work type
2. **Role labels for grouping** - `role: sub-feature` and `role: test suite` provide hierarchy structure
3. **Function level uses type** - Functions get `type: function`, not a role label
4. **Test cases use type** - Individual tests get `type: test`, not a role label
5. **Full depth required** - All work types follow complete 5-level hierarchy

### Ready/Done Gates (from section 1.4)

- **Feature READY:** AC defined, Sub-Feature children created
- **Sub-Feature READY:** contracts + ≥ 1 IB + ≥ 2 OOB cases defined
- **Function READY:** pre/post/invariants listed; no missing TS links
- **DONE:** all lower-level issues closed; CI passing; metrics green

### ✅ Implementation Status (Completed 2025-11-10)

1. ✅ **Updated LABEL_DESIGN_SPEC.md** (v1.3):
   - Added `type: function` label (Brown #292524)
   - Added `type: tooling` label (Gray #6b7280)
   - Changed `type: improvement` color (Blue → Tan #78716c)
   - Updated work type definitions clarifying test vs tooling
   - Documented atomic hierarchy rules
   - Commit: 811616a

2. ✅ **Created labels in GitHub** (via settings.yml and apply_settings workflow):
   - Updated `.github/settings.yml` with new labels
   - Ran label sync workflow in apply mode
   - Verified labels exist in repository (36 total labels now)

3. ⏸️ **Create issue templates** for each hierarchy level (NEXT: P0.2):
   - Feature template
   - Sub-Feature template
   - Function template
   - Test-Suite template

4. ✅ **Fixed issue #26** with correct labels:
   - Removed: `type: test`
   - Added: `type: tooling`
   - Kept: `type: feature`, `difficulty: complex`, `ai: human+ai`, `needs-human`, `workflow: backlog`
   - Issue #26 no longer triggers IB/OOB validation workflows

5. ⏸️ **Templates for bug/improvement/refactor/tooling** (way down the line - P3 or later)

---
