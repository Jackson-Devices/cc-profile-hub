# Orchestrator V3: Docker/LLM/API Architecture

**Generated:** 2025-11-14
**Purpose:** Architectural design for Docker containerization, LLM integration, and API layer for the GitHub Workflow Orchestrator
**Status:** Planning / Design Phase
**Version:** 3.0.0

---

## Executive Summary

This document outlines the V3 architecture for the GitHub Workflow Orchestrator, expanding from a GitHub Actions-native system to a full-featured API-driven platform with:

1. **Docker Containerization** - All language modules (Python, CSS, XML, etc.) run in isolated containers
2. **LLM Integration Layer** - Claude/OpenAI API integration for intelligent decision-making
3. **REST API Layer** - Programmatic access to orchestrator functionality
4. **TDD-First Methodology** - Comprehensive test coverage for all new components

**Key Benefits:**
- **Portability:** Run orchestrator locally via Docker without GitHub Actions dependency
- **Intelligence:** LLM-powered code analysis, fix suggestions, and decision-making
- **Extensibility:** API allows integration with external tools and workflows
- **Testability:** Isolated containers enable robust testing without system dependencies

---

## Table of Contents

1. [Architecture Overview](#architecture-overview)
2. [Docker Containerization](#docker-containerization)
3. [API Layer Design](#api-layer-design)
4. [LLM Integration](#llm-integration)
5. [TDD Strategy](#tdd-strategy)
6. [Implementation Phases](#implementation-phases)
7. [Security Considerations](#security-considerations)
8. [Performance & Scaling](#performance--scaling)

---

## Architecture Overview

### Current State (V2)

```
GitHub Actions Workflows
    ↓
Orchestrator Core (.github/scripts/orchestrator/)
    ↓
Language Modules (Python, CSS, XML, etc.)
    ↓
System-Installed Tools (pylint, stylelint, etc.)
```

**Limitations:**
- Requires GitHub Actions environment
- System-level tool dependencies
- No programmatic API access
- Limited local testing capabilities
- No AI-powered intelligence

### Target State (V3)

```
┌─────────────────────────────────────────────────────────────┐
│                      API Gateway                             │
│  (REST/GraphQL - Express.js + OpenAPI)                      │
└─────────────────────────────────────────────────────────────┘
                            ↓
┌─────────────────────────────────────────────────────────────┐
│                 Orchestrator Core API                        │
│  (Business Logic, Routing, Authentication)                  │
└─────────────────────────────────────────────────────────────┘
         ↓                    ↓                    ↓
┌──────────────────┐  ┌──────────────────┐  ┌──────────────────┐
│  Language Module │  │  LLM Integration │  │  Decision Logger │
│   Containers     │  │     Layer        │  │    (JSONL)       │
└──────────────────┘  └──────────────────┘  └──────────────────┘
         ↓                    ↓
┌──────────────────┐  ┌──────────────────┐
│  Docker Network  │  │  Claude/OpenAI   │
│  (python-module) │  │      APIs        │
│  (css-module)    │  │                  │
│  (xml-module)    │  │                  │
│  (mermaid-module)│  │                  │
└──────────────────┘  └──────────────────┘
```

**Enhancements:**
- ✅ Docker containers for all language modules
- ✅ REST API for programmatic access
- ✅ LLM integration for intelligent analysis
- ✅ Local development without GitHub Actions
- ✅ Comprehensive API documentation (OpenAPI/Swagger)
- ✅ Authentication and authorization
- ✅ Rate limiting and caching

---

## Docker Containerization

### Module Container Strategy

Each language module gets a dedicated Dockerfile with all required tools pre-installed:

#### 1. Python Module Container

**Dockerfile:** `docker/python-module.Dockerfile`

```dockerfile
FROM python:3.11-slim

# Install Python linting and formatting tools
RUN pip install --no-cache-dir \
    pylint==3.0.0 \
    flake8==6.1.0 \
    black==23.12.0 \
    isort==5.13.0 \
    mypy==1.7.0 \
    bandit==1.7.5

# Install Node.js for orchestrator communication
RUN curl -fsSL https://deb.nodesource.com/setup_20.x | bash - && \
    apt-get install -y nodejs

# Copy module code
WORKDIR /app
COPY .github/scripts/orchestrator/modules/python-module.mjs ./
COPY .github/scripts/orchestrator/base-module.mjs ./

# Health check
HEALTHCHECK --interval=30s --timeout=3s \
  CMD node -e "require('./python-module.mjs')" || exit 1

# Expose API port
EXPOSE 3000

CMD ["node", "python-module.mjs", "--server"]
```

**Image Size Target:** <500MB
**Build Time Target:** <2 minutes
**Startup Time Target:** <5 seconds

#### 2. CSS Module Container

**Dockerfile:** `docker/css-module.Dockerfile`

```dockerfile
FROM node:20-slim

# Install CSS tools
RUN npm install -g \
    stylelint@16.0.0 \
    stylelint-config-standard@35.0.0 \
    prettier@3.1.0

# Copy module code
WORKDIR /app
COPY .github/scripts/orchestrator/modules/css-module.mjs ./
COPY .github/scripts/orchestrator/base-module.mjs ./

EXPOSE 3000
CMD ["node", "css-module.mjs", "--server"]
```

#### 3. XML Module Container

**Dockerfile:** `docker/xml-module.Dockerfile`

```dockerfile
FROM node:20-slim

# Install XML validation tools
WORKDIR /app
RUN npm install @xmldom/xmldom@0.8.11

# Copy module code
COPY .github/scripts/orchestrator/modules/xml-module.mjs ./
COPY .github/scripts/orchestrator/base-module.mjs ./

EXPOSE 3000
CMD ["node", "xml-module.mjs", "--server"]
```

### Docker Compose Configuration

**File:** `docker-compose.yml`

```yaml
version: '3.8'

services:
  orchestrator-api:
    build:
      context: .
      dockerfile: docker/orchestrator-api.Dockerfile
    ports:
      - '8080:8080'
    environment:
      - NODE_ENV=production
      - ANTHROPIC_API_KEY=${ANTHROPIC_API_KEY}
      - OPENAI_API_KEY=${OPENAI_API_KEY}
      - LOG_LEVEL=info
    volumes:
      - ./decision_logs:/app/logs
      - ./test-files:/app/test-files:ro
    depends_on:
      - python-module
      - css-module
      - xml-module
      - mermaid-module
    networks:
      - orchestrator-network

  python-module:
    build:
      context: .
      dockerfile: docker/python-module.Dockerfile
    expose:
      - '3000'
    networks:
      - orchestrator-network
    healthcheck:
      test: ['CMD', 'curl', '-f', 'http://localhost:3000/health']
      interval: 30s
      timeout: 10s
      retries: 3

  css-module:
    build:
      context: .
      dockerfile: docker/css-module.Dockerfile
    expose:
      - '3000'
    networks:
      - orchestrator-network

  xml-module:
    build:
      context: .
      dockerfile: docker/xml-module.Dockerfile
    expose:
      - '3000'
    networks:
      - orchestrator-network

  mermaid-module:
    build:
      context: .
      dockerfile: docker/mermaid-module.Dockerfile
    expose:
      - '3000'
    networks:
      - orchestrator-network

networks:
  orchestrator-network:
    driver: bridge

volumes:
  decision_logs:
```

### Container Communication Protocol

**Inter-container communication uses HTTP/JSON:**

```javascript
// Request format
POST http://python-module:3000/check
Content-Type: application/json

{
  "files": ["/app/test-files/example.py"],
  "options": {
    "enableLinting": true,
    "linters": ["pylint", "flake8"]
  }
}

// Response format
{
  "success": true,
  "results": [
    {
      "file": "/app/test-files/example.py",
      "issues": [
        {
          "line": 10,
          "column": 5,
          "message": "Undefined variable 'foo'",
          "severity": "error",
          "rule": "undefined-variable"
        }
      ]
    }
  ],
  "metadata": {
    "duration_ms": 245,
    "tools_used": ["pylint", "flake8"]
  }
}
```

---

## API Layer Design

### Technology Stack

- **Framework:** Express.js (Node.js 20+)
- **API Spec:** OpenAPI 3.1
- **Validation:** Ajv JSON Schema
- **Authentication:** JWT (JSON Web Tokens)
- **Rate Limiting:** express-rate-limit
- **Documentation:** Swagger UI
- **Monitoring:** Prometheus metrics

### API Endpoints

#### 1. Validation Endpoints

**POST /api/v1/validate**

Validate files with orchestrator:

```json
{
  "files": [
    {
      "path": "src/example.py",
      "content": "def hello():\n    print('world')\n"
    }
  ],
  "options": {
    "modules": ["python"],
    "enableAutoFix": false
  }
}
```

Response:

```json
{
  "validation_id": "550e8400-e29b-41d4-a716-446655440000",
  "status": "completed",
  "results": {
    "python": {
      "issues": [],
      "auto_fixes_applied": 0
    }
  },
  "summary": {
    "total_issues": 0,
    "errors": 0,
    "warnings": 0,
    "info": 0
  },
  "duration_ms": 312
}
```

**GET /api/v1/validate/:validation_id**

Get validation results by ID.

#### 2. LLM Analysis Endpoints

**POST /api/v1/analyze/code**

LLM-powered code analysis:

```json
{
  "code": "def foo(x):\n    return x + y\n",
  "language": "python",
  "context": {
    "file_path": "src/utils.py",
    "related_files": ["src/main.py"]
  },
  "analysis_type": "error_explanation"
}
```

Response:

```json
{
  "analysis_id": "660e8400-e29b-41d4-a716-446655440000",
  "llm_provider": "claude",
  "model": "claude-sonnet-4.5",
  "analysis": {
    "issues_found": [
      {
        "line": 2,
        "description": "Variable 'y' is undefined. It should be passed as a parameter or defined before use.",
        "severity": "error",
        "suggested_fix": "def foo(x, y):\n    return x + y\n"
      }
    ],
    "suggestions": [
      "Add 'y' as a parameter to the function",
      "Define 'y' as a module-level constant if it's meant to be global"
    ]
  },
  "confidence": 0.95,
  "tokens_used": {
    "input": 45,
    "output": 89
  }
}
```

**POST /api/v1/analyze/fix-suggestion**

Get LLM-generated fix for validation issues:

```json
{
  "file_path": "src/example.py",
  "issues": [
    {
      "line": 10,
      "message": "Undefined variable 'foo'",
      "rule": "undefined-variable"
    }
  ],
  "code_context": "..."
}
```

#### 3. Decision Logging Endpoints

**POST /api/v1/decisions**

Log a decision:

```json
{
  "type": "validation",
  "context": {
    "file": "src/example.py",
    "module": "python"
  },
  "action": "fix_applied",
  "outcome": "success",
  "metrics": {
    "issues_before": 5,
    "issues_after": 0
  }
}
```

**GET /api/v1/decisions**

Query decisions with filters:

```
GET /api/v1/decisions?type=validation&sessionId=abc123&level=info&startDate=2025-11-01
```

#### 4. Module Management Endpoints

**GET /api/v1/modules**

List all available modules:

```json
{
  "modules": [
    {
      "name": "python",
      "version": "1.0.0",
      "status": "healthy",
      "capabilities": ["check", "fix", "syntax", "lint", "format", "typecheck"],
      "container_id": "python-module-abc123",
      "last_health_check": "2025-11-14T10:30:00Z"
    }
  ]
}
```

**GET /api/v1/modules/:module/health**

Check module health status.

**POST /api/v1/modules/:module/restart**

Restart a module container (admin only).

#### 5. Authentication & Authorization

**POST /api/v1/auth/login**

Authenticate and get JWT:

```json
{
  "username": "admin",
  "password": "****"
}
```

Response:

```json
{
  "token": "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9...",
  "expires_in": 3600,
  "user": {
    "username": "admin",
    "roles": ["admin", "user"]
  }
}
```

**Roles:**
- `user`: Can validate files, query decisions
- `admin`: Can restart modules, view all decisions, access metrics
- `llm`: Can access LLM endpoints (requires API key + role)

### OpenAPI Specification

**File:** `docs/api/openapi.yaml`

```yaml
openapi: 3.1.0
info:
  title: GitHub Workflow Orchestrator API
  version: 3.0.0
  description: |
    REST API for the GitHub Workflow Orchestrator with Docker containerization,
    LLM integration, and comprehensive validation capabilities.
  contact:
    name: Jackson Devices
    url: https://github.com/Jackson-Devices/JD_GitHub_template

servers:
  - url: http://localhost:8080/api/v1
    description: Local development
  - url: https://orchestrator.example.com/api/v1
    description: Production

paths:
  /validate:
    post:
      summary: Validate files
      operationId: validateFiles
      security:
        - bearerAuth: []
      requestBody:
        required: true
        content:
          application/json:
            schema:
              $ref: '#/components/schemas/ValidationRequest'
      responses:
        '200':
          description: Validation completed
          content:
            application/json:
              schema:
                $ref: '#/components/schemas/ValidationResponse'
        '401':
          $ref: '#/components/responses/Unauthorized'
        '429':
          $ref: '#/components/responses/RateLimitExceeded'

components:
  securitySchemes:
    bearerAuth:
      type: http
      scheme: bearer
      bearerFormat: JWT

  schemas:
    ValidationRequest:
      type: object
      required:
        - files
      properties:
        files:
          type: array
          items:
            $ref: '#/components/schemas/FileInput'
        options:
          $ref: '#/components/schemas/ValidationOptions'

    FileInput:
      type: object
      required:
        - path
        - content
      properties:
        path:
          type: string
          example: 'src/example.py'
        content:
          type: string
          example: 'def hello():\n    print(\"world\")\n'

    ValidationOptions:
      type: object
      properties:
        modules:
          type: array
          items:
            type: string
            enum: [python, css, xml, mermaid, obsidian, n8n]
        enableAutoFix:
          type: boolean
          default: false

    ValidationResponse:
      type: object
      properties:
        validation_id:
          type: string
          format: uuid
        status:
          type: string
          enum: [completed, failed, partial]
        results:
          type: object
          additionalProperties:
            $ref: '#/components/schemas/ModuleResult'
        summary:
          $ref: '#/components/schemas/ValidationSummary'
        duration_ms:
          type: integer

  responses:
    Unauthorized:
      description: Unauthorized - Invalid or missing JWT
    RateLimitExceeded:
      description: Rate limit exceeded - Too many requests
```

---

## LLM Integration

### Supported Providers

1. **Anthropic Claude** (Primary)
   - Model: `claude-sonnet-4.5`
   - Use cases: Code analysis, fix suggestions, error explanations
   - Cost: ~$3 per million input tokens, ~$15 per million output tokens

2. **OpenAI** (Secondary)
   - Model: `gpt-4-turbo`
   - Use cases: Alternative for Claude unavailability
   - Cost: ~$10 per million input tokens, ~$30 per million output tokens

### LLM Integration Layer

**File:** `.github/scripts/orchestrator/llm-integration.mjs`

```javascript
import Anthropic from '@anthropic-ai/sdk';
import OpenAI from 'openai';

export class LLMIntegration {
  constructor(config) {
    this.provider = config.provider || 'claude'; // claude | openai
    this.model = config.model || 'claude-sonnet-4.5';

    if (this.provider === 'claude') {
      this.client = new Anthropic({
        apiKey: process.env.ANTHROPIC_API_KEY
      });
    } else {
      this.client = new OpenAI({
        apiKey: process.env.OPENAI_API_KEY
      });
    }
  }

  async analyzeCode(code, language, context, analysisType) {
    const prompt = this.buildPrompt(code, language, context, analysisType);

    if (this.provider === 'claude') {
      const response = await this.client.messages.create({
        model: this.model,
        max_tokens: 2048,
        messages: [{ role: 'user', content: prompt }]
      });

      return {
        analysis: this.parseAnalysis(response.content[0].text),
        tokens_used: {
          input: response.usage.input_tokens,
          output: response.usage.output_tokens
        },
        model: this.model
      };
    } else {
      const response = await this.client.chat.completions.create({
        model: this.model,
        messages: [{ role: 'user', content: prompt }],
        max_tokens: 2048
      });

      return {
        analysis: this.parseAnalysis(response.choices[0].message.content),
        tokens_used: {
          input: response.usage.prompt_tokens,
          output: response.usage.completion_tokens
        },
        model: this.model
      };
    }
  }

  buildPrompt(code, language, context, analysisType) {
    const prompts = {
      error_explanation: `
You are a code analysis expert. Analyze the following ${language} code and explain any errors or issues you find.

Code:
\`\`\`${language}
${code}
\`\`\`

Context:
- File: ${context.file_path}
- Related files: ${context.related_files?.join(', ') || 'None'}

Provide:
1. A list of issues with line numbers
2. Severity (error, warning, info)
3. Clear explanation of each issue
4. Suggested fix for each issue

Format your response as JSON.
`,
      fix_suggestion: `
You are a code repair expert. Given the following ${language} code with identified issues, suggest complete fixes.

Code:
\`\`\`${language}
${code}
\`\`\`

Issues:
${JSON.stringify(context.issues, null, 2)}

Provide the complete fixed code and explain what you changed.
`,
      code_review: `
You are conducting a code review. Review this ${language} code for:
- Best practices
- Performance issues
- Security vulnerabilities
- Maintainability concerns

Code:
\`\`\`${language}
${code}
\`\`\`

Provide specific, actionable feedback.
`
    };

    return prompts[analysisType] || prompts.error_explanation;
  }

  parseAnalysis(text) {
    // Try to parse as JSON first
    try {
      return JSON.parse(text);
    } catch {
      // Fall back to plain text parsing
      return {
        raw_text: text,
        issues_found: this.extractIssues(text),
        suggestions: this.extractSuggestions(text)
      };
    }
  }

  extractIssues(text) {
    // Parse common patterns for issues
    const issuePatterns = [
      /Line (\d+):\s*(.+)/gi,
      /(\d+):\s*(.+)/gi
    ];

    const issues = [];
    for (const pattern of issuePatterns) {
      const matches = [...text.matchAll(pattern)];
      for (const match of matches) {
        issues.push({
          line: parseInt(match[1]),
          description: match[2].trim()
        });
      }
    }

    return issues;
  }

  extractSuggestions(text) {
    // Extract bullet points or numbered lists
    const suggestions = [];
    const lines = text.split('\n');

    for (const line of lines) {
      if (line.trim().match(/^[-*\d.]/)) {
        suggestions.push(line.trim().replace(/^[-*\d.]\s*/, ''));
      }
    }

    return suggestions;
  }
}
```

### LLM Usage Patterns

#### 1. Error Explanation

When validation finds issues, query LLM for human-friendly explanations:

```javascript
const llm = new LLMIntegration({ provider: 'claude' });

const pythonIssues = await pythonModule.check(files);

if (pythonIssues.length > 0) {
  const analysis = await llm.analyzeCode(
    fileContent,
    'python',
    { file_path: 'src/example.py', issues: pythonIssues },
    'error_explanation'
  );

  // Combine static analysis + LLM insights
  return {
    static_analysis: pythonIssues,
    llm_explanation: analysis.analysis,
    tokens_used: analysis.tokens_used
  };
}
```

#### 2. Automated Fix Generation

Use LLM to generate fixes for common issues:

```javascript
const fixSuggestion = await llm.analyzeCode(
  fileContent,
  'python',
  { issues: pythonIssues },
  'fix_suggestion'
);

// Present fix to user for approval before applying
if (userApprovesAutoFix) {
  await fs.writeFile(filePath, fixSuggestion.analysis.fixed_code);
}
```

#### 3. Code Review Assistance

Augment orchestrator validation with LLM code review:

```javascript
const review = await llm.analyzeCode(
  fileContent,
  'python',
  { file_path: 'src/example.py' },
  'code_review'
);

// Merge with static analysis
return {
  validation_issues: staticIssues,
  code_review_feedback: review.analysis,
  combined_severity: calculateCombinedSeverity(staticIssues, review)
};
```

---

## TDD Strategy

### Test Pyramid

```
        /\
       /  \
      / E2E \        10% - E2E Tests (API integration, Docker)
     /------\
    /  Integ \       20% - Integration Tests (Module communication)
   /----------\
  /    Unit    \     70% - Unit Tests (Pure functions, validation)
 /--------------\
```

### Testing Requirements

**All new code MUST have:**
- ✅ Unit tests written BEFORE implementation
- ✅ Integration tests for module interactions
- ✅ E2E tests for API endpoints
- ✅ 95%+ code coverage
- ✅ Tests pass in CI before merge

### Test Structure

#### 1. Unit Tests for API Endpoints

**File:** `tests/orchestrator/api/validation-endpoint.test.mjs`

```javascript
import { describe, it, before, after } from 'node:test';
import assert from 'node:assert';
import request from 'supertest';
import { createApp } from '../../../.github/scripts/orchestrator/api/app.mjs';

describe('POST /api/v1/validate', () => {
  let app, server;

  before(async () => {
    app = await createApp({ testing: true });
    server = app.listen(0);
  });

  after(async () => {
    await server.close();
  });

  it('should validate valid Python code', async () => {
    const response = await request(app)
      .post('/api/v1/validate')
      .set('Authorization', 'Bearer test-token')
      .send({
        files: [{
          path: 'test.py',
          content: 'def hello():\n    print("world")\n'
        }],
        options: {
          modules: ['python']
        }
      })
      .expect(200);

    assert.strictEqual(response.body.status, 'completed');
    assert.strictEqual(response.body.summary.total_issues, 0);
  });

  it('should detect Python syntax errors', async () => {
    const response = await request(app)
      .post('/api/v1/validate')
      .set('Authorization', 'Bearer test-token')
      .send({
        files: [{
          path: 'test.py',
          content: 'def hello(:\n    print("world")\n'
        }],
        options: {
          modules: ['python']
        }
      })
      .expect(200);

    assert.strictEqual(response.body.status, 'completed');
    assert(response.body.summary.total_issues > 0);
    assert.strictEqual(response.body.summary.errors, 1);
  });

  it('should return 401 without authentication', async () => {
    await request(app)
      .post('/api/v1/validate')
      .send({
        files: [{ path: 'test.py', content: 'print("hello")' }]
      })
      .expect(401);
  });
});
```

#### 2. Integration Tests for Docker Modules

**File:** `tests/orchestrator/docker/python-module-container.test.mjs`

```javascript
import { describe, it, before, after } from 'node:test';
import assert from 'node:assert';
import { exec } from 'node:child_process';
import { promisify } from 'node:util';

const execAsync = promisify(exec);

describe('Python Module Docker Container', () => {
  let containerId;

  before(async () => {
    // Start Python module container
    const { stdout } = await execAsync(
      'docker run -d -p 3001:3000 orchestrator-python-module:latest'
    );
    containerId = stdout.trim();

    // Wait for container to be ready
    await new Promise(resolve => setTimeout(resolve, 2000));
  });

  after(async () => {
    // Stop container
    if (containerId) {
      await execAsync(`docker stop ${containerId}`);
      await execAsync(`docker rm ${containerId}`);
    }
  });

  it('should respond to health check', async () => {
    const response = await fetch('http://localhost:3001/health');
    assert.strictEqual(response.status, 200);

    const data = await response.json();
    assert.strictEqual(data.status, 'healthy');
  });

  it('should validate Python code via HTTP', async () => {
    const response = await fetch('http://localhost:3001/check', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        files: ['test.py'],
        content: 'def foo():\n    print("bar")\n'
      })
    });

    assert.strictEqual(response.status, 200);
    const data = await response.json();
    assert.strictEqual(data.success, true);
  });
});
```

#### 3. E2E Tests for LLM Integration

**File:** `tests/orchestrator/llm/claude-integration.test.mjs`

```javascript
import { describe, it } from 'node:test';
import assert from 'node:assert';
import { LLMIntegration } from '../../../.github/scripts/orchestrator/llm-integration.mjs';

describe('LLM Integration - Claude', () => {
  it('should analyze Python code with errors', async () => {
    const llm = new LLMIntegration({
      provider: 'claude',
      model: 'claude-sonnet-4.5'
    });

    const code = 'def foo(x):\n    return x + y\n';
    const analysis = await llm.analyzeCode(
      code,
      'python',
      { file_path: 'test.py' },
      'error_explanation'
    );

    assert(analysis.analysis.issues_found.length > 0);
    assert(analysis.analysis.issues_found[0].line === 2);
    assert(analysis.analysis.issues_found[0].description.includes('undefined'));
    assert(analysis.tokens_used.input > 0);
    assert(analysis.tokens_used.output > 0);
  });

  it('should generate fix suggestions', async () => {
    const llm = new LLMIntegration({ provider: 'claude' });

    const code = 'def foo(x):\n    return x + y\n';
    const analysis = await llm.analyzeCode(
      code,
      'python',
      {
        issues: [{
          line: 2,
          message: 'Undefined variable y',
          rule: 'undefined-variable'
        }]
      },
      'fix_suggestion'
    );

    assert(analysis.analysis.fixed_code.includes('def foo(x, y):'));
  });
});
```

### CI/CD Integration

**File:** `.github/workflows/orchestrator-v3-ci.yml`

```yaml
name: Orchestrator V3 CI

on:
  push:
    branches: ['**']
  pull_request:
    branches: [main]

jobs:
  unit-tests:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v4
      - uses: actions/setup-node@v4
        with:
          node-version: '20'

      - name: Install dependencies
        run: npm ci

      - name: Run unit tests
        run: npm run test:orchestrator:unit

      - name: Upload coverage
        uses: codecov/codecov-action@v4
        with:
          files: ./coverage/coverage-final.json

  docker-tests:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v4

      - name: Build Docker images
        run: docker-compose build

      - name: Run integration tests
        run: npm run test:orchestrator:docker

      - name: Check container health
        run: docker-compose ps

  api-tests:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v4
      - uses: actions/setup-node@v4
        with:
          node-version: '20'

      - name: Start API server
        run: docker-compose up -d orchestrator-api

      - name: Wait for API to be ready
        run: npx wait-on http://localhost:8080/health -t 30000

      - name: Run E2E tests
        run: npm run test:orchestrator:e2e
        env:
          API_URL: http://localhost:8080

      - name: Stop API server
        run: docker-compose down
```

---

## Implementation Phases

### Phase 1: Docker Containerization (Week 1-2)

**Goal:** All language modules running in Docker containers

**Tasks:**
1. Create Dockerfiles for all 6 modules (Python, CSS, XML, Mermaid, Obsidian, n8n)
2. Create docker-compose.yml for orchestration
3. Implement HTTP API for each module
4. Write integration tests for container communication
5. Update module code to support server mode
6. Document Docker setup and usage

**Deliverables:**
- ✅ 6 Docker images built and tested
- ✅ docker-compose.yml functional
- ✅ Integration tests passing (20+ tests)
- ✅ Documentation complete

**Estimated Time:** 40-60 hours with TDD

### Phase 2: API Layer (Week 3-4)

**Goal:** RESTful API for orchestrator functionality

**Tasks:**
1. Create Express.js API server
2. Implement authentication (JWT)
3. Implement validation endpoints
4. Implement decision logging endpoints
5. Implement module management endpoints
6. Create OpenAPI specification
7. Set up Swagger UI
8. Implement rate limiting
9. Write API endpoint tests (unit + E2E)
10. Document API usage with examples

**Deliverables:**
- ✅ API server functional with all endpoints
- ✅ OpenAPI spec complete
- ✅ 50+ API endpoint tests passing
- ✅ Swagger UI accessible
- ✅ API documentation complete

**Estimated Time:** 60-80 hours with TDD

### Phase 3: LLM Integration (Week 5-6)

**Goal:** Claude/OpenAI integration for intelligent code analysis

**Tasks:**
1. Create LLMIntegration class
2. Implement Claude API client
3. Implement OpenAI API client (fallback)
4. Create prompt templates for each analysis type
5. Implement error explanation endpoint
6. Implement fix suggestion endpoint
7. Implement code review endpoint
8. Add token usage tracking
9. Write LLM integration tests (with mocks)
10. Document LLM usage patterns

**Deliverables:**
- ✅ LLM integration functional for both providers
- ✅ 3 analysis types implemented
- ✅ 30+ LLM tests passing
- ✅ Token usage tracking working
- ✅ LLM documentation complete

**Estimated Time:** 40-50 hours with TDD

### Phase 4: GitHub Actions Integration (Week 7)

**Goal:** Orchestrator V3 usable from GitHub Actions

**Tasks:**
1. Create GitHub Actions workflow to start Docker containers
2. Modify existing workflows to use orchestrator API
3. Implement API authentication for GitHub Actions
4. Add decision logging to GitHub Actions
5. Test complete workflow pipeline
6. Document GitHub Actions integration

**Deliverables:**
- ✅ GitHub Actions workflows updated
- ✅ End-to-end pipeline tested
- ✅ Documentation complete

**Estimated Time:** 20-30 hours

### Phase 5: Performance Optimization (Week 8)

**Goal:** Fast response times, efficient resource usage

**Tasks:**
1. Implement caching for validation results
2. Optimize Docker image sizes
3. Add container health checks and auto-restart
4. Implement API request batching
5. Add Prometheus metrics
6. Performance benchmark tests
7. Optimize LLM API usage (prompt caching)

**Deliverables:**
- ✅ Response times <500ms (p95)
- ✅ Docker images <500MB each
- ✅ Metrics dashboard functional
- ✅ Performance tests passing

**Estimated Time:** 30-40 hours

**Total Estimated Time:** 190-260 hours (5-7 weeks with 1 developer)

---

## Security Considerations

### 1. API Authentication

- **JWT tokens** with 1-hour expiration
- **Refresh tokens** for long-running sessions
- **Role-based access control** (user, admin, llm)
- **API keys** for service-to-service communication

### 2. Container Security

- **Non-root users** in all containers
- **Read-only file systems** where possible
- **Resource limits** (CPU, memory) per container
- **Network isolation** via Docker networks
- **Regular image updates** for security patches

### 3. LLM API Security

- **API keys stored in environment variables**, not code
- **Rate limiting** to prevent API abuse
- **Token usage monitoring** and alerts
- **Input sanitization** before sending to LLM
- **Output validation** before returning to user

### 4. Data Privacy

- **No sensitive data in logs**
- **Decision logs encrypted at rest** (optional)
- **API request/response logging** (audit trail)
- **GDPR compliance** (data retention policies)

---

## Performance & Scaling

### Performance Targets

| Metric                          | Target       | Measurement                        |
| ------------------------------- | ------------ | ---------------------------------- |
| API Response Time (p50)         | <200ms       | Validation endpoint                |
| API Response Time (p95)         | <500ms       | Validation endpoint                |
| API Response Time (p99)         | <1000ms      | Validation endpoint                |
| Container Startup Time          | <5s          | All modules                        |
| Docker Image Size               | <500MB       | Per module                         |
| LLM API Response Time           | <3s          | Code analysis                      |
| Concurrent Validations          | 50+          | Without degradation                |
| Memory Usage (API server)       | <512MB       | Idle state                         |
| Memory Usage (per module)       | <256MB       | Idle state                         |

### Scaling Strategy

#### Horizontal Scaling

- **Multiple module containers** per type (Python-1, Python-2, etc.)
- **Load balancing** with round-robin or least-connections
- **Auto-scaling** based on request volume

**docker-compose.yml with scaling:**

```yaml
services:
  python-module:
    deploy:
      replicas: 3
```

Run with: `docker-compose up --scale python-module=3`

#### Vertical Scaling

- **Increase container resources** for high-load scenarios
- **Optimize module code** for faster execution
- **Cache validation results** to avoid redundant processing

#### Caching Strategy

```javascript
import Redis from 'redis';

const cache = Redis.createClient();

async function validateWithCache(fileContent, options) {
  const cacheKey = `validation:${hashContent(fileContent)}:${JSON.stringify(options)}`;

  // Check cache first
  const cached = await cache.get(cacheKey);
  if (cached) {
    return JSON.parse(cached);
  }

  // Perform validation
  const result = await orchestrator.validate(fileContent, options);

  // Cache for 1 hour
  await cache.setex(cacheKey, 3600, JSON.stringify(result));

  return result;
}
```

---

## Migration from V2 to V3

### Backward Compatibility

V3 maintains backward compatibility with V2:

- **Existing workflows continue to work** with V2 modules
- **V3 API is additive**, no breaking changes
- **Gradual migration path** - modules can be migrated individually

### Migration Steps

1. **Phase 1:** Deploy V3 API alongside V2 workflows (parallel)
2. **Phase 2:** Migrate one module at a time to Docker
3. **Phase 3:** Update GitHub Actions workflows to use V3 API
4. **Phase 4:** Deprecate V2 modules (6 months notice)
5. **Phase 5:** Remove V2 code

---

## Conclusion

This architecture provides a robust, scalable, and intelligent orchestrator platform with:

✅ **Docker containerization** for portability and isolation
✅ **RESTful API** for programmatic access
✅ **LLM integration** for intelligent code analysis
✅ **Comprehensive TDD** for reliability
✅ **Security-first design** for production readiness
✅ **Performance targets** for fast response times

**Next Steps:**
1. Review and approve architecture
2. Create implementation issues for each phase
3. Set up development environment
4. Begin Phase 1 (Docker containerization)

**Estimated Total Effort:** 190-260 hours (5-7 weeks with 1 developer, 2-3 weeks with 2 developers)

---

**Document Version:** 1.0
**Last Updated:** 2025-11-14
**Author:** Claude (AI)
**Status:** Ready for Review
