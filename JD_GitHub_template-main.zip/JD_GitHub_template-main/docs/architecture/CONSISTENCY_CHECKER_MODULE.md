# Consistency Checker Module

**Priority:** HIGH (prevents merge conflicts)
**Type:** Cross-cutting concern
**Auto-fix:** YES

---

## Problem Statement

Different contributors, branches, or tools may apply formatting inconsistently:

### Example: Blank Line Formatting

```markdown
**Checkers** (20+ workflows):

- `format-check.yml`
```

vs.

```markdown
**Checkers** (20+ workflows):
- `format-check.yml`
```

These trivial differences cause **merge conflicts** and **wasted time**.

---

## Solution: Consistency Checker Module

### Design

The Consistency Checker is a **meta-module** that:

1. **Detects** formatting inconsistencies across the codebase
2. **Enforces** a single canonical format per file type
3. **Auto-fixes** before commits to prevent conflicts
4. **Validates** that all files follow the same conventions

### Module Type

- **Type:** `syntax` (formatting enforcement)
- **Category:** Cross-cutting (runs on all file types)
- **Capabilities:** `CAN_AUTO_FIX`, `CROSS_FILE`

---

## Implementation

### File: `.github/scripts/orchestrator/modules/consistency-module.mjs`

```javascript
import BaseModule from './base-module.mjs';
import { readFile, writeFile } from 'node:fs/promises';

/**
 * Consistency Checker Module
 *
 * Enforces consistent formatting across all files to prevent merge conflicts
 */
export default class ConsistencyModule extends BaseModule {
  constructor(config = {}) {
    super('consistency', {
      ...config,
      extensions: ['*'], // Runs on all files
      type: 'syntax',
      capabilities: ['can_auto_fix', 'cross_file'],
      enabled: true,
      priority: 100 // Highest priority - runs first
    });

    // Formatting rules per file type
    this.rules = {
      markdown: [
        { id: 'blank-line-after-heading', pattern: /^(#+\s+.+)\n([^#\n])/, replacement: '$1\n\n$2' },
        { id: 'blank-line-before-list', pattern: /([^\n])\n([-*+]\s)/, replacement: '$1\n\n$2' },
        { id: 'no-multiple-blank-lines', pattern: /\n{3,}/g, replacement: '\n\n' },
        { id: 'trim-trailing-spaces', pattern: /[ \t]+$/gm, replacement: '' },
        { id: 'single-final-newline', pattern: /\n*$/, replacement: '\n' }
      ],
      javascript: [
        { id: 'no-multiple-blank-lines', pattern: /\n{3,}/g, replacement: '\n\n' },
        { id: 'trim-trailing-spaces', pattern: /[ \t]+$/gm, replacement: '' },
        { id: 'single-final-newline', pattern: /\n*$/, replacement: '\n' }
      ],
      yaml: [
        { id: 'no-multiple-blank-lines', pattern: /\n{3,}/g, replacement: '\n\n' },
        { id: 'trim-trailing-spaces', pattern: /[ \t]+$/gm, replacement: '' },
        { id: 'single-final-newline', pattern: /\n*$/, replacement: '\n' }
      ],
      shell: [
        { id: 'no-multiple-blank-lines', pattern: /\n{3,}/g, replacement: '\n\n' },
        { id: 'trim-trailing-spaces', pattern: /[ \t]+$/gm, replacement: '' },
        { id: 'single-final-newline', pattern: /\n*$/, replacement: '\n' }
      ],
      // Universal rules applied to all files
      universal: [
        { id: 'trim-trailing-spaces', pattern: /[ \t]+$/gm, replacement: '' },
        { id: 'single-final-newline', pattern: /\n*$/, replacement: '\n' },
        { id: 'no-tabs', pattern: /\t/g, replacement: '  ', enabled: false } // Optional
      ]
    };
  }

  /**
   * Check files for consistency issues
   */
  async check(files, options = {}) {
    const startTime = Date.now();
    const issues = [];

    for (const file of files) {
      const fileIssues = await this.checkFile(file);
      issues.push(...fileIssues);
    }

    return this.formatCheckResult(
      issues.length === 0,
      issues,
      {
        duration_ms: Date.now() - startTime,
        tool_version: '1.0.0'
      }
    );
  }

  /**
   * Check a single file
   */
  async checkFile(file) {
    const content = await readFile(file, 'utf8');
    const rules = this.getRulesForFile(file);
    const issues = [];

    for (const rule of rules) {
      if (rule.enabled === false) continue;

      const matches = this.findMatches(content, rule.pattern);
      if (matches.length > 0) {
        issues.push({
          file,
          line: matches[0].line,
          code: rule.id,
          severity: 'warning',
          message: `Inconsistent formatting: ${rule.id}`,
          suggestion: `Apply standard formatting`
        });
      }
    }

    return issues;
  }

  /**
   * Fix files by applying consistency rules
   */
  async fix(files, strategy = 'balanced', options = {}) {
    const startTime = Date.now();
    const filesModified = [];
    let fixesApplied = 0;

    for (const file of files) {
      const result = await this.fixFile(file, strategy);
      if (result.modified) {
        filesModified.push(file);
        fixesApplied += result.fixCount;
      }
    }

    return this.formatFixResult(
      true,
      filesModified,
      fixesApplied,
      strategy,
      {
        duration_ms: Date.now() - startTime
      }
    );
  }

  /**
   * Fix a single file
   */
  async fixFile(file, strategy) {
    let content = await readFile(file, 'utf8');
    const originalContent = content;
    const rules = this.getRulesForFile(file);
    let fixCount = 0;

    for (const rule of rules) {
      if (rule.enabled === false) continue;

      // Apply rule based on strategy
      if (this.shouldApplyRule(rule, strategy)) {
        const newContent = content.replace(rule.pattern, rule.replacement);
        if (newContent !== content) {
          content = newContent;
          fixCount++;
        }
      }
    }

    const modified = content !== originalContent;
    if (modified) {
      await writeFile(file, content, 'utf8');
    }

    return { modified, fixCount };
  }

  /**
   * Get rules for a specific file
   */
  getRulesForFile(file) {
    const ext = file.split('.').pop();

    // Get file-type-specific rules
    let rules = [];
    if (file.endsWith('.md')) {
      rules = [...this.rules.markdown];
    } else if (file.match(/\.(js|mjs|cjs|ts|tsx)$/)) {
      rules = [...this.rules.javascript];
    } else if (file.match(/\.(yml|yaml)$/)) {
      rules = [...this.rules.yaml];
    } else if (file.match(/\.(sh|bash)$/)) {
      rules = [...this.rules.shell];
    }

    // Add universal rules
    rules.push(...this.rules.universal);

    return rules;
  }

  /**
   * Determine if rule should be applied based on strategy
   */
  shouldApplyRule(rule, strategy) {
    // Conservative: Only apply safe rules (trailing spaces, final newline)
    const safeRules = ['trim-trailing-spaces', 'single-final-newline'];

    if (strategy === 'conservative') {
      return safeRules.includes(rule.id);
    }

    // Balanced: Apply most rules
    if (strategy === 'balanced') {
      return !rule.aggressive;
    }

    // Aggressive: Apply all rules
    return true;
  }

  /**
   * Find pattern matches with line numbers
   */
  findMatches(content, pattern) {
    const matches = [];
    const lines = content.split('\n');

    if (pattern.global) {
      // Global regex
      let match;
      const regex = new RegExp(pattern);
      while ((match = regex.exec(content)) !== null) {
        const line = content.substring(0, match.index).split('\n').length;
        matches.push({ line, match: match[0] });
      }
    } else {
      // Non-global: check whole content
      const match = content.match(pattern);
      if (match) {
        const line = content.substring(0, match.index).split('\n').length;
        matches.push({ line, match: match[0] });
      }
    }

    return matches;
  }

  /**
   * Validate module is ready
   */
  async validate() {
    return {
      ready: true,
      capabilities: Array.from(this.capabilities)
    };
  }
}
```

---

## Configuration

### Add to `.github/orchestrator-modules.yml`

```yaml
modules:
  consistency:
    name: "Consistency Checker"
    description: "Enforces consistent formatting to prevent merge conflicts"
    extensions: ['*']
    type: syntax
    capabilities: [can_auto_fix, cross_file]
    checker:
      builtin: true
    fixer:
      builtin: true
      strategies: ['conservative', 'balanced', 'aggressive']
    enabled: true
    priority: 100  # Runs FIRST before all other modules

  # ... other modules
```

---

## Dependency Rule Integration

### Add to `.github/orchestrator-dependencies.yml`

```yaml
rules:
  - id: consistent-formatting-required
    name: "All files must use consistent formatting"
    condition:
      always: true
    check:
      run_module: consistency
    auto_fix:
      enabled: true
      action: run_module
      module: consistency
      strategy: balanced
    severity: warning
```

---

## Pre-Commit Hook Integration

### File: `.github/scripts/pre-commit-consistency.sh`

```bash
#!/bin/bash
# Pre-commit hook to enforce consistency

echo "🔍 Checking formatting consistency..."

# Run consistency module on staged files
STAGED_FILES=$(git diff --cached --name-only --diff-filter=ACM)

if [ -z "$STAGED_FILES" ]; then
  echo "✅ No files to check"
  exit 0
fi

# Run consistency checker
node .github/scripts/orchestrator/orchestrator-cli.mjs \
  --module consistency \
  --files "$STAGED_FILES" \
  --fix \
  --strategy balanced

if [ $? -ne 0 ]; then
  echo "❌ Consistency check failed"
  echo "Run: npm run format:fix"
  exit 1
fi

echo "✅ Consistency check passed"
exit 0
```

---

## GitHub Workflow Integration

### File: `.github/workflows/consistency-check.yml`

```yaml
name: Consistency Check

on:
  pull_request:
    types: [opened, synchronize]

jobs:
  check:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v4
        with:
          fetch-depth: 0

      - uses: actions/setup-node@v4
        with:
          node-version: 20

      - name: Get changed files
        id: changed-files
        run: |
          FILES=$(git diff --name-only origin/${{ github.base_ref }}...HEAD)
          echo "files=$FILES" >> $GITHUB_OUTPUT

      - name: Run consistency checker
        run: |
          node .github/scripts/orchestrator/orchestrator-cli.mjs \
            --module consistency \
            --files "${{ steps.changed-files.outputs.files }}" \
            --check

      - name: Auto-fix if needed
        if: failure()
        run: |
          node .github/scripts/orchestrator/orchestrator-cli.mjs \
            --module consistency \
            --files "${{ steps.changed-files.outputs.files }}" \
            --fix \
            --strategy balanced

          git config user.name "orchestrator-bot"
          git config user.email "orchestrator@github.com"
          git add -A
          git commit -m "fix: apply consistent formatting" || true
          git push
```

---

## Testing

### File: `tests/orchestrator/modules/consistency-module.test.mjs`

```javascript
import { describe, it } from 'node:test';
import assert from 'node:assert';
import ConsistencyModule from '../../../.github/scripts/orchestrator/modules/consistency-module.mjs';
import { writeFile, readFile, mkdtemp, rm } from 'node:fs/promises';
import { join } from 'node:path';
import { tmpdir } from 'node:os';

describe('ConsistencyModule', () => {
  describe('check', () => {
    it('should detect multiple blank lines', async () => {
      const module = new ConsistencyModule();
      const tmpDir = await mkdtemp(join(tmpdir(), 'consistency-test-'));
      const testFile = join(tmpDir, 'test.md');

      await writeFile(testFile, 'Line 1\n\n\n\nLine 2\n');

      const result = await module.check([testFile]);

      assert.strictEqual(result.success, false);
      assert.strictEqual(result.issues.length, 1);
      assert.strictEqual(result.issues[0].code, 'no-multiple-blank-lines');

      await rm(tmpDir, { recursive: true });
    });

    it('should detect trailing spaces', async () => {
      const module = new ConsistencyModule();
      const tmpDir = await mkdtemp(join(tmpdir(), 'consistency-test-'));
      const testFile = join(tmpDir, 'test.js');

      await writeFile(testFile, 'const x = 1;   \nconst y = 2;\n');

      const result = await module.check([testFile]);

      assert.strictEqual(result.success, false);
      assert.strictEqual(result.issues.length, 1);
      assert.strictEqual(result.issues[0].code, 'trim-trailing-spaces');

      await rm(tmpDir, { recursive: true });
    });
  });

  describe('fix', () => {
    it('should remove multiple blank lines', async () => {
      const module = new ConsistencyModule();
      const tmpDir = await mkdtemp(join(tmpdir(), 'consistency-test-'));
      const testFile = join(tmpDir, 'test.md');

      await writeFile(testFile, 'Line 1\n\n\n\nLine 2\n');

      const result = await module.fix([testFile], 'balanced');

      assert.strictEqual(result.success, true);
      assert.strictEqual(result.files_modified.length, 1);

      const content = await readFile(testFile, 'utf8');
      assert.strictEqual(content, 'Line 1\n\nLine 2\n');

      await rm(tmpDir, { recursive: true });
    });

    it('should trim trailing spaces', async () => {
      const module = new ConsistencyModule();
      const tmpDir = await mkdtemp(join(tmpdir(), 'consistency-test-'));
      const testFile = join(tmpDir, 'test.js');

      await writeFile(testFile, 'const x = 1;   \nconst y = 2;\n');

      const result = await module.fix([testFile], 'conservative');

      assert.strictEqual(result.success, true);
      const content = await readFile(testFile, 'utf8');
      assert.strictEqual(content, 'const x = 1;\nconst y = 2;\n');

      await rm(tmpDir, { recursive: true });
    });

    it('should respect strategy levels', async () => {
      const module = new ConsistencyModule();
      const tmpDir = await mkdtemp(join(tmpdir(), 'consistency-test-'));
      const testFile = join(tmpDir, 'test.md');

      // File with both trailing spaces (conservative fix) and blank line issues (balanced fix)
      await writeFile(testFile, '# Heading   \n\n\n\nParagraph\n');

      // Conservative should only fix trailing spaces
      await writeFile(testFile, '# Heading   \n\n\n\nParagraph\n');
      await module.fix([testFile], 'conservative');
      let content = await readFile(testFile, 'utf8');
      assert.strictEqual(content, '# Heading\n\n\n\nParagraph\n');

      // Balanced should fix both
      await writeFile(testFile, '# Heading   \n\n\n\nParagraph\n');
      await module.fix([testFile], 'balanced');
      content = await readFile(testFile, 'utf8');
      assert.strictEqual(content, '# Heading\n\nParagraph\n');

      await rm(tmpDir, { recursive: true });
    });
  });

  describe('cross-file consistency', () => {
    it('should apply same rules to all markdown files', async () => {
      const module = new ConsistencyModule();
      const tmpDir = await mkdtemp(join(tmpdir(), 'consistency-test-'));

      const file1 = join(tmpDir, 'file1.md');
      const file2 = join(tmpDir, 'file2.md');

      await writeFile(file1, '# Heading   \n\n\n\nText\n');
      await writeFile(file2, '# Heading   \n\n\n\nText\n');

      await module.fix([file1, file2], 'balanced');

      const content1 = await readFile(file1, 'utf8');
      const content2 = await readFile(file2, 'utf8');

      // Both files should have identical formatting
      assert.strictEqual(content1, content2);
      assert.strictEqual(content1, '# Heading\n\nText\n');

      await rm(tmpDir, { recursive: true });
    });
  });
});
```

---

## Benefits

### 1. Prevents Merge Conflicts

- All contributors use the same formatting
- Automated enforcement in CI
- Pre-commit hooks catch issues early

### 2. Reduces Code Review Time

- No debates about formatting
- Reviewers focus on logic, not style

### 3. Compounding Effect

- Every new file follows standards
- Codebase becomes more consistent over time
- Future merges are cleaner

### 4. Self-Improving

- Decision logs show which rules trigger most
- Can refine rules based on actual usage

---

## Preventing Auto-Merge Failures

### The Problem

```
Branch A: Commits code → Auto-formatted → Pushed
Branch B: Commits code → NOT formatted yet → Pushed

Result: Cannot auto-merge even though logic is identical!
```

### The Solution: Synchronized Formatting Points

**CRITICAL:** Formatting must happen at the **same lifecycle stage** for ALL commits.

#### Strategy 1: Pre-Push Hook (RECOMMENDED)

Format all files **before** they leave the developer's machine:

```bash
# .git/hooks/pre-push
#!/bin/bash

echo "🔧 Auto-formatting before push..."

# Get all files to be pushed
FILES=$(git diff --name-only @{upstream}..HEAD)

if [ -z "$FILES" ]; then
  exit 0
fi

# Run consistency fixer
node .github/scripts/orchestrator/orchestrator-cli.mjs \
  --module consistency \
  --files "$FILES" \
  --fix \
  --strategy balanced \
  --auto-commit

if [ $? -ne 0 ]; then
  echo "❌ Formatting failed"
  exit 1
fi

# If files were modified, auto-commit them
if ! git diff-index --quiet HEAD --; then
  git add -A
  git commit --amend --no-edit
  echo "✅ Formatting applied and committed"
fi

echo "✅ Ready to push"
exit 0
```

#### Strategy 2: PR Auto-Format Bot

When PR is opened, **immediately** apply formatting:

```yaml
# .github/workflows/pr-auto-format.yml
name: Auto-Format PR

on:
  pull_request:
    types: [opened, synchronize]

jobs:
  format:
    runs-on: ubuntu-latest
    permissions:
      contents: write
      pull-requests: write

    steps:
      - uses: actions/checkout@v4
        with:
          ref: ${{ github.head_ref }}
          fetch-depth: 0

      - uses: actions/setup-node@v4
        with:
          node-version: 20

      - name: Get changed files
        id: files
        run: |
          FILES=$(git diff --name-only origin/${{ github.base_ref }}...HEAD)
          echo "files=$FILES" >> $GITHUB_OUTPUT

      - name: Auto-format
        run: |
          node .github/scripts/orchestrator/orchestrator-cli.mjs \
            --module consistency \
            --files "${{ steps.files.outputs.files }}" \
            --fix \
            --strategy balanced

      - name: Commit formatting changes
        run: |
          git config user.name "github-actions[bot]"
          git config user.email "github-actions[bot]@users.noreply.github.com"

          if ! git diff-index --quiet HEAD --; then
            git add -A
            git commit -m "chore: auto-format code [skip ci]"
            git push
            echo "✅ Formatting applied"
          else
            echo "✅ No formatting needed"
          fi
```

#### Strategy 3: Base Branch Consistency

Ensure the base branch (main) is **always** formatted:

```yaml
# .github/workflows/main-consistency-gate.yml
name: Main Branch Consistency Gate

on:
  push:
    branches: [main]

jobs:
  enforce:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v4

      - name: Check formatting
        run: |
          node .github/scripts/orchestrator/orchestrator-cli.mjs \
            --module consistency \
            --check

      - name: Fail if inconsistent
        if: failure()
        run: |
          echo "❌ ERROR: Main branch has inconsistent formatting!"
          echo "This should never happen. All PRs should auto-format before merge."
          exit 1
```

### Recommended Configuration

#### Option A: Aggressive (Best for preventing conflicts)

```yaml
# All formatting happens pre-push
hooks:
  pre_push:
    enabled: true
    auto_commit: true
    strategy: balanced

# PR bot only validates (doesn't modify)
pr_bot:
  enabled: true
  mode: validate
  fail_on_inconsistency: true
```

**Flow:**
1. Developer commits locally
2. Pre-push hook formats and amends commit
3. Push happens with formatted code
4. PR bot validates (should always pass)
5. No conflicts because all code is pre-formatted

#### Option B: Lazy (Easier for developers)

```yaml
# No pre-push hook
hooks:
  pre_push:
    enabled: false

# PR bot auto-formats
pr_bot:
  enabled: true
  mode: auto_fix
  auto_commit: true
```

**Flow:**
1. Developer commits and pushes unformatted code
2. PR bot detects inconsistency
3. PR bot auto-formats and pushes
4. All PRs have consistent formatting before review

**Risk:** If two PRs are opened simultaneously, bot might format them differently (timing issue).

#### Option C: Hybrid (RECOMMENDED)

```yaml
# Optional pre-push hook (developer choice)
hooks:
  pre_push:
    enabled: true
    optional: true  # Can be skipped with --no-verify
    auto_commit: true

# PR bot always runs as backup
pr_bot:
  enabled: true
  mode: auto_fix
  auto_commit: true

# Main branch gate as final safeguard
main_gate:
  enabled: true
  block_on_failure: true
```

**Flow:**
1. Developer can format pre-push (optional)
2. If not formatted locally, PR bot formats it
3. Main gate prevents any inconsistent code from landing
4. **All code in main is always formatted identically**

---

## Implementation: Auto-Commit Feature

### Enhanced Orchestrator CLI

**File:** `.github/scripts/orchestrator/orchestrator-cli.mjs`

```javascript
#!/usr/bin/env node

import Orchestrator from './orchestrator.mjs';
import { parseArgs } from 'node:util';
import { exec } from 'node:child_process';
import { promisify } from 'node:util';

const execAsync = promisify(exec);

const { values } = parseArgs({
  options: {
    module: { type: 'string' },
    files: { type: 'string' },
    fix: { type: 'boolean', default: false },
    check: { type: 'boolean', default: false },
    strategy: { type: 'string', default: 'balanced' },
    'auto-commit': { type: 'boolean', default: false },
    'commit-message': { type: 'string', default: 'chore: auto-format code' }
  }
});

async function main() {
  const orchestrator = new Orchestrator();

  // ... existing orchestrator logic ...

  const result = await orchestrator.run(context, options);

  // If auto-commit is enabled and files were modified
  if (values['auto-commit'] && result.filesModified?.length > 0) {
    await autoCommitChanges(
      result.filesModified,
      values['commit-message']
    );
  }

  process.exit(result.success ? 0 : 1);
}

/**
 * Auto-commit formatted changes
 */
async function autoCommitChanges(files, message) {
  try {
    console.log('📝 Auto-committing formatting changes...');

    // Stage files
    await execAsync(`git add ${files.join(' ')}`);

    // Check if there are staged changes
    const { stdout: status } = await execAsync('git diff --cached --quiet');

    // Commit if there are changes
    try {
      await execAsync(`git commit -m "${message}"`);
      console.log('✅ Changes committed');
    } catch (error) {
      // No changes to commit (diff --quiet passed)
      console.log('ℹ️ No changes to commit');
    }
  } catch (error) {
    console.error('❌ Failed to auto-commit:', error.message);
    throw error;
  }
}

main().catch((error) => {
  console.error('❌ Orchestrator error:', error.message);
  process.exit(1);
});
```

---

## Testing Merge Scenarios

### Test Case 1: Parallel PRs with Auto-Format

```bash
# Setup
git checkout main
echo "Line1\n\n\n\nLine2" > test.md
git add test.md
git commit -m "Initial commit"
git push

# Branch A
git checkout -b branch-a
echo "Line1\n\n\n\nLine2\nLineA" > test.md
git add test.md
git commit -m "Add line A"
# Pre-push hook runs → formats to "Line1\n\nLine2\nLineA"
git push

# Branch B (created from main, not branch-a)
git checkout main
git checkout -b branch-b
echo "Line1\n\n\n\nLine2\nLineB" > test.md
git add test.md
git commit -m "Add line B"
# Pre-push hook runs → formats to "Line1\n\nLine2\nLineB"
git push

# Result:
# Both branches have IDENTICAL formatting (2 blank lines → 1)
# Git can auto-merge because only LineA vs LineB differs
# SUCCESS: Auto-merge possible!
```

### Test Case 2: Without Auto-Format (OLD WAY)

```bash
# Branch A - developer A uses 2 spaces
echo "Line1\n\n\n\nLine2\nLineA" > test.md
# → Not formatted
git push

# Branch B - developer B uses 4 spaces
echo "Line1\n\n\n\nLine2\nLineB" > test.md
# → Not formatted
git push

# Both PRs get merged at different times
# Branch A merges first → CI auto-formats it
# Branch B tries to merge → CONFLICT!
# Even though logic is identical, formatting differs

# FAILURE: Manual merge required
```

---

## Rollout Plan

### Phase 1: Soft Launch (Week 1)
- [ ] Implement ConsistencyModule
- [ ] Add to orchestrator-modules.yml (disabled)
- [ ] Run on entire codebase to identify issues
- [ ] Generate report of violations

### Phase 2: Format Existing Code (Week 2)
- [ ] Enable module
- [ ] Run with `balanced` strategy on main branch
- [ ] Create "formatting baseline" PR
- [ ] Review and merge
- [ ] **All future PRs branch from formatted main**

### Phase 3: Enable PR Bot (Week 3)
- [ ] Add pr-auto-format.yml workflow
- [ ] Test on a few PRs
- [ ] Monitor for issues
- [ ] Enable for all PRs

### Phase 4: Enable Pre-Push Hook (Week 4)
- [ ] Add pre-push hook script
- [ ] Document installation process
- [ ] Make it optional (developers can skip with --no-verify)
- [ ] Encourage adoption

### Phase 5: Full Enforcement (Week 5)
- [ ] Add main branch consistency gate
- [ ] Require consistency check to pass for merges
- [ ] Document in CONTRIBUTING.md
- [ ] Celebrate zero formatting conflicts! 🎉

---

## Success Metrics

- **Zero** formatting-related merge conflicts
- **<1 minute** PR review time spent on formatting
- **100%** of files pass consistency checks
- **Automatic** fixes applied before human review

---

**This is exactly the kind of compounding improvement that makes the orchestrator invaluable!**
