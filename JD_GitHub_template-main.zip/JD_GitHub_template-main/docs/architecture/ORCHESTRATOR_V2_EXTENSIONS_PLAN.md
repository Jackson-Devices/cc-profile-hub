# Orchestrator V2 Extension Planning

**Version:** 1.0
**Status:** Planning Phase
**Date:** 2025-11-14
**Approach:** TDD-First, BMAD (Build-Measure-Analyze-Decide), Compounding Engineering

---

## Executive Summary

This document outlines the extension of Orchestrator V2 to support:

1. **20+ new language/protocol checkers** (Mermaid, Python, Obsidian, n8n, Markdown, C/C++, XML, CSS, JSON, IPv4, Bluetooth, BLE, MIDI, Serial, USB)
2. **Contextual dependency validation** (if A exists, then B and C must exist)
3. **Recipe/template system** for reusable patterns
4. **External orchestration API** for LLM and Cloudflare Workers integration
5. **Enhanced decision logging** and intelligent language understanding
6. **Auto-repair capabilities** for missing contextual elements

### Design Principles

- **TDD-First:** Every feature gets tests before implementation
- **BMAD:** Build incrementally, measure impact, analyze results, decide next steps
- **Compounding:** Each module builds on previous work, creating exponential value
- **Atomic:** Changes are small, focused, and independently testable
- **Extensible:** Design for future additions without core changes

---

## Table of Contents

1. [Current State Analysis](#current-state-analysis)
2. [Extension Categories](#extension-categories)
3. [Architecture Changes](#architecture-changes)
4. [Module Taxonomy](#module-taxonomy)
5. [Contextual Dependency System](#contextual-dependency-system)
6. [Recipe System](#recipe-system)
7. [External Orchestration API](#external-orchestration-api)
8. [Decision Logging System](#decision-logging-system)
9. [Implementation Roadmap](#implementation-roadmap)
10. [Testing Strategy](#testing-strategy)

---

## Current State Analysis

### What We Have (V2 Implementation)

```javascript
// ✅ Core Infrastructure
- Orchestrator main controller
- BaseModule interface
- FileDiscovery service
- FileRouter with priority-based routing
- MultiPassFixEngine with retry logic
- Strategy escalation (conservative → balanced → aggressive)
- GitHub Actions integration

// ✅ Working Modules
- Shell (shellcheck)
- JavaScript (ESLint)
- YAML (Prettier)

// ⚠️ Stub Modules (Disabled)
- C++ (clang-tidy/clang-format)
- Python (pylint/black)
```

### What We Need

```
Phase 1: Language/Syntax Checkers (7 modules)
├── Mermaid - diagram syntax validation
├── Markdown - linting and formatting
├── XML - well-formedness and schema validation
├── CSS - style linting
├── JSON - schema validation
├── Python - linting/formatting (enable existing stub)
└── C/C++ - static analysis (enable existing stub)

Phase 2: Protocol/Data Validators (6 modules)
├── IPv4 - address/network validation
├── Bluetooth - UUID and spec validation
├── BLE - GATT profile validation
├── MIDI - message format validation
├── Serial - configuration validation
└── USB - descriptor validation

Phase 3: Domain-Specific Modules (3 modules)
├── Obsidian - vault structure and link validation
├── n8n - workflow validation
└── Protocol Buffer - schema validation

Phase 4: Contextual Intelligence
├── Dependency graph system
├── Recipe/template engine
├── Auto-repair engine
└── External orchestration API

Phase 5: Observability
├── Decision logging
├── Metrics collection
└── Audit trail
```

---

## Extension Categories

### Category 1: Syntax/Structure Validators

**Characteristics:**
- Check well-formedness and syntax
- Can often auto-fix formatting
- Static analysis only
- Fast execution

**Examples:** Mermaid, Markdown, XML, CSS, JSON

**Module Pattern:**
```javascript
class SyntaxModule extends BaseModule {
  async check(files) {
    // 1. Parse file
    // 2. Validate syntax against grammar
    // 3. Run linter rules
    // 4. Return structured issues
  }

  async fix(files, strategy) {
    // 1. Apply prettier/formatter
    // 2. Auto-fix known patterns
    // 3. Return modified files
  }
}
```

### Category 2: Protocol/Specification Validators

**Characteristics:**
- Validate against external specs (IEEE, Bluetooth SIG, etc.)
- Often need context (e.g., USB class determines descriptor requirements)
- May require lookup tables or databases
- Cannot auto-fix (requires human decision)

**Examples:** IPv4, Bluetooth, BLE, MIDI, Serial, USB

**Module Pattern:**
```javascript
class ProtocolModule extends BaseModule {
  async check(files) {
    // 1. Parse protocol data
    // 2. Validate against spec
    // 3. Check for common misconfigurations
    // 4. Return violations
  }

  async fix(files, strategy) {
    // Most protocol errors cannot be auto-fixed
    // Return suggestions only
    return {
      success: false,
      suggestions: [...],
      manual_intervention_required: true
    };
  }
}
```

### Category 3: Domain-Specific Validators

**Characteristics:**
- Understand domain semantics (not just syntax)
- May need cross-file analysis
- Context-aware validation
- May interact with external systems

**Examples:** Obsidian, n8n, Protocol Buffers

**Module Pattern:**
```javascript
class DomainModule extends BaseModule {
  async check(files) {
    // 1. Load domain context (vault, workflow, etc.)
    // 2. Validate cross-references
    // 3. Check domain rules
    // 4. Return semantic issues
  }

  async fix(files, strategy) {
    // Context-aware fixes
    // May create new files or modify multiple files
  }
}
```

---

## Architecture Changes

### 1. Module Type System

**New file:** `.github/scripts/orchestrator/module-types.mjs`

```javascript
/**
 * Module Type Enumeration
 */
export const ModuleType = {
  SYNTAX: 'syntax',           // Syntax/formatting checkers
  PROTOCOL: 'protocol',       // Protocol/spec validators
  DOMAIN: 'domain',           // Domain-specific validators
  HYBRID: 'hybrid'            // Combination (e.g., C++ has syntax + semantics)
};

/**
 * Capability Flags
 */
export const ModuleCapability = {
  CAN_AUTO_FIX: 'can_auto_fix',
  REQUIRES_CONTEXT: 'requires_context',
  CROSS_FILE: 'cross_file',
  EXTERNAL_DEPS: 'external_deps',
  SEMANTIC_ANALYSIS: 'semantic_analysis'
};

/**
 * Enhanced BaseModule with type system
 */
export class TypedBaseModule extends BaseModule {
  constructor(name, config) {
    super(name, config);
    this.moduleType = config.type || ModuleType.SYNTAX;
    this.capabilities = new Set(config.capabilities || []);
  }

  hasCapability(cap) {
    return this.capabilities.has(cap);
  }

  requiresContext() {
    return this.hasCapability(ModuleCapability.REQUIRES_CONTEXT);
  }

  canAutoFix() {
    return this.hasCapability(ModuleCapability.CAN_AUTO_FIX);
  }
}
```

### 2. Context Provider System

**New file:** `.github/scripts/orchestrator/context-provider.mjs`

```javascript
/**
 * Provides context for modules that need it
 */
export class ContextProvider {
  constructor() {
    this.contexts = new Map();
  }

  /**
   * Register a context provider
   */
  register(name, provider) {
    this.contexts.set(name, provider);
  }

  /**
   * Get context for a module
   */
  async getContext(moduleName, files) {
    const provider = this.contexts.get(moduleName);
    if (!provider) return {};

    return await provider.provide(files);
  }
}

/**
 * Example: Obsidian context provider
 */
export class ObsidianContextProvider {
  async provide(files) {
    // Scan vault structure
    // Build link graph
    // Index tags and metadata
    return {
      vaultRoot: '...',
      linkGraph: {...},
      tags: [...],
      templates: [...]
    };
  }
}
```

### 3. Dependency Graph System

**New file:** `.github/scripts/orchestrator/dependency-graph.mjs`

```javascript
/**
 * Dependency Graph for contextual validation
 *
 * Rules like: "If A exists, then B and C must exist"
 */
export class DependencyGraph {
  constructor() {
    this.rules = [];
  }

  /**
   * Add a dependency rule
   */
  addRule(rule) {
    this.rules.push(rule);
  }

  /**
   * Load rules from configuration
   */
  async loadRules(configPath) {
    // Load from YAML/JSON
  }

  /**
   * Validate all files against dependency rules
   */
  async validate(files) {
    const violations = [];

    for (const rule of this.rules) {
      const result = await this.checkRule(rule, files);
      if (!result.valid) {
        violations.push({
          rule: rule.id,
          message: rule.message,
          missing: result.missing,
          found: result.found
        });
      }
    }

    return violations;
  }

  async checkRule(rule, files) {
    // Example rule:
    // {
    //   id: 'package-json-requires-lock',
    //   condition: { file_exists: 'package.json' },
    //   requires: [
    //     { file_exists: 'package-lock.json' }
    //   ],
    //   message: 'package.json requires package-lock.json'
    // }

    const conditionMet = await this.evaluateCondition(rule.condition, files);
    if (!conditionMet) return { valid: true };

    const missing = [];
    for (const req of rule.requires) {
      const reqMet = await this.evaluateCondition(req, files);
      if (!reqMet) {
        missing.push(req);
      }
    }

    return {
      valid: missing.length === 0,
      missing,
      found: files
    };
  }

  async evaluateCondition(condition, files) {
    if (condition.file_exists) {
      return files.some(f => f.includes(condition.file_exists));
    }
    if (condition.file_contains) {
      // Read file and check for pattern
    }
    if (condition.custom) {
      // Run custom validation function
    }
    return false;
  }
}
```

**Configuration:** `.github/orchestrator-dependencies.yml`

```yaml
# Dependency rules configuration
rules:
  - id: package-lock-required
    name: "package.json requires package-lock.json"
    condition:
      file_exists: "package.json"
    requires:
      - file_exists: "package-lock.json"
    auto_fix:
      enabled: true
      action: run_command
      command: "npm install"
    severity: error

  - id: typescript-config-required
    name: "TypeScript files require tsconfig.json"
    condition:
      file_pattern: "**/*.ts"
    requires:
      - file_exists: "tsconfig.json"
    auto_fix:
      enabled: true
      action: create_file
      template: "templates/tsconfig.json"
    severity: error

  - id: readme-required
    name: "Projects should have README.md"
    condition:
      file_exists: "package.json"
    requires:
      - file_exists: "README.md"
    auto_fix:
      enabled: true
      action: create_from_recipe
      recipe: "readme-template"
    severity: warning

  - id: obsidian-daily-note-template
    name: "Obsidian daily notes require template"
    condition:
      file_pattern: "daily-notes/**/*.md"
    requires:
      - file_exists: ".obsidian/templates/daily-note.md"
    auto_fix:
      enabled: true
      action: create_from_recipe
      recipe: "obsidian-daily-template"
    severity: warning

  - id: n8n-credentials-required
    name: "n8n workflows require credentials file"
    condition:
      file_pattern: "workflows/**/*.json"
      file_contains: "\"credentialsId\":"
    requires:
      - file_exists: "credentials/**/*.json"
    auto_fix:
      enabled: false
    severity: error
```

---

## Module Taxonomy

### Tier 1: High-Value, Low-Complexity (Implement First)

| Module | Type | Auto-Fix | Tools | Priority | Complexity |
|--------|------|----------|-------|----------|------------|
| **Markdown** | Syntax | ✅ Yes | markdownlint, prettier | 1 | Low |
| **JSON** | Syntax | ✅ Yes | jsonlint, jq | 1 | Low |
| **CSS** | Syntax | ✅ Yes | stylelint, prettier | 2 | Low |
| **XML** | Syntax | ✅ Yes | xmllint, prettier | 2 | Low |
| **Python** | Hybrid | ✅ Yes | pylint, black, mypy | 1 | Medium |

### Tier 2: Medium-Value, Medium-Complexity

| Module | Type | Auto-Fix | Tools | Priority | Complexity |
|--------|------|----------|-------|----------|------------|
| **Mermaid** | Domain | ⚠️ Partial | mermaid-cli | 3 | Medium |
| **Obsidian** | Domain | ⚠️ Partial | Custom | 3 | Medium |
| **C/C++** | Hybrid | ✅ Yes | clang-tidy, clang-format | 2 | High |
| **IPv4** | Protocol | ❌ No | Custom | 4 | Low |

### Tier 3: Specialized, High-Complexity

| Module | Type | Auto-Fix | Tools | Priority | Complexity |
|--------|------|----------|-------|----------|------------|
| **n8n** | Domain | ⚠️ Partial | Custom | 4 | High |
| **Bluetooth/BLE** | Protocol | ❌ No | Custom | 5 | High |
| **MIDI** | Protocol | ❌ No | Custom | 5 | Medium |
| **Serial/USB** | Protocol | ❌ No | Custom | 5 | Medium |

---

## Contextual Dependency System

### Design

```
┌────────────────────────────────────────────────────────┐
│ 1. FILE DISCOVERY                                      │
│    └─> List of changed files                          │
└─────────────────┬──────────────────────────────────────┘
                  │
                  ▼
┌────────────────────────────────────────────────────────┐
│ 2. DEPENDENCY VALIDATION (NEW)                         │
│    ├─> Load dependency rules                           │
│    ├─> Evaluate conditions                             │
│    ├─> Check requirements                              │
│    └─> Generate violations                             │
└─────────────────┬──────────────────────────────────────┘
                  │
                  ▼
┌────────────────────────────────────────────────────────┐
│ 3. AUTO-REPAIR ENGINE (NEW)                            │
│    ├─> Identify fixable violations                     │
│    ├─> Apply recipes/templates                         │
│    ├─> Run fix commands                                │
│    └─> Create missing files                            │
└─────────────────┬──────────────────────────────────────┘
                  │
                  ▼
┌────────────────────────────────────────────────────────┐
│ 4. STANDARD MODULE ROUTING                             │
│    └─> Continue with existing orchestrator flow       │
└────────────────────────────────────────────────────────┘
```

### Auto-Repair Engine

**File:** `.github/scripts/orchestrator/auto-repair-engine.mjs`

```javascript
export class AutoRepairEngine {
  constructor(recipeRegistry) {
    this.recipeRegistry = recipeRegistry;
  }

  async repair(violations) {
    const results = [];

    for (const violation of violations) {
      if (!violation.rule.auto_fix?.enabled) {
        results.push({
          violation,
          repaired: false,
          reason: 'Auto-fix not enabled'
        });
        continue;
      }

      const result = await this.applyFix(violation);
      results.push(result);
    }

    return results;
  }

  async applyFix(violation) {
    const { action } = violation.rule.auto_fix;

    switch (action) {
      case 'run_command':
        return await this.runCommand(violation);

      case 'create_file':
        return await this.createFile(violation);

      case 'create_from_recipe':
        return await this.createFromRecipe(violation);

      default:
        return { repaired: false, reason: 'Unknown action' };
    }
  }

  async runCommand(violation) {
    // Execute command (e.g., npm install)
  }

  async createFile(violation) {
    // Create file from template
  }

  async createFromRecipe(violation) {
    // Load recipe and generate file
    const recipe = await this.recipeRegistry.get(
      violation.rule.auto_fix.recipe
    );
    return await recipe.apply(violation);
  }
}
```

---

## Recipe System

### Design Philosophy

**Recipes** are reusable templates/patterns that can:
- Generate files from templates
- Apply multi-file transformations
- Encode best practices
- Be shared and evolved

### Recipe Structure

**File:** `.github/orchestrator-recipes.yml`

```yaml
recipes:
  readme-template:
    name: "Standard README Template"
    description: "Generates a README.md with standard sections"
    version: "1.0.0"
    inputs:
      - name: project_name
        type: string
        required: true
      - name: description
        type: string
        required: true
      - name: author
        type: string
        default: ""

    actions:
      - type: create_file
        path: "README.md"
        template: |
          # {{project_name}}

          {{description}}

          ## Installation

          ```bash
          npm install
          ```

          ## Usage

          TODO: Add usage instructions

          ## Author

          {{author}}

  obsidian-daily-template:
    name: "Obsidian Daily Note Template"
    inputs:
      - name: date
        type: date
        default: today

    actions:
      - type: create_file
        path: ".obsidian/templates/daily-note.md"
        template: |
          ---
          date: {{date}}
          tags: [daily]
          ---

          # {{date}}

          ## Tasks
          - [ ]

          ## Notes

          ## Links

  typescript-project-setup:
    name: "TypeScript Project Setup"
    description: "Complete TypeScript project configuration"
    inputs:
      - name: target
        type: string
        default: "ES2020"

    actions:
      - type: create_file
        path: "tsconfig.json"
        template_file: "templates/tsconfig.json.tmpl"

      - type: create_file
        path: ".eslintrc.json"
        template_file: "templates/eslintrc-ts.json.tmpl"

      - type: run_command
        command: "npm install --save-dev typescript @types/node"

      - type: modify_file
        path: "package.json"
        operation: merge
        data:
          scripts:
            build: "tsc"
            type-check: "tsc --noEmit"
```

### Recipe Registry

**File:** `.github/scripts/orchestrator/recipe-registry.mjs`

```javascript
export class RecipeRegistry {
  constructor() {
    this.recipes = new Map();
  }

  async load(configPath) {
    // Load recipes from YAML
  }

  register(name, recipe) {
    this.recipes.set(name, recipe);
  }

  async get(name) {
    return this.recipes.get(name);
  }

  async apply(recipeName, inputs = {}) {
    const recipe = await this.get(recipeName);
    if (!recipe) {
      throw new Error(`Recipe not found: ${recipeName}`);
    }

    return await recipe.execute(inputs);
  }
}

export class Recipe {
  constructor(config) {
    this.name = config.name;
    this.description = config.description;
    this.inputs = config.inputs || [];
    this.actions = config.actions || [];
  }

  async execute(inputs) {
    // Validate inputs
    const validatedInputs = this.validateInputs(inputs);

    // Execute actions
    const results = [];
    for (const action of this.actions) {
      const result = await this.executeAction(action, validatedInputs);
      results.push(result);
    }

    return {
      success: results.every(r => r.success),
      results
    };
  }

  validateInputs(inputs) {
    const validated = {};

    for (const inputDef of this.inputs) {
      if (inputDef.required && !inputs[inputDef.name]) {
        throw new Error(`Required input missing: ${inputDef.name}`);
      }

      validated[inputDef.name] = inputs[inputDef.name] || inputDef.default;
    }

    return validated;
  }

  async executeAction(action, inputs) {
    switch (action.type) {
      case 'create_file':
        return await this.createFile(action, inputs);
      case 'modify_file':
        return await this.modifyFile(action, inputs);
      case 'run_command':
        return await this.runCommand(action, inputs);
      default:
        throw new Error(`Unknown action type: ${action.type}`);
    }
  }

  async createFile(action, inputs) {
    // Render template with inputs
    const content = this.renderTemplate(action.template, inputs);

    // Write file
    // ...

    return { success: true, path: action.path };
  }

  renderTemplate(template, inputs) {
    // Simple template rendering (use mustache/handlebars in production)
    let rendered = template;
    for (const [key, value] of Object.entries(inputs)) {
      rendered = rendered.replaceAll(`{{${key}}}`, value);
    }
    return rendered;
  }
}
```

---

## External Orchestration API

### Design Goals

Enable **external systems** (LLMs, Cloudflare Workers, human operators) to:
1. **Query** orchestrator status
2. **Provide** hints/suggestions for fixes
3. **Orchestrate** the orchestrator (meta-orchestration)
4. **Contribute** new recipes dynamically

### API Design

**Protocol:** JSON-RPC over HTTP or stdin/stdout

**File:** `.github/scripts/orchestrator/api-server.mjs`

```javascript
/**
 * External Orchestration API
 *
 * Enables LLMs and other services to interact with the orchestrator
 */
export class OrchestratorAPI {
  constructor(orchestrator) {
    this.orchestrator = orchestrator;
    this.handlers = new Map();
    this.registerHandlers();
  }

  registerHandlers() {
    this.handlers.set('get_status', this.getStatus.bind(this));
    this.handlers.set('suggest_fix', this.suggestFix.bind(this));
    this.handlers.set('apply_recipe', this.applyRecipe.bind(this));
    this.handlers.set('validate_dependencies', this.validateDependencies.bind(this));
    this.handlers.set('get_module_info', this.getModuleInfo.bind(this));
  }

  /**
   * Process API request
   */
  async handle(request) {
    const { method, params, id } = request;

    try {
      const handler = this.handlers.get(method);
      if (!handler) {
        return {
          id,
          error: { code: -32601, message: 'Method not found' }
        };
      }

      const result = await handler(params);
      return { id, result };
    } catch (error) {
      return {
        id,
        error: { code: -32000, message: error.message }
      };
    }
  }

  /**
   * Get current orchestrator status
   */
  async getStatus(params) {
    return {
      status: 'ready',
      modules_loaded: this.orchestrator.fileRouter?.modules?.size || 0,
      capabilities: [
        'check',
        'fix',
        'dependency_validation',
        'recipe_application'
      ]
    };
  }

  /**
   * Receive fix suggestion from external system (e.g., LLM)
   */
  async suggestFix(params) {
    // {
    //   file: 'script.sh',
    //   issue_code: 'SC2086',
    //   suggestion: 'Add quotes around variable',
    //   confidence: 0.95
    // }

    // Log suggestion
    // Apply if confidence > threshold
    // Return result

    return {
      accepted: params.confidence > 0.9,
      applied: false,
      reason: 'Suggestion logged for review'
    };
  }

  /**
   * Apply a recipe
   */
  async applyRecipe(params) {
    // { recipe: 'readme-template', inputs: { project_name: 'foo' } }

    const recipe = await this.orchestrator.recipeRegistry.get(params.recipe);
    const result = await recipe.execute(params.inputs);

    return result;
  }

  /**
   * Validate dependencies
   */
  async validateDependencies(params) {
    // { files: ['package.json'] }

    const violations = await this.orchestrator.dependencyGraph.validate(
      params.files
    );

    return { violations };
  }

  /**
   * Get module information
   */
  async getModuleInfo(params) {
    // { module: 'shell' }

    const module = this.orchestrator.fileRouter.modules.get(params.module);
    return module ? module.getInfo() : null;
  }
}
```

### API Usage Examples

**1. LLM asks for status:**

```json
{
  "jsonrpc": "2.0",
  "method": "get_status",
  "params": {},
  "id": 1
}

// Response:
{
  "jsonrpc": "2.0",
  "id": 1,
  "result": {
    "status": "ready",
    "modules_loaded": 8,
    "capabilities": ["check", "fix", "dependency_validation", "recipe_application"]
  }
}
```

**2. LLM suggests a fix:**

```json
{
  "jsonrpc": "2.0",
  "method": "suggest_fix",
  "params": {
    "file": "script.sh",
    "line": 45,
    "issue_code": "SC2086",
    "suggestion": "Change $var to \"$var\"",
    "confidence": 0.98,
    "rationale": "Variable contains spaces based on context analysis"
  },
  "id": 2
}
```

**3. Cloudflare Worker applies recipe:**

```json
{
  "jsonrpc": "2.0",
  "method": "apply_recipe",
  "params": {
    "recipe": "readme-template",
    "inputs": {
      "project_name": "My Project",
      "description": "A cool project",
      "author": "Jane Doe"
    }
  },
  "id": 3
}
```

---

## Decision Logging System

### Goals

- **Track all decisions** made by the orchestrator
- **Explain reasoning** behind fix strategies
- **Enable auditing** and debugging
- **Learn from outcomes** (future: ML integration)

### Decision Log Structure

**File:** `.github/scripts/orchestrator/decision-logger.mjs`

```javascript
export class DecisionLogger {
  constructor() {
    this.decisions = [];
    this.logPath = '.orchestrator-logs';
  }

  /**
   * Log a decision
   */
  log(decision) {
    const entry = {
      timestamp: new Date().toISOString(),
      decision_id: this.generateId(),
      ...decision
    };

    this.decisions.push(entry);
    return entry.decision_id;
  }

  /**
   * Log module selection decision
   */
  logModuleSelection(file, selectedModule, reason) {
    return this.log({
      type: 'module_selection',
      file,
      selected_module: selectedModule.name,
      reason,
      available_modules: [...],
      factors: {
        extension_match: true,
        priority: selectedModule.priority,
        enabled: selectedModule.enabled
      }
    });
  }

  /**
   * Log strategy selection decision
   */
  logStrategySelection(module, file, strategy, reason) {
    return this.log({
      type: 'strategy_selection',
      module: module.name,
      file,
      strategy,
      reason,
      factors: {
        attempt_number: 3,
        previous_strategies: ['conservative', 'balanced'],
        issue_count_trend: [10, 8, 7],
        escalation_triggered: true
      }
    });
  }

  /**
   * Log dependency validation decision
   */
  logDependencyValidation(rule, files, violation) {
    return this.log({
      type: 'dependency_validation',
      rule_id: rule.id,
      files_checked: files.length,
      violation_found: !!violation,
      auto_fix_available: rule.auto_fix?.enabled || false,
      decision: violation && rule.auto_fix?.enabled ? 'auto_fix' : 'report',
      reasoning: `Rule ${rule.id} triggered, ${violation ? 'applying auto-fix' : 'no violation'}`
    });
  }

  /**
   * Log recipe application decision
   */
  logRecipeApplication(recipe, inputs, outcome) {
    return this.log({
      type: 'recipe_application',
      recipe_name: recipe.name,
      inputs,
      outcome,
      reasoning: `Applied recipe to fix dependency violation`
    });
  }

  /**
   * Generate summary report
   */
  generateSummary() {
    const summary = {
      total_decisions: this.decisions.length,
      by_type: {},
      timeline: []
    };

    for (const decision of this.decisions) {
      summary.by_type[decision.type] = (summary.by_type[decision.type] || 0) + 1;
    }

    return summary;
  }

  /**
   * Save decisions to file
   */
  async save() {
    const fs = await import('node:fs/promises');
    const path = await import('node:path');

    const timestamp = new Date().toISOString().replace(/:/g, '-');
    const filename = path.join(this.logPath, `decisions-${timestamp}.json`);

    await fs.mkdir(this.logPath, { recursive: true });
    await fs.writeFile(
      filename,
      JSON.stringify(
        {
          run_timestamp: new Date().toISOString(),
          decisions: this.decisions,
          summary: this.generateSummary()
        },
        null,
        2
      )
    );

    return filename;
  }
}
```

### Decision Log Example

```json
{
  "run_timestamp": "2025-11-14T10:30:00Z",
  "decisions": [
    {
      "timestamp": "2025-11-14T10:30:01Z",
      "decision_id": "dec_abc123",
      "type": "module_selection",
      "file": "script.sh",
      "selected_module": "shell",
      "reason": "Extension .sh matches shell module",
      "factors": {
        "extension_match": true,
        "priority": 10,
        "enabled": true
      }
    },
    {
      "timestamp": "2025-11-14T10:30:05Z",
      "decision_id": "dec_def456",
      "type": "strategy_selection",
      "module": "shell",
      "file": "script.sh",
      "strategy": "aggressive",
      "reason": "Escalated to aggressive after 2 failed attempts",
      "factors": {
        "attempt_number": 3,
        "previous_strategies": ["conservative", "balanced"],
        "issue_count_trend": [10, 8, 7],
        "escalation_triggered": true
      }
    },
    {
      "timestamp": "2025-11-14T10:30:10Z",
      "decision_id": "dec_ghi789",
      "type": "dependency_validation",
      "rule_id": "package-lock-required",
      "files_checked": 15,
      "violation_found": true,
      "auto_fix_available": true,
      "decision": "auto_fix",
      "reasoning": "Rule package-lock-required triggered, applying auto-fix"
    }
  ],
  "summary": {
    "total_decisions": 3,
    "by_type": {
      "module_selection": 1,
      "strategy_selection": 1,
      "dependency_validation": 1
    }
  }
}
```

---

## Implementation Roadmap

### Phase 1: Foundation (Week 1-2)

**Goal:** Extend architecture to support new module types and contextual validation

#### Sprint 1.1: Module Type System (2 days)
- [ ] Create `module-types.mjs` with TypedBaseModule
- [ ] Add capability flags system
- [ ] Update existing modules to use new base class
- [ ] Write tests for type system

#### Sprint 1.2: Context Provider System (2 days)
- [ ] Create `context-provider.mjs`
- [ ] Implement basic context providers
- [ ] Integrate with orchestrator
- [ ] Write tests for context system

#### Sprint 1.3: Dependency Graph (3 days)
- [ ] Create `dependency-graph.mjs`
- [ ] Implement rule evaluation engine
- [ ] Create `orchestrator-dependencies.yml` config schema
- [ ] Write comprehensive tests
- [ ] Add basic rules (package.json → package-lock.json)

#### Sprint 1.4: Auto-Repair Engine (3 days)
- [ ] Create `auto-repair-engine.mjs`
- [ ] Implement command execution
- [ ] Implement file creation from templates
- [ ] Integrate with dependency graph
- [ ] Write tests for all repair actions

**Deliverable:** Enhanced orchestrator with contextual validation and auto-repair

---

### Phase 2: Tier 1 Modules (Week 3-4)

**Goal:** Implement high-value, low-complexity modules

#### Sprint 2.1: Markdown Module (2 days)
- [ ] Create `markdown-module.mjs`
- [ ] Integrate markdownlint-cli
- [ ] Add prettier formatting
- [ ] Write comprehensive tests
- [ ] Add to `orchestrator-modules.yml`

#### Sprint 2.2: JSON Module (1 day)
- [ ] Create `json-module.mjs`
- [ ] Integrate jsonlint/jq
- [ ] Add schema validation support
- [ ] Write tests
- [ ] Add configuration

#### Sprint 2.3: CSS Module (2 days)
- [ ] Create `css-module.mjs`
- [ ] Integrate stylelint
- [ ] Add prettier formatting
- [ ] Write tests
- [ ] Add configuration

#### Sprint 2.4: XML Module (2 days)
- [ ] Create `xml-module.mjs`
- [ ] Integrate xmllint
- [ ] Add schema validation (XSD)
- [ ] Write tests
- [ ] Add configuration

#### Sprint 2.5: Enable Python Module (1 day)
- [ ] Implement `python-module.mjs` (was stub)
- [ ] Integrate pylint, black, mypy
- [ ] Write tests
- [ ] Enable in configuration

**Deliverable:** 5 new working modules

---

### Phase 3: Recipe System (Week 5)

#### Sprint 3.1: Recipe Registry (2 days)
- [ ] Create `recipe-registry.mjs`
- [ ] Implement Recipe class
- [ ] Add template rendering
- [ ] Write tests

#### Sprint 3.2: Recipe Configuration (1 day)
- [ ] Create `orchestrator-recipes.yml`
- [ ] Define standard recipes
  - readme-template
  - typescript-setup
  - obsidian-templates
  - gitignore-template
- [ ] Document recipe format

#### Sprint 3.3: Recipe Actions (2 days)
- [ ] Implement create_file action
- [ ] Implement modify_file action
- [ ] Implement run_command action
- [ ] Write integration tests

**Deliverable:** Working recipe system with 5+ recipes

---

### Phase 4: External API (Week 6)

#### Sprint 4.1: API Server (2 days)
- [ ] Create `api-server.mjs`
- [ ] Implement JSON-RPC handler
- [ ] Add authentication/authorization
- [ ] Write tests

#### Sprint 4.2: API Methods (2 days)
- [ ] Implement get_status
- [ ] Implement suggest_fix
- [ ] Implement apply_recipe
- [ ] Implement validate_dependencies
- [ ] Write integration tests

#### Sprint 4.3: API Client Example (1 day)
- [ ] Create example LLM client
- [ ] Create example Cloudflare Worker
- [ ] Document API usage
- [ ] Write end-to-end test

**Deliverable:** Working external API with examples

---

### Phase 5: Decision Logging (Week 7)

#### Sprint 5.1: Decision Logger (2 days)
- [ ] Create `decision-logger.mjs`
- [ ] Implement decision types
- [ ] Add file persistence
- [ ] Write tests

#### Sprint 5.2: Integration (2 days)
- [ ] Integrate logger into orchestrator
- [ ] Add logging to all decision points
- [ ] Create decision summary reports
- [ ] Write integration tests

#### Sprint 5.3: Visualization (1 day)
- [ ] Create decision log viewer (CLI)
- [ ] Generate markdown reports
- [ ] Add to GitHub step summary

**Deliverable:** Complete decision logging system

---

### Phase 6: Tier 2 Modules (Week 8-9)

#### Sprint 6.1: Mermaid Module (3 days)
- [ ] Create `mermaid-module.mjs`
- [ ] Integrate mermaid-cli
- [ ] Add syntax validation
- [ ] Add rendering test
- [ ] Write tests

#### Sprint 6.2: Obsidian Module (3 days)
- [ ] Create `obsidian-module.mjs`
- [ ] Implement vault scanning
- [ ] Add link validation
- [ ] Add broken link detection
- [ ] Write tests

#### Sprint 6.3: Enable C++ Module (3 days)
- [ ] Implement `cpp-module.mjs` (was stub)
- [ ] Integrate clang-tidy
- [ ] Integrate clang-format
- [ ] Add PlatformIO support
- [ ] Write tests

#### Sprint 6.4: IPv4 Module (1 day)
- [ ] Create `ipv4-module.mjs`
- [ ] Add address validation
- [ ] Add CIDR validation
- [ ] Add subnet calculations
- [ ] Write tests

**Deliverable:** 4 new modules

---

### Phase 7: Tier 3 Modules (Week 10-12)

#### Sprint 7.1: n8n Module (4 days)
- [ ] Create `n8n-module.mjs`
- [ ] Parse workflow JSON
- [ ] Validate node connections
- [ ] Check credential references
- [ ] Write tests

#### Sprint 7.2: Bluetooth/BLE Module (3 days)
- [ ] Create `bluetooth-module.mjs`
- [ ] Validate UUIDs (16-bit, 128-bit)
- [ ] Validate GATT profiles
- [ ] Check service/characteristic structure
- [ ] Write tests

#### Sprint 7.3: MIDI Module (2 days)
- [ ] Create `midi-module.mjs`
- [ ] Validate MIDI messages
- [ ] Check channel/note ranges
- [ ] Write tests

#### Sprint 7.4: Serial/USB Module (3 days)
- [ ] Create `serial-module.mjs`
- [ ] Create `usb-module.mjs`
- [ ] Validate configuration (baud, parity, etc.)
- [ ] Validate USB descriptors
- [ ] Write tests

**Deliverable:** 5 specialized modules

---

## Testing Strategy

### Test-Driven Development Approach

**Every feature follows this pattern:**

```
1. Write failing test
2. Implement minimum code to pass
3. Refactor
4. Add edge case tests
5. Commit
```

### Test Categories

#### 1. Unit Tests

**Example:** `tests/orchestrator/dependency-graph.test.mjs`

```javascript
import { describe, it } from 'node:test';
import assert from 'node:assert';
import { DependencyGraph } from '../../../.github/scripts/orchestrator/dependency-graph.mjs';

describe('DependencyGraph', () => {
  describe('addRule', () => {
    it('should add a rule to the graph', () => {
      const graph = new DependencyGraph();
      const rule = {
        id: 'test-rule',
        condition: { file_exists: 'foo.txt' },
        requires: [{ file_exists: 'bar.txt' }]
      };

      graph.addRule(rule);
      assert.strictEqual(graph.rules.length, 1);
    });
  });

  describe('validate', () => {
    it('should detect missing dependencies', async () => {
      const graph = new DependencyGraph();
      graph.addRule({
        id: 'package-lock-required',
        condition: { file_exists: 'package.json' },
        requires: [{ file_exists: 'package-lock.json' }]
      });

      const files = ['package.json']; // Missing package-lock.json
      const violations = await graph.validate(files);

      assert.strictEqual(violations.length, 1);
      assert.strictEqual(violations[0].rule, 'package-lock-required');
    });

    it('should pass when dependencies exist', async () => {
      const graph = new DependencyGraph();
      graph.addRule({
        id: 'package-lock-required',
        condition: { file_exists: 'package.json' },
        requires: [{ file_exists: 'package-lock.json' }]
      });

      const files = ['package.json', 'package-lock.json'];
      const violations = await graph.validate(files);

      assert.strictEqual(violations.length, 0);
    });
  });
});
```

#### 2. Integration Tests

**Example:** `tests/orchestrator/integration/auto-repair.test.mjs`

```javascript
describe('Auto-Repair Integration', () => {
  it('should auto-create missing package-lock.json', async () => {
    // Setup: Create temp directory with package.json
    // Run: orchestrator with dependency validation
    // Assert: package-lock.json is created
    // Assert: dependency violation is resolved
  });
});
```

#### 3. End-to-End Tests

**Example:** `tests/orchestrator/e2e/full-flow.test.mjs`

```javascript
describe('Full Orchestrator Flow', () => {
  it('should validate dependencies, repair, and check modules', async () => {
    // Create test repository with:
    // - package.json (missing package-lock.json)
    // - script.sh (with shellcheck issues)
    // - README.md (with markdownlint issues)

    // Run orchestrator
    const result = await orchestrator.run(context);

    // Assert: All dependencies resolved
    // Assert: All files fixed
    // Assert: Decision log created
  });
});
```

### Test Fixtures

```
tests/fixtures/orchestrator/
├── markdown/
│   ├── bad/
│   │   ├── no-heading.md
│   │   ├── trailing-spaces.md
│   │   └── broken-links.md
│   └── good/
│       └── proper.md
├── json/
│   ├── bad/
│   │   ├── syntax-error.json
│   │   ├── invalid-schema.json
│   │   └── duplicate-keys.json
│   └── good/
│       └── valid.json
├── dependencies/
│   ├── missing-lock/
│   │   └── package.json
│   ├── missing-tsconfig/
│   │   └── src/index.ts
│   └── valid/
│       ├── package.json
│       └── package-lock.json
└── recipes/
    └── test-templates/
```

### Continuous Integration

**GitHub Actions workflow:** `.github/workflows/orchestrator-v2-test.yml`

```yaml
name: Orchestrator V2 Tests

on: [push, pull_request]

jobs:
  test:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v4

      - uses: actions/setup-node@v4
        with:
          node-version: 20

      - name: Install dependencies
        run: npm ci

      - name: Run unit tests
        run: npm run test:orchestrator

      - name: Run integration tests
        run: npm run test:orchestrator:integration

      - name: Check coverage
        run: npm run test:orchestrator:coverage

      - name: Upload coverage
        uses: codecov/codecov-action@v3
```

---

## BMAD Metrics

### Build

**Metrics to track during implementation:**

- Lines of code added per sprint
- Test coverage percentage
- Number of modules implemented
- Number of recipes created

### Measure

**Performance metrics:**

- Execution time per module
- Memory usage
- API response time
- Decision log size

**Quality metrics:**

- Test pass rate
- Code coverage
- Bug count
- False positive rate (incorrect fixes)

### Analyze

**Questions to answer:**

- Which modules provide most value?
- Which modules have highest failure rate?
- What are common dependency violations?
- Which recipes are most used?
- What is average fix success rate?

### Decide

**Decision points:**

- Prioritize module development based on usage
- Adjust fix strategies based on success rates
- Refine dependency rules based on violations
- Create new recipes based on patterns
- Optimize slow modules

---

## Compounding Engineering Principles

### 1. Layered Value Creation

```
Layer 1: Base modules (shell, JS, YAML)
└─> Enable basic checking/fixing

Layer 2: Enhanced modules (markdown, JSON, CSS)
└─> Reuse base infrastructure
└─> Build on existing patterns

Layer 3: Domain modules (Obsidian, n8n)
└─> Reuse module system
└─> Add context providers
└─> Compound value with cross-file analysis

Layer 4: Contextual validation
└─> Works across all modules
└─> Multiplies effectiveness

Layer 5: Recipe system
└─> Codifies best practices from all modules
└─> Creates reusable patterns

Layer 6: External API
└─> Enables external intelligence (LLMs)
└─> Exponential value through automation
```

### 2. Knowledge Capture

- Every bug fix → Test case
- Every manual pattern → Recipe
- Every decision → Logged and analyzable
- Every module → Template for next module

### 3. Feedback Loops

```
Short loop (minutes):
  Fix attempt → Result → Adjust strategy

Medium loop (hours):
  Module run → Metrics → Optimize module

Long loop (days/weeks):
  Usage patterns → New recipes → Better defaults
```

---

## Success Criteria

### Phase 1 (Foundation)
- [ ] Dependency graph validates 10+ rules
- [ ] Auto-repair fixes 80%+ of violations
- [ ] All tests pass with >85% coverage
- [ ] Decision log captures all major decisions

### Phase 2 (Tier 1 Modules)
- [ ] 5 new modules working
- [ ] All modules have >80% fix success rate
- [ ] Integration tests cover all modules
- [ ] Documentation complete

### Phase 3 (Recipe System)
- [ ] 10+ recipes available
- [ ] Recipes fix 90%+ of common patterns
- [ ] Recipe registry loads from YAML
- [ ] LLMs can create new recipes via API

### Phase 4 (External API)
- [ ] API handles 100+ requests/second
- [ ] LLM integration working
- [ ] Cloudflare Worker example functional
- [ ] API documentation complete

### Phase 5 (Decision Logging)
- [ ] All decisions logged
- [ ] Log analysis provides actionable insights
- [ ] Logs enable debugging of all failures
- [ ] Visualization tools available

### Overall Success
- [ ] 15+ modules operational
- [ ] 95%+ of common issues auto-fixed
- [ ] External systems can orchestrate the orchestrator
- [ ] System is self-improving through decision logs
- [ ] Documentation enables easy extension

---

## Next Steps

1. **Review this plan** with stakeholders
2. **Prioritize modules** based on project needs
3. **Start Phase 1, Sprint 1.1** (Module Type System)
4. **Set up BMAD tracking** (create metrics dashboard)
5. **Create first PR** with module type system

---

**END OF PLANNING DOCUMENT**
