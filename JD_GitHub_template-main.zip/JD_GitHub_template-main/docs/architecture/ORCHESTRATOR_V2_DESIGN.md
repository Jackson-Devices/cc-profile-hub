# Orchestrator V2: Intelligent Multi-Pass Checker/Fixer System

## Design Document

**Version:** 2.0
**Status:** Design Phase
**Author:** Claude (via GitHub Issue Request)
**Date:** 2025-11-14

---

## Table of Contents

1. [Executive Summary](#executive-summary)
2. [Current State Analysis](#current-state-analysis)
3. [Design Goals](#design-goals)
4. [Architecture Overview](#architecture-overview)
5. [Core Components](#core-components)
6. [File Type Router](#file-type-router)
7. [Multi-Pass Fix Engine](#multi-pass-fix-engine)
8. [Module System](#module-system)
9. [Implementation Phases](#implementation-phases)
10. [Testing Strategy](#testing-strategy)
11. [Future Extensibility](#future-extensibility)

---

## Executive Summary

This design document outlines Orchestrator V2: an intelligent, multi-pass checker/fixer system that:

- **Automatically selects** the right tools based on file type
- **Retries intelligently** with multiple passes until problems are fixed
- **Provides modular architecture** for easy extension (C++, LSP, platformio, etc.)
- **Only fails** when truly unable to fix after exhaustive attempts
- **Prioritizes robustness** over speed (user preference)

**Key Principle:** "Keep trying different strategies until it works, only error if truly stuck"

---

## Current State Analysis

### What We Have

```
┌─────────────────────────────────────────────────────────┐
│ CURRENT: Linear Phase Execution                         │
├─────────────────────────────────────────────────────────┤
│ pre_checks → linting → formatting → validation →        │
│ maintenance → post_checks                                │
│                                                          │
│ - Each phase runs once                                  │
│ - No retry on failure                                   │
│ - No file-type awareness                                │
│ - Manual tool selection in config                       │
└─────────────────────────────────────────────────────────┘
```

### Existing Patterns (Informal)

**Checkers** (20+ workflows):
- `format-check.yml`, `lint-check.yml`, `eslint-check.yml`
- `workflow-lint-gate.yml`, `format-gate.yml`, `eslint-gate.yml`
- `docs-drift-gate.yml`, `pr-risk-gate.yml`

**Fixers** (4 workflows):
- `format-apply.yml` (Prettier)
- `eslint-apply.yml` (ESLint --fix)
- `workflow-lint-apply.yml` (shellcheck)
- `workflow-yaml-format-apply.yml` (YAML prettier)

**Scripts**:
- `.github/scripts/shellcheck-apply.sh` (3 strategies: conservative, balanced, aggressive)
- `.github/scripts/validation/check-dependencies.mjs`
- `.github/scripts/validation/check-permissions.mjs`

### Gaps

1. **No formalized module system** - checkers/fixers not pluggable
2. **No retry logic** - one pass and done
3. **No file-type routing** - runs all tools regardless of relevance
4. **No strategy escalation** - can't try conservative then aggressive
5. **No dependency tracking** - can't handle "fix A requires fix B first"
6. **Limited error recovery** - generic failures

---

## Design Goals

### Primary Goals

1. **Intelligent Tool Selection**
   - Route files to appropriate checkers/fixers based on extension
   - Don't run shell linters on JavaScript, etc.
   - Support multi-language projects

2. **Multi-Pass Fix Loop**
   - Check → Fix → Check → Fix until clean or max attempts
   - Escalate fix strategies (conservative → balanced → aggressive)
   - Track what was tried to avoid infinite loops

3. **Modular Architecture**
   - Easy to add new languages (C++, Python, Rust, etc.)
   - Easy to add new tools (LSP servers, language-specific linters)
   - Pluggable checker/fixer modules

4. **Robust Error Handling**
   - Only fail when truly unable to fix
   - Provide detailed diagnostics on what was tried
   - Suggest manual intervention steps

5. **Future-Proof**
   - Architecture supports MCU tooling integration
   - Architecture supports LSP protocol integration
   - Architecture supports platformio integration
   - Architecture supports conflict resolution (Phase 2)
   - Architecture supports ML prediction (Phase 3)

### Non-Goals (For Now)

- ML-powered fix prediction (Phase 3 future work)
- Visual UI for orchestration (CLI/GitHub Actions only)
- Real-time streaming output (batch processing is fine)

---

## Architecture Overview

```
┌────────────────────────────────────────────────────────────────────────┐
│                     ORCHESTRATOR V2 ARCHITECTURE                        │
└────────────────────────────────────────────────────────────────────────┘

┌─────────────────────────────────────────────────────────────────────────┐
│  1. FILE DISCOVERY & CLASSIFICATION                                     │
│     - Scan changed files (git diff, PR files, etc.)                    │
│     - Classify by extension (.sh, .js, .yml, .cpp, etc.)              │
│     - Group by file type for batch processing                          │
└──────────────────────────┬──────────────────────────────────────────────┘
                           │
                           ▼
┌─────────────────────────────────────────────────────────────────────────┐
│  2. FILE TYPE ROUTER                                                    │
│     ┌──────────────┬──────────────┬──────────────┬─────────────────┐   │
│     │ Shell Files  │ JS/TS Files  │ YAML Files   │ Future: C++     │   │
│     │ (.sh, .bash) │ (.js, .mjs)  │ (.yml, .yaml)│ (.cpp, .h)      │   │
│     └──────┬───────┴──────┬───────┴──────┬───────┴─────┬───────────┘   │
│            │              │              │             │               │
│            ▼              ▼              ▼             ▼               │
│     ┌────────────┐ ┌────────────┐ ┌────────────┐ ┌──────────────┐     │
│     │ Shell      │ │ JS         │ │ YAML       │ │ C++ Module   │     │
│     │ Module     │ │ Module     │ │ Module     │ │ (Future)     │     │
│     └────────────┘ └────────────┘ └────────────┘ └──────────────┘     │
└──────────────────────────┬──────────────────────────────────────────────┘
                           │
                           ▼
┌─────────────────────────────────────────────────────────────────────────┐
│  3. MULTI-PASS FIX ENGINE (Per Module)                                  │
│                                                                          │
│     Pass 1: Check → (issues?) → Fix (strategy: conservative)            │
│         ↓                                                                │
│     Pass 2: Check → (issues?) → Fix (strategy: balanced)                │
│         ↓                                                                │
│     Pass 3: Check → (issues?) → Fix (strategy: aggressive)              │
│         ↓                                                                │
│     Pass N: Check → (issues?) → FAIL (report what was tried)            │
│         ↓                                                                │
│     ✓ Success → Next file group                                         │
│                                                                          │
│  Max attempts: Configurable (default: 5)                                │
│  Timeout per pass: Configurable (default: 60s)                          │
└──────────────────────────┬──────────────────────────────────────────────┘
                           │
                           ▼
┌─────────────────────────────────────────────────────────────────────────┐
│  4. RESULT AGGREGATION & REPORTING                                      │
│     - Collect results from all modules                                  │
│     - Generate summary (files fixed, files failed, strategies used)     │
│     - Create GitHub step summary with details                           │
│     - Only set failed if any file truly unfixable                       │
└─────────────────────────────────────────────────────────────────────────┘
```

---

## Core Components

### 1. File Discovery Service

**Location:** `.github/scripts/orchestrator/file-discovery.mjs`

**Responsibilities:**
- Detect changed files (git diff, PR API, manual list)
- Classify files by type
- Filter by include/exclude patterns
- Return grouped file lists

**API:**
```javascript
class FileDiscovery {
  async getChangedFiles(context) {
    // Returns: { event: 'push', files: ['file1.sh', 'file2.js'] }
  }

  classifyFiles(files) {
    // Returns: {
    //   shell: ['file1.sh', 'file2.bash'],
    //   javascript: ['file3.js', 'file4.mjs'],
    //   yaml: ['file5.yml'],
    //   unknown: ['file6.xyz']
    // }
  }
}
```

**Tests:**
- `tests/orchestrator/file-discovery.test.mjs`
- Test git diff parsing
- Test PR file list parsing
- Test classification logic
- Test include/exclude patterns

---

### 2. File Type Router

**Location:** `.github/scripts/orchestrator/file-router.mjs`

**Responsibilities:**
- Map file types to appropriate modules
- Handle unknown file types gracefully
- Support custom routing rules

**Configuration:**
```yaml
# .github/orchestrator-modules.yml
modules:
  shell:
    extensions: ['.sh', '.bash', '.zsh']
    checker: 'shell-checker'
    fixer: 'shell-fixer'
    enabled: true

  javascript:
    extensions: ['.js', '.mjs', '.cjs', '.ts', '.tsx']
    checker: 'eslint-checker'
    fixer: 'eslint-fixer'
    enabled: true

  yaml:
    extensions: ['.yml', '.yaml']
    checker: 'yaml-checker'
    fixer: 'yaml-fixer'
    enabled: true

  cpp:
    extensions: ['.cpp', '.h', '.hpp', '.c']
    checker: 'clang-tidy-checker'
    fixer: 'clang-format-fixer'
    enabled: false  # Future

  python:
    extensions: ['.py']
    checker: 'pylint-checker'
    fixer: 'black-fixer'
    enabled: false  # Future
```

**API:**
```javascript
class FileRouter {
  constructor(config) { /* Load module config */ }

  getModuleForFile(filename) {
    // Returns: { name: 'shell', checker: 'shell-checker', fixer: 'shell-fixer' }
  }

  routeFiles(classifiedFiles) {
    // Returns: Map<Module, File[]>
  }
}
```

**Tests:**
- `tests/orchestrator/file-router.test.mjs`
- Test extension mapping
- Test unknown file handling
- Test module enable/disable
- Test custom routing rules

---

### 3. Checker/Fixer Module Interface

**Location:** `.github/scripts/orchestrator/modules/base-module.mjs`

**Base Class (All modules inherit):**
```javascript
class BaseModule {
  constructor(name, config) {
    this.name = name;
    this.config = config;
  }

  // MUST IMPLEMENT: Run checker on files
  async check(files, options = {}) {
    throw new Error('check() must be implemented');
    // Returns: {
    //   success: boolean,
    //   issues: [{ file, line, code, severity, message }],
    //   metadata: { tool_version, duration_ms }
    // }
  }

  // MUST IMPLEMENT: Run fixer on files
  async fix(files, strategy = 'balanced', options = {}) {
    throw new Error('fix() must be implemented');
    // Returns: {
    //   success: boolean,
    //   files_modified: string[],
    //   fixes_applied: number,
    //   metadata: { strategy, duration_ms }
    // }
  }

  // OPTIONAL: Validate module is ready
  async validate() {
    return { ready: true };
  }

  // OPTIONAL: Get supported strategies
  getSupportedStrategies() {
    return ['conservative', 'balanced', 'aggressive'];
  }
}
```

**Module Implementations:**

#### Shell Module
```javascript
// .github/scripts/orchestrator/modules/shell-module.mjs
class ShellModule extends BaseModule {
  async check(files) {
    // Run shellcheck on files
    // Parse JSON output
    // Return structured issues
  }

  async fix(files, strategy) {
    // Use existing shellcheck-apply.sh
    // Pass strategy flag
    // Return modified file list
  }

  getSupportedStrategies() {
    return ['conservative', 'balanced', 'aggressive'];
  }
}
```

#### JavaScript Module
```javascript
// .github/scripts/orchestrator/modules/javascript-module.mjs
class JavaScriptModule extends BaseModule {
  async check(files) {
    // Run ESLint
    // Return issues
  }

  async fix(files, strategy) {
    // Run ESLint --fix
    // Strategy affects ESLint rules (maybe)
    // Return results
  }
}
```

#### YAML Module
```javascript
// .github/scripts/orchestrator/modules/yaml-module.mjs
class YAMLModule extends BaseModule {
  async check(files) {
    // Run yamllint or prettier --check
    // Return issues
  }

  async fix(files) {
    // Run prettier --write
    // Return results
  }

  getSupportedStrategies() {
    return ['default'];  // No strategy variations for YAML
  }
}
```

**Tests (per module):**
- `tests/orchestrator/modules/shell-module.test.mjs`
- `tests/orchestrator/modules/javascript-module.test.mjs`
- `tests/orchestrator/modules/yaml-module.test.mjs`
- Test check() returns valid structure
- Test fix() modifies files correctly
- Test strategy handling
- Test error scenarios

---

### 4. Multi-Pass Fix Engine

**Location:** `.github/scripts/orchestrator/fix-engine.mjs`

**Responsibilities:**
- Execute check → fix → check loop
- Track attempts and strategies tried
- Escalate strategies on repeated failure
- Determine when to give up
- Provide detailed failure diagnostics

**Algorithm:**
```javascript
class MultiPassFixEngine {
  async fixWithRetries(module, files, options = {}) {
    const {
      maxAttempts = 5,
      strategies = module.getSupportedStrategies(),
      timeout = 60000,
    } = options;

    const attemptLog = [];
    let currentFiles = files;

    for (let attempt = 1; attempt <= maxAttempts; attempt++) {
      // 1. Check current state
      const checkResult = await this.runWithTimeout(
        () => module.check(currentFiles),
        timeout
      );

      attemptLog.push({
        attempt,
        phase: 'check',
        result: checkResult,
      });

      // 2. If no issues, SUCCESS
      if (checkResult.success && checkResult.issues.length === 0) {
        return {
          success: true,
          attempts: attempt,
          log: attemptLog,
        };
      }

      // 3. If last attempt, FAIL
      if (attempt === maxAttempts) {
        return {
          success: false,
          attempts: attempt,
          log: attemptLog,
          remainingIssues: checkResult.issues,
          message: `Failed after ${maxAttempts} attempts`,
        };
      }

      // 4. Apply fix with escalating strategy
      const strategy = this.selectStrategy(attempt, strategies);
      const fixResult = await this.runWithTimeout(
        () => module.fix(currentFiles, strategy),
        timeout
      );

      attemptLog.push({
        attempt,
        phase: 'fix',
        strategy,
        result: fixResult,
      });

      // 5. If fix failed, try next strategy
      if (!fixResult.success) {
        continue;
      }

      // 6. Update file list with modifications
      currentFiles = fixResult.files_modified || currentFiles;
    }

    // Should never reach here
    return {
      success: false,
      attempts: maxAttempts,
      log: attemptLog,
    };
  }

  selectStrategy(attempt, strategies) {
    // Escalate strategy based on attempt number
    // attempt 1-2: conservative
    // attempt 3-4: balanced
    // attempt 5+: aggressive
    if (attempt <= 2) return strategies[0] || 'conservative';
    if (attempt <= 4) return strategies[1] || 'balanced';
    return strategies[2] || 'aggressive';
  }

  async runWithTimeout(fn, timeout) {
    // Execute with timeout, throw on timeout
  }
}
```

**Tests:**
- `tests/orchestrator/fix-engine.test.mjs`
- Test successful fix on first attempt
- Test successful fix after multiple attempts
- Test strategy escalation
- Test max attempts reached
- Test timeout handling
- Test partial fixes (some files succeed, some fail)

---

### 5. Orchestrator Main Controller

**Location:** `.github/scripts/orchestrator/orchestrator.mjs`

**Responsibilities:**
- Coordinate all components
- Manage overall workflow
- Generate reports
- Handle errors gracefully

**Flow:**
```javascript
class Orchestrator {
  async run(context, options = {}) {
    // 1. Discover files
    const fileDiscovery = new FileDiscovery();
    const files = await fileDiscovery.getChangedFiles(context);
    const classified = fileDiscovery.classifyFiles(files);

    // 2. Route to modules
    const router = new FileRouter(moduleConfig);
    const routedFiles = router.routeFiles(classified);

    // 3. Process each module's files
    const engine = new MultiPassFixEngine();
    const results = [];

    for (const [module, moduleFiles] of routedFiles) {
      const result = await engine.fixWithRetries(module, moduleFiles, {
        maxAttempts: options.maxAttempts || 5,
        timeout: options.timeout || 60000,
      });

      results.push({
        module: module.name,
        files: moduleFiles,
        ...result,
      });
    }

    // 4. Aggregate and report
    const summary = this.generateSummary(results);
    await this.writeGitHubSummary(summary);

    // 5. Determine overall success
    const allFixed = results.every(r => r.success);

    if (!allFixed) {
      const failures = results.filter(r => !r.success);
      throw new OrchestratorError(
        `Failed to fix all issues. Modules with failures: ${failures.map(f => f.module).join(', ')}`,
        { failures }
      );
    }

    return { success: true, summary };
  }

  generateSummary(results) {
    // Aggregate statistics
    // Format for human readability
    // Include attempt logs for debugging
  }

  async writeGitHubSummary(summary) {
    // Write to GITHUB_STEP_SUMMARY
    // Include markdown tables, emojis, etc.
  }
}
```

**Tests:**
- `tests/orchestrator/orchestrator.test.mjs`
- Test full end-to-end flow with mocked modules
- Test partial failures
- Test all successes
- Test error reporting
- Test summary generation

---

## File Type Router

### Router Configuration Schema

```yaml
# .github/orchestrator-modules.yml

# Module definitions
modules:
  shell:
    name: "Shell Script Module"
    extensions: ['.sh', '.bash', '.zsh', '.ksh']
    patterns: ['*.sh', '**/scripts/*.bash']  # Additional glob patterns
    checker:
      command: 'shellcheck'
      args: ['--format=json', '--severity=warning']
    fixer:
      script: '.github/scripts/shellcheck-apply.sh'
      strategies: ['conservative', 'balanced', 'aggressive']
    enabled: true
    priority: 10  # Higher = process first

  javascript:
    name: "JavaScript/TypeScript Module"
    extensions: ['.js', '.mjs', '.cjs', '.ts', '.tsx', '.jsx']
    checker:
      command: 'eslint'
      args: ['--format=json']
    fixer:
      command: 'eslint'
      args: ['--fix']
      strategies: ['default']
    enabled: true
    priority: 20

  yaml:
    name: "YAML Module"
    extensions: ['.yml', '.yaml']
    checker:
      command: 'prettier'
      args: ['--check']
    fixer:
      command: 'prettier'
      args: ['--write']
    enabled: true
    priority: 5  # Lower priority (formatting is less critical)

  # Future modules (disabled for now)
  cpp:
    name: "C++ Module (MCU Support)"
    extensions: ['.cpp', '.hpp', '.h', '.c', '.cc', '.cxx']
    checker:
      command: 'clang-tidy'
      args: ['--format-style=file']
    fixer:
      command: 'clang-format'
      args: ['-i']
    platformio:
      enabled: false  # Future: platformio integration
      lsp_server: 'clangd'
    enabled: false
    priority: 15

  python:
    name: "Python Module"
    extensions: ['.py', '.pyw']
    checker:
      command: 'pylint'
      args: ['--output-format=json']
    fixer:
      command: 'black'
      args: ['--quiet']
    enabled: false
    priority: 15

# Global routing rules
routing:
  # Files to always exclude
  exclude_patterns:
    - 'node_modules/**'
    - '.git/**'
    - 'dist/**'
    - 'build/**'
    - '*.min.js'

  # Files to always include (even if not changed)
  force_include_patterns:
    - '.github/workflows/*.yml'

  # Unknown file handling
  unknown_files:
    action: 'warn'  # Options: 'ignore', 'warn', 'error'

  # Parallel processing
  parallel:
    enabled: true
    max_concurrent_modules: 3
```

### Router Implementation

```javascript
// .github/scripts/orchestrator/file-router.mjs

import * as fs from 'fs';
import * as path from 'path';
import YAML from 'yaml';
import { minimatch } from 'minimatch';

class FileRouter {
  constructor(configPath = '.github/orchestrator-modules.yml') {
    this.config = this.loadConfig(configPath);
    this.modules = this.initializeModules();
  }

  loadConfig(configPath) {
    const content = fs.readFileSync(configPath, 'utf8');
    return YAML.parse(content);
  }

  initializeModules() {
    const modules = new Map();

    for (const [key, moduleConfig] of Object.entries(this.config.modules)) {
      if (!moduleConfig.enabled) continue;

      // Dynamically load module implementation
      const ModuleClass = this.loadModuleClass(key);
      modules.set(key, new ModuleClass(moduleConfig));
    }

    return modules;
  }

  loadModuleClass(moduleName) {
    // Dynamic import based on module name
    const modulePath = `./modules/${moduleName}-module.mjs`;
    return require(modulePath).default;
  }

  routeFiles(files) {
    const routing = new Map();
    const unrouted = [];

    // Filter excluded files
    const filteredFiles = files.filter(file =>
      !this.isExcluded(file)
    );

    // Route each file to appropriate module
    for (const file of filteredFiles) {
      const module = this.findModuleForFile(file);

      if (module) {
        if (!routing.has(module)) {
          routing.set(module, []);
        }
        routing.get(module).push(file);
      } else {
        unrouted.push(file);
      }
    }

    // Handle unrouted files
    this.handleUnrouted(unrouted);

    return routing;
  }

  findModuleForFile(file) {
    const ext = path.extname(file);
    const basename = path.basename(file);

    // Find matching modules (there may be multiple)
    const matches = [];

    for (const [name, module] of this.modules) {
      const config = this.config.modules[name];

      // Check extension match
      if (config.extensions && config.extensions.includes(ext)) {
        matches.push({ name, module, config });
      }

      // Check pattern match
      if (config.patterns) {
        for (const pattern of config.patterns) {
          if (minimatch(file, pattern)) {
            matches.push({ name, module, config });
            break;
          }
        }
      }
    }

    if (matches.length === 0) {
      return null;
    }

    // If multiple matches, use priority
    matches.sort((a, b) => (b.config.priority || 0) - (a.config.priority || 0));

    return matches[0].module;
  }

  isExcluded(file) {
    const excludePatterns = this.config.routing?.exclude_patterns || [];

    return excludePatterns.some(pattern =>
      minimatch(file, pattern)
    );
  }

  handleUnrouted(files) {
    if (files.length === 0) return;

    const action = this.config.routing?.unknown_files?.action || 'warn';

    switch (action) {
      case 'ignore':
        // Do nothing
        break;
      case 'warn':
        console.warn(`Warning: ${files.length} files could not be routed to any module:`);
        files.forEach(f => console.warn(`  - ${f}`));
        break;
      case 'error':
        throw new Error(`Unknown file types detected: ${files.join(', ')}`);
    }
  }
}

export default FileRouter;
```

---

## Multi-Pass Fix Engine

### Engine Configuration

```yaml
# .github/orchestrator-engine.yml

engine:
  # Maximum attempts per module
  max_attempts: 5

  # Timeout per attempt (ms)
  timeout_per_attempt: 60000

  # Strategy escalation
  strategy_escalation:
    enabled: true
    schedule:
      - attempts: [1, 2]
        strategy: 'conservative'
      - attempts: [3, 4]
        strategy: 'balanced'
      - attempts: [5]
        strategy: 'aggressive'

  # Early termination
  early_termination:
    # Stop if no progress for N attempts
    no_progress_limit: 3

    # Stop if same error repeated N times
    repeated_error_limit: 2

  # Backoff between attempts
  backoff:
    enabled: true
    initial_delay_ms: 1000
    multiplier: 1.5
    max_delay_ms: 10000

  # Reporting
  verbose: true
  save_attempt_logs: true
  log_path: '.orchestrator-logs'
```

### Engine Implementation Details

**Attempt Tracking:**
```javascript
class AttemptTracker {
  constructor() {
    this.attempts = [];
  }

  recordAttempt(phase, result) {
    this.attempts.push({
      number: this.attempts.length + 1,
      phase,  // 'check' or 'fix'
      timestamp: Date.now(),
      result,
    });
  }

  hasProgress() {
    // Compare issue counts across attempts
    const checkAttempts = this.attempts.filter(a => a.phase === 'check');

    if (checkAttempts.length < 2) return true;

    const lastTwo = checkAttempts.slice(-2);
    const prev = lastTwo[0].result.issues?.length || 0;
    const current = lastTwo[1].result.issues?.length || 0;

    return current < prev;  // Progress if issues decreased
  }

  hasSameErrorRepeated(limit) {
    const recent = this.attempts.slice(-limit);

    if (recent.length < limit) return false;

    // Check if all recent attempts have same error
    const firstError = this.getErrorSignature(recent[0]);

    return recent.every(attempt =>
      this.getErrorSignature(attempt) === firstError
    );
  }

  getErrorSignature(attempt) {
    // Create unique signature for error type
    if (attempt.result.issues && attempt.result.issues.length > 0) {
      const firstIssue = attempt.result.issues[0];
      return `${firstIssue.code}:${firstIssue.file}:${firstIssue.line}`;
    }
    return null;
  }
}
```

**Strategy Selector:**
```javascript
class StrategySelector {
  constructor(config) {
    this.config = config;
  }

  selectStrategy(attemptNumber, availableStrategies) {
    if (!this.config.strategy_escalation?.enabled) {
      return availableStrategies[0] || 'default';
    }

    const schedule = this.config.strategy_escalation.schedule;

    for (const { attempts, strategy } of schedule) {
      if (attempts.includes(attemptNumber)) {
        // Check if this strategy is available for this module
        if (availableStrategies.includes(strategy)) {
          return strategy;
        }
      }
    }

    // Fallback to last available strategy
    return availableStrategies[availableStrategies.length - 1];
  }
}
```

**Progress Reporter:**
```javascript
class ProgressReporter {
  constructor(verbose = false) {
    this.verbose = verbose;
  }

  reportAttempt(module, attemptNumber, phase, result) {
    if (!this.verbose) return;

    console.log(`\n[${'module.name'}] Attempt ${attemptNumber} - ${phase}`);

    if (phase === 'check') {
      const issueCount = result.issues?.length || 0;
      console.log(`  Issues found: ${issueCount}`);

      if (issueCount > 0 && issueCount <= 5) {
        result.issues.forEach(issue => {
          console.log(`    - ${issue.file}:${issue.line} [${issue.code}] ${issue.message}`);
        });
      } else if (issueCount > 5) {
        console.log(`    (showing first 5)`);
        result.issues.slice(0, 5).forEach(issue => {
          console.log(`    - ${issue.file}:${issue.line} [${issue.code}] ${issue.message}`);
        });
      }
    } else if (phase === 'fix') {
      console.log(`  Strategy: ${result.strategy || 'default'}`);
      console.log(`  Files modified: ${result.files_modified?.length || 0}`);
      console.log(`  Fixes applied: ${result.fixes_applied || 0}`);
    }
  }

  reportSuccess(module, attempts) {
    console.log(`\n✅ [${module.name}] All issues resolved after ${attempts} attempt(s)`);
  }

  reportFailure(module, attempts, remainingIssues) {
    console.error(`\n❌ [${module.name}] Failed after ${attempts} attempt(s)`);
    console.error(`  Remaining issues: ${remainingIssues?.length || 'unknown'}`);

    if (remainingIssues && remainingIssues.length > 0) {
      console.error(`\n  Unresolved issues:`);
      remainingIssues.forEach(issue => {
        console.error(`    - ${issue.file}:${issue.line} [${issue.code}] ${issue.message}`);
      });
    }
  }
}
```

---

## Module System

### Module Registry

```javascript
// .github/scripts/orchestrator/module-registry.mjs

class ModuleRegistry {
  constructor() {
    this.modules = new Map();
  }

  register(name, moduleClass) {
    this.modules.set(name, moduleClass);
  }

  get(name) {
    return this.modules.get(name);
  }

  list() {
    return Array.from(this.modules.keys());
  }
}

// Singleton instance
const registry = new ModuleRegistry();

export default registry;
```

### Module Loader

```javascript
// .github/scripts/orchestrator/module-loader.mjs

import registry from './module-registry.mjs';

// Auto-register built-in modules
import ShellModule from './modules/shell-module.mjs';
import JavaScriptModule from './modules/javascript-module.mjs';
import YAMLModule from './modules/yaml-module.mjs';

registry.register('shell', ShellModule);
registry.register('javascript', JavaScriptModule);
registry.register('yaml', YAMLModule);

// Function to load custom modules (future)
export async function loadCustomModules(modulePaths) {
  for (const modulePath of modulePaths) {
    const { name, module } = await import(modulePath);
    registry.register(name, module);
  }
}

export { registry };
```

---

## Implementation Phases

### Phase 1: Design & Architecture ✓ (This Document)

**Deliverables:**
- [x] Architecture design document (this file)
- [ ] Review and approval

**Commit:** After approval

---

### Phase 2: Core Infrastructure

**Sub-tasks:**
1. Create base module interface and tests
2. Implement file discovery service and tests
3. Implement file router and tests
4. Create module configuration schema
5. Implement module registry

**Tests Created:**
- `tests/orchestrator/modules/base-module.test.mjs`
- `tests/orchestrator/file-discovery.test.mjs`
- `tests/orchestrator/file-router.test.mjs`
- `tests/orchestrator/module-registry.test.mjs`

**Validation:**
- [ ] All tests pass
- [ ] Local npm test succeeds
- [ ] Code coverage > 80%

**Commit:** "feat: add orchestrator v2 core infrastructure with full test coverage"

---

### Phase 3: Module Implementations

**Sub-tasks:**
1. Implement Shell module (use existing shellcheck-apply.sh)
2. Test Shell module with all strategies
3. Implement JavaScript module (use ESLint)
4. Test JavaScript module
5. Implement YAML module (use Prettier)
6. Test YAML module

**Tests Created:**
- `tests/orchestrator/modules/shell-module.test.mjs`
- `tests/orchestrator/modules/javascript-module.test.mjs`
- `tests/orchestrator/modules/yaml-module.test.mjs`

**Test Fixtures:**
- `tests/fixtures/orchestrator/shell/` (bad scripts, good scripts)
- `tests/fixtures/orchestrator/javascript/` (eslint issues)
- `tests/fixtures/orchestrator/yaml/` (formatting issues)

**Validation:**
- [ ] All module tests pass
- [ ] Manual testing of each module
- [ ] Local npm test succeeds

**Commit:** "feat: implement shell, javascript, and yaml modules with comprehensive tests"

---

### Phase 4: Multi-Pass Fix Engine

**Sub-tasks:**
1. Implement AttemptTracker class and tests
2. Implement StrategySelector class and tests
3. Implement ProgressReporter class and tests
4. Implement MultiPassFixEngine class and tests
5. Create engine configuration schema

**Tests Created:**
- `tests/orchestrator/attempt-tracker.test.mjs`
- `tests/orchestrator/strategy-selector.test.mjs`
- `tests/orchestrator/progress-reporter.test.mjs`
- `tests/orchestrator/fix-engine.test.mjs`

**Test Scenarios:**
- Success on first attempt
- Success after multiple attempts
- Strategy escalation
- Early termination (no progress)
- Early termination (repeated errors)
- Timeout handling
- Max attempts reached

**Validation:**
- [ ] All engine tests pass
- [ ] Test with mocked modules
- [ ] Local npm test succeeds

**Commit:** "feat: implement multi-pass fix engine with intelligent retry logic"

---

### Phase 5: Orchestrator Main Controller

**Sub-tasks:**
1. Implement Orchestrator main class
2. Implement result aggregation
3. Implement GitHub summary generation
4. Create CLI wrapper script
5. End-to-end integration tests

**Tests Created:**
- `tests/orchestrator/orchestrator.test.mjs`
- `tests/orchestrator/integration/e2e.test.mjs`

**Scripts Created:**
- `.github/scripts/orchestrator/orchestrator-cli.mjs` (CLI entry point)

**Validation:**
- [ ] E2E tests pass with real files
- [ ] GitHub summary renders correctly
- [ ] Error reporting is comprehensive
- [ ] Local npm test succeeds

**Commit:** "feat: implement orchestrator main controller with E2E tests"

---

### Phase 6: Workflow Integration

**Sub-tasks:**
1. Create new workflow: `.github/workflows/orchestrator-v2.yml`
2. Update existing workflows to support orchestrator calls
3. Add orchestrator configuration files
4. Test workflow in CI

**Files Created:**
- `.github/workflows/orchestrator-v2.yml`
- `.github/orchestrator-modules.yml`
- `.github/orchestrator-engine.yml`

**Validation:**
- [ ] Workflow runs successfully in CI
- [ ] No race conditions detected
- [ ] Summary output looks good
- [ ] All edge cases handled

**Commit:** "feat: integrate orchestrator v2 into GitHub Actions workflow"

---

### Phase 7: Documentation & Polish

**Sub-tasks:**
1. Write user guide: `docs/ORCHESTRATOR_V2_USER_GUIDE.md`
2. Write developer guide: `docs/ORCHESTRATOR_V2_DEVELOPER_GUIDE.md`
3. Update README with orchestrator info
4. Add troubleshooting guide
5. Add examples

**Validation:**
- [ ] Documentation is clear
- [ ] Examples work
- [ ] All links valid

**Commit:** "docs: add comprehensive orchestrator v2 documentation"

---

### Phase 8: Future Extensions (Stubs)

**Sub-tasks:**
1. Create C++ module stub (disabled)
2. Create Python module stub (disabled)
3. Add LSP integration interface (stub)
4. Add PlatformIO integration interface (stub)

**Files Created:**
- `.github/scripts/orchestrator/modules/cpp-module.mjs` (stub)
- `.github/scripts/orchestrator/modules/python-module.mjs` (stub)
- `.github/scripts/orchestrator/integrations/lsp-client.mjs` (stub)
- `.github/scripts/orchestrator/integrations/platformio.mjs` (stub)

**Validation:**
- [ ] Stubs follow module interface
- [ ] Stubs have placeholder tests
- [ ] Documentation explains future roadmap

**Commit:** "feat: add stubs for future module extensions (C++, Python, LSP, PlatformIO)"

---

## Testing Strategy

### Test Categories

1. **Unit Tests** (per component)
   - BaseModule interface
   - FileDiscovery
   - FileRouter
   - Each module implementation
   - AttemptTracker
   - StrategySelector
   - ProgressReporter
   - MultiPassFixEngine
   - Orchestrator main

2. **Integration Tests**
   - Router + Modules
   - Engine + Modules
   - Full orchestrator flow (mocked I/O)

3. **End-to-End Tests**
   - Real files with real issues
   - Multi-pass scenarios
   - All modules together

4. **Regression Tests**
   - Ensure existing workflows still work
   - No breaking changes to current system

### Test Infrastructure

**Test Helpers:**
```javascript
// tests/helpers/orchestrator-test-utils.mjs

export class MockModule extends BaseModule {
  constructor(config = {}) {
    super('mock', config);
    this.checkResults = [];
    this.fixResults = [];
  }

  setCheckResults(results) {
    this.checkResults = results;
  }

  setFixResults(results) {
    this.fixResults = results;
  }

  async check() {
    return this.checkResults.shift() || { success: true, issues: [] };
  }

  async fix() {
    return this.fixResults.shift() || { success: true, files_modified: [] };
  }
}

export function createTestFile(path, content) {
  // Create temp file for testing
}

export function cleanupTestFiles(files) {
  // Remove temp files
}
```

**Fixtures:**
```
tests/fixtures/orchestrator/
├── shell/
│   ├── bad/
│   │   ├── unquoted-vars.sh          # SC2086
│   │   ├── cd-without-check.sh       # SC2164
│   │   └── backticks.sh              # SC2006
│   └── good/
│       └── proper-script.sh
├── javascript/
│   ├── bad/
│   │   ├── unused-var.js
│   │   └── no-semicolon.mjs
│   └── good/
│       └── clean-code.js
└── yaml/
    ├── bad/
    │   ├── improper-indent.yml
    │   └── unquoted-strings.yaml
    └── good/
        └── proper-config.yml
```

### Test Execution

```bash
# Run all orchestrator tests
npm run test:orchestrator

# Run specific test suite
npm run test:orchestrator:modules
npm run test:orchestrator:engine
npm run test:orchestrator:integration

# Run with coverage
npm run test:orchestrator:coverage
```

**package.json additions:**
```json
{
  "scripts": {
    "test:orchestrator": "node --test tests/orchestrator/**/*.test.mjs",
    "test:orchestrator:modules": "node --test tests/orchestrator/modules/*.test.mjs",
    "test:orchestrator:engine": "node --test tests/orchestrator/fix-engine.test.mjs",
    "test:orchestrator:integration": "node --test tests/orchestrator/integration/*.test.mjs",
    "test:orchestrator:coverage": "c8 npm run test:orchestrator"
  }
}
```

---

## Future Extensibility

### C++ / MCU Integration (Phase 1g+)

**Module Configuration:**
```yaml
cpp:
  name: "C++ Module (MCU Support)"
  extensions: ['.cpp', '.hpp', '.h', '.c', '.cc', '.cxx', '.ino']
  checker:
    command: 'clang-tidy'
    args: ['--format-style=file', '--checks=*']
  fixer:
    command: 'clang-format'
    args: ['-i', '--style=file']
  platformio:
    enabled: true
    config: 'platformio.ini'
    lsp_server: 'clangd'
    integration:
      pre_check:
        - 'pio run --target compiledb'  # Generate compile_commands.json
      post_fix:
        - 'pio run'  # Test build
  enabled: false  # Enable when ready
```

**LSP Integration:**
```javascript
// .github/scripts/orchestrator/integrations/lsp-client.mjs

class LSPClient {
  constructor(serverCommand, rootPath) {
    this.serverCommand = serverCommand;
    this.rootPath = rootPath;
  }

  async start() {
    // Start LSP server process
  }

  async getDiagnostics(fileUri) {
    // Request diagnostics from LSP server
    // Returns: [{ range, severity, message, source }]
  }

  async applyCodeAction(fileUri, diagnostic) {
    // Apply LSP code action (auto-fix)
  }

  async stop() {
    // Shutdown LSP server
  }
}
```

**PlatformIO Integration:**
```javascript
// .github/scripts/orchestrator/integrations/platformio.mjs

class PlatformIOIntegration {
  constructor(projectPath) {
    this.projectPath = projectPath;
  }

  async generateCompileCommands() {
    // Run: pio run --target compiledb
    // Generates compile_commands.json for clang tooling
  }

  async build() {
    // Run: pio run
    // Returns build success/failure
  }

  async test() {
    // Run: pio test
    // Returns test results
  }
}
```

### Python Integration (Future)

```yaml
python:
  name: "Python Module"
  extensions: ['.py', '.pyw']
  checker:
    commands:
      - name: 'pylint'
        args: ['--output-format=json']
      - name: 'mypy'
        args: ['--strict']
  fixer:
    commands:
      - name: 'black'
        args: []
      - name: 'isort'
        args: []
  strategies:
    conservative:
      black_args: ['--line-length=88']
    aggressive:
      black_args: ['--line-length=120', '--experimental-string-processing']
```

### Conflict Resolution (Phase 2)

```javascript
// .github/scripts/orchestrator/conflict-resolver.mjs

class ConflictResolver {
  async detectConflicts(checkResult) {
    // Detect conflicting fix suggestions
    // Example: SC2086 (quote var) vs intentional word splitting
  }

  async resolveConflict(conflict, strategy) {
    // Apply resolution rules
    // May involve user input (future: interactive mode)
  }
}
```

### ML Prediction Integration (Phase 3)

```javascript
// .github/scripts/orchestrator/ml-predictor.mjs

class MLStrategyPredictor {
  async predictStrategy(file, checkResult) {
    // Call ML service
    // Returns: { strategy: 'balanced', confidence: 0.92 }
  }

  async recordOutcome(file, strategy, success) {
    // Send telemetry for retraining
  }
}
```

---

## Metrics & Observability

### Metrics to Track

```javascript
{
  "run_id": "uuid",
  "timestamp": "2025-11-14T10:30:00Z",
  "modules_executed": ["shell", "javascript", "yaml"],
  "total_files": 45,
  "files_by_type": {
    "shell": 12,
    "javascript": 30,
    "yaml": 3
  },
  "total_attempts": 67,
  "average_attempts_per_file": 1.49,
  "success_rate": 0.956,
  "failures": [
    {
      "module": "shell",
      "file": "scripts/complex.sh",
      "attempts": 5,
      "final_issues": 2
    }
  ],
  "duration_ms": 45678,
  "strategies_used": {
    "conservative": 30,
    "balanced": 25,
    "aggressive": 12
  }
}
```

### GitHub Summary Template

```markdown
# Orchestrator V2 Execution Summary

## 📊 Overall Result: ✅ Success / ❌ Partial Success / ❌ Failure

### Statistics
- **Total Files:** 45
- **Modules Used:** Shell, JavaScript, YAML
- **Total Attempts:** 67
- **Success Rate:** 95.6%
- **Duration:** 45.7s

### Module Results

#### Shell Module (12 files)
- ✅ 11 files fixed
- ❌ 1 file with remaining issues
- Attempts: 18 total (avg 1.5 per file)
- Strategies: 6 conservative, 8 balanced, 4 aggressive

<details>
<summary>View details</summary>

**Fixed Files:**
- ✅ `scripts/deploy.sh` (2 attempts, balanced)
- ✅ `scripts/utils.sh` (1 attempt, conservative)
- ...

**Failed Files:**
- ❌ `scripts/complex.sh` (5 attempts, remaining issues: 2)
  - `line 45: SC2046` - Quote command substitution
  - `line 67: SC2086` - Quote variable expansion

</details>

#### JavaScript Module (30 files)
- ✅ 30 files fixed
- Attempts: 35 total (avg 1.2 per file)

#### YAML Module (3 files)
- ✅ 3 files fixed
- Attempts: 3 total (1 per file)

### Failed Files Detail

| File | Module | Attempts | Remaining Issues | Strategies Tried |
|------|--------|----------|------------------|------------------|
| `scripts/complex.sh` | Shell | 5 | 2 | conservative, balanced, aggressive |

### Recommendations

For files that couldn't be automatically fixed:
1. Review remaining issues manually
2. Consider adding shellcheck disable comments if intentional
3. See logs at `.orchestrator-logs/run-uuid.json`

---
**Orchestrator V2** | [Docs](docs/ORCHESTRATOR_V2_USER_GUIDE.md) | [Report Issue](issues/new)
```

---

## Success Criteria

### Phase 2 Success Criteria
- [ ] Base module interface implemented
- [ ] File discovery service working
- [ ] File router correctly classifies files
- [ ] Module registry functional
- [ ] All unit tests pass
- [ ] Code coverage > 80%
- [ ] Local validation successful
- [ ] Committed to branch

### Phase 3 Success Criteria
- [ ] Shell module uses shellcheck-apply.sh correctly
- [ ] JavaScript module uses ESLint correctly
- [ ] YAML module uses Prettier correctly
- [ ] All three module tests pass
- [ ] Manual testing successful
- [ ] Local validation successful
- [ ] Committed to branch

### Phase 4 Success Criteria
- [ ] Multi-pass engine retries correctly
- [ ] Strategy escalation works
- [ ] Early termination works (no progress)
- [ ] Early termination works (repeated errors)
- [ ] Timeout handling works
- [ ] All engine tests pass
- [ ] Local validation successful
- [ ] Committed to branch

### Phase 5 Success Criteria
- [ ] Orchestrator coordinates all components
- [ ] Result aggregation correct
- [ ] GitHub summary renders well
- [ ] E2E tests pass
- [ ] Local validation successful
- [ ] Committed to branch

### Phase 6 Success Criteria
- [ ] Workflow runs in CI successfully
- [ ] No race conditions
- [ ] Summary output correct
- [ ] Edge cases handled
- [ ] Committed to branch

### Phase 7 Success Criteria
- [ ] User guide complete
- [ ] Developer guide complete
- [ ] Troubleshooting guide complete
- [ ] Examples work
- [ ] Committed to branch

### Overall Success Criteria
- [ ] All tests pass (local and CI)
- [ ] Code coverage > 85%
- [ ] No regressions in existing workflows
- [ ] Documentation complete
- [ ] User satisfied with robustness
- [ ] Ready for C++/LSP/PlatformIO extension

---

## Appendix

### File Structure

```
.github/
├── scripts/
│   └── orchestrator/
│       ├── orchestrator.mjs              # Main controller
│       ├── orchestrator-cli.mjs          # CLI wrapper
│       ├── file-discovery.mjs            # File discovery service
│       ├── file-router.mjs               # File type router
│       ├── fix-engine.mjs                # Multi-pass engine
│       ├── module-registry.mjs           # Module registry
│       ├── module-loader.mjs             # Module loader
│       ├── attempt-tracker.mjs           # Attempt tracking
│       ├── strategy-selector.mjs         # Strategy selection
│       ├── progress-reporter.mjs         # Progress reporting
│       ├── modules/
│       │   ├── base-module.mjs           # Base class
│       │   ├── shell-module.mjs          # Shell implementation
│       │   ├── javascript-module.mjs     # JS implementation
│       │   ├── yaml-module.mjs           # YAML implementation
│       │   ├── cpp-module.mjs            # C++ stub (future)
│       │   └── python-module.mjs         # Python stub (future)
│       └── integrations/
│           ├── lsp-client.mjs            # LSP client (future)
│           └── platformio.mjs            # PlatformIO (future)
├── workflows/
│   ├── orchestrator-v2.yml               # V2 workflow
│   └── orchestrator.yml                  # V1 (existing)
├── orchestrator-modules.yml              # Module config
└── orchestrator-engine.yml               # Engine config

tests/
└── orchestrator/
    ├── orchestrator.test.mjs
    ├── file-discovery.test.mjs
    ├── file-router.test.mjs
    ├── fix-engine.test.mjs
    ├── attempt-tracker.test.mjs
    ├── strategy-selector.test.mjs
    ├── progress-reporter.test.mjs
    ├── module-registry.test.mjs
    ├── modules/
    │   ├── base-module.test.mjs
    │   ├── shell-module.test.mjs
    │   ├── javascript-module.test.mjs
    │   └── yaml-module.test.mjs
    └── integration/
        └── e2e.test.mjs

docs/
├── architecture/
│   └── ORCHESTRATOR_V2_DESIGN.md         # This file
├── ORCHESTRATOR_V2_USER_GUIDE.md         # User guide
└── ORCHESTRATOR_V2_DEVELOPER_GUIDE.md    # Developer guide
```

### References

- Issue #143: Phase 1b Task 4 - Additional orchestration components
- Issue #153: Phase 2 - Conflict resolution system
- Issue #157: Phase 3 - ML-powered fix prediction
- Issue #202: Orchestrator dependency conflicts (resolved)
- Current orchestrator: `.github/workflows/orchestrator.yml`
- Current config: `.github/workflow-orchestration.yml`
- Shellcheck apply script: `.github/scripts/shellcheck-apply.sh`

---

**End of Design Document**
