# Label Design Specification

## Purpose

This document defines the complete label taxonomy for issue tracking systems (GitHub, Linear, etc.). It establishes naming conventions, color schemes, and organizational structure for consistent project management across tools.

---

## Design Principles

### 1. Color Strategy

- **Tailwind CSS colors** for consistency and accessibility
- **Semantic grouping** within categories (gradients or related colors)
- **Visual distinction** between categories at a glance
- **Reserved colors**: Red for urgent/critical states across all categories

### 2. Naming Conventions

- **Both GitHub and Linear**: Lowercase with colons and spaces for hierarchical organization (`difficulty: easy`, `ai: supervised`, `type: bug`)
- **Consistent format**: All labels use `category: value` pattern (colon + space) across both systems
- **No mapping needed**: Same format syncs directly between systems

### 3. Category Organization

Labels are organized into 13 main categories:

1. Difficulty (5 levels)
2. AI Capability (4 levels)
3. Workflow Status (8 states)
4. Validation Status (3 states)
5. Test Type (4 classes)
6. Role (2 tags)
7. Work Type (10 types)
8. Documentation (8 states)
9. Technique (11 types)
10. Security (6 types)
11. Artifact (6 types)
12. Environment (2 types)
13. Resource (2 types)

Plus: Conditional Flags (2 flags)

---

## Label Taxonomy

### Difficulty Labels

Indicates task complexity and estimated effort. Uses traffic palette gradient (green → yellow → orange → red).

| Label Name            | Color  | Hex       | Description                                                   |
| --------------------- | ------ | --------- | ------------------------------------------------------------- |
| `difficulty: trivial` | Green  | `#22c55e` | Quick fix or simple task - minimal complexity                 |
| `difficulty: easy`    | Lime   | `#84cc16` | Straightforward task with clear solution                      |
| `difficulty: medium`  | Yellow | `#fef08a` | Moderate complexity requiring some problem-solving            |
| `difficulty: hard`    | Amber  | `#f59e0b` | Complex task requiring significant effort and expertise       |
| `difficulty: complex` | Red    | `#ef4444` | Highly complex, may require research or architectural changes |

**Rules:**

- Exactly one difficulty label per issue
- Default: `medium` if uncertainty exists
- Re-evaluate after investigation phase

---

### AI Capability Labels

Defines the level of AI autonomy vs. human involvement required. Uses Purple Gradient Palette (darkest → lightest).

| Label Name       | Color             | Hex       | Description                                                     |
| ---------------- | ----------------- | --------- | --------------------------------------------------------------- |
| `ai: autonomous` | Indigo            | `#4b0082` | AI can complete this task independently without human oversight |
| `ai: supervised` | Violet            | `#7c3aed` | AI can do the work but requires human review/approval           |
| `ai: human+ai`   | Light Purple      | `#a78bfa` | Collaborative work - human and AI working together throughout   |
| `ai: human-only` | Very Light Purple | `#ddd6fe` | Requires human expertise, judgment, or cannot be automated      |

**Rules:**

- Exactly one AI capability label per issue
- Default: `Human + AI` (collaborative)
- Auto-applies `needs-human` flag for supervised/human+ai/human-only

---

### Workflow Status Labels

Tracks current state of work. Uses status-based semantic colors.

| Label Name              | Color      | Hex       | Description                                                                 |
| ----------------------- | ---------- | --------- | --------------------------------------------------------------------------- |
| `workflow: backlog`     | Gray       | `#6b7280` | Planned but not yet ready to start                                          |
| `workflow: ready`       | Blue       | `#3b82f6` | All dependencies resolved, ready to begin work                              |
| `workflow: in-progress` | Purple     | `#8b5cf6` | Currently being worked on                                                   |
| `workflow: review`      | Amber      | `#f59e0b` | Awaiting review or approval                                                 |
| `workflow: on-hold`     | Yellow     | `#fef08a` | Paused or waiting (intentional hold)                                        |
| `workflow: testing`     | Cyan       | `#06b6d4` | Implementation done, in testing/QA phase                                    |
| `workflow: blocked`     | Red        | `#ef4444` | Cannot proceed - waiting on dependency or other blocker                     |
| `workflow: not-planned` | Light Gray | `#d1d5db` | Issue closed without implementation - won't fix, out of scope, or duplicate |

**Rules:**

- Exactly one workflow status label per issue (mutually exclusive)
- Transitions: Backlog → Ready → In Progress → Review/Testing → Done
- Special states: Blocked (can occur at any stage), On Hold (intentional pause), Not Planned (terminal state)
- Not Planned is applied when closing issues that won't be implemented

**Typical Flow:**

```
Backlog → Ready → In Progress → Review → Testing → [Done]
   ↓              ↓
Not Planned    Blocked (temporary) → back to previous state
                  ↓
              On Hold (intentional) → back when resumed
```

---

### Validation Labels

Represents validation gate state independent from workflow progress. Reuses the Traffic Palette (red/amber/green) for fast signal recognition.

| Label Name            | Color | Hex       | Description                                                                                |
| --------------------- | ----- | --------- | ------------------------------------------------------------------------------------------ |
| `validation: pending` | Amber | `#f59e0b` | Default state when the issue opens or re-enters testing; validation suite not yet complete |
| `validation: passed`  | Green | `#22c55e` | All IB/OOB validation cases satisfied and release gate approved                            |
| `validation: failed`  | Red   | `#ef4444` | One or more validation cases failing or gate rejected                                      |

**Rules:**

- Exactly one validation label per issue
- Default: `validation: pending` on creation or after fixes before re-run
- Promote to `validation: passed` once every required validation case is complete
- Switch to `validation: failed` immediately when any validation case breaks

---

### Test Type Labels

Classifies what behavior a test exercises, independent of implementation difficulty. Provides fast filtering for analytics and test focus planning.

| Label Name                | Color | Hex       | Description                                                                            |
| ------------------------- | ----- | --------- | -------------------------------------------------------------------------------------- |
| `test-type: simple`       | Cyan  | `#06b6d4` | Targets a single behavior or assertion path with minimal branching                     |
| `test-type: simple-edge`  | Blue  | `#3b82f6` | Covers a narrow, hard-to-trigger condition while keeping setup straightforward         |
| `test-type: complex`      | Tan   | `#78716c` | Combines several proven simple checks or requires layered setup to exercise behavior   |
| `test-type: complex-edge` | Brown | `#292524` | Stress-tests unlikely or multi-step edge scenarios that demand intricate orchestration |

**Rules:**

- Exactly one test-type label when the work includes new or updated automated tests
- Default: `test-type: simple` unless scope clearly advances into multi-step or aggregated assertions
- Promote to `test-type: complex`/`complex-edge` when a test relies on chained setups, nested flows, or multiple coordinated assertions
- Reserve edge variants for cases with low-probability triggers, difficult reproduction, or high-impact regressions

---

### Role Labels

Used to help define hierarchy, eg grouping tests for a specific feature together. Enables portfolio-style queries without affecting normal workflow.

| Label Name          | Color | Hex       | Description                                                                        |
| ------------------- | ----- | --------- | ---------------------------------------------------------------------------------- |
| `role: test suite`  | Pink  | `#ec4899` | Aggregates a cohesive set of tests tied to a specific feature or sub-feature scope |
| `role: sub-feature` | Blue  | `#3b82f6` | Represents a required feature slice with its own backlog and child issues          |

**Rules:**

- Optional but recommended for planning artifacts; apply at most one role label per issue
- Use `role: test suite` for umbrella issues tracking multiple related tests
- Use `role: sub-feature` when the issue owns a distinct slice of functionality beneath a larger feature
- Leaf-level test implementation issues generally rely on `type: test` without an additional role label

---

### Work Type Labels

Categorizes the nature of work. Uses Standard Palette and Traffic Palette colors for visual differentiation.

| Label Name                  | Color  | Hex       | Description                                                  |
| --------------------------- | ------ | --------- | ------------------------------------------------------------ |
| `type: bug`                 | Red    | `#ef4444` | Something isn't working                                      |
| `type: feature`             | Blue   | `#3b82f6` | New functionality                                            |
| `type: improvement`         | Tan    | `#78716c` | Enhancement to existing functionality                        |
| `type: refactor`            | Gray   | `#6b7280` | Code restructuring without changing functionality            |
| `type: docs`                | Cyan   | `#06b6d4` | Documentation updates                                        |
| `type: test`                | Pink   | `#ec4899` | Individual test cases (IB/OOB format only)                   |
| `type: function`            | Brown  | `#292524` | Function contract definition (inputs, outputs, invariants)   |
| `type: tooling`             | Gray   | `#6b7280` | Internal tools and infrastructure (testing infra, workflows) |
| `type: internal-dependency` | Yellow | `#fef08a` | Depends on other work within this project                    |
| `type: external-dependency` | Amber  | `#eab308` | Depends on external work or third-party changes              |

**Rules:**

- **Work type labels on parent issues ONLY** - Children do NOT inherit work type labels
- **Atomic hierarchy applies to all work types**: Work Type → Sub-Feature → Function → Test-Suite → Test-Case
- Work type labels (bug, feature, improvement, refactor, docs, tooling) identify the top-level parent
- `type: function` used for function contract issues (middle of hierarchy)
- `type: test` used ONLY for individual test case issues (IB/OOB format, bottom of hierarchy)
- Refactor ≠ Improvement (refactor may not add user value, improvement always does)
- `type: test` triggers validation workflows expecting IB-01, OOB-01 format
- `type: tooling` does NOT trigger test validation workflows
- Dependency labels indicate blockers, not regular relationships

**Hierarchy Examples:**

- `type: feature` (parent) → `role: sub-feature` → `type: function` → `role: test suite` → `type: test`
- `type: bug` (parent) → `role: sub-feature` → `type: function` → `role: test suite` → `type: test`
- `type: tooling` (parent) → `role: sub-feature` → `type: function` → `role: test suite` → `type: test`

**Work Type Distinction:**

- `type: test` = Individual test cases with IB/OOB format (e.g., "Test login with valid credentials (IB-01)")
- `type: tooling` = Building testing infrastructure itself (e.g., "Build synthetic testing framework")
- `type: function` = Function contract definition (e.g., "validatePassword function contract")

---

### Documentation Labels

Tracks documentation state independent of workflow progress. Applied when documentation artifacts (cards, guides, specs) are relevant to the issue.

| Label Name            | Color   | Hex       | Description                                                              |
| --------------------- | ------- | --------- | ------------------------------------------------------------------------ |
| `Docs: Needed`        | Red     | `#ef4444` | Drift detected or policy indicates documentation is required             |
| `Docs: Ready`         | Green   | `#22c55e` | Cards updated and validated; last_verified_commit advanced               |
| `Docs: Needs-Improve` | Amber   | `#f59e0b` | Cards present but flagged for quality or clarity issues                  |
| `Docs: Ingest-Needed` | Cyan    | `#06b6d4` | Cards validated but not yet included in bundles or mirrored              |
| `Docs: Ingested`      | Emerald | `#10b981` | Bundles built and mirrors current; documentation complete                |
| `Docs: Blocked`       | Red     | `#dc2626` | Pending upstream decisions before documentation can complete             |
| `Docs: Defer`         | Gray    | `#9ca3af` | Explicit acknowledgment that documentation will follow later             |
| `Docs: Not-Needed`    | Gray    | `#d1d5db` | Issue mirror sufficient; no additional conceptual documentation required |

**Rules:**

- Optional and conditional - Not all issues require documentation beyond issue mirroring
- All issues mirrored to `docs/issues_mirror/` for AI agents without GitHub API access
- Docs: labels track conceptual documentation (cards) when needed beyond the mirror
- Multiple docs labels allowed (e.g., both `Docs: Needed` and `Docs: Blocked`)
- Workflow independence - Docs labels separate from `Workflow:` status
- Warn-only enforcement - Documentation gaps generate warnings but never fail CI
- Commit-aware triggers - Drift detection can create issues for uncommitted doc changes
- `Docs: Defer` explicitly acknowledges "this could use docs, but we're consciously postponing"
- `Docs: Not-Needed` explicitly documents decision that issue mirror is sufficient

**Typical Flow:**

```
Issue Created → All issues mirrored to docs/issues_mirror/
    ↓
Decision: Does this need conceptual documentation (cards)?
    ↓
    NO → Apply Docs: Not-Needed (mirror is sufficient)
    ↓
    YES → Apply Docs: Needed
        ↓
        Docs: Ready (cards written and validated)
        ↓
        Docs: Ingest-Needed (needs bundle generation)
        ↓
        Docs: Ingested (complete)

Alternative paths:
- Docs: Needs-Improve (quality issues)
- Docs: Blocked (waiting on decisions)
- Docs: Defer (explicit postponement)
```

---

### Conditional Flags

Special indicators that modify or clarify other labels.

| Label Name    | Color  | Hex       | Description                                                                     |
| ------------- | ------ | --------- | ------------------------------------------------------------------------------- |
| `Needs-Human` | Yellow | `#fef08a` | Some tasks cannot be done by AI, or require a human in the loop during the task |
| `Risky!`      | Amber  | `#f59e0b` | Proceed with caution - not forbidden but requires careful attention and review  |

**Rules:**

- `Needs-Human` is auto-applied when AI capability is `Supervised`, `Human+AI`, or `Human-Only`
- `Needs-Human` can be manually added to `Autonomous` tasks if human verification needed
- `Risky!` is a warning flag - work can proceed but needs extra care and review
- Flags issues requiring human attention in AI-assisted workflows

---

## Label Taxonomy by Hierarchy Level

The 5-level atomic hierarchy defines exactly which labels are required, optional, or forbidden at each level.

### Level 1: Feature (Top-level parent)

**Required labels:**

- `Type:` One of: Feature, Bug, Improvement, Refactor, Tooling, Docs
- `Workflow: Backlog` (all issues start here)

**Forbidden labels:**

- All other labels (Difficulty, AI, Role, Validation, Test-Type, Technique, Security, Artifact, Env, Resource, flags)

### Level 2: Sub-Feature

**Required labels:**

- `Role: Sub-Feature`
- `Type:` (inherited from Level 1 - creates actual label on this issue)
- `Workflow: Backlog` (starts here, transitions via gates)

**Forbidden labels:**

- `Difficulty:` _, `AI:` _, `Needs-Human`, `Validation:` _, `Test-Type:` _, `Technique:` _, `Security:` _, `Artifact:` _, `Env:` _, `Resource:` \*

### Level 3: Function

**Required labels:**

- `Type: Function`
- `Type:` (inherited from Level 1 - creates actual label on this issue)
- `Workflow: Backlog` (starts here, transitions via gates)
- `Difficulty:` One of: Trivial, Easy, Medium, Hard, Complex
- `AI:` One of: Autonomous, Supervised, Human+AI, Human-Only

**Auto-applied by logic:**

- `Needs-Human` (automatically added when AI is Supervised/Human+AI/Human-Only)

**Forbidden labels:**

- `Role:` _, `Validation:` _, `Test-Type:` _, `Technique:` _, `Security:` _, `Artifact:` _, `Env:` _, `Resource:` _

### Level 4: Test-Suite

**Required labels:**

- `Role: Test-Suite`
- `Type:` (inherited from Level 1 - creates actual label on this issue)
- `Workflow: Backlog` (starts here, transitions via gates)

**Forbidden labels:**

- `Type: Test` (only at Level 5), `Difficulty:` _, `AI:` _, `Needs-Human`, `Validation:` _, `Test-Type:` _, `Technique:` _, `Security:` _, `Artifact:` _, `Env:` _, `Resource:` \*

### Level 5: Test (Leaf test cases)

**Required labels:**

- `Type: Test`
- `Type:` (inherited from Level 1 - creates actual label on this issue)
- `Workflow: Backlog` (starts here, transitions via gates)
- `Validation: Pending` (default when created, changes to Passed/Failed)
- `Difficulty:` One of: Trivial, Easy, Medium, Hard, Complex
- `AI:` One of: Autonomous, Supervised, Human+AI, Human-Only
- `Env:` One of: Synthetic, Hardware
- `Test-Type:` One of: Simple, Simple-Edge, Complex, Complex-Edge
- `Technique:` One of: Unit, Integration, End-to-End, Property-Based, Mutation, Contract, Fuzz, Regression, Observability, Snapshot, Benchmark

**Auto-applied by logic:**

- `Needs-Human` (automatically added when AI is Supervised/Human+AI/Human-Only)

**Optional labels (test classification):**

- `Security:` Injection, Auth, Authorization, Crypto, Validation, Threat-Lite
- `Artifact:` Error-Taxonomy, Determinism-Kit, Observability-Spec
- `Resource:` High-CPU, Network-Dependent

**Forbidden labels:**

- `Role:` \* (uses Type: Test, not a role)

### Key Inheritance Rules

1. **Type inheritance creates actual labels** - When Level 2-5 inherit Type from Level 1, the Type label is actually applied to the child issue
2. **Workflow always starts as Backlog** - All issues at all levels start with `Workflow: Backlog`
3. **Workflow transitions require gates** - Moving from Backlog → Ready → In-Progress requires dependency checks and validation
4. **Needs-Human is auto-applied** - Never manually required; automatically added based on AI label value
5. **Difficulty/AI start at Level 3** - Function is the first level where implementation complexity matters
6. **Test classification only at Level 5** - Technique, Test-Type, Env, Security, Artifact, Resource labels only on leaf test issues

---

## Project Labels (Linear Only)

Project labels are applied at the project/initiative level in Linear, not to individual issues.

### Visibility Labels

Indicates whether the project is customer-facing or internal-only.

| Linear Name | Color  | Hex       | Description                                         |
| ----------- | ------ | --------- | --------------------------------------------------- |
| `External`  | Purple | `#8b5cf6` | Customer-facing or public project                   |
| `Internal`  | Gray   | `#6b7280` | Internal-only project (tools, infrastructure, etc.) |

**Rules:**

- Exactly one visibility label per project
- Default: Internal (unless explicitly customer-facing)

---

### Project Status Labels

Tracks the current phase of the project lifecycle.

| Linear Name          | Color  | Hex       | Description                                           |
| -------------------- | ------ | --------- | ----------------------------------------------------- |
| `Planning`           | Yellow | `#fef08a` | Project in planning/design phase                      |
| `Active Development` | Blue   | `#3b82f6` | Project actively being developed                      |
| `On Hold`            | Amber  | `#f59e0b` | Project paused (resource constraints, blockers, etc.) |
| `Maintenance`        | Green  | `#22c55e` | Project completed, in maintenance mode                |

**Rules:**

- Exactly one status label per project
- Typical flow: Planning → Active Development → Maintenance
- On Hold can occur at any phase

---

### Domain Labels

Indicates technical domain or product area.

| Linear Name | Color | Hex       | Description                             |
| ----------- | ----- | --------- | --------------------------------------- |
| `Hardware`  | Stone | `#78716c` | Physical hardware design/development    |
| `Firmware`  | Cyan  | `#06b6d4` | Embedded firmware/software for hardware |

**Rules:**

- Multiple domain labels allowed (e.g., Hardware + Firmware)
- Add additional domains as needed (Software, Cloud, AI, etc.)

---

### Scope Labels

Defines project hierarchy and dependencies.

| Linear Name    | Color | Hex       | Description                                |
| -------------- | ----- | --------- | ------------------------------------------ |
| `Main Project` | Pink  | `#ec4899` | Standalone project or top-level initiative |
| `Sub-Project`  | Brown | `#292524` | Component of a larger project              |

**Rules:**

- Exactly one scope label per project
- Sub-Projects should be linked to parent Main Project
- Default: Main Project

---

## Color Accessibility

All colors meet WCAG AA contrast requirements:

- Light backgrounds: All colors visible
- Dark backgrounds: Adjusted for visibility in dark mode

### Color Palettes

**Traffic Palette** (4 colors - strong semantic meaning):

- **Red** (#ef4444): Critical, errors, blocks
- **Amber** (#f59e0b): Warnings, attention needed
- **Yellow** (#fef08a): Caution, moderate complexity
- **Green** (#22c55e, #10b981): Success, ready states, positive

**Purple Gradient Palette** (for AI capability grading only):

- **Indigo → Violet → Light Purple → Very Light Purple** (#4b0082 → #7c3aed → #a78bfa → #ddd6fe): AI autonomy levels from fully autonomous to human-only

**Standard Palette** (general categorization):

- **Blue** (#3b82f6): Features, active work, hierarchy
- **Cyan** (#06b6d4): Documentation, testing states
- **Gray** (#6b7280): Inactive states, refactoring
- **Pink** (#ec4899): Testing, test coverage
- **Purple** (#8b5cf6): Specialized work
- **Stone** (#78716c): Complex test orchestration
- **Brown** (#292524): Complex edge test orchestration

---

## Usage Guidelines

### When Creating Issues

1. **Always apply**: Difficulty, AI Capability, Workflow Status, Work Type
2. **Apply if relevant**: Test Type (must,only when introducing/modifying automated tests), Role (must,only for suites and sub-features), Validation Status(must,only for tests), Conditional flags(currently only 1but must for the majority of AI capability levs
3. **Default values**: Medium difficulty, Human + AI capability, Backlog status, `validation: pending`

### When Updating Issues

- **Workflow changes**: Update status as work progresses
- **Scope changes**: Re-evaluate difficulty if complexity shifts
- **AI involvement**: Adjust capability if automation level changes
- **Test scope**: Update test-type when test coverage grows in complexity or focus
- **Hierarchy**: Add or adjust role labels when issues become suites or sub-features

### Label Combinations to Avoid

- Multiple difficulty labels (pick one)
- Multiple workflow status labels (mutually exclusive)
- Multiple validation labels (mutually exclusive)
- Multiple test-type labels (mutually exclusive)
- Multiple role labels (pick one hierarchy role)
- `ai: autonomous` + `needs-human` (contradictory, unless human verification required)

---

## Version History

**v1.6 - 2025-11-11**

- Added Documentation label category (8 labels): Needed, Ready, Needs-Improve, Ingest-Needed, Ingested, Blocked, Defer, Not-Needed
- Introduced docs/issues_mirror/ for universal issue mirroring to support AI agents without GitHub API access
- Documentation labels track conceptual documentation (cards) separately from issue mirrors
- Warn-only enforcement: documentation gaps never fail CI
- Commit-aware triggers: drift detection can create issues for uncommitted documentation changes
- Multiple docs labels allowed (workflow independence)
- Updated category count from 12 to 13 categories
- Updated total label count from 65 to 73 labels

**v1.5 - 2025-11-11**

- Added `Workflow: Not-Planned` label (Light Gray #d1d5db) for issues closed without implementation
- Terminal state for: won't fix, out of scope, or duplicate issues
- Updated workflow status count from 7 to 8 labels
- Updated total label count from 64 to 65 labels
- Updated workflow diagram to include Not-Planned terminal state

**v1.4 - 2025-11-11**

- Added 5 new Technique labels: Unit, Integration, End-to-End, Snapshot, Benchmark
- Added `Risky!` flag (Amber #f59e0b) for caution/careful review
- Converted all label names to Title Case (e.g., `Type: Test`, `Workflow: Backlog`)
- Added comprehensive "Label Taxonomy by Hierarchy Level" section defining:
  - Level 1 (Feature): Only Type + Workflow labels
  - Level 2 (Sub-Feature): Role + inherited Type + Workflow
  - Level 3 (Function): Type: Function + inherited Type + Workflow + Difficulty + AI
  - Level 4 (Test-Suite): Role + inherited Type + Workflow
  - Level 5 (Test): Type: Test + inherited Type + Workflow + Validation + Difficulty + AI + Env + Test-Type + Technique (required); Security/Artifact/Resource (optional)
- Documented that Type inheritance creates actual labels on child issues
- Documented that Workflow always starts as Backlog, transitions controlled by gates
- Documented that Needs-Human flag is auto-applied based on AI label, not manually required
- Updated Technique category from 6 to 11 labels
- Updated total label count from 58 to 64 labels
- Updated flag count from 1 to 2 (added Risky!)

**v1.3 - 2025-11-09**

- Added `type: function` label (Brown #292524) for function contract issues in atomic hierarchy
- Added `type: tooling` label (Gray #6b7280) for internal tools and infrastructure work
- Changed `type: improvement` color from Blue (#3b82f6) to Tan (#78716c) for color uniqueness
- Updated `type: test` description to clarify it's ONLY for individual test cases (IB/OOB format)
- Documented atomic hierarchy: Work Type → Sub-Feature → Function → Test-Suite → Test-Case
- Added work type hierarchy rules (parent only, children don't inherit)
- Clarified distinction between `type: test` (test cases) and `type: tooling` (testing infrastructure)
- Updated label count from 34 to 36 issue labels
- Updated work type count from 8 to 10 labels

**v1.2 - 2025-11-06**

- Reorganized color scheme into three named palettes: Traffic, Purple Gradient, and Standard
- Changed work type colors: improvement (Blue), refactor (Gray), docs (Cyan)
- Changed role colors: test suite (Pink), sub-feature (Blue)
- Eliminated unique colors (Sky, Azure) in favor of Standard Palette reuse
- Updated color accessibility section to group by palette
- Fixed all Linear project labels to use distinct colors from defined palettes:
  - Visibility: External (Purple), Internal (Gray)
  - Project Status: Planning (Yellow), Active Development (Blue), On Hold (Amber), Maintenance (Green)
  - Domain: Hardware (Stone), Firmware (Cyan)
  - Scope: Main Project (Pink), Sub-Project (Brown)

**v1.1 - 2025-11-06**

- Added validation label category (pending, passed, failed) with shared red/amber/green palette
- Added test-type label category (simple, simple-edge, complex, complex-edge) for test coverage classification
- Added role label category (test suite, sub-feature) for hierarchy reporting
- Updated guidelines and automation notes to incorporate validation status, test coverage, and hierarchy tagging

**v1.0 - 2025-01-31**

- Initial specification
- 5 categories, 25 total labels
- Tailwind color scheme
- GitHub/Linear dual-system support

---

## Future Enhancements

### Potential Additions

- Priority labels (P0, P1, P2, P3)
- Component/Area labels (Frontend, Backend, Infrastructure)
- Release/Milestone labels
- Customer impact labels

### Automation Roadmap

- Label sync agent (GitHub → Linear)
- Auto-labeling based on content analysis
- Label validation on issue creation
- Stale label detection and cleanup

---

## Appendix: Quick Reference

### Complete Issue Label List (73 labels)

**Difficulty (5):** Trivial, Easy, Medium, Hard, Complex
**AI Capability (4):** Autonomous, Supervised, Human+AI, Human-Only
**Workflow (8):** Backlog, Ready, In-Progress, Review, On-Hold, Testing, Blocked, Not-Planned
**Validation (3):** Pending, Passed, Failed
**Test Type (4):** Simple, Simple-Edge, Complex, Complex-Edge
**Role (2):** Test-Suite, Sub-Feature
**Work Type (10):** Bug, Feature, Improvement, Refactor, Docs, Test, Function, Tooling, Internal-Dependency, External-Dependency
**Docs (8):** Needed, Ready, Needs-Improve, Ingest-Needed, Ingested, Blocked, Defer, Not-Needed
**Technique (11):** Unit, Integration, End-to-End, Property-Based, Mutation, Contract, Fuzz, Regression, Observability, Snapshot, Benchmark
**Security (6):** Injection, Auth, Authorization, Crypto, Validation, Threat-Lite
**Artifact (6):** RFC, ADR, Spike, Error-Taxonomy, Determinism-Kit, Observability-Spec
**Env (2):** Synthetic, Hardware
**Resource (2):** High-CPU, Network-Dependent
**Flags (2):** Needs-Human, Risky!

### Complete Project Label List (10 labels - Linear Only)

**Visibility (2):** External, Internal
**Project Status (4):** Planning, Active Development, On Hold, Maintenance
**Domain (2):** Hardware, Firmware
**Scope (2):** Main Project, Sub-Project
