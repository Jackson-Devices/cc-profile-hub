# Issue Template Usage Guide

**Version:** 1.0
**Last Updated:** 2025-11-14
**Status:** Complete

## Overview

This repository uses a hierarchical issue template system implementing the Atomic TDD Framework. There are **6 template types** mapping to the 5-level test hierarchy:

```
Feature (Level 1)
└── Sub-Feature (Level 2)
    └── Function (Level 3)
        └── Test-Suite (Level 4)
            └── Test (Level 5)
```

Plus a standalone **Test** template for issues that don't fit the hierarchy.

---

## Template Hierarchy

### 1. Feature Template (`feature.yml`)

**Purpose:** Top-level parent issue defining a user outcome with acceptance criteria.

**When to use:**
- Defining a new capability or user-facing feature
- Planning major enhancements or improvements
- Organizing related work under acceptance criteria

**Key sections:**
- **Feature Name:** Short descriptive name
- **User Outcome:** "As a [user], I want [capability] so that [benefit]"
- **Work Type:** Feature/Bug Fix/Improvement/Refactor/Tooling
- **Acceptance Criteria:** List of ACs (each becomes a Sub-Feature)
- **Success Metrics:** Measurable, objective outcomes
- **Dependencies:** Blocking issues or requirements
- **Sub-Features:** Auto-generated links to child issues
- **Estimated Effort:** XS/S/M/L/XL sizing
- **Ready Gate:** Checklist to verify readiness

**Example title:** `FEATURE: User Authentication System`

**Labels applied:** Based on Work Type dropdown

**Workflow:**
1. Create Feature issue
2. Define acceptance criteria (one per capability)
3. Create Sub-Feature issues (one per AC)
4. Link Sub-Features in the "Sub-Features" section
5. Check Ready Gate when all children are created

---

### 2. Sub-Feature Template (`sub-feature.yml`)

**Purpose:** Child of Feature, implements one acceptance criterion through function contracts.

**When to use:**
- Implementing a single acceptance criterion from a Feature
- Breaking down Features into implementation units
- Organizing Functions that deliver one capability

**Key sections:**
- **Sub-Feature Name:** Descriptive name
- **Parent Feature Issue URL:** Link to parent Feature
- **Acceptance Criterion:** The specific AC being implemented
- **Technical Approach:** Implementation strategy
- **Function Contracts:** List of Functions needed (each becomes a Function issue)
- **Test Coverage Plan:** Testing strategy
- **Dependencies:** Technical dependencies
- **Ready Gate:** Checklist to verify readiness

**Example title:** `SUB-FEATURE: User Registration Flow [Parent #123]`

**Labels applied:** `Role: Sub-Feature`

**Workflow:**
1. Create from parent Feature's acceptance criteria
2. Define required Functions with contracts
3. Create Function issues
4. Link Functions in "Function Contracts" section
5. Implement Functions
6. Verify AC is met

---

### 3. Function Template (`function.yml`)

**Purpose:** Implementation unit with formal contract (inputs, outputs, invariants, pre/post conditions).

**When to use:**
- Defining a specific function or method
- Establishing formal contracts for implementation
- Creating testable units with clear boundaries

**Key sections:**
- **Function Name:** Exact signature with parameters
- **Parent Sub-Feature Issue URL:** Link to parent
- **Contract Definition:**
  - **Inputs:** Parameters with types and constraints
  - **Outputs:** Return values with types and guarantees
  - **Preconditions:** Assumptions before execution
  - **Postconditions:** Guarantees after execution
  - **Invariants:** Conditions that must always hold
- **Error Conditions:** Exception/error cases
- **Test Suite:** Link to associated Test-Suite issue
- **Implementation Notes:** Technical details
- **Ready Gate:** Contract completeness checklist

**Example title:** `FUNCTION: validate_email(email: string): ValidationResult [Parent #124]`

**Labels applied:** `Type: Function`

**Workflow:**
1. Create from parent Sub-Feature
2. Define complete contract (inputs/outputs/pre/post/invariants)
3. Create Test-Suite issue
4. Implement function following contract
5. Verify all invariants hold
6. Link Test-Suite results

---

### 4. Test-Suite Template (`test-suite.yml`)

**Purpose:** Collection of test cases validating one function contract (organizes IB/OOB tests).

**When to use:**
- Organizing tests for a specific Function
- Planning comprehensive test coverage
- Tracking IB (In-Bounds) and OOB (Out-of-Bounds) test cases

**Key sections:**
- **Test Suite Name:** Descriptive name
- **Parent Function Issue URL:** Link to parent Function
- **Function Contract Summary:** Quick reference
- **Test Coverage Strategy:** Approach to testing
- **Test Cases:** List of individual tests (each can become a Test issue)
  - IB (In-Bounds): Valid inputs, expected behavior
  - OOB (Out-of-Bounds): Invalid inputs, error handling, edge cases
- **Coverage Metrics:** Target percentages
- **Ready Gate:** Coverage completeness checklist

**Example title:** `TEST-SUITE: validate_email() Coverage [Parent #125]`

**Labels applied:** `Role: Test-Suite`

**Workflow:**
1. Create from parent Function
2. Analyze Function contract
3. Plan test cases (IB and OOB)
4. Create Test issues for complex cases
5. Implement tests
6. Verify coverage metrics met
7. Link test results

---

### 5. Test Template (`test.yml`)

**Purpose:** Individual test case with IB/OOB namespace, expected behavior, and validation gate.

**When to use:**
- Creating atomic test cases
- Defining specific test scenarios
- Tracking test implementation and validation

**Key sections:**
- **Test Name:** Descriptive test case name
- **Parent Test-Suite Issue URL:** Link to parent (optional)
- **IB/OOB Namespace:** In-Bounds or Out-of-Bounds classification
- **Test Scenario:** What is being tested
- **Expected Behavior:** What should happen
- **Test Implementation:** Code or steps
- **Validation Results:** Automated gate results
- **AI Metadata:** Pass tracking, decision logs
- **Ready Gate:** Test completion checklist

**Example title:** `TEST: validate_email() rejects invalid format [IB-01] [Parent #126]`

**Labels applied:** `Type: Test`

**Workflow:**
1. Create from Test-Suite or standalone
2. Define IB/OOB classification
3. Specify expected behavior
4. Implement test
5. Run automated validation
6. Check validation gate passes
7. Update decision log if failures occur

---

## Creating Issues in Hierarchy Order

### Step-by-Step Workflow

**Phase 1: Feature Planning**
1. Create **Feature** issue
2. Define user outcome and acceptance criteria
3. Define success metrics
4. Identify dependencies

**Phase 2: Sub-Feature Creation**
1. For each AC in Feature:
   - Create **Sub-Feature** issue
   - Link to parent Feature
   - Define technical approach
   - Plan required Functions

**Phase 3: Function Definition**
1. For each Function in Sub-Feature:
   - Create **Function** issue
   - Link to parent Sub-Feature
   - Define complete contract (inputs/outputs/pre/post/invariants)
   - Specify error conditions

**Phase 4: Test Suite Planning**
1. For each Function:
   - Create **Test-Suite** issue
   - Link to parent Function
   - Plan IB and OOB test cases
   - Define coverage targets

**Phase 5: Test Implementation**
1. For complex test cases:
   - Create **Test** issues
   - Link to parent Test-Suite
   - Implement and validate
   - Track in validation gate

---

## Label Assignment

Templates auto-apply labels based on configuration:

| Template | Auto-Labels | Additional (manual) |
|----------|------------|---------------------|
| Feature | Based on Work Type dropdown | Priority, Status |
| Sub-Feature | `Role: Sub-Feature` | Type, Priority |
| Function | `Type: Function` | Status |
| Test-Suite | `Role: Test-Suite` | Status |
| Test | `Type: Test` | Validation, Status |

**Work Type mapping (Feature template):**
- "Feature (new capability)" → `Type: Feature`
- "Bug Fix (fixes incorrect behavior)" → `Type: Bug`
- "Improvement (enhances existing feature)" → `Type: Improvement`
- "Refactor (internal restructuring)" → `Type: Refactor`
- "Tooling (dev tools, testing infrastructure)" → `Type: Tooling`

---

## Ready Gates

Each template includes a **Ready Gate** checklist to verify completeness:

### Feature Ready Gate
- [ ] All acceptance criteria defined and specific
- [ ] Success metrics are measurable and objective
- [ ] Dependencies identified and documented
- [ ] Sub-Feature issues created (one per AC)

### Sub-Feature Ready Gate
- [ ] Parent Feature linked
- [ ] Acceptance criterion clearly defined
- [ ] Technical approach documented
- [ ] All required Functions identified
- [ ] Function issues created

### Function Ready Gate
- [ ] Parent Sub-Feature linked
- [ ] Complete contract defined (inputs/outputs/pre/post/invariants)
- [ ] Error conditions specified
- [ ] Test-Suite issue created
- [ ] Implementation notes documented

### Test-Suite Ready Gate
- [ ] Parent Function linked
- [ ] Contract summary documented
- [ ] Test coverage strategy defined
- [ ] IB test cases planned
- [ ] OOB test cases planned
- [ ] Coverage metrics specified

### Test Ready Gate
- [ ] Test scenario clearly defined
- [ ] Expected behavior documented
- [ ] Test implementation provided
- [ ] Validation executed
- [ ] Results documented

---

## Best Practices

### Naming Conventions

**Features:**
```
FEATURE: <short description>
Example: FEATURE: User Authentication System
```

**Sub-Features:**
```
SUB-FEATURE: <AC summary> [Parent #XXX]
Example: SUB-FEATURE: User Registration Flow [Parent #123]
```

**Functions:**
```
FUNCTION: <function_signature()> [Parent #XXX]
Example: FUNCTION: validate_email(email: string): ValidationResult [Parent #124]
```

**Test-Suites:**
```
TEST-SUITE: <function_name()> Coverage [Parent #XXX]
Example: TEST-SUITE: validate_email() Coverage [Parent #125]
```

**Tests:**
```
TEST: <scenario> [IB/OOB-##] [Parent #XXX]
Example: TEST: validate_email() rejects invalid format [OOB-02] [Parent #126]
```

### Parent Linking

**ALWAYS include parent issue number in:**
- Sub-Feature titles
- Function titles
- Test-Suite titles
- Test titles (if part of suite)

**Format:** `[Parent #123]`

### IB/OOB Classification

**In-Bounds (IB):** Valid inputs, expected happy path behavior
**Out-of-Bounds (OOB):** Invalid inputs, error cases, edge conditions

**Examples:**
- IB-01: Valid email format accepted
- IB-02: Standard ASCII characters processed correctly
- OOB-01: Empty string rejected with error
- OOB-02: Invalid format rejected
- OOB-03: SQL injection attempt blocked

---

## Validation Gates

### Automated Validation (Test template)

Tests include automated validation via GitHub Actions:

1. **Test Execution:** Runs test code
2. **Result Capture:** Captures pass/fail status
3. **Label Update:** Applies `validation: passed/failed/blocked`
4. **Decision Log:** Records attempt in `.ai_logs/`
5. **Pass Tracking:** Increments `ai_pass_count`
6. **Escalation:** Auto-applies `needs-human` if max passes exceeded

### Manual Validation (Other templates)

For Feature/Sub-Feature/Function/Test-Suite:

- Review Ready Gate checklist
- Verify all child issues created
- Confirm parent links are correct
- Check completeness of contracts/criteria

---

## Common Workflows

### Workflow 1: New Feature from Scratch

```
1. Create Feature issue
   - Define user outcome
   - List acceptance criteria (AC1, AC2, AC3)
   - Define success metrics

2. Create Sub-Features (one per AC)
   - Sub-Feature #101: AC1 implementation
   - Sub-Feature #102: AC2 implementation
   - Sub-Feature #103: AC3 implementation

3. For each Sub-Feature, create Functions
   - Sub-Feature #101 → Function #110, #111, #112
   - Sub-Feature #102 → Function #120, #121
   - Sub-Feature #103 → Function #130

4. For each Function, create Test-Suite
   - Function #110 → Test-Suite #115
   - Function #111 → Test-Suite #116
   - etc.

5. Implement and validate
```

### Workflow 2: Standalone Test (No Hierarchy)

```
1. Create Test issue directly
2. Classify as IB or OOB
3. Define scenario and expected behavior
4. Implement test
5. Run validation gate
6. Review results
```

### Workflow 3: Adding Tests to Existing Function

```
1. Find Function issue
2. Find associated Test-Suite (or create if missing)
3. Create new Test issue
4. Link to Test-Suite
5. Implement and validate
```

---

## Template Selection Guide

| Situation | Use This Template |
|-----------|------------------|
| Planning new user-facing capability | **Feature** |
| Implementing one AC from a Feature | **Sub-Feature** |
| Defining specific function/method | **Function** |
| Planning comprehensive test coverage | **Test-Suite** |
| Creating atomic test case | **Test** |
| Bug that doesn't fit hierarchy | **Feature** (Work Type: Bug Fix) |
| Code improvement | **Feature** (Work Type: Improvement) |
| Dev tool or infrastructure | **Feature** (Work Type: Tooling) |

---

## Troubleshooting

### "I created a Feature but can't link Sub-Features"

Sub-Features must be created separately. After creating Sub-Feature issues, edit the Feature and add links in the "Sub-Features" section.

### "The validation gate isn't running"

Check that:
1. The Test issue has the `Type: Test` label
2. The issue body contains "Test Implementation" section with code
3. The repository has validation workflows enabled
4. You've committed test code to the repo

### "My Function issue is missing the contract"

Edit the Function issue and fill in all contract sections:
- Inputs
- Outputs
- Preconditions
- Postconditions
- Invariants

A Function without a complete contract fails the Ready Gate.

### "I don't know if my test is IB or OOB"

Ask:
- Does it test valid input? → **IB**
- Does it test invalid input, errors, or edge cases? → **OOB**

---

## Related Documentation

- [Atomic TDD Framework](../../ATOMIC_TDD_FRAMEWORK.md) - Complete framework specification
- [Label Design Spec](../../LABEL_DESIGN_SPEC.md) - Label taxonomy v1.3
- [Workflow Behavior](../../.github/WORKFLOW_BEHAVIOR.md) - GitHub Actions workflows
- [Decision Log Format](../ai_work/decision_log_format.md) - AI decision logging

---

**Questions?** See [Contributing Guide](../../CONTRIBUTING.md) or open a discussion.
