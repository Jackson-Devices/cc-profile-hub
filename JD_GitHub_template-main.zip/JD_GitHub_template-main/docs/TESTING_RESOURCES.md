# Testing Resources - Documentation URLs & Versions

**Complete reference of official documentation and package versions for testing GitHub Actions and Node.js automation**

**Last Updated**: 2025-11-09

---

## Official Documentation URLs

### GitHub Actions

| Topic                  | URL                                                                                                                                        |
| ---------------------- | ------------------------------------------------------------------------------------------------------------------------------------------ |
| **Main Documentation** | https://docs.github.com/en/actions                                                                                                         |
| **Workflow Syntax**    | https://docs.github.com/en/actions/writing-workflows/workflow-syntax-for-github-actions                                                    |
| **Building & Testing** | https://docs.github.com/en/actions/automating-builds-and-tests                                                                             |
| **Building Node.js**   | https://docs.github.com/en/actions/automating-builds-and-tests/building-and-testing-nodejs                                                 |
| **Matrix Strategy**    | https://docs.github.com/en/actions/writing-workflows/choosing-what-your-workflow-does/running-variations-of-jobs-in-a-workflow             |
| **Security Guides**    | https://docs.github.com/en/actions/security-guides                                                                                         |
| **Using Secrets**      | https://docs.github.com/en/actions/security-guides/using-secrets-in-github-actions                                                         |
| **Examples**           | https://docs.github.com/en/actions/examples                                                                                                |
| **Contexts**           | https://docs.github.com/en/actions/writing-workflows/choosing-what-your-workflow-does/accessing-contextual-information-about-workflow-runs |

### Node.js Testing

| Topic                    | URL                                                       |
| ------------------------ | --------------------------------------------------------- |
| **Test Runner API**      | https://nodejs.org/api/test.html                          |
| **Test Runner Tutorial** | https://nodejs.org/en/learn/test-runner/using-test-runner |
| **Assert Module**        | https://nodejs.org/api/assert.html                        |
| **ESM Modules**          | https://nodejs.org/api/esm.html                           |

### Testing Frameworks

| Framework    | Documentation URL                         | Repository                           |
| ------------ | ----------------------------------------- | ------------------------------------ |
| **Vitest**   | https://vitest.dev                        | https://github.com/vitest-dev/vitest |
| **Jest**     | https://jestjs.io                         | https://github.com/jestjs/jest       |
| **Jest ESM** | https://jestjs.io/docs/ecmascript-modules | -                                    |
| **Mocha**    | https://mochajs.org                       | https://github.com/mochajs/mocha     |

### Validation & Schema

| Tool                    | Documentation                                 | Repository                           |
| ----------------------- | --------------------------------------------- | ------------------------------------ |
| **Ajv**                 | https://ajv.js.org                            | https://github.com/ajv-validator/ajv |
| **Ajv Getting Started** | https://ajv.js.org/guide/getting-started.html | -                                    |
| **Ajv API Reference**   | https://ajv.js.org/api.html                   | -                                    |
| **js-yaml**             | https://github.com/nodeca/js-yaml             | https://github.com/nodeca/js-yaml    |
| **JSON Schema**         | https://json-schema.org                       | -                                    |

### GitHub API & Tools

| Tool                  | Documentation                                   | Repository                               |
| --------------------- | ----------------------------------------------- | ---------------------------------------- |
| **Octokit.js**        | https://octokit.github.io/rest.js               | https://github.com/octokit/octokit.js    |
| **github-script**     | -                                               | https://github.com/actions/github-script |
| **@octokit/fixtures** | https://www.npmjs.com/package/@octokit/fixtures | https://github.com/octokit/fixtures      |
| **GitHub REST API**   | https://docs.github.com/en/rest                 | -                                        |

### Workflow Testing Tools

| Tool                  | Documentation                                                | Repository                              |
| --------------------- | ------------------------------------------------------------ | --------------------------------------- |
| **actionlint**        | https://rhysd.github.io/actionlint/                          | https://github.com/rhysd/actionlint     |
| **actionlint Checks** | https://github.com/rhysd/actionlint/blob/main/docs/checks.md | -                                       |
| **act (nektos)**      | https://nektosact.com                                        | https://github.com/nektos/act           |
| **yamllint**          | https://yamllint.readthedocs.io                              | https://github.com/adrienverge/yamllint |

---

## Package Versions (Current as of 2025-11-09)

### Node.js

- **Current Version**: v25.1.0 (latest)
- **LTS Version**: v22.x (recommended for production)
- **Minimum for Test Runner**: v20.0.0 (stable)
- **Test Runner Stable**: v20.0.0+
- **Experimental Features**: Some features marked experimental in v18-v19

### Testing Packages

```json
{
  "devDependencies": {
    "vitest": "^2.1.0",
    "@vitest/coverage-v8": "^2.1.0",
    "jest": "^29.7.0",
    "mocha": "^10.7.0"
  }
}
```

### Validation Packages

```json
{
  "dependencies": {
    "ajv": "^8.17.1",
    "ajv-formats": "^3.0.1",
    "js-yaml": "^4.1.0"
  }
}
```

### GitHub API Packages

```json
{
  "dependencies": {
    "@octokit/rest": "^21.0.2",
    "@actions/core": "^1.10.1",
    "@actions/github": "^6.0.0"
  },
  "devDependencies": {
    "@octokit/fixtures": "^23.0.0",
    "nock": "^13.5.5"
  }
}
```

---

## GitHub Actions Versions

### Official Actions

| Action                        | Current Version | Repository                                   |
| ----------------------------- | --------------- | -------------------------------------------- |
| **actions/checkout**          | v4              | https://github.com/actions/checkout          |
| **actions/setup-node**        | v4              | https://github.com/actions/setup-node        |
| **actions/github-script**     | v7              | https://github.com/actions/github-script     |
| **actions/upload-artifact**   | v4              | https://github.com/actions/upload-artifact   |
| **actions/download-artifact** | v4              | https://github.com/actions/download-artifact |

### Version Notes

- **github-script v8**: Requires Node 24, runner v2.327.1+
- **github-script v7**: Node 20 (current stable)
- **github-script v5**: Breaking change - REST methods moved to `github.rest.*`

---

## Tool Versions

### actionlint

- **Latest Version**: v1.7.8 (as of 2025-11-09)
- **Installation**:
  ```bash
  go install github.com/rhysd/actionlint/cmd/actionlint@latest
  ```

### act (Local Testing)

- **Latest Release**: Check https://github.com/nektos/act/releases
- **Docker Images**:
  - Micro: `node:16-buster-slim` (<200MB)
  - Medium: `catthehacker/ubuntu:act-latest` (~500MB)
  - Large: `catthehacker/ubuntu:full-latest` (+20GB)

---

## Version-Specific Features

### Node.js Test Runner Timeline

| Version      | Features                        |
| ------------ | ------------------------------- |
| **v25.1.0**  | Latest stable with all features |
| **v22.3.0+** | Snapshot testing stable         |
| **v20.0.0+** | Test runner stable, recommended |
| **v19.2.0+** | Watch mode (experimental)       |
| **v18.0.0+** | Test runner (experimental)      |

### ESM Support Status

| Framework            | ESM Support   | Notes                            |
| -------------------- | ------------- | -------------------------------- |
| **Node Test Runner** | Native        | Best ESM support                 |
| **Vitest**           | Native        | ESM-first design                 |
| **Jest**             | Requires flag | `--experimental-vm-modules`      |
| **Mocha**            | Good          | Via `.mjs` or `"type": "module"` |

---

## Recommended Stack (2025)

### For New Projects

```json
{
  "name": "my-github-automation",
  "type": "module",
  "engines": {
    "node": ">=20.0.0"
  },
  "scripts": {
    "test": "node --test",
    "test:watch": "node --test --watch",
    "test:coverage": "node --test --experimental-test-coverage",
    "validate:workflows": "actionlint",
    "validate:yaml": "yamllint .github/workflows/"
  },
  "devDependencies": {
    "@octokit/rest": "^21.0.2",
    "ajv": "^8.17.1",
    "ajv-formats": "^3.0.1",
    "js-yaml": "^4.1.0"
  }
}
```

### For Existing Projects with Jest

```json
{
  "type": "module",
  "scripts": {
    "test": "node --experimental-vm-modules node_modules/jest/bin/jest"
  },
  "jest": {
    "testEnvironment": "node",
    "transform": {},
    "extensionsToTreatAsEsm": [".js"]
  },
  "devDependencies": {
    "jest": "^29.7.0"
  }
}
```

### For Maximum Performance

```json
{
  "type": "module",
  "scripts": {
    "test": "vitest",
    "test:ui": "vitest --ui",
    "test:coverage": "vitest --coverage"
  },
  "devDependencies": {
    "vitest": "^2.1.0",
    "@vitest/coverage-v8": "^2.1.0"
  }
}
```

---

## Breaking Changes & Migration Guides

### github-script

**v7 → v8**:

- Node 20 → Node 24
- Requires runner v2.327.1+

**v5 → v7**:

- REST API calls: `github.*` → `github.rest.*`
- GraphQL previews: Now only apply to GraphQL

### Jest ESM

**Ongoing requirement** (as of v29.7.0):

- Still requires `--experimental-vm-modules` flag
- Consider Vitest or Node Test Runner for better ESM support

### Node.js Test Runner

**v18 → v20**:

- Test runner moved from experimental to stable
- No breaking changes, just stability improvements

**v19 → v20**:

- Watch mode stabilized
- Performance improvements

---

## Community Resources

### Learning & Tutorials

| Resource                    | URL                                                     |
| --------------------------- | ------------------------------------------------------- |
| **GitHub Actions Examples** | https://github.com/actions/toolkit/tree/main/docs       |
| **Awesome Actions**         | https://github.com/sdras/awesome-actions                |
| **Learn GitHub Actions**    | https://resources.github.com/learn/pathways/automation/ |

### Testing Guides

| Resource                  | URL                                       |
| ------------------------- | ----------------------------------------- |
| **Node.js Testing Guide** | https://nodejs.org/en/learn/test-runner   |
| **Vitest Guide**          | https://vitest.dev/guide/                 |
| **Jest ESM Guide**        | https://jestjs.io/docs/ecmascript-modules |

### GitHub Community

| Resource              | URL                                                     |
| --------------------- | ------------------------------------------------------- |
| **Actions Community** | https://github.community/c/code-to-cloud/github-actions |
| **Discussions**       | https://github.com/orgs/community/discussions           |
| **Changelog**         | https://github.blog/changelog/                          |

---

## Browser/Online Tools

### Testing Playgrounds

| Tool                      | URL                                 | Purpose               |
| ------------------------- | ----------------------------------- | --------------------- |
| **actionlint playground** | https://rhysd.github.io/actionlint/ | Test workflow linting |
| **RunKit (Ajv)**          | https://runkit.com/npm/ajv          | Try Ajv online        |
| **Vitest Playground**     | https://stackblitz.com/edit/vitest  | Try Vitest online     |

### Schema Validators

| Tool                      | URL                                 |
| ------------------------- | ----------------------------------- |
| **JSON Schema Validator** | https://www.jsonschemavalidator.net |
| **YAML Lint**             | https://www.yamllint.com            |

---

## CI/CD Integration Examples

### GitHub Actions Workflow for Testing

```yaml
name: Test Suite

on:
  push:
    branches: [main]
  pull_request:

jobs:
  validate:
    name: Validate Workflows
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v4

      - name: Install actionlint
        run: |
          bash <(curl https://raw.githubusercontent.com/rhysd/actionlint/main/scripts/download-actionlint.bash)

      - name: Run actionlint
        run: ./actionlint -color

  test:
    name: Test (Node ${{ matrix.node }})
    runs-on: ubuntu-latest
    strategy:
      matrix:
        node: [20, 22]
    steps:
      - uses: actions/checkout@v4

      - uses: actions/setup-node@v4
        with:
          node-version: ${{ matrix.node }}
          cache: 'npm'

      - run: npm ci
      - run: npm test

  coverage:
    name: Code Coverage
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v4

      - uses: actions/setup-node@v4
        with:
          node-version: 20
          cache: 'npm'

      - run: npm ci
      - run: npm run test:coverage
```

---

## Quick Command Reference

### Install Tools

```bash
# actionlint
go install github.com/rhysd/actionlint/cmd/actionlint@latest

# act
brew install act  # macOS
scoop install act # Windows

# yamllint
pip install yamllint

# Node.js (via nvm)
nvm install 20
nvm use 20
```

### Validate Workflows

```bash
# With actionlint
actionlint

# With yamllint
yamllint .github/workflows/

# Test locally with act
act -n  # dry run
act     # run workflows
```

### Run Tests

```bash
# Node.js native
node --test
node --test --watch
node --test --experimental-test-coverage

# Vitest
vitest
vitest --ui
vitest --coverage

# Jest with ESM
node --experimental-vm-modules node_modules/jest/bin/jest
```

---

## Version Compatibility Matrix

| Node.js | Test Runner     | Vitest   | Jest      | github-script |
| ------- | --------------- | -------- | --------- | ------------- |
| v25.x   | ✅ Stable       | ✅ v2.1+ | ✅ v29.7+ | ✅ v8         |
| v22.x   | ✅ Stable       | ✅ v2.1+ | ✅ v29.7+ | ✅ v7         |
| v20.x   | ✅ Stable       | ✅ v2.0+ | ✅ v29.0+ | ✅ v7         |
| v18.x   | ⚠️ Experimental | ✅ v1.0+ | ✅ v29.0+ | ✅ v6         |

---

## Security Advisories

Always check for security updates:

- **GitHub Actions**: https://github.com/advisories
- **npm packages**: `npm audit`
- **Node.js**: https://nodejs.org/en/blog/vulnerability/

---

## Updates & Changelog

### Subscribe to Updates

- **GitHub Actions Blog**: https://github.blog/changelog/label/actions/
- **Node.js Releases**: https://nodejs.org/en/blog/release/
- **Vitest Releases**: https://github.com/vitest-dev/vitest/releases
- **Jest Releases**: https://github.com/jestjs/jest/releases

### Check Package Versions

```bash
# Check installed versions
npm list --depth=0

# Check for outdated packages
npm outdated

# Update packages
npm update

# Update to latest (breaking changes)
npm install package@latest
```

---

**This document is maintained as part of the JD GitHub Template project.**
**For updates, see**: https://github.com/Jackson-Devices/JD_GitHub_template
