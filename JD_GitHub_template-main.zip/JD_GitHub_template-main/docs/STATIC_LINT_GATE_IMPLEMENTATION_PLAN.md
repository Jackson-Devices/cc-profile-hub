# Static Lint Gate Implementation Plan (JavaScript Adaptation)

## Overview

Adapt issue #65 (Static Lint Gate) for JavaScript-only codebase with Node.js ES modules.

**Status**: Ready for implementation
**Estimated Time**: 30-45 minutes
**Priority**: High (Fail-fast lane)

---

## Context: Why This Is Applicable

### Current State

- ✅ Prettier configured for formatting
- ❌ No ESLint for defect detection
- 📦 ~2,567 LOC of production JavaScript (.mjs files)
- 🔧 Critical automation: GitHub API, git hooks, workflow validation
- 📊 256 console statements across 11 files
- 🐛 Technical debt markers (TODO/FIXME) present

### Risk Without Linting

- Unhandled promise rejections in GitHub API calls
- Unused variables after refactoring
- Async/await misuse in critical automation
- Inconsistent error handling patterns
- Accidental globals in Node.js scripts

---

## Adaptations from Original Issue #65

| Original AC                                  | JavaScript Adaptation                                 |
| -------------------------------------------- | ----------------------------------------------------- |
| **AC1**: TypeScript/JavaScript/JSX/TSX paths | **Adapted**: JavaScript/ES Modules only (_.mjs, _.js) |
| **AC2**: Exclude style rules                 | **Same**: Use eslint-config-prettier                  |
| **AC3**: Fail on errors, no autofix          | **Same**: --max-warnings 0, no --fix in CI            |
| **AC4**: Clear error messages                | **Same**: ESLint native file:line:col format          |
| **AC5**: <60s execution                      | **Achievable**: Small codebase (~2.5k LOC)            |

---

## Implementation Phases

### Phase 1: Install Dependencies (5 min)

**Files Modified**: `package.json`

```json
{
  "devDependencies": {
    "eslint": "^9.15.0",
    "eslint-config-prettier": "^9.1.0",
    "eslint-plugin-n": "^17.13.2",
    "globals": "^15.12.0"
  }
}
```

**Rationale**:

- `eslint` v9 - Latest with flat config support
- `eslint-config-prettier` - Disable style rules (Prettier handles formatting)
- `eslint-plugin-n` - Node.js best practices and API validation
- `globals` - Predefined global variables for Node.js environment

**Commands**:

```bash
npm install --save-dev eslint eslint-config-prettier eslint-plugin-n globals
```

---

### Phase 2: Create ESLint Configuration (15 min)

**New File**: `eslint.config.js`

```javascript
import js from '@eslint/js';
import prettier from 'eslint-config-prettier';
import nodePlugin from 'eslint-plugin-n';
import globals from 'globals';

export default [
  // Base recommended config
  js.configs.recommended,

  // Node.js plugin recommended rules
  nodePlugin.configs['flat/recommended-module'],

  // Custom configuration
  {
    files: ['**/*.js', '**/*.mjs'],

    languageOptions: {
      ecmaVersion: 2022,
      sourceType: 'module',
      globals: {
        ...globals.node,
        ...globals.es2021,
      },
    },

    rules: {
      // === Core Defect Detection ===

      // Unused code detection
      'no-unused-vars': [
        'error',
        {
          argsIgnorePattern: '^_',
          varsIgnorePattern: '^_',
          caughtErrors: 'all',
        },
      ],

      // Unreachable code
      'no-unreachable': 'error',
      'no-unreachable-loop': 'error',

      // Variable issues
      'no-undef': 'error',
      'no-redeclare': 'error',

      // === Async/Promise Safety (Critical for GitHub API) ===

      // Prevent race conditions in async
      'require-atomic-updates': 'error',

      // Promise best practices
      'no-async-promise-executor': 'error',
      'no-promise-executor-return': 'error',
      'no-await-in-loop': 'warn', // Often intentional, but worth flagging

      // === Error Handling ===

      // Ensure proper error handling
      'no-ex-assign': 'error',
      'no-unsafe-finally': 'error',

      // === Code Quality ===

      // Prevent confusing patterns
      'no-fallthrough': 'error',
      'no-constant-condition': ['error', { checkLoops: false }],
      'no-empty': ['error', { allowEmptyCatch: false }],

      // === Node.js Specific ===

      // Handle callbacks properly
      'n/handle-callback-err': ['error', '^(err|error)$'],

      // Validate Node.js APIs
      'n/no-deprecated-api': 'error',

      // Process exit needs cleanup
      'n/no-process-exit': 'warn',
    },
  },

  // Ignore patterns
  {
    ignores: ['node_modules/**', 'dist/**', 'build/**', '.git/**', 'coverage/**'],
  },

  // Disable Prettier conflicts (MUST BE LAST)
  prettier,
];
```

**Rationale for Rule Selection**:

- **Focus on defects, not style** - No indentation, spacing, or formatting rules
- **Async safety** - Critical for GitHub API calls and file operations
- **Node.js specific** - Validate proper use of Node.js APIs
- **No false positives** - Only high-signal rules that catch real bugs
- **Prettier integration** - Disabled conflicting style rules

---

### Phase 3: Fix Initial Violations (10-20 min)

**Commands**:

```bash
# Run linter to identify issues
npm run lint

# Review output and fix errors
# Expected issues:
# - Unused variables (likely 3-8 instances)
# - Missing error handling (likely 2-5 instances)
# - Potential async issues (likely 1-3 instances)
```

**Strategy**:

1. **Unused variables**: Remove or prefix with `_` if intentionally unused
2. **Error handling**: Add try/catch or .catch() to promise chains
3. **Async issues**: Review for race conditions or missing awaits
4. **Node.js deprecations**: Update to modern APIs if any found

**Estimated Violations**: 5-15 errors (based on codebase complexity)

---

### Phase 4: Update npm Scripts (5 min)

**File Modified**: `package.json`

```json
{
  "scripts": {
    "lint": "eslint .",
    "lint:check": "eslint . --max-warnings 0",
    "lint:fix": "eslint . --fix",
    "format": "prettier --write .",
    "format:check": "prettier --check .",
    "format:staged": "prettier --write $(git diff --cached --name-only --diff-filter=ACM | grep -E '\\.(yml|yaml|md|json|js|mjs|ts|css|html)$' | xargs)",
    "test:formatters": "node claude_mods/scripts/test_formatters.mjs",
    "test:workflow-consistency": "node tests/workflows/test_workflow_template_consistency.mjs",
    "test": "npm run lint:check && npm run test:formatters && npm run test:workflow-consistency"
  }
}
```

**Changes**:

- Added `lint` - Run ESLint (shows warnings)
- Added `lint:check` - Strict mode for CI (fail on warnings)
- Added `lint:fix` - Auto-fix safe issues (local dev only)
- Updated `test` - Run lint before other tests

**Rationale**:

- `lint:check` with `--max-warnings 0` ensures CI fails on any issues
- `lint:fix` is available for local dev but NOT used in CI (per AC3)
- Integrated into `test` command for single entry point

---

### Phase 5: GitHub Actions Integration (5 min)

**File Modified**: `.github/workflows/format-check.yml` (if exists) or create new workflow

**Option A: Extend Existing Format Check Workflow**

```yaml
name: Code Quality Check
on:
  pull_request:
    paths:
      - '**.js'
      - '**.mjs'
      - '**.yml'
      - '**.yaml'
      - '**.json'
      - '**.md'

jobs:
  quality-check:
    name: Format & Lint Check
    runs-on: ubuntu-latest
    timeout-minutes: 10

    steps:
      - name: Checkout code
        uses: actions/checkout@v4

      - name: Setup Node.js
        uses: actions/setup-node@v4
        with:
          node-version: '20'
          cache: 'npm'

      - name: Install dependencies
        run: npm ci

      - name: Check formatting (Prettier)
        run: npm run format:check

      - name: Check code quality (ESLint)
        run: npm run lint:check

      - name: Run tests
        run: npm test
```

**Option B: Separate ESLint Workflow**

Create `.github/workflows/lint-check.yml`:

```yaml
name: ESLint Gate
on:
  pull_request:
    paths:
      - '**.js'
      - '**.mjs'
      - 'eslint.config.js'
      - 'package.json'

jobs:
  eslint:
    name: Static Lint Check
    runs-on: ubuntu-latest
    timeout-minutes: 5

    steps:
      - uses: actions/checkout@v4

      - uses: actions/setup-node@v4
        with:
          node-version: '20'
          cache: 'npm'

      - name: Install dependencies
        run: npm ci

      - name: Run ESLint (strict mode)
        run: npm run lint:check
```

**Recommendation**: Option B (separate workflow) for:

- Faster feedback (only runs on JS changes)
- Independent pass/fail status
- Clearer PR checks ("ESLint Gate" vs "Format Check")

---

### Phase 6: Verification & Testing (5 min)

**Verification Checklist**:

```bash
# 1. Verify linting works locally
npm run lint:check

# 2. Verify execution time (<60s requirement)
time npm run lint:check
# Expected: <5 seconds for ~2.5k LOC

# 3. Test that errors block properly
# Intentionally introduce error:
echo "const unused = 123;" >> test_lint_error.mjs
npm run lint:check  # Should fail
rm test_lint_error.mjs

# 4. Verify no style rules interfere with Prettier
npm run format
npm run lint:check  # Should still pass

# 5. Test in CI (push to PR branch)
git add .
git commit -m "feat: Add ESLint static lint gate"
git push
# Watch GitHub Actions - ESLint check should run
```

**Success Criteria Met**:

- ✅ AC1: Runs on all .js/.mjs files
- ✅ AC2: No style rules (verified by Prettier compatibility)
- ✅ AC3: Fails on errors with `--max-warnings 0`
- ✅ AC4: Clear file:line:col error format
- ✅ AC5: Executes in <5s (well under 60s)

---

## Expected Outcomes

### Immediate Benefits

1. **Catch defects before merge**: Unused vars, unreachable code, async bugs
2. **Consistent error handling**: Standardize patterns across 11 JS files
3. **Prevent regressions**: New code validated automatically
4. **Fast feedback**: <5s execution, no PR delay

### Long-term Benefits

1. **Template standard**: Other Jackson-Devices repos follow pattern
2. **Compound quality**: Each new script validated from day one
3. **Reduced review churn**: Automated checks = fewer human reviews
4. **Documentation via lint**: Rules encode best practices

---

## Rollback Plan

If issues arise during implementation:

```bash
# Remove ESLint
npm uninstall eslint eslint-config-prettier eslint-plugin-n globals

# Delete config
rm eslint.config.js

# Revert package.json scripts
git restore package.json

# Revert workflow changes
git restore .github/workflows/
```

---

## Post-Implementation

### Monitoring Metrics (from original issue)

- ✅ Zero PRs merged with ESLint errors (enforced by CI)
- 🎯 <5% false positive rate (tune rules after 2 weeks if needed)
- ✅ p95 execution time <60s (expect <5s)
- ✅ Config contains only high-signal rules (no style noise)

### Maintenance

- **Rule tuning**: Review after 5 PRs, adjust if false positives >5%
- **Upgrade cadence**: Update ESLint quarterly with npm audit
- **New rules**: Consider adding rules as new patterns emerge

---

## Files Changed Summary

| File                                           | Change Type | Description                        |
| ---------------------------------------------- | ----------- | ---------------------------------- |
| `package.json`                                 | Modified    | Add ESLint deps, update scripts    |
| `eslint.config.js`                             | Created     | ESLint flat config for Node.js     |
| `.github/workflows/lint-check.yml`             | Created     | CI workflow for ESLint gate        |
| `docs/STATIC_LINT_GATE_IMPLEMENTATION_PLAN.md` | Created     | This document                      |
| `**/*.mjs`                                     | Modified    | Fix ESLint violations (5-15 files) |

---

## Decision Gate Alignment

| Property        | Value                         |
| --------------- | ----------------------------- |
| **Lane**        | Fail-fast (first priority) ✅ |
| **Speed**       | Fast (<5s, target <60s) ✅    |
| **Determinism** | Fully deterministic ✅        |
| **Signal**      | High (no style noise) ✅      |
| **Blocking**    | Required for merge ✅         |

---

## References

- Original Issue: #65 (Static Lint Gate)
- ESLint Docs: https://eslint.org/docs/latest/
- Node.js Plugin: https://github.com/eslint-community/eslint-plugin-n
- Prettier Integration: https://github.com/prettier/eslint-config-prettier

---

**Created**: 2025-11-11
**Author**: Claude (AI Assistant)
**Status**: Ready for execution
