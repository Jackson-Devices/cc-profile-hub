# File Tracking Plan - When to Add Untracked Files

**Last Updated:** 2025-11-10
**Purpose:** Track which files should be committed when, preventing forgotten documentation

---

## 🟢 TRACKED & UP TO DATE

These files are already committed and current:

- ✅ `current_work_todo.md` - P0.1 completion tracked (commit 8c9ccb5)
- ✅ `even_more_todo.md` - Label implementation status tracked (commit 8c9ccb5)
- ✅ `LABEL_DESIGN_SPEC.md` - Updated to v1.3 (commit 811616a)
- ✅ `.github/settings.yml` - 36 labels (commit 811616a)
- ✅ All other core files (README.md, issues_rules.md, TODO.md, etc.)

---

## 🟡 NEEDS UPDATING (Already Tracked)

These files are tracked but contain outdated information:

### `TODO.md`

- **Status:** Tracked, needs update
- **Issue:** Still shows "34 issue labels" (should be 36)
- **Update needed:**
  - Change label count to 36
  - Update "Current Status" section with P0.1 completion
  - Add P0.2 as next priority
- **When:** Before starting P0.2 (issue templates)
- **Priority:** P0.1.1 (cleanup task)

### `TODO_REVIEW_AND_LOGGING_PLAN.md`

- **Status:** Tracked, check if needs update
- **Action:** Review for any P0.1-related updates needed
- **When:** With TODO.md update
- **Priority:** P0.1.1 (cleanup task)

---

## 🔴 UNTRACKED - ADD WHEN CREATING ISSUE #26 SUB-FEATURES (P2.1)

These files support the testing infrastructure (issue #26) but should NOT be committed until we create the actual sub-feature issues:

### `.github/ISSUE_TESTING_INFRASTRUCTURE.md`

- **Status:** Untracked
- **Purpose:** Issue body for #26 (testing infrastructure)
- **When to add:** When creating issue #26's first sub-feature issue
- **Why wait:** This is the parent feature description; commit when breaking down into atomic sub-features
- **Priority:** P2.1 Task 1 (after P0.2 templates exist)
- **Related:** Issue #26

### `RESEARCH_GITHUB_ACTIONS_TESTING.md`

- **Status:** Untracked
- **Purpose:** Research findings for testing infrastructure
- **When to add:** With `.github/ISSUE_TESTING_INFRASTRUCTURE.md`
- **Why wait:** Supporting documentation for issue #26 breakdown
- **Priority:** P2.1 Task 1
- **Related:** Issue #26

### `docs/TESTING_GUIDE.md`

- **Status:** Untracked (10,000+ words)
- **Purpose:** Comprehensive testing guide for GitHub Actions workflows
- **When to add:** When creating first testing-related sub-feature
- **Why wait:** Implementation guide; commit when starting actual test implementation
- **Priority:** P2.1 Task 2 (after extracting validation logic to testable modules)
- **Related:** Issue #26, sub-features for unit tests

### `docs/TESTING_QUICK_REFERENCE.md`

- **Status:** Untracked
- **Purpose:** Quick reference for testing patterns
- **When to add:** With `docs/TESTING_GUIDE.md`
- **Why wait:** Supporting documentation for testing work
- **Priority:** P2.1 Task 2

### `docs/PROJECT_TESTING_EXAMPLES.md`

- **Status:** Untracked
- **Purpose:** Project-specific testing examples
- **When to add:** With `docs/TESTING_GUIDE.md`
- **Why wait:** Examples specific to this project's testing approach
- **Priority:** P2.1 Task 2

### `docs/TESTING_RESOURCES.md`

- **Status:** Untracked
- **Purpose:** External testing resources and URLs
- **When to add:** With `docs/TESTING_GUIDE.md`
- **Why wait:** Reference material for testing implementation
- **Priority:** P2.1 Task 2

---

## 📋 COMMIT STRATEGY

### Immediate (P0.1.1 - Cleanup)

**When:** Now (before starting P0.2)
**Files:**

- `TODO.md` (update label count, current status)
- `TODO_REVIEW_AND_LOGGING_PLAN.md` (if needed)

**Commit message:**

```
docs: Update TODO.md with P0.1 completion and label count (36)

- Update label count from 34 to 36
- Document P0.1 completion (label taxonomy)
- Mark P0.2 as next priority (issue templates)
```

### P2.1 Task 1 - Testing Infrastructure Issue Breakdown

**When:** After P0.2 complete (templates exist) AND before creating first test sub-feature
**Files:**

- `.github/ISSUE_TESTING_INFRASTRUCTURE.md`
- `RESEARCH_GITHUB_ACTIONS_TESTING.md`

**Commit message:**

```
docs: Add testing infrastructure research and issue template

Comprehensive research and planning for synthetic testing infrastructure
(Issue #26). Includes 30-task implementation plan across 3 phases.

Supporting documentation for breaking down issue #26 into atomic
sub-features following the new hierarchy templates.
```

### P2.1 Task 2 - Testing Documentation

**When:** When creating first unit test sub-feature issue
**Files:**

- `docs/TESTING_GUIDE.md`
- `docs/TESTING_QUICK_REFERENCE.md`
- `docs/PROJECT_TESTING_EXAMPLES.md`
- `docs/TESTING_RESOURCES.md`

**Commit message:**

```
docs: Add comprehensive testing guides for GitHub Actions workflows

Complete testing documentation suite:
- 10,000+ word comprehensive guide
- Quick reference for testing patterns
- Project-specific examples
- External resources and URLs

Supports implementation of unit tests for validation workflows
(Issue #26 sub-features).
```

---

## 🎯 CHECKLIST FOR COMMIT GATES

Before committing any file, verify:

- [ ] **File is referenced in current_work_todo.md priority section**
- [ ] **Corresponding issue/sub-feature exists (for implementation docs)**
- [ ] **Templates exist if file describes hierarchy (for issue bodies)**
- [ ] **No WIP/TODO markers in file unless intentional**
- [ ] **File follows house style (will be auto-formatted by pre-commit hook)**
- [ ] **Commit message follows conventional commits format**
- [ ] **Co-Authored-By: Claude line present**

---

## 📝 NOTES

**Why not commit everything now?**

1. Testing docs support P2.1 work - committing early creates "abandoned docs"
2. Issue #26 body should be committed when we break it down (shows workflow)
3. Atomic commits that match atomic work phases aid git history clarity
4. Prevents merge conflicts if templates change during P0.2

**Exception cases:**

- If user explicitly requests committing a file, do it (document reason in commit message)
- If file blocks current work, commit immediately
- If file referenced by committed work, commit together

---

**For AI Review Plugin:** Read this file to understand commit strategy and file tracking status.
