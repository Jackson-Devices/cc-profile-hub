# Intelligent Commit Splitting

## Overview

The Intelligent Commit Splitting system automatically analyzes commits on a branch to determine if they should be squashed together or split across separate branches. This provides **automatic remediation** for the "multiple_features" error that previously required manual intervention.

## Key Features

### 1. **Diff-Based Analysis**
- Analyzes actual file changes, not just commit messages
- Examines which files/directories each commit touches
- Calculates change size (insertions + deletions)

### 2. **Semantic Understanding**
- Recognizes conventional commit types (`feat`, `fix`, `docs`, etc.)
- Extracts scopes and feature areas
- Groups related changes intelligently

### 3. **Similarity Scoring**
- Calculates similarity between commits based on:
  - Commit type (30% weight)
  - Scope overlap (20% weight)
  - File/directory overlap (40% weight)
  - Specific file changes (10% weight)
- Threshold: 60% similarity to group commits

### 4. **Intelligent Decision Making**
- **SQUASH**: Related commits (same feature, fixes, tests)
- **SPLIT**: Multiple unrelated features
- **KEEP AS-IS**: Large refactors, merge commits

## How It Works

### Workflow Integration

```yaml
# .github/workflows/auto-squash-commits.yml
- name: Run intelligent commit analysis
  run: node scripts/split-commits-intelligently.mjs
```

### Exit Codes

| Code | Meaning | Action |
|------|---------|--------|
| 0 | No action needed | Single commit or no changes |
| 1 | Needs squash | All commits are related - squash them |
| 2 | Needs split | Multiple features - consider splitting |
| 3 | Error | Analysis failed |

### Decision Logic

#### Example 1: Related Commits → SQUASH
```
✅ Commits:
  - feat: add user authentication
  - test: add auth tests
  - fix: handle edge case in login

→ Decision: SQUASH (all related to auth feature)
```

#### Example 2: Unrelated Features → SPLIT
```
❌ Commits:
  - feat: add user authentication
  - feat: implement dashboard
  - feat: add payment processing

→ Decision: SPLIT (3 distinct features)
```

#### Example 3: Feature + Docs → SQUASH
```
✅ Commits:
  - feat: add authentication
  - docs: update README with auth guide

→ Decision: SQUASH (docs related to feature)
```

## Usage

### Manual Analysis

Run the script manually to analyze a branch:

```bash
# From the repository root
node scripts/split-commits-intelligently.mjs
```

### Test Suite

Run the comprehensive test suite:

```bash
npm run test:commit-splitter
```

### In GitHub Actions

The script runs automatically when:
1. You push to a `claude/**` branch
2. Auto-squash workflow triggers
3. Multiple commits are detected

## Configuration

### Thresholds (in `split-commits-intelligently.mjs`)

```javascript
const SIMILARITY_THRESHOLD = 0.6;      // 60% similarity to group
const LARGE_CHANGE_THRESHOLD = 1000;   // Lines for "large" change
const MAX_FEATURE_GROUPS = 3;          // Max features before split
```

### Commit Type Weights

```javascript
const COMMIT_TYPES = {
  feat: { weight: 1.0 },      // Major features
  fix: { weight: 0.8 },       // Bug fixes
  refactor: { weight: 0.9 },  // Code improvements
  docs: { weight: 0.3 },      // Documentation only
  test: { weight: 0.5 },      // Tests only
  // ...
};
```

## Fault Tolerance

### Status Check Failures
When GitHub API status checks fail:
- **Old behavior**: Block with "multiple_features" error
- **New behavior**: Assume previous failures may have occurred, be lenient

```javascript
// scripts/check-sequential-commits.mjs
if (statusChecksFailed && previousCommits.length > 0) {
  console.log('⚠️  Could not verify all commit statuses via GitHub API');
  console.log('💡 Being lenient - assuming previous commits may have had failures');
  hasPreviousFailures = true;
}
```

## Examples from Tests

### Test 1: Group by Directory
```javascript
// Commits touching same directory are related
commit1: ['src/auth/login.js', 'src/auth/register.js']
commit2: ['src/auth/logout.js']

→ Both touch src/auth → GROUP TOGETHER
```

### Test 2: Separate Features
```javascript
commit1: ['src/auth/login.js']        // Authentication
commit2: ['src/dashboard/Dashboard.js'] // Dashboard
commit3: ['src/payments/checkout.js']   // Payments

→ Three distinct areas → RECOMMEND SPLIT
```

### Test 3: Feature + Tests
```javascript
commit1: ['src/auth/login.js']          // Implementation
commit2: ['tests/auth/login.test.js']   // Tests

→ Implementation + tests → GROUP TOGETHER
```

## TDD Approach

This feature was developed using Test-Driven Development:

1. ✅ **Red Phase**: Wrote 21 comprehensive tests first
2. ✅ **Green Phase**: Implemented logic to pass all tests
3. ✅ **Refactor Phase**: Integrated with workflows

```bash
# All tests pass
npm run test:commit-splitter
# ✓ 21 tests, 6 suites
```

## Benefits

### Before
```
❌ BLOCKED: Multiple feature commits detected

OPTIONS:
1. Manually create new branch
2. Manually squash
3. Manually reorganize

→ Requires user intervention
```

### After
```
🧠 INTELLIGENT ANALYSIS

✅ Analysis complete
   - Option 1: Auto-squash (if related)
   - Option 2: Recommendations for split (if unrelated)
   - Option 3: Detailed reasoning in logs

→ Self-healing workflow
```

## Output Example

```
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
🧠 Intelligent Commit Analysis
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

📍 Base branch: main

📊 Total commits to analyze: 3

📋 Analyzing commit details:

  abc1234 [feat] add user authentication
    📁 Area: src/auth
    📝 Files: 3, Changes: +120/-5

  def5678 [test] add auth tests
    📁 Area: tests/auth
    📝 Files: 1, Changes: +45/-0

  ghi9012 [fix] handle login edge case
    📁 Area: src/auth
    📝 Files: 1, Changes: +15/-3

🔍 Grouping related commits...

📦 Found 1 feature group(s):

  Group 1: 3 commit(s)
    Types: feat, test, fix
    Areas: src/auth, tests/auth
    Commits: abc1234, def5678, ghi9012

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
💡 Decision Analysis
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

✅ All commits are related to the same feature

📋 Recommendation: SQUASH

   All commits can be combined into a single commit

📝 Suggested commit message:
   feat: add user authentication

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
📊 Final Result
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

Action: squash
Reason: single_feature_group
Confidence: 95%
```

## Related Files

- **Script**: `scripts/split-commits-intelligently.mjs`
- **Tests**: `tests/workflows/split-commits-intelligently.test.mjs`
- **Workflow**: `.github/workflows/auto-squash-commits.yml`
- **Checker**: `scripts/check-sequential-commits.mjs` (updated for fault tolerance)

## See Also

- [Sequential Commit Prevention](./SEQUENTIAL_COMMIT_PREVENTION.md)
- [Auto-Squash Workflow](../.github/workflows/auto-squash-commits.yml)
