# Issue Hierarchy Examples

**Purpose:** Concrete examples of the 5-level atomic hierarchy with labels and relationships

---

## The 5-Level Hierarchy

```
1. Feature (top-level parent, user outcome)
     ↓
2. Sub-Feature (implements one acceptance criterion)
     ↓
3. Function (implementation unit with formal contract)
     ↓
4. Test-Suite (organizes IB/OOB tests for one function)
     ↓
5. Test-Case (individual IB or OOB test)
```

**Key Principle:** Work flows downward (Feature defines ACs → Sub-Features implement them → Functions realize the work → Test-Suites validate → Test-Cases prove correctness).

---

## Label Application Rules

### Work Type Labels (type:)

Applied to **parent-level** (Feature) and **implementation units** (Function, Test):

| Issue Type  | Label Applied                                                                           | Why                                     |
| ----------- | --------------------------------------------------------------------------------------- | --------------------------------------- |
| Feature     | `type:feature` OR `type:bug` OR `type:improvement` OR `type:refactor` OR `type:tooling` | User selects work type                  |
| Sub-Feature | NONE                                                                                    | Inherits work type from parent Feature  |
| Function    | `type:function`                                                                         | Function is an implementation work type |
| Test-Suite  | NONE                                                                                    | Test-Suite is an organizer, not work    |
| Test        | `type:test`                                                                             | Test is an implementation work type     |

### Role Labels (role:)

Applied to **organizational** issues (Sub-Feature, Test-Suite):

| Issue Type  | Label Applied      | Why                              |
| ----------- | ------------------ | -------------------------------- |
| Feature     | NONE               | Top-level parent, no role        |
| Sub-Feature | `role:sub-feature` | Organizes functions for one AC   |
| Function    | NONE               | Function is work type, not role  |
| Test-Suite  | `role:test suite`  | Organizes tests for one function |
| Test        | NONE               | Test is work type, not role      |

**Summary:** Parent issues and implementation units get `type:` labels. Organizational issues get `role:` labels.

---

## Example 1: Email Validation Feature (Complete Hierarchy)

### Level 1: Feature

```
Issue #100: User Email Validation System
Labels: Type: Feature, Workflow: Backlog
(Note: Initially ALL Level 1 issues get ONLY Type + Workflow: Backlog. No Difficulty, AI, or other labels at this level.)

User Outcome:
As a user registration system, I want to validate email addresses
so that only valid emails are accepted and invalid ones are rejected early.

Acceptance Criteria:
- AC1: System validates email format per RFC 5322
- AC2: System checks domain has valid MX records
- AC3: System provides clear error messages for invalid emails

Success Metrics:
- Test coverage ≥95% for validation logic
- Performance: Validation completes in <50ms (p95)
- Security: Zero false positives on valid emails
```

### Level 2: Sub-Features (one per AC)

#### Sub-Feature for AC1

```
Issue #200: Email Format Validation (AC1)
Parent: #100 (User Email Validation System)
Labels: Role: Sub-Feature, Type: Feature (inherited), Workflow: Backlog
(Note: Level 2 gets Role + inherited Type + Workflow. NO Difficulty or AI at this level.)

Acceptance Criterion: AC1: System validates email format per RFC 5322

Functions Needed:
- FN: validate_email_format(email) - Check RFC 5322 compliance
- FN: normalize_email(email) - Lowercase and trim whitespace
- FN: extract_domain(email) - Parse domain from email string

Test Coverage: IB≥1, OOB≥2 per function
```

#### Sub-Feature for AC2

```
Issue #210: Domain MX Record Validation (AC2)
Parent: #100 (User Email Validation System)
Labels: Role: Sub-Feature, Type: Feature (inherited), Workflow: Backlog

Acceptance Criterion: AC2: System checks domain has valid MX records

Functions Needed:
- FN: check_domain_mx(domain) - Query DNS for MX records
- FN: cache_domain_result(domain, result) - Cache for 5 minutes

Test Coverage: IB≥1, OOB≥2 per function
```

### Level 3: Functions (implementation units)

#### Function for validate_email_format()

```
Issue #300: validate_email_format() Function
Parent: #200 (Email Format Validation)
Labels: Type: Function, Type: Feature (inherited), Workflow: Backlog, Difficulty: Easy, AI: Supervised
Auto-applied: Needs-Human
(Note: Level 3 is where Difficulty and AI classification begins. Function gets its own Type: Function plus inherited Type.)

Function: validate_email_format(email: string): ValidationResult

Contract:
  Inputs:
    - email: string (0-254 chars, any UTF-8)
  Outputs:
    - VALID (0): Email matches RFC 5322
    - INVALID_LOCAL (1): Local part malformed
    - INVALID_DOMAIN (2): Domain part malformed
    - INVALID_FORMAT (3): Overall structure invalid
  Invariants:
    - Never modifies input
    - Thread-safe, deterministic
    - No exceptions thrown
  Preconditions:
    - email not null, valid UTF-8
  Postconditions:
    - If VALID: email syntactically correct
    - No memory leaks

Test Suite: #400
```

#### Function for check_domain_mx()

```
Issue #310: check_domain_mx() Function
Parent: #210 (Domain MX Record Validation)
Labels: type:function, difficulty:moderate
Status: workflow:pending

Function: check_domain_mx(domain: string): MXResult

Contract:
  Inputs:
    - domain: string (valid domain format)
  Outputs:
    - HAS_MX (0): Domain has valid MX records
    - NO_MX (1): Domain exists but no MX records
    - DOMAIN_NOT_FOUND (2): Domain doesn't exist
    - DNS_ERROR (3): DNS query failed
  Invariants:
    - Thread-safe, uses connection pool
    - Results cached for 5 minutes
  Preconditions:
    - domain not null, valid format
    - Network available
  Postconditions:
    - Cache updated on success
    - Timeout after 3 seconds

Test Suite: #410
```

### Level 4: Test-Suites (one per function)

#### Test-Suite for validate_email_format()

```
Issue #400: validate_email_format() Test Suite
Parent: #300 (validate_email_format Function)
Labels: Role: Test-Suite, Type: Feature (inherited), Workflow: Backlog
(Note: Level 4 is an organizer like Level 2. Gets Role + inherited Type + Workflow. NO Difficulty/AI.)

Coverage Target: IB=3, OOB=5 (exceeds minimum IB≥1, OOB≥2)

Test Cases:
  In-Bounds (valid inputs):
    - Test #501: IB-01: Valid Gmail address returns VALID [T-501]
    - Test #502: IB-02: Valid corporate domain returns VALID [T-502]
    - Test #503: IB-03: Valid intl email with unicode returns VALID [T-503]

  Out-of-Bounds (edge/error cases):
    - Test #601: OOB-01: Missing @ symbol returns INVALID_FORMAT [T-601]
    - Test #602: OOB-02: Multiple @ symbols returns INVALID_FORMAT [T-602]
    - Test #603: OOB-03: Empty string returns INVALID_FORMAT [T-603]
    - Test #604: OOB-04: Null input violates precondition [T-604]
    - Test #605: OOB-05: 300-char email exceeds max [T-605]
```

#### Test-Suite for check_domain_mx()

```
Issue #410: check_domain_mx() Test Suite
Parent: #310 (check_domain_mx Function)
Labels: role:test suite, difficulty:moderate
Status: workflow:pending

Coverage Target: IB=2, OOB=4 (exceeds minimum)

Test Cases:
  In-Bounds:
    - Test #511: IB-01: gmail.com has MX records [T-511]
    - Test #512: IB-02: Corporate domain has MX [T-512]

  Out-of-Bounds:
    - Test #611: OOB-01: Domain exists but no MX [T-611]
    - Test #612: OOB-02: Domain doesn't exist [T-612]
    - Test #613: OOB-03: Network timeout [T-613]
    - Test #614: OOB-04: Null domain input [T-614]
```

### Level 5: Test-Cases (individual tests)

#### Example Test-Case (IB-01 for validate_email_format)

```
Issue #501: Valid Gmail address returns VALID [T-501]
Parent Suite: #400 (validate_email_format Test Suite)
Labels: Type: Test, Type: Feature (inherited), Workflow: Backlog, Validation: Pending,
       Difficulty: Easy, AI: Autonomous, Env: Synthetic, Test-Type: Simple, Technique: Unit
(Note: Level 5 has most labels. All test classification labels required: Env, Test-Type, Technique.)

Test ID: T-501

In-Bounds Cases:
  - IB-01: test@gmail.com → returns VALID (0)
    Input: email = "test@gmail.com"
    Expected: ValidationResult.VALID (0)

Validation Method:
  - Tool: pytest
  - Command: pytest tests/test_501_valid_gmail.py
  - Pass threshold: Return value == VALID, no exceptions

Evidence: (to be attached after execution)
```

#### Example Test-Case (OOB-01 for validate_email_format)

```
Issue #601: Missing @ symbol returns INVALID_FORMAT [T-601]
Parent Suite: #400 (validate_email_format Test Suite)
Labels: type:test, validation:pending
Status: workflow:pending

Test ID: T-601

Out-of-Bounds Cases:
  - OOB-01: testgmail.com → returns INVALID_FORMAT (3)
    Input: email = "testgmail.com" (missing @)
    Expected: ValidationResult.INVALID_FORMAT (3)

Validation Method:
  - Tool: pytest
  - Command: pytest tests/test_601_missing_at.py
  - Pass threshold: Return value == INVALID_FORMAT, no crash

Evidence: (to be attached after execution)
```

---

## Example 2: Bug Fix Hierarchy

### Level 1: Feature (Bug Fix)

```
Issue #150: Fix Login Timeout After 30 Minutes
Labels: Type: Bug, Workflow: Backlog
(Note: Level 1 gets ONLY Type + Workflow. No severity, AI, or other labels.)

User Outcome:
As a logged-in user, I want my session to remain valid for the full duration
so that I don't get unexpectedly logged out during active use.

Acceptance Criteria:
- AC1: Session token refreshes automatically before expiry
- AC2: User activity extends session timeout
- AC3: Graceful logout on actual timeout

Success Metrics:
- Zero unexpected logouts reported
- Session refresh succeeds >99.9% of time
- Logout UX displays countdown timer
```

### Level 2: Sub-Feature

```
Issue #250: Automatic Session Token Refresh (AC1)
Parent: #150 (Fix Login Timeout)
Labels: role:sub-feature, severity:high
Status: workflow:in-progress

Acceptance Criterion: AC1: Session token refreshes automatically before expiry

Functions Needed:
- FN: refresh_session_token(token) - Request new token from auth service
- FN: schedule_token_refresh(token, expiry) - Schedule refresh 5 min before expiry
- FN: handle_refresh_failure(token, error) - Graceful degradation on failure

Test Coverage: IB≥1, OOB≥2 per function
```

### Level 3: Function

```
Issue #350: refresh_session_token() Function
Parent: #250 (Automatic Session Token Refresh)
Labels: type:function, severity:high
Status: workflow:in-progress

Function: refresh_session_token(token: SessionToken): RefreshResult

Contract:
  Inputs:
    - token: SessionToken (valid, non-expired)
  Outputs:
    - SUCCESS (0): New token issued
    - EXPIRED (1): Token already expired, cannot refresh
    - AUTH_ERROR (2): Auth service unreachable
    - INVALID_TOKEN (3): Token malformed
  Invariants:
    - Original token never modified
    - Atomic operation (either succeeds or rolls back)
  Preconditions:
    - token not null, properly formatted
    - Auth service reachable
  Postconditions:
    - On SUCCESS: New token stored, old token invalidated
    - On failure: Original token remains valid
    - Audit log entry created

Test Suite: #450
```

### Level 4: Test-Suite

```
Issue #450: refresh_session_token() Test Suite
Parent: #350 (refresh_session_token Function)
Labels: role:test suite, severity:high
Status: workflow:pending

Coverage Target: IB=3, OOB=4

Test Cases:
  In-Bounds:
    - Test #551: IB-01: Valid token refreshes successfully [T-551]
    - Test #552: IB-02: Token near expiry refreshes [T-552]
    - Test #553: IB-03: Multiple refreshes work sequentially [T-553]

  Out-of-Bounds:
    - Test #651: OOB-01: Expired token returns EXPIRED [T-651]
    - Test #652: OOB-02: Invalid token format returns INVALID_TOKEN [T-652]
    - Test #653: OOB-03: Auth service down returns AUTH_ERROR [T-653]
    - Test #654: OOB-04: Network timeout handled gracefully [T-654]
```

### Level 5: Test-Cases

```
Issue #551: Valid token refreshes successfully [T-551]
Parent Suite: #450
Labels: type:test, validation:pending

Test ID: T-551
In-Bounds: IB-01: Fresh token (1 hour TTL remaining) → SUCCESS

Issue #651: Expired token returns EXPIRED [T-651]
Parent Suite: #450
Labels: type:test, validation:pending

Test ID: T-651
Out-of-Bounds: OOB-01: Token expired 5 minutes ago → EXPIRED
```

---

## Label Combinations Table

| Level | Issue Type  | Type: Label                              | Role: Label | Workflow: Label | Example                                |
| ----- | ----------- | ---------------------------------------- | ----------- | --------------- | -------------------------------------- |
| 1     | Feature     | Feature/Bug/Improvement/Refactor/Tooling | NONE        | Backlog (init)  | #100: Type: Feature, Workflow: Backlog |
| 2     | Sub-Feature | NONE (no type at Level 2)                | Sub-Feature | TBD             | #200: Role: Sub-Feature                |
| 3     | Function    | Function                                 | NONE        | TBD             | #300: Type: Function                   |
| 4     | Test-Suite  | NONE                                     | Test-Suite  | TBD             | #400: Role: Test-Suite                 |
| 5     | Test-Case   | Test                                     | NONE        | TBD             | #501: Type: Test                       |

**Pattern:**

- Levels 1, 3, 5 (parent + implementation units): Get `type:` labels
- Levels 2, 4 (organizational): Get `role:` labels
- Never both `type:` and `role:` on same issue

---

## Work Type Hierarchy Rules

### Rule 1: Parent Defines Work Type

The top-level Feature defines the work type (feature, bug, improvement, refactor, tooling). All descendant issues inherit this classification.

**Example:**

```
Feature #100: type:bug (fix login timeout)
  └─ Sub-Feature #250: role:sub-feature (inherits "bug" classification)
       └─ Function #350: type:function (implementation is still part of bug fix)
            └─ Test-Suite #450: role:test suite (testing bug fix)
                 └─ Test #551: type:test (validating bug fix)
```

All work in this hierarchy is classified as "bug fix work" even though individual issues have different labels.

### Rule 2: Children Don't Override Work Type

Sub-Features, Test-Suites never change the work type classification. They organize work within the parent's classification.

**Invalid:**

```
❌ Feature #100: type:feature (new capability)
     └─ Sub-Feature #200: type:bug ← WRONG! Can't change work type
```

**Valid:**

```
✅ Feature #100: type:feature (new capability)
     └─ Sub-Feature #200: role:sub-feature ← CORRECT! Organizational role
```

### Rule 3: Functions and Tests Are Typed

Functions and Tests get `type:` labels because they are implementation work:

- `type:function` - Code implementation
- `type:test` - Test implementation

But they still belong to the parent Feature's work classification.

---

## Traceability Example

Given this hierarchy:

```
Feature #100 (type:feature) "Email Validation"
  └─ Sub-Feature #200 (role:sub-feature) "Format Validation"
       └─ Function #300 (type:function) "validate_email_format()"
            └─ Test-Suite #400 (role:test suite) "Coverage"
                 └─ Test #501 (type:test) "Valid Gmail test"
```

**Traceability queries:**

Q: "Which Feature does Test #501 belong to?"
A: #501 → #400 → #300 → #200 → #100 (Email Validation)

Q: "What work type is Test #501?"
A: It's a test (`type:test`) that validates a function (`type:function`) implementing a Sub-Feature (`role:sub-feature`) within a Feature (`type:feature`). Overall work type: Feature.

Q: "How many tests validate Function #300?"
A: Check Test-Suite #400, count test issues linked to it.

Q: "Is AC1 complete?"
A: Check Sub-Feature #200 (which implements AC1). It's complete when all its Functions are complete, which happens when all their Test-Suites pass.

---

## Complete Hierarchy Visualization

```
Feature #100: Email Validation (type:feature)
│
├─ Sub-Feature #200: Format Validation [AC1] (role:sub-feature)
│  ├─ Function #300: validate_email_format() (type:function)
│  │  └─ Test-Suite #400: validate_email_format() Coverage (role:test suite)
│  │     ├─ Test #501: IB-01 Valid Gmail [T-501] (type:test)
│  │     ├─ Test #502: IB-02 Valid corporate [T-502] (type:test)
│  │     ├─ Test #503: IB-03 Valid intl [T-503] (type:test)
│  │     ├─ Test #601: OOB-01 Missing @ [T-601] (type:test)
│  │     ├─ Test #602: OOB-02 Multiple @ [T-602] (type:test)
│  │     ├─ Test #603: OOB-03 Empty string [T-603] (type:test)
│  │     ├─ Test #604: OOB-04 Null input [T-604] (type:test)
│  │     └─ Test #605: OOB-05 Too long [T-605] (type:test)
│  │
│  ├─ Function #305: normalize_email() (type:function)
│  │  └─ Test-Suite #405: normalize_email() Coverage (role:test suite)
│  │     └─ (tests...)
│  │
│  └─ Function #310: extract_domain() (type:function)
│     └─ Test-Suite #410: extract_domain() Coverage (role:test suite)
│        └─ (tests...)
│
└─ Sub-Feature #210: MX Record Validation [AC2] (role:sub-feature)
   ├─ Function #320: check_domain_mx() (type:function)
   │  └─ Test-Suite #420: check_domain_mx() Coverage (role:test suite)
   │     └─ (tests...)
   │
   └─ Function #325: cache_domain_result() (type:function)
      └─ Test-Suite #425: cache_domain_result() Coverage (role:test suite)
         └─ (tests...)
```

**Statistics for Feature #100:**

- 2 Sub-Features (AC1, AC2)
- 5 Functions
- 5 Test-Suites
- ~25+ individual Test-Cases (assuming IB≥1, OOB≥2 per function)

---

## Related Documentation

- **Test Naming:** [test_naming_examples.md](./test_naming_examples.md) - IB/OOB/T-ID conventions
- **Template Usage:** [../templates/template_usage.md](../templates/template_usage.md) - Which template to use when
- **Label Design:** [../../LABEL_DESIGN_SPEC.md](../../LABEL_DESIGN_SPEC.md) - Complete label taxonomy

---

**Last Updated:** 2025-11-10
**Source:** Created for P1.1 Documentation Refactoring
