# Test Naming Examples

**Purpose:** Concrete examples of IB/OOB/T-ID naming conventions

---

## Key Concept: Issue Number = Namespace

The GitHub issue number IS the namespace for test IDs. This means:

- `IB-01` in issue #100 is DIFFERENT from `IB-01` in issue #101
- No global registry needed
- No naming conflicts possible
- Simple, predictable naming

**Rule:** When writing test cases, use simple `IB-01`, `IB-02`, `OOB-01`, `OOB-02` - the issue you're editing provides the context.

---

## Example 1: Buffer Processing Tests (Issue #100)

**Issue:** #100 - Test buffer processing
**Test ID:** T-100

### In-Bounds Cases (IB - Valid Inputs)

```
- IB-01: Valid buffer with 512 samples
  - Input: buffer[512] with valid audio samples (int16_t, range -32768 to 32767)
  - Expected: SUCCESS, buffer processed without errors

- IB-02: Edge case at boundary (1024 samples = max size)
  - Input: buffer[1024] at maximum allowed size
  - Expected: SUCCESS, processes full buffer correctly
```

### Out-of-Bounds Cases (OOB - Edge/Error Cases)

```
- OOB-01: Buffer overflow (1025 samples when max=1024)
  - Input: buffer[1025] exceeds maximum
  - Expected: ERROR_OVERFLOW, no crash, buffer unchanged

- OOB-02: NULL pointer
  - Input: buffer = NULL
  - Expected: ERROR_NULL_POINTER, no crash or segfault
```

### Filesystem Mapping

```
tests/test_100_buffer_processing/
├── IB_01_valid_buffer.c
├── IB_02_edge_boundary.c
├── OOB_01_overflow.c
└── OOB_02_null_pointer.c
```

---

## Example 2: State Machine Tests (Issue #101)

**Issue:** #101 - Test state machine
**Test ID:** T-101

### In-Bounds Cases

```
- IB-01: Valid state transition (IDLE → RUNNING)
  - Input: current_state = IDLE, command = START
  - Expected: SUCCESS, state = RUNNING
```

### Out-of-Bounds Cases

```
- OOB-01: Invalid state code
  - Input: current_state = 99 (undefined state)
  - Expected: ERROR_INVALID_STATE, state unchanged

- OOB-02: Uninitialized state
  - Input: current_state = uninitialized (random memory)
  - Expected: ERROR_UNINITIALIZED, safe failure mode
```

### Filesystem Mapping

```
tests/test_101_state_machine/
├── IB_01_valid_transition.c
├── OOB_01_invalid_state.c
└── OOB_02_uninitialized.c
```

---

## Example 3: Error Handling Tests (Issue #102)

**Issue:** #102 - Test error handling
**Test ID:** T-102

### In-Bounds Cases

```
- IB-01: Normal error path (expected file not found)
  - Input: open_file("nonexistent.txt")
  - Expected: ERROR_FILE_NOT_FOUND, clear error message

- IB-02: Recoverable error (retry succeeds)
  - Input: network_request() fails once, succeeds on retry
  - Expected: SUCCESS after retry, latency logged
```

### Out-of-Bounds Cases

```
- OOB-01: Error cascade (multiple simultaneous errors)
  - Input: disk full + network down + invalid permissions
  - Expected: ERROR_MULTIPLE, first error reported, no crash

- OOB-02: Error during error handling
  - Input: logging fails while reporting original error
  - Expected: Original error code returned, degraded logging mode

- OOB-03: Resource exhaustion (out of error codes)
  - Input: 1000+ concurrent errors
  - Expected: ERROR_OVERFLOW, oldest errors discarded, system stable
```

### Filesystem Mapping

```
tests/test_102_error_handling/
├── IB_01_expected_error.c
├── IB_02_recoverable_error.c
├── OOB_01_error_cascade.c
├── OOB_02_error_during_error.c
└── OOB_03_resource_exhaustion.c
```

---

## Naming Rules

### IB (In-Bounds) Naming

**Format:** `IB-NN` where NN is 01-99

**Purpose:** Valid inputs that should produce correct behavior

**Examples:**

- `IB-01`: Most common case (happy path)
- `IB-02`: Edge case at boundary (still valid)
- `IB-03`: Alternative valid input format
- `IB-04`: Valid but uncommon input
- `IB-05`: Maximum valid input size

**Execution Order:** Generally IB-01, IB-02, IB-03... ascending by ID

### OOB (Out-of-Bounds) Naming

**Format:** `OOB-NN` where NN is 01-99

**Purpose:** Invalid/edge inputs that should fail gracefully

**Minimum Required:** 2 OOB cases per test issue

**Examples:**

- `OOB-01`: Boundary violation (overflow, underflow)
- `OOB-02`: NULL/invalid pointer
- `OOB-03`: Wrong data type
- `OOB-04`: Resource exhaustion
- `OOB-05`: Concurrent access conflict

**Execution Order:**

- If boundary applies: OOB-01 → IB-01 → OOB-02, then remaining ascending
- Otherwise: Ascending by ID (OOB-01, OOB-02, OOB-03...)

### T-ID (Test Issue Identifier)

**Format:** `T-NNN` where NNN is the issue number

**Purpose:** Stable identifier for the entire test issue

**Examples:**

- Test issue #100 → `T-100`
- Test issue #101 → `T-101`
- Test issue #999 → `T-999`

**Usage:** Appears in issue title: `TEST: <short name> [T-100]`

---

## Filesystem Conventions

### Directory Naming

**Format:** `test_<issue-number>_<descriptive-name>/`

**Examples:**

- Issue #100 → `test_100_buffer_processing/`
- Issue #101 → `test_101_state_machine/`
- Issue #102 → `test_102_error_handling/`

### File Naming

**Format:** `<IB|OOB>_<NN>_<descriptive_name>.<ext>`

**Examples:**

- `IB-01` → `IB_01_valid_buffer.c`
- `OOB-02` → `OOB_02_null_pointer.c`
- `IB-03` → `IB_03_alternative_format.py`

**Key Points:**

- Underscore separates parts (not hyphen)
- Descriptive name uses underscores (snake_case)
- File extension matches implementation language

---

## Complete Example: Multi-Test Suite

```
Issue #42: Build Test Suite (role: test suite)
  ├─ Issue #100: Test buffer processing [T-100] (type: test)
  │    tests/test_100_buffer_processing/
  │      ├── IB_01_valid_buffer.c
  │      ├── IB_02_edge_boundary.c
  │      ├── OOB_01_overflow.c
  │      └── OOB_02_null_pointer.c
  │
  ├─ Issue #101: Test state machine [T-101] (type: test)
  │    tests/test_101_state_machine/
  │      ├── IB_01_valid_transition.c
  │      ├── OOB_01_invalid_state.c
  │      └── OOB_02_uninitialized.c
  │
  └─ Issue #102: Test error handling [T-102] (type: test)
       tests/test_102_error_handling/
         ├── IB_01_expected_error.c
         ├── IB_02_recoverable_error.c
         ├── OOB_01_error_cascade.c
         ├── OOB_02_error_during_error.c
         └── OOB_03_resource_exhaustion.c
```

---

## Common Mistakes to Avoid

### ❌ WRONG: Global IB/OOB numbering

```
Issue #100: IB-01, IB-02, IB-03
Issue #101: IB-04, IB-05, IB-06  ← WRONG! Renumbers based on previous issue
```

### ✅ CORRECT: Per-issue namespace

```
Issue #100: IB-01, IB-02, IB-03
Issue #101: IB-01, IB-02, IB-03  ← CORRECT! Each issue starts at 01
```

### ❌ WRONG: Renumbering existing IDs

```
Issue #100 originally:
- IB-01: Test A
- IB-02: Test B

Later adding new test:
- IB-01: Test A
- IB-02: New test  ← WRONG! Changed existing ID
- IB-03: Test B
```

### ✅ CORRECT: Never renumber, add new IDs

```
Issue #100 originally:
- IB-01: Test A
- IB-02: Test B

Later adding new test:
- IB-01: Test A     (unchanged)
- IB-02: Test B     (unchanged)
- IB-03: New test   ← CORRECT! Added as IB-03
```

### ❌ WRONG: Using hyphen in filesystem

```
tests/test-100-buffer-processing/  ← WRONG! Hyphens instead of underscores
  IB-01-valid-buffer.c             ← WRONG! Keeps hyphen in filename
```

### ✅ CORRECT: Underscore in filesystem

```
tests/test_100_buffer_processing/  ← CORRECT! Underscores
  IB_01_valid_buffer.c             ← CORRECT! Underscore replaces hyphen
```

---

## FAQ

### Q: Can I skip IB/OOB numbers (e.g., IB-01, IB-03, skipping IB-02)?

**A:** Yes, but not recommended. Sequential numbering is clearer. However, if you delete a test, don't renumber - leave the gap.

### Q: What if I need more than 99 IB or OOB cases?

**A:** Unlikely, but if needed, use three digits: IB-100, IB-101. The format is flexible.

### Q: Can IB and OOB have same numbers (e.g., IB-01 and OOB-01)?

**A:** Yes! They're in separate namespaces. IB-01 and OOB-01 can coexist in the same test issue.

### Q: Do I need leading zeros (IB-01 vs IB-1)?

**A:** Yes, use leading zeros (IB-01, not IB-1) for consistent sorting and readability.

### Q: What about integration tests or system tests?

**A:** Same rules apply. Each test issue gets its own IB/OOB namespace regardless of test type.

---

## Related Documentation

- **Hierarchy Examples:** [hierarchy_examples.md](./hierarchy_examples.md) - Complete Feature → Test hierarchies
- **Test Template:** [.github/ISSUE_TEMPLATE/test.yml](../../.github/ISSUE_TEMPLATE/test.yml) - Actual template with IB/OOB fields
- **Workflow Behavior:** [.github/WORKFLOW_BEHAVIOR.md](../../.github/WORKFLOW_BEHAVIOR.md) - How workflows parse IB/OOB IDs

---

**Last Updated:** 2025-11-10
**Source:** Extracted from README.md (P1.1 Documentation Refactoring)
