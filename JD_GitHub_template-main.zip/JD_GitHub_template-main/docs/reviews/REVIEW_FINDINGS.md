# Issue Template & Validation System - Comprehensive Review Findings

**Review Date:** 2025-11-10
**Reviewer:** Claude (AI)
**Scope:** Complete deep-dive review of issue templates, validation workflows, label taxonomy integration, and GitHub Actions testing infrastructure

---

## Executive Summary

This document contains findings from a comprehensive review of the entire issue template and validation system. Findings are categorized as:

- **🔴 CRITICAL** - Breaks functionality, must fix immediately
- **🟡 HIGH** - Impacts usability or correctness, should fix soon
- **🟢 MEDIUM** - Improvement opportunity, nice to have
- **🔵 LOW** - Enhancement or documentation improvement

---

## 1. Issue Template Review

### 1.1 Template: `test.yml`

#### ✅ WORKING CORRECTLY

1. All required fields present and properly configured
2. Proper input types (input, textarea, checkboxes)
3. Validation (required: true) set appropriately
4. Labels auto-applied: `type: test`, `validation: pending`
5. IB/OOB format guidance clear in descriptions
6. Validation gate checkbox properly formatted

#### 🔴 CRITICAL ISSUES

**NONE FOUND**

#### 🟡 HIGH PRIORITY ISSUES

1. **Missing test-type label dropdown**
   - **Issue:** Template doesn't collect test-type classification (simple, simple-edge, complex, complex-edge)
   - **Impact:** Manual label application required, inconsistent categorization
   - **Fix:** Add dropdown field for test-type selection
   - **Spec Reference:** LABEL_DESIGN_SPEC.md lines 131-147

2. **Missing difficulty label dropdown**
   - **Issue:** No difficulty classification collected
   - **Impact:** Cannot auto-apply difficulty labels based on test complexity
   - **Fix:** Add dropdown field (trivial, easy, medium, hard, complex)
   - **Spec Reference:** LABEL_DESIGN_SPEC.md lines 41-57

3. **Missing ai-capability label dropdown**
   - **Issue:** No AI capability classification collected
   - **Impact:** Cannot track which tests AI can run autonomously
   - **Fix:** Add dropdown field (autonomous, supervised, human+ai, human-only)
   - **Spec Reference:** LABEL_DESIGN_SPEC.md lines 61-77

#### 🟢 MEDIUM PRIORITY ISSUES

4. **Parent/suite fields allow "_No response_" placeholder**
   - **Issue:** Validation workflow (validate-issue.yml:282) checks for `_No response_` but template marks these as required
   - **Impact:** Confusing - required field can be empty
   - **Fix:** Either make optional OR add validation error when empty
   - **Decision needed:** Are parent/suite always required for test issues?

5. **No workflow status dropdown**
   - **Issue:** Tests need workflow status (backlog, ready, in-progress, review, testing, blocked)
   - **Impact:** Manual label application required
   - **Fix:** Add dropdown for workflow status
   - **Spec Reference:** LABEL_DESIGN_SPEC.md lines 79-108

6. **Evidence checkboxes not validated**
   - **Issue:** Evidence attachments section has checkboxes but they're optional and not validated
   - **Impact:** Tests can pass validation without evidence
   - **Decision needed:** Should evidence be required? Or part of "DONE" criteria?

#### 🔵 LOW PRIORITY ISSUES

7. **Title placeholder could be more specific**
   - **Current:** `TEST: <short name> [T-xxx]`
   - **Suggestion:** `TEST: <function_name> - <behavior> [T-xxx]`
   - **Example:** `TEST: validateEmail - handles null input [T-042]`

---

### 1.2 Template: `test-suite.yml`

#### ✅ WORKING CORRECTLY

1. Proper hierarchy linking (parent_function field)
2. Function contract summary section (good for test writers)
3. Test case listing with IB/OOB format guidance
4. Coverage target and strategy sections
5. Completion gate checklist

#### 🟡 HIGH PRIORITY ISSUES

1. **Missing role label auto-application**
   - **Issue:** Template should auto-apply `role: test suite` label
   - **Impact:** Manual label application required
   - **Fix:** Add to `labels:` field in template
   - **Current:** `labels: ["role: test suite"]` (CORRECT - no issue here, verified)

2. **No workflow status dropdown**
   - **Issue:** Missing workflow status selection
   - **Impact:** Manual label application
   - **Fix:** Add dropdown

3. **No difficulty/ai-capability classification**
   - **Issue:** Suite-level complexity not tracked
   - **Impact:** Cannot estimate effort or AI capability
   - **Fix:** Add dropdown fields

#### 🟢 MEDIUM PRIORITY ISSUES

4. **Test case format guidance**
   - **Current:** Shows format as `- IB: #XXX - [test name]`
   - **Issue:** This references issue numbers, but workflow validation looks for `IB-01` format within test issue bodies
   - **Clarification needed:** Is this listing child issue links, or IB/OOB cases within the suite itself?
   - **Impact:** Potential confusion between suite's test listing and individual test IB/OOB cases

5. **Coverage target not enforced**
   - **Issue:** Coverage targets are documented but not validated
   - **Impact:** No automated check that coverage goals were met
   - **Enhancement:** Could add validation that counts linked test issues and verifies against target

---

### 1.3 Template: `function.yml`

#### ✅ WORKING CORRECTLY

1. Contract sections comprehensive (inputs, outputs, invariants, pre/post conditions)
2. Auto-applies `type: function` label correctly
3. Test suite linking field present
4. Ready gate checklist appropriate

#### 🟡 HIGH PRIORITY ISSUES

1. **Missing workflow status dropdown**
   - **Impact:** Manual label application
   - **Fix:** Add dropdown

2. **Missing difficulty/ai-capability dropdowns**
   - **Impact:** Cannot track complexity or AI suitability
   - **Fix:** Add dropdown fields

#### 🟢 MEDIUM PRIORITY ISSUES

3. **Test suite link is required too early**
   - **Issue:** Test-Suite issue URL is required in function template
   - **Impact:** Forces specific order: create function → create test suite → link back
   - **Better workflow:** Function can be "READY" when contract is complete, test suite created after
   - **Fix:** Make test_suite_link optional, move to ready gate checklist

4. **No validation that test suite actually validates this function**
   - **Issue:** Link is provided but not verified
   - **Enhancement:** Workflow could verify test suite's parent_function field points back to this function

---

### 1.4 Template: `sub-feature.yml`

#### ✅ WORKING CORRECTLY

1. Auto-applies `role: sub-feature` label correctly
2. Acceptance criterion linkage to parent feature
3. Function contracts listing section
4. Test coverage requirements section

#### 🟡 HIGH PRIORITY ISSUES

1. **Missing workflow status dropdown**
2. **Missing difficulty/ai-capability dropdowns**
3. **No validation that AC text matches parent feature**
   - **Issue:** User copies AC from parent, but no automated check
   - **Enhancement:** Workflow could fetch parent and verify AC exists

#### 🟢 MEDIUM PRIORITY ISSUES

4. **Function issues section is manual**
   - **Current:** "Auto-generated section - Fill this after Function issues are created"
   - **Issue:** Not actually auto-generated, requires manual update
   - **Enhancement:** Workflow automation to populate this when child Function issues link back

5. **Ready gate doesn't verify test suites exist**
   - **Current:** Checklist says "Test-Suite issues created for each function"
   - **Issue:** No automated validation
   - **Enhancement:** Could add workflow to count test suites and validate against function count

---

### 1.5 Template: `feature.yml`

#### 🔴 CRITICAL ISSUES

**NONE FOUND**

#### 🟡 HIGH PRIORITY ISSUES

1. **Work type dropdown doesn't auto-apply label**
   - **Issue:** Dropdown shows work type options (Feature, Bug Fix, Improvement, Refactor, Tooling) but template doesn't have labels field
   - **Impact:** Label must be manually applied after issue creation
   - **Fix:** Templates can't conditionally apply labels based on dropdown selection
   - **GitHub Limitation:** Issue templates can't use conditional logic
   - **Workaround Options:**
     a. Create separate templates (feature.yml, bug.yml, improvement.yml, refactor.yml, tooling.yml)
     b. Keep single template with no auto-labeling (current approach)
     c. Add workflow automation to apply label based on dropdown value

2. **Missing workflow status dropdown**

3. **Missing difficulty/ai-capability dropdowns**

#### 🟢 MEDIUM PRIORITY ISSUES

4. **Sub-features section is manual**
   - **Same issue as sub-feature template's function issues section**
   - **Enhancement:** Automation to populate when child sub-features link back

5. **Estimated effort dropdown not integrated with difficulty label**
   - **Issue:** Effort estimate (XS/S/M/L/XL) exists separately from difficulty label (trivial/easy/medium/hard/complex)
   - **Impact:** Two similar but different classifications
   - **Decision needed:** Should these map to each other? Or serve different purposes?

---

### 1.6 Template: `config.yml`

#### ✅ WORKING CORRECTLY

- Blank issues enabled (allows free-form issues when needed)
- No contact links configured (appropriate for this template repo)

#### 🔵 LOW PRIORITY ISSUES

1. **Could add helpful contact links**
   - **Enhancement:** Links to documentation, workflow behavior guide, etc.
   - **Example:**
     ```yaml
     contact_links:
       - name: Workflow Behavior Documentation
         url: https://github.com/Jackson-Devices/JD_GitHub_template/blob/main/.github/WORKFLOW_BEHAVIOR.md
         about: Learn about validation workflows and commands
       - name: Label Design Specification
         url: https://github.com/Jackson-Devices/JD_GitHub_template/blob/main/LABEL_DESIGN_SPEC.md
         about: Complete label taxonomy reference
     ```

---

## 2. Label Taxonomy Integration Review

### 2.1 Label Application Coverage

| Label Category       | Template Coverage | Notes                                                                                                                 |
| -------------------- | ----------------- | --------------------------------------------------------------------------------------------------------------------- |
| `type:` (work type)  | ❌ Partial        | Only `test`, `function`, `test suite`, `sub-feature` auto-applied. Feature/bug/improvement require manual application |
| `difficulty:`        | ❌ None           | No templates collect this                                                                                             |
| `ai:` (capability)   | ❌ None           | No templates collect this                                                                                             |
| `workflow:` (status) | ❌ None           | No templates collect this                                                                                             |
| `validation:`        | ✅ Partial        | Only `test.yml` auto-applies `validation: pending`                                                                    |
| `test-type:`         | ❌ None           | No templates collect this                                                                                             |
| `role:`              | ✅ Complete       | `test-suite.yml` and `sub-feature.yml` correctly apply                                                                |
| `needs-human`        | ❌ None           | Could auto-apply based on ai-capability dropdown if added                                                             |

### 2.2 Missing Label Automation

**Impact:** Most labels require manual application after issue creation, defeating the purpose of templates ensuring consistency.

**Root Cause:** GitHub issue templates have limited conditional logic. Can't auto-apply labels based on dropdown selections.

**Solutions:**

1. **Separate templates per work type** (recommended)
   - Create: `feature.yml`, `bug.yml`, `improvement.yml`, `refactor.yml`, `tooling.yml`, `docs.yml`
   - Each auto-applies correct `type:` label
   - Reduces choice paralysis, clearer workflow

2. **Post-creation workflow automation**
   - Workflow triggers on issue creation
   - Reads dropdown values from issue body
   - Applies appropriate labels
   - **Complexity:** Medium (requires YAML parsing and label mapping)

3. **Keep manual labeling** (current state)
   - Pro: Simple, no additional automation
   - Con: Inconsistent labeling, human error

---

## 3. Validation Workflow Review

### 3.1 Workflow: `validate-issue.yml`

#### ✅ WORKING CORRECTLY

1. Comprehensive validation (9 categories)
2. IB/OOB regex patterns correct (`IB-01` to `IB-99`)
3. Invalid format detection (catches `IB-1`, `IB-001`, etc.)
4. Test ID format validation (`T-\d{3,}`)
5. Validation gate checkbox detection
6. Parent/suite issue accessibility checks
7. YAML validation for suite issues
8. Proper label state machine (blocked → pending)
9. Concurrency control prevents race conditions

#### 🟡 HIGH PRIORITY ISSUES

1. **Validation passes with "_No response_" in required fields**
   - **Issue:** Lines 170: `if (content === '' || content === '_No response_')`
   - **Impact:** Required sections can be empty placeholders
   - **Question:** Is this intentional to allow gradual issue completion?
   - **Recommendation:** Either:
     a. Reject `_No response_` as invalid (strict validation)
     b. Document this is allowed for draft issues

2. **Parent/suite URL validation is asymmetric**
   - **Issue:** Suite issues require YAML block (lines 292-300), parent issues don't (lines 302-320)
   - **Question:** Why different requirements?
   - **Impact:** Could catch suite issues that aren't properly set up
   - **Recommendation:** Document why suite needs YAML but parent doesn't

#### 🟢 MEDIUM PRIORITY ISSUES

3. **Warnings don't block validation**
   - **Current:** Case structure warnings (lines 236-262) don't fail validation
   - **Impact:** Tests can pass with poorly structured cases
   - **Question:** Should warnings be optional quality gates?
   - **Recommendation:** Consider making some warnings hard errors

4. **No validation of test case uniqueness**
   - **Issue:** Multiple `IB-01` entries in same issue aren't detected as error
   - **Current:** Deduplication (line 206) silently removes duplicates
   - **Impact:** User might define `IB-01` twice and not realize only one is counted
   - **Recommendation:** Warn or error on duplicates

---

### 3.2 Workflow: `enforce_test_gate.yml`

#### ✅ WORKING CORRECTLY

1. Atomic gate enforcement (single decision point)
2. Auto-unchecks gate when requirements not met
3. Auto-clears run checklist on violation
4. Batch label updates prevent race conditions
5. Proper state machine enforcement (only runs in pending/passed states)
6. Concurrency control

#### 🔴 CRITICAL ISSUES

**NONE FOUND**

#### 🟡 HIGH PRIORITY ISSUES

**NONE FOUND** - This workflow is well-designed!

#### 🟢 MEDIUM PRIORITY ISSUES

1. **Silent deduplication**
   - Same issue as validate-issue.yml (lines 97-98)
   - **Recommendation:** Warn user if duplicates found

---

### 3.3 Workflow: `seed-test-runlist.yml` (Not fully reviewed yet)

_Placeholder - full review in next section_

---

## 4. Test Categorization & Taxonomy

### 4.1 Current Test Categorization

**Defined Test Types:**

1. **IB/OOB Format** (well-defined)
   - IB = In-Bounds (valid inputs, happy path)
   - OOB = Out-of-Bounds (invalid/edge inputs, error handling)
   - Format: `IB-01` to `IB-99`, `OOB-01` to `OOB-99`
   - Well documented in templates and workflows

2. **Test-Type Labels** (defined in LABEL_DESIGN_SPEC.md but not integrated)
   - `test-type: simple` - Single behavior, minimal branching
   - `test-type: simple-edge` - Narrow edge case, straightforward setup
   - `test-type: complex` - Multiple assertions, layered setup
   - `test-type: complex-edge` - Multi-step edge scenarios, intricate orchestration
   - **Issue:** No template collects this, no workflow validates it
   - **Impact:** Manual classification required

3. **Advanced Testing Types** (mentioned in ATOMIC_TDD_FRAMEWORK.md but not operationalized)
   - Property-Based Testing (PBT)
   - Mutation Testing
   - Contract Testing
   - Edge tests
   - **Issue:** Concepts defined but no issue template or workflow support
   - **Impact:** Can't track which tests use these advanced techniques

### 4.2 Missing Test Categorization

**NOT DEFINED:**

1. **Test execution environment**
   - Unit test (isolated)
   - Integration test (multiple components)
   - End-to-end test (full system)
   - **Impact:** Cannot filter/run tests by scope

2. **Test determinism**
   - Deterministic (same input → same output always)
   - Non-deterministic (involves time, random, network)
   - **Impact:** Cannot identify flaky tests

3. **Test resource requirements**
   - CPU/memory intensive
   - Network dependent
   - Hardware required
   - **Impact:** Cannot schedule tests appropriately

4. **Test coverage type**
   - Statement coverage
   - Branch coverage
   - Path coverage
   - Mutation coverage
   - **Impact:** Cannot track coverage quality

### 4.3 Recommendations

1. **Immediate:** Add test-type dropdown to test.yml template
2. **Short-term:** Define and document execution environment classification
3. **Medium-term:** Add labels for advanced test types (PBT, mutation, contract)
4. **Long-term:** Build test analytics dashboard using these classifications

---

## 5. Workflow Chain Integration Review

### 5.1 Current Chain

```
Issue Created (test.yml)
  ↓ Auto-triggers
validate-issue.yml
  ↓ Sets label: validation: pending
enforce_test_gate.yml (runs concurrently)
  ↓ Checks gate, sets validation: passed if checked & requirements met
seed-test-runlist.yml (runs concurrently)
  ↓ Generates run checklist
User runs tests, checks boxes
  ↓ User checks validation gate
enforce_test_gate.yml
  ↓ Sets validation: passed
DONE
```

### 5.2 Chain Issues

#### 🟡 HIGH PRIORITY

1. **Validation and gate enforcement can race**
   - **Issue:** Both trigger on issue edit, run concurrently
   - **Impact:** Gate enforcement might run before validation completes
   - **Mitigation:** State machine prevents this (gate only runs in pending/passed states)
   - **Question:** Is this optimal, or should gate enforcement wait for validation to complete?

2. **No automated transition from validation:passed to workflow:testing**
   - **Issue:** Labels are orthogonal, but should be coordinated
   - **Impact:** Manual workflow status updates required
   - **Recommendation:** When validation:passed applied, suggest or auto-apply workflow:testing

#### 🟢 MEDIUM PRIORITY

3. **No "DONE" state**
   - **Issue:** Validation:passed is set, but what triggers issue closure?
   - **Current:** Manual close when tests pass
   - **Enhancement:** Auto-close when validation:passed && all run checklist items checked?

---

## 6. GitHub Actions Testing Infrastructure

### 6.1 Current State

**EXISTS:**

- Test fixtures for formatter (tests/formatters/)
- Decision logging tests (tests/decision_logging/)
- Formatter test script (test_formatters.mjs)

**DOES NOT EXIST:**

- Tests for validation workflows themselves
- Tests for enforce_test_gate workflow
- Tests for seed-test-runlist workflow
- Tests for issue template rendering
- Tests for label sync workflow

### 6.2 Missing Test Infrastructure

#### 🔴 CRITICAL GAPS

1. **No validation for workflow YAML syntax**
   - **Issue:** Workflow syntax errors only caught when running
   - **Impact:** Broken workflows pushed to main
   - **Fix:** Add `actionlint` to CI
   - **Spec Reference:** TODO.md P2.1 Task 1 (line 296)

2. **No validation for issue template YAML syntax**
   - **Issue:** Template syntax errors only caught when users try to create issues
   - **Impact:** Broken templates frustrate users
   - **Fix:** Add `yamllint` to CI

3. **No tests for workflow JavaScript logic**
   - **Issue:** github-script blocks have no unit tests
   - **Impact:** Logic errors only caught in production
   - **Fix:** Extract JavaScript to separate files, write unit tests

#### 🟡 HIGH PRIORITY GAPS

4. **No integration tests for workflow chain**
   - **Issue:** Can't verify validate→enforce→seed chain works end-to-end
   - **Impact:** Integration bugs only caught manually
   - **Fix:** Create test harness that:
     a. Creates test issue
     b. Verifies validation runs
     c. Checks labels applied correctly
     d. Verifies gate enforcement
     e. Confirms checklist generation

5. **No test fixtures for issue templates**
   - **Issue:** Can't test validation logic without real issues
   - **Impact:** Manual testing required for every change
   - **Fix:** Create fixtures:
     a. `test-valid-minimal.md` (minimal valid test)
     b. `test-invalid-no-ib.md` (missing IB cases)
     c. `test-invalid-format.md` (wrong IB format)
     d. `test-edge-cases.md` (boundary conditions)

---

## 7. README.md Review

### 7.1 Outdated Content

#### 🟡 HIGH PRIORITY

1. **Label count is outdated**
   - **README.md line 20:** "36 issue labels + 10 project labels"
   - **LABEL_DESIGN_SPEC.md v1.3:** Same count
   - **Status:** CORRECT (verified against LABEL_DESIGN_SPEC.md appendix line 422-431)

2. **Git worktree workflow section is current**
   - **README.md lines 82-222:** Comprehensive git worktree workflow
   - **Status:** UP TO DATE and excellent!

3. **Template version**
   - **README.md line 358:** "Template Version: 1.3"
   - **Status:** CURRENT

#### 🟢 MEDIUM PRIORITY

4. **Missing Mermaid diagrams**
   - **Issue:** README describes hierarchy but no visual diagram
   - **Impact:** Harder to understand complex hierarchy
   - **Fix:** Add Mermaid diagram showing 5-level hierarchy
   - **Location:** After line 32 (Issue Hierarchy section)

5. **Workflow behavior link**
   - **README.md line 272:** Links to WORKFLOW_BEHAVIOR.md
   - **Status:** Link exists and is correct

---

## 8. Missing Visual Documentation

### 8.1 Recommended Mermaid Diagrams

#### 🟢 MEDIUM PRIORITY

1. **5-Level Atomic Hierarchy Diagram**

   ```mermaid
   graph TD
       A[Feature/Bug/Improvement<br/>type: feature] --> B1[Sub-Feature 1<br/>role: sub-feature]
       A --> B2[Sub-Feature 2<br/>role: sub-feature]
       B1 --> C[Function<br/>type: function]
       C --> D[Test Suite<br/>role: test suite]
       D --> E1[Test IB-01<br/>type: test]
       D --> E2[Test OOB-01<br/>type: test]
       D --> E3[Test OOB-02<br/>type: test]
   ```

2. **Validation State Machine Diagram**

   ```mermaid
   stateDiagram-v2
       [*] --> Pending: Issue created
       Pending --> Blocked: Validation fails
       Blocked --> Pending: Errors fixed
       Pending --> Passed: Gate checked & requirements met
       Passed --> Pending: Code changes (gate auto-unchecked)
       Passed --> [*]: Issue closed
   ```

3. **Workflow Execution Flow**

   ```mermaid
   sequenceDiagram
       participant User
       participant Issue
       participant Validate
       participant Gate
       participant Seed

       User->>Issue: Create/Edit Issue
       Issue->>Validate: Auto-trigger
       Validate->>Validate: Check format, IB/OOB
       alt Validation fails
           Validate->>Issue: validation: blocked
       else Validation passes
           Validate->>Issue: validation: pending
           Issue->>Gate: Auto-trigger
           Issue->>Seed: Auto-trigger
           Gate->>Gate: Check requirements
           Seed->>Seed: Generate checklist
       end
   ```

---

## Summary of Findings

### Critical Issues (Must Fix): 0

### High Priority Issues: 15

1. Test template missing test-type dropdown
2. Test template missing difficulty dropdown
3. Test template missing ai-capability dropdown
4. Test-suite template missing workflow status dropdown
5. Test-suite template missing difficulty/ai-capability dropdowns
6. Function template missing workflow status dropdown
7. Function template missing difficulty/ai-capability dropdowns
8. Sub-feature template missing workflow status dropdown
9. Sub-feature template missing difficulty/ai-capability dropdowns
10. Feature template work type dropdown doesn't auto-apply label
11. Feature template missing workflow status dropdown
12. Feature template missing difficulty/ai-capability dropdowns
13. No validation workflow tests
14. No issue template syntax validation
15. No workflow JavaScript logic tests

### Medium Priority Issues: 12

### Low Priority Issues: 2

---

## Recommended Next Steps

### Phase 1: Label Integration (Immediate)

**Goal:** Auto-apply labels from issue templates

**Tasks:**

1. Add dropdown fields to all templates (difficulty, ai-capability, workflow, test-type)
2. Create post-creation workflow to apply labels based on dropdown values
3. Test with fixtures

**Estimated:** 4-6 hours

### Phase 2: Testing Infrastructure (High Priority)

**Goal:** Automated testing for workflows and templates

**Tasks:**

1. Install actionlint and yamllint
2. Create test fixtures for all templates
3. Write unit tests for workflow JavaScript
4. Write integration tests for workflow chain

**Estimated:** 8-12 hours

### Phase 3: Documentation (Medium Priority)

**Goal:** Visual diagrams and updated docs

**Tasks:**

1. Add Mermaid diagrams to README
2. Create visual workflow guide
3. Document test categorization fully

**Estimated:** 2-4 hours

---

**End of Review**
