# Orchestration Framework with Human-in-the-Loop

## Overview

This framework provides **deterministic, LLM-free orchestration** of tools with **human approval gates** for critical decisions. Every tool interaction is strictly defined by contracts - no guesswork, no LLM interpretation.

## Architecture

```
┌──────────────────────────────────────────────────────────┐
│              Workflow Orchestrator                        │
│  (Executes tools based on manifests)                     │
└────────────┬─────────────────────────────────────────────┘
             │
      ┌──────┴───────┐
      │              │
┌─────▼─────┐  ┌────▼──────────┐
│ Tool      │  │ Human Approval │
│ Registry  │  │ Gate           │
│ (Manifests)│  │ (Wait for input)│
└───────────┘  └────────────────┘
      │              │
      │              │
┌─────▼──────────────▼───────────────────────────────────┐
│  Tool Manifest (Strict Contract)                       │
├────────────────────────────────────────────────────────┤
│  • Inputs: typed, validated parameters                 │
│  • Outputs: ALL possible exit codes + messages        │
│  • Message Registry: output text → action mapping     │
│  • Approval Points: when to pause for human           │
│  • Error Recovery: deterministic strategies           │
└────────────────────────────────────────────────────────┘
```

## Key Principles

### 1. **No LLM Interpretation**
- Every possible output is pre-mapped to an action
- Message registry maps regex patterns → deterministic responses
- No "figure it out" - only "if X then Y"

### 2. **Strict I/O Contracts**
- Tools declare ALL possible inputs/outputs
- Orchestrator validates before execution
- Type checking, pattern validation, required fields

### 3. **Human Approval Gates**
- Tools specify when human input is needed
- Secret-protected approval (prevents unauthorized execution)
- Parameterized decisions ("we guessed X, want to change?")

### 4. **Deterministic Error Recovery**
- Pre-defined recovery strategies
- No ad-hoc error handling
- Retry/skip/fail/human_approval based on exact conditions

## Tool Manifest Schema

Every tool must provide a manifest describing its complete behavior.

### Example: Prettier Manifest

```json
{
  "id": "prettier",
  "type": "formatter",
  "outputs": {
    "exit_codes": {
      "0": { "meaning": "Success", "action": "continue" },
      "1": { "meaning": "Needs formatting", "action": "human_approval" }
    },
    "message_registry": [
      {
        "pattern": "^Code style issues found in (\\d+) files?\\.",
        "severity": "warning",
        "action": "human_approval",
        "extract": { "count": "(\\d+)" },
        "suggested_fix": "Run: prettier --write ."
      }
    ]
  },
  "human_approval": {
    "approval_prompts": [
      {
        "trigger": "on_changes",
        "message": "Found {count} files with issues. Fix them?",
        "options": [
          { "value": "fix_all", "label": "Fix all", "action": "continue" },
          { "value": "skip", "label": "Skip", "action": "abort" }
        ]
      }
    ]
  }
}
```

## Message Registry

Maps EVERY possible output message to a deterministic action.

### Why This Matters

**Without Message Registry (LLM-dependent):**
```
prettier output: "Code style issues found in 5 files."
→ LLM interprets → might guess → unreliable
```

**With Message Registry (Deterministic):**
```
prettier output: "Code style issues found in 5 files."
→ Matches pattern: "^Code style issues found in (\\d+) files?\\."
→ Action: "human_approval"
→ Extracts: { count: "5" }
→ Triggers approval prompt with count
→ 100% deterministic
```

### Message Types

1. **Error Messages** - Mapped to fail/retry/skip
2. **Warning Messages** - Mapped to continue/human_approval
3. **Success Messages** - Mapped to continue
4. **Information Messages** - Mapped to log

## Human Approval System

### How It Works

1. **Tool requests approval** via manifest
2. **Workflow creates approval request** (GitHub Issue or workflow_dispatch)
3. **Human responds** with secret + decision
4. **Workflow validates** secret
5. **Workflow executes** approved action

### Approval Methods

#### Method A: GitHub Issue Comments

```bash
# Tool pauses, creates issue
# Human comments on issue:
/approve task-123-abc MY_SECRET

# Workflow validates secret, continues
```

#### Method B: workflow_dispatch

```yaml
# Tool pauses
# Human goes to: Actions → Human Approval Gate
# Enters:
#   - Task ID: task-123-abc
#   - Decision: approve
#   - Secret: MY_SECRET
# Workflow validates, continues
```

### Approval Prompts

Tools can define interactive prompts:

```json
{
  "trigger": "on_changes",
  "message": "We guessed the name '{guessed_name}'. Correct?",
  "options": [
    {
      "value": "accept",
      "label": "Yes, use that name",
      "action": "continue"
    },
    {
      "value": "change",
      "label": "No, let me specify",
      "action": "custom",
      "follow_up": {
        "type": "text",
        "prompt": "Enter the correct name:",
        "validation": "^[a-z][a-z0-9-]*$"
      }
    }
  ]
}
```

## Security

### Approval Secret

**Setup:**
1. Go to: Settings → Secrets → Actions
2. Create secret: `APPROVAL_SECRET`
3. Value: Strong random string (e.g., `openssl rand -hex 32`)

**Usage:**
- Required for ALL approval actions
- Prevents unauthorized workflow execution
- Validates using constant-time comparison (prevents timing attacks)

### Secret Validation

```bash
# Constant-time comparison (secure)
if [ "$PROVIDED_SECRET" = "$EXPECTED_SECRET" ]; then
  # Approved
fi

# NOT this (vulnerable to timing attacks):
# if [[ "$PROVIDED_SECRET" == "$EXPECTED_SECRET" ]]; then
```

## Tool Development

### Creating a New Tool

1. **Write manifest** following schema
2. **Define ALL possible outputs**
3. **Map messages to actions**
4. **Specify approval points**
5. **Test exhaustively**

### Manifest Checklist

- [ ] All exit codes documented
- [ ] All output messages in registry
- [ ] Approval prompts defined
- [ ] Error recovery strategies specified
- [ ] Constraints declared (run before/after, etc.)
- [ ] Capabilities documented
- [ ] Tests cover all code paths

### Example: Adding a Linter

```json
{
  "id": "eslint",
  "type": "linter",
  "outputs": {
    "exit_codes": {
      "0": { "meaning": "No errors", "action": "continue" },
      "1": { "meaning": "Lint errors found", "action": "human_approval" },
      "2": { "meaning": "Config error", "action": "fail" }
    },
    "message_registry": [
      {
        "pattern": "✖ (\\d+) problems? \\((\\d+) errors?, (\\d+) warnings?\\)",
        "severity": "error",
        "action": "human_approval",
        "extract": {
          "total": "(\\d+) problems?",
          "errors": "(\\d+) errors?",
          "warnings": "(\\d+) warnings?"
        }
      }
    ]
  }
}
```

## Usage Examples

### Example 1: Naming Convention Fixer

```javascript
import { requestApproval } from './scripts/lib/approval-gate.mjs';

// Detect naming violation
const suggestedName = 'feature-user-auth';
const currentName = 'my_random_branch';

const result = await requestApproval({
  task_type: 'naming-convention-fix',
  description: `Branch name '${currentName}' doesn't follow conventions`,
  proposed_action: `Rename to: ${suggestedName}`,
  parameters: {
    current_name: currentName,
    suggested_name: suggestedName,
    allow_custom: true
  },
  timeout_minutes: 30
});

if (result.approved) {
  if (result.parameters?.custom_name) {
    // Human provided custom name
    renameBranch(result.parameters.custom_name);
  } else {
    // Use suggested name
    renameBranch(suggestedName);
  }
}
```

### Example 2: Conflict Resolution

```javascript
const result = await requestApproval({
  task_type: 'conflict-resolution',
  description: 'Merge conflict in src/auth/login.js',
  proposed_action: 'Accept incoming changes (their version)',
  parameters: {
    file: 'src/auth/login.js',
    conflict_type: 'concurrent_modifications',
    our_changes: 'Added error handling',
    their_changes: 'Updated API endpoint',
    recommendation: 'accept_both_and_refactor'
  }
});

if (result.approved) {
  resolveConflict(result.parameters.resolution_strategy);
}
```

### Example 3: Commit Squashing

```javascript
const result = await requestApproval({
  task_type: 'commit-squash',
  description: 'Squash 5 commits into one',
  proposed_action: 'git commit-tree ... (safe non-destructive method)',
  parameters: {
    commit_count: 5,
    preserve_backup: true,
    backup_branch: 'feature/auth-backup-1234567890'
  }
});

if (result.approved) {
  // Execute safe squash
  await execSafeSquash();
}
```

## Testing

### Manifest Validation

```bash
# Validate manifest against schema
npx ajv validate -s schemas/tool-manifest.schema.json \
  -d .orchestrator/tools/prettier.manifest.json
```

### Message Registry Testing

Create test cases for EVERY message in the registry:

```javascript
describe('Prettier Message Registry', () => {
  it('should match formatting warning', () => {
    const message = 'Code style issues found in 5 files.';
    const pattern = /^Code style issues found in (\d+) files?\.$/;

    assert.ok(pattern.test(message));
    const match = message.match(pattern);
    assert.equal(match[1], '5');
  });
});
```

### Approval Flow Testing

```bash
# Test approval request creation
node scripts/lib/approval-gate.mjs --test

# Test secret validation
APPROVAL_SECRET=test123 node test-approval.js

# Test timeout handling
node test-approval.js --timeout=1
```

## Best Practices

### 1. **Exhaustive Message Registry**
- Add EVERY possible output
- Use regex for flexibility
- Extract structured data

### 2. **Clear Approval Prompts**
- Explain what will happen
- Provide context (show diffs, counts, etc.)
- Offer meaningful choices

### 3. **Secure Secrets**
- Use strong random secrets
- Never log secrets
- Constant-time comparison

### 4. **Graceful Timeouts**
- Reasonable defaults (30-60 minutes)
- Clear timeout behavior (abort vs. continue)
- Notify on timeout

### 5. **Audit Trail**
- Log all approvals
- Include: who, when, what, why
- Keep approval history

## Integration with Existing Workflows

### auto-squash-commits.yml

```yaml
- name: Request approval before squashing
  id: request
  run: |
    node scripts/lib/approval-gate.mjs \
      --task-type commit-squash \
      --description "Squash $COUNT commits" \
      --proposed-action "$(cat /tmp/squash-preview.txt)"

- name: Execute squash (if approved)
  if: steps.request.outputs.approved == 'true'
  run: |
    node scripts/safe-squash-commits.mjs
```

## Future Enhancements

1. **Visual Approval UI** - Web interface for approvals
2. **Approval Analytics** - Track approval patterns, times
3. **Smart Defaults** - Learn from approval history
4. **Multi-Approver** - Require N approvals for critical actions
5. **Conditional Logic** - More complex approval rules

## Troubleshooting

### Approval Timeout

**Problem:** Approval request expired
**Solution:**
- Check timeout setting in manifest
- Increase timeout for complex decisions
- Set up notifications for approval requests

### Invalid Secret

**Problem:** "Invalid approval secret" error
**Solution:**
- Verify `APPROVAL_SECRET` is set in repository
- Check for typos
- Ensure secret hasn't changed

### Message Not Matched

**Problem:** Tool output not handled
**Solution:**
- Add message pattern to registry
- Check regex escaping
- Test pattern with actual output

## Summary

This framework provides:

✅ **Deterministic orchestration** - No LLM guessing
✅ **Human-in-the-loop** - Approval gates for critical decisions
✅ **Strict contracts** - All I/O pre-defined
✅ **Secure approvals** - Secret-protected
✅ **Complete auditability** - Every decision logged
✅ **Extensible** - Easy to add new tools

**Result:** Production-ready automation that knows when to pause and ask a human.
