---
issue_number: 141
title: 'Phase 1b Task 2: Snapshot tests for shellcheck-apply.sh'
state: open
labels: []
created_at: '2025-11-13T15:28:15Z'
updated_at: '2025-11-13T15:28:19Z'
last_synced_commit: 44a80ba
tokens_estimate: 484
author: Jackson-Devices
---

## Part of #139

## Objective

Create snapshot tests to verify consistent output from shellcheck-apply.sh across different scenarios

## Location

`tests/snapshots/shellcheck-apply/`

## Snapshots to Create

### 1. Conservative Strategy Output

- Test conservative fix behavior
- Capture stdout/stderr output
- Verify minimal changes applied

### 2. Balanced Strategy Output

- Test balanced fix behavior
- Capture stdout/stderr output
- Verify moderate changes applied

### 3. Aggressive Strategy Output

- Test aggressive fix behavior
- Capture stdout/stderr output
- Verify maximum fixes applied

### 4. Multi-pass Output

- Test multi-pass execution
- Capture progress through passes
- Verify convergence behavior

### 5. Failure Output

- Test failure scenarios
- Capture error messages
- Verify backup restoration

### 6. Escalation Output

- Test strategy escalation
- Capture escalation messages
- Verify strategy progression

## Target

10+ snapshot tests total

## Implementation Details

### Snapshot Format

- Use snapshot-matcher.js helper
- Store snapshots in JSON format
- Include: stdout, stderr, exit code, file changes

### Update Mechanism

- Support `--update-snapshots` flag in test runner
- Clear diffs when snapshots change
- Document when to update snapshots

## Success Criteria

- [ ] All 6 snapshot categories implemented
- [ ] 10+ snapshot tests created
- [ ] Snapshots stored in version control
- [ ] Update mechanism working
- [ ] Tests passing with current snapshots
- [ ] Documentation for snapshot maintenance

## Testing Approach

- Use snapshot-matcher.js helper
- Capture both stdout and stderr
- Include file contents in snapshots
- Use descriptive snapshot names

## Dependencies

- Phase 1a complete (shellcheck-apply.sh exists)
- snapshot-matcher.js helper available
- Test fixtures in place

---

📋 **Part of**: Phase 1b - Extended Components & CI Integration (#139)
🔗 **Source**: ORCHESTRATION_ROADMAP.md
