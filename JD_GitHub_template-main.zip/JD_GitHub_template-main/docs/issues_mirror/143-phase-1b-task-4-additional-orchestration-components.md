---
issue_number: 143
title: 'Phase 1b Task 4: Additional orchestration components'
state: open
labels: []
created_at: '2025-11-13T15:28:53Z'
updated_at: '2025-11-13T15:28:58Z'
last_synced_commit: 7fac627
tokens_estimate: 662
author: Jackson-Devices
---

## Part of #139

## Objective

Create additional orchestration scripts to complement shellcheck-apply.sh

## Components to Implement

### 1. workflow-apply.sh

**Location**: `.github/scripts/workflow-apply.sh`

**Purpose**: Apply shellcheck fixes to workflow files

**Features**:

- Scan `.github/workflows/*.yml` for shell script blocks
- Extract shell code from workflow files
- Apply shellcheck-apply.sh to extracted code
- Update workflow files with fixed code
- Preserve YAML formatting and indentation

**Use Case**: Auto-fix shell code in GitHub Actions workflows

---

### 2. lint-gate.sh

**Location**: `.github/scripts/lint-gate.sh`

**Purpose**: Enforce linting gates with optional auto-fix

**Features**:

- Run linting checks on shell scripts
- Support multiple linters (shellcheck, shfmt, etc.)
- Auto-fix mode: Apply fixes automatically
- Gate mode: Block on lint failures
- Configurable severity levels
- Exit codes for CI integration

**Use Case**: Quality gate in CI/CD pipeline

---

### 3. format-apply.sh

**Location**: `.github/scripts/format-apply.sh`

**Purpose**: Auto-format shell scripts using shfmt

**Features**:

- Format shell scripts using shfmt
- Configurable indentation (spaces/tabs)
- Preserve shebang and file permissions
- Dry-run mode
- Backup/restore on failure
- Multiple formatting styles

**Use Case**: Consistent code formatting across project

---

## Implementation Approach

### Common Features (all scripts)

- Consistent CLI interface with shellcheck-apply.sh
- `--help` flag for usage information
- `--dry-run` mode
- `--verbose` output
- Error handling with meaningful exit codes
- Backup/restore mechanism

### Testing Strategy

- Create test fixtures for each component
- Integration tests using Node.js test runner
- Test all CLI flags and options
- Test error scenarios
- Test with real workflow files (workflow-apply.sh)

## Success Criteria

- [ ] workflow-apply.sh implemented and tested
- [ ] lint-gate.sh implemented and tested
- [ ] format-apply.sh implemented and tested
- [ ] All scripts have consistent CLI interface
- [ ] Test suites created for each script
- [ ] Documentation written for each script
- [ ] Integration with CI workflows planned

## Dependencies

- shellcheck-apply.sh as reference implementation
- Test infrastructure from Phase 1a
- shfmt tool for format-apply.sh

## Future Enhancements

- Combine all scripts into unified orchestration tool
- Add configuration file support (.shellcheck-orchestration.yml)
- Add plugin system for custom linters/formatters

---

📋 **Part of**: Phase 1b - Extended Components & CI Integration (#139)
🔗 **Source**: ORCHESTRATION_ROADMAP.md
