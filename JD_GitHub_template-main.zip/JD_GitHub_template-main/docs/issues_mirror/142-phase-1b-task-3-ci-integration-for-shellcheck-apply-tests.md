---
issue_number: 142
title: 'Phase 1b Task 3: CI Integration for shellcheck-apply tests'
state: open
labels: []
created_at: '2025-11-13T15:28:32Z'
updated_at: '2025-11-13T15:28:37Z'
last_synced_commit: 0f15492
tokens_estimate: 515
author: Jackson-Devices
---

## Part of #139

## Objective

Create GitHub Actions workflow to run shellcheck-apply.sh test suite on all PRs and commits

## Workflow File

`.github/workflows/test-shellcheck-apply.yml`

## Workflow Configuration

### Trigger Events

```yaml
on:
  pull_request:
    paths:
      - '.github/scripts/shellcheck-apply.sh'
      - 'tests/**'
      - '.github/workflows/test-shellcheck-apply.yml'
  push:
    branches:
      - main
```

### Job Configuration

```yaml
jobs:
  test:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v4
      - uses: actions/setup-node@v4
        with:
          node-version: '20'
      - name: Install shellcheck
        run: sudo apt-get install -y shellcheck
      - name: Run tests
        run: node tests/run-shellcheck-tests.js --verbose
      - name: Upload test results
        if: always()
        uses: actions/upload-artifact@v4
        with:
          name: test-results
          path: test-results/
```

## Additional Features

### Test Coverage Report

- Generate coverage report during test run
- Upload as artifact
- Display in PR comments (future enhancement)

### Badge Integration

- Add test status badge to README
- Show passing/failing status
- Link to latest workflow run

### Notifications

- Notify on test failures
- Include failure details in PR checks
- Block merge on test failures

## Success Criteria

- [ ] Workflow file created
- [ ] Tests run automatically on PR
- [ ] Tests run on push to main
- [ ] shellcheck properly installed in CI
- [ ] Test results visible in PR checks
- [ ] Artifacts uploaded on failure
- [ ] Workflow triggers on relevant file changes only

## Testing the Workflow

- Create test PR with dummy change to shellcheck-apply.sh
- Verify workflow triggers
- Verify tests execute successfully
- Verify results appear in PR checks

## Dependencies

- Phase 1a test suite complete
- Test runner working locally
- GitHub Actions enabled on repository

---

📋 **Part of**: Phase 1b - Extended Components & CI Integration (#139)
🔗 **Source**: ORCHESTRATION_ROADMAP.md
