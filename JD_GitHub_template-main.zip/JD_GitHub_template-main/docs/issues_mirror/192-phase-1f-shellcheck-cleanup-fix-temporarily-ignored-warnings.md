---
issue_number: 192
title: 'Phase 1f: Shellcheck Cleanup - Fix Temporarily Ignored Warnings'
state: open
labels: []
created_at: '2025-11-13T16:27:32Z'
updated_at: '2025-11-13T16:27:37Z'
last_synced_commit: '53e8962'
tokens_estimate: 875
author: Jackson-Devices
---

## Part of Workflow Orchestration System

**Priority**: HIGH  
**Status**: URGENT Technical Debt  
**Estimated Time**: 4-6 hours  
**Upstream Dependencies**: None (can start immediately)

## Problem

The workflow-lint-gate.yml currently ignores 4 shellcheck warning codes to allow CI to pass:

```yaml
actionlint_flags: '-ignore SC2086 -ignore SC2034 -ignore SC2129 -ignore SC2016'
```

This is **temporary technical debt** that masks real shell script quality issues. These warnings indicate:

- **SC2086**: Unquoted variables that can cause word splitting/globbing bugs
- **SC2034**: Unused variables (dead code or typos)
- **SC2129**: Inefficient command grouping/redirection patterns
- **SC2016**: Single quote expansion issues (variables won't expand)

## Goal

Fix ALL shellcheck warnings in the codebase and remove the temporary ignore flags, achieving clean CI passes.

## Tasks

### 1. Audit Current Violations

- Run `shellcheck` on all .sh files to get full violation report
- Categorize violations by SC code and file
- Document current state (baseline)

### 2. Fix SC2086 (Quote Variables)

- Identify all unquoted variable expansions
- Add proper quoting: `"$variable"` instead of `$variable`
- Special cases: arrays, intentional word splitting (use `$*` or `${array[*]}`)
- Test each fix on Windows, Linux, macOS

### 3. Fix SC2034 (Unused Variables)

- Identify genuinely unused variables → remove
- Identify false positives (sourced scripts, exported vars) → add shellcheck directive:
  ```bash
  # shellcheck disable=SC2034
  EXPORTED_VAR="value"  # Used by sourcing script
  ```

### 4. Fix SC2129 (Command Grouping)

- Replace multiple redirects with grouped commands:

  ```bash
  # Before (inefficient)
  echo "line1" >> file
  echo "line2" >> file

  # After (efficient)
  {
    echo "line1"
    echo "line2"
  } >> file
  ```

### 5. Fix SC2016 (Quote Expansion)

- Identify variables in single quotes that should be in double quotes
- Fix: `'$var'` → `"$var"` or mixed quoting for literal dollar signs

### 6. Remove Temporary Ignores

- Edit `.github/workflows/workflow-lint-gate.yml`
- Remove line 38: `actionlint_flags: "-ignore SC2086 -ignore SC2034 -ignore SC2129 -ignore SC2016"`
- Commit with message: "fix: remove shellcheck ignores - all violations resolved"

### 7. Validate on All Platforms

- Run full test suite on Windows
- Run full test suite on Linux (GitHub Actions)
- Run full test suite on macOS (if available)
- Ensure no regressions

### 8. Documentation

- Document common shellcheck patterns in CONTRIBUTING.md or docs/
- Add pre-commit hook recommendation for shellcheck
- Update ORCHESTRATION_ROADMAP.md Phase 1f status

## Success Criteria

- [ ] Zero shellcheck warnings in codebase
- [ ] `actionlint_flags` removed from workflow-lint-gate.yml
- [ ] All CI gates pass cleanly
- [ ] Tests pass on Windows, Linux, macOS
- [ ] Documentation updated

## Related Issues

- Upstream of: Clean CI system (all future work depends on this)
- Related to: #149 (AST-based shellcheck-apply improvements)
- Related to: Phase 1g Windows compatibility issues

## Notes

- This is **blocking** work - many other issues depend on clean CI
- Do NOT use regex/sed to auto-fix - manually review each violation
- Cross-platform testing is CRITICAL (Windows CRLF, path differences)
- Some violations may be intentional - use shellcheck directives with comments

---

🤖 Generated with [Claude Code](https://claude.com/claude-code)

Co-Authored-By: Claude <noreply@anthropic.com>
