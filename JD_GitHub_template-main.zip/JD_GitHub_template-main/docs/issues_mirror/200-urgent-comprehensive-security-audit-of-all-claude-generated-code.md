---
issue_number: 200
title: 'URGENT: Comprehensive Security Audit of All Claude-Generated Code'
state: open
labels:
  - 'AI: Supervised'
  - Needs-Human
  - 'Security: Injection'
  - 'Security: Validation'
  - 'Priority: Urgent'
created_at: '2025-11-14T00:18:22Z'
updated_at: '2025-11-14T00:18:29Z'
last_synced_commit: acc3f91
tokens_estimate: 1018
author: Jackson-Devices
---

## Problem

**All Claude-generated code needs comprehensive security audit.** No systematic security review has been performed on:

- 27 workflow files
- 15+ scripts in .github/scripts/
- Test infrastructure
- Issue templates
- Decision log systems

**Known vulnerabilities to check:**

- Command injection (xargs, sed, eval, sh -c)
- Path traversal (find, file operations)
- Environment variable injection (GITHUB_OUTPUT, etc.)
- Token exposure in logs
- Permission escalation
- Input validation failures
- YAML injection
- Git injection
- Secrets exposure

## Scope: All Claude-Generated Files

### Category 1: Workflows (27 files)

All .github/workflows/\*.yml files need security audit for:

- Command injection via unchecked inputs
- Token/secrets exposure in logs
- Permission over-granting
- Untrusted input handling
- File path validation

### Category 2: Scripts (15+ files)

All scripts in .github/scripts/ and scripts/ need audit for:

- Shell injection vulnerabilities
- Path traversal vulnerabilities
- Input sanitization
- Privilege escalation
- Unsafe file operations

### Category 3: Test Infrastructure

- Test helpers and mocks
- Fixture generation
- Snapshot storage
- Temp file handling

### Category 4: Templates & Configs

- Issue templates (YAML injection)
- Workflow templates
- Config files

## Security Checklist Per File

### Command Injection

- Quote all variables in shell commands
- Never use eval or sh -c with user input
- Validate inputs before passing to xargs, sed, awk
- Check for backticks, semicolons, pipes in inputs

### Path Traversal

- Validate file paths (no ../ sequences)
- Restrict file operations to allowed directories
- Use absolute paths where possible
- Sanitize find command patterns

### Environment Injection

- Quote GITHUB_OUTPUT, GITHUB_ENV writes
- Validate environment variable values
- Check for newline injection in outputs
- Prevent variable overwrite attacks

### Token/Secrets Exposure

- Never log GITHUB_TOKEN
- Redact secrets in error messages
- Check workflow logs for token leaks
- Validate secret scoping

### Input Validation

- Sanitize all PR titles, branch names, filenames
- Check for special characters
- Validate lengths and formats
- Reject malicious patterns

### YAML Injection

- Validate YAML structure before parsing
- Check for billion laughs attacks
- Validate anchor/alias usage
- Sanitize user-provided YAML

### Git Injection

- Quote git commands properly
- Validate branch names
- Validate commit messages
- Check for malicious git config

## High-Risk Areas Identified

### 1. auto-delete-branch.yml

```yaml
ref: heads/${branchName} # Is branchName validated?
```

### 2. shellcheck-apply.sh

```bash
xargs npx prettier --write  # Are filenames validated?
```

### 3. check-pr-risks.mjs

```javascript
execSync with filenames  # Command injection risk?
```

### 4. All \*-apply.yml workflows

Auto-fix workflows that execute code on PRs - highest risk

## Audit Methodology

### Phase 1: Automated Scanning

- Run semgrep with security rules
- Run CodeQL analysis
- Run shellcheck with security flags
- Check for common vulnerability patterns

### Phase 2: Manual Code Review

- Line-by-line review of high-risk areas
- Trace all user input flows
- Validate all shell command constructions
- Check all file operations

### Phase 3: Penetration Testing

- Craft malicious inputs
- Test injection vectors
- Try privilege escalation
- Test error handling

### Phase 4: External Validation

- Submit to security researchers
- Get third-party audit
- Check CVE databases
- Review OWASP guidelines

## Success Criteria

- All command injection vectors identified and fixed
- All path traversal vulnerabilities patched
- All token exposure risks eliminated
- All input validation implemented
- All security tests passing
- External audit confirms no critical vulnerabilities

## Priority

**URGENT** - Security vulnerabilities in CI/CD can compromise entire repo

## Related

- Issue #196: Permissions audit
- Issue #197: Comprehensive workflow testing (security tests)

---

🤖 Generated with Claude Code
