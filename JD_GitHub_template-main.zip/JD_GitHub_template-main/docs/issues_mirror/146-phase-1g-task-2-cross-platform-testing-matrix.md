---
issue_number: 146
title: 'Phase 1g Task 2: Cross-platform testing matrix'
state: open
labels: []
created_at: '2025-11-13T15:31:07Z'
updated_at: '2025-11-13T15:31:12Z'
last_synced_commit: f3eb3fe
tokens_estimate: 761
author: Jackson-Devices
---

## Part of #144

## Objective

Implement comprehensive cross-platform testing to verify scripts work on Windows, macOS, and Linux

## Current State

- Tests only run locally on single platform
- No CI coverage for cross-platform compatibility
- Windows-specific issues not caught until runtime

## Implementation

### Test Matrix Configuration

Add OS matrix to all test workflows:

```yaml
strategy:
  matrix:
    os: [ubuntu-latest, windows-latest, macos-latest]
    node-version: ['18', '20']

runs-on: ${{ matrix.os }}
```

### Platforms to Test

#### 1. Ubuntu (Primary Platform)

- Ubuntu latest (22.04 or newer)
- Default bash shell
- Primary development environment

#### 2. Windows

**Test Configurations**:

- Windows + Git Bash (primary)
- Windows + WSL2 (secondary)
- Windows + PowerShell (shell detection only)

**Considerations**:

- Line endings (CRLF vs LF)
- Path separators (\ vs /)
- Shell availability
- File permissions

#### 3. macOS

- macOS latest (13.x or newer)
- Default bash/zsh shell
- BSD vs GNU tool differences

### Workflow Updates

#### Update: `.github/workflows/test-shellcheck-apply.yml`

```yaml
jobs:
  test:
    strategy:
      matrix:
        os: [ubuntu-latest, windows-latest, macos-latest]
        node-version: ['20']

    runs-on: ${{ matrix.os }}

    steps:
      - uses: actions/checkout@v4

      - uses: actions/setup-node@v4
        with:
          node-version: ${{ matrix.node-version }}

      - name: Install shellcheck (Ubuntu/macOS)
        if: runner.os != 'Windows'
        run: |
          if [ "$RUNNER_OS" = "Linux" ]; then
            sudo apt-get install -y shellcheck
          else
            brew install shellcheck
          fi

      - name: Install shellcheck (Windows)
        if: runner.os == 'Windows'
        run: choco install shellcheck

      - name: Run tests
        run: node tests/run-shellcheck-tests.js --verbose
```

### Platform-Specific Test Cases

Add test cases to verify:

- Line ending handling
- Path separator handling
- Shell execution (bash vs sh)
- File permission differences
- Symlink support
- Case sensitivity

## Success Criteria

- [ ] Test matrix configured for Ubuntu, Windows, macOS
- [ ] All workflows updated with matrix testing
- [ ] shellcheck installed correctly on all platforms
- [ ] All tests pass on Ubuntu
- [ ] All tests pass on Windows (37/37)
- [ ] All tests pass on macOS
- [ ] Platform-specific test cases added
- [ ] CI results visible for all platforms
- [ ] Documentation updated with platform requirements

## Testing Strategy

1. Start with Ubuntu (known working)
2. Fix Windows issues (critical path)
3. Validate on macOS
4. Add platform-specific edge case tests

## Known Issues to Address

- Windows CRLF line endings (#145)
- Windows path separators (fixed)
- Windows shell execution (fixed)

## Dependencies

- Requires: #145 (line ending enforcement)
- Blocks: Phase 1b, Phase 2

---

📋 **Part of**: Phase 1g - Windows/Cross-Platform Compatibility (#144)
🔗 **Source**: ORCHESTRATION_ROADMAP.md
