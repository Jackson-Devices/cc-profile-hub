---
issue_number: 131
title: Add YAML formatter to auto-fix workflow syntax issues
state: closed
labels: []
created_at: '2025-11-12T14:06:51Z'
updated_at: '2025-11-13T23:48:34Z'
last_synced_commit: 08bb6c2
tokens_estimate: 86
author: Jackson-Devices
closed_at: '2025-11-13T23:48:34Z'
---

## Problem

YAML syntax issues in workflows aren't caught until lint gate runs. Need auto-formatter for common issues like quote escaping and multi-line strings.

## Solution

Create workflow-yaml-format-apply.yml to auto-format workflow files before linting.

## Benefits

- Catch YAML issues earlier
- Reduce manual fixes
- Consistent style
