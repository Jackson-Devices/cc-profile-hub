# Issue Mirroring System

This directory contains mirrored copies of all GitHub issues for AI agent access without requiring GitHub API access.

## Purpose

AI agents working in environments without GitHub API access can read issue content by accessing the mirrored files in this directory. This ensures full project context is available to all development tools.

## File Format

Each mirrored issue follows this structure:

```markdown
---
issue_number: 42
title: 'Add JWT authentication to login endpoint'
state: open
labels:
  - 'Type: Feature'
  - 'Difficulty: Medium'
  - 'AI: Supervised'
  - 'Workflow: In-Progress'
created_at: '2025-11-11T10:00:00Z'
updated_at: '2025-11-11T14:30:00Z'
last_synced_commit: 'abc123def456'
tokens_estimate: 450
author: username
---

## Feature Name

Add JWT authentication to login endpoint

## User Outcome

As a developer, I want to implement JWT-based authentication...

[Rest of issue body content]
```

## File Naming Convention

Files are named using the pattern: `{issue-number:03d}-{slugified-title}.md`

Examples:

- `001-setup-project-structure.md`
- `042-add-jwt-authentication-to-login-endpoint.md`
- `123-refactor-testing-framework.md`

## Sync Frequency

Issues are automatically synced within ~5 minutes of:

- Issue creation
- Issue updates (title, body, labels)
- Issue state changes (open → closed, etc.)
- Label changes

## Token Estimation

Each mirror includes a `tokens_estimate` field calculated using the same heuristic as documentation cards:

```
tokens_estimate = CEILING(total_characters / 4)
```

This includes both front-matter and body content.

## Staleness Threshold

Mirrors are considered stale if `last_synced_commit` is more than 24 hours old. The validation system will flag stale mirrors for re-sync.

## Manual Sync

To manually trigger a sync for a specific issue:

```bash
npm run sync-issue <issue-number>
```

To sync all issues:

```bash
npm run sync-all-issues
```

## Mirror vs Doc Cards

**Issue Mirrors:**

- ALL issues are mirrored (no filtering)
- Direct 1:1 copy of GitHub issue content
- Automated sync on every issue change
- Purpose: Ensure AI agents have full project context

**Doc Cards:**

- Only created when additional conceptual documentation is needed
- Self-contained explanations beyond issue content
- Manually authored and curated
- Purpose: Provide implementation guidance and patterns

## Workflow Integration

The issue mirroring system integrates with the label taxonomy:

- `Docs: Needed` - Issue needs additional conceptual doc cards
- `Docs: Ready` - Doc cards written and validated
- `Docs: Not-Needed` - Issue mirror is sufficient documentation
- `Docs: Ingested` - Mirror + cards + bundles all complete

## Front-Matter Fields

| Field                | Type     | Description                      |
| -------------------- | -------- | -------------------------------- |
| `issue_number`       | integer  | GitHub issue number              |
| `title`              | string   | Issue title                      |
| `state`              | enum     | `open`, `closed`                 |
| `labels`             | array    | All labels applied to issue      |
| `created_at`         | datetime | ISO 8601 timestamp               |
| `updated_at`         | datetime | ISO 8601 timestamp               |
| `last_synced_commit` | string   | Git commit hash when last synced |
| `tokens_estimate`    | integer  | Estimated token count            |
| `author`             | string   | GitHub username of issue creator |
| `assignees`          | array    | GitHub usernames (optional)      |
| `milestone`          | string   | Milestone name (optional)        |
| `closed_at`          | datetime | ISO 8601 timestamp (if closed)   |

## Implementation Notes

### Sync Script

The sync script (`scripts/sync-issue-mirror.js`) handles:

1. Fetching issue data via GitHub API
2. Rendering front-matter with metadata
3. Rendering body content in markdown
4. Writing mirror file with proper naming
5. Token estimation

### GitHub Actions Workflow

The workflow (`.github/workflows/issue-mirror-sync.yml`) triggers on:

```yaml
on:
  issues:
    types: [opened, edited, closed, reopened, labeled, unlabeled]
```

### Closed Issues

Closed issues are NOT deleted from the mirror. Instead:

- The `state` field is updated to `closed`
- The `closed_at` timestamp is added
- The file remains for historical reference

## Troubleshooting

### Mirror file missing

If an issue is not mirrored:

1. Check if the workflow ran: `gh run list --workflow=issue-mirror-sync.yml`
2. Check workflow logs for errors
3. Manually trigger sync: `npm run sync-issue <number>`

### Mirror content outdated

If a mirror's content doesn't match the current issue:

1. Check `last_synced_commit` age
2. Check if workflow is enabled
3. Manually trigger sync

### Token estimate inaccurate

Token estimates may drift by ±10%. This is acceptable variance. If drift exceeds this:

1. Check character count includes both front-matter and body
2. Verify calculation: `characters / 4` rounded up
3. Re-sync the mirror

## Future Enhancements

Potential future features (not in current scope):

- Comments mirroring (append to mirror file)
- Pull request mirroring
- Mirror index file for quick lookup
- Selective mirroring with filters
- Real-time sync (< 1 minute latency)

---

**Last Updated:** 2025-11-12
**Related:** [Token-Efficient Documentation System](../FEATURE_token_efficient_docs_system.md), [SUB_FEATURE_03_issue_mirroring.md](../../SUB_FEATURE_03_issue_mirroring.md)
