---
issue_number: 124
title: 'FUNCTION: Auto-Create PR on Commit'
state: open
labels:
  - 'Difficulty: Easy'
  - 'AI: Autonomous'
  - 'Workflow: Backlog'
  - 'Type: Feature'
  - 'Type: Function'
created_at: '2025-11-12T04:03:23Z'
updated_at: '2025-11-12T04:03:31Z'
last_synced_commit: 40428a2
tokens_estimate: 544
author: Jackson-Devices
---

# FUNCTION: GitHub Action - Auto-Create PR on Commit

## Overview

GitHub Action that automatically creates a pull request when a commit is pushed to a `claude/**` branch, using the commit message as the PR description.

**Problem**: Manual PR creation is repetitive when following one-commit-per-branch policy.

**Solution**: Workflow that:

1. Triggers on push to `claude/**` branches
2. Checks if PR already exists
3. If no PR: Creates PR with commit message as description
4. Uses full commit message (including body) for PR description

---

## Technical Approach

**File**: `.github/workflows/auto-create-pr.yml`

**Trigger**: `push` to `claude/**` branches

**Logic**:

```yaml
name: Auto-Create PR

on:
  push:
    branches:
      - 'claude/**'

jobs:
  create-pr:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v4

      - name: Check if PR exists
        id: check
        run: |
          PR_EXISTS=$(gh pr list --head ${{ github.ref_name }} --json number --jq length)
          echo "exists=$PR_EXISTS" >> $GITHUB_OUTPUT
        env:
          GH_TOKEN: ${{ github.token }}

      - name: Get commit message
        if: steps.check.outputs.exists == '0'
        id: commit
        run: |
          # Get full commit message (title + body)
          MSG=$(git log -1 --pretty=%B)
          echo "message<<EOF" >> $GITHUB_OUTPUT
          echo "$MSG" >> $GITHUB_OUTPUT
          echo "EOF" >> $GITHUB_OUTPUT

      - name: Create PR
        if: steps.check.outputs.exists == '0'
        run: |
          gh pr create \
            --title "$(git log -1 --pretty=%s)" \
            --body "${{ steps.commit.outputs.message }}"
        env:
          GH_TOKEN: ${{ github.token }}
```

---

## Acceptance Criteria

- [ ] Auto-creates PR on first push to `claude/**` branch
- [ ] Uses commit title as PR title
- [ ] Uses full commit message as PR body
- [ ] Does NOT create duplicate PRs
- [ ] Works with auto-fix commits (format-gate, eslint-gate)

---

🤖 Generated with [Claude Code](https://claude.com/claude-code)

Co-Authored-By: Claude <noreply@anthropic.com>
