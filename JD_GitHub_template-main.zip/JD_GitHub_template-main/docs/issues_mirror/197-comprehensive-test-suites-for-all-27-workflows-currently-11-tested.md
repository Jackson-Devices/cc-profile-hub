---
issue_number: 197
title: Comprehensive Test Suites for All 27 Workflows (Currently 11% tested)
state: open
labels:
  - 'AI: Supervised'
  - 'Type: Tooling'
  - Needs-Human
  - 'Technique: Unit'
  - 'Technique: Integration'
  - 'Priority: High'
created_at: '2025-11-14T00:03:54Z'
updated_at: '2025-11-14T00:03:59Z'
last_synced_commit: 6bc291b
tokens_estimate: 2017
author: Jackson-Devices
---

# Comprehensive Test Suites for All 27 Workflows

## Problem

Only **3 workflows have test coverage** out of 27 total. The YAML formatter test suite audit (Issue #195) revealed that even tested workflows have only 12.7% coverage of the comprehensive test taxonomy.

**Current test coverage:**

- ✅ check-pr-risks.mjs test (partial)
- ✅ workflow-yaml-format-apply test (12.7% coverage - Issue #195)
- ✅ auto-delete-branch test (exists but untested for permissions failure - Issue #196)
- ❌ **24 workflows completely untested**

**Test coverage target:** 80% minimum across all label taxonomy categories

## Workflows Requiring Comprehensive Test Suites

### Category 1: Auto-Fix Workflows (7)

1. **eslint-apply.yml** - Auto-fixes ESLint violations
2. **format-apply.yml** - Auto-formats code with Prettier
3. **workflow-lint-apply.yml** - Auto-fixes shellcheck violations in workflows
4. **workflow-yaml-format-apply.yml** - Auto-formats workflow YAML (Issue #195 tracking tests)
5. **auto-squash-commits.yml** - Auto-squashes commits
6. **apply_settings.yml** - Applies repo settings
7. **decision_log_writer.yml** - Auto-generates decision logs

### Category 2: Gate/Validation Workflows (9)

8. **eslint-gate.yml** - Blocks on ESLint violations
9. **format-gate.yml** - Blocks on formatting violations
10. **workflow-lint-gate.yml** - Blocks on workflow lint violations
11. **docs-drift-gate.yml** - Blocks on documentation drift
12. **enforce_test_gate.yml** - Enforces test requirements
13. **prevent-sequential-commits-gate.yml** - Blocks sequential commits
14. **pr-risk-gate.yml** - Blocks risky PR patterns
15. **validate-function.yml** - Validates Function issue format
16. **validate-issue.yml** - Validates generic issue format
17. **validate-sub-feature.yml** - Validates Sub-Feature issue format
18. **validate-test-suite.yml** - Validates Test-Suite issue format

### Category 3: Check/Report Workflows (4)

19. **eslint-check.yml** - Reports ESLint violations (non-blocking)
20. **format-check.yml** - Reports formatting violations (non-blocking)
21. **lint-check.yml** - Generic lint checking
22. **pr-risk-check.yml** - Reports PR risks (non-blocking)

### Category 4: Automation/Orchestration Workflows (5)

23. **auto-delete-branch.yml** - Auto-deletes merged branches (Issue #196 tracking permission tests)
24. **orchestrator.yml** - Coordinates workflow execution
25. **context-commands.yml** - Handles context commands
26. **issue-mirror-sync.yml** - Syncs issue mirrors
27. **seed-test-runlist.yml** - Seeds test run lists

## Test Taxonomy (Per Label System)

Each workflow requires tests across ALL applicable categories:

### Test-Type

- **Simple** - Single behavior, minimal branching
- **Simple-Edge** - Narrow edge condition, straightforward setup
- **Complex** - Layered setup, multiple validation cases
- **Complex-Edge** - Multi-step unlikely scenarios

### Technique

- **Unit** - Function-level, direct inputs/outputs
- **Integration** - Multiple components, realistic interactions
- **End-to-End** - Full system flow, entry to output
- **Snapshot** - Output comparison vs saved snapshots
- **Regression** - Prove fixed bugs stay fixed
- **Benchmark** - Performance thresholds, resource tracking
- **Property-Based** - Generated inputs, invariant assertions
- **Mutation** - Verify test sensitivity
- **Fuzz** - Malformed/unpredictable inputs
- **Contract** - Schema/version compatibility
- **Observability** - Logs/metrics/traces validation

### Security

- **Auth** - Authentication flows (valid/invalid/expired)
- **Authorization** - Permission boundaries, role enforcement
- **Injection** - SQL/script/template injection prevention
- **Validation** - Input/output validation, encoding/escaping
- **Crypto** - Key/hash/randomness handling
- **Threat-Lite** - Threat-model-derived defenses

### Environment

- **Synthetic** - Mocked/simulated (current state for most)
- **Hardware** - Real device/hardware (future consideration)

### Resource

- **High-CPU** - Requires CPU/wall-time estimate
- **Network-Dependent** - Requires network I/O

### Artifact

- **Determinism-Kit** - Reproducible test runs (seeds/clocks/env)
- **Error-Taxonomy** - Canonical error codes
- **Observability-Spec** - Required metrics/logs/traces
- **ADR** - Architecture decision records
- **RFC** - Pre-implementation proposals

## Test Coverage Targets (Per Workflow)

### Minimum (Phase 1) - 50%

- Unit tests (positive + negative)
- Integration tests (basic workflows)
- Security validation (injection, input validation)
- Cross-platform (Windows, Linux, macOS)

### Production-Ready (Phase 2) - 80%

- All Phase 1 tests
- Snapshot testing (regression detection)
- Benchmark testing (performance thresholds)
- Observability validation
- Error taxonomy
- Contract testing

### Ideal (Phase 3) - 95%

- All Phase 2 tests
- Property-based testing
- Mutation testing
- Fuzz testing
- End-to-end integration
- Determinism kit

## Priority Classification

### URGENT (Blocking Production Use)

Auto-fix workflows that modify code - **MUST have 80% coverage before auto-trigger**:

1. eslint-apply.yml
2. format-apply.yml
3. workflow-lint-apply.yml
4. workflow-yaml-format-apply.yml (Issue #195)
5. auto-squash-commits.yml

### HIGH (Critical Gates)

Gate workflows that block PRs - **MUST have 80% coverage**: 6. eslint-gate.yml 7. format-gate.yml 8. workflow-lint-gate.yml 9. prevent-sequential-commits-gate.yml 10. pr-risk-gate.yml

### MEDIUM (Validation & Automation)

Validation and automation workflows - **Target 80% coverage**:
11-27. All remaining workflows

## Test Implementation Strategy

### Per-Workflow Test Suite Structure

```
tests/workflows/<workflow-name>/
├── unit/
│   ├── positive-cases.test.mjs
│   ├── negative-cases.test.mjs
│   ├── edge-cases.test.mjs
│   └── error-handling.test.mjs
├── integration/
│   ├── workflow-interaction.test.mjs
│   ├── git-operations.test.mjs
│   └── github-api.test.mjs
├── security/
│   ├── injection.test.mjs
│   ├── validation.test.mjs
│   ├── authorization.test.mjs
│   └── auth.test.mjs
├── performance/
│   ├── benchmark.test.mjs
│   ├── timeout.test.mjs
│   └── resource-limits.test.mjs
├── regression/
│   ├── bug-corpus.test.mjs
│   └── snapshots/
├── cross-platform/
│   ├── windows.test.mjs
│   ├── linux.test.mjs
│   └── macos.test.mjs
├── observability/
│   ├── logging.test.mjs
│   ├── github-output.test.mjs
│   └── artifacts.test.mjs
└── property-based/
    ├── invariants.test.mjs
    └── generators.mjs
```

### Shared Test Infrastructure

Create reusable test helpers:

- **Mock GitHub API** - Consistent API mocking across tests
- **Mock Git operations** - Deterministic git behavior
- **Temp file helpers** - Cross-platform temp file management
- **Snapshot matchers** - Consistent snapshot testing
- **Permission testers** - Simulate permission scenarios
- **Performance profilers** - Benchmark measurement utilities

## Success Criteria

- [ ] All 27 workflows have test suites
- [ ] URGENT workflows: 80% coverage minimum
- [ ] HIGH workflows: 80% coverage minimum
- [ ] MEDIUM workflows: 50% coverage minimum
- [ ] All tests run on Windows, Linux, macOS
- [ ] All security tests validate no vulnerabilities
- [ ] Shared test infrastructure reduces duplication
- [ ] CI enforces minimum coverage thresholds
- [ ] Test coverage badges in README

## Related Issues

- Issue #195: YAML formatter test suite (12.7% → 80%)
- Issue #196: Workflow permissions audit (authorization testing)
- Issue #26: Comprehensive testing infrastructure (parent)

## Implementation Approach

1. **Create test templates** - Standard structure for workflow tests
2. **Build shared infrastructure** - Reusable mocks, helpers, utilities
3. **Prioritize URGENT workflows** - Auto-fix workflows first
4. **Parallel implementation** - Multiple workflows can be tested concurrently
5. **Incremental coverage** - Phase 1 → Phase 2 → Phase 3 for each workflow
6. **CI integration** - Enforce coverage thresholds per workflow
7. **Documentation** - Test writing guide, patterns, examples

---

🤖 Generated with Claude Code
