---
issue_number: 139
title: 'Phase 1b: Extended Components & CI Integration'
state: open
labels: []
created_at: '2025-11-13T15:27:30Z'
updated_at: '2025-11-13T15:27:34Z'
last_synced_commit: ddb3981
tokens_estimate: 499
author: Jackson-Devices
---

## Goal

Complete remaining Phase 1a components and integrate with CI

## Status

📋 Planned

## Target

Week of 2025-11-18

## Overview

This phase extends the core shellcheck-apply.sh infrastructure with comprehensive unit tests, snapshot tests, CI integration, and additional orchestration components.

## Components

### 1. Unit Tests for shellcheck-apply.sh

**Location**: `tests/unit/shellcheck-apply/`

Tests to implement:

- Individual fix functions (fix_sc2086, fix_sc2046, etc.)
- Strategy selection logic
- Pass counting logic
- Backup/restore operations

**Target**: 20+ unit tests

### 2. Snapshot Tests

**Location**: `tests/snapshots/shellcheck-apply/`

Snapshots to create:

- Conservative strategy output
- Balanced strategy output
- Aggressive strategy output
- Multi-pass output
- Failure output
- Escalation output

**Target**: 10+ snapshot tests

### 3. CI Integration

**File**: `.github/workflows/test-shellcheck-apply.yml`

Workflow configuration:

- Trigger on PR changes to shellcheck-apply.sh and tests
- Run on Ubuntu with Node 20 and shellcheck
- Execute full test suite with verbose output

### 4. Additional Components

- **workflow-apply.sh** - Apply shellcheck fixes to workflow files
- **lint-gate.sh** - Enforce linting gates with auto-fix option
- **format-apply.sh** - Auto-format shell scripts

## Success Criteria

- [ ] All unit tests implemented and passing
- [ ] All snapshot tests created
- [ ] CI workflow running on all PRs
- [ ] Test coverage report generated
- [ ] Additional components implemented
- [ ] Documentation updated

## Dependencies

- Requires Phase 1a completion
- Requires Phase 1g (Windows compatibility) for reliable test execution

## Related Issues

Child issues will be created for each component:

- Unit tests for shellcheck-apply.sh
- Snapshot tests for shellcheck-apply.sh
- CI integration workflow
- Additional orchestration components

---

📋 **Part of**: Orchestration System Development Roadmap
🔗 **Source**: ORCHESTRATION_ROADMAP.md
