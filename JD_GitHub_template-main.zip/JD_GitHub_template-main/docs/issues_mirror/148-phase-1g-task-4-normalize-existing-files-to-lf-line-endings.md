---
issue_number: 148
title: 'Phase 1g Task 4: Normalize existing files to LF line endings'
state: open
labels: []
created_at: '2025-11-13T15:32:13Z'
updated_at: '2025-11-13T15:32:18Z'
last_synced_commit: 89770ad
tokens_estimate: 800
author: Jackson-Devices
---

## Part of #144

## Objective

Convert all existing shell scripts from CRLF to LF line endings as a one-time fix

## Problem

Many existing `.sh` files in the repository have CRLF line endings, causing:

- Test failures on Windows (30/37 tests failing)
- Bash parsing errors with variables
- Blocked PR merges

## Prerequisites

- #145 must be completed first (.gitattributes configured)
- Line ending validation workflow in place

## Implementation Steps

### Step 1: Identify Files with CRLF

```bash
# Find all shell scripts with CRLF
git ls-files '*.sh' '*.bash' '.github/scripts/*.sh' | while read file; do
  if file "$file" | grep -q CRLF; then
    echo "$file"
  fi
done
```

Or use Git to check:

```bash
git grep -I --files-with-matches $'\r' -- '*.sh' '*.bash' '.github/scripts/*.sh'
```

### Step 2: Convert to LF

**Option 1: Using dos2unix**

```bash
# Install dos2unix (if not available)
# Ubuntu: sudo apt-get install dos2unix
# macOS: brew install dos2unix
# Windows: choco install dos2unix

# Convert all shell scripts
find . -name "*.sh" -exec dos2unix {} \;
```

**Option 2: Using Git**

```bash
# Re-checkout files with LF line endings (after .gitattributes is set)
git add --renormalize .
git status  # Should show modified shell scripts
```

**Option 3: Using sed (cross-platform)**

```bash
# Remove CR characters
find . -name "*.sh" -exec sed -i 's/\r$//' {} \;
```

### Step 3: Verify Conversion

```bash
# Check that no CRLF remains
git grep -I --files-with-matches $'\r' -- '*.sh' '*.bash' '.github/scripts/*.sh'
# Should return nothing

# Check file line endings
file .github/scripts/shellcheck-apply.sh
# Should show: "ASCII text" (not "ASCII text, with CRLF line terminators")
```

### Step 4: Commit Changes

```bash
git add .
git commit -m "fix: normalize all shell scripts to LF line endings

- Convert CRLF → LF in all .sh and .bash files
- Fixes Windows bash parsing errors
- Enables test suite to pass on Windows (37/37 tests)
- Part of Phase 1g cross-platform compatibility

Part of #144"
```

### Step 5: Test on Windows

- Pull changes on Windows machine
- Verify files have LF line endings
- Run test suite: `node tests/run-shellcheck-tests.js`
- Verify all 37 tests pass

## Files to Normalize

Likely candidates (check with git grep):

- `.github/scripts/*.sh`
- `tests/fixtures/mock_scripts/*.sh`
- Any other shell scripts in repository

## Success Criteria

- [ ] All `.sh` files identified
- [ ] All CRLF → LF conversions completed
- [ ] No CRLF remaining (verified with git grep)
- [ ] Changes committed with descriptive message
- [ ] Test suite passes on Windows (37/37)
- [ ] Validation workflow passes
- [ ] `.gitattributes` prevents future CRLF issues

## Rollback Plan

If normalization causes issues:

```bash
git revert <commit-hash>
```

## Documentation

Document the normalization process in commit message and/or:

- Update `docs/WINDOWS_COMPATIBILITY.md` (#147)
- Add note to `tests/README.md`

## Dependencies

- Requires: #145 (.gitattributes configuration)
- Blocks: #146 (cross-platform testing)
- Blocks: All future shell script development

---

📋 **Part of**: Phase 1g - Windows/Cross-Platform Compatibility (#144)
🔗 **Source**: ORCHESTRATION_ROADMAP.md
