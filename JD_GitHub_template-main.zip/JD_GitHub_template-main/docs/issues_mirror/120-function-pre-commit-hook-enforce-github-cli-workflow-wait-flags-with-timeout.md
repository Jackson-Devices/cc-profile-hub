---
issue_number: 120
title: 'FUNCTION: Pre-Commit Hook - Enforce GitHub CLI Workflow Wait Flags with Timeout'
state: open
labels:
  - 'Difficulty: Medium'
  - 'AI: Supervised'
  - 'Workflow: Backlog'
  - 'Type: Feature'
  - 'Type: Function'
created_at: '2025-11-12T03:25:56Z'
updated_at: '2025-11-12T03:26:04Z'
last_synced_commit: 57fcd57
tokens_estimate: 4514
author: Jackson-Devices
---

# FUNCTION: Pre-Commit Hook - Enforce GitHub CLI Workflow Wait Flags with Timeout

## Overview

Create a pre-commit hook that prevents commits containing inefficient GitHub CLI workflow polling patterns (manual sleep loops, repeated status checks) and enforces the use of `--watch` with mandatory timeout protection.

**Problem**: Manually polling workflow status with sleep loops wastes time and provides poor UX. The correct approach is using `gh run watch` or similar commands WITH timeout flags, but developers often forget the timeout protection.

**Solution**: Pre-commit hook that:

1. Detects manual polling patterns (sleep loops checking `gh run view`, etc.)
2. Enforces use of `--watch` flags for workflow monitoring
3. Requires timeout flags on ALL watch commands to prevent indefinite blocking
4. Provides helpful error messages showing the correct pattern

---

## Problem Statement / Motivation

When working with GitHub Actions workflows via the CLI, there are two anti-patterns to avoid:

### Anti-Pattern 1: Manual Polling Loops

```bash
# ❌ VERY BAD - Manual polling with arbitrary sleeps
while true; do
  gh run view $RUN_ID --json status
  sleep 5
  # ... check status manually
done
```

### Anti-Pattern 2: Watch Without Timeout

```bash
# ❌ BAD - Can block indefinitely if workflow hangs
gh run watch $RUN_ID

# ❌ BAD - No timeout protection
gh pr checks --watch
```

### The CORRECT Pattern

```bash
# ✅ BEST - Watch with timeout (default: 5m, configurable)
gh run watch $RUN_ID --timeout 5m

# ✅ GOOD - Explicit timeout override when needed
gh run watch $RUN_ID --timeout 15m

# ✅ GOOD - Alternative with exit-on-timeout
gh pr checks --watch --interval 10 --exit-on-timeout
```

**The Risk**:

- Manual polling wastes developer time checking status
- Commands without timeout can hang indefinitely if workflows fail
- No clear failure signal when workflows stall
- Scripts become unreliable in CI/CD contexts

**The Goal**:

- Detect and block manual polling patterns (sleep loops)
- Enforce use of `--watch` flags for efficient waiting
- Require timeout protection on ALL watch commands
- Support configurable timeout defaults with override capability
- Provide clear error messages with fix instructions
- Maintain cross-platform compatibility (Windows/Linux/macOS)

---

## Proposed Solution

### Pre-Commit Hook Implementation

**File**: `scripts/pre-commit-gh-wait-check.sh`

**Triggers**: Before each local commit

**Behavior**:

1. Scan all staged files for GitHub CLI commands
2. **Detect Anti-Pattern #1**: Manual polling loops (`while` + `sleep` + `gh run view/list`)
3. **Detect Anti-Pattern #2**: Watch commands without timeout flags
4. Block commit if violations found, with helpful error message
5. Support configurable default timeout via repo variable
6. Allow override with special comment syntax

### Patterns to Detect

**Anti-Pattern #1: Manual Polling**

- `while` loops containing `gh run view` or `gh run list` or `gh pr view`
- Commands with `sleep` followed by workflow status checks
- Repeated `gh` commands in loops without `--watch`

**Anti-Pattern #2: Watch Without Timeout**

- `gh run watch` without `--timeout <duration>`
- `gh pr checks --watch` without `--timeout` OR (`--interval` + `--exit-on-timeout`)
- `gh workflow run --watch` without `--timeout <duration>`

### Default Timeout Configuration

**Repo Variable**: `GH_WATCH_DEFAULT_TIMEOUT`

- **Default value**: `5m` (5 minutes)
- **Override in code**: Use explicit `--timeout <value>` flag
- **Purpose**: Ensures all watch commands have reasonable timeout protection

**File types to scan**:

- Shell scripts: `*.sh`, `*.bash`, `*.zsh`
- GitHub Actions workflows: `*.yml`, `*.yaml` (in `.github/workflows/`)
- Documentation: `*.md` (code blocks only)
- JavaScript: `*.js`, `*.mjs` (string literals with `gh` commands)

### Override Mechanism

Allow bypassing the check with special comment syntax:

```bash
# gh-wait-override: needs 30m timeout for integration tests
gh run watch $RUN_ID --timeout 30m  # Override default 5m timeout

# gh-wait-override: interactive debugging session
gh run watch $RUN_ID  # No timeout during manual debugging
```

**Requirements for override**:

- Must be on same line or line immediately before command
- Must include meaningful explanation (minimum 10 characters)
- Explanation logged for review
- Overrides allow both missing timeout AND custom timeout values

---

## Technical Approach

### Hook Architecture

```bash
#!/bin/bash
# Pre-commit hook to enforce GitHub CLI workflow wait patterns with timeout

set -e

# Get default timeout from repo variable (fallback to 5m)
DEFAULT_TIMEOUT="${GH_WATCH_DEFAULT_TIMEOUT:-5m}"

# Get list of staged files
STAGED_FILES=$(git diff --cached --name-only --diff-filter=ACM)

# Filter to relevant file types
SCAN_FILES=$(echo "$STAGED_FILES" | grep -E '\.(sh|bash|zsh|yml|yaml|js|mjs|md)$' || true)

if [ -z "$SCAN_FILES" ]; then
    exit 0  # No relevant files to scan
fi

# Scan each file for violations
VIOLATIONS=()
POLLING_VIOLATIONS=()

for file in $SCAN_FILES; do
    # Anti-Pattern #1: Detect manual polling loops
    # Look for while loops with sleep + gh commands
    if grep -Pzo '(?s)while.*?do.*?(sleep|gh (run|pr|workflow) (view|list)).*?done' "$file" | grep -q .; then
        if ! grep -q "gh-wait-override" "$file"; then
            POLLING_VIOLATIONS+=("$file: Manual polling loop detected (use 'gh run watch --timeout ${DEFAULT_TIMEOUT}' instead)")
        fi
    fi

    # Anti-Pattern #2a: gh run watch without --timeout
    if grep -n "gh run watch" "$file" | grep -v "\-\-timeout" | grep -v "gh-wait-override"; then
        VIOLATIONS+=("$file: 'gh run watch' requires --timeout flag (default: ${DEFAULT_TIMEOUT})")
    fi

    # Anti-Pattern #2b: gh pr checks --watch without proper flags
    if grep -n "gh pr checks.*--watch" "$file" | grep -Ev "(\-\-interval.*\-\-exit-on-timeout|\-\-timeout)" | grep -v "gh-wait-override"; then
        VIOLATIONS+=("$file: 'gh pr checks --watch' requires --timeout or --exit-on-timeout")
    fi

    # Anti-Pattern #2c: gh workflow run --watch without --timeout
    if grep -n "gh workflow run.*--watch" "$file" | grep -v "\-\-timeout" | grep -v "gh-wait-override"; then
        VIOLATIONS+=("$file: 'gh workflow run --watch' requires --timeout flag (default: ${DEFAULT_TIMEOUT})")
    fi
done

# If violations found, block commit
TOTAL_VIOLATIONS=$((${#VIOLATIONS[@]} + ${#POLLING_VIOLATIONS[@]}))

if [ $TOTAL_VIOLATIONS -gt 0 ]; then
    cat << 'EOF'
❌ COMMIT BLOCKED: Inefficient workflow waiting patterns detected
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

Use GitHub CLI's built-in --watch flags WITH timeout protection instead of
manual polling loops or indefinite waits.

EOF

    if [ ${#POLLING_VIOLATIONS[@]} -gt 0 ]; then
        echo "📋 MANUAL POLLING DETECTED (use --watch instead):"
        for violation in "${POLLING_VIOLATIONS[@]}"; do
            echo "   • $violation"
        done
        echo ""
    fi

    if [ ${#VIOLATIONS[@]} -gt 0 ]; then
        echo "📋 MISSING TIMEOUT FLAGS:"
        for violation in "${VIOLATIONS[@]}"; do
            echo "   • $violation"
        done
        echo ""
    fi

    cat << EOF

🔧 HOW TO FIX:

For 'gh run watch' (default timeout: ${DEFAULT_TIMEOUT}):
    gh run watch <run-id> --timeout ${DEFAULT_TIMEOUT}

For custom timeout:
    gh run watch <run-id> --timeout 15m

For 'gh pr checks --watch':
    gh pr checks <pr-number> --watch --interval 10 --exit-on-timeout

For 'gh workflow run --watch':
    gh workflow run <workflow> --watch --timeout ${DEFAULT_TIMEOUT}

Replace manual polling loops with:
    # ❌ BAD
    while true; do
      gh run view \$RUN_ID --json status
      sleep 5
    done

    # ✅ GOOD
    gh run watch \$RUN_ID --timeout ${DEFAULT_TIMEOUT}

💡 OVERRIDE (if absolutely necessary):
    # gh-wait-override: needs 30m for long integration test
    gh run watch <run-id> --timeout 30m

    # gh-wait-override: interactive debugging session
    gh run watch <run-id>  # No timeout

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
EOF
    exit 1
fi

# All checks passed
exit 0
```

### Installation Script

**File**: `scripts/install-gh-wait-hook.sh`

```bash
#!/bin/bash
# Installation script for GitHub CLI wait flag enforcement hook

set -e

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
HOOK_SOURCE="${SCRIPT_DIR}/pre-commit-gh-wait-check.sh"
HOOK_DEST=".git/hooks/pre-commit"

echo "🔧 Installing GitHub CLI Wait Flag Enforcement Hook"
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"

# Check if .git directory exists
if [ ! -d ".git" ]; then
    echo "❌ Error: Not in a git repository root"
    exit 1
fi

# Check if hook source exists
if [ ! -f "$HOOK_SOURCE" ]; then
    echo "❌ Error: Hook source not found at $HOOK_SOURCE"
    exit 1
fi

# Handle existing pre-commit hook
if [ -f "$HOOK_DEST" ]; then
    # Check if it's our sequential commit hook
    if grep -q "Sequential commit prevention" "$HOOK_DEST"; then
        echo "📦 Combining with existing sequential commit hook"
        # Create combined hook that runs both
        COMBINED_HOOK="${HOOK_DEST}.combined"
        cat > "$COMBINED_HOOK" << 'HOOK_EOF'
#!/bin/bash
# Combined pre-commit hook: Sequential commits + GH wait flags

# Run sequential commit check
if [ -f ".git/hooks/pre-commit.sequential" ]; then
    bash .git/hooks/pre-commit.sequential || exit 1
fi

# Run GH wait flag check
if [ -f ".git/hooks/pre-commit.gh-wait" ]; then
    bash .git/hooks/pre-commit.gh-wait || exit 1
fi

exit 0
HOOK_EOF

        # Save existing hooks
        mv "$HOOK_DEST" ".git/hooks/pre-commit.sequential"
        cp "$HOOK_SOURCE" ".git/hooks/pre-commit.gh-wait"
        mv "$COMBINED_HOOK" "$HOOK_DEST"
        chmod +x "$HOOK_DEST" .git/hooks/pre-commit.*

        echo "✅ Combined hook installed"
    else
        # Unknown hook, backup
        BACKUP="${HOOK_DEST}.backup.$(date +%Y%m%d_%H%M%S)"
        echo "📦 Backing up existing pre-commit hook to: ${BACKUP}"
        cp "$HOOK_DEST" "$BACKUP"

        # Install our hook
        cp "$HOOK_SOURCE" "$HOOK_DEST"
        chmod +x "$HOOK_DEST"
        echo "✅ Hook installed (previous hook backed up)"
    fi
else
    # No existing hook, simple install
    cp "$HOOK_SOURCE" "$HOOK_DEST"
    chmod +x "$HOOK_DEST"
    echo "✅ Hook installed"
fi

echo ""
echo "📋 What this hook does:"
echo "   • Scans staged files for GitHub CLI wait commands"
echo "   • Enforces --timeout or --exit-on-timeout flags"
echo "   • Provides clear fix instructions on failure"
echo ""
echo "🔧 To uninstall:"
echo "   rm .git/hooks/pre-commit"
echo ""
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
```

### Pattern Detection Details

**Regex patterns** (handle common variations):

```bash
# Match 'gh run watch' without --timeout
gh\s+run\s+watch(?!.*--timeout)

# Match 'gh pr checks --watch' without proper flags
gh\s+pr\s+checks.*--watch(?!.*(--interval.*--exit-on-timeout|--timeout))

# Match 'gh workflow run --watch' without --timeout
gh\s+workflow\s+run.*--watch(?!.*--timeout)
```

**Override detection**:

```bash
# Look for override comment on same line or previous line
# gh-wait-override: <explanation>
```

**Minimum explanation length**: 10 characters (prevent lazy overrides like "# gh-wait-override: ok")

---

## Implementation Plan

### Phase 1: Core Hook (Week 1)

1. **Create hook script** (`pre-commit-gh-wait-check.sh`)
   - Implement file scanning logic
   - Add pattern detection for `gh run watch`
   - Add basic error reporting
   - Test on sample shell scripts

2. **Create installation script** (`install-gh-wait-hook.sh`)
   - Handle existing hooks (backup/combine)
   - Add combined hook support for sequential commit hook
   - Provide clear installation feedback

3. **Write documentation** (`docs/GH_WAIT_FLAG_ENFORCEMENT.md`)
   - Explain why timeout flags are required
   - Show examples of correct vs incorrect usage
   - Document override mechanism
   - Include troubleshooting section

### Phase 2: Extended Coverage (Week 2)

4. **Add pattern detection** for:
   - `gh pr checks --watch`
   - `gh workflow run --watch`
   - Commands in YAML workflows
   - Commands in JavaScript string literals

5. **Improve error messages**:
   - Show line numbers where violations found
   - Suggest specific fixes for each violation type
   - Colorize output for better readability

6. **Add override mechanism**:
   - Parse `gh-wait-override` comments
   - Validate explanation length
   - Log overrides for review

### Phase 3: Testing & Refinement (Week 3)

7. **Create test fixtures**:
   - Valid scripts with proper timeout flags
   - Invalid scripts with violations
   - Edge cases (multi-line commands, comments)

8. **Cross-platform testing**:
   - Test on Windows (Git Bash, WSL)
   - Test on macOS
   - Test on Linux

9. **Documentation**:
   - Add quick start guide
   - Include in main README
   - Update CONTRIBUTING.md with hook requirements

---

## Acceptance Criteria

### Functional Requirements

- [ ] **Hook detects** manual polling loops (`while` + `sleep` + `gh` commands)
- [ ] **Hook suggests** replacing polling with `gh run watch --timeout`
- [ ] **Hook detects** `gh run watch` without `--timeout`
- [ ] **Hook detects** `gh pr checks --watch` without proper timeout flags
- [ ] **Hook detects** `gh workflow run --watch` without `--timeout`
- [ ] **Hook uses** configurable default timeout via `GH_WATCH_DEFAULT_TIMEOUT` (default: 5m)
- [ ] **Hook scans** shell scripts (`.sh`, `.bash`, `.zsh`)
- [ ] **Hook scans** workflows (`.yml`, `.yaml` in `.github/workflows/`)
- [ ] **Hook scans** JavaScript files (`.js`, `.mjs`)
- [ ] **Hook scans** Markdown code blocks
- [ ] **Override mechanism** works with `gh-wait-override` comment
- [ ] **Override requires** minimum 10-character explanation
- [ ] **Error messages** show file names and categorize violations
- [ ] **Error messages** suggest specific fixes with default timeout value
- [ ] **Error messages** show examples of correct vs incorrect patterns
- [ ] **Installation script** handles existing hooks gracefully
- [ ] **Installation script** combines with sequential commit hook
- [ ] **Uninstallation** is simple (`rm .git/hooks/pre-commit`)

### Non-Functional Requirements

- [ ] **Performance**: Hook completes in <2 seconds for typical commits
- [ ] **Cross-platform**: Works on Windows/macOS/Linux
- [ ] **Maintainability**: Clear, well-commented code
- [ ] **Extensibility**: Easy to add new pattern detections
- [ ] **Documentation**: Complete installation and usage guide

### Quality Gates

- [ ] **Testing**: Validated against 10+ test cases (valid/invalid/edge cases)
- [ ] **Documentation**: Complete guide in `docs/GH_WAIT_FLAG_ENFORCEMENT.md`
- [ ] **Integration**: Works alongside existing sequential commit hook
- [ ] **UX**: Clear, actionable error messages
- [ ] **Code Review**: Hook code reviewed for security and correctness

---

## Edge Cases & Considerations

### Edge Case 1: Multi-line Commands

```bash
gh run watch \
  12345 \
  --timeout 5m  # ✅ Should be detected as valid
```

**Solution**: Parse multi-line commands using backslash continuation

### Edge Case 2: Commands in Comments

```bash
# Example: gh run watch 12345  ← Should NOT trigger violation
```

**Solution**: Skip lines starting with `#` (except override comments)

### Edge Case 3: Commands in Strings

```javascript
const command = 'gh run watch 12345'; // ❌ Should trigger violation
```

**Solution**: Detect GitHub CLI commands in string literals

### Edge Case 4: Already Combined Hooks

If user has manually combined hooks:

**Solution**: Installation script detects existing combined hooks and adds our check to the chain

### Edge Case 5: Timeout in Variable

```bash
TIMEOUT="5m"
gh run watch $RUN_ID --timeout $TIMEOUT  # ✅ Should be valid
```

**Solution**: Pattern detection looks for `--timeout` flag presence, not literal value validation

---

## Success Metrics

1. **Polling Detection**: Hook catches 100% of manual polling loops in test suite
2. **Timeout Detection**: Hook catches 100% of watch commands without timeout
3. **False Positives**: <5% false positive rate
4. **Performance**: <2 seconds execution time for typical commits
5. **Adoption**: Installed by 100% of contributors
6. **Override Usage**: <10% of commands use override (indicates pattern is not too strict)
7. **Documentation Clarity**: 100% of users can install without help
8. **Default Timeout**: 90%+ of commands use default 5m timeout (not custom values)

---

## Dependencies

- Git (2.0+)
- Bash (4.0+)
- Basic Unix tools (`grep`, `sed`, `awk`)
- Node.js test runner (for testing the hook itself)

---

## Related Issues / PRs

- Sequential Commit Prevention (#119) - This hook should work alongside it
- Testing Infrastructure (TBD) - Will include tests for this hook

---

## Documentation Updates Required

- [ ] Create `docs/GH_WAIT_FLAG_ENFORCEMENT.md`
- [ ] Update `docs/README.md` to link to new guide
- [ ] Add section to `CONTRIBUTING.md` about pre-commit hooks
- [ ] Update repository README with hook installation instructions
- [ ] Add `GH_WATCH_DEFAULT_TIMEOUT` to `.github/REPO_VARIABLES.md`
  - Document default value: `5m`
  - Explain purpose: Default timeout for all `gh watch` commands
  - Show how to override in code with explicit `--timeout` flag

---

🤖 Generated with [Claude Code](https://claude.com/claude-code)

Co-Authored-By: Claude <noreply@anthropic.com>
