---
issue_number: 144
title: 'Phase 1g: Windows/Cross-Platform Compatibility'
state: open
labels: []
created_at: '2025-11-13T15:29:42Z'
updated_at: '2025-11-13T15:29:47Z'
last_synced_commit: 05e0cf5
tokens_estimate: 1102
author: Jackson-Devices
---

## Goal

Ensure full cross-platform compatibility for all scripts, tests, and workflows

## Status

🚨 URGENT - Blocking test execution

## Priority

CRITICAL

## Target

Week of 2025-11-18 (ASAP)

## Current Issues

### 1. CRLF Line Ending Issues 🚨

**Problem**: Windows CRLF (`\r\n`) line endings in shell scripts cause bash parsing errors:

- Variables like `$count` include `\r`, making `10` appear as `1\r0`
- Bash comparison `[[ "$count" -gt 0 ]]` fails with syntax errors
- Test execution completely blocked on Windows systems

**Root Cause**: Git not enforcing LF line endings for shell scripts

**Impact**:

- ✗ All shellcheck-apply.sh tests fail on Windows (30/37 failing)
- ✗ Cannot validate test suite locally on Windows
- ✗ Blocks Phase 1a completion and PR #138 merge

### 2. Path Handling Issues

**Problem**: Forward slash vs backslash path separators

- Test runner used literal `/` in path.replace() patterns
- Failed to find test files on Windows

**Status**: ✅ FIXED in tests/run-shellcheck-tests.js (regex-based replace)

### 3. Shell Script Execution

**Problem**: Cannot execute `.sh` files directly on Windows via `execFile()`

- Node.js execFile doesn't recognize `.sh` files on Windows
- Requires explicit bash invocation

**Status**: ✅ FIXED in tests/helpers/shell-runner.js (platform detection)

## Implementation Tasks

### Task 1: Line Ending Enforcement 🚨

- Add `.gitattributes` configuration for shell scripts
- Create line ending validation workflow
- Ensure CRLF detection runs EARLY in gate sequence
- Auto-fix option: Convert CRLF → LF and commit
- Block merge if CRLF detected and auto-fix disabled

### Task 2: Cross-Platform Testing

- Test on Ubuntu, Windows, macOS
- Add OS matrix to CI workflows
- Test with Git Bash and WSL2 on Windows
- Verify all tests pass on all platforms

### Task 3: Windows Quirks Research & Documentation

- Research line endings, path separators, shell availability
- Research file permissions, case sensitivity, symlinks
- Document all compatibility considerations
- Create `docs/WINDOWS_COMPATIBILITY.md`

### Task 4: Normalize Existing Files

- Run dos2unix on all `.sh` files
- Verify .gitattributes is applied
- Re-commit all shell scripts with LF endings
- Test on Windows to verify fix

### Task 5: AST-Based Shell Script Fixing 🔬

- Research AST-based approaches for shell script fixing
- Evaluate shellcheck --format=diff capabilities
- Research bash AST parser libraries
- Compare AST vs LSP approaches
- Improve fix accuracy from ~57% to >95%

### Task 6: Test Debug Modes 🐛

- Add debug mode to all test suites
- Environment variable: `DEBUG=1` or command flag: `--debug`
- Capture: script stdout/stderr, temp files, shellcheck output
- Non-invasive: No performance impact when disabled

## Success Criteria

- [ ] `.gitattributes` configured for shell scripts
- [ ] Line ending validation workflow created and passing
- [ ] All existing shell scripts normalized to LF
- [ ] Test suite passes on Windows (37/37 tests)
- [ ] Test suite passes on Ubuntu
- [ ] Test suite passes on macOS
- [ ] Windows compatibility documented
- [ ] Edge cases identified and handled
- [ ] Validator catches future CRLF issues
- [ ] AST-based fixing researched and documented
- [ ] Test debug modes implemented

## Dependencies

**Blocks**:

- Phase 1a completion (test validation)
- PR #138 merge (test-suite branch)
- Phase 1b (extended components)
- All future shell script development

**Requires**:

- Git with .gitattributes support
- Bash available on all platforms
- dos2unix or equivalent tool
- CI runners for Windows/Mac/Linux

## Implementation Approach

**MUST FOLLOW TDD**:

1. ✅ Write test suite first (already done in PR #138)
2. ✅ Identify cross-platform issues (CRLF, paths, shell execution)
3. ⏳ Research all Windows quirks and document
4. ⏳ Design comprehensive fix with validation
5. ⏳ Implement .gitattributes + line ending fixer
6. ⏳ Implement line ending validator workflow
7. ⏳ Normalize all existing files
8. ⏳ Validate test suite passes on all platforms
9. ⏳ Document all fixes and edge cases

## Related Issues

Child issues will be created for each task:

- Line ending enforcement
- Cross-platform testing matrix
- Windows quirks research & documentation
- Normalize existing files
- AST-based shell script fixing
- Test debug modes

---

📋 **Part of**: Orchestration System Development Roadmap
🔗 **Source**: ORCHESTRATION_ROADMAP.md
