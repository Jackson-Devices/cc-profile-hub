---
issue_number: 123
title: 'FUNCTION: Pre-Commit Hook - Validate Issue Link with Random Override'
state: open
labels:
  - 'Difficulty: Medium'
  - 'AI: Supervised'
  - 'Workflow: Backlog'
  - 'Type: Feature'
  - 'Type: Function'
created_at: '2025-11-12T04:01:40Z'
updated_at: '2025-11-12T04:01:49Z'
last_synced_commit: 66d0597
tokens_estimate: 3107
author: Jackson-Devices
---

# FUNCTION: Pre-Commit Hook - Validate Issue Link and Documentation

## Overview

Create a pre-commit hook that validates commits are linked to GitHub issues and prompts for documentation status. Uses a random override code system to prevent easy bypassing - AI agents cannot auto-bypass, only humans can.

**Problem**: Commits often lack issue tracking links and documentation isn't always considered, making it hard to trace changes back to requirements and maintain documentation coverage.

**Solution**: Pre-commit hook that:

1. Checks if commit message references an issue (`#123`, `Fixes #123`, `Closes #123`)
2. If no issue link, prompts user with question: "Is this connected to an issue? Should it be documented?"
3. Requires **random single character override code** to proceed without issue link
4. No command-line flags can bypass (only manual code entry)
5. Character changes every time (prevents scripting/automation)

---

## Problem Statement / Motivation

**Current issues:**

- Commits lack traceability to issues
- Documentation gaps when features are added without docs consideration
- Easy to forget to link commits to work items
- AI agents might auto-bypass simple prompts

**The Goal:**

- Force conscious decision about issue linking
- Prompt consideration of documentation needs
- Make bypassing difficult enough that it's intentional (not accidental)
- Prevent AI/automation from auto-bypassing (no flag-based overrides)
- Only humans can override (by typing random code)

---

## Proposed Solution

### Pre-Commit Hook Implementation

**File**: `scripts/pre-commit-issue-link-check.sh`

**Triggers**: Before each local commit

**Behavior**:

1. Parse commit message for issue references
2. If found: Allow commit (happy path)
3. If NOT found: Interactive prompt with random override code
4. User must type exact code to bypass (no flags accepted)
5. Log all bypasses for review

### Issue Reference Detection

**Patterns to detect:**

- `#123` - Simple issue reference
- `Fixes #123` - Closing keywords
- `Closes #123`, `Resolves #123`
- `Related to #123`
- `See #123`

**GitHub's closing keywords**: Fixes, Closes, Resolves (and lowercase variants)

### Override Code System

**Requirements:**

- **1 random character** (alphanumeric, case-sensitive)
- **Changes every execution** (not predictable)
- **No command-line flags** to bypass (prevents automation)
- **Must be typed manually** (prevents copy-paste from scripts)

**Example**:

```
❌ COMMIT BLOCKED: No issue reference found
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

No GitHub issue reference detected in commit message.

📋 QUESTIONS:
   1. Is this commit connected to a GitHub issue?
   2. Should this change be documented?

🔧 OPTIONS:
   A) Add issue reference to commit message:
      git commit --amend -m "feat: your message (#123)"

   B) Proceed without issue link:
      Type this character to continue: K

      ⚠️  Override code: [user input here]

💡 WHY ISSUE LINKS MATTER:
   • Traceability to requirements
   • Better PR context
   • Easier debugging/rollback
   • Documentation planning

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
```

---

## Technical Approach

### Hook Architecture

```bash
#!/bin/bash
# Pre-commit hook to validate issue links and documentation consideration

set -e

# Get commit message from file
COMMIT_MSG_FILE="$1"
COMMIT_MSG=$(cat "$COMMIT_MSG_FILE")

# Patterns for issue references
ISSUE_PATTERNS=(
  '#[0-9]+'                           # Simple: #123
  '(Fixes?|Closes?|Resolves?) #[0-9]+' # Closing: Fixes #123
  'Related to #[0-9]+'                # Related: Related to #123
  'See #[0-9]+'                       # Reference: See #123
)

# Check if commit message contains any issue reference
HAS_ISSUE_REF=false
for pattern in "${ISSUE_PATTERNS[@]}"; do
  if echo "$COMMIT_MSG" | grep -qE "$pattern"; then
    HAS_ISSUE_REF=true
    break
  fi
done

# If has issue reference, allow commit
if [ "$HAS_ISSUE_REF" = true ]; then
  exit 0
fi

# No issue reference found - prompt user
echo ""
echo "❌ COMMIT BLOCKED: No issue reference found"
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
echo ""
echo "No GitHub issue reference detected in commit message."
echo ""
echo "📋 QUESTIONS:"
echo "   1. Is this commit connected to a GitHub issue?"
echo "   2. Should this change be documented?"
echo ""
echo "🔧 OPTIONS:"
echo "   A) Add issue reference to commit message:"
echo "      git commit --amend -m \"feat: your message (#123)\""
echo ""
echo "   B) Proceed without issue link:"

# Generate random single character (alphanumeric, case-sensitive)
# Use /dev/urandom for true randomness
OVERRIDE_CODE=$(LC_ALL=C tr -dc 'A-Za-z0-9' </dev/urandom | head -c 1)

echo "      Type this character to continue: $OVERRIDE_CODE"
echo ""
echo -n "      ⚠️  Override code: "

# Read user input (no echo for security)
read -r USER_INPUT

# Validate override code (must match exactly)
if [ "$USER_INPUT" = "$OVERRIDE_CODE" ]; then
  echo ""
  echo "✅ Override accepted. Commit proceeding without issue link."

  # Log override for review
  {
    echo "$(date -Iseconds) | No issue link | Override: $OVERRIDE_CODE | Message: ${COMMIT_MSG:0:50}..."
  } >> .git/hooks/override-log.txt

  exit 0
else
  echo ""
  echo "❌ Incorrect override code. Commit blocked."
  echo ""
  echo "💡 TIP: Copy-paste the exact code shown above"
  echo ""
  exit 1
fi
```

### Security Features

**1. No Flag-Based Bypass**

```bash
# ❌ NOT ALLOWED - no --skip or --force flags
git commit -m "message" --skip-issue-check

# ✅ ONLY WAY - type random code interactively
```

**2. Random Code Generation**

- Uses `/dev/urandom` for true randomness
- 1 character: 62 possibilities (A-Z, a-z, 0-9)
- Changes every execution
- Case-sensitive

**3. Override Logging**

- All bypasses logged to `.git/hooks/override-log.txt`
- Includes timestamp, code, commit message snippet
- Reviewable by team

**4. No Automation Possible**

- Requires interactive input (no stdin redirection accepted)
- Random code prevents scripting
- AI agents cannot predict code

---

## Implementation Plan

### Phase 1: Core Hook (Week 1)

1. **Create hook script** (`pre-commit-issue-link-check.sh`)
   - Implement issue reference detection
   - Add interactive prompt with random code
   - Test with various commit message formats

2. **Create installation script** (`install-issue-link-hook.sh`)
   - Handle existing hooks (combine with sequential commit hook)
   - Create combined hook runner
   - Add clear installation instructions

3. **Write documentation** (`docs/ISSUE_LINK_VALIDATION.md`)
   - Explain issue reference patterns
   - Document override code system
   - Include troubleshooting guide

### Phase 2: Enhanced Features (Week 2)

4. **Add documentation prompt**:
   - After override code, ask: "Should this be documented? (y/n)"
   - Log documentation decisions
   - Provide helpful guidance

5. **Improve override logging**:
   - Add more context to logs
   - Include branch name, author
   - Make logs easily reviewable

6. **Cross-platform testing**:
   - Test on Windows (Git Bash)
   - Test on macOS
   - Test on Linux

### Phase 3: Integration & Refinement (Week 3)

7. **Combine with existing hooks**:
   - Sequential commit prevention
   - Workflow wait flag enforcement
   - Create unified hook runner

8. **Add team review workflow**:
   - Create script to review override logs
   - Flag suspicious patterns (frequent overrides)
   - Generate reports

9. **Documentation**:
   - Quick start guide
   - Integration with CONTRIBUTING.md
   - Best practices for issue linking

---

## Acceptance Criteria

### Functional Requirements

- [ ] **Hook detects** issue references: `#123`, `Fixes #123`, etc.
- [ ] **Hook allows** commits with issue references immediately
- [ ] **Hook blocks** commits without issue references
- [ ] **Hook generates** random 8-character override code each time
- [ ] **Hook validates** user input matches override code exactly
- [ ] **Hook has NO** command-line flag bypasses (`--skip-*`, `--force-*`)
- [ ] **Hook logs** all override attempts to `.git/hooks/override-log.txt`
- [ ] **Hook is interactive** (requires manual code entry)
- [ ] **Installation script** handles existing hooks gracefully
- [ ] **Installation script** combines with other pre-commit hooks
- [ ] **Uninstallation** is simple

### Non-Functional Requirements

- [ ] **Security**: No automation can bypass (only human input)
- [ ] **Usability**: Clear error messages and instructions
- [ ] **Cross-platform**: Works on Windows/macOS/Linux
- [ ] **Performance**: Hook completes in <2 seconds
- [ ] **Maintainability**: Clean, well-commented code

### Quality Gates

- [ ] **Testing**: Validated with 20+ test cases
- [ ] **Documentation**: Complete guide with examples
- [ ] **Integration**: Works alongside sequential commit hook
- [ ] **UX**: Helpful, non-frustrating override process
- [ ] **Security Review**: Bypass mechanisms verified as secure

---

## Edge Cases & Considerations

### Edge Case 1: WIP Commits

**Scenario**: Developer making WIP (work in progress) commits

**Solution**:

- WIP commits should still reference issue
- Alternative: Use commit message prefix: `WIP #123: implementing feature`
- Override code still required if truly no issue

### Edge Case 2: Merge Commits

**Scenario**: Automated merge commits from git

**Solution**: Skip check for merge commits

```bash
# Detect merge commit
if git rev-parse -q --verify MERGE_HEAD >/dev/null; then
  exit 0  # Allow merge commits without check
fi
```

### Edge Case 3: Revert Commits

**Scenario**: `git revert` creates automatic commit messages

**Solution**: Allow commits that start with "Revert"

```bash
if echo "$COMMIT_MSG" | grep -q "^Revert"; then
  exit 0
fi
```

### Edge Case 4: Hotfix Commits

**Scenario**: Emergency hotfixes that can't wait for issue creation

**Solution**: Override code system handles this - but it's intentionally difficult to ensure hotfixes are still tracked

### Edge Case 5: Documentation-Only Commits

**Scenario**: Commits that only update documentation

**Solution**: These should STILL link to issues (documentation issues)

- Documentation changes are features/fixes too
- Should be tracked and reviewable

---

## Success Metrics

1. **Adoption Rate**: >90% of commits have issue references
2. **Override Rate**: <10% of commits use override code
3. **False Positives**: <5% of blocked commits were legitimate
4. **Time Impact**: <30 seconds average delay for override path
5. **Documentation Awareness**: Measurable increase in doc commits

---

## Dependencies

- Git (2.0+)
- Bash (4.0+)
- `/dev/urandom` (for random code generation)
- `grep` with regex support

---

## Related Issues / PRs

- Sequential Commit Prevention (#119) - This hook should work alongside it
- Workflow Wait Flag Enforcement (#120) - Part of unified pre-commit system

---

## Documentation Updates Required

- [ ] Create `docs/ISSUE_LINK_VALIDATION.md`
- [ ] Update `docs/README.md` to link to new guide
- [ ] Add section to `CONTRIBUTING.md` about issue linking requirements
- [ ] Update pre-commit hooks documentation
- [ ] Create team review workflow for override logs

---

## Security Considerations

**Why No Flags?**

- Flags can be automated by scripts/AI
- Users might create aliases: `alias gc='git commit --skip-issue-check'`
- Random code REQUIRES human attention

**Why Single Character?**

- 62 possibilities (A-Z, a-z, 0-9)
- Just enough randomness to prevent accidents
- Quick to type (not a password)
- Forces conscious decision without being burdensome

**Why Case-Sensitive?**

- Increases options from 36 to 62
- Requires attention to detail

**Logging Privacy**

- Logs stored locally only (`.git/hooks/override-log.txt`)
- Not committed to repository
- Added to `.gitignore`
- Team can review periodically

---

🤖 Generated with [Claude Code](https://claude.com/claude-code)

Co-Authored-By: Claude <noreply@anthropic.com>
