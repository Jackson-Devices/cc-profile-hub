---
issue_number: 205
title: "BUG: YAML Formatter Auto-Triggers Despite 'Manual Only' Configuration"
state: closed
labels: []
created_at: '2025-11-14T01:07:13Z'
updated_at: '2025-11-14T02:27:46Z'
last_synced_commit: d361656
tokens_estimate: 946
author: Jackson-Devices
closed_at: '2025-11-14T02:27:46Z'
---

## Problem

The YAML formatter workflow auto-triggers on push events despite being configured as "manual trigger only". The workflow was intended to be disabled until comprehensive testing is complete (Issue #195), but it continues to run automatically.

## Root Cause

**Location:** `.github/workflows/workflow-yaml-format-apply.yml:7-20`

**Current broken configuration:**

```yaml
name: Workflow YAML Format Apply (Reusable)

# DISABLED: Manual trigger only until comprehensive test suite implemented
# See Issue #195 for test coverage requirements (currently 12.7%, need 80% minimum)
# DO NOT enable auto-trigger until Phase 2 tests complete

on:
  workflow_dispatch: # Manual trigger only
    # workflow_call: # DISABLED - uncomment after Issue #195 Phase 2 complete
    inputs: # <-- ORPHANED - Still parsed by YAML!
      auto_commit:
        description: 'Automatically commit fixes'
        required: false
        type: boolean
        default: false
      # ... more inputs
```

**Issue:** The `inputs:` section (lines 10-30) is orphaned - it's not under `workflow_dispatch` and the `workflow_call:` above it is commented out. YAML parser treats this as invalid configuration, which can cause undefined trigger behavior.

**Evidence:** Workflow runs on push events:

- Run 19350307045: Triggered by "chore: remove temp test gap analysis file" push
- Run 19349534781: Triggered by "fix: add checks:read permission..." push
- Run 19349451914: Triggered by "feat: add YAML formatter workflow..." push

## Impact

- Workflow runs when it shouldn't (disabled for testing)
- Tests are failing (2/6 tests, see Issue #195)
- Broken workflow execution with every push
- Wastes CI minutes
- "Disable" comment misleading - workflow NOT actually disabled

## Required Fixes

### Option 1: Properly Disable (Recommended Until Issue #195 Complete)

```yaml
on:
  workflow_dispatch:
    inputs:
      auto_commit:
        description: 'Automatically commit fixes'
        required: false
        type: boolean
        default: false
      # ... rest of inputs moved under workflow_dispatch
# After Issue #195 Phase 2 complete, add:
#  workflow_call:
#    inputs:
#      auto_commit:
#        required: false
#        type: boolean
#        default: false
#      # ... etc
```

### Option 2: Delete Workflow File Until Ready

```bash
git rm .github/workflows/workflow-yaml-format-apply.yml
git commit -m "chore: remove YAML formatter until Issue #195 tests complete"
```

### Option 3: Add Safeguard Check

```yaml
jobs:
  apply:
    runs-on: ubuntu-latest
    steps:
      - name: Verify manual trigger
        run: |
          if [ "${{ github.event_name }}" != "workflow_dispatch" ]; then
            echo "::error::This workflow is disabled for auto-trigger"
            echo "::error::See Issue #195 - tests must reach 80% coverage first"
            exit 1
          fi
```

## Testing Requirements

1. **Test workflow_dispatch only** - Verify workflow ONLY runs on manual trigger
2. **Test push events ignored** - Push to main should NOT trigger workflow
3. **Test workflow_call disabled** - Other workflows cannot call this workflow
4. **Error messages** - If auto-triggered, error must reference Issue #195

## Acceptance Criteria

- [ ] Workflow ONLY triggers on manual workflow_dispatch
- [ ] No auto-trigger on push/pull_request/workflow_call
- [ ] Clear error if accidentally triggered incorrectly
- [ ] Test suite validates trigger behavior
- [ ] After Issue #195 Phase 2: Re-enable workflow_call with proper inputs

## Related Issues

- #195: YAML Formatter Comprehensive Test Suite (must complete before re-enabling)
- Tests currently failing (2/6) due to Windows path bug

## Labels

type/bug, priority/urgent, component/yaml-formatter, area/ci-cd, blocked-by/195
