---
issue_number: 198
title: 'Missing GitHub Issue Templates: Bug, Improvement, Refactor, Docs, Tooling'
state: open
labels: []
created_at: '2025-11-14T00:04:56Z'
updated_at: '2025-11-14T00:05:01Z'
last_synced_commit: 7ab6fed
tokens_estimate: 811
author: Jackson-Devices
---

## Problem

Only 6 issue templates exist, but the label taxonomy defines 10+ issue types. Missing templates force users to either use generic templates or create issues without proper structure/validation.

**Current templates (6):**

- feature.yml
- function.yml
- sub-feature.yml
- test.yml
- test-suite.yml
- config.yml

**Missing templates (5+):**

- bug.yml (Type: Bug)
- improvement.yml (Type: Improvement)
- refactor.yml (Type: Refactor)
- docs.yml (Type: Docs)
- tooling.yml (Type: Tooling)

**Potentially missing:**

- internal-dependency.yml (Type: Internal-Dependency)
- external-dependency.yml (Type: External-Dependency)
- adr.yml (Artifact: ADR)
- rfc.yml (Artifact: RFC)
- spike.yml (Artifact: Spike)

## Impact

**Without proper templates:**

- Inconsistent issue structure
- Missing required fields
- Incorrect label application
- Manual validation overhead
- Poor searchability/filtering
- AI confusion about issue type

## Required Templates

### 1. bug.yml

**Type:** Bug
**Required fields:**

- Bug description
- Steps to reproduce
- Expected behavior
- Actual behavior
- Environment (OS, Node version, etc.)
- Error messages/logs
- Related issues/PRs
- Severity (Critical/High/Medium/Low)

### 2. improvement.yml

**Type:** Improvement
**Required fields:**

- Current behavior
- Improved behavior
- Rationale (why improve?)
- Impact assessment
- Breaking changes (Y/N)
- Related issues

### 3. refactor.yml

**Type:** Refactor
**Required fields:**

- Code to refactor (files/functions)
- Current problems
- Refactoring goals
- Expected benefits
- Risk assessment
- Test coverage requirements

### 4. docs.yml

**Type:** Docs
**Required fields:**

- Documentation type (README, ADR, guide, API docs, etc.)
- Missing/outdated content
- Target audience
- Related code/features
- Documentation standards to follow

### 5. tooling.yml

**Type:** Tooling
**Required fields:**

- Tool category (CI, testing, linting, formatting, etc.)
- Problem tool solves
- Alternatives considered
- Integration requirements
- Maintenance overhead

### 6. internal-dependency.yml (Optional)

**Type:** Internal-Dependency
**Required fields:**

- Blocking issues (list)
- Dependency type (sequential, parallel, partial)
- Unblocking criteria
- Estimated wait time

### 7. external-dependency.yml (Optional)

**Type:** External-Dependency
**Required fields:**

- External project/org
- Dependency description
- Tracking URL
- Estimated resolution
- Workaround options

## Template Requirements

Each template must:

- Use YAML format consistent with existing templates
- Include proper label auto-assignment
- Include required fields as mandatory
- Include validation where possible
- Follow atomic hierarchy principles
- Include AI-friendly descriptions
- Link to relevant documentation

## Success Criteria

- [ ] All 5 core templates created (Bug, Improvement, Refactor, Docs, Tooling)
- [ ] Optional dependency templates evaluated
- [ ] All templates validated with yamllint
- [ ] All templates tested with actual issue creation
- [ ] Label auto-assignment works correctly
- [ ] Required fields enforced
- [ ] Documentation updated

## Priority

**HIGH** - Missing bug template is especially critical for issue reporting

---

🤖 Generated with Claude Code
