---
issue_number: 202
title: 'URGENT: Fix Orchestrator Dependency Conflict & Error Messages'
state: closed
labels: []
created_at: '2025-11-14T01:03:03Z'
updated_at: '2025-11-14T02:37:36Z'
last_synced_commit: afe7361
tokens_estimate: 949
author: Jackson-Devices
closed_at: '2025-11-14T02:37:36Z'
---

## Problem

The orchestrator workflow is failing due to an npm dependency conflict and provides meaningless error messages that don't help diagnose the actual issue.

## Root Causes

### 1. Dependency Conflict (.github/workflows/orchestrator.yml:207)

```yaml
- name: Install dependencies
  run: npm install yaml @octokit/core @octokit/plugin-retry
```

**Issue:**

- Installs `@octokit/plugin-retry@8.0.3` which requires `@octokit/core >= 7`
- `package.json` has `@octokit/core@6.1.6`
- npm peer dependency conflict kills the job
- **`@octokit/plugin-retry` is never actually used in the workflow code**

**Error:**

```
npm error peer @octokit/core@">=7" from @octokit/plugin-retry@8.0.3
npm error Found: @octokit/core@6.1.6
```

### 2. Meaningless Error Message (.github/workflows/orchestrator.yml:399)

```javascript
if (executeResult !== 'success' && executeResult !== 'skipped') {
  core.setFailed('Orchestration did not complete successfully');
}
```

**Issue:** Generic "computer says no" error message doesn't indicate what actually failed or why.

### 3. Missing Error Handling

Execute stage has no:

- try/catch blocks
- Retry logic
- Error detail capture from npm/workflow failures
- Stack trace logging

## Required Fixes

### Fix 1: Remove Unused Dependency

```yaml
- name: Install dependencies
  run: npm install yaml @octokit/core
  # Removed @octokit/plugin-retry - not used in workflow code
```

**Alternative if retry plugin needed:** Use `--legacy-peer-deps` or upgrade `@octokit/core` to v7 in package.json

### Fix 2: Meaningful Error Messages

```javascript
if (executeResult !== 'success' && executeResult !== 'skipped') {
  // Capture actual error details
  const executeRun = await github.rest.actions.getWorkflowRun({
    owner: context.repo.owner,
    repo: context.repo.repo,
    run_id: executeRunId,
  });

  const failedJobs = await github.rest.actions.listJobsForWorkflowRun({
    owner: context.repo.owner,
    repo: context.repo.repo,
    run_id: executeRunId,
    filter: 'latest',
  });

  const errorDetails = failedJobs.data.jobs
    .filter((job) => job.conclusion === 'failure')
    .map(
      (job) =>
        `${job.name}: ${job.steps.find((s) => s.conclusion === 'failure')?.name || 'unknown step'}`
    )
    .join(', ');

  core.setFailed(`Orchestration failed during Execute stage: ${errorDetails || 'Unknown error'}`);
}
```

### Fix 3: Add Error Handling & Retry

```javascript
try {
  const executeRun = await github.rest.actions.createWorkflowDispatch({
    owner: context.repo.owner,
    repo: context.repo.repo,
    workflow_id: 'orchestrator-execute.yml',
    ref: context.ref,
    inputs: { ... }
  });
} catch (error) {
  core.error(`Failed to trigger Execute workflow: ${error.message}`);
  core.error(`Stack: ${error.stack}`);
  throw error;
}
```

## Testing Requirements

1. **Test dependency installation** - Verify no peer dependency conflicts
2. **Test error message quality** - Failure messages must include:
   - What failed (which stage/job/step)
   - Why it failed (actual error message)
   - How to debug (logs location, relevant context)
3. **Test error scenarios** - Trigger failures intentionally to verify error handling:
   - Invalid workflow syntax
   - Missing permissions
   - Network failures
   - Dependency conflicts

## Acceptance Criteria

- [ ] Orchestrator installs dependencies without conflicts
- [ ] All error messages are actionable and specific
- [ ] Error handling includes try/catch with stack traces
- [ ] Test suite validates error message quality
- [ ] No "computer says no" type generic errors

## Related Issues

- Part of comprehensive error message audit needed across all 27 workflows
- See upcoming issue for system-wide error handling standards

## Labels

type/bug, priority/urgent, component/orchestrator, area/dx
