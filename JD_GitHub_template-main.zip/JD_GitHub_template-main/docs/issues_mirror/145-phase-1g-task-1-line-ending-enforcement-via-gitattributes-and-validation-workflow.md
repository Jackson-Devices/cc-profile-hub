---
issue_number: 145
title: 'Phase 1g Task 1: Line ending enforcement via .gitattributes and validation workflow'
state: open
labels: []
created_at: '2025-11-13T15:30:43Z'
updated_at: '2025-11-13T15:30:49Z'
last_synced_commit: e0d9780
tokens_estimate: 678
author: Jackson-Devices
---

## Part of #144

## Objective

Enforce LF line endings for all shell scripts and workflow files to prevent Windows CRLF issues

## Problem Statement

Windows CRLF (`\r\n`) line endings cause bash parsing errors:

- Variables include `\r` characters, breaking comparisons
- 30/37 tests failing on Windows due to CRLF
- Blocks test execution and Phase 1a completion

## Implementation

### Step 1: Add .gitattributes Configuration

**File**: `.gitattributes` (root directory)

```gitattributes
# Shell scripts MUST use LF line endings
*.sh text eol=lf
*.bash text eol=lf

# Workflow files MUST use LF line endings
.github/workflows/*.yml text eol=lf
.github/scripts/*.sh text eol=lf
```

### Step 2: Create Line Ending Validation Workflow

**File**: `.github/workflows/line-ending-check.yml`

**Features**:

- Trigger: On all PRs and pushes
- Run EARLY: Before any shell script execution
- Check: Scan all `.sh` files for CRLF
- Auto-fix mode: Convert CRLF → LF and commit (optional)
- Block merge: If CRLF detected and auto-fix disabled

**Workflow Example**:

```yaml
name: Line Ending Check

on:
  pull_request:
  push:
    branches: [main]

jobs:
  check-line-endings:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v4

      - name: Check for CRLF in shell scripts
        run: |
          if git grep -I --files-with-matches $'\r' -- '*.sh' '*.bash' '.github/scripts/*.sh'; then
            echo "ERROR: CRLF line endings detected in shell scripts"
            echo "Run: dos2unix <file> or configure .gitattributes"
            exit 1
          fi

      - name: Verify .gitattributes is effective
        run: |
          git check-attr text eol -- *.sh .github/scripts/*.sh
```

### Step 3: Add Auto-Fix Option (Future Enhancement)

- Detect CRLF in pre-commit hook
- Auto-convert to LF
- Commit with descriptive message
- Requires workflow permissions configuration

## Success Criteria

- [ ] `.gitattributes` file created with shell script rules
- [ ] Line ending validation workflow created
- [ ] Workflow runs on all PRs
- [ ] Workflow catches CRLF issues before merge
- [ ] Workflow runs EARLY in gate sequence
- [ ] Clear error messages when CRLF detected
- [ ] Documentation for fixing CRLF locally

## Testing

- Create test PR with CRLF in shell script
- Verify workflow detects and blocks merge
- Verify error message is clear and actionable
- Verify workflow passes with LF-only scripts

## Dependencies

- Git with .gitattributes support
- GitHub Actions enabled

## Related

- Blocks: #144 (Phase 1g)
- Enables: Task 4 (normalize existing files)

---

📋 **Part of**: Phase 1g - Windows/Cross-Platform Compatibility (#144)
🔗 **Source**: ORCHESTRATION_ROADMAP.md
