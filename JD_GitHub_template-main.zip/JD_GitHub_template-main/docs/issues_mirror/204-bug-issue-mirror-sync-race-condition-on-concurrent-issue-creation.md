---
issue_number: 204
title: 'BUG: Issue Mirror Sync Race Condition on Concurrent Issue Creation'
state: open
labels: []
created_at: '2025-11-14T01:06:03Z'
updated_at: '2025-11-14T01:06:09Z'
last_synced_commit: dd32786
tokens_estimate: 1191
author: Jackson-Devices
---

## Problem

The Issue Mirror Sync workflow fails with git push rejections when multiple issues are created simultaneously, causing race conditions where parallel sync workflows try to push to main at the same time.

## Root Cause

**Location:** `.github/workflows/issue-mirror-sync.yml` commit step

**Evidence from logs (run 19350046060):**

```
git push
To https://github.com/Jackson-Devices/JD_GitHub_template
 ! [rejected]        main -> main (fetch first)
error: failed to push some refs
hint: Updates were rejected because the remote contains work that you do not
hint: have locally. This is usually caused by another repository pushing to
hint: the same ref.
```

**Scenario:**

1. User creates issues #195, #196, #197, #198, #199, #200, #201 in quick succession
2. Each triggers `issue-mirror-sync.yml` simultaneously
3. All 7 workflows checkout main at the same time (same commit)
4. All 7 create their mirror files
5. First push succeeds
6. Remaining 6 fail with "fetch first" error

## Impact

- Mirror sync fails for most issues during batch creation
- Inconsistent mirror state - some issues synced, others not
- No automatic retry or recovery
- Manual re-sync required

## Current Code

```yaml
- name: Commit mirror file
  run: |
    git config user.name "github-actions[bot]"
    git config user.email "github-actions[bot]@users.noreply.github.com"
    git add docs/issues_mirror/
    if git diff --staged --quiet; then
      echo "No changes to commit"
    else
      git commit -m "docs: sync issue #${ISSUE_NUMBER} mirror"
      git push  # <-- NO RETRY LOGIC
    fi
```

## Required Fixes

### 1. Add Pull-Retry Logic Before Push

```yaml
- name: Commit mirror file
  run: |
    git config user.name "github-actions[bot]"
    git config user.email "github-actions[bot]@users.noreply.github.com"
    git add docs/issues_mirror/

    if git diff --staged --quiet; then
      echo "No changes to commit"
      exit 0
    fi

    git commit -m "docs: sync issue #${ISSUE_NUMBER} mirror" \
      -m "Auto-synced by issue-mirror-sync workflow" \
      -m "Issue: #${ISSUE_NUMBER}" \
      -m "Title: ${ISSUE_TITLE}" \
      -m "State: ${ISSUE_STATE}"

    # Retry push up to 5 times with exponential backoff
    MAX_RETRIES=5
    RETRY_COUNT=0

    while [ $RETRY_COUNT -lt $MAX_RETRIES ]; do
      if git push; then
        echo "✅ Push succeeded on attempt $((RETRY_COUNT + 1))"
        exit 0
      else
        RETRY_COUNT=$((RETRY_COUNT + 1))
        
        if [ $RETRY_COUNT -lt $MAX_RETRIES ]; then
          WAIT_TIME=$((2 ** RETRY_COUNT))
          echo "⚠️ Push failed, retrying in ${WAIT_TIME}s (attempt $RETRY_COUNT/$MAX_RETRIES)"
          sleep $WAIT_TIME
          
          # Pull and rebase
          echo "Pulling latest changes..."
          git pull --rebase origin main
        else
          echo "::error::Failed to push after $MAX_RETRIES attempts"
          exit 1
        fi
      fi
    done
```

### 2. Use GitHub Concurrency Control

```yaml
concurrency:
  group: issue-mirror-sync-${{ github.event.issue.number }}
  cancel-in-progress: false # Don't cancel, let it queue
```

**Note:** This prevents parallel syncs for the SAME issue, but doesn't solve the race for DIFFERENT issues pushing to main simultaneously. The pull-retry logic is still required.

### 3. Add Meaningful Error Messages

```yaml
echo "::error::Failed to push issue #${ISSUE_NUMBER} mirror after $MAX_RETRIES attempts"
echo "::error::This usually indicates ongoing concurrent pushes to main"
echo "::error::The workflow will need to be manually re-run"
echo "::notice::Last pull attempt before failure:"
git log -1 --oneline
```

## Testing Requirements

1. **Test concurrent issue creation** - Create 5+ issues simultaneously, verify all mirrors sync
2. **Test retry logic** - Simulate push rejection, verify retry with backoff
3. **Test pull-rebase** - Verify conflicts resolved correctly during rebase
4. **Test single issue** - Verify normal case still works without delays
5. **Error message quality** - Failed pushes must show attempt count and suggest re-run

## Acceptance Criteria

- [ ] Pull-retry logic with exponential backoff implemented
- [ ] Concurrency control per issue number
- [ ] Meaningful error messages on final failure
- [ ] Test suite validates concurrent sync scenarios
- [ ] No manual intervention required for race conditions

## Alternative Solution: Single Batch Sync

Instead of syncing each issue immediately, queue them and batch sync every N minutes:

```yaml
on:
  schedule:
    - cron: '*/5 * * * *' # Every 5 minutes
```

This eliminates race conditions entirely but delays sync. Discuss with user.

## Labels

type/bug, priority/high, component/issue-mirror, area/dx, area/race-condition
