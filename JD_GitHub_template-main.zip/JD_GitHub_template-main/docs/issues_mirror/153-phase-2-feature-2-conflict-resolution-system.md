---
issue_number: 153
title: 'Phase 2 Feature 2: Conflict resolution system'
state: open
labels: []
created_at: '2025-11-13T15:35:56Z'
updated_at: '2025-11-13T15:36:01Z'
last_synced_commit: '9188239'
tokens_estimate: 1777
author: Jackson-Devices
---

## Part of #151

## Objective

Build a system to detect and resolve conflicting shellcheck fixes

## Problem Statement

### Conflicting Fixes Can Occur

**Example 1: Word Splitting Intention**

```bash
# Original (intentional word splitting)
words="foo bar baz"
echo $words  # SC2086: Quote to prevent word splitting

# But quoting breaks the intention:
echo "$words"  # Outputs: foo bar baz (single line)
# vs
echo $words    # Outputs: foo bar baz (separate words)
```

**Example 2: Conflicting SC Codes**

```bash
# SC2046: Quote command substitution
# SC2086: Quote variable expansion
files=$(ls *.txt)
for file in $files; do  # Both SC2046 and SC2086
  echo "$file"
done

# Fix 1: Quote $files (SC2086)
for file in "$files"; do  # Now iterates once over entire string

# Fix 2: Quote ls substitution (SC2046)
files="$(ls *.txt)"
for file in $files; do  # Still has SC2086

# Correct fix: Use glob instead
for file in *.txt; do
  echo "$file"
done
```

**Example 3: Strategy Conflicts**

```bash
# Conservative might preserve word splitting
echo $var

# Aggressive might quote everything
echo "$var"

# But user wants word splitting here!
```

## Implementation

### 1. Conflict Detection

#### Detect Conflicting Intentions

```javascript
const conflicts = [
  {
    name: 'intentional_word_splitting',
    detect: (code, context) => {
      // SC2086 on variable used in contexts suggesting word splitting
      return code === 'SC2086' && (context.usedInLoop || context.usedInEcho);
    },
    message: 'This variable may be intentionally unquoted for word splitting',
  },

  {
    name: 'quote_removal_vs_addition',
    detect: (code, context) => {
      // Conflicting quote suggestions
      return (
        context.fixes.some((f) => f.adds_quotes) && context.fixes.some((f) => f.removes_quotes)
      );
    },
    message: 'Conflicting suggestions about quoting',
  },
];
```

#### Detect Multiple Fix Strategies

```javascript
function detectStrategyConflicts(file, strategies) {
  const conservativeFixes = applyStrategy(file, 'conservative');
  const balancedFixes = applyStrategy(file, 'balanced');
  const aggressiveFixes = applyStrategy(file, 'aggressive');

  // Compare fixes
  if (differ(conservativeFixes, balancedFixes, aggressiveFixes)) {
    return {
      conflict: true,
      strategies: ['conservative', 'balanced', 'aggressive'],
      differences: computeDiff(conservativeFixes, balancedFixes, aggressiveFixes),
    };
  }
}
```

### 2. Conflict Prioritization

#### Priority System

```javascript
const scCodePriority = {
  SC2164: 1, // cd without error handling (critical)
  SC2046: 2, // Quote command substitution (important)
  SC2006: 3, // Use $() instead of backticks (style)
  SC2086: 4, // Quote variables (can be intentional)
};

function prioritizeFixes(fixes) {
  return fixes.sort((a, b) => scCodePriority[a.code] - scCodePriority[b.code]);
}
```

#### Conflict Resolution Rules

```yaml
conflict_resolution:
  rules:
    # Rule 1: Safety first
    - when: critical_safety_issue
      action: apply_safest_fix
      priority: 1

    # Rule 2: Preserve intentions
    - when: intentional_word_splitting
      action: skip_fix
      priority: 2
      markers:
        - '# shellcheck disable=SC2086'
        - '# intentional word splitting'

    # Rule 3: User preference
    - when: user_override_exists
      action: apply_user_preference
      priority: 3

    # Rule 4: Historical success
    - when: strategy_succeeded_before
      action: use_previous_strategy
      priority: 4
```

### 3. Interactive Resolution

#### CLI Interactive Mode

```bash
# Enable interactive conflict resolution
shellcheck-apply.sh --interactive script.sh

# Output:
# Conflict detected in script.sh at line 15:
#
#   echo $words  # SC2086
#
# This may be intentional word splitting.
#
# Options:
#   1. Quote variable: echo "$words"
#   2. Keep as-is (add shellcheck disable comment)
#   3. Show context and help
#   4. Skip this fix
#
# Your choice [1-4]: _
```

#### Automated Resolution

```bash
# Apply resolution rules from config
shellcheck-apply.sh --resolve-conflicts script.sh

# With explanation
shellcheck-apply.sh --resolve-conflicts --explain script.sh
```

### 4. Preference Storage

#### Store Resolutions

**File**: `.shellcheck-resolutions.json`

```json
{
  "resolutions": [
    {
      "file": "scripts/deploy.sh",
      "line": 15,
      "code": "SC2086",
      "resolution": "skip",
      "reason": "intentional_word_splitting",
      "timestamp": "2025-11-13T10:30:00Z"
    },
    {
      "file": "scripts/utils.sh",
      "line": 42,
      "code": "SC2046",
      "resolution": "apply_fix",
      "strategy": "aggressive",
      "timestamp": "2025-11-13T10:35:00Z"
    }
  ]
}
```

#### Apply Stored Preferences

```bash
# Use stored resolutions
shellcheck-apply.sh --use-resolutions script.sh

# Clear resolutions for file
shellcheck-apply.sh --clear-resolutions script.sh
```

### 5. Learning from Resolutions

#### Track Resolution Outcomes

```javascript
function recordResolutionOutcome(resolution, outcome) {
  database.insert({
    resolution_id: resolution.id,
    success: outcome.success,
    broke_tests: outcome.broke_tests,
    manual_revert: outcome.manual_revert,
    timestamp: Date.now(),
  });
}
```

#### Update Conflict Detection

```javascript
function updateConflictRules(resolutions) {
  // Learn which resolutions work best
  const successful = resolutions.filter((r) => r.outcome.success);

  // Update priority weights
  for (const resolution of successful) {
    conflictRules[resolution.type].weight += 0.1;
  }
}
```

## CLI Changes

### New Flags

```bash
# Interactive conflict resolution
--interactive

# Automated conflict resolution
--resolve-conflicts

# Use stored resolutions
--use-resolutions

# Clear stored resolutions
--clear-resolutions [file]

# Explain resolution decisions
--explain
```

## Success Criteria

- [ ] Conflict detection rules implemented
- [ ] SC code priority system working
- [ ] Interactive resolution mode implemented
- [ ] Automated resolution with rules
- [ ] Preference storage system working
- [ ] Resolution learning/feedback loop
- [ ] Tests for all conflict scenarios
- [ ] Documentation with examples

## Testing

- Test intentional word splitting detection
- Test conflicting quote suggestions
- Test strategy conflict detection
- Test priority system
- Test interactive mode (mock input)
- Test stored preference application
- Test learning from outcomes

## Documentation

- Document conflict types and detection
- Provide examples of each conflict
- Explain priority system
- Guide for interactive resolution
- Config file format for rules

## Dependencies

- Phase 1a complete (basic shellcheck-apply.sh)
- JSON storage for resolutions
- YAML parsing for config (optional)

## Future Enhancements

- ML model to predict conflict likelihood
- Team-wide conflict resolution sharing
- Visual diff tool for conflict inspection
- Integration with code review tools

---

📋 **Part of**: Phase 2 - Advanced Orchestration (#151)
🔗 **Source**: ORCHESTRATION_ROADMAP.md
