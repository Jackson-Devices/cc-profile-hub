# FUNCTION: Task Selection Engine

**Issue Type:** Function
**Parent:** SUB-FEATURE: Tasks Map System (#TBD)
**Grand-Parent:** FEATURE: Token-Efficient Documentation System (#TBD)
**Work Type:** Feature (inherited from parent)
**Labels:** `Type: Function`, `Type: Feature`, `Workflow: Backlog`, `Difficulty: Medium`, `AI: Supervised`

---

## Function Name

Task Selection Engine

---

## Parent Context

**Parent Sub-Feature:** Tasks Map System (AC2)
**Grand-Parent Feature:** Token-Efficient Documentation System

**This Function implements:** Deterministic card selection from task sequences

---

## Function Contract

**Inputs:**

- Task ID (string)
- Parsed tasks map (object)
- Cards base path (string)

**Outputs:**

- Ordered card list (array of card objects)
- Total token count (integer)
- Selection errors (array, empty if successful)

**Invariants:**

- Card order strictly matches sequence order
- All card files must exist
- No LLM/AI selection (deterministic only)
- Same task always returns same sequence

---

## Objective

Resolve task ID to ordered list of card file paths, ensuring deterministic selection without AI inference.

---

## Scope

**In Scope:**

- Task ID lookup in tasks map
- Card ID to file path resolution
- Level suffix handling
- Anchor reference extraction
- Missing card detection

**Out of Scope:**

- Token budget enforcement (handled in Function #2.3)
- Card content reading (done separately)
- Circular dependency detection (handled in AC5)

---

## Success Criteria

1. Resolves task ID to card sequence
2. Handles level suffixes correctly
3. Preserves strict ordering
4. Detects missing cards
5. Returns actionable error messages
6. Same task always produces same result

---

## Test Suite

- [ ] TEST-SUITE #2.2.1: Card Resolution Suite (6 tests)

---

## Technical Implementation

```javascript
// engines/task-selection-engine.js
import { resolve, join } from 'path';
import { existsSync } from 'fs';

export class TaskSelectionEngine {
  constructor(tasksMap, cardsBasePath) {
    this.tasks = tasksMap.tasks;
    this.cardsBase = cardsBasePath;
  }

  selectCardsForTask(taskId) {
    // Lookup task
    const task = this.tasks[taskId];
    if (!task) {
      return {
        success: false,
        cards: [],
        errors: [`Task '${taskId}' not found in tasks map`],
      };
    }

    // Resolve each card in sequence
    const cards = [];
    const errors = [];

    for (const [index, item] of task.sequence.entries()) {
      const result = this.resolveCardReference(item, index);

      if (result.success) {
        cards.push(result.card);
      } else {
        errors.push(result.error);
      }
    }

    return {
      success: errors.length === 0,
      task: {
        id: taskId,
        description: task.description,
        audience: task.audience,
        budget: task.bundle_budget_tokens,
      },
      cards: cards,
      errors: errors,
    };
  }

  resolveCardReference(item, sequenceIndex) {
    // Parse card ID
    // Format: level/card-id or just card-id
    const parts = item.id.split('/');
    let level, cardId;

    if (parts.length === 2) {
      [level, cardId] = parts;
    } else {
      return {
        success: false,
        error: `Sequence[${sequenceIndex}]: Invalid card ID format '${item.id}'. Expected 'level/card-id'`,
      };
    }

    // Validate level
    if (!['quick', 'task', 'deep'].includes(level)) {
      return {
        success: false,
        error: `Sequence[${sequenceIndex}]: Invalid level '${level}' in '${item.id}'`,
      };
    }

    // Resolve file path
    const filePath = join(this.cardsBase, level, `${cardId}.md`);

    if (!existsSync(filePath)) {
      return {
        success: false,
        error: `Sequence[${sequenceIndex}]: Card file not found: ${filePath}`,
      };
    }

    return {
      success: true,
      card: {
        id: item.id,
        level: level,
        cardId: cardId,
        filePath: filePath,
        anchor: item.anchor || null,
        levelOverride: item.level || null,
      },
    };
  }

  listAllTasks() {
    return Object.keys(this.tasks).map((taskId) => ({
      id: taskId,
      description: this.tasks[taskId].description,
      audience: this.tasks[taskId].audience,
      cardCount: this.tasks[taskId].sequence.length,
    }));
  }
}
```

---

## Dependencies

**Requires:**

- Function #2.1 (Tasks Map Parser) - parsed tasks map
- Function #1.2 (Card Storage) - file paths to resolve

**Blocks:**

- Function #2.3 (Budget Management) - needs card selection
- AC6 (Helper Automations) - bundle generation uses selection

---

## Related Documentation

- Parent: SUB-FEATURE #2 - Tasks Map System

---

**Created:** 2025-11-11
