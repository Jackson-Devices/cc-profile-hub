# FUNCTION: Near-Duplicate Detector

**Labels:** `Type: Function`, `Type: Feature`, `Workflow: Backlog`, `Difficulty: Hard`, `AI: Human+AI`

## Function Contract

**Inputs:** All cards, similarity threshold (default 0.8)
**Outputs:** Duplicate pairs with similarity scores, consolidation suggestions

## Test Suite

- [ ] TEST-SUITE #6.2.1: Similarity Detection Suite (6 tests)

**Created:** 2025-11-11
