# FUNCTION: Card Metadata Schema

**Issue Type:** Function
**Parent:** SUB-FEATURE: Doc Card Infrastructure (#TBD)
**Grand-Parent:** FEATURE: Token-Efficient Documentation System (#TBD)
**Work Type:** Feature (inherited from parent)
**Labels:** `Type: Function`, `Type: Feature`, `Workflow: Backlog`, `Difficulty: Medium`, `AI: Supervised`

---

## Function Name

Card Metadata Schema

---

## Parent Context

**Parent Sub-Feature:** Doc Card Infrastructure (AC1)
**Grand-Parent Feature:** Token-Efficient Documentation System

**This Function implements:** Card metadata schema definition and validation

---

## Function Contract

**Inputs:**

- Card file path (string)
- YAML front-matter content (object)

**Outputs:**

- Validation result (boolean)
- Error details (array of validation errors)
- Parsed metadata (object with typed fields)

**Invariants:**

- All required fields must be present
- Enum values must be from defined sets
- Token estimate must be positive integer
- Commit hashes must be valid SHA format
- Semantic version must follow semver spec

---

## Objective

Define and implement the JSON Schema that validates card metadata, ensuring all cards have consistent, type-safe front-matter with all required fields.

---

## Scope

**In Scope:**

- JSON Schema definition for card metadata
- Required fields: id, title, topics, audience, level, tokens_estimate, since_commit, last_verified_commit, source_paths, related_tasks, version
- Enum constraints: audience [human, agent, both], level [quick, task, deep]
- Type validation: strings, integers, arrays
- Format validation: commit hashes, semantic versions

**Out of Scope:**

- Card content validation (handled separately)
- Token estimate accuracy (validated in AC5)
- Link resolution (handled in Function #1.3)

---

## Success Criteria

1. JSON Schema file exists: `docs/cards/schema.json`
2. Schema defines all 11 required metadata fields
3. Schema includes type constraints and enum values
4. Schema validates successfully with ajv
5. Example cards pass schema validation
6. Schema documented in `docs/cards/README.md`

---

## Test Suite

- [ ] TEST-SUITE #1.1.1: Schema Validation Suite (6 tests)

---

## Technical Implementation

**Schema Structure:**

```json
{
  "$schema": "http://json-schema.org/draft-07/schema#",
  "type": "object",
  "required": [
    "id",
    "title",
    "topics",
    "audience",
    "level",
    "tokens_estimate",
    "since_commit",
    "last_verified_commit",
    "source_paths",
    "related_tasks",
    "version"
  ],
  "properties": {
    "id": {
      "type": "string",
      "pattern": "^[a-z0-9-]+$",
      "description": "Unique kebab-case identifier"
    },
    "title": {
      "type": "string",
      "minLength": 1,
      "maxLength": 100,
      "description": "Human-readable card title"
    },
    "topics": {
      "type": "array",
      "items": { "type": "string" },
      "minItems": 1,
      "description": "Topical tags for filtering"
    },
    "audience": {
      "type": "string",
      "enum": ["human", "agent", "both"],
      "description": "Intended audience"
    },
    "level": {
      "type": "string",
      "enum": ["quick", "task", "deep"],
      "description": "Card depth level"
    },
    "tokens_estimate": {
      "type": "integer",
      "minimum": 1,
      "description": "Estimated token count"
    },
    "since_commit": {
      "type": "string",
      "pattern": "^[a-f0-9]{7,40}$",
      "description": "Commit hash when created"
    },
    "last_verified_commit": {
      "type": "string",
      "pattern": "^[a-f0-9]{7,40}$",
      "description": "Commit hash when last verified"
    },
    "source_paths": {
      "type": "array",
      "items": { "type": "string" },
      "description": "Repository paths this card depends on"
    },
    "related_tasks": {
      "type": "array",
      "items": { "type": "string" },
      "description": "Task IDs from tasks.map.yaml"
    },
    "version": {
      "type": "string",
      "pattern": "^\\d+\\.\\d+\\.\\d+$",
      "description": "Semantic version for card content"
    }
  },
  "additionalProperties": false
}
```

**Validation Function:**

```javascript
// validators/card-schema.js
import Ajv from 'ajv';
import { readFile } from 'fs/promises';
import YAML from 'js-yaml';

const ajv = new Ajv({ allErrors: true });
const schema = JSON.parse(await readFile('docs/cards/schema.json', 'utf8'));
const validate = ajv.compile(schema);

export function validateCardMetadata(metadata) {
  const valid = validate(metadata);

  if (!valid) {
    return {
      valid: false,
      errors: validate.errors.map((err) => ({
        field: err.instancePath,
        message: err.message,
        params: err.params,
      })),
    };
  }

  return { valid: true };
}
```

---

## Dependencies

**Requires:**

- Node.js v20+ with ESM
- `ajv` for JSON Schema validation
- `js-yaml` for front-matter parsing

**Blocks:**

- Function #1.2 (Card Storage) - needs schema to validate against
- Function #1.3 (Card Linking) - needs metadata fields defined
- AC5 (Validation CLI) - uses this schema

---

## Related Documentation

- Parent: SUB-FEATURE #1 - Doc Card Infrastructure
- [TESTING_GUIDE.md](./docs/TESTING_GUIDE.md) - JSON Schema validation with Ajv

---

**Created:** 2025-11-11
**Last Updated:** 2025-11-11
