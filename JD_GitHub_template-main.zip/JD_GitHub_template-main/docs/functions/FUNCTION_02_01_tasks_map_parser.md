# FUNCTION: Tasks Map Parser

**Issue Type:** Function
**Parent:** SUB-FEATURE: Tasks Map System (#TBD)
**Grand-Parent:** FEATURE: Token-Efficient Documentation System (#TBD)
**Work Type:** Feature (inherited from parent)
**Labels:** `Type: Function`, `Type: Feature`, `Workflow: Backlog`, `Difficulty: Easy`, `AI: Autonomous`

---

## Function Name

Tasks Map Parser

---

## Parent Context

**Parent Sub-Feature:** Tasks Map System (AC2)
**Grand-Parent Feature:** Token-Efficient Documentation System

**This Function implements:** YAML parsing and structure validation for tasks.map.yaml

---

## Function Contract

**Inputs:**

- Tasks map file path (string): `docs/tasks.map.yaml`

**Outputs:**

- Parsed tasks object (object)
- Task count (integer)
- Parse errors (array, empty if successful)

**Invariants:**

- YAML must be valid and parseable
- Root object must have `tasks` key
- Each task must have required fields: description, audience, bundle_budget_tokens, sequence
- Sequence must be non-empty array
- Card references in sequence must have `id` field

---

## Objective

Parse and validate the structure of tasks.map.yaml, ensuring it contains well-formed task definitions with all required attributes.

---

## Scope

**In Scope:**

- YAML file parsing with js-yaml
- Structure validation (required fields present)
- Type checking (strings, integers, arrays)
- Sequence array validation
- Error reporting with line numbers

**Out of Scope:**

- Card existence validation (handled in Function #2.2)
- Circular dependency detection (handled in AC5)
- Token budget accuracy (handled in Function #2.3)

---

## Success Criteria

1. Parser function implemented with js-yaml
2. Validates required task attributes
3. Returns structured task objects
4. Clear error messages with line/field references
5. Handles malformed YAML gracefully
6. Documented in `docs/tasks.map.yaml` comments

---

## Test Suite

- [ ] TEST-SUITE #2.1.1: YAML Parsing Suite (6 tests)

---

## Technical Implementation

**Tasks Map Schema:**

```yaml
# docs/tasks.map.yaml
# Task definitions for deterministic documentation selection

tasks:
  user-authentication:
    description: 'Implement user authentication with JWT tokens'
    audience: agent # human | agent | both
    bundle_budget_tokens: 1200
    sequence:
      - id: quick/label-taxonomy
      - id: task/jwt-auth-strategy
      - id: deep/security-patterns
        anchor: '#token-handling' # optional
        level: deep # optional: select specific level variant

  testing-strategy:
    description: 'Design test suite following TDD hierarchy'
    audience: both
    bundle_budget_tokens: 1500
    sequence:
      - id: quick/test-types
      - id: task/tdd-workflow
      - id: deep/test-hierarchy
```

**Parser Implementation:**

```javascript
// parsers/tasks-map-parser.js
import YAML from 'js-yaml';
import { readFile } from 'fs/promises';

export class TasksMapParser {
  async parse(filePath) {
    try {
      const content = await readFile(filePath, 'utf8');
      const data = YAML.load(content);

      // Validate root structure
      if (!data || typeof data !== 'object') {
        throw new Error('Invalid tasks map: root must be an object');
      }

      if (!data.tasks || typeof data.tasks !== 'object') {
        throw new Error('Invalid tasks map: missing "tasks" key');
      }

      // Parse and validate each task
      const tasks = {};
      for (const [taskId, taskData] of Object.entries(data.tasks)) {
        tasks[taskId] = this.parseTask(taskId, taskData);
      }

      return {
        success: true,
        tasks: tasks,
        taskCount: Object.keys(tasks).length,
        errors: [],
      };
    } catch (error) {
      return {
        success: false,
        tasks: {},
        taskCount: 0,
        errors: [this.formatError(error)],
      };
    }
  }

  parseTask(taskId, taskData) {
    // Validate required fields
    const required = ['description', 'audience', 'bundle_budget_tokens', 'sequence'];
    for (const field of required) {
      if (!(field in taskData)) {
        throw new Error(`Task '${taskId}': missing required field '${field}'`);
      }
    }

    // Validate types
    if (typeof taskData.description !== 'string') {
      throw new Error(`Task '${taskId}': 'description' must be a string`);
    }

    if (!['human', 'agent', 'both'].includes(taskData.audience)) {
      throw new Error(`Task '${taskId}': invalid audience '${taskData.audience}'`);
    }

    if (!Number.isInteger(taskData.bundle_budget_tokens) || taskData.bundle_budget_tokens <= 0) {
      throw new Error(`Task '${taskId}': 'bundle_budget_tokens' must be positive integer`);
    }

    if (!Array.isArray(taskData.sequence) || taskData.sequence.length === 0) {
      throw new Error(`Task '${taskId}': 'sequence' must be non-empty array`);
    }

    // Validate sequence items
    const sequence = taskData.sequence.map((item, index) => {
      if (!item.id) {
        throw new Error(`Task '${taskId}', sequence[${index}]: missing 'id' field`);
      }
      return {
        id: item.id,
        anchor: item.anchor || null,
        level: item.level || null,
      };
    });

    return {
      description: taskData.description,
      audience: taskData.audience,
      bundle_budget_tokens: taskData.bundle_budget_tokens,
      sequence: sequence,
    };
  }

  formatError(error) {
    return {
      message: error.message,
      line: error.mark?.line || null,
      column: error.mark?.column || null,
    };
  }
}
```

**Usage Example:**

```javascript
import { TasksMapParser } from './parsers/tasks-map-parser.js';

const parser = new TasksMapParser();
const result = await parser.parse('docs/tasks.map.yaml');

if (result.success) {
  console.log(`Loaded ${result.taskCount} tasks`);
  console.log('Tasks:', Object.keys(result.tasks));
} else {
  console.error('Parse errors:', result.errors);
}
```

---

## Dependencies

**Requires:**

- Node.js v20+ with ESM
- `js-yaml` for YAML parsing

**Blocks:**

- Function #2.2 (Selection Engine) - needs parsed tasks
- Function #2.3 (Budget Management) - needs budget values
- AC5 (Validation CLI) - validates tasks map integrity

---

## Related Documentation

- Parent: SUB-FEATURE #2 - Tasks Map System
- [TESTING_GUIDE.md](./docs/TESTING_GUIDE.md) - YAML validation patterns

---

**Created:** 2025-11-11
**Last Updated:** 2025-11-11
