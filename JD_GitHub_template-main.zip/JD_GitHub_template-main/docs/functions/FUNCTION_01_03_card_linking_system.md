# FUNCTION: Card Linking System

**Issue Type:** Function
**Parent:** SUB-FEATURE: Doc Card Infrastructure (#TBD)
**Grand-Parent:** FEATURE: Token-Efficient Documentation System (#TBD)
**Work Type:** Feature (inherited from parent)
**Labels:** `Type: Function`, `Type: Feature`, `Workflow: Backlog`, `Difficulty: Medium`, `AI: Supervised`

---

## Function Name

Card Linking System

---

## Parent Context

**Parent Sub-Feature:** Doc Card Infrastructure (AC1)
**Grand-Parent Feature:** Token-Efficient Documentation System

**This Function implements:** Cross-reference linking between cards and task references

---

## Function Contract

**Inputs:**

- Link reference (string): `[text](path)` or `[text](#anchor)` or `task: task-id`
- Current card path (string)

**Outputs:**

- Resolved target path (string)
- Link validity (boolean)
- Link type (enum: file, anchor, task)

**Invariants:**

- Relative links resolved from card's directory
- Anchor links must have valid heading in target
- Task references must exist in tasks.map.yaml
- No circular references (card A → card B → card A)

---

## Objective

Enable cards to cross-reference each other, link to specific sections within cards, and reference tasks from the tasks map without creating broken links.

---

## Scope

**In Scope:**

- Markdown link parsing (standard markdown syntax)
- Relative path resolution between cards
- Anchor/heading resolution within target files
- Task reference syntax: `task: {task-id}`
- Circular reference detection

**Out of Scope:**

- External URL validation (out of repo)
- Image link handling (future enhancement)
- Link rewriting/transformation
- Automatic backlink generation

---

## Success Criteria

1. Link resolution function implemented
2. Relative paths resolve correctly between cards
3. Anchor links validate against target headings
4. Task references resolve via tasks.map.yaml
5. Circular references detected and flagged
6. Link syntax documented in `docs/cards/README.md`

---

## Test Suite

- [ ] TEST-SUITE #1.3.1: Link Resolution Suite (6 tests)

---

## Technical Implementation

**Link Types:**

1. **File Links** - Relative markdown links between cards

   ```markdown
   [See JWT Strategy](../task/jwt-auth-strategy.md)
   [Quick Reference](../quick/label-taxonomy.md)
   ```

2. **Anchor Links** - Links to specific sections

   ```markdown
   [Token Handling](#token-handling)
   [Security Patterns](../deep/security.md#jwt-patterns)
   ```

3. **Task References** - Links to tasks map entries
   ```markdown
   See task: user-authentication
   Related: task: testing-strategy
   ```

**Link Resolution Logic:**

```javascript
// utils/link-resolver.js
import { resolve, dirname, relative } from 'path';
import { existsSync, readFileSync } from 'fs';

export class LinkResolver {
  constructor(cardsBasePath, tasksMapPath) {
    this.cardsBase = cardsBasePath;
    this.tasksMap = this.loadTasksMap(tasksMapPath);
  }

  resolveLink(linkRef, currentCardPath) {
    // Parse link type
    if (linkRef.startsWith('task:')) {
      return this.resolveTaskReference(linkRef);
    }

    if (linkRef.includes('#')) {
      return this.resolveAnchorLink(linkRef, currentCardPath);
    }

    return this.resolveFileLink(linkRef, currentCardPath);
  }

  resolveFileLink(linkRef, currentCardPath) {
    const currentDir = dirname(currentCardPath);
    const targetPath = resolve(currentDir, linkRef);

    return {
      type: 'file',
      target: targetPath,
      valid: existsSync(targetPath),
      error: existsSync(targetPath) ? null : 'File not found',
    };
  }

  resolveAnchorLink(linkRef, currentCardPath) {
    const [filePath, anchor] = linkRef.split('#');

    // Resolve file path
    const currentDir = dirname(currentCardPath);
    const targetPath = filePath ? resolve(currentDir, filePath) : currentCardPath; // Same file anchor

    if (!existsSync(targetPath)) {
      return {
        type: 'anchor',
        target: targetPath,
        anchor: anchor,
        valid: false,
        error: 'Target file not found',
      };
    }

    // Check if anchor exists
    const content = readFileSync(targetPath, 'utf8');
    const anchorExists = this.findHeading(content, anchor);

    return {
      type: 'anchor',
      target: targetPath,
      anchor: anchor,
      valid: anchorExists,
      error: anchorExists ? null : `Anchor #${anchor} not found`,
    };
  }

  resolveTaskReference(linkRef) {
    const taskId = linkRef.replace(/^task:\s*/, '');
    const taskExists = this.tasksMap.tasks.hasOwnProperty(taskId);

    return {
      type: 'task',
      target: taskId,
      valid: taskExists,
      error: taskExists ? null : `Task '${taskId}' not found in tasks.map.yaml`,
    };
  }

  findHeading(content, anchor) {
    // Convert anchor to heading format
    // #token-handling → ## Token Handling
    const headingText = anchor
      .split('-')
      .map((word) => word.charAt(0).toUpperCase() + word.slice(1))
      .join(' ');

    const headingRegex = new RegExp(`^#+\\s+${headingText}`, 'm');
    return headingRegex.test(content);
  }

  loadTasksMap(path) {
    // Load and parse tasks.map.yaml
    // Implementation in AC2
    return { tasks: {} };
  }
}
```

**Circular Reference Detection:**

```javascript
export class CircularReferenceDetector {
  constructor() {
    this.visited = new Set();
    this.stack = new Set();
  }

  detectCycle(cardId, linkGraph) {
    if (this.stack.has(cardId)) {
      // Circular reference found
      return true;
    }

    if (this.visited.has(cardId)) {
      // Already checked, no cycle
      return false;
    }

    this.visited.add(cardId);
    this.stack.add(cardId);

    // Check all links from this card
    const links = linkGraph[cardId] || [];
    for (const linkedCardId of links) {
      if (this.detectCycle(linkedCardId, linkGraph)) {
        return true;
      }
    }

    this.stack.delete(cardId);
    return false;
  }
}
```

**Link Syntax Documentation:**

````markdown
## Linking Between Cards

### File Links (Relative Paths)

```markdown
[Card Title](../level/card-id.md)
```
````

Examples:

- From task/ to quick/: `[Labels](../quick/label-taxonomy.md)`
- From deep/ to task/: `[Auth Strategy](../task/jwt-auth.md)`

### Anchor Links (Specific Sections)

```markdown
[Section Name](../level/card-id.md#heading-anchor)
[Same Card Section](#heading-anchor)
```

### Task References

```markdown
See task: task-id
Related task: another-task-id
```

Task IDs must exist in `docs/tasks.map.yaml`.

```

---

## Dependencies

**Requires:**
- Function #1.1 (Metadata Schema) - defines `related_tasks` field
- Function #1.2 (Storage Structure) - needs paths to resolve
- AC2 (Tasks Map) - task references resolve via tasks.map.yaml

**Blocks:**
- AC5 (Validation CLI) - uses link resolution for validation

---

## Related Documentation

- Parent: SUB-FEATURE #1 - Doc Card Infrastructure
- AC2: Tasks Map System - task reference resolution

---

**Created:** 2025-11-11
**Last Updated:** 2025-11-11
```
