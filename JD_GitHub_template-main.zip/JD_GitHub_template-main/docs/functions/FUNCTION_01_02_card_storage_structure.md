# FUNCTION: Card Storage Structure

**Issue Type:** Function
**Parent:** SUB-FEATURE: Doc Card Infrastructure (#TBD)
**Grand-Parent:** FEATURE: Token-Efficient Documentation System (#TBD)
**Work Type:** Feature (inherited from parent)
**Labels:** `Type: Function`, `Type: Feature`, `Workflow: Backlog`, `Difficulty: Easy`, `AI: Autonomous`

---

## Function Name

Card Storage Structure

---

## Parent Context

**Parent Sub-Feature:** Doc Card Infrastructure (AC1)
**Grand-Parent Feature:** Token-Efficient Documentation System

**This Function implements:** Directory organization for cards by level (quick/task/deep)

---

## Function Contract

**Inputs:**

- Card level (enum: quick, task, deep)
- Card ID (string, kebab-case)

**Outputs:**

- Resolved file path (string)
- Directory existence confirmation (boolean)

**Invariants:**

- Quick cards always in `docs/cards/quick/`
- Task cards always in `docs/cards/task/`
- Deep cards always in `docs/cards/deep/`
- Filename format: `{card-id}.md`
- No duplicate filenames within same directory

---

## Objective

Establish the directory structure for organizing cards by their depth level and ensure proper file naming conventions.

---

## Scope

**In Scope:**

- Create `docs/cards/` directory structure
- Create `docs/cards/README.md` with authoring guide
- Define file naming convention (kebab-case .md files)
- Document directory organization
- Create placeholder example cards

**Out of Scope:**

- Card content creation (done on-demand)
- Card validation (handled in AC5)
- Card indexing/search (future enhancement)

---

## Success Criteria

1. Directory structure exists: `docs/cards/{quick,task,deep}/`
2. Each directory contains `.gitkeep` or example card
3. `docs/cards/README.md` documents structure and conventions
4. File naming convention documented
5. At least one example card per level created

---

## Test Suite

- [ ] TEST-SUITE #1.2.1: Directory Organization Suite (5 tests)

---

## Technical Implementation

**Directory Structure:**

```
docs/cards/
├── README.md              # Authoring guide and conventions
├── schema.json            # JSON Schema for metadata
├── quick/                 # ~100 word reference cards
│   ├── .gitkeep
│   └── label-taxonomy.md  # Example
├── task/                  # ~200 word implementation guides
│   ├── .gitkeep
│   └── jwt-auth-strategy.md  # Example
└── deep/                  # Deep dives, no word limit
    ├── .gitkeep
    └── tdd-philosophy.md  # Example
```

**File Naming Convention:**

- Pattern: `{card-id}.md`
- Card ID: lowercase, hyphen-separated, alphanumeric
- Examples: `label-taxonomy.md`, `jwt-auth-strategy.md`, `tdd-philosophy.md`
- ID must match front-matter `id` field exactly

**Path Resolution Function:**

```javascript
// utils/card-paths.js
import { join } from 'path';

const CARDS_BASE = 'docs/cards';

export function getCardPath(level, cardId) {
  if (!['quick', 'task', 'deep'].includes(level)) {
    throw new Error(`Invalid card level: ${level}`);
  }

  if (!/^[a-z0-9-]+$/.test(cardId)) {
    throw new Error(`Invalid card ID format: ${cardId}`);
  }

  return join(CARDS_BASE, level, `${cardId}.md`);
}

export function parseCardPath(filePath) {
  const match = filePath.match(/docs\/cards\/(quick|task|deep)\/([a-z0-9-]+)\.md$/);

  if (!match) {
    return null;
  }

  return {
    level: match[1],
    cardId: match[2],
  };
}
```

**README.md Structure:**

```markdown
# Documentation Cards

Self-contained documentation cards organized by depth level.

## Directory Organization

- `quick/` - Quick reference cards (~100 words)
  - Fast lookups
  - Cheat sheets
  - Label taxonomies

- `task/` - Task-oriented cards (~200 words)
  - Implementation approaches
  - Workflow guides
  - Strategy overviews

- `deep/` - Deep dive cards (no limit)
  - Architecture rationale
  - Trade-off analysis
  - Comprehensive guides

## File Naming

- Format: `{card-id}.md`
- Card ID: lowercase, hyphen-separated
- Must match front-matter `id` field

## Authoring Guide

[See full authoring guide below...]
```

---

## Dependencies

**Requires:**

- Function #1.1 (Metadata Schema) - defines `level` field

**Blocks:**

- Function #1.3 (Card Linking) - needs paths to resolve
- AC2 (Tasks Map) - needs paths to reference cards
- AC5 (Validation CLI) - needs structure to scan

---

## Related Documentation

- Parent: SUB-FEATURE #1 - Doc Card Infrastructure
- [docs/README.md](./docs/README.md) - Documentation directory overview

---

**Created:** 2025-11-11
**Last Updated:** 2025-11-11
