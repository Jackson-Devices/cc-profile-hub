# Orchestration Framework - Work Plan & Dependencies

## Current Status: Foundation Complete ✅

### What's Done
- [x] Tool Manifest Schema
- [x] Human Approval Workflow
- [x] Approval Gate Library
- [x] Example: Prettier Manifest
- [x] Documentation

### What's NOT Done
- [ ] Integration tests for approval flow
- [ ] Validation against existing workflows
- [ ] Tool manifests for existing tools (ESLint, ShellCheck, etc.)
- [ ] Naming Convention Checker
- [ ] Conflict Resolution Analyzer

---

## Stage 1: Test & Validate Foundation (CURRENT PRIORITY)

### Objective
Ensure the orchestration framework works with existing workflows before building new features.

### Tasks

#### 1.1 Create Integration Tests for Approval System
**Dependencies:**
- ✅ Upstream: `scripts/lib/approval-gate.mjs` exists
- ✅ Upstream: `schemas/tool-manifest.schema.json` exists
- ❌ External: None (pure unit/integration tests)

**Test Requirements (TDD):**
```javascript
// tests/orchestrator/approval-gate.test.mjs
describe('Approval Gate Library', () => {
  it('should generate unique task IDs');
  it('should validate task type');
  it('should create approval state file');
  it('should parse approval commands from issue comments');
  it('should validate approval secrets');
  it('should handle timeout expiration');
  it('should extract parameters from approvals');
});
```

**Exit Criteria:**
- [ ] All approval library functions tested
- [ ] 100% coverage on approval flow
- [ ] Tests pass in CI

#### 1.2 Validate Tool Manifest Schema
**Dependencies:**
- ✅ Upstream: `schemas/tool-manifest.schema.json` exists
- ✅ Upstream: `.orchestrator/tools/prettier.manifest.json` exists
- ❌ Downstream: Will be used by all tool manifests
- 📦 External: `ajv` package (already installed)

**Test Requirements:**
```bash
# Validate schema is valid JSON Schema
npx ajv compile -s schemas/tool-manifest.schema.json

# Validate prettier manifest against schema
npx ajv validate -s schemas/tool-manifest.schema.json \
  -d .orchestrator/tools/prettier.manifest.json
```

**Exit Criteria:**
- [ ] Schema validates correctly
- [ ] Prettier manifest validates against schema
- [ ] Add validation to package.json scripts
- [ ] Add validation to pre-commit hook

#### 1.3 Test Against Existing Workflows
**Dependencies:**
- ✅ Upstream: All workflows in `.github/workflows/`
- ❌ Downstream: None (validation only)
- 📦 External: None

**Workflows to Test:**
1. `auto-squash-commits.yml` - Can it integrate approval?
2. `prevent-sequential-commits-gate.yml` - Does it still work?
3. `orchestrator.yml` - Compatible with new tools?

**Test Matrix:**
```markdown
| Workflow | Test | Expected Result | Status |
|----------|------|-----------------|--------|
| auto-squash | Run on multi-commit branch | Analyzes commits | ⏳ TODO |
| auto-squash | Trigger approval (mock) | Creates approval request | ⏳ TODO |
| sequential-gate | Run analysis script | Passes/fails correctly | ⏳ TODO |
| orchestrator | Add tool manifest | Loads manifest | ⏳ TODO |
```

**Exit Criteria:**
- [ ] All existing workflows still pass
- [ ] No regressions introduced
- [ ] Workflows can load tool manifests
- [ ] Integration points documented

---

## Stage 2: Build Naming Convention Checker (NEXT)

### Objective
Create deterministic naming convention validator/fixer with human approval.

### Dependencies
**Upstream:**
- ✅ Orchestration framework (Stage 1 complete)
- ✅ Approval gate library
- ✅ Tool manifest schema

**Downstream:**
- ❌ Will be used by: commit-msg hook, pre-push hook, PR validation
- ❌ Will trigger: Human approval for renaming

**External:**
- None (pure logic)

### Sub-stages

#### 2.1 Write Tests First (TDD Red Phase)
**File:** `tests/orchestrator/naming-convention.test.mjs`

**Test Cases:**
```javascript
describe('Branch Naming Convention', () => {
  it('should validate conventional branch names', () => {
    assert.ok(isValid('feature/user-auth'));
    assert.ok(isValid('fix/login-bug'));
    assert.ok(isValid('docs/api-guide'));
    assert.notOk(isValid('my_random_branch'));
    assert.notOk(isValid('FEATURE-123'));
  });

  it('should suggest corrections', () => {
    assert.equal(suggest('my_branch'), 'feature/my-branch');
    assert.equal(suggest('FIX_BUG'), 'fix/bug');
  });

  it('should extract type from branch name', () => {
    assert.equal(extractType('feature/auth'), 'feature');
    assert.equal(extractType('invalid'), null);
  });
});

describe('Commit Message Convention', () => {
  it('should validate conventional commits', () => {
    assert.ok(isValid('feat: add login'));
    assert.ok(isValid('fix(auth): resolve token issue'));
    assert.notOk(isValid('fixed stuff'));
  });

  it('should suggest corrections', () => {
    assert.equal(suggest('fixed login bug'), 'fix: resolve login bug');
  });
});

describe('Issue Title Convention', () => {
  it('should validate issue titles', () => {
    assert.ok(isValid('[BUG] Login fails'));
    assert.ok(isValid('[FEATURE] Add dark mode'));
    assert.notOk(isValid('need to fix this'));
  });
});
```

**Exit Criteria:**
- [ ] All tests written
- [ ] Tests FAIL (no implementation yet)
- [ ] Coverage plan documented

#### 2.2 Create Tool Manifest (Before Implementation)
**File:** `.orchestrator/tools/naming-convention.manifest.json`

**Required Sections:**
```json
{
  "id": "naming-convention-fixer",
  "outputs": {
    "exit_codes": {
      "0": { "meaning": "All names valid", "action": "continue" },
      "1": { "meaning": "Invalid names found", "action": "human_approval" }
    },
    "message_registry": [
      {
        "pattern": "Branch '(.+)' violates (.+) convention",
        "severity": "warning",
        "action": "human_approval",
        "extract": {
          "branch_name": "Branch '(.+)'",
          "convention": "violates (.+) convention"
        },
        "suggested_fix": "Rename to: {suggested_name}"
      }
    ]
  },
  "human_approval": {
    "approval_prompts": [...]
  }
}
```

**Dependencies:**
- ✅ Upstream: Tool manifest schema
- ❌ Downstream: Orchestrator will load this

**Exit Criteria:**
- [ ] Manifest validates against schema
- [ ] All possible outputs documented
- [ ] All messages mapped to actions
- [ ] Approval prompts defined

#### 2.3 Implement Checker (TDD Green Phase)
**File:** `scripts/naming-convention-checker.mjs`

**Implementation Order:**
1. Branch name validation
2. Commit message validation
3. Issue title validation
4. Suggestion engine
5. Approval integration

**Exit Criteria:**
- [ ] All tests pass
- [ ] Manifest messages match actual outputs
- [ ] Dry-run mode works
- [ ] Integration with approval gate

#### 2.4 Integration Tests
**File:** `tests/orchestrator/naming-convention-integration.test.mjs`

**Test Real Scenarios:**
```javascript
describe('Integration: Branch Renaming', () => {
  it('should detect invalid branch, suggest rename, request approval');
  it('should allow custom name via approval');
  it('should handle approval timeout');
  it('should skip if approved as-is');
});
```

**Exit Criteria:**
- [ ] End-to-end tests pass
- [ ] Approval flow tested
- [ ] Timeout handling verified
- [ ] All exit codes tested

---

## Stage 3: Build Conflict Resolution Analyzer

### Dependencies
**Upstream:**
- ✅ Orchestration framework (Stage 1)
- ✅ Naming checker (Stage 2) - for testing patterns
- ✅ Approval gate library

**Downstream:**
- ❌ Will be used by: merge workflows, rebase workflows
- ❌ Will trigger: Human approval for resolution strategy

**External:**
- Git (system dependency)
- Conflict parsing (pure logic)

### Sub-stages

#### 3.1 Write Tests First (TDD)
**File:** `tests/orchestrator/conflict-resolver.test.mjs`

```javascript
describe('Conflict Detection', () => {
  it('should detect merge conflicts in git status');
  it('should parse conflict markers from file');
  it('should identify conflict type (content, rename, delete)');
  it('should extract our vs their changes');
});

describe('Conflict Analysis', () => {
  it('should analyze concurrent modifications');
  it('should detect incompatible changes');
  it('should recommend resolution strategy');
  it('should provide context (commits, authors, timestamps)');
});

describe('Resolution Strategies', () => {
  it('should apply "accept ours" strategy');
  it('should apply "accept theirs" strategy');
  it('should merge both changes (manual required)');
  it('should preserve backup before resolving');
});
```

**Exit Criteria:**
- [ ] All test cases defined
- [ ] Tests FAIL (no implementation)
- [ ] Real conflict examples created for testing

#### 3.2 Create Tool Manifest
**File:** `.orchestrator/tools/conflict-resolver.manifest.json`

**Message Registry:**
```json
{
  "message_registry": [
    {
      "pattern": "CONFLICT \\(content\\): Merge conflict in (.+)",
      "severity": "error",
      "action": "human_approval",
      "extract": { "file": "in (.+)" }
    },
    {
      "pattern": "CONFLICT \\(rename/rename\\): (.+)",
      "severity": "error",
      "action": "human_approval"
    }
  ]
}
```

#### 3.3 Implement Analyzer
**File:** `scripts/conflict-resolver.mjs`

**Implementation Order:**
1. Detect conflicts
2. Parse conflict markers
3. Analyze changes
4. Generate recommendations
5. Approval integration
6. Apply resolution (with backup)

**Exit Criteria:**
- [ ] Tests pass
- [ ] Handles all conflict types
- [ ] Safe (creates backups)
- [ ] Non-destructive

---

## Stage 4: Integrate with Existing Tools

### Objective
Add manifests for existing tools (ESLint, ShellCheck, Prettier).

### Sub-stages

#### 4.1 ESLint Manifest
**File:** `.orchestrator/tools/eslint.manifest.json`

**Message Registry:**
```json
{
  "pattern": "✖ (\\d+) problems? \\((\\d+) errors?, (\\d+) warnings?\\)",
  "extract": {
    "total": "(\\d+) problems?",
    "errors": "(\\d+) errors?",
    "warnings": "(\\d+) warnings?"
  },
  "action": "human_approval"
}
```

**Dependencies:**
- ✅ Upstream: ESLint already in use
- ❌ Downstream: Orchestrator will use this
- 📦 External: ESLint (already installed)

**Exit Criteria:**
- [ ] Manifest validates
- [ ] All ESLint outputs mapped
- [ ] Approval prompts defined
- [ ] Integration tested

#### 4.2 ShellCheck Manifest
**File:** `.orchestrator/tools/shellcheck.manifest.json`

**Exit Criteria:**
- [ ] All outputs mapped
- [ ] Integration tested

#### 4.3 Prettier Manifest (Already Exists)
**Tasks:**
- [ ] Validate against real Prettier output
- [ ] Test approval flow
- [ ] Document any gaps

---

## Stage 5: End-to-End Testing

### Objective
Test complete orchestration flow with all tools.

### Test Scenarios

#### 5.1 Happy Path
```
1. Push code with issues
2. ESLint finds errors → requests approval
3. Human approves "fix all"
4. ESLint auto-fixes
5. Prettier formats → requests approval
6. Human approves
7. All checks pass
```

**Exit Criteria:**
- [ ] Complete flow works
- [ ] All approvals handled
- [ ] No manual intervention bugs

#### 5.2 Rejection Path
```
1. Tool finds issues
2. Requests approval
3. Human rejects
4. Workflow aborts gracefully
```

**Exit Criteria:**
- [ ] Rejection handled correctly
- [ ] No orphaned states
- [ ] Clear error messages

#### 5.3 Timeout Path
```
1. Tool requests approval
2. No response within timeout
3. Default action taken
```

**Exit Criteria:**
- [ ] Timeout handled
- [ ] Audit log created
- [ ] Workflow continues/aborts per config

---

## Testing Checklist (Before ANY Commit)

### Local Tests
```bash
# Unit tests
npm run test:commit-splitter
npm run test:commit-splitter:integration

# Lint
npm run lint:check

# Workflow validation
npm run validate:workflows

# Schema validation
npx ajv validate -s schemas/tool-manifest.schema.json \
  -d .orchestrator/tools/*.manifest.json

# Full test suite
npm test
```

### Workflow Tests
```bash
# Test auto-squash workflow (dry-run)
git checkout -b test-squash
# Make multiple commits
git push

# Verify workflow runs
gh workflow view auto-squash-commits

# Test approval workflow
gh workflow run human-approval-gate \
  --field task_id=test-123 \
  --field task_type=commit-squash \
  --field approval_secret=<secret>
```

### Integration Tests
```bash
# Create test branch with violations
git checkout -b test/invalid_name  # Violates convention

# Run naming checker
node scripts/naming-convention-checker.mjs --dry-run

# Verify output matches manifest
```

---

## Dependency Graph

```
Foundation (Stage 1)
    ├── Tool Manifest Schema ✅
    ├── Approval Gate Library ✅
    ├── Human Approval Workflow ✅
    └── Documentation ✅
        ↓
    [TESTS REQUIRED BEFORE PROCEEDING]
        ↓
Naming Checker (Stage 2)
    ├── Depends on: Foundation
    ├── Required by: Commit hooks, PR validation
    └── Triggers: Approval workflow
        ↓
Conflict Resolver (Stage 3)
    ├── Depends on: Foundation, Naming Checker (for patterns)
    ├── Required by: Merge workflows
    └── Triggers: Approval workflow
        ↓
Tool Integration (Stage 4)
    ├── Depends on: Foundation
    ├── Integrates: ESLint, ShellCheck, Prettier
    └── Required by: Orchestrator
        ↓
End-to-End Tests (Stage 5)
    ├── Depends on: All stages
    └── Validates: Complete system
```

---

## External Dependencies

### NPM Packages
- `ajv` - JSON Schema validation ✅ (installed)
- `eslint` - Linting ✅ (installed)
- `prettier` - Formatting ✅ (installed)
- `js-yaml` - YAML parsing ✅ (installed)

### GitHub Features
- Secrets - For approval validation ⏳ (needs setup)
- Issues - For approval comments ✅ (available)
- Workflows - workflow_dispatch ✅ (available)
- Actions - github-script ✅ (available)

### System Dependencies
- Git 2.0+ ✅ (available)
- Node 20+ ✅ (available)
- Bash ✅ (available)

---

## Risk Mitigation

### High-Risk Operations
1. **Commit squashing** - Mitigated by backup branches
2. **Branch renaming** - Requires approval
3. **Conflict resolution** - Creates backups, requires approval
4. **Destructive operations** - Always require approval + secret

### Rollback Plan
```bash
# If new feature breaks workflows
git revert <commit-sha>
git push

# If approval system fails
# Workflows can still run without approval
# (they just won't pause for human input)

# If schema validation breaks
# Old manifests without schema still work
# (schema is opt-in validation)
```

---

## Success Metrics

### Stage 1 (Foundation Testing)
- ✅ All existing workflows pass
- ✅ Schema validation working
- ✅ Approval library tested
- ✅ No regressions

### Stage 2 (Naming Checker)
- ✅ Detects 100% of convention violations
- ✅ Suggestions accurate >90%
- ✅ Approval flow works
- ✅ Zero false positives

### Stage 3 (Conflict Resolver)
- ✅ Detects all conflict types
- ✅ Provides actionable recommendations
- ✅ Never loses data (backups work)
- ✅ Human can always override

### Stage 4 (Tool Integration)
- ✅ All tools have manifests
- ✅ All outputs mapped
- ✅ Orchestrator loads all tools
- ✅ No unmapped messages

### Stage 5 (E2E)
- ✅ Complete flow works
- ✅ All edge cases handled
- ✅ Performance acceptable (<2min for full flow)
- ✅ Clear error messages

---

## Next Actions (Priority Order)

1. **[CURRENT]** Run full test suite
   ```bash
   npm test
   ```

2. **[NEXT]** Validate tool manifest schema
   ```bash
   npm run validate:manifests  # Add this script
   ```

3. **[THEN]** Test against existing workflows
   ```bash
   .github/workflows/test-orchestration.yml  # Create this
   ```

4. **[AFTER]** Start Stage 2 (Naming Checker)
   - Write tests first (TDD)
   - Create manifest
   - Implement
   - Integrate

**DO NOT proceed to Stage 2 until Stage 1 testing is 100% complete.**
