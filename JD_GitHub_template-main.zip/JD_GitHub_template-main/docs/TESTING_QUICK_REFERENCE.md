# Testing Quick Reference - GitHub Actions & Node.js

**Quick access guide for common testing patterns and commands**

---

## Essential Commands

### Node.js Native Test Runner

```bash
# Run all tests
node --test

# Watch mode
node --test --watch

# With coverage
node --test --experimental-test-coverage

# Specific pattern
node --test "**/*.test.js"

# Filter by name
node --test --test-name-pattern="user.*"
```

### Vitest

```bash
# Run tests
npm test

# Watch mode
vitest

# Coverage
vitest --coverage

# UI mode
vitest --ui
```

### Local Workflow Testing (act)

```bash
# Run all workflows
act

# Specific event
act push

# Specific job
act -j test

# Dry run
act -n

# List workflows
act -l
```

### Workflow Validation (actionlint)

```bash
# Validate all workflows
actionlint

# Specific file
actionlint .github/workflows/test.yml

# JSON output
actionlint -format '{{json .}}'
```

---

## Common Test Patterns

### Basic Test (Node.js)

```javascript
import { test } from 'node:test';
import assert from 'node:assert/strict';

test('description', () => {
  assert.strictEqual(actual, expected);
});

test('async test', async () => {
  const result = await someAsyncFunction();
  assert.ok(result);
});
```

### Test Suite with Hooks

```javascript
import { describe, it, before, after, beforeEach, afterEach } from 'node:test';

describe('Suite', () => {
  before(() => console.log('setup'));
  after(() => console.log('teardown'));
  beforeEach(() => console.log('before each'));
  afterEach(() => console.log('after each'));

  it('test 1', () => {});
  it('test 2', () => {});
});
```

### Mocking Functions

```javascript
import { test } from 'node:test';

test('mock function', (t) => {
  const fn = t.mock.fn((a, b) => a + b);

  fn(2, 3);

  assert.strictEqual(fn.mock.callCount(), 1);
  assert.deepStrictEqual(fn.mock.calls[0].arguments, [2, 3]);
});
```

### Mocking Timers

```javascript
test('mock timers', (t) => {
  t.mock.timers.enable({ apis: ['setTimeout'] });

  const fn = t.mock.fn();
  setTimeout(fn, 1000);

  t.mock.timers.tick(1000);
  assert.strictEqual(fn.mock.callCount(), 1);
});
```

---

## GitHub Actions Patterns

### Matrix Strategy

```yaml
strategy:
  matrix:
    node-version: [18, 20, 22]
    os: [ubuntu-latest, windows-latest]
    exclude:
      - os: windows-latest
        node-version: 18
    include:
      - node-version: 23
        experimental: true
```

### Using Secrets

```yaml
steps:
  - name: Use secrets
    env:
      API_KEY: ${{ secrets.API_KEY }}
    run: npm test
```

### Conditional Steps

```yaml
steps:
  - name: Run only on main
    if: github.ref == 'refs/heads/main'
    run: echo "Main branch"

  - name: Run on PR
    if: github.event_name == 'pull_request'
    run: echo "PR"
```

### Job Outputs

```yaml
jobs:
  job1:
    outputs:
      result: ${{ steps.step1.outputs.result }}
    steps:
      - id: step1
        run: echo "result=success" >> $GITHUB_OUTPUT

  job2:
    needs: job1
    steps:
      - run: echo ${{ needs.job1.outputs.result }}
```

---

## Validation Patterns

### YAML Validation

```javascript
import YAML from 'js-yaml';
import { readFile } from 'fs/promises';

const content = await readFile('file.yml', 'utf8');
const data = YAML.load(content);
```

### JSON Schema Validation

```javascript
import Ajv from 'ajv';

const ajv = new Ajv();
const schema = {
  type: 'object',
  properties: {
    name: { type: 'string' },
  },
  required: ['name'],
};

const validate = ajv.compile(schema);
const valid = validate(data);

if (!valid) console.log(validate.errors);
```

---

## Mock GitHub API

### Mock Octokit

```javascript
const mockGithub = {
  rest: {
    issues: {
      get: async () => ({ data: { id: 1, title: 'Test' } }),
      createComment: async () => ({ data: { id: 1 } }),
    },
  },
};
```

### Mock Context

```javascript
const mockContext = {
  repo: { owner: 'test', repo: 'test' },
  issue: { number: 1 },
  eventName: 'issues',
  payload: { issue: { number: 1 } },
};
```

---

## Assertions Cheat Sheet

### Node.js Assert (Strict)

```javascript
import assert from 'node:assert/strict';

// Equality
assert.strictEqual(actual, expected);
assert.deepStrictEqual(obj1, obj2);

// Truthiness
assert.ok(value);

// Throws
assert.throws(() => fn(), Error);
assert.rejects(async () => fn(), /error message/);

// Does not throw
assert.doesNotThrow(() => fn());
assert.doesNotReject(async () => fn());

// Match
assert.match(string, /regex/);
```

### Vitest Assertions

```javascript
import { expect } from 'vitest';

// Equality
expect(value).toBe(expected);
expect(obj).toEqual(expected);

// Truthiness
expect(value).toBeTruthy();
expect(value).toBeFalsy();

// Objects
expect(obj).toHaveProperty('key');
expect(obj).toMatchObject({ key: 'value' });

// Arrays
expect(arr).toContain(item);
expect(arr).toHaveLength(3);

// Throws
expect(() => fn()).toThrow();
expect(() => fn()).toThrow('message');

// Async
await expect(promise).resolves.toBe(value);
await expect(promise).rejects.toThrow();

// Snapshots
expect(data).toMatchSnapshot();
```

---

## Environment Setup

### package.json

```json
{
  "type": "module",
  "scripts": {
    "test": "node --test",
    "test:watch": "node --test --watch",
    "test:coverage": "node --test --experimental-test-coverage"
  },
  "devDependencies": {
    "js-yaml": "^4.1.0",
    "ajv": "^8.12.0",
    "@octokit/rest": "^20.0.2"
  }
}
```

### Test Directory Structure

```
test/
├── unit/
│   ├── validators.test.js
│   └── helpers.test.js
├── integration/
│   ├── api.test.js
│   └── workflows.test.js
├── e2e/
│   └── full-pipeline.test.js
├── fixtures/
│   ├── workflows/
│   ├── issues/
│   └── responses/
└── helpers/
    ├── github.js
    └── setup.js
```

---

## Debugging Tests

### Enable Debug Output

```bash
# Node.js test runner
NODE_OPTIONS='--enable-source-maps' node --test

# GitHub Actions
ACTIONS_STEP_DEBUG=true

# In workflow
env:
  ACTIONS_STEP_DEBUG: true
```

### Isolate Test

```javascript
// Run only this test
test('only this one', { only: true }, () => {});

// Skip this test
test('skip this', { skip: true }, () => {});

// Mark as TODO
test('finish later', { todo: true }, () => {});
```

### Watch Specific Files

```bash
# Node.js
node --test --watch test/specific.test.js

# Vitest
vitest test/specific.test.js
```

---

## CI/CD Integration

### Basic Test Workflow

```yaml
name: Test
on: [push, pull_request]

jobs:
  test:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v4
      - uses: actions/setup-node@v4
        with:
          node-version: '20'
          cache: 'npm'
      - run: npm ci
      - run: npm test
```

### With Coverage

```yaml
- run: npm run test:coverage
- uses: codecov/codecov-action@v4
  with:
    files: ./coverage/coverage.xml
```

### Matrix Testing

```yaml
strategy:
  matrix:
    node: [18, 20, 22]
    os: [ubuntu-latest, windows-latest]

runs-on: ${{ matrix.os }}
steps:
  - uses: actions/setup-node@v4
    with:
      node-version: ${{ matrix.node }}
```

---

## Security Checklist

- [ ] No hardcoded secrets in code
- [ ] Secrets passed via environment variables
- [ ] User input sanitized (no script injection)
- [ ] Third-party actions pinned to SHA
- [ ] GITHUB_TOKEN uses minimal permissions
- [ ] Dependabot doesn't expose secrets
- [ ] actionlint passes all checks
- [ ] Test secrets separate from production

---

## Useful Links

| Resource            | URL                                      |
| ------------------- | ---------------------------------------- |
| Node.js Test Runner | https://nodejs.org/api/test.html         |
| Vitest              | https://vitest.dev                       |
| GitHub Actions Docs | https://docs.github.com/en/actions       |
| actionlint          | https://github.com/rhysd/actionlint      |
| act                 | https://github.com/nektos/act            |
| Octokit             | https://github.com/octokit/octokit.js    |
| Ajv                 | https://ajv.js.org                       |
| github-script       | https://github.com/actions/github-script |

---

## Common Issues & Solutions

### Issue: ESM Import Errors

**Solution**: Ensure `"type": "module"` in package.json and use `.js` extensions in imports:

```javascript
// Correct
import { fn } from './module.js';

// Incorrect
import { fn } from './module';
```

### Issue: Tests Not Found

**Solution**: Use correct glob pattern:

```bash
# Correct
node --test "**/*.test.js"

# Also check file naming matches pattern
```

### Issue: Mock Not Working

**Solution**: For Node.js test runner, use test context:

```javascript
// Correct
test('name', (t) => {
  const mock = t.mock.fn();
});

// Incorrect (global mock doesn't exist)
const mock = mock.fn();
```

### Issue: GitHub Actions Secrets Not Available

**Solution**: Check secret scope and environment:

```yaml
# Repository secret
env:
  API_KEY: ${{ secrets.API_KEY }}

# Environment secret (requires environment)
environment: production
env:
  API_KEY: ${{ secrets.API_KEY }}
```

### Issue: actionlint False Positives

**Solution**: Use actionlint.yaml config to ignore:

```yaml
# .github/actionlint.yaml
ignore:
  - 'property "custom_key" is not defined'
```

---

**Last Updated**: 2025-11-09
