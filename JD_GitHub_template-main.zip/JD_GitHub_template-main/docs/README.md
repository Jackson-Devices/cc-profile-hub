# Documentation Directory

**Purpose:** Centralized documentation for Jackson-Devices GitHub Template

---

## Directory Structure

```
docs/
├── README.md (this file) - Directory map and overview
├── architecture/ - Framework architecture and design specifications
├── features/ - Feature and Sub-Feature specifications
├── functions/ - Function contract specifications
├── examples/ - Concrete examples of framework usage
├── workflows/ - Workflow documentation and guides
├── testing/ - Testing strategy and research
├── planning/ - Roadmaps and implementation plans
├── reviews/ - Code review reports and status updates
├── logging/ - Logging system documentation
├── reference/ - Reference documents and configuration
├── issues_mirror/ - Issue tracking and analysis
│   └── analysis/ - Issue-specific analysis documents
├── ai_work/ - AI-specific documentation (decision logs, max pass)
├── diagrams/ - Visual diagrams and flowcharts
├── templates/ - Issue template documentation
├── formatters/ - Code formatter documentation
├── cards/ - Documentation cards (quick/deep/task)
└── archive/ - Historical TODO files and design docs
```

---

## Quick Navigation

### For Users

- **Getting Started:** See main [README.md](../README.md)
- **Issue Templates:** [templates/template_usage.md](./templates/template_usage.md)
- **Test Naming:** [examples/test_naming_examples.md](./examples/test_naming_examples.md)
- **Hierarchy Examples:** [examples/hierarchy_examples.md](./examples/hierarchy_examples.md)
- **Workflow Reference:** [workflows/test_workflow_detailed.md](./workflows/test_workflow_detailed.md)

### For AI Assistants

- **Decision Logging:** [ai_work/decision_log_format.md](./ai_work/decision_log_format.md)
- **Max Pass Enforcement:** [ai_work/max_pass_enforcement.md](./ai_work/max_pass_enforcement.md)
- **Decision Log Example:** [examples/decision_log_example_full.md](./examples/decision_log_example_full.md)
- **Worktree Workflow:** [reference/TASK_REFERENCE_INDEX.md](./reference/TASK_REFERENCE_INDEX.md#git-worktree-workflow-for-atomic-tasks-required-for-ai)

### For Developers

- **Formatters:** [formatters/](./formatters/) - Prettier setup and usage
- **Atomic TDD Framework:** [architecture/ATOMIC_TDD_FRAMEWORK.md](./architecture/ATOMIC_TDD_FRAMEWORK.md)
- **Label Design:** [architecture/LABEL_DESIGN_SPEC.md](./architecture/LABEL_DESIGN_SPEC.md)
- **Orchestration Roadmap:** [planning/ORCHESTRATION_ROADMAP.md](./planning/ORCHESTRATION_ROADMAP.md)

---

## Documentation Categories

### Architecture (`architecture/`)

Framework architecture and design specifications:

- **ATOMIC_TDD_FRAMEWORK.md** - 5-level test hierarchy specification
- **LABEL_DESIGN_SPEC.md** - Complete label taxonomy v1.3
- **TOKEN_EFFICIENT_DOCS_HIERARCHY.md** - Documentation system design

### Features (`features/`)

Feature and Sub-Feature specifications following the atomic hierarchy:

- FEATURE_* - Top-level feature specifications
- SUB_FEATURE_* - Sub-feature implementation details
- Linked to functions via acceptance criteria

### Functions (`functions/`)

Function contract specifications (23 functions):

- FUNCTION_01_* - Doc card infrastructure functions
- FUNCTION_02_* - Tasks map system functions
- FUNCTION_03_* - Issue mirroring functions
- FUNCTION_04_* - Drift detection functions
- FUNCTION_05_* - Validation CLI functions
- FUNCTION_06_* - Helper automation functions

### Examples (`examples/`)

Concrete, real-world examples showing how to use the framework:

- Test naming conventions (IB/OOB/T-ID)
- Complete hierarchy examples (Feature → Test)
- Decision log walkthrough with multiple passes
- Template usage scenarios

### Workflows (`workflows/`)

Detailed workflow documentation:

- Test workflow state machine
- Validation gate enforcement
- Checklist generation algorithm
- Error handling and retry logic

### AI Work (`ai_work/`)

Documentation specific to AI assistants:

- Decision log format specification
- Max pass enforcement rules
- Escalation workflows
- AI execution patterns

### Templates (`templates/`)

Issue template documentation:

- Template usage guide
- Schema designs
- Testing checklists
- Verification reports

### Formatters (`formatters/`)

Code formatting documentation:

- Prettier setup and configuration
- House style rules
- Integration guides
- Troubleshooting

### Testing (`testing/`)

Testing strategy and research:

- TESTING_STRATEGY_DECISION_LOG.md - Testing approach decisions
- RESEARCH_GITHUB_ACTIONS_TESTING.md - GitHub Actions testing research
- Testing guides and quick references

### Planning (`planning/`)

Roadmaps and implementation plans:

- ORCHESTRATION_ROADMAP.md - Workflow orchestrator roadmap
- FILE_TRACKING_PLAN.md - File tracking system plan
- Strategic planning documents

### Reviews (`reviews/`)

Code review reports and status updates:

- COMPREHENSIVE_STATUS_UPDATE.md - Overall status reports
- REVIEW_FINDINGS.md, REVIEW_SUMMARY.md - Code review results
- SCRIPT_FIX_SUMMARY.md - Bug fix summaries

### Logging (`logging/`)

Logging system documentation:

- LOGGING_DEEP_DIVE_SUMMARY.md - Logging architecture deep dive
- Decision logging specifications
- Logging best practices

### Reference (`reference/`)

Reference documents and configuration:

- REPO_INIT.md - Repository initialization guide
- REPO_VARIABLES.md - Repository variables reference
- TASK_REFERENCE_INDEX.md - Task and workflow reference
- issues_rules.md - Issue management rules

### Issues Mirror & Analysis (`issues_mirror/`)

Issue tracking and analysis:

- **analysis/** - Issue-specific analysis documents
  - ISSUE_26_BREAKDOWN.md, ISSUE_132_ANALYSIS.md
  - ISSUE_AUDIT_REPORT.md

### Archive (`archive/`)

Historical documents (read-only):

- Previous TODO files
- Design decision records
- Evolution of framework

---

## Contributing to Documentation

When adding new documentation:

1. **Choose the right directory:**
   - Architecture/design specs? → `architecture/`
   - Feature/sub-feature specs? → `features/`
   - Function contracts? → `functions/`
   - Concrete examples? → `examples/`
   - Workflow guides? → `workflows/`
   - Testing docs? → `testing/`
   - Planning/roadmaps? → `planning/`
   - Review reports? → `reviews/`
   - AI-specific? → `ai_work/`
   - Template docs? → `templates/`
   - Reference materials? → `reference/`

2. **Follow naming convention:**
   - Use lowercase with underscores: `test_naming_examples.md`
   - Be descriptive: `decision_log_example_full.md` not `example.md`

3. **Add to this README:**
   - Update navigation section
   - Add brief description
   - Link appropriately

4. **Cross-reference:**
   - Link from main README.md if user-facing
   - Link from reference/TASK_REFERENCE_INDEX.md if AI workflow-related
   - Link from architecture/ATOMIC_TDD_FRAMEWORK.md if methodology-related

---

## Documentation Principles

1. **Examples over Explanation:** Show, don't just tell
2. **Concrete over Abstract:** Real issue numbers, actual code
3. **Scannable:** Use tables, lists, decision trees
4. **Cross-Referenced:** Link related docs liberally
5. **Maintained:** Update when framework changes

---

**Last Updated:** 2025-11-14 (P1.1 Documentation Refactoring)
**Maintained by:** Jackson-Devices
