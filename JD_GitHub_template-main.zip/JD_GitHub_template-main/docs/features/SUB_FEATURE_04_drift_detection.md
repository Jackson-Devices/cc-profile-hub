# SUB-FEATURE: Drift Detection System

**Issue Type:** Sub-Feature
**Parent:** FEATURE: Token-Efficient Documentation System (#TBD)
**Work Type:** Feature (inherited from parent)
**Labels:** `Role: Sub-Feature`, `Type: Feature`, `Workflow: Backlog`

---

## Sub-Feature Name

Drift Detection System

---

## Parent Context

**Parent Feature:** Token-Efficient Documentation System

**This Sub-Feature implements:** AC4 - Drift detection monitors code changes and flags documentation updates (warn-only)

---

## Objective

Automatically detect when code changes affect documentation cards and flag issues for review, ensuring docs stay synchronized with implementation without blocking work.

**What this delivers:**

- Monitoring of file paths referenced in card `source_paths`
- Commit-based drift detection (works with or without linked issues)
- Automatic label application (`Docs: Needed`)
- Impact summary comments on PRs
- Warn-only enforcement (never fails CI)

---

## Scope

**In Scope:**

- Monitor changes to paths in card `source_paths` metadata
- Detect drift on: PR creation, PR update, direct commits to main
- Apply `Docs: Needed` label to affected issues
- Post PR comment summarizing affected cards
- Create tracking issue for uncommitted drift (commits without linked issues)
- Warn-only: never block merges

**Out of Scope:**

- Intelligent heuristics for "should this have docs" (Phase 2)
- Automatic card content updates (manual review required)
- Real-time drift detection (acceptable delay: workflow run time)
- Semantic change detection (simple path matching only in Phase 1)

---

## Acceptance Criteria

1. GitHub Actions workflow created: `docs-drift-gate.yml`
2. Workflow triggers on: pull_request, push to main
3. Detects changes to paths in any card's `source_paths`
4. Applies `Docs: Needed` label to affected issues (or creates new issue)
5. Posts PR comment listing affected cards with links
6. Workflow always exits success (warn-only, never fails)
7. At least one test case demonstrates drift detection

---

## Function Breakdown

This Sub-Feature decomposes into 3 functions:

- [ ] Function #XXX: Source Path Monitoring
- [ ] Function #YYY: Change Impact Analysis
- [ ] Function #ZZZ: Warning Label Application

---

## Success Metrics

**Detection Accuracy:**

- 100% of relevant changes detected (no false negatives for exact path matches)
- <10% false positives (paths match but semantic change doesn't affect docs)

**Response Time:**

- Drift detection completes within 30 seconds of PR/commit
- Label application within 5 seconds of detection
- PR comment posted within 10 seconds

**Usability:**

- Clear, actionable warnings with card links
- False positives easy to dismiss (close as `Docs: Not-Needed`)
- Creates tracking issues for orphaned drift (commits without issues)

---

## Dependencies

**Requires:**

- AC1 (Doc Card Infrastructure) - `source_paths` field must exist
- `docs/cards/` structure with valid front-matter

**Blocks:**

- None (enhances workflow but not blocking)

---

## Technical Notes

**Drift Detection Logic:**

```javascript
// Pseudocode for drift detection
1. Get list of changed files from commit/PR
2. Scan all cards in docs/cards/**/*.md
3. Parse front-matter for each card
4. Check if any changed file matches source_paths
5. For each affected card:
   - Find related issues (via related_tasks or issue references)
   - Apply Docs: Needed label
   - Add to impact summary
6. If no related issue found:
   - Create new tracking issue
   - Title: "Documentation drift: {card-id}"
   - Body: Link to card, commit SHA, changed paths
7. Post PR comment with impact summary
```

**Workflow Structure:**

```yaml
# .github/workflows/docs-drift-gate.yml
name: Documentation Drift Detection

on:
  pull_request:
    types: [opened, synchronize]
  push:
    branches: [main]

jobs:
  detect-drift:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v4
        with:
          fetch-depth: 0 # Need full history for diff

      - name: Get changed files
        id: changed
        run: |
          if [ "${{ github.event_name }}" == "pull_request" ]; then
            git diff --name-only origin/${{ github.base_ref }}...HEAD
          else
            git diff --name-only HEAD~1 HEAD
          fi

      - name: Detect drift
        run: node scripts/detect-docs-drift.js
        env:
          CHANGED_FILES: ${{ steps.changed.outputs.files }}
          GITHUB_TOKEN: ${{ secrets.GITHUB_TOKEN }}

      - name: Always succeed (warn-only)
        if: always()
        run: exit 0
```

**PR Comment Format:**

```markdown
## 📚 Documentation Drift Detected

The following documentation cards may need updates:

### Affected Cards:

- [`task/jwt-auth-strategy.md`](../docs/cards/task/jwt-auth-strategy.md)
  - Changed files: `src/auth/jwt.js`, `src/middleware/auth-check.js`
  - Last verified: `abc123` (3 days ago)
  - Related issue: #42

- [`deep/security-patterns.md`](../docs/cards/deep/security-patterns.md)
  - Changed files: `src/auth/jwt.js`
  - Last verified: `def456` (1 week ago)
  - No related issue found - [Create tracking issue?]

### Next Steps:

1. Review affected cards for accuracy
2. Update `last_verified_commit` if content still valid
3. Update card content if changes affect documentation
4. Apply `Docs: Ready` when complete

This is a **warning only** and does not block this PR.
```

**Tracking Issue Creation:**

When drift detected for card with no related issue:

```markdown
Title: Documentation drift: jwt-auth-strategy

## Affected Card

[`docs/cards/task/jwt-auth-strategy.md`](../docs/cards/task/jwt-auth-strategy.md)

## Triggering Changes

- Commit: abc123def456
- Changed files:
  - `src/auth/jwt.js` (37 lines changed)
  - `src/middleware/auth-check.js` (12 lines changed)

## Last Verified

- Last verified commit: `xyz789` (5 days ago)
- Card version: 1.0.0

## Action Required

Review card content and either:

1. Update card if changes affect documentation
2. Update `last_verified_commit` if still accurate
3. Apply `Docs: Ready` when complete
4. Apply `Docs: Not-Needed` if card no longer relevant

Labels: Docs: Needed, Type: Docs
```

---

## Implementation Phases

**Phase 1: Path Monitoring**

1. Implement changed file detection (git diff)
2. Implement card scanning (parse all front-matter)
3. Implement path matching logic

**Phase 2: Impact Analysis**

1. Identify affected cards
2. Find related issues
3. Calculate staleness (last_verified_commit age)

**Phase 3: Warning System**

1. Apply labels to existing issues
2. Create tracking issues for orphaned drift
3. Post PR comments with impact summary
4. Ensure warn-only (always exit success)

---

## Related Documentation

- Parent: FEATURE: Token-Efficient Documentation System
- AC1: Doc Card Infrastructure (dependency)
- [LABEL_DESIGN_SPEC.md](./LABEL_DESIGN_SPEC.md) - Docs: label usage

---

## Questions / Open Issues

- Should drift detection run on every commit or only PRs?
- What threshold for "stale" (last_verified_commit age)?
- Should we track drift history (how many times card has drifted)?
- How to handle renames/moves of source files?
- Should we detect deletions of source files?

---

**Created:** 2025-11-11
**Last Updated:** 2025-11-11
