# FEATURE: Token-Efficient Documentation System

**Issue Type:** Feature (Top-level parent)
**Work Type:** Feature (new capability)
**Labels:** `Type: Feature`, `Workflow: Backlog`

---

## Feature Name

Token-Efficient Documentation System

---

## User Outcome

As a **developer** (human or AI agent), I want **precise, minimal documentation snippets** for any given task so that **I can quickly understand concepts, contracts, and strategies within strict token budgets without reading entire guides**.

**Why it matters:**

- AI agents with token constraints can access exactly the documentation they need
- Human developers get focused, relevant information without information overload
- Documentation stays synchronized with code changes through drift detection
- All issues are accessible to AI agents restricted to repository view (no GitHub API access)

---

## Acceptance Criteria

This feature delivers 6 distinct capabilities, each mapped to a Sub-Feature:

- **AC1:** Doc card infrastructure exists with validated metadata schema, storage structure, and linking system
- **AC2:** Tasks map system enables deterministic card selection with budget management
- **AC3:** Issue mirroring system syncs all GitHub issues to `docs/issues_mirror/` for AI agent access
- **AC4:** Drift detection monitors code changes and flags documentation updates (warn-only)
- **AC5:** Single validation CLI tool consolidates all checks (schema, tokens, links, duplicates)
- **AC6:** Helper automations generate bundles, detect duplicates, and provide token budget menus

---

## Success Metrics

**Coverage:**

- ≥90% of public APIs have corresponding doc cards
- 100% of issues mirrored to `docs/issues_mirror/` within 5 minutes of creation/update

**Quality:**

- Token estimates accurate within ±10% of actual
- Zero broken links/anchors in validated cards
- <5% duplicate content across card library

**Performance:**

- Validation CLI completes full repo scan in <30 seconds
- Bundle generation for any task completes in <5 seconds
- Drift detection processes commits in <10 seconds

**Usability:**

- Default task selection stays within 1,200 token budget
- Token budget menu provides clear subtopic choices when budget exceeded
- Warn-only enforcement: zero CI failures from documentation gaps

---

## Dependencies

**Internal:**

- None - all functionality is self-contained within this repository

**External:**

- Node.js v20+ (already required by project)
- `js-yaml` for YAML parsing
- `ajv` for JSON schema validation
- GitHub Actions environment for automation workflows

**Blockers:**

- None identified

---

## Sub-Features

This section will be populated after Sub-Feature issues are created:

- [ ] Sub-Feature #XXX: AC1 - Doc Card Infrastructure
- [ ] Sub-Feature #YYY: AC2 - Tasks Map System
- [ ] Sub-Feature #ZZZ: AC3 - Issue Mirroring System
- [ ] Sub-Feature #AAA: AC4 - Drift Detection System
- [ ] Sub-Feature #BBB: AC5 - Validation CLI Tool
- [ ] Sub-Feature #CCC: AC6 - Helper Automations

---

## Estimated Effort

**L (2-4 weeks)**

**Breakdown by Sub-Feature:**

- AC1 (Doc Card Infrastructure): M (1 week) - Schema, storage, linking
- AC2 (Tasks Map System): S (1-3 days) - Parser and selection engine
- AC3 (Issue Mirroring): S (1-3 days) - Label trigger and sync automation
- AC4 (Drift Detection): M (1 week) - Source path monitoring and impact analysis
- AC5 (Validation CLI): M (1 week) - Consolidate all validation checks
- AC6 (Helper Automations): S (1-3 days) - Bundle generation and utilities

---

## Feature Ready Gate

- [ ] All acceptance criteria defined and specific
- [ ] Success metrics are measurable and objective
- [ ] Dependencies identified and documented
- [ ] Sub-Feature issues created (one per AC)

---

## Implementation Notes

**Key Design Principles:**

1. **Spec First, Implementation Later:** Labels and structure defined upfront (v1.6); automation logic comes in later phases
2. **Warn-Only Gates:** Documentation gaps never block CI; they generate warnings and apply labels
3. **Dual-Optimized:** Serves both human developers (rich cross-linking) and AI agents (strict token budgets)
4. **Issue Mirror vs Doc Cards:** ALL issues mirrored to `docs/issues_mirror/`; only some need additional conceptual doc cards
5. **Commit-Aware:** Drift detection works on both issue-linked and direct commits

**Directory Structure:**

```
docs/
├── cards/                    # Self-contained doc cards
│   ├── quick/               # ~100 words
│   ├── task/                # ~200 words
│   └── deep/                # No limit
├── tasks.map.yaml           # Deterministic card selection
├── issues_mirror/           # Mirrored GitHub issues
└── [existing folders]
```

**Label Usage:**

- `Docs: Needed` - Applied when conceptual documentation required beyond issue mirror
- `Docs: Ready` - Cards written and validated
- `Docs: Ingest-Needed` - Cards ready but bundles not generated
- `Docs: Ingested` - Complete (mirror + cards + bundles)
- `Docs: Not-Needed` - Issue mirror sufficient
- `Docs: Defer` - Acknowledged but postponed
- `Docs: Blocked` - Waiting on decisions

**Implementation Phases:**

- **Phase 1 (This Feature):** Core infrastructure, manual processes
- **Phase 2 (Future):** Intelligent heuristics for automatic `Docs: Needed` detection
- **Phase 3 (Future):** Variant registry for near-duplicate handling

---

## Related Documentation

- [LABEL_DESIGN_SPEC.md](./LABEL_DESIGN_SPEC.md) - v1.6 with Docs: category
- [Token-Efficient Documentation System Specification](./TOKEN_EFFICIENT_DOCS_SPEC.md) - Original spec (to be created)
- [docs/README.md](./docs/README.md) - Documentation directory structure

---

## Questions / Risks

**Questions:**

- Should drift detection create new issues automatically, or just comment on existing PRs?
- What heuristics determine "this needs docs" for intelligent automation (Phase 2)?
- Should bundles be precompiled on every commit, or generated on-demand?

**Risks:**

- **Low:** Token estimation accuracy depends on consistent formatting
- **Medium:** Drift detection may generate false positives initially; tuning required
- **Low:** Near-duplicate detection needs careful threshold tuning to avoid noise

---

**Created:** 2025-11-11
**Last Updated:** 2025-11-11
