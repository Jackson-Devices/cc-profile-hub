# SUB-FEATURE: Helper Automations

**Issue Type:** Sub-Feature
**Parent:** FEATURE: Token-Efficient Documentation System (#TBD)
**Work Type:** Feature (inherited from parent)
**Labels:** `Role: Sub-Feature`, `Type: Feature`, `Workflow: Backlog`

---

## Sub-Feature Name

Helper Automations

---

## Parent Context

**Parent Feature:** Token-Efficient Documentation System

**This Sub-Feature implements:** AC6 - Helper automations generate bundles, detect duplicates, and provide token budget menus

---

## Objective

Provide automated helpers that improve day-to-day usability: precompiled bundles for tasks, near-duplicate detection for maintenance, and interactive token budget menus for overflow scenarios.

**What this delivers:**

- Bundle generator (concatenates cards for tasks)
- Near-duplicate detector (identifies similar cards)
- Token budget menu (interactive subtopic selection)
- Bundle metadata tracking (checksums, commits, tokens)

---

## Scope

**In Scope:**

- Bundle generation from task selections
- Bundle metadata (originating commits, tokens, checksum)
- Near-duplicate detection with similarity scoring
- Token budget menu for overflow handling
- Bundle artifacts under dedicated path (e.g., `docs/bundles/`)

**Out of Scope:**

- Real-time bundle updates (on-demand or scheduled generation)
- Bundle compression/optimization
- Variant registry (deferred to future enhancement)
- Bundle distribution/deployment

---

## Acceptance Criteria

1. Script exists: `scripts/generate-bundles.js`
2. Bundles generated for all tasks in `docs/tasks.map.yaml`
3. Bundle files created in `docs/bundles/{task-id}.md`
4. Bundle metadata includes: task ID, tokens, checksum, originating commits
5. Near-duplicate detection script: `scripts/detect-duplicates.js`
6. Token budget menu function implemented
7. At least one test bundle generated and validated
8. Bundle generation completes in <5 seconds per task

---

## Function Breakdown

This Sub-Feature decomposes into 3 functions:

- [ ] Function #XXX: Card Bundle Generator
- [ ] Function #YYY: Near-Duplicate Detector
- [ ] Function #ZZZ: Token Budget Menu

---

## Success Metrics

**Bundle Generation:**

- All tasks produce valid bundles
- Bundle ordering matches tasks map exactly
- Token counts accurate within ±1%
- Generation time <5 seconds per task

**Duplicate Detection:**

- Detects >80% similar cards
- <5% false positives
- Provides actionable consolidation suggestions

**Budget Menu:**

- Clear subtopic choices when budget exceeded
- Accurate token calculations per subtopic
- Interactive selection works in both CLI and CI contexts

---

## Dependencies

**Requires:**

- AC1 (Doc Card Infrastructure) - card structure
- AC2 (Tasks Map) - task definitions
- AC5 (Validation CLI) - validation integration

**Blocks:**

- None (enhances usability)

---

## Technical Notes

**Bundle Structure:**

```markdown
# Bundle: user-authentication

Generated: 2025-11-11T15:30:00Z
Task: user-authentication
Total Tokens: 1185
Cards: 4
Originating Commits:

- docs/cards/quick/label-taxonomy.md: abc123
- docs/cards/task/jwt-auth-strategy.md: def456
- docs/cards/task/state-machine.md: def456
- docs/cards/deep/security-patterns.md: ghi789
  Checksum: sha256:a1b2c3d4...

---

## <!-- Card 1: quick/label-taxonomy.md -->

id: label-taxonomy
title: Label Taxonomy Quick Reference
level: quick
tokens_estimate: 95

---

[Card content...]

---

## <!-- Card 2: task/jwt-auth-strategy.md -->

id: jwt-auth-strategy
title: JWT Authentication Strategy
level: task
tokens_estimate: 287

---

[Card content...]

[... remaining cards ...]
```

**Bundle Generator Logic:**

```javascript
// Pseudocode
1. Load tasks.map.yaml
2. For each task:
   a. Resolve card sequence
   b. Read card files
   c. Concatenate with separators
   d. Calculate total tokens
   e. Generate metadata
   f. Write bundle file
3. Create bundle index
```

**Near-Duplicate Detection:**

```javascript
// Similarity scoring
function calculateSimilarity(card1, card2) {
  // Use Levenshtein distance or cosine similarity
  // Compare card content (exclude front-matter)
  // Return similarity score 0.0 - 1.0
}

function detectDuplicates(threshold = 0.8) {
  const cards = loadAllCards();
  const pairs = [];

  for (let i = 0; i < cards.length; i++) {
    for (let j = i + 1; j < cards.length; j++) {
      const similarity = calculateSimilarity(cards[i], cards[j]);
      if (similarity >= threshold) {
        pairs.push({
          card1: cards[i].id,
          card2: cards[j].id,
          similarity: similarity,
          suggestion: generateSuggestion(cards[i], cards[j]),
        });
      }
    }
  }

  return pairs;
}
```

**Token Budget Menu:**

```javascript
function generateBudgetMenu(task, selection, budget) {
  const overrun = selection.totalTokens - budget;

  // Group cards by topic
  const subtopics = groupByTopic(selection.cards);

  // Generate menu options
  const options = subtopics.map((topic) => ({
    name: topic.name,
    tokens: topic.totalTokens,
    cards: topic.cards.map((c) => c.id),
  }));

  return {
    overrun: overrun,
    budget: budget,
    actual: selection.totalTokens,
    subtopics: options,
    actions: [
      'Exclude subtopics to fit budget',
      'Accept full bundle',
      'Increase budget for this task',
    ],
  };
}
```

**Bundle Artifacts Structure:**

```
docs/bundles/
├── README.md                           # Bundle system overview
├── index.json                          # Bundle index with metadata
├── user-authentication.md              # Task bundle
├── testing-strategy.md
├── deployment-workflow.md
└── checksums.txt                       # SHA256 checksums for integrity
```

**Bundle Index:**

```json
{
  "generated_at": "2025-11-11T15:30:00Z",
  "generator_version": "1.0.0",
  "bundles": [
    {
      "task_id": "user-authentication",
      "file": "user-authentication.md",
      "tokens": 1185,
      "cards": 4,
      "checksum": "sha256:a1b2c3d4...",
      "within_budget": true
    },
    {
      "task_id": "testing-strategy",
      "file": "testing-strategy.md",
      "tokens": 1450,
      "cards": 5,
      "checksum": "sha256:e5f6g7h8...",
      "within_budget": false,
      "budget_exceeded_by": 250
    }
  ]
}
```

---

## Implementation Phases

**Phase 1: Bundle Generator**

1. Implement card resolution from tasks map
2. Implement card concatenation
3. Generate bundle metadata
4. Write bundle files

**Phase 2: Near-Duplicate Detector**

1. Implement similarity scoring algorithm
2. Implement pairwise comparison
3. Generate consolidation suggestions
4. Integrate with validation CLI

**Phase 3: Token Budget Menu**

1. Implement topic grouping
2. Implement menu generation
3. Add interactive selection (CLI)
4. Add JSON output (programmatic access)

**Phase 4: Integration**

1. Add bundle generation to npm scripts
2. Add duplicate detection to validation
3. Add budget menu to task selection
4. Document usage in README

---

## Related Documentation

- Parent: FEATURE: Token-Efficient Documentation System
- AC2: Tasks Map System (dependency)
- AC5: Validation CLI (integration point)
- [docs/cards/README.md](./docs/cards/README.md) - Card structure

---

## Questions / Open Issues

- Should bundles be regenerated on every commit (CI) or on-demand?
- Where to store bundle artifacts (docs/bundles/ vs separate repo)?
- Should bundles be versioned independently of cards?
- How to handle bundle staleness (cards updated but bundle not regenerated)?
- Should we support bundle fragments (partial bundles for sub-tasks)?

---

**Created:** 2025-11-11
**Last Updated:** 2025-11-11
