# SUB-FEATURE: Validation CLI Tool

**Issue Type:** Sub-Feature
**Parent:** FEATURE: Token-Efficient Documentation System (#TBD)
**Work Type:** Feature (inherited from parent)
**Labels:** `Role: Sub-Feature`, `Type: Feature`, `Workflow: Backlog`

---

## Sub-Feature Name

Validation CLI Tool

---

## Parent Context

**Parent Feature:** Token-Efficient Documentation System

**This Sub-Feature implements:** AC5 - Single validation CLI tool consolidates all checks (schema, tokens, links, duplicates)

---

## Objective

Provide a single, consolidated CLI tool that validates all aspects of the documentation system, avoiding duplication across scripts and ensuring consistency.

**What this delivers:**

- Single command: `npm run validate:docs`
- Comprehensive validation checks in one tool
- Clear, actionable diagnostics
- Warn-only exit status (suitable for CI)
- Local development feedback

---

## Scope

**In Scope:**

- Metadata schema validation (ajv + JSON Schema)
- Token estimate accuracy (±10% tolerance)
- Link and anchor resolution (intra-repo only)
- Tasks map integrity (references exist, no cycles)
- Issue mirror freshness (synced within 24h)
- Near-duplicate detection (similarity threshold)
- Budget simulation (tasks don't exceed budgets)
- Identity checks (unique IDs, no duplicate titles per topic)

**Out of Scope:**

- Content quality assessment (subjective)
- Grammar/spelling checks (use separate linters)
- External link validation (may be unreliable)
- Automated fixes (diagnostic only)

---

## Acceptance Criteria

1. CLI script exists: `scripts/validate-docs.js`
2. npm script defined: `"validate:docs": "node scripts/validate-docs.js"`
3. All 8 validation checks implemented and documented
4. Clear output format with severity levels (error, warning, info)
5. Exit code 0 (warn-only, suitable for CI)
6. Help text and usage examples in `--help`
7. Validates successfully against example cards/tasks
8. Full repo scan completes in <30 seconds

---

## Function Breakdown

This Sub-Feature decomposes into 3 functions:

- [ ] Function #XXX: CLI Argument Parser
- [ ] Function #YYY: Validation Runner
- [ ] Function #ZZZ: Report Generator

---

## Success Metrics

**Performance:**

- Full validation completes in <30 seconds
- Incremental validation (single card) <1 second

**Accuracy:**

- 100% of schema violations caught
- Token drift detection ±1% of actual
- Link resolution 100% accurate for valid paths

**Usability:**

- Clear error messages with file:line references
- Color-coded output (errors red, warnings yellow, info blue)
- Progress indicators for long operations
- JSON output mode for CI integration

---

## Dependencies

**Requires:**

- AC1 (Doc Card Infrastructure) - cards to validate
- AC2 (Tasks Map) - tasks map to validate
- AC3 (Issue Mirroring) - mirrors to check freshness
- Node.js v20+ with ESM
- `js-yaml` for YAML parsing
- `ajv` for JSON Schema validation

**Blocks:**

- None (validation is informational)

---

## Technical Notes

**Validation Checks:**

1. **Metadata Schema**
   - Validate front-matter against JSON Schema
   - Check required fields present
   - Validate enum values (audience, level)
   - Ensure version follows semver

2. **Token Estimates**
   - Recalculate: `(characters / 4) rounded up`
   - Compare to `tokens_estimate` field
   - Warn if drift >±10%

3. **Links and Anchors**
   - Parse markdown links: `[text](path)`, `[text](#anchor)`
   - Verify file paths exist
   - Verify anchors exist in target files
   - Flag broken cross-references

4. **Identity Checks**
   - Ensure card IDs unique across all cards
   - Warn on duplicate titles within same topic
   - Check for conflicting versions

5. **Tasks Map Integrity**
   - Parse `docs/tasks.map.yaml`
   - Verify all card references resolve to files
   - Check for circular task dependencies
   - Validate sequence ordering

6. **Issue Mirror Freshness**
   - Check `last_synced_commit` in mirrors
   - Compare to current HEAD
   - Warn if >24 hours stale

7. **Near-Duplicate Detection**
   - Calculate similarity between cards (Levenshtein distance)
   - Warn if >80% similar
   - Prompt to consolidate or mark as variants

8. **Budget Simulation**
   - For each task, calculate total tokens
   - Compare to `bundle_budget_tokens`
   - Warn if exceeds budget

**CLI Interface:**

```bash
# Run all validations
npm run validate:docs

# Validate specific card
npm run validate:docs -- --card=docs/cards/task/jwt-auth.md

# JSON output for CI
npm run validate:docs -- --format=json

# Specific checks only
npm run validate:docs -- --checks=schema,tokens

# Verbose mode
npm run validate:docs -- --verbose

# Help
npm run validate:docs -- --help
```

**Output Format:**

```
🔍 Validating Documentation System...

[1/8] Metadata Schema........................ ✓ PASS (45 cards)
[2/8] Token Estimates........................ ⚠ WARN (3 cards)
  ├─ docs/cards/task/jwt-auth.md
  │  Expected: 287 tokens, Found: 315 (+9.7%)
  ├─ docs/cards/deep/security.md
  │  Expected: 520 tokens, Found: 580 (+11.5%)
  └─ docs/cards/quick/labels.md
     Expected: 95 tokens, Found: 85 (-10.5%)

[3/8] Links and Anchors...................... ✗ ERROR (2 broken)
  ├─ docs/cards/task/jwt-auth.md:15
  │  Broken link: [Strategy](../deep/auth-strategy.md)
  │  File not found: docs/cards/deep/auth-strategy.md
  └─ docs/cards/deep/testing.md:42
     Broken anchor: [Test Types](#types)
     Anchor not found in: docs/cards/task/test-workflow.md

[4/8] Identity................................ ✓ PASS
[5/8] Tasks Map Integrity.................... ✓ PASS (12 tasks)
[6/8] Issue Mirror Freshness................. ⚠ WARN (5 stale)
[7/8] Near-Duplicates........................ ⓘ INFO (2 pairs)
[8/8] Budget Simulation...................... ✓ PASS (12 tasks)

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
Summary: 2 errors, 8 warnings, 2 info
Completed in 12.4s

⚠️  Warnings do not fail validation (warn-only mode)
```

**Exit Codes:**

- Always `0` (warn-only mode for CI)
- Future: optional `--strict` mode exits 1 on warnings

---

## Implementation Phases

**Phase 1: CLI Framework**

1. Implement argument parsing (--help, --format, --checks)
2. Set up validation framework (runner, reporters)
3. Add progress indicators

**Phase 2: Core Validations**

1. Implement schema validation (ajv)
2. Implement token estimate checker
3. Implement link resolver
4. Implement identity checks

**Phase 3: Advanced Validations**

1. Implement tasks map validator
2. Implement mirror freshness checker
3. Implement near-duplicate detector
4. Implement budget simulator

**Phase 4: Reporting**

1. Implement color-coded console output
2. Implement JSON output mode
3. Add file:line references
4. Add actionable suggestions

---

## Related Documentation

- Parent: FEATURE: Token-Efficient Documentation System
- [TESTING_GUIDE.md](./docs/TESTING_GUIDE.md) - Node.js testing frameworks
- [docs/cards/README.md](./docs/cards/README.md) - Card schema

---

## Questions / Open Issues

- Should validation run automatically on pre-commit hook?
- Do we need a `--fix` mode for auto-corrections?
- Should near-duplicate threshold be configurable?
- How to handle valid duplicates (intentional variants)?
- Should we validate card content length (quick/task/deep limits)?

---

**Created:** 2025-11-11
**Last Updated:** 2025-11-11
