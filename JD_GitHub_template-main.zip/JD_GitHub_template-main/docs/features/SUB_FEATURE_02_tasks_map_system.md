# SUB-FEATURE: Tasks Map System

**Issue Type:** Sub-Feature
**Parent:** FEATURE: Token-Efficient Documentation System (#TBD)
**Work Type:** Feature (inherited from parent)
**Labels:** `Role: Sub-Feature`, `Type: Feature`, `Workflow: Backlog`

---

## Sub-Feature Name

Tasks Map System

---

## Parent Context

**Parent Feature:** Token-Efficient Documentation System

**This Sub-Feature implements:** AC2 - Tasks map system enables deterministic card selection with budget management

---

## Objective

Implement a deterministic, zero-LLM system for selecting and ordering documentation cards for any given task, with strict token budget enforcement and overflow handling.

**What this delivers:**

- YAML-based tasks map defining card sequences per task
- Deterministic card selection (no AI inference required)
- Token budget tracking and enforcement
- Overflow handling with subtopic menus

---

## Scope

**In Scope:**

- `docs/tasks.map.yaml` structure and schema
- Task-to-card mapping with ordered sequences
- Per-task token budget configuration
- Budget overflow detection
- Subtopic menu generation for budget overruns

**Out of Scope:**

- Bundle precompilation (handled in AC6)
- Card content creation
- Validation logic (handled in AC5)

---

## Acceptance Criteria

1. `docs/tasks.map.yaml` file exists with documented schema
2. At least 3 example tasks defined with card sequences
3. Task attributes include: description, audience, bundle_budget_tokens, sequence
4. Sequence supports both card references and optional level suffixes
5. Budget calculation logic documented
6. Overflow handling strategy documented (subtopic menu)

---

## Function Breakdown

This Sub-Feature decomposes into 3 functions:

- [ ] Function #XXX: Tasks Map Parser
- [ ] Function #YYY: Task Selection Engine
- [ ] Function #ZZZ: Budget Management

---

## Success Metrics

**Determinism:**

- Same task always returns same card sequence (zero randomness)
- Ordering strictly preserved from tasks map

**Budget Compliance:**

- Default 1,200 token budget enforced
- Overflow detection accuracy 100%
- Subtopic menu generation works for all card topic combinations

**Usability:**

- Clear error messages when task not found
- Budget overrun provides actionable choices
- Task descriptions help users find appropriate tasks

---

## Dependencies

**Requires:**

- AC1 (Doc Card Infrastructure) - card metadata and structure must exist

**Blocks:**

- AC6 (Helper Automations) - bundle generation uses task selection
- Future precompiled bundles feature

---

## Technical Notes

**Tasks Map Schema (Draft):**

```yaml
# docs/tasks.map.yaml

tasks:
  user-authentication:
    description: 'Implement user authentication with JWT tokens'
    audience: agent # human | agent | both
    bundle_budget_tokens: 1200 # default budget
    sequence:
      - id: quick/label-taxonomy
      - id: task/jwt-auth-strategy
      - id: task/state-machine
        level: task # optional: select specific level variant
      - id: deep/security-patterns
        anchor: '#token-handling' # optional: specific section

  testing-strategy:
    description: 'Design test suite following TDD hierarchy'
    audience: both
    bundle_budget_tokens: 1500
    sequence:
      - id: quick/test-types
      - id: task/tdd-workflow
      - id: deep/test-hierarchy
```

**Budget Calculation:**

1. Sum `tokens_estimate` from all cards in sequence
2. Add front-matter overhead (~50 tokens per card)
3. Compare to `bundle_budget_tokens`

**Overflow Handling:**

When selection exceeds budget:

```
⚠️ Selected cards exceed budget (1450 / 1200 tokens)

Available subtopics:
1. Security (350 tokens) - Include deep/security-patterns
2. Workflow (200 tokens) - Include task/state-machine
3. Quick Reference (100 tokens) - Include quick/label-taxonomy

Choose subtopics to exclude, or:
- Accept full bundle (1450 tokens)
- Increase budget for this task
```

**Selection Engine Logic:**

1. Parse task ID from request
2. Lookup task in tasks.map.yaml
3. Resolve card IDs to file paths
4. Calculate total tokens
5. If under budget: return ordered sequence
6. If over budget: generate subtopic menu

---

## Implementation Phases

**Phase 1: Schema & Parser**

1. Define tasks.map.yaml schema
2. Implement YAML parser
3. Validate structure

**Phase 2: Selection Engine**

1. Implement task lookup
2. Implement card resolution
3. Handle missing cards gracefully

**Phase 3: Budget Management**

1. Implement token calculation
2. Implement overflow detection
3. Implement subtopic menu generation

---

## Related Documentation

- Parent: FEATURE: Token-Efficient Documentation System
- AC1: Doc Card Infrastructure (dependency)
- [docs/cards/README.md](./docs/cards/README.md) - Card structure

---

## Questions / Open Issues

- Should tasks support inheritance (base task + overrides)?
- Do we need task aliases (multiple names for same task)?
- Should budget be per-task or have global defaults with overrides?
- How to handle circular card references in sequences?

---

**Created:** 2025-11-11
**Last Updated:** 2025-11-11
