# SUB-FEATURE: Doc Card Infrastructure

**Issue Type:** Sub-Feature
**Parent:** FEATURE: Token-Efficient Documentation System (#TBD)
**Work Type:** Feature (inherited from parent)
**Labels:** `Role: Sub-Feature`, `Type: Feature`, `Workflow: Backlog`

---

## Sub-Feature Name

Doc Card Infrastructure

---

## Parent Context

**Parent Feature:** Token-Efficient Documentation System

**This Sub-Feature implements:** AC1 - Doc card infrastructure exists with validated metadata schema, storage structure, and linking system

---

## Objective

Establish the foundational infrastructure for self-contained documentation cards with validated metadata, organized storage, and cross-reference linking capabilities.

**What this delivers:**

- Standardized card metadata schema (YAML front-matter)
- Directory structure for cards organized by level (quick/task/deep)
- Card linking system for cross-references
- Token estimation methodology

---

## Scope

**In Scope:**

- Card metadata schema definition (JSON Schema)
- Directory structure: `docs/cards/{quick,task,deep}/`
- Front-matter fields: id, title, topics, audience, level, tokens_estimate, since_commit, last_verified_commit, source_paths, related_tasks, version
- Card authoring guide in `docs/cards/README.md`
- Token estimation heuristic (characters / 4, rounded up)
- Basic linking conventions (markdown links between cards)

**Out of Scope:**

- Validation logic (handled in AC5 - Validation CLI)
- Drift detection (handled in AC4)
- Bundle generation (handled in AC6)
- Actual card content (created on-demand as features are documented)

---

## Acceptance Criteria

1. Card metadata schema defined as JSON Schema
2. Directory structure created: `docs/cards/{quick,task,deep}/`
3. `docs/cards/README.md` exists with:
   - Card authoring guide
   - Metadata field definitions
   - Token estimation methodology
   - Linking conventions
   - Example cards
4. At least 3 example cards created (one per level)
5. Schema validates successfully against example cards

---

## Function Breakdown

This Sub-Feature decomposes into 3 functions:

- [ ] Function #XXX: Card Metadata Schema
- [ ] Function #YYY: Card Storage Structure
- [ ] Function #ZZZ: Card Linking System

---

## Success Metrics

**Schema Quality:**

- All required fields documented
- Enum constraints defined for audience, level
- Validation rules clear and unambiguous

**Documentation Quality:**

- Card authoring guide complete and understandable
- Example cards demonstrate all three levels
- Token estimation methodology documented with examples

**Usability:**

- Developers can author new cards following README without questions
- Schema validation catches common errors

---

## Dependencies

**Requires:**

- None (foundational infrastructure)

**Blocks:**

- AC2 (Tasks Map) - needs card structure to reference
- AC4 (Drift Detection) - needs source_paths field definition
- AC5 (Validation CLI) - needs schema to validate against
- AC6 (Helper Automations) - needs structure for bundle generation

---

## Technical Notes

**Card Metadata Schema (Draft):**

```yaml
# Front-matter fields
id: string (kebab-case, unique)
title: string (concise, human-readable)
topics: array of strings (tags for filtering)
audience: enum [human, agent, both]
level: enum [quick, task, deep]
tokens_estimate: integer (characters / 4, rounded up)
since_commit: string (commit hash when created)
last_verified_commit: string (commit hash when last verified)
source_paths: array of strings (repo paths this card depends on)
related_tasks: array of strings (task IDs from tasks.map.yaml)
version: string (semantic version for card content)
```

**Directory Organization:**

```
docs/cards/
├── README.md                    # Authoring guide
├── quick/
│   ├── label-taxonomy.md       # Example: quick reference
│   └── test-types.md
├── task/
│   ├── jwt-auth-strategy.md    # Example: implementation approach
│   └── state-machine.md
└── deep/
    ├── tdd-philosophy.md        # Example: deep dive
    └── security-patterns.md
```

**Token Estimation:**

- Heuristic: `characters / 4` (rounded up)
- Includes front-matter overhead (~50-100 tokens)
- Validation will flag drift >±10%

**Linking Conventions:**

- Relative markdown links: `[Card Title](../deep/card-name.md)`
- Anchor links: `[Section](#heading-anchor)`
- Task references: `See task: user-authentication` (resolved via tasks.map.yaml)

---

## Implementation Phases

**Phase 1: Schema Definition**

1. Define JSON Schema for card metadata
2. Document required vs optional fields
3. Define enum constraints

**Phase 2: Structure Creation**

1. Create directory structure
2. Write authoring guide README
3. Document token estimation

**Phase 3: Examples**

1. Create example quick card
2. Create example task card
3. Create example deep card
4. Validate schema against examples

---

## Related Documentation

- Parent: FEATURE: Token-Efficient Documentation System
- [LABEL_DESIGN_SPEC.md](./LABEL_DESIGN_SPEC.md) - Documentation label usage
- [docs/README.md](./docs/README.md) - Documentation structure overview

---

## Questions / Open Issues

- Should card IDs follow a specific naming convention (e.g., `domain-concept-name`)?
- Do we need a card index file, or is directory scanning sufficient?
- Should related_tasks be bidirectional (tasks reference cards, cards reference tasks)?

---

**Created:** 2025-11-11
**Last Updated:** 2025-11-11
