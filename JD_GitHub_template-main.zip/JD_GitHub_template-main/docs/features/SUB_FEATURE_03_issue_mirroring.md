# SUB-FEATURE: Issue Mirroring System

**Issue Type:** Sub-Feature
**Parent:** FEATURE: Token-Efficient Documentation System (#TBD)
**Work Type:** Feature (inherited from parent)
**Labels:** `Role: Sub-Feature`, `Type: Feature`, `Workflow: Backlog`

---

## Sub-Feature Name

Issue Mirroring System

---

## Parent Context

**Parent Feature:** Token-Efficient Documentation System

**This Sub-Feature implements:** AC3 - Issue mirroring system syncs all GitHub issues to `docs/issues_mirror/` for AI agent access

---

## Objective

Provide AI agents without GitHub API access the ability to read issue content by mirroring all issues to repository files with structured front-matter and rendered markdown.

**What this delivers:**

- Universal issue mirroring to `docs/issues_mirror/`
- Automatic sync on issue create/update/close
- Structured front-matter (issue metadata)
- Rendered body content in markdown

---

## Scope

**In Scope:**

- Mirror all issues (regardless of type/state) to `docs/issues_mirror/`
- File naming: `{issue-number}-{slugified-title}.md`
- Front-matter: issue ID, title, state, labels, created/updated timestamps, token estimate
- Body: full issue body rendered as markdown
- Automatic sync via GitHub Actions workflow
- Mirror freshness tracking (last_synced_commit)

**Out of Scope:**

- Comments mirroring (future enhancement)
- Pull request mirroring (future enhancement)
- Selective mirroring (all issues are mirrored)
- Real-time sync (acceptable delay: 5 minutes)

---

## Acceptance Criteria

1. `docs/issues_mirror/` directory exists with README explaining purpose
2. GitHub Actions workflow created: `issue-mirror-sync.yml`
3. Workflow triggers on: issues (opened, edited, closed, labeled)
4. Mirror file format documented with example
5. At least one test issue successfully mirrored
6. Sync completes within 5 minutes of issue change

---

## Function Breakdown

This Sub-Feature decomposes into 3 functions:

- [ ] Function #XXX: Mirror Label Trigger
- [ ] Function #YYY: Mirror Sync Automation
- [ ] Function #ZZZ: Mirror Freshness Check

---

## Success Metrics

**Coverage:**

- 100% of issues mirrored (no filtering)
- Mirror files updated within 5 minutes of issue changes

**Accuracy:**

- Front-matter metadata matches GitHub issue exactly
- Body content rendered correctly (preserves formatting)
- Token estimates within ±10% of actual

**Reliability:**

- Zero sync failures for standard issue operations
- Graceful degradation for malformed issue content
- Stale mirrors flagged after 24 hours without sync

---

## Dependencies

**Requires:**

- GitHub Actions environment
- `GITHUB_TOKEN` with issues:read permission

**Blocks:**

- None (independent functionality)
- Enhances: AC1 (Doc Cards) - cards can reference issue mirrors

---

## Technical Notes

**Mirror File Format:**

```markdown
---
issue_number: 42
title: 'Add JWT authentication to login endpoint'
state: open
labels:
  - 'Type: Feature'
  - 'Difficulty: Medium'
  - 'AI: Supervised'
  - 'Workflow: In-Progress'
created_at: '2025-11-11T10:00:00Z'
updated_at: '2025-11-11T14:30:00Z'
last_synced_commit: 'abc123def456'
tokens_estimate: 450
author: username
---

## Feature Name

Add JWT authentication to login endpoint

## User Outcome

As a developer, I want to implement JWT-based authentication...

[Rest of issue body content]
```

**File Naming Convention:**

- Pattern: `{issue-number:03d}-{slugified-title}.md`
- Example: `042-add-jwt-authentication-to-login-endpoint.md`
- Zero-padded to 3 digits for proper sorting
- Title slugified: lowercase, hyphens, no special chars

**Sync Workflow Trigger:**

```yaml
# .github/workflows/issue-mirror-sync.yml
name: Issue Mirror Sync

on:
  issues:
    types: [opened, edited, closed, reopened, labeled, unlabeled]

jobs:
  sync-mirror:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v4
      - name: Sync issue to mirror
        run: node scripts/sync-issue-mirror.js
        env:
          ISSUE_NUMBER: ${{ github.event.issue.number }}
          GITHUB_TOKEN: ${{ secrets.GITHUB_TOKEN }}
```

**Token Estimation:**

- Calculate from front-matter + body content
- Heuristic: `characters / 4` (same as cards)
- Include in front-matter for quick reference

**Mirror README:**

`docs/issues_mirror/README.md` explains:

- Purpose: AI agent access without GitHub API
- Sync frequency: ~5 minutes
- File format and front-matter fields
- How to manually trigger sync
- Staleness threshold: 24 hours

---

## Implementation Phases

**Phase 1: Structure Setup**

1. Create `docs/issues_mirror/` directory
2. Write README explaining purpose
3. Define file format and naming convention

**Phase 2: Sync Script**

1. Implement `scripts/sync-issue-mirror.js`
2. Fetch issue via GitHub API
3. Generate front-matter
4. Render body content
5. Write to mirror file

**Phase 3: Automation**

1. Create GitHub Actions workflow
2. Configure triggers (issue events)
3. Test with example issues
4. Add error handling and logging

---

## Related Documentation

- Parent: FEATURE: Token-Efficient Documentation System
- [docs/README.md](./docs/README.md) - Documentation structure
- [LABEL_DESIGN_SPEC.md](./LABEL_DESIGN_SPEC.md) - Label taxonomy

---

## Questions / Open Issues

- Should closed issues be deleted from mirror or marked as closed?
- Do we need a mirror index file or is directory scanning sufficient?
- Should we mirror PR descriptions as well (future)?
- How to handle very large issues (>10k tokens)?
- Should comments be included (future enhancement)?

---

**Created:** 2025-11-11
**Last Updated:** 2025-11-11
