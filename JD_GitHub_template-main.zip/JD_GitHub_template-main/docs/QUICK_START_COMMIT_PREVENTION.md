# Quick Start: Sequential Commit Prevention

## TL;DR

**One branch = One commit.** If you need to make more changes, create a new branch.

## How It Works

When you try to commit to a branch that already has a commit, you'll be blocked with instructions to create a new branch.

## Installation (Optional Local Check)

```bash
./scripts/install-commit-prevention-hook.sh
```

## Basic Usage

### ✅ Correct: First commit on a branch

```bash
git checkout -b claude/my-feature-abc123
# make changes
git add .
git commit -m "feat: add feature"
git push -u origin claude/my-feature-abc123
```

### ❌ Incorrect: Second commit on same branch

```bash
# Still on claude/my-feature-abc123
git add .
git commit -m "fix: another change"  # ❌ BLOCKED
```

### ✅ Correct: New branch for new changes

```bash
# Save your work
git stash

# Create new branch
git checkout -b claude/my-other-feature-def456

# Apply your changes
git stash pop

# Commit on new branch
git add .
git commit -m "fix: another change"  # ✅ ALLOWED
git push -u origin claude/my-other-feature-def456
```

## Why?

- Keeps PRs focused and reviewable
- Separates concerns
- Makes rollbacks easier
- Cleaner git history

## More Info

See [SEQUENTIAL_COMMIT_PREVENTION.md](./SEQUENTIAL_COMMIT_PREVENTION.md) for complete documentation.
