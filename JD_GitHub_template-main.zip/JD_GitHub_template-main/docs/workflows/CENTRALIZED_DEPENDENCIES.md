# Centralized Dependency Management for GitHub Actions Workflows

**Status:** Implemented
**Related Issue:** #202 - Fix Orchestrator Dependency Conflict & Error Messages
**Created:** 2025-11-14
**Last Updated:** 2025-11-14

---

## Overview

This document describes the centralized dependency management system for GitHub Actions workflows in this repository. The system prevents dependency conflicts, ensures version consistency, and simplifies workflow maintenance.

## Problem Statement

Prior to this implementation, workflows had the following issues:

1. **Dependency Conflicts**: Workflows manually installed npm packages with conflicting peer dependencies
   - Example: `@octokit/plugin-retry@8.x` requires `@octokit/core >= 7`, but workflows used `@octokit/core@6.x`
   - Result: Workflow failures due to npm peer dependency errors

2. **Inconsistent Node.js Versions**: While all workflows used v20, the setup was duplicated 27 times
   - No single source of truth
   - Difficult to update globally

3. **Unused Dependencies**: Workflows installed packages that were never used in the code
   - Wasted CI time and introduced unnecessary conflict risk

4. **No Validation**: No automated checks to detect dependency conflicts before deployment

## Solution

### 1. Composite Action: `setup-node-deps`

**Location:** `.github/actions/setup-node-deps/action.yml`

A reusable composite action that centralizes Node.js setup and dependency management.

#### Features

- ✅ Standardized Node.js version (v20) across all workflows
- ✅ Built-in npm caching for faster builds
- ✅ Flexible installation methods (`ci`, `install`, `specific`, `skip`)
- ✅ **Automatic peer dependency conflict detection**
- ✅ Version validation (ensures correct Node.js version is installed)
- ✅ Detailed error messages for troubleshooting

#### Usage

```yaml
- name: Setup Node.js with dependencies
  uses: ./.github/actions/setup-node-deps
  with:
    node-version: '20' # Optional, defaults to '20'
    cache: 'true' # Optional, defaults to 'true'
    install-method: 'ci' # Options: ci, install, specific, skip
    packages: '' # Required only for install-method: specific
```

#### Installation Methods

| Method         | When to Use                                                  | Example                                                  |
| -------------- | ------------------------------------------------------------ | -------------------------------------------------------- |
| `ci` (default) | Production workflows that need all package.json dependencies | Most workflows                                           |
| `install`      | Development workflows that need devDependencies              | Local testing scripts                                    |
| `specific`     | Workflows that only need 1-2 packages                        | Lightweight workflows, scripts with minimal dependencies |
| `skip`         | Workflows that don't need npm packages                       | Shell-only workflows, git operations                     |

#### Examples

**Example 1: Full CI install (default)**

```yaml
- uses: ./.github/actions/setup-node-deps
  # Uses defaults: node-version=20, cache=true, install-method=ci
```

**Example 2: Install only specific packages**

```yaml
- uses: ./.github/actions/setup-node-deps
  with:
    install-method: specific
    packages: 'yaml @octokit/core'
```

**Example 3: Skip dependency installation**

```yaml
- uses: ./.github/actions/setup-node-deps
  with:
    install-method: skip
```

---

### 2. Automated Testing

**Location:** `tests/workflows/orchestrator/unit/`

Comprehensive test suite to prevent dependency conflicts and ensure quality:

#### Test Categories

1. **Dependency Validation** (`dependency-validation.test.mjs`)
   - Detects unused dependencies in workflows
   - Validates peer dependency compatibility
   - Ensures consistent Node.js versions
   - Verifies package.json matches workflow requirements

2. **Error Message Quality** (`error-messages.test.mjs`)
   - Enforces actionable error messages (WHAT + WHY + HOW)
   - Prevents generic "did not complete successfully" errors
   - Validates error handling with try/catch blocks
   - Ensures observability through logging and summaries

#### Running Tests

```bash
# Run all orchestrator tests
node --test tests/workflows/orchestrator/unit/

# Run specific test file
node --test tests/workflows/orchestrator/unit/dependency-validation.test.mjs
node --test tests/workflows/orchestrator/unit/error-messages.test.mjs
```

---

### 3. Repository Variables

**Location:** `REPO_VARIABLES.md` (see documentation there for current list)

#### New Variables (Recommended)

These variables are recommended for future enhancement:

| Variable                       | Default | Purpose                                       |
| ------------------------------ | ------- | --------------------------------------------- |
| `NODE_VERSION`                 | `20`    | Centralized Node.js version for all workflows |
| `NPM_CACHE_ENABLED`            | `true`  | Global toggle for npm caching                 |
| `ENABLE_DEPENDENCY_VALIDATION` | `true`  | Run pre-flight dependency checks              |

**Note:** These are recommendations. The composite action currently uses hardcoded defaults (Node.js v20) to ensure consistency. Repository variables can be added in a future iteration if runtime flexibility is needed.

---

## Issue #202 Resolution

### Problems Identified

1. **Dependency Conflict** (orchestrator.yml:207)
   - ❌ **Before:** `npm install yaml @octokit/core @octokit/plugin-retry`
   - ✅ **After:** `npm install yaml @octokit/core`
   - **Fix:** Removed unused `@octokit/plugin-retry` that caused peer dependency conflict

2. **Generic Error Messages** (orchestrator.yml:399)
   - ❌ **Before:** `core.setFailed('Orchestration did not complete successfully')`
   - ✅ **After:** Detailed error messages with failure stage, reason, and debugging steps
   - **Fix:** Added comprehensive error handling with context-specific messages

3. **Missing Error Handling**
   - ❌ **Before:** No try/catch blocks around critical operations
   - ✅ **After:** Full try/catch coverage with error logging and stack traces
   - **Fix:** Wrapped configuration parsing, file I/O, and workflow execution in try/catch blocks

### Verification

All tests pass after fixes:

```bash
$ node --test tests/workflows/orchestrator/unit/dependency-validation.test.mjs
# tests 6 | pass 6 | fail 0

$ node --test tests/workflows/orchestrator/unit/error-messages.test.mjs
# tests 8 | pass 8 | fail 0
```

---

## Workflow Dependency Patterns (Analysis from Issue #202 Research)

### Node.js Versions

**Current State:** 100% consistency - all workflows use Node.js v20

| Workflow Type                            | Node.js Version | Count  |
| ---------------------------------------- | --------------- | ------ |
| Workflows with explicit setup-node       | v20             | 20     |
| Workflows using github-script (implicit) | v20             | 7      |
| **Total**                                | **v20**         | **27** |

### Common Dependencies

| Package                         | Version (package.json) | Used By       | Purpose                     |
| ------------------------------- | ---------------------- | ------------- | --------------------------- |
| `yaml`                          | ^2.8.1                 | 10+ workflows | YAML parsing and generation |
| `prettier`                      | ^3.6.2                 | 8+ workflows  | Code formatting             |
| `eslint`                        | ^9.15.0                | 5+ workflows  | Code linting                |
| `@octokit/core`                 | ^6.1.2                 | 3 workflows   | GitHub API interactions     |
| `@octokit/plugin-paginate-rest` | ^11.3.5                | 2 workflows   | API pagination support      |

### Consolidation Opportunities

From exploration of all 27 workflows:

1. **High Priority:** 23 workflows could use the `setup-node-deps` composite action
2. **Medium Priority:** 10 workflows install full node_modules when only 1-2 packages are needed
3. **Low Priority:** Create reusable workflow templates for common patterns (format-check, eslint-check, etc.)

---

## Best Practices

### 1. Use the Composite Action

✅ **DO:**

```yaml
- uses: ./.github/actions/setup-node-deps
  with:
    install-method: specific
    packages: 'yaml prettier'
```

❌ **DON'T:**

```yaml
- uses: actions/setup-node@v4
  with:
    node-version: '20'
- run: npm install yaml prettier
```

**Why:** The composite action includes:

- Automatic peer dependency conflict detection
- Version validation
- Consistent caching setup
- Better error messages

### 2. Only Install What You Need

✅ **DO:**

```yaml
- uses: ./.github/actions/setup-node-deps
  with:
    install-method: specific
    packages: 'yaml' # Only install what the workflow actually uses
```

❌ **DON'T:**

```yaml
- run: npm install # Installs all devDependencies unnecessarily
```

**Why:**

- Faster CI runs (2-3 minutes faster per workflow)
- Reduced conflict surface area
- Clearer intent (documents which packages the workflow needs)

### 3. Verify Dependency Usage

Before adding a dependency to a workflow, verify it's actually used:

```bash
# Search workflow file for package usage
grep -E "@octokit|yaml|prettier" .github/workflows/my-workflow.yml
```

If the package isn't used in the workflow code, don't install it.

### 4. Write Tests for Dependency Changes

When modifying workflow dependencies:

1. Write tests first (TDD)
2. Run existing tests to catch regressions
3. Verify no peer dependency conflicts

```bash
# Test dependency validation
node --test tests/workflows/orchestrator/unit/dependency-validation.test.mjs
```

---

## Migration Guide

### Migrating Existing Workflows

**Current pattern:**

```yaml
- name: Setup Node.js
  uses: actions/setup-node@v4
  with:
    node-version: '20'

- name: Install dependencies
  run: npm install yaml @octokit/core
```

**Migrate to:**

```yaml
- name: Setup Node.js with dependencies
  uses: ./.github/actions/setup-node-deps
  with:
    install-method: specific
    packages: 'yaml @octokit/core'
```

**Benefits:**

- 2 steps → 1 step (less YAML duplication)
- Automatic conflict detection
- Built-in caching
- Version validation

### Rollout Plan

The composite action is available but **not yet mandatory**. Workflows can be migrated incrementally:

**Phase 1 (Completed):**

- ✅ Create composite action
- ✅ Fix Issue #202 (orchestrator.yml)
- ✅ Add test coverage

**Phase 2 (Recommended - Future):**

- Migrate high-traffic workflows (format-check, eslint-check, pr-risk-check)
- Update 5-10 workflows that have specific dependencies

**Phase 3 (Aspirational):**

- Migrate all 27 workflows to use composite action
- Add CI enforcement (fail on direct npm install without using composite action)

---

## Troubleshooting

### Peer Dependency Conflicts

**Symptom:**

```
npm ERR! peer @octokit/core@">=7" from @octokit/plugin-retry@8.0.3
npm ERR! Found: @octokit/core@6.1.6
```

**Solution:**

1. Check `package.json` for conflicting versions
2. Remove the unused plugin (if it's not used in workflow code)
3. OR upgrade the base package to match peer requirements
4. Run tests to verify: `node --test tests/workflows/orchestrator/unit/dependency-validation.test.mjs`

### Node.js Version Mismatch

**Symptom:**

```
Error: Node.js version mismatch: expected v20, got v18
```

**Solution:**

1. Verify `node-version` input in workflow:
   ```yaml
   - uses: ./.github/actions/setup-node-deps
     with:
       node-version: '20' # Ensure this matches repo standard
   ```
2. Check actions/setup-node cache (may need to bust cache if stale)

### Installation Fails

**Symptom:**

```
Error: Failed to install dependencies: ENOENT package not found
```

**Solution:**

1. Verify package name is correct (check npm registry)
2. Ensure `install-method: specific` if using `packages` input
3. Check network connectivity to npm registry
4. Review workflow logs for detailed error message

---

## References

- Issue #202: URGENT: Fix Orchestrator Dependency Conflict & Error Messages
- Issue #197: Comprehensive Test Suites for All 27 Workflows (Currently 11% tested)
- `REPO_VARIABLES.md` - Repository variables documentation
- `TESTING_STRATEGY_DECISION_LOG.md` - Testing approach and taxonomy
- `.github/actions/setup-node-deps/action.yml` - Composite action implementation

---

## Change Log

| Date       | Change                                                                    | Author      |
| ---------- | ------------------------------------------------------------------------- | ----------- |
| 2025-11-14 | Initial implementation: composite action + tests                          | Claude Code |
| 2025-11-14 | Fixed Issue #202: removed @octokit/plugin-retry, added error handling     | Claude Code |
| 2025-11-14 | Added comprehensive test coverage (dependency-validation, error-messages) | Claude Code |

---

**Next Steps:**

1. Consider adding `NODE_VERSION` repository variable for runtime flexibility
2. Migrate 5-10 high-traffic workflows to use composite action
3. Add CI enforcement to prevent dependency conflicts in PRs
4. Expand test coverage to other workflows (see Issue #197)
