# Workflow Validation Guide

**Status:** Active
**Created:** 2025-11-14
**Last Updated:** 2025-11-14

---

## Overview

This guide describes the centralized workflow validation system for ensuring consistency, security, and reliability across all 27 GitHub Actions workflows in this repository.

## Quick Start

```bash
# Validate all workflows for dependency conflicts
npm run validate:dependencies

# Validate all workflows for permission issues
npm run validate:permissions

# Run both validations
npm run validate:workflows
```

---

## Validation Tools

### 1. Dependency Validation

**Script:** `.github/scripts/validation/check-dependencies.mjs`

#### What It Checks

- ✅ **Peer dependency conflicts** - Detects incompatible package versions (e.g., @octokit/core@6.x with @octokit/plugin-retry@8.x)
- ✅ **Unused dependencies** - Finds packages installed but not used in workflow code
- ✅ **Node.js version consistency** - Ensures all workflows use the same Node.js version (v20)
- ✅ **Package.json compatibility** - Verifies workflow dependencies match package.json

#### Usage

```bash
# Check all workflows
node .github/scripts/validation/check-dependencies.mjs --all

# Check specific workflow
node .github/scripts/validation/check-dependencies.mjs .github/workflows/orchestrator.yml

# Via npm script
npm run validate:dependencies
```

#### Example Output

```
🔍 Checking orchestrator.yml...

============================================================
📊 DEPENDENCY VALIDATION RESULTS
============================================================

✅ Workflows checked: 27

⚠️  Warnings (2):
  - apply_settings.yml: Package "@octokit/plugin-paginate-rest" may not be used in workflow

❌ Errors (1):
  - orchestrator.yml: Dependency conflict detected in "npm install @octokit/plugin-retry"
  Reason: @octokit/plugin-retry@8.x requires @octokit/core >= 7
  Fix: Remove @octokit/plugin-retry or upgrade @octokit/core to v7
```

#### Exit Codes

- `0` - All checks passed
- `1` - Validation errors found
- `2` - Script error (missing files, parse errors)

---

### 2. Permission Validation

**Script:** `.github/scripts/validation/check-permissions.mjs`

#### What It Checks

- ✅ **Missing required permissions** - Validates workflows have necessary permissions
- ✅ **Least-privilege principle** - Detects overly-permissive workflows
- ✅ **Dangerous combinations** - Finds risky permission sets (e.g., `contents: write` + `actions: write`)
- ✅ **Permission usage statistics** - Shows which permissions are most commonly used

#### Usage

```bash
# Check all workflows
node .github/scripts/validation/check-permissions.mjs --all

# Check specific workflow
node .github/scripts/validation/check-permissions.mjs .github/workflows/orchestrator.yml

# Via npm script
npm run validate:permissions
```

#### Example Output

```
🔍 Checking orchestrator.yml...

============================================================
🔒 PERMISSION VALIDATION RESULTS
============================================================

✅ Workflows checked: 27

📊 Permission Usage Statistics:
  contents: write                → 18 workflow(s)
  issues: write                  → 10 workflow(s)
  contents: read                 → 6 workflow(s)

⚠️  Warnings (4):
  - eslint-check.yml: No workflow-level permissions defined

❌ Errors (2):
  - format-check.yml: Missing required permission "contents: read"
```

---

## Common Issues & Fixes

### Issue 1: Peer Dependency Conflict

**Error:**

```
orchestrator.yml: Dependency conflict detected
Reason: @octokit/plugin-retry@8.x requires @octokit/core >= 7
```

**Fix Options:**

**Option A: Remove unused plugin (recommended)**

```yaml
# Before
- run: npm install yaml @octokit/core @octokit/plugin-retry

# After
- run: npm install yaml @octokit/core
```

**Option B: Upgrade core package**

```json
// package.json
{
  "devDependencies": {
    "@octokit/core": "^7.0.0" // Upgrade from 6.x to 7.x
  }
}
```

---

### Issue 2: Missing Permissions

**Error:**

```
format-check.yml: Missing required permission "contents: read"
```

**Fix:**

```yaml
# Add to workflow file
permissions:
  contents: read
```

**Why:** Workflows need explicit permissions to access repository content, even for read-only operations.

---

### Issue 3: Unused Dependencies

**Warning:**

```
apply_settings.yml: Package "@octokit/plugin-paginate-rest" may not be used
```

**Fix Options:**

**Option A: Verify usage** - Check if package is actually used:

```bash
grep -r "plugin-paginate-rest" .github/workflows/apply_settings.yml
```

**Option B: Remove if unused:**

```yaml
# Before
- run: npm install yaml @octokit/core @octokit/plugin-paginate-rest

# After (if plugin-paginate-rest not used)
- run: npm install yaml @octokit/core
```

---

### Issue 4: Node.js Version Mismatch

**Error:**

```
validate-issue.yml: Node.js version 18 does not match repo standard (20)
```

**Fix:**

```yaml
# Update in workflow file
- uses: actions/setup-node@v4
  with:
    node-version: '20' # Changed from '18'
```

**Why:** Repo standard is Node.js v20 (see `REPO_VARIABLES.md`)

---

## Integration with CI

### Pre-Commit Hook (Recommended)

Add to `.husky/pre-commit` or similar:

```bash
#!/bin/sh
npm run validate:workflows || {
  echo "❌ Workflow validation failed"
  echo "Run 'npm run validate:workflows' to see errors"
  exit 1
}
```

### GitHub Actions Workflow

Create `.github/workflows/validate-workflows.yml`:

```yaml
name: Validate Workflows

on:
  pull_request:
    paths:
      - '.github/workflows/**'
      - 'package.json'
      - 'package-lock.json'

permissions:
  contents: read

jobs:
  validate:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v4

      - uses: ./.github/actions/setup-node-deps
        with:
          install-method: ci

      - name: Validate dependencies
        run: npm run validate:dependencies

      - name: Validate permissions
        run: npm run validate:permissions
```

---

## Validation Rules Reference

### Dependency Rules

| Rule                     | Severity | Description                             |
| ------------------------ | -------- | --------------------------------------- |
| Peer dependency conflict | Error    | Incompatible package versions           |
| Unused dependency        | Warning  | Package installed but not used          |
| Node.js version mismatch | Error    | Workflow uses different Node.js version |
| Unrecognized package     | Warning  | Package not in allowed list             |

### Permission Rules

| Rule                        | Severity      | Description                               |
| --------------------------- | ------------- | ----------------------------------------- |
| Missing required permission | Error         | Workflow needs permission it doesn't have |
| No permissions defined      | Warning       | Should explicitly set permissions         |
| Dangerous combination       | Error/Warning | Risky permission set detected             |
| Overly permissive           | Warning       | More write permissions than typical       |

---

## Allowed Packages

The following npm packages are recognized by the dependency validator:

**Core Packages:**

- `yaml` - YAML parsing and generation
- `prettier` - Code formatting
- `eslint` - Code linting
- `@octokit/core` - GitHub API interactions
- `@octokit/plugin-paginate-rest` - API pagination support

**Utility Packages:**

- `js-yaml` - YAML parsing with validation
- `ajv` - JSON Schema validation
- `execa` - Execute external processes

**Not Allowed (Known Conflicts):**

- `@octokit/plugin-retry@8.x` - Conflicts with `@octokit/core@6.x`

To add a package to the allowed list, update `.github/scripts/validation/check-dependencies.mjs` and document the reason.

---

## Required Permissions by Workflow Type

| Workflow Type      | Required Permissions                                                        |
| ------------------ | --------------------------------------------------------------------------- |
| Read-only checks   | `contents: read`, `pull-requests: read` (if checking PRs)                   |
| Auto-fix workflows | `contents: write`                                                           |
| Issue validators   | `issues: write`, `contents: write`                                          |
| PR managers        | `pull-requests: write`, `contents: read`                                    |
| Orchestrators      | `contents: write`, `issues: write`, `pull-requests: write`, `actions: read` |

See `.github/scripts/validation/check-permissions.mjs` for complete mapping.

---

## Best Practices

### 1. Run Validation Before Committing

```bash
# Before committing workflow changes
npm run validate:workflows

# If errors found, fix them before committing
git add .github/workflows/
git commit -m "fix: resolve workflow validation errors"
```

### 2. Use Composite Actions

Instead of duplicating Node.js setup:

```yaml
# ❌ Don't repeat setup across workflows
- uses: actions/setup-node@v4
  with:
    node-version: '20'
- run: npm install yaml @octokit/core

# ✅ Use centralized composite action
- uses: ./.github/actions/setup-node-deps
  with:
    install-method: specific
    packages: 'yaml @octokit/core'
```

**Benefits:**

- Automatic dependency conflict detection
- Consistent Node.js version
- Built-in caching
- Reduced duplication

### 3. Document Unusual Permissions

If a workflow needs unusual permissions, document why:

```yaml
permissions:
  actions: write # Required to cancel in-progress workflow runs
  contents: write
```

### 4. Validate After Dependency Updates

```bash
# After updating package.json
npm install
npm run validate:workflows

# Check for new conflicts
git diff package-lock.json
```

---

## Troubleshooting

### Validation Script Fails to Run

**Problem:** Script doesn't execute or shows "command not found"

**Solution:**

```bash
# Make scripts executable
chmod +x .github/scripts/validation/*.mjs

# Or run with node explicitly
node .github/scripts/validation/check-dependencies.mjs --all
```

### False Positives

**Problem:** Validator reports a package as unused, but it is used

**Solution:**

- Check if package is loaded dynamically (e.g., via `require()` in template string)
- Update validator's usage detection patterns
- Document the exception in the script

### Script Parse Errors

**Problem:** "Failed to parse YAML" error

**Solution:**

```bash
# Validate YAML syntax
yamllint .github/workflows/problematic-workflow.yml

# Or use online validator
cat .github/workflows/problematic-workflow.yml | pbcopy
# Paste at https://www.yamllint.com/
```

---

## Advanced Usage

### Custom Validation Rules

To add custom validation rules, edit the validation scripts:

```javascript
// .github/scripts/validation/check-dependencies.mjs

// Add new conflict pattern
const CONFLICTING_PACKAGES = [
  {
    packages: ['package-a@2', 'package-b@3'],
    reason: 'Reason for conflict',
    fix: 'How to fix it',
  },
];
```

### Filtering Output

```bash
# Show only errors (no warnings)
npm run validate:dependencies 2>&1 | grep "❌"

# Save report to file
npm run validate:workflows > validation-report.txt 2>&1
```

### CI Integration with Status Checks

```yaml
# In GitHub Actions workflow
- name: Validate workflows
  id: validate
  run: npm run validate:workflows
  continue-on-error: true

- name: Report status
  if: steps.validate.outcome == 'failure'
  run: |
    echo "::error::Workflow validation failed"
    exit 1
```

---

## Related Documentation

- **Repository Variables:** `REPO_VARIABLES.md`
- **Centralized Dependencies:** `docs/workflows/CENTRALIZED_DEPENDENCIES.md`
- **Composite Actions:** `.github/actions/setup-node-deps/action.yml`
- **Testing Strategy:** `TESTING_STRATEGY_DECISION_LOG.md`

---

## Change Log

| Date       | Change                                     | Author      |
| ---------- | ------------------------------------------ | ----------- |
| 2025-11-14 | Initial workflow validation system         | Claude Code |
| 2025-11-14 | Added dependency and permission validators | Claude Code |
| 2025-11-14 | Integrated validation into npm scripts     | Claude Code |

---

## Feedback

Found a bug or have a suggestion?

1. Run validation with `--verbose` flag (if available)
2. Check related documentation above
3. Open an issue with the `tooling` label
