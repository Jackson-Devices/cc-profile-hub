# Test Workflow System - Detailed Documentation

**Purpose:** Comprehensive technical documentation for the three-workflow test validation and execution system.

**Audience:** Developers, AI contributors, workflow maintainers

**Related Files:**

- `.github/workflows/validate-issue.yml` - Format validation
- `.github/workflows/enforce_test_gate.yml` - IB/OOB gate enforcement
- `.github/workflows/seed-test-runlist.yml` - Run checklist generation

---

## Overview

The test workflow system consists of three coordinated workflows that enforce test quality through automated validation, gate enforcement, and execution ordering:

```
validate-issue.yml       →  Validates format, sections, IB/OOB naming
         ↓
enforce_test_gate.yml    →  Enforces IB/OOB minimums, blocks invalid tests
         ↓
seed-test-runlist.yml    →  Generates ordered run checklist (OOB → IB → OOB)
```

**State Machine:** All workflows respect a three-state validation system:

```
blocked → pending → passed
   ↑         ↑         ↑
   |         |         |
   |         |         └─ All validations passed, gate checked
   |         └─────────── Format valid, requirements met, gate unchecked
   └─────────────────── Validation errors present
```

**Key Design Principles:**

1. **Atomic validation** - Single decision point prevents race conditions
2. **Fail-fast feedback** - Post detailed error messages immediately
3. **State-driven execution** - Workflows only run in `pending` or `passed` states
4. **Concurrency protection** - Prevent parallel runs on same issue

---

## Configuration Variables

All three workflows reference configurable repository variables:

| Variable           | Default | Purpose                                   |
| ------------------ | ------- | ----------------------------------------- |
| `IB_MIN_REQUIRED`  | `1`     | Minimum In-Bounds test cases required     |
| `OOB_MIN_REQUIRED` | `2`     | Minimum Out-of-Bounds test cases required |

**Setting variables:**

```bash
# Repository Settings → Secrets and variables → Actions → Variables
IB_MIN_REQUIRED=1
OOB_MIN_REQUIRED=2
```

---

## 1. Validate Issue Format (`validate-issue.yml`)

**Purpose:** Comprehensive format validation for `type: test` issues

**Triggers:**

- Manual: `/validate` comment on issue
- Automatic: Issue opened or edited (if `type: test` label present)

**Permissions:** `issues: write`

**Concurrency:**

```yaml
concurrency:
  group: validate-issue-${{ github.event.issue.number }}
  cancel-in-progress: false
```

- One validation run per issue at a time
- Subsequent runs wait (not cancelled) to preserve all validation attempts
- Prevents race conditions when multiple edits occur rapidly

### Validation Steps

The workflow performs 9 validation categories in sequence:

#### 1. Issue Body Not Empty

```javascript
if (!body || body.trim() === '') {
  errors.push('❌ Issue body is empty');
  // Early exit - no further validation possible
}
```

#### 2. Required Sections Present

Validates all required sections from the `test.yml` template:

| Section                                | Min Length | Notes                                 |
| -------------------------------------- | ---------- | ------------------------------------- |
| Test ID                                | 4 chars    | Must match `T-XXX` format (3+ digits) |
| Suite (c1) Issue URL                   | 10 chars   | Can be `_No response_`                |
| Parent feature/bug (p) URL             | 10 chars   | Can be `_No response_`                |
| Purpose                                | 20 chars   | Meaningful explanation required       |
| In-Bounds Case(s) (IB≥1)               | 30 chars   | Must contain structured IB cases      |
| Out-of-Bounds Case(s) (OOB≥2 required) | 30 chars   | Must contain structured OOB cases     |
| Expected Behavior (authoritative)      | 20 chars   | Reference documentation               |
| Validation Method                      | 20 chars   | How to verify correctness             |
| Validation Gate                        | 10 chars   | Must contain gate checkbox            |

**Rejection criteria:**

- Section missing entirely
- Section present but empty
- Section contains only `_No response_` placeholder
- Section content shorter than minimum length

#### 3. Test ID Format

```javascript
const testIdPattern = /^T-\d{3,}$/; // T-XXX where XXX is 3+ digits

// Valid examples:
// - T-001
// - T-042
// - T-123
// - T-1000

// Invalid examples:
// - T-1 (too short, need 3+ digits)
// - T-AB (not numeric)
// - TEST-001 (wrong prefix)
```

#### 4. IB/OOB Test Case Format

**Regex patterns:**

```javascript
const ibRegex = /(^|\n)\s*-\s*(IB-(0[1-9]|[1-9][0-9]))\b/gi;
const oobRegex = /(^|\n)\s*-\s*(OOB-(0[1-9]|[1-9][0-9]))\b/gi;
```

**Valid formats:**

- `IB-01` through `IB-99` (leading zero for 01-09)
- `OOB-01` through `OOB-99` (leading zero for 01-09)

**Invalid formats detected:**

```javascript
const invalidIBPattern = /(^|\n)\s*-\s*(IB-(?:0|[1-9](?![0-9])|[0-9]{3,}))\b/gi;
const invalidOOBPattern = /(^|\n)\s*-\s*(OOB-(?:0|[1-9](?![0-9])|[0-9]{3,}))\b/gi;

// Invalid examples:
// - IB-0 (need 01-99)
// - IB-1 (missing leading zero, should be IB-01)
// - IB-001 (too many digits, use IB-01)
// - IB-100 (exceeds 99 limit)
```

**Count validation:**

```javascript
if (IB.length < IB_MIN) {
  errors.push(`❌ Insufficient IB cases: found ${IB.length}, need ≥${IB_MIN}`);
}

if (OOB.length < OOB_MIN) {
  errors.push(`❌ Insufficient OOB cases: found ${OOB.length}, need ≥${OOB_MIN}`);
}
```

#### 5. IB/OOB Case Markdown Structure

Each case is validated for proper structure:

**Expected format:**

```markdown
- IB-01: Brief description of test case
  - **Input(s):** What's being tested
  - **Steps:** How to run the test
  - **Expected:** What should happen
```

**Validation rules:**

```javascript
function validateCaseStructure(caseId, sectionName) {
  // Extract case description (text after colon)
  const description = match[1].trim();

  if (!description || description.length < 10) {
    warnings.push(`⚠️ ${caseId}: Description is too short or missing`);
  }

  // Check for indented sub-bullets
  const hasSubBullets = /\n\s{2,}-\s+/.test(details);

  if (!hasSubBullets && details.length < 20) {
    warnings.push(`⚠️ ${caseId}: Missing detailed structure. Expected indented sub-bullets`);
  }
}
```

**Note:** These are warnings, not errors (validation still passes)

#### 6. Validation Gate Checkbox

```javascript
const gatePattern = /- \[( |x)\]\s*✅?\s*test\.validated\s*=\s*true/i;

// Valid formats:
// - [ ] ✅ test.validated = true
// - [x] ✅ test.validated = true
// - [ ] test.validated = true (emoji optional)
```

#### 7. Parent/Suite Issue References

**Suite issue validation:**

````javascript
if (suiteUrlMatch && suiteUrlMatch[1] && suiteUrlMatch[1].trim() !== '_No response_') {
  const suiteUrl = suiteUrlMatch[1].trim();
  const suiteBody = await fetchIssueBody(suiteUrl);

  if (suiteBody === null) {
    errors.push(`❌ Suite issue not accessible or invalid URL: ${suiteUrl}`);
  } else {
    // Check for YAML context block
    const yamlBlockMatch = suiteBody.match(/```yaml[\r\n]+([\s\S]*?)```/i);

    if (yamlBlockMatch) {
      try {
        const parsedYaml = YAML.load(yamlBlockMatch[1]);
        // Valid YAML required
      } catch (err) {
        errors.push(`❌ Suite issue contains invalid YAML: ${err.message}`);
      }
    } else {
      errors.push('❌ Suite issue does not contain a YAML context block');
    }
  }
}
````

**Parent issue validation:**

- Checks accessibility only
- No YAML requirement

#### 8. Context References (Advanced)

Validates any `hier_parent:` references in YAML blocks:

```javascript
const contextReferences = body.match(/hier_parent:\s*(https?:\/\/\S+)/g) || [];

for (const ref of contextReferences) {
  const refBody = await fetchIssueBody(refUrl);
  if (refBody === null) {
    errors.push(`❌ Context-referenced issue not accessible: ${refUrl}`);
  }
}
```

### Label Updates

**On validation failure:**

```javascript
await setLabels(
  ['validation: blocked'], // Add
  ['validation: pending', 'validation: passed'] // Remove
);
```

**On validation success:**

```javascript
await setLabels(
  ['validation: pending'], // Add
  ['validation: blocked'] // Remove
);
```

**Note:** Validation success sets `pending`, not `passed`. The `passed` state is set by `enforce_test_gate.yml` when the validation gate is checked.

### Outputs for Decision Logging

```yaml
outputs:
  validation_status: ${{ steps.validation.outputs.status }}
  validation_results: ${{ steps.validation.outputs.results }}
  pass_number: ${{ steps.validation.outputs.pass_number }}
  committer_name: ${{ steps.validation.outputs.committer }}
```

**Results JSON structure:**

```javascript
{
  testId: "T-001",
  errors: ["❌ Insufficient IB cases: found 0, need ≥1"],
  warnings: ["⚠️ IB-01: Description is too short"],
  passed: ["✅ Issue body is not empty", "✅ Section present: Test ID"],
  hasErrors: true,
  errorCount: 1,
  warningCount: 1,
  passedCount: 2
}
```

### Decision Log Integration

```yaml
log_decision:
  needs: validate
  if: always() # Run even if validation fails
  uses: ./.github/workflows/decision_log_writer.yml
  with:
    issue_number: ${{ github.event.issue.number }}
    pass_number: ${{ needs.validate.outputs.pass_number }}
    status: ${{ needs.validate.outputs.validation_status }}
    workflow_name: 'Validate Issue Format'
    trigger_event: ${{ github.event_name }}
    validation_results_json: ${{ needs.validate.outputs.validation_results }}
    committer_name: ${{ needs.validate.outputs.committer }}
```

---

## 2. Enforce Test Gate (`enforce_test_gate.yml`)

**Purpose:** Atomic enforcement of IB/OOB minimums with gate state management

**Triggers:**

- Automatic: Issue opened or edited (if `type: test` label present)

**Permissions:** `issues: write`

**Concurrency:**

```yaml
concurrency:
  group: enforce-gate-issue-${{ github.event.issue.number }}
  cancel-in-progress: false
```

### State Machine Logic

**Job condition:**

```yaml
if: |
  contains(join(github.event.issue.labels.*.name, ','), 'type: test') &&
  (contains(join(github.event.issue.labels.*.name, ','), 'validation: pending') ||
   contains(join(github.event.issue.labels.*.name, ','), 'validation: passed'))
```

**Only executes in:**

- `validation: pending` - Format valid, gate not checked
- `validation: passed` - Format valid, gate checked and requirements met

**Does not execute in:**

- `validation: blocked` - Format invalid (separate job posts explanation comment)

### Gate Enforcement Algorithm

```javascript
// 1. Extract test cases (same regex as validate-issue.yml)
const IB = [...new Set(ibMatches)];
const OOB = [...new Set(oobMatches)];

// 2. Extract validation gate checkbox
const gateRe = /- \[( |x)\]\s*✅?\s*test\.validated\s*=\s*true/i;
const gate = body.match(gateRe);

if (!gate) {
  // Gate checkbox missing - format invalid, shouldn't happen if validation passed
  return;
}

const gateChecked = /\[x\]/i.test(gate[0]);

// 3. Check requirements (atomic decision)
const meetsRequirements = ibCount >= IB_MIN && oobCount >= OOB_MIN;

// 4. State transitions
if (gateChecked && !meetsRequirements) {
  // VIOLATION: Gate checked but requirements not met
  // → Uncheck gate, clear run checklist, set workflow: blocked
}

if (gateChecked && meetsRequirements) {
  // SUCCESS: Gate checked and requirements met
  // → Set validation: passed, remove workflow: blocked
}

if (!gateChecked) {
  // PENDING: Gate not checked (regardless of requirements)
  // → Set validation: pending
}
```

### Gate Violation Handling

When requirements are not met but gate is checked:

**1. Uncheck validation gate:**

```javascript
let newBody = body.replace(gateRe, '- [ ] ✅ test.validated = true');
```

**2. Clear run checklist:**

```javascript
newBody = newBody.replace(/(###\s*Run checklist[\s\S]*?)- \[x\]/gi, '$1- [ ]');
```

**3. Update issue body:**

```javascript
await github.rest.issues.update({
  owner: context.repo.owner,
  repo: context.repo.repo,
  issue_number: issue.number,
  body: newBody,
});
```

**4. Post detailed feedback:**

```markdown
❌ Validation gate blocked: requirements not met

**Requirements** (configurable via repository variables):

- IB cases: need ≥1, found **0**
- OOB cases: need ≥2, found **1**

**Found IB cases**: none
**Found OOB cases**: OOB-01

**Action taken**:

- ✅ Validation gate checkbox unchecked
- ✅ Run checklist auto-emptied
- ✅ Labels updated: `workflow: blocked`, `validation: pending`

**Next steps**:

1. Add missing test cases to meet requirements
2. If any case fails or code changes, re-run from the top
3. Check the validation gate when all cases pass

**Boundary order** (if applicable): OOB-01 → IB-01 → OOB-02
```

**5. Update labels:**

```javascript
await batchUpdateLabels(
  ['workflow: blocked', 'validation: pending'], // Add
  ['validation: passed'] // Remove
);
```

### Batch Label Updates

**Why batching?**

- Single API call prevents race conditions
- Calculates final label set atomically
- Only updates if changes detected

```javascript
async function batchUpdateLabels(toAdd, toRemove) {
  const currentLabels = new Set(issue.labels.map((l) => l.name));

  // Calculate final label set
  const finalLabels = new Set(currentLabels);
  toRemove.forEach((label) => finalLabels.delete(label));
  toAdd.forEach((label) => finalLabels.add(label));

  // Only update if there's a change
  if (
    finalLabels.size !== currentLabels.size ||
    ![...finalLabels].every((l) => currentLabels.has(l))
  ) {
    await github.rest.issues.setLabels({
      owner: context.repo.owner,
      repo: context.repo.repo,
      issue_number: issue.number,
      labels: [...finalLabels],
    });
  }
}
```

### Blocked State Handler

Separate job explains why workflow didn't run:

```yaml
validation_blocked:
  if: |
    contains(join(github.event.issue.labels.*.name, ','), 'type: test') &&
    contains(join(github.event.issue.labels.*.name, ','), 'validation: blocked')
  runs-on: ubuntu-latest
  steps:
    - uses: actions/github-script@v7
      with:
        script: |
          await github.rest.issues.createComment({
            owner: context.repo.owner,
            repo: context.repo.repo,
            issue_number: context.payload.issue.number,
            body: '🚫 **Validation state: blocked**\n\n' +
                  'This workflow cannot execute while validation is blocked.\n\n' +
                  '**State machine**: `blocked` → `pending` → `passed`\n\n' +
                  '**Next steps**:\n' +
                  '1. Ensure test case requirements are met (IB/OOB minimums)\n' +
                  '2. The validation gate will transition to `pending` automatically\n' +
                  '3. Check the validation checkbox when ready\n\n' +
                  'See recent comments for details on what blocked validation.'
          });
```

### Outputs for Decision Logging

```javascript
const gateResults = {
  ibCount: ibCount,
  oobCount: oobCount,
  ibCases: uniqueIB,
  oobCases: uniqueOOB,
  meetsRequirements: meetsRequirements,
  gateChecked: gateChecked,
  errorReason: !meetsRequirements ? `IB: ${ibCount}/${IB_MIN}, OOB: ${oobCount}/${OOB_MIN}` : null,
};

const status =
  gateChecked && meetsRequirements ? 'Success' : meetsRequirements ? 'Attempted' : 'Failed';
```

---

## 3. Seed Test Runlist (`seed-test-runlist.yml`)

**Purpose:** Generate ordered run checklist with conflict resolution commands

**Triggers:**

- Automatic: Issue opened (if `type: test` label present)
- Manual: `/seed <command>` comment on issue

**Permissions:** `issues: write`

**Concurrency:**

```yaml
concurrency:
  group: seed-runlist-issue-${{ github.event.issue.number }}
  cancel-in-progress: false
```

### Checklist Generation Algorithm

**Ordering rule:** OOB-01 → IB-01 → OOB-02 → remaining (ascending)

```javascript
// 1. Extract and deduplicate test cases
const uniq = (xs) => [...new Set(xs)];
const num = (id) => parseInt(id.split('-')[1], 10);
const IB = uniq(ibMatches).sort((a, b) => num(a) - num(b));
const OOB = uniq(oobMatches).sort((a, b) => num(a) - num(b));

// 2. Check requirements
if (IB.length < IB_MIN || OOB.length < OOB_MIN) {
  // Don't seed, post warning
  return;
}

// 3. Build ordered list
const order = [];
const o1 = OOB[0],
  o2 = OOB[1],
  i1 = IB[0];

if (OOB.length >= 2 && IB.length >= 1) {
  // Standard ordering: OOB → IB → OOB → rest
  order.push(o1, i1, o2);
  order.push(...OOB.slice(2), ...IB.slice(1));
} else {
  // Fallback: OOBs ascending, then IBs ascending
  order.push(...OOB, ...IB);
}

// 4. Format as markdown checklist
const checklist = ['### Run checklist', ...order.map((id) => `- [ ] ${id}`)].join('\n');
```

**Example ordering:**

Given test cases:

- IB-01, IB-02, IB-03
- OOB-01, OOB-02, OOB-03, OOB-04

Result:

```
OOB-01 → IB-01 → OOB-02 → OOB-03 → OOB-04 → IB-02 → IB-03
```

**Rationale:**

- OOB-01 tests boundary at minimum (e.g., empty input)
- IB-01 tests valid baseline (e.g., single valid item)
- OOB-02 tests boundary at maximum (e.g., overflow)
- Remaining cases test additional edge cases and valid scenarios

### Auto-Seed on Issue Open

```yaml
seed:
  if: |
    github.event_name == 'issues' &&
    github.event.action == 'opened' &&
    contains(join(github.event.issue.labels.*.name, ','), 'type: test') &&
    (contains(join(github.event.issue.labels.*.name, ','), 'validation: pending') ||
     contains(join(github.event.issue.labels.*.name, ','), 'validation: passed'))
```

**Behavior:**

```javascript
// Check for existing checklist
const hasRunlist = /(^|\n)#{2,3}\s*Run checklist\b/i.test(body);

if (!hasRunlist) {
  // Create new checklist
  const newBody = `${body}\n\n${checklist}\n`;
  await github.rest.issues.update({ body: newBody });

  await postComment(`✅ Run checklist seeded\n\n**Order**: ${order.join(' → ')}`);
} else {
  // Checklist exists - don't modify (preserve manual edits)
  await postComment(
    `ℹ️ Run checklist already exists - not modified\n\n` + `Use \`/seed overwrite\` to replace`
  );
}
```

### Manual Seed Commands

Three commands for conflict resolution:

#### `/seed overwrite`

**Purpose:** Replace existing checklist with freshly generated one

**Use cases:**

- Test cases added/removed, need new checklist
- Manual edits incorrect, want to reset
- Ordering changed (e.g., renumbered test cases)

**Behavior:**

```javascript
const checklist = ['### Run checklist', ...order.map((id) => `- [ ] ${id}`)].join('\n');

const newBody = body.replace(/(^|\n)#{2,3}\s*Run checklist\b[\s\S]*$/i, `$1${checklist}`);

await github.rest.issues.update({ body: newBody });
await postComment(
  `✅ Run checklist overwritten by @${commenter}\n\n` +
    `**New order**: ${order.join(' → ')}\n` +
    `**Total cases**: ${order.length}`
);
```

**Warning:** Destroys all manual edits and check states

#### `/seed keep`

**Purpose:** Keep existing checklist unchanged

**Use cases:**

- Manual edits in progress, don't want workflow to interfere
- Custom ordering intentionally applied
- Debugging workflow behavior

**Behavior:**

```javascript
await postComment(`✅ Keeping existing Run checklist unchanged`);
// No issue update
```

#### `/seed merge`

**Purpose:** Merge new test cases into existing checklist, preserving check states

**Use cases:**

- Added new test cases, want to preserve checked items
- Removed some test cases, want to clean up checklist
- Maintain execution progress while updating checklist

**Behavior:**

```javascript
// 1. Extract existing checklist items with check states
const existingItems = [...checklistMatch[0].matchAll(/- \[([ x])\] (IB-\d+|OOB-\d+)/gi)].map(
  (m) => ({ checked: m[1] === 'x', id: m[2].toUpperCase() })
);

// 2. Preserve checked state, add new items unchecked
const mergedOrder = order.map((id) => {
  const existing = existingItems.find((item) => item.id === id);
  return existing ? `- [${existing.checked ? 'x' : ' '}] ${id}` : `- [ ] ${id}`;
});

// 3. Update issue
const checklist = ['### Run checklist', ...mergedOrder].join('\n');
const newBody = body.replace(/(^|\n)#{2,3}\s*Run checklist\b[\s\S]*$/i, `$1${checklist}`);

await github.rest.issues.update({ body: newBody });
await postComment(
  `✅ Run checklist merged by @${commenter}\n\n` +
    `Preserved check states for existing items.\n` +
    `**Order**: ${order.join(' → ')}\n` +
    `**Total cases**: ${order.length}`
);
```

**Example merge:**

**Before:**

```markdown
### Run checklist

- [x] OOB-01
- [x] IB-01
- [ ] OOB-02
```

**New test cases added:** IB-02, OOB-03

**After merge:**

```markdown
### Run checklist

- [x] OOB-01
- [x] IB-01
- [ ] OOB-02
- [ ] OOB-03 ← newly added
- [ ] IB-02 ← newly added
```

### Permission Checks

Manual commands require write access:

```javascript
const { data } = await github.rest.repos.getCollaboratorPermissionLevel({
  owner: context.repo.owner,
  repo: context.repo.repo,
  username: commenter,
});

if (!['admin', 'write', 'maintain'].includes(data.permission)) {
  await postComment(
    `❌ Permission denied\n\n` +
      `@${commenter} you need write access or higher to use /seed commands.`
  );
  return;
}
```

---

## Workflow Coordination and Race Conditions

### Concurrency Control

**Problem:** Multiple events (issue edits, comments) can trigger workflows simultaneously on the same issue.

**Solution:** Concurrency groups with `cancel-in-progress: false`

```yaml
concurrency:
  group: validate-issue-${{ github.event.issue.number }}
  cancel-in-progress: false
```

**Effect:**

- Workflows with same group key run sequentially
- Subsequent runs wait (not cancelled)
- Preserves all validation attempts for audit trail
- Prevents conflicting issue body updates

### State Machine Enforcement

**Problem:** Workflows might run before validation completes.

**Solution:** Label-based state machine

```
blocked → pending → passed
```

**Enforcement:**

```yaml
# validate-issue.yml: Always runs (no state check)
if: |
  contains(join(github.event.issue.labels.*.name, ','), 'type: test')

# enforce_test_gate.yml: Only runs in pending/passed
if: |
  contains(join(github.event.issue.labels.*.name, ','), 'type: test') &&
  (contains(join(github.event.issue.labels.*.name, ','), 'validation: pending') ||
   contains(join(github.event.issue.labels.*.name, ','), 'validation: passed'))

# seed-test-runlist.yml: Only runs in pending/passed
if: |
  contains(join(github.event.issue.labels.*.name, ','), 'type: test') &&
  (contains(join(github.event.issue.labels.*.name, ','), 'validation: pending') ||
   contains(join(github.event.issue.labels.*.name, ','), 'validation: passed'))
```

### Atomic Operations

**Problem:** Multiple independent checks can create race conditions.

**Example (BAD):**

```yaml
# Anti-pattern: Independent IB and OOB checks
- name: Check IB
  if: steps.count_ib.outputs.count < 1
  run: apply_blocked_label

- name: Check OOB
  if: steps.count_oob.outputs.count < 2
  run: apply_blocked_label
```

**Problem:** Both checks might run, label applied twice, or race with other workflows.

**Solution (GOOD):**

```javascript
// Single atomic decision
const meetsRequirements = ibCount >= IB_MIN && oobCount >= OOB_MIN;

if (gateChecked && !meetsRequirements) {
  // Single update operation
  await github.rest.issues.update({ body: newBody });
  await batchUpdateLabels(['workflow: blocked'], ['validation: passed']);
}
```

---

## Error Handling and Retry Logic

### Network Errors

**Problem:** GitHub API calls can fail due to network issues.

**Current behavior:** Workflows fail and retry automatically via GitHub Actions retry mechanism.

**Improvement opportunity:** Implement exponential backoff for API calls:

```javascript
async function fetchIssueBodyWithRetry(url, maxRetries = 3) {
  for (let attempt = 1; attempt <= maxRetries; attempt++) {
    try {
      const { data } = await github.rest.issues.get({ owner, repo, issue_number });
      return data.body || '';
    } catch (err) {
      if (attempt === maxRetries) return null;

      // Exponential backoff: 1s, 2s, 4s
      const delay = Math.pow(2, attempt - 1) * 1000;
      await new Promise((resolve) => setTimeout(resolve, delay));
    }
  }
}
```

### Missing Required Data

**Problem:** Issue body might not have expected sections.

**Solution:** Graceful degradation with clear feedback

```javascript
if (!body || body.trim() === '') {
  // Early exit with explanation
  await postComment(`⚠️ Issue body is empty\n\nCannot validate without content.`);
  return;
}

if (!gate) {
  // Missing validation gate - likely not from template
  await postComment(
    `⚠️ Validation gate checkbox not found\n\n` +
      `Expected format: \`- [ ] ✅ test.validated = true\`\n\n` +
      `Please ensure your issue was created from the test template.`
  );
  return;
}
```

### YAML Parsing Errors

**Problem:** Suite issues might contain invalid YAML.

**Solution:** Try-catch with detailed error message

```javascript
try {
  const parsedYaml = YAML.load(yamlBlockMatch[1]);
  if (parsedYaml && typeof parsedYaml === 'object') {
    validations.push('✅ Suite issue contains valid YAML context');
  } else {
    errors.push('❌ Suite issue YAML block is empty or invalid structure');
  }
} catch (err) {
  errors.push(`❌ Suite issue contains invalid YAML: ${err.message}`);
}
```

### Permission Errors

**Problem:** Manual commands might be used by users without write access.

**Solution:** Pre-flight permission check

```javascript
let perm;
try {
  const { data } = await github.rest.repos.getCollaboratorPermissionLevel({
    owner: context.repo.owner,
    repo: context.repo.repo,
    username: commenter,
  });
  perm = data.permission;
} catch (err) {
  await postComment(`❌ Failed to check permissions: ${err.message}`);
  return;
}

if (!['admin', 'write', 'maintain'].includes(perm)) {
  await postComment(`❌ Permission denied\n\n` + `@${commenter} you need write access or higher.`);
  return;
}
```

### Timeout Protection

All workflows have timeout limits:

```yaml
timeout-minutes: 5  # validate-issue.yml
timeout-minutes: 3  # enforce_test_gate.yml
timeout-minutes: 5  # seed-test-runlist.yml (manual commands)
```

**Effect:** Prevents hung workflows from consuming runner minutes indefinitely.

---

## Decision Logging Integration

All three workflows call `decision_log_writer.yml` to record their activities:

```yaml
log_decision:
  needs: validate
  if: always() # Run even if validation fails
  uses: ./.github/workflows/decision_log_writer.yml
  with:
    issue_number: ${{ github.event.issue.number }}
    pass_number: ${{ needs.validate.outputs.pass_number }}
    status: ${{ needs.validate.outputs.validation_status }}
    workflow_name: 'Validate Issue Format'
    trigger_event: ${{ github.event_name }}
    validation_results_json: ${{ needs.validate.outputs.validation_results }}
    committer_name: ${{ needs.validate.outputs.committer }}
```

**Pass number calculation:**

```javascript
// Count existing pass entries in decision log
const logFileName = `issue_${String(issue.number).padStart(4, '0')}_decision_log.md`;
const { data: fileData } = await github.rest.repos
  .getContent({
    owner: context.repo.owner,
    repo: context.repo.repo,
    path: `.ai_logs/${logFileName}`,
    ref: context.ref,
  })
  .catch(() => ({ data: null }));

if (fileData) {
  const content = Buffer.from(fileData.content, 'base64').toString('utf8');
  const passMatches = content.match(/^## Pass \d+:/gm);
  passNumber = passMatches ? passMatches.length + 1 : 1;
} else {
  passNumber = 1; // First pass
}
```

**Status values:**

- `Success` - Operation completed successfully
- `Failed` - Operation failed (errors present)
- `Blocked` - Operation blocked by validation state
- `Attempted` - Operation attempted but no change made (e.g., checklist already exists)

---

## Testing and Verification

### Unit Testing Approach

Test each workflow independently:

**1. Test validation logic:**

```bash
# Create test issue with missing IB cases
gh issue create --label "type: test" --body "$(cat test_missing_ib.md)"

# Verify:
# - validation: blocked label applied
# - Error comment posted with specific error
# - No checklist generated
```

**2. Test gate enforcement:**

```bash
# Create test issue with IB=0, OOB=1, gate checked
gh issue create --label "type: test" --body "$(cat test_insufficient_cases.md)"

# Verify:
# - Gate automatically unchecked
# - workflow: blocked label applied
# - Error comment lists missing cases
```

**3. Test checklist generation:**

```bash
# Create test issue with IB=3, OOB=4
gh issue create --label "type: test" --body "$(cat test_valid_cases.md)"

# Verify:
# - Checklist auto-generated on issue open
# - Order: OOB-01 → IB-01 → OOB-02 → OOB-03 → OOB-04 → IB-02 → IB-03
# - All items unchecked
```

### Integration Testing

Test workflow coordination:

**1. Test state transitions:**

```bash
# Start with blocked state
# Edit to fix errors
# Verify transition: blocked → pending
# Check validation gate
# Verify transition: pending → passed
```

**2. Test conflict resolution:**

```bash
# Create issue with IB-01, IB-02, OOB-01, OOB-02
# Wait for auto-seed
# Add IB-03, OOB-03 to issue body
# Run `/seed merge`
# Verify: New cases added to checklist, existing check states preserved
```

**3. Test concurrency:**

```bash
# Rapidly edit issue multiple times
# Verify:
# - All validation attempts recorded
# - No race conditions or corrupted issue bodies
# - Final state correct based on last edit
```

### End-to-End Testing

Simulate full test lifecycle:

```bash
# 1. Create test issue from template
gh issue create --template test.yml

# 2. Fill out required sections with IB-01, OOB-01, OOB-02
# Auto-triggers: validate-issue, enforce_test_gate, seed-test-runlist

# 3. Verify checklist generated with correct order

# 4. Run OOB-01 → check box
# 5. Run IB-01 → check box
# 6. Run OOB-02 → check box

# 7. Check validation gate
# Triggers: enforce_test_gate
# Verify: validation: passed label applied

# 8. Add IB-02 to issue
# Verify: Gate automatically unchecked (checklist changed)

# 9. Run `/seed merge`
# Verify: IB-02 added to checklist, previous checks preserved

# 10. Run IB-02 → check box
# 11. Check validation gate again
# Verify: validation: passed label applied
```

---

## Troubleshooting

### Common Issues

#### Validation Passed But Gate Still Blocked

**Symptoms:**

- `/validate` shows all checks passed
- Validation gate checkbox won't stay checked
- `workflow: blocked` label remains

**Causes:**

1. Requirements not met (IB < 1 or OOB < 2)
2. Run checklist has unchecked items

**Solution:**

```bash
# Check test case counts
grep -E "^- (IB-|OOB-)" issue.md | wc -l

# Verify requirements met
IB_COUNT=$(grep -c "^- IB-" issue.md)
OOB_COUNT=$(grep -c "^- OOB-" issue.md)

echo "IB: $IB_COUNT (need ≥1)"
echo "OOB: $OOB_COUNT (need ≥2)"

# If requirements met but gate still blocked:
# 1. Check all run checklist items
# 2. Re-run `/validate` to clear state
# 3. Check validation gate
```

#### Checklist Order Incorrect

**Symptoms:**

- Checklist generated but not in OOB → IB → OOB order

**Causes:**

1. Test case IDs not properly formatted (missing leading zeros)
2. Manual edits to checklist

**Solution:**

```bash
# Regenerate checklist from scratch
# Comment: /seed overwrite

# Verify test case format
grep -E "^- (IB-|OOB-)" issue.md

# Should see: IB-01, IB-02 (not IB-1, IB-2)
# Should see: OOB-01, OOB-02 (not OOB-1, OOB-2)
```

#### Workflow Not Triggering

**Symptoms:**

- Edit issue but no workflow runs
- No comments posted by workflow

**Causes:**

1. Issue missing `type: test` label
2. Issue in `validation: blocked` state
3. Workflow concurrency lock (another run in progress)

**Solution:**

```bash
# Check labels
gh issue view <number> --json labels

# Expected: type: test, validation: pending (or passed)
# If blocked: Fix validation errors first

# Check workflow runs
gh run list --workflow=validate-issue.yml --limit=5

# If stuck, wait 5 minutes for concurrency timeout
```

#### Permission Denied on /seed Commands

**Symptoms:**

- `/seed overwrite` returns "Permission denied"

**Causes:**

- User lacks write access to repository

**Solution:**

```bash
# Check user permission
gh api repos/OWNER/REPO/collaborators/USERNAME/permission

# Should return: admin, maintain, or write
# If read or none: User needs to be added as collaborator
```

---

## Maintenance and Updates

### Updating IB/OOB Requirements

**To change minimums:**

1. Update repository variables:
   - Settings → Secrets and variables → Actions → Variables
   - Edit `IB_MIN_REQUIRED` and `OOB_MIN_REQUIRED`

2. No workflow changes needed (values are read dynamically)

3. Existing issues not affected until next edit/validation

### Adding New Validation Checks

**To add a new validation:**

1. Add validation logic to `validate-issue.yml`:

   ```javascript
   // Example: Validate test ID prefix
   const testId = testIdMatch[1].trim();
   if (!testId.startsWith('T-')) {
     errors.push(`❌ Test ID must start with T- (found: ${testId})`);
   } else {
     validations.push(`✅ Test ID prefix valid`);
   }
   ```

2. Update this documentation with new validation rule

3. Test with existing issues to verify no false positives

### Modifying Checklist Ordering

**To change ordering algorithm:**

1. Edit `seed-test-runlist.yml`, both jobs (`seed` and `handle_seed_command`):

   ```javascript
   // Current: OOB-01 → IB-01 → OOB-02 → rest ascending

   // Example: All OOBs first, then all IBs
   const order = [...OOB, ...IB];

   // Example: Interleaved OOB/IB
   const order = [];
   const maxLen = Math.max(OOB.length, IB.length);
   for (let i = 0; i < maxLen; i++) {
     if (OOB[i]) order.push(OOB[i]);
     if (IB[i]) order.push(IB[i]);
   }
   ```

2. Update this documentation with new ordering rule and rationale

3. Test with various test case combinations

---

## Related Documentation

- [Issue Template Usage](../templates/template_usage.md) - How to create test issues
- [Test Naming Examples](../examples/test_naming_examples.md) - IB/OOB naming conventions
- [Decision Log Format](../ai_work/decision_log_format.md) - Decision logging structure
- [Hierarchy Examples](../examples/hierarchy_examples.md) - 5-level atomic hierarchy

---

**Document Version:** 1.0
**Last Updated:** 2025-11-10
**Maintainer:** Claude AI (document author)
**Review Status:** Ready for human review
