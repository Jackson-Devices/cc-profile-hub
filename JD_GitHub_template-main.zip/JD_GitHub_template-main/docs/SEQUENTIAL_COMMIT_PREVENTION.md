# Sequential Commit Prevention System

## Overview

This system prevents sequential commits on the same branch, enforcing a "one branch, one logical change" policy. When a branch already has commits, any attempt to add more commits will be blocked, requiring the creation of a new branch.

## Why This Policy?

Sequential commits on the same branch can lead to:

- **Mixed concerns**: Unrelated changes bundled together
- **Complex reviews**: Large PRs with multiple logical changes
- **Difficult rollbacks**: Hard to revert specific changes without affecting others
- **Lost context**: Changes blur together over time

By enforcing one logical change per branch, we get:

- ✅ Focused, reviewable PRs
- ✅ Clear separation of concerns
- ✅ Easy rollback of individual changes
- ✅ Better git history and audit trail

## Architecture

The system has two enforcement layers:

### 1. GitHub Actions Workflow (Remote Enforcement)

**File**: `.github/workflows/prevent-sequential-commits-gate.yml`

**Triggers**: On push to `claude/**` branches

**Behavior**:

- Counts commits on the branch beyond the base branch
- If count > 1: Blocks the push and provides detailed instructions
- If count = 1: Allows the push (first commit on branch)

**Advantages**:

- Enforces policy at the remote level
- Works for all contributors automatically
- No local setup required
- Provides consistent enforcement

### 2. Local Pre-commit Hook (Optional, Local Enforcement)

**File**: `scripts/pre-commit-sequential-check.sh`

**Triggers**: Before each local commit

**Behavior**:

- Checks if the current branch already has commits
- If yes: Blocks the commit before it's created
- If no: Allows the commit

**Advantages**:

- Catches issues earlier (before push)
- Saves time by preventing failed pushes
- Provides immediate feedback
- Reduces CI/CD resource usage

## Installation

### GitHub Actions Workflow

**Status**: ✅ Automatically active

The workflow is active by default for all `claude/**` branches. No installation required.

### Local Pre-commit Hook

**Status**: ⚙️ Optional (recommended)

To install the local pre-commit hook:

```bash
# From the repository root
./scripts/install-commit-prevention-hook.sh
```

This will:

1. Backup any existing pre-commit hook
2. Install the sequential commit prevention hook
3. Make it executable

To uninstall:

```bash
rm .git/hooks/pre-commit
```

## Usage

### Normal Workflow (First Commit)

```bash
# Create a new branch
git checkout -b claude/my-feature-<SESSION_ID>

# Make changes
# ... edit files ...

# Commit (will succeed)
git add .
git commit -m "feat: add new feature"

# Push (will succeed)
git push -u origin claude/my-feature-<SESSION_ID>
```

### When You Need to Make More Changes

If you try to commit again on the same branch:

```bash
# This will be BLOCKED by the pre-commit hook
git add .
git commit -m "fix: another change"
```

**Error message**:

```
❌ COMMIT BLOCKED: Sequential commits not allowed
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

This branch already has commits. Sequential commits are not permitted.

📋 CURRENT STATUS:
   • Branch: claude/my-feature-<SESSION_ID>
   • Existing commits: 1

📋 ACTION REQUIRED:
   Create a NEW branch for your additional changes.
```

**Correct approach**:

```bash
# 1. Stash your current changes
git stash

# 2. Create a new branch
git checkout -b claude/my-other-feature-<SESSION_ID>

# 3. Apply your changes
git stash pop

# 4. Commit on the new branch
git add .
git commit -m "fix: another change"

# 5. Push the new branch
git push -u origin claude/my-other-feature-<SESSION_ID>
```

## Enforcement Details

### Branch Naming Pattern

The policy applies to branches matching:

- `claude/**` (all claude-prefixed branches)

Other branches are not affected by this policy.

### Commit Counting

The system counts commits that exist on the current branch but not on the default branch (typically `main`).

**Example**:

```
main branch:      A---B---C
                       \
feature branch:         D---E
                            ↑
                         Blocked (2nd commit)
```

- When committing `D`: ✅ Allowed (first commit)
- When committing `E`: ❌ Blocked (second commit)

### Edge Cases

**Scenario**: What if I need to fix a typo in my commit message?

```bash
# Use amend for small fixes to the last commit ONLY
git commit --amend -m "feat: fixed commit message"
git push --force-with-lease
```

⚠️ **Note**: Amending doesn't create a new commit, so it's allowed. However, use sparingly and only for trivial fixes immediately after committing.

**Scenario**: What if I absolutely must add to the same branch?

If you have a legitimate need to bypass the policy:

1. Discuss with your team first
2. Temporarily disable the local hook: `mv .git/hooks/pre-commit .git/hooks/pre-commit.disabled`
3. Make your commit
4. Re-enable the hook: `mv .git/hooks/pre-commit.disabled .git/hooks/pre-commit`
5. Document why in your PR description

⚠️ **Warning**: The GitHub Actions workflow will still block your push. This is intentional to ensure policy compliance.

## Troubleshooting

### Problem: Hook not triggering

**Solution**:

```bash
# Check if hook is installed
ls -la .git/hooks/pre-commit

# Reinstall if needed
./scripts/install-commit-prevention-hook.sh
```

### Problem: Hook blocking legitimate first commit

**Symptom**: Hook blocks even though this is your first commit

**Possible causes**:

1. Branch has commits from previous work
2. You're not on a fresh branch

**Solution**:

```bash
# Check commit count
git rev-list --count origin/main..HEAD

# If > 0, create a new branch
git checkout -b claude/new-branch-<SESSION_ID>
git cherry-pick <your-commit-hash>
```

### Problem: GitHub Actions workflow failing

**Symptom**: Push succeeds locally but fails in CI

This is expected behavior if:

- You bypassed the local hook
- You pushed multiple commits

**Solution**:

1. Create a new branch from the base
2. Cherry-pick only your desired commit
3. Push the new branch

## Configuration

### Modifying Branch Pattern

To change which branches are protected, edit:

**Workflow**: `.github/workflows/prevent-sequential-commits-gate.yml`

```yaml
on:
  push:
    branches:
      - 'claude/**' # Modify this pattern
```

**Hook**: `scripts/pre-commit-sequential-check.sh`

```bash
# Only check claude/ branches
if [[ ! "$CURRENT_BRANCH" =~ ^claude/ ]]; then
    # Modify this pattern
    exit 0
fi
```

### Disabling the System

**Disable workflow**:

- Delete or rename `.github/workflows/prevent-sequential-commits-gate.yml`

**Disable local hook**:

```bash
rm .git/hooks/pre-commit
```

## Integration with CI/CD

This system integrates seamlessly with existing CI/CD workflows:

1. **Before** sequential commit prevention: All other checks run
2. **During** sequential commit prevention: Commit count check runs
3. **After** sequential commit prevention: If blocked, other checks don't run (saves resources)

The workflow has a 5-minute timeout and minimal resource usage.

## Related Documentation

- [Testing Guide](./TESTING_GUIDE.md)
- [Contributing Guidelines](../CONTRIBUTING.md) (if exists)
- [Git Workflow](./GIT_WORKFLOW.md) (if exists)

## Support

For issues or questions:

1. Check this documentation
2. Review the error messages (they include helpful instructions)
3. Open an issue on the repository

## Version History

- **v1.0** (2025-11-12): Initial implementation
  - GitHub Actions workflow
  - Local pre-commit hook
  - Installation script
  - Documentation
