# Project-Specific Testing Examples

**Testing patterns for JD GitHub Template Repository workflows and automation**

---

## Table of Contents

1. [Testing Validate-Issue Workflow](#1-testing-validate-issue-workflow)
2. [Testing GitHub Script Functions](#2-testing-github-script-functions)
3. [Testing YAML Validation](#3-testing-yaml-validation)
4. [Testing Label Taxonomy](#4-testing-label-taxonomy)
5. [Testing Decision Log Writer](#5-testing-decision-log-writer)
6. [Integration Tests](#6-integration-tests)

---

## 1. Testing Validate-Issue Workflow

### 1.1 Extract Script Logic to Module

**Create**: `scripts/validate-issue.js`

```javascript
/**
 * Validates issue format according to test.yml template requirements
 * @param {Object} params
 * @param {Object} params.github - Octokit instance
 * @param {Object} params.context - GitHub Actions context
 * @param {Object} params.config - Configuration (IB_MIN, OOB_MIN)
 * @returns {Promise<Object>} Validation results
 */
export async function validateIssue({ github, context, config }) {
  const issue = context.payload.issue;
  const body = issue.body || '';

  const errors = [];
  const warnings = [];
  const validations = [];

  // Configuration
  const IB_MIN = config.IB_MIN || 1;
  const OOB_MIN = config.OOB_MIN || 2;

  // Helper functions
  async function fetchIssueBody(url) {
    const match = url.match(/github\.com\/([^/]+)\/([^/]+)\/issues\/(\d+)/);
    if (!match) return null;

    const [, owner, repo, issue_number] = match;
    try {
      const { data } = await github.rest.issues.get({
        owner,
        repo,
        issue_number: parseInt(issue_number, 10),
      });
      return data.body || '';
    } catch (err) {
      return null;
    }
  }

  // 1. Validate Issue Body Not Empty
  if (!body || body.trim() === '') {
    errors.push('Issue body is empty');
    return { valid: false, errors, warnings, validations };
  }
  validations.push('Issue body is not empty');

  // 2. Validate Required Sections
  const requiredSections = [
    { name: 'Test ID', pattern: /### Test ID\s*\n+(.+)/, minLength: 4 },
    {
      name: 'Suite (c1) Issue URL',
      pattern: /### Suite \(c1\) Issue URL\s*\n+(.+)/,
      minLength: 10,
    },
    {
      name: 'Parent feature\/bug \(p\) URL',
      pattern: /### Parent feature\/bug \(p\) URL\s*\n+(.+)/,
      minLength: 10,
    },
    { name: 'Purpose', pattern: /### Purpose\s*\n+([\s\S]+?)(?=\n###|$)/, minLength: 20 },
    {
      name: 'In-Bounds Case(s)',
      pattern: /### In-Bounds Case\(s\)\s*\(IB≥1\)\s*\n+([\s\S]+?)(?=\n###|$)/,
      minLength: 30,
    },
    {
      name: 'Out-of-Bounds Case(s)',
      pattern: /### Out-of-Bounds Case\(s\)\s*\(OOB≥2 required\)\s*\n+([\s\S]+?)(?=\n###|$)/,
      minLength: 30,
    },
    {
      name: 'Expected Behavior',
      pattern: /### Expected Behavior \(authoritative\)\s*\n+([\s\S]+?)(?=\n###|$)/,
      minLength: 20,
    },
    {
      name: 'Validation Method',
      pattern: /### Validation Method\s*\n+([\s\S]+?)(?=\n###|$)/,
      minLength: 20,
    },
    {
      name: 'Validation Gate',
      pattern: /### Validation Gate\s*\n+([\s\S]+?)(?=\n###|$)/,
      minLength: 10,
    },
  ];

  for (const section of requiredSections) {
    const match = body.match(section.pattern);
    if (!match || !match[1]) {
      errors.push(`Missing required section: ${section.name}`);
    } else {
      const content = match[1].trim();
      if (content === '' || content === '_No response_') {
        errors.push(`Section ${section.name} is empty or placeholder`);
      } else if (section.minLength && content.length < section.minLength) {
        errors.push(
          `Section ${section.name} content too short (${content.length} chars, min ${section.minLength})`
        );
      } else {
        validations.push(`Section present: ${section.name}`);
      }
    }
  }

  // 3. Validate Test ID Format
  const testIdMatch = body.match(/### Test ID\s*\n+(.+)/);
  if (testIdMatch && testIdMatch[1]) {
    const testId = testIdMatch[1].trim();
    const testIdPattern = /^T-\d{3,}$/;

    if (!testIdPattern.test(testId)) {
      errors.push(`Invalid Test ID format: "${testId}" (expected: T-XXX)`);
    } else {
      validations.push(`Test ID format valid: ${testId}`);
    }
  }

  // 4. Validate IB/OOB Test Case Format
  const ibRegex = /(^|\n)\s*-\s*(IB-(0[1-9]|[1-9][0-9]))\b/gi;
  const oobRegex = /(^|\n)\s*-\s*(OOB-(0[1-9]|[1-9][0-9]))\b/gi;

  const ibMatches = [...body.matchAll(ibRegex)].map((m) => m[2].toUpperCase());
  const oobMatches = [...body.matchAll(oobRegex)].map((m) => m[2].toUpperCase());

  const IB = [...new Set(ibMatches)];
  const OOB = [...new Set(oobMatches)];

  if (IB.length < IB_MIN) {
    errors.push(`Insufficient IB cases: found ${IB.length}, need ≥${IB_MIN}`);
  } else {
    validations.push(`IB cases: found ${IB.length} (${IB.join(', ')})`);
  }

  if (OOB.length < OOB_MIN) {
    errors.push(`Insufficient OOB cases: found ${OOB.length}, need ≥${OOB_MIN}`);
  } else {
    validations.push(`OOB cases: found ${OOB.length} (${OOB.join(', ')})`);
  }

  // 5. Validate Validation Gate Checkbox
  const gatePattern = /- \[( |x)\]\s*✅?\s*test\.validated\s*=\s*true/i;
  const gateMatch = body.match(gatePattern);

  if (!gateMatch) {
    errors.push('Validation gate checkbox not found');
  } else {
    validations.push('Validation gate checkbox present');
  }

  return {
    valid: errors.length === 0,
    errors,
    warnings,
    validations,
  };
}
```

### 1.2 Unit Tests for Validation Logic

**Create**: `test/unit/validate-issue.test.js`

```javascript
import { describe, it, test } from 'node:test';
import assert from 'node:assert/strict';
import { validateIssue } from '../../scripts/validate-issue.js';

describe('validateIssue', () => {
  const createMockGithub = () => ({
    rest: {
      issues: {
        get: async ({ owner, repo, issue_number }) => ({
          data: { id: issue_number, body: 'Mock issue body' },
        }),
      },
    },
  });

  const createMockContext = (body) => ({
    payload: {
      issue: {
        number: 1,
        body: body,
        labels: [],
      },
    },
    repo: { owner: 'test', repo: 'test' },
  });

  const config = { IB_MIN: 1, OOB_MIN: 2 };

  test('rejects empty issue body', async () => {
    const github = createMockGithub();
    const context = createMockContext('');

    const result = await validateIssue({ github, context, config });

    assert.strictEqual(result.valid, false);
    assert.ok(result.errors.some((e) => e.includes('empty')));
  });

  test('validates Test ID format', async () => {
    const validBody = `
### Test ID
T-001

### Suite (c1) Issue URL
https://github.com/test/test/issues/1

### Parent feature/bug (p) URL
https://github.com/test/test/issues/2

### Purpose
This is a test purpose with sufficient length to pass validation

### In-Bounds Case(s) (IB≥1)
- IB-01: Valid in-bounds test case
  - Input: test
  - Steps: test steps
  - Expected: test result

### Out-of-Bounds Case(s) (OOB≥2 required)
- OOB-01: First out-of-bounds case
  - Input: test
- OOB-02: Second out-of-bounds case
  - Input: test

### Expected Behavior (authoritative)
Expected behavior description

### Validation Method
Validation method description

### Validation Gate
- [ ] ✅ test.validated = true
`;

    const github = createMockGithub();
    const context = createMockContext(validBody);

    const result = await validateIssue({ github, context, config });

    assert.strictEqual(result.valid, true);
    assert.ok(result.validations.some((v) => v.includes('T-001')));
  });

  test('rejects invalid Test ID format', async () => {
    const invalidBody = `
### Test ID
T-1

### Suite (c1) Issue URL
https://github.com/test/test/issues/1

### Parent feature/bug (p) URL
_No response_

### Purpose
This is a test purpose with sufficient length

### In-Bounds Case(s) (IB≥1)
- IB-01: Test case

### Out-of-Bounds Case(s) (OOB≥2 required)
- OOB-01: Test
- OOB-02: Test

### Expected Behavior (authoritative)
Expected behavior

### Validation Method
Validation method

### Validation Gate
- [ ] test.validated = true
`;

    const github = createMockGithub();
    const context = createMockContext(invalidBody);

    const result = await validateIssue({ github, context, config });

    assert.strictEqual(result.valid, false);
    assert.ok(result.errors.some((e) => e.includes('Invalid Test ID format')));
  });

  test('validates IB/OOB case counts', async () => {
    const insufficientCases = `
### Test ID
T-001

### Suite (c1) Issue URL
https://github.com/test/test/issues/1

### Parent feature/bug (p) URL
_No response_

### Purpose
Test purpose with sufficient length to pass validation

### In-Bounds Case(s) (IB≥1)
- IB-01: Only one IB case

### Out-of-Bounds Case(s) (OOB≥2 required)
- OOB-01: Only one OOB case (need 2)

### Expected Behavior (authoritative)
Expected behavior description

### Validation Method
Validation method description

### Validation Gate
- [ ] test.validated = true
`;

    const github = createMockGithub();
    const context = createMockContext(insufficientCases);

    const result = await validateIssue({ github, context, config });

    assert.strictEqual(result.valid, false);
    assert.ok(result.errors.some((e) => e.includes('Insufficient OOB cases')));
  });

  test('validates IB/OOB case format (leading zeros)', async () => {
    const invalidFormat = `
### Test ID
T-001

### Suite (c1) Issue URL
https://github.com/test/test/issues/1

### Parent feature/bug (p) URL
_No response_

### Purpose
Test purpose

### In-Bounds Case(s) (IB≥1)
- IB-1: Invalid (missing leading zero)

### Out-of-Bounds Case(s) (OOB≥2 required)
- OOB-1: Invalid
- OOB-2: Invalid

### Expected Behavior (authoritative)
Expected

### Validation Method
Method

### Validation Gate
- [ ] test.validated = true
`;

    const github = createMockGithub();
    const context = createMockContext(invalidFormat);

    const result = await validateIssue({ github, context, config });

    // Should fail because IB-1, OOB-1, OOB-2 don't match the regex
    assert.strictEqual(result.valid, false);
  });
});
```

---

## 2. Testing GitHub Script Functions

### 2.1 Helper Functions Module

**Create**: `scripts/github-helpers.js`

```javascript
/**
 * Posts a comment on an issue
 */
export async function postComment(github, context, message) {
  return await github.rest.issues.createComment({
    owner: context.repo.owner,
    repo: context.repo.repo,
    issue_number: context.payload.issue.number,
    body: message,
  });
}

/**
 * Sets labels on an issue
 */
export async function setLabels(github, context, labelsToAdd = [], labelsToRemove = []) {
  const currentLabels = context.payload.issue.labels.map((l) => l.name);
  const newLabels = currentLabels
    .filter((l) => !labelsToRemove.includes(l))
    .concat(labelsToAdd.filter((l) => !currentLabels.includes(l)));

  return await github.rest.issues.setLabels({
    owner: context.repo.owner,
    repo: context.repo.repo,
    issue_number: context.payload.issue.number,
    labels: newLabels,
  });
}

/**
 * Fetches issue body from a GitHub URL
 */
export async function fetchIssueBody(github, url) {
  const match = url.match(/github\.com\/([^/]+)\/([^/]+)\/issues\/(\d+)/);
  if (!match) return null;

  const [, owner, repo, issue_number] = match;
  try {
    const { data } = await github.rest.issues.get({
      owner,
      repo,
      issue_number: parseInt(issue_number, 10),
    });
    return data.body || '';
  } catch (err) {
    return null;
  }
}

/**
 * Validates GitHub issue URL format
 */
export function isValidGitHubIssueUrl(url) {
  const pattern = /^https:\/\/github\.com\/[^/]+\/[^/]+\/issues\/\d+$/;
  return pattern.test(url);
}
```

### 2.2 Tests for Helper Functions

**Create**: `test/unit/github-helpers.test.js`

```javascript
import { describe, it } from 'node:test';
import assert from 'node:assert/strict';
import {
  postComment,
  setLabels,
  fetchIssueBody,
  isValidGitHubIssueUrl,
} from '../../scripts/github-helpers.js';

describe('GitHub Helpers', () => {
  describe('postComment', () => {
    it('posts comment with correct parameters', async () => {
      let capturedParams;

      const mockGithub = {
        rest: {
          issues: {
            createComment: async (params) => {
              capturedParams = params;
              return { data: { id: 1 } };
            },
          },
        },
      };

      const mockContext = {
        repo: { owner: 'test', repo: 'test' },
        payload: { issue: { number: 42 } },
      };

      await postComment(mockGithub, mockContext, 'Test message');

      assert.strictEqual(capturedParams.owner, 'test');
      assert.strictEqual(capturedParams.repo, 'test');
      assert.strictEqual(capturedParams.issue_number, 42);
      assert.strictEqual(capturedParams.body, 'Test message');
    });
  });

  describe('setLabels', () => {
    it('adds new labels', async () => {
      let finalLabels;

      const mockGithub = {
        rest: {
          issues: {
            setLabels: async ({ labels }) => {
              finalLabels = labels;
              return { data: {} };
            },
          },
        },
      };

      const mockContext = {
        repo: { owner: 'test', repo: 'test' },
        payload: {
          issue: {
            number: 1,
            labels: [{ name: 'existing' }],
          },
        },
      };

      await setLabels(mockGithub, mockContext, ['new-label'], []);

      assert.ok(finalLabels.includes('existing'));
      assert.ok(finalLabels.includes('new-label'));
    });

    it('removes specified labels', async () => {
      let finalLabels;

      const mockGithub = {
        rest: {
          issues: {
            setLabels: async ({ labels }) => {
              finalLabels = labels;
              return { data: {} };
            },
          },
        },
      };

      const mockContext = {
        repo: { owner: 'test', repo: 'test' },
        payload: {
          issue: {
            number: 1,
            labels: [{ name: 'keep' }, { name: 'remove' }],
          },
        },
      };

      await setLabels(mockGithub, mockContext, [], ['remove']);

      assert.ok(finalLabels.includes('keep'));
      assert.ok(!finalLabels.includes('remove'));
    });

    it('adds and removes labels simultaneously', async () => {
      let finalLabels;

      const mockGithub = {
        rest: {
          issues: {
            setLabels: async ({ labels }) => {
              finalLabels = labels;
              return { data: {} };
            },
          },
        },
      };

      const mockContext = {
        repo: { owner: 'test', repo: 'test' },
        payload: {
          issue: {
            number: 1,
            labels: [{ name: 'validation: blocked' }],
          },
        },
      };

      await setLabels(mockGithub, mockContext, ['validation: pending'], ['validation: blocked']);

      assert.ok(finalLabels.includes('validation: pending'));
      assert.ok(!finalLabels.includes('validation: blocked'));
    });
  });

  describe('fetchIssueBody', () => {
    it('fetches issue body from valid URL', async () => {
      const mockGithub = {
        rest: {
          issues: {
            get: async ({ owner, repo, issue_number }) => ({
              data: {
                id: issue_number,
                body: 'Test issue body',
              },
            }),
          },
        },
      };

      const url = 'https://github.com/test-org/test-repo/issues/123';
      const body = await fetchIssueBody(mockGithub, url);

      assert.strictEqual(body, 'Test issue body');
    });

    it('returns null for invalid URL', async () => {
      const mockGithub = {
        rest: {
          issues: {
            get: async () => ({ data: { body: 'Should not be called' } }),
          },
        },
      };

      const body = await fetchIssueBody(mockGithub, 'invalid-url');

      assert.strictEqual(body, null);
    });

    it('returns null when issue not found', async () => {
      const mockGithub = {
        rest: {
          issues: {
            get: async () => {
              throw new Error('Not found');
            },
          },
        },
      };

      const url = 'https://github.com/test/test/issues/999';
      const body = await fetchIssueBody(mockGithub, url);

      assert.strictEqual(body, null);
    });
  });

  describe('isValidGitHubIssueUrl', () => {
    it('validates correct GitHub issue URLs', () => {
      const validUrls = [
        'https://github.com/owner/repo/issues/1',
        'https://github.com/my-org/my-repo/issues/12345',
      ];

      for (const url of validUrls) {
        assert.ok(isValidGitHubIssueUrl(url), `Should validate: ${url}`);
      }
    });

    it('rejects invalid URLs', () => {
      const invalidUrls = [
        'http://github.com/owner/repo/issues/1', // http instead of https
        'https://github.com/owner/repo/pull/1', // pull request, not issue
        'https://github.com/owner/repo/issues', // no issue number
        'github.com/owner/repo/issues/1', // no protocol
        'https://gitlab.com/owner/repo/issues/1', // wrong domain
      ];

      for (const url of invalidUrls) {
        assert.ok(!isValidGitHubIssueUrl(url), `Should reject: ${url}`);
      }
    });
  });
});
```

---

## 3. Testing YAML Validation

### 3.1 YAML Workflow Validator

**Create**: `scripts/validate-workflow.js`

```javascript
import YAML from 'js-yaml';
import Ajv from 'ajv';
import { readFile } from 'fs/promises';

const ajv = new Ajv({ allErrors: true });

// Simplified GitHub Actions workflow schema
const workflowSchema = {
  type: 'object',
  required: ['name', 'on', 'jobs'],
  properties: {
    name: { type: 'string', minLength: 1 },
    on: {
      oneOf: [{ type: 'string' }, { type: 'array', items: { type: 'string' } }, { type: 'object' }],
    },
    permissions: { type: 'object' },
    concurrency: {
      oneOf: [{ type: 'string' }, { type: 'object' }],
    },
    jobs: {
      type: 'object',
      minProperties: 1,
      patternProperties: {
        '^[a-zA-Z_][a-zA-Z0-9_-]*$': {
          type: 'object',
          required: ['runs-on'],
          properties: {
            'runs-on': {
              oneOf: [{ type: 'string' }, { type: 'array' }],
            },
            'timeout-minutes': { type: 'number' },
            steps: {
              type: 'array',
              items: { type: 'object' },
            },
            outputs: { type: 'object' },
            if: { type: 'string' },
            needs: {
              oneOf: [{ type: 'string' }, { type: 'array', items: { type: 'string' } }],
            },
          },
        },
      },
    },
  },
};

const validate = ajv.compile(workflowSchema);

export async function validateWorkflowFile(filePath) {
  try {
    const content = await readFile(filePath, 'utf8');
    const data = YAML.load(content);

    const valid = validate(data);

    if (!valid) {
      return {
        valid: false,
        errors: validate.errors.map((err) => ({
          path: err.instancePath,
          message: err.message,
          params: err.params,
        })),
      };
    }

    return { valid: true, data };
  } catch (err) {
    return {
      valid: false,
      errors: [{ message: err.message }],
    };
  }
}
```

### 3.2 Tests for YAML Validation

**Create**: `test/unit/validate-workflow.test.js`

```javascript
import { describe, it, test } from 'node:test';
import assert from 'node:assert/strict';
import { writeFile, unlink } from 'fs/promises';
import { validateWorkflowFile } from '../../scripts/validate-workflow.js';

describe('validateWorkflowFile', () => {
  const testFile = 'test-workflow.yml';

  test('validates correct workflow', async () => {
    const validWorkflow = `
name: Test Workflow
on: push
jobs:
  test:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v4
      - run: echo "test"
`;

    await writeFile(testFile, validWorkflow);

    const result = await validateWorkflowFile(testFile);

    await unlink(testFile);

    assert.ok(result.valid);
    assert.ok(result.data);
    assert.strictEqual(result.data.name, 'Test Workflow');
  });

  test('rejects workflow without name', async () => {
    const invalidWorkflow = `
on: push
jobs:
  test:
    runs-on: ubuntu-latest
    steps:
      - run: echo "test"
`;

    await writeFile(testFile, invalidWorkflow);

    const result = await validateWorkflowFile(testFile);

    await unlink(testFile);

    assert.strictEqual(result.valid, false);
    assert.ok(result.errors.length > 0);
  });

  test('rejects workflow without jobs', async () => {
    const invalidWorkflow = `
name: Test
on: push
`;

    await writeFile(testFile, invalidWorkflow);

    const result = await validateWorkflowFile(testFile);

    await unlink(testFile);

    assert.strictEqual(result.valid, false);
  });

  test('validates matrix strategy', async () => {
    const matrixWorkflow = `
name: Matrix Test
on: push
jobs:
  test:
    runs-on: ubuntu-latest
    strategy:
      matrix:
        node-version: [18, 20, 22]
    steps:
      - uses: actions/setup-node@v4
        with:
          node-version: \${{ matrix.node-version }}
`;

    await writeFile(testFile, matrixWorkflow);

    const result = await validateWorkflowFile(testFile);

    await unlink(testFile);

    assert.ok(result.valid);
  });

  test('handles invalid YAML syntax', async () => {
    const invalidYaml = `
name: Test
on: push
jobs:
  test:
    runs-on: ubuntu-latest
    steps:
      - name: Invalid
        run: |
          echo "Missing quote
`;

    await writeFile(testFile, invalidYaml);

    const result = await validateWorkflowFile(testFile);

    await unlink(testFile);

    assert.strictEqual(result.valid, false);
    assert.ok(result.errors[0].message.includes('unexpected'));
  });
});
```

---

## 4. Testing Label Taxonomy

### 4.1 Label Validator

**Create**: `scripts/label-validator.js`

```javascript
export const LABEL_TAXONOMY = {
  prefixes: ['type:', 'priority:', 'status:', 'validation:', 'scope:'],
  types: ['test', 'bug', 'feature', 'docs', 'chore'],
  priorities: ['critical', 'high', 'medium', 'low'],
  statuses: ['pending', 'in-progress', 'blocked', 'resolved'],
  validations: ['pending', 'blocked', 'passed'],
  scopes: ['workflow', 'issue', 'pr', 'docs'],
};

export function validateLabel(label) {
  const errors = [];

  // Check if label has valid prefix
  const hasValidPrefix = LABEL_TAXONOMY.prefixes.some((prefix) => label.startsWith(prefix));

  if (!hasValidPrefix) {
    errors.push(`Label "${label}" doesn't use valid prefix: ${LABEL_TAXONOMY.prefixes.join(', ')}`);
    return { valid: false, errors };
  }

  // Extract prefix and value
  const [prefix, ...valueParts] = label.split(':');
  const value = valueParts.join(':');

  if (!value) {
    errors.push(`Label "${label}" has prefix but no value`);
    return { valid: false, errors };
  }

  // Validate specific taxonomy
  const taxonomyKey = prefix.replace(':', '') + 's'; // e.g., 'type:' -> 'types'
  const validValues = LABEL_TAXONOMY[taxonomyKey];

  if (validValues && !validValues.includes(value)) {
    errors.push(`Invalid ${prefix} value "${value}". Valid values: ${validValues.join(', ')}`);
    return { valid: false, errors };
  }

  return { valid: true, errors: [] };
}

export function validateLabelSet(labels) {
  const errors = [];
  const warnings = [];

  // Validate each label
  for (const label of labels) {
    const result = validateLabel(label);
    if (!result.valid) {
      errors.push(...result.errors);
    }
  }

  // Check for required labels
  const hasTypeLabel = labels.some((l) => l.startsWith('type:'));
  if (!hasTypeLabel) {
    errors.push('Missing required type: label');
  }

  // Check for duplicate prefixes
  const prefixCounts = {};
  for (const label of labels) {
    const prefix = label.split(':')[0] + ':';
    prefixCounts[prefix] = (prefixCounts[prefix] || 0) + 1;
  }

  for (const [prefix, count] of Object.entries(prefixCounts)) {
    if (count > 1 && prefix === 'type:') {
      warnings.push(`Multiple ${prefix} labels found (${count}). Consider using only one.`);
    }
  }

  return {
    valid: errors.length === 0,
    errors,
    warnings,
  };
}
```

### 4.2 Tests for Label Validation

**Create**: `test/unit/label-validator.test.js`

```javascript
import { describe, it } from 'node:test';
import assert from 'node:assert/strict';
import { validateLabel, validateLabelSet } from '../../scripts/label-validator.js';

describe('Label Validator', () => {
  describe('validateLabel', () => {
    it('validates correct type labels', () => {
      const validLabels = ['type:test', 'type:bug', 'type:feature'];

      for (const label of validLabels) {
        const result = validateLabel(label);
        assert.ok(result.valid, `Should validate: ${label}`);
      }
    });

    it('validates correct priority labels', () => {
      const validLabels = ['priority:critical', 'priority:high', 'priority:low'];

      for (const label of validLabels) {
        const result = validateLabel(label);
        assert.ok(result.valid);
      }
    });

    it('rejects labels without valid prefix', () => {
      const result = validateLabel('invalid-label');

      assert.strictEqual(result.valid, false);
      assert.ok(result.errors[0].includes("doesn't use valid prefix"));
    });

    it('rejects labels with invalid type value', () => {
      const result = validateLabel('type:invalid');

      assert.strictEqual(result.valid, false);
      assert.ok(result.errors[0].includes('Invalid type: value'));
    });

    it('rejects labels with prefix but no value', () => {
      const result = validateLabel('type:');

      assert.strictEqual(result.valid, false);
      assert.ok(result.errors[0].includes('has prefix but no value'));
    });

    it('validates validation labels', () => {
      const validLabels = ['validation:pending', 'validation:blocked', 'validation:passed'];

      for (const label of validLabels) {
        const result = validateLabel(label);
        assert.ok(result.valid);
      }
    });
  });

  describe('validateLabelSet', () => {
    it('validates complete label set', () => {
      const labels = ['type:test', 'priority:high', 'status:pending'];

      const result = validateLabelSet(labels);

      assert.ok(result.valid);
      assert.strictEqual(result.errors.length, 0);
    });

    it('requires type label', () => {
      const labels = ['priority:high', 'status:pending'];

      const result = validateLabelSet(labels);

      assert.strictEqual(result.valid, false);
      assert.ok(result.errors.some((e) => e.includes('Missing required type: label')));
    });

    it('warns about multiple type labels', () => {
      const labels = ['type:test', 'type:bug', 'priority:high'];

      const result = validateLabelSet(labels);

      // Should be valid but with warning
      assert.ok(result.valid);
      assert.ok(result.warnings.length > 0);
      assert.ok(result.warnings[0].includes('Multiple type: labels'));
    });

    it('collects errors from individual labels', () => {
      const labels = ['type:test', 'invalid-label', 'priority:invalid'];

      const result = validateLabelSet(labels);

      assert.strictEqual(result.valid, false);
      assert.ok(result.errors.length >= 2);
    });
  });
});
```

---

## 5. Testing Decision Log Writer

### 5.1 Decision Log Formatter

**Create**: `scripts/decision-log-formatter.js`

```javascript
/**
 * Formats validation results into decision log entry
 */
export function formatDecisionLog(params) {
  const {
    issueNumber,
    passNumber,
    status,
    workflowName,
    triggerEvent,
    validationResults,
    committerName,
    timestamp = new Date().toISOString(),
  } = params;

  let log = `## Pass ${passNumber}: ${workflowName}\n\n`;
  log += `**Status**: ${status}\n`;
  log += `**Triggered by**: @${committerName}\n`;
  log += `**Event**: ${triggerEvent}\n`;
  log += `**Timestamp**: ${timestamp}\n\n`;

  if (validationResults) {
    const results =
      typeof validationResults === 'string' ? JSON.parse(validationResults) : validationResults;

    if (results.errors && results.errors.length > 0) {
      log += `### Errors (${results.errors.length})\n\n`;
      results.errors.forEach((err) => {
        log += `- ${err}\n`;
      });
      log += '\n';
    }

    if (results.warnings && results.warnings.length > 0) {
      log += `### Warnings (${results.warnings.length})\n\n`;
      results.warnings.forEach((warn) => {
        log += `- ${warn}\n`;
      });
      log += '\n';
    }

    if (results.passed && results.passed.length > 0) {
      log += `### Validations Passed (${results.passed.length})\n\n`;
      results.passed.forEach((pass) => {
        log += `- ${pass}\n`;
      });
      log += '\n';
    }
  }

  log += '---\n\n';

  return log;
}

/**
 * Generates decision log filename
 */
export function getDecisionLogFilename(issueNumber) {
  const paddedNumber = String(issueNumber).padStart(4, '0');
  return `issue_${paddedNumber}_decision_log.md`;
}
```

### 5.2 Tests for Decision Log

**Create**: `test/unit/decision-log-formatter.test.js`

```javascript
import { describe, it } from 'node:test';
import assert from 'node:assert/strict';
import { formatDecisionLog, getDecisionLogFilename } from '../../scripts/decision-log-formatter.js';

describe('Decision Log Formatter', () => {
  describe('formatDecisionLog', () => {
    it('formats successful validation', () => {
      const params = {
        issueNumber: 123,
        passNumber: 1,
        status: 'Success',
        workflowName: 'Validate Issue Format',
        triggerEvent: 'issues',
        validationResults: {
          errors: [],
          warnings: [],
          passed: ['Issue body is not empty', 'Test ID format valid'],
        },
        committerName: 'testuser',
        timestamp: '2025-01-01T00:00:00Z',
      };

      const log = formatDecisionLog(params);

      assert.ok(log.includes('## Pass 1: Validate Issue Format'));
      assert.ok(log.includes('**Status**: Success'));
      assert.ok(log.includes('@testuser'));
      assert.ok(log.includes('Issue body is not empty'));
      assert.ok(!log.includes('### Errors'));
    });

    it('formats failed validation with errors', () => {
      const params = {
        issueNumber: 456,
        passNumber: 2,
        status: 'Failed',
        workflowName: 'Validate Issue Format',
        triggerEvent: 'issue_comment',
        validationResults: {
          errors: ['Missing required section: Test ID', 'Insufficient IB cases'],
          warnings: ['IB-01: Description too short'],
          passed: ['Issue body is not empty'],
        },
        committerName: 'reviewer',
      };

      const log = formatDecisionLog(params);

      assert.ok(log.includes('## Pass 2'));
      assert.ok(log.includes('**Status**: Failed'));
      assert.ok(log.includes('### Errors (2)'));
      assert.ok(log.includes('Missing required section: Test ID'));
      assert.ok(log.includes('### Warnings (1)'));
      assert.ok(log.includes('### Validations Passed (1)'));
    });

    it('handles JSON string validation results', () => {
      const params = {
        issueNumber: 789,
        passNumber: 1,
        status: 'Success',
        workflowName: 'Test',
        triggerEvent: 'push',
        validationResults: JSON.stringify({
          errors: [],
          warnings: [],
          passed: ['All checks passed'],
        }),
        committerName: 'bot',
      };

      const log = formatDecisionLog(params);

      assert.ok(log.includes('All checks passed'));
    });
  });

  describe('getDecisionLogFilename', () => {
    it('generates filename with zero padding', () => {
      assert.strictEqual(getDecisionLogFilename(1), 'issue_0001_decision_log.md');

      assert.strictEqual(getDecisionLogFilename(42), 'issue_0042_decision_log.md');

      assert.strictEqual(getDecisionLogFilename(123), 'issue_0123_decision_log.md');

      assert.strictEqual(getDecisionLogFilename(12345), 'issue_12345_decision_log.md');
    });
  });
});
```

---

## 6. Integration Tests

### 6.1 Full Workflow Integration Test

**Create**: `test/integration/workflow-integration.test.js`

```javascript
import { describe, it, before } from 'node:test';
import assert from 'node:assert/strict';
import { validateIssue } from '../../scripts/validate-issue.js';
import { formatDecisionLog } from '../../scripts/decision-log-formatter.js';
import { validateLabelSet } from '../../scripts/label-validator.js';

describe('Workflow Integration', () => {
  const sampleIssueBody = `
### Test ID
T-001

### Suite (c1) Issue URL
https://github.com/test/test/issues/1

### Parent feature/bug (p) URL
_No response_

### Purpose
This is a comprehensive test to validate the entire workflow integration

### In-Bounds Case(s) (IB≥1)
- IB-01: Valid user input
  - Input: Valid data
  - Steps: Process data
  - Expected: Success

### Out-of-Bounds Case(s) (OOB≥2 required)
- OOB-01: Invalid user input
  - Input: Malformed data
  - Expected: Error handling
- OOB-02: Empty input
  - Input: Empty string
  - Expected: Validation error

### Expected Behavior (authoritative)
System should validate input and return appropriate response

### Validation Method
Automated tests with manual verification

### Validation Gate
- [ ] ✅ test.validated = true
`;

  it('complete validation workflow', async () => {
    // 1. Mock GitHub API
    const mockGithub = {
      rest: {
        issues: {
          get: async () => ({
            data: { id: 1, body: 'Parent issue body' },
          }),
          createComment: async (params) => {
            assert.ok(params.body);
            return { data: { id: 1 } };
          },
          setLabels: async (params) => {
            assert.ok(Array.isArray(params.labels));
            return { data: {} };
          },
        },
      },
    };

    const mockContext = {
      payload: {
        issue: {
          number: 123,
          body: sampleIssueBody,
          labels: [{ name: 'type:test' }],
        },
      },
      repo: { owner: 'test', repo: 'test' },
    };

    // 2. Run validation
    const validationResult = await validateIssue({
      github: mockGithub,
      context: mockContext,
      config: { IB_MIN: 1, OOB_MIN: 2 },
    });

    assert.ok(validationResult.valid);
    assert.strictEqual(validationResult.errors.length, 0);

    // 3. Validate labels
    const labels = ['type:test', 'validation:pending'];
    const labelResult = validateLabelSet(labels);

    assert.ok(labelResult.valid);

    // 4. Generate decision log
    const logEntry = formatDecisionLog({
      issueNumber: 123,
      passNumber: 1,
      status: 'Success',
      workflowName: 'Validate Issue Format',
      triggerEvent: 'issues',
      validationResults: {
        errors: validationResult.errors,
        warnings: validationResult.warnings,
        passed: validationResult.validations,
      },
      committerName: 'testuser',
    });

    assert.ok(logEntry.includes('## Pass 1'));
    assert.ok(logEntry.includes('Success'));
  });

  it('handles validation failure workflow', async () => {
    const invalidIssueBody = `
### Test ID
INVALID

### Purpose
Too short
`;

    const mockGithub = {
      rest: {
        issues: {
          get: async () => ({ data: { id: 1, body: '' } }),
          createComment: async () => ({ data: { id: 1 } }),
          setLabels: async () => ({ data: {} }),
        },
      },
    };

    const mockContext = {
      payload: {
        issue: {
          number: 456,
          body: invalidIssueBody,
          labels: [],
        },
      },
      repo: { owner: 'test', repo: 'test' },
    };

    const validationResult = await validateIssue({
      github: mockGithub,
      context: mockContext,
      config: { IB_MIN: 1, OOB_MIN: 2 },
    });

    assert.strictEqual(validationResult.valid, false);
    assert.ok(validationResult.errors.length > 0);

    // Generate failure log
    const logEntry = formatDecisionLog({
      issueNumber: 456,
      passNumber: 1,
      status: 'Failed',
      workflowName: 'Validate Issue Format',
      triggerEvent: 'issues',
      validationResults: {
        errors: validationResult.errors,
        warnings: validationResult.warnings,
        passed: validationResult.validations,
      },
      committerName: 'testuser',
    });

    assert.ok(logEntry.includes('Failed'));
    assert.ok(logEntry.includes('### Errors'));
  });
});
```

---

## Running the Tests

### Package.json Scripts

```json
{
  "scripts": {
    "test": "node --test",
    "test:unit": "node --test test/unit/**/*.test.js",
    "test:integration": "node --test test/integration/**/*.test.js",
    "test:watch": "node --test --watch",
    "test:coverage": "node --test --experimental-test-coverage"
  }
}
```

### Run Tests

```bash
# All tests
npm test

# Unit tests only
npm run test:unit

# Integration tests only
npm run test:integration

# Watch mode
npm run test:watch

# With coverage
npm run test:coverage
```

---

**Last Updated**: 2025-11-09
