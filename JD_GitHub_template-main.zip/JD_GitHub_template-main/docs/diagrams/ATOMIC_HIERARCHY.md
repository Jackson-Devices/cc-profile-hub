# Atomic Hierarchy Diagrams

Visual representations of the 5-level atomic test hierarchy.

---

## Complete 5-Level Hierarchy

```mermaid
graph TD
    A[Feature/Bug/Improvement<br/>type: feature] --> B1[Sub-Feature 1<br/>role: sub-feature]
    A --> B2[Sub-Feature 2<br/>role: sub-feature]
    B1 --> C1[Function 1<br/>type: function]
    B1 --> C2[Function 2<br/>type: function]
    B2 --> C3[Function 3<br/>type: function]
    C1 --> D1[Test Suite 1<br/>role: test suite]
    C2 --> D2[Test Suite 2<br/>role: test suite]
    C3 --> D3[Test Suite 3<br/>role: test suite]
    D1 --> E1[Test IB-01<br/>type: test]
    D1 --> E2[Test OOB-01<br/>type: test]
    D1 --> E3[Test OOB-02<br/>type: test]
    D2 --> E4[Test IB-01<br/>type: test]
    D2 --> E5[Test OOB-01<br/>type: test]
    D2 --> E6[Test OOB-02<br/>type: test]
    D3 --> E7[Test IB-01<br/>type: test]
    D3 --> E8[Test OOB-01<br/>type: test]
    D3 --> E9[Test OOB-02<br/>type: test]

    style A fill:#3b82f6,color:#fff
    style B1 fill:#3b82f6,color:#fff
    style B2 fill:#3b82f6,color:#fff
    style C1 fill:#292524,color:#fff
    style C2 fill:#292524,color:#fff
    style C3 fill:#292524,color:#fff
    style D1 fill:#ec4899,color:#fff
    style D2 fill:#ec4899,color:#fff
    style D3 fill:#ec4899,color:#fff
    style E1 fill:#ec4899,color:#fff
    style E2 fill:#ec4899,color:#fff
    style E3 fill:#ec4899,color:#fff
    style E4 fill:#ec4899,color:#fff
    style E5 fill:#ec4899,color:#fff
    style E6 fill:#ec4899,color:#fff
    style E7 fill:#ec4899,color:#fff
    style E8 fill:#ec4899,color:#fff
    style E9 fill:#ec4899,color:#fff
```

**Legend:**

- 🔵 Blue: Work Type (Feature/Bug) + Sub-Features
- 🟤 Brown: Functions (Contracts)
- 🔴 Pink: Test Suites + Individual Tests

---

## Validation State Machine

```mermaid
stateDiagram-v2
    [*] --> Pending: Issue created with<br/>type: test label
    Pending --> Blocked: Validation fails<br/>(format errors, insufficient IB/OOB)
    Blocked --> Pending: Errors fixed,<br/>validation passes
    Pending --> Passed: Gate checked &<br/>requirements met
    Passed --> Pending: Code changes<br/>(gate auto-unchecked)
    Passed --> [*]: Issue closed<br/>(all tests pass)

    note right of Blocked
        validation: blocked
        - Format errors
        - Missing IB/OOB
        - Invalid test ID
    end note

    note right of Pending
        validation: pending
        - Format valid
        - Requirements met
        - Gate not checked
    end note

    note right of Passed
        validation: passed
        - All tests executed
        - Gate checked
        - Requirements met
    end note
```

---

## Workflow Execution Flow

```mermaid
sequenceDiagram
    participant User
    participant Issue
    participant Validate
    participant Gate
    participant Seed
    participant Logs

    User->>Issue: Create/Edit Test Issue
    Note over Issue: type: test label present

    Issue->>Validate: Auto-trigger (on issue open/edit)
    Validate->>Validate: Check format, sections, IB/OOB

    alt Validation Fails
        Validate->>Issue: Apply validation: blocked
        Validate->>Logs: Log failure details
        Validate->>User: Post error comment
    else Validation Passes
        Validate->>Issue: Apply validation: pending
        Validate->>Logs: Log success

        par Concurrent Workflows
            Issue->>Gate: Auto-trigger
            Gate->>Gate: Check IB/OOB requirements
            alt Gate Checked but Requirements Not Met
                Gate->>Issue: Uncheck gate,<br/>clear checklist
                Gate->>Issue: Apply workflow: blocked
                Gate->>Logs: Log violation
            else Requirements Met
                Gate->>Issue: Keep validation: pending
            end
        and
            Issue->>Seed: Auto-trigger
            Seed->>Seed: Generate run checklist
            Seed->>Issue: Add checklist to body
            Seed->>Logs: Log generation
        end
    end

    User->>Issue: Run tests, check boxes
    User->>Issue: Check validation gate

    Issue->>Gate: Auto-trigger (on edit)
    Gate->>Gate: Verify all requirements met
    Gate->>Issue: Apply validation: passed
    Gate->>Logs: Log success
```

---

## Test Execution Order

```mermaid
flowchart LR
    A[Run Checklist Generated] --> B[OOB-01<br/>Boundary Minimum]
    B --> C[IB-01<br/>Valid Baseline]
    C --> D[OOB-02<br/>Boundary Maximum]
    D --> E[OOB-03...OOB-N<br/>Additional Edge Cases]
    E --> F[IB-02...IB-N<br/>Additional Valid Cases]
    F --> G[All Tests Pass]
    G --> H[Check Validation Gate]
    H --> I[validation: passed]

    style B fill:#ef4444,color:#fff
    style D fill:#ef4444,color:#fff
    style E fill:#ef4444,color:#fff
    style C fill:#22c55e,color:#000
    style F fill:#22c55e,color:#000
    style I fill:#22c55e,color:#000
```

**Rationale:**

1. **OOB-01** tests boundary at minimum (e.g., empty input)
2. **IB-01** tests valid baseline (e.g., single valid item)
3. **OOB-02** tests boundary at maximum (e.g., overflow)
4. **Remaining** OOB cases test additional edge conditions
5. **Remaining** IB cases test additional valid scenarios

---

## Label Application Flow

```mermaid
flowchart TD
    A[Create Issue from Template] --> B{Which Template?}
    B -->|test.yml| C[Auto-apply:<br/>type: test<br/>validation: pending]
    B -->|test-suite.yml| D[Auto-apply:<br/>role: test suite]
    B -->|function.yml| E[Auto-apply:<br/>type: function]
    B -->|sub-feature.yml| F[Auto-apply:<br/>role: sub-feature]
    B -->|feature.yml| G[Manual label needed]

    C --> H[Validation Workflow Runs]
    D --> I[Manual Labels Required]
    E --> I
    F --> I
    G --> I

    H --> J{Validation Result?}
    J -->|Pass| K[Keep validation: pending]
    J -->|Fail| L[Apply validation: blocked]

    I --> M[Apply difficulty, ai-capability,<br/>workflow, test-type labels]

    style C fill:#22c55e,color:#000
    style D fill:#22c55e,color:#000
    style E fill:#22c55e,color:#000
    style F fill:#22c55e,color:#000
    style G fill:#f59e0b,color:#000
    style L fill:#ef4444,color:#fff
```

---

## Git Worktree Workflow

```mermaid
graph TB
    A[Main Repo<br/>/home/user/project] --> B[Phase 1 Worktree<br/>../project-worktrees/p0.2-phase1<br/>Branch: claude/p0.2-phase1-session123]
    A --> C[Phase 2A Worktree<br/>../project-worktrees/p0.2-phase2a<br/>Branch: claude/p0.2-phase2a-session123]
    A --> D[Phase 2B Worktree<br/>../project-worktrees/p0.2-phase2b<br/>Branch: claude/p0.2-phase2b-session123]
    A --> E[Phase 3 Worktree<br/>../project-worktrees/p0.2-phase3<br/>Branch: claude/p0.2-phase3-session123]

    B --> F[PR #1<br/>Design Template Schemas]
    C --> G[PR #2<br/>Create Feature Template]
    D --> H[PR #3<br/>Create Sub-Feature Template]
    E --> I[PR #4<br/>Integration & Documentation]

    F --> J[Human merges when ready]
    G --> J
    H --> J
    I --> J

    J --> K[All phases merged<br/>independently]

    style A fill:#6b7280,color:#fff
    style B fill:#3b82f6,color:#fff
    style C fill:#3b82f6,color:#fff
    style D fill:#3b82f6,color:#fff
    style E fill:#3b82f6,color:#fff
    style K fill:#22c55e,color:#000
```

**Benefits:**

- ✅ Each phase has own branch and PR
- ✅ Clean audit trail (one commit per phase)
- ✅ Parallel work (Phase 3 while Phase 1 in review)
- ✅ No commit pileup or garbled descriptions

---

## Test Categorization Dimensions

```mermaid
mindmap
  root((Test))
    Scope
      IB In-Bounds
      OOB Out-of-Bounds
    Complexity
      Simple
      Simple-Edge
      Complex
      Complex-Edge
    Environment
      Unit
      Integration
      E2E
      Synthetic
      Hardware
    Determinism
      Deterministic
      Time-Dependent
      Random
      Network
    Advanced Techniques
      PBT Property-Based
      Mutation
      Contract
      Fuzz
      Regression
    Security
      Injection
      Authentication
      Authorization
      Cryptography
      Validation
    Resources
      CPU
      Memory
      Time
      Network
      Storage
```

---

**Document Version:** 1.0
**Last Updated:** 2025-11-10
**Purpose:** Visual reference for atomic hierarchy and workflow processes
