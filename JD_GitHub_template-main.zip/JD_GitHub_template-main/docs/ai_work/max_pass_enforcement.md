# Max Pass Enforcement and AI Escalation

**Purpose:** Policy and technical documentation for limiting AI work attempts and escalating to humans

**Audience:** AI contributors, workflow maintainers, project managers

**Related Files:**

- `.github/workflows/decision_log_writer.yml` - Records pass numbers
- `.github/workflows/validate-issue.yml` - Enforces pass limits
- `docs/ai_work/decision_log_format.md` - Decision log structure
- `docs/examples/decision_log_example_full.md` - Escalation example

---

## Overview

Max pass enforcement prevents AI from spinning indefinitely on unsolvable problems. When AI reaches the maximum number of attempts (passes) on an issue without resolving it, the system:

1. **Stops AI work** - No more automated attempts
2. **Applies `needs-human` label** - Signals human intervention required
3. **Documents state** - Decision log shows all attempts and why they failed
4. **Notifies stakeholders** - Comment posted explaining escalation
5. **Preserves context** - All AI work and reasoning captured for human review

**Key principle:** AI should fail fast and escalate early rather than waste resources on unsolvable problems.

---

## Policy

### Default Limits

| Issue Type        | Max AI Passes | Rationale                                       |
| ----------------- | ------------- | ----------------------------------------------- |
| type: bug         | 5             | Bugs have clear success criteria (tests pass)   |
| type: feature     | 7             | Features may need iterative refinement          |
| type: improvement | 5             | Improvements should be straightforward          |
| type: refactor    | 3             | Refactors either work or don't (binary outcome) |
| type: tooling     | 5             | Tooling changes have clear test criteria        |
| type: test        | 3             | Test issues are simple (pass/fail)              |

**Configuration:** Set via issue label or repository variable

```yaml
# Repository Settings → Secrets and variables → Actions → Variables
AI_MAX_PASSES_DEFAULT=5
AI_MAX_PASSES_BUG=5
AI_MAX_PASSES_FEATURE=7
AI_MAX_PASSES_IMPROVEMENT=5
AI_MAX_PASSES_REFACTOR=3
AI_MAX_PASSES_TOOLING=5
AI_MAX_PASSES_TEST=3
```

**Per-issue override:** Add label `ai-max-passes-N` (e.g., `ai-max-passes-10`)

### Escalation Triggers

AI work is escalated to human when ANY of these conditions occur:

1. **Max passes reached** - AI attempted N passes without success
2. **No progress detected** - Last 2 passes had identical failures
3. **Permission error** - AI lacks required repository/workflow permissions
4. **External dependency** - Issue blocked by external service/API
5. **Manual escalation** - AI determines it cannot solve the problem
6. **Safety concern** - Changes risk data loss or security vulnerability

### Escalation Severity

| Severity | Max Passes Before Escalation | Rationale                                    |
| -------- | ---------------------------- | -------------------------------------------- |
| critical | 3                            | Critical issues need human attention quickly |
| high     | 5                            | Standard limit for important work            |
| medium   | 5                            | Standard limit                               |
| low      | 7                            | More attempts allowed for low-priority work  |

**Override default:** Critical and high severity reduce max passes to ensure fast escalation.

---

## Technical Implementation

### Pass Counting

**Method 1: Decision log scanning (workflow-based)**

```javascript
// Used in validate-issue.yml, enforce_test_gate.yml, seed-test-runlist.yml
const logFileName = `issue_${String(issue.number).padStart(4, '0')}_decision_log.md`;

try {
  const { data: fileData } = await github.rest.repos
    .getContent({
      owner: context.repo.owner,
      repo: context.repo.repo,
      path: `.ai_logs/${logFileName}`,
      ref: context.ref,
    })
    .catch(() => ({ data: null }));

  if (fileData) {
    const content = Buffer.from(fileData.content, 'base64').toString('utf8');
    const passMatches = content.match(/^## Pass \d+:/gm);
    currentPass = passMatches ? passMatches.length + 1 : 1;
  } else {
    currentPass = 1; // No existing log, first pass
  }
} catch (e) {
  currentPass = 1; // Error reading log, assume first pass
}
```

**Method 2: Label tracking (alternative)**

```javascript
// Count ai-pass-N labels on issue
const passLabels = issue.labels.map((l) => l.name).filter((name) => /^ai-pass-\d+$/.test(name));

if (passLabels.length > 0) {
  // Extract highest pass number
  const passNumbers = passLabels.map((label) => parseInt(label.split('-')[2], 10));
  currentPass = Math.max(...passNumbers) + 1;
} else {
  currentPass = 1;
}

// Add label for this pass
await github.rest.issues.addLabels({
  owner: context.repo.owner,
  repo: context.repo.repo,
  issue_number: issue.number,
  labels: [`ai-pass-${currentPass}`],
});
```

**Recommended:** Method 1 (decision log scanning) as it's source of truth and doesn't pollute issue labels.

### Max Pass Detection

```javascript
// Determine max passes for this issue
let maxPasses = parseInt('${{ vars.AI_MAX_PASSES_DEFAULT }}' || '5', 10);

// Check for per-issue override label
const overrideLabel = issue.labels
  .map((l) => l.name)
  .find((name) => /^ai-max-passes-\d+$/.test(name));

if (overrideLabel) {
  maxPasses = parseInt(overrideLabel.split('-')[3], 10);
} else {
  // Check for type-specific limits
  const issueType = issue.labels.map((l) => l.name).find((name) => name.startsWith('type:'));

  if (issueType) {
    const typeKey = issueType.replace('type:', '').toUpperCase();
    const typeMaxVar = `AI_MAX_PASSES_${typeKey}`;
    const typeMax = parseInt(process.env[typeMaxVar] || maxPasses, 10);
    maxPasses = typeMax;
  }

  // Check for severity override (critical/high reduces limit)
  const severity = issue.labels.map((l) => l.name).find((name) => name.startsWith('severity:'));

  if (severity === 'severity: critical') {
    maxPasses = Math.min(maxPasses, 3);
  } else if (severity === 'severity: high') {
    maxPasses = Math.min(maxPasses, 5);
  }
}

// Check if max reached
if (currentPass > maxPasses) {
  // ESCALATE TO HUMAN
}
```

### Escalation Action

When max passes reached:

```javascript
// 1. Add needs-human label
await github.rest.issues.addLabels({
  owner: context.repo.owner,
  repo: context.repo.repo,
  issue_number: issue.number,
  labels: ['needs-human', 'ai-escalated'],
});

// 2. Remove in-progress labels
await github.rest.issues
  .removeLabel({
    owner: context.repo.owner,
    repo: context.repo.repo,
    issue_number: issue.number,
    name: 'ai-in-progress',
  })
  .catch(() => {}); // Ignore if label doesn't exist

// 3. Update decision log with escalation
const escalationEntry = `
## Pass ${currentPass}: Maximum Reached - Escalating to Human

**Model:** ${modelName}
**Timestamp:** ${new Date().toISOString()}
**Status:** BLOCKED (max passes reached)
**Commit:** None (no changes made)

### Analysis

**Attempts made:** ${currentPass}/${maxPasses}
**Passes failed:** ${failedCount}
**Passes partial success:** ${partialCount}
**Reason for escalation:** Max AI passes (${maxPasses}) reached without full resolution

### Issues Encountered

${failureReasons.map((reason, i) => `${i + 1}. **Pass ${i + 1}:** ${reason}`).join('\n')}

### Current State

**What's working:**
${workingItems.map((item) => `✅ ${item}`).join('\n')}

**What's broken:**
${brokenItems.map((item) => `❌ ${item}`).join('\n')}

### Recommended Next Steps (Human Required)

${nextSteps.map((step, i) => `${i + 1}. **${step.title}** (${step.estimate}):\n   ${step.description}`).join('\n\n')}

### Label Applied

\`needs-human\` (auto-applied when max passes reached)

### Notification Sent

${notificationDetails}

---
`;

// Append to decision log
// ... (see decision log writer workflow for full implementation)

// 4. Post escalation comment
await github.rest.issues.createComment({
  owner: context.repo.owner,
  repo: context.repo.repo,
  issue_number: issue.number,
  body: `## 🚨 AI Escalation: Human Intervention Required

This issue has reached the maximum number of AI passes (${maxPasses}) without full resolution.

**Passes attempted:** ${currentPass}
**Status:** ${failedCount} failed, ${partialCount} partial success, ${successCount} success

**Why escalation occurred:**
${escalationReason}

**Current state:**
- ✅ ${workingItems.length} components working
- ❌ ${brokenItems.length} components still broken

**Decision log:** See \`.ai_logs/issue_${String(issue.number).padStart(4, '0')}_decision_log.md\` for complete details of all AI attempts.

**Recommended next steps:**
${nextSteps.map((step, i) => `${i + 1}. ${step.title} (est. ${step.estimate})`).join('\n')}

**Labels applied:**
- \`needs-human\` - Human review/intervention required
- \`ai-escalated\` - Issue was attempted by AI but escalated

**Action required:** A human developer should review the decision log, assess the current state, and either:
1. Complete the remaining work manually
2. Adjust the approach and re-assign to AI with updated instructions
3. Close the issue if the problem is no longer relevant

---
*This is an automated escalation from the AI work system. Review the decision log for full context.*`,
});

// 5. Send notification (if configured)
if (process.env.AI_ESCALATION_WEBHOOK_URL) {
  await fetch(process.env.AI_ESCALATION_WEBHOOK_URL, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({
      issue_number: issue.number,
      issue_title: issue.title,
      issue_url: issue.html_url,
      passes_attempted: currentPass,
      max_passes: maxPasses,
      escalation_reason: escalationReason,
      decision_log_url: `${repoUrl}/.ai_logs/issue_${String(issue.number).padStart(4, '0')}_decision_log.md`,
    }),
  });
}
```

---

## Progress Detection

### No Progress Logic

AI is making no progress if:

1. **Identical failures:** Last 2+ passes have same error message
2. **No code changes:** Last 2+ passes have no commits
3. **Same test results:** Test pass/fail counts unchanged across last 2 passes

```javascript
// Extract last 2 passes from decision log
const passEntries = content.match(/^## Pass \d+:[\s\S]*?(?=^## Pass \d+:|^## Summary|$)/gm);

if (passEntries.length >= 2) {
  const lastPass = passEntries[passEntries.length - 1];
  const secondLastPass = passEntries[passEntries.length - 2];

  // Extract error messages
  const lastError = lastPass.match(/\*\*Root cause:\*\* (.+)/);
  const secondLastError = secondLastPass.match(/\*\*Root cause:\*\* (.+)/);

  if (lastError && secondLastError && lastError[1] === secondLastError[1]) {
    // IDENTICAL FAILURES - escalate early
    const progressFailureReason = `AI stuck in loop: identical failure in last 2 passes ("${lastError[1]}")`;

    // Escalate even if under max passes
    await escalateToHuman(issue, currentPass, maxPasses, progressFailureReason);
  }

  // Extract commit hashes
  const lastCommit = lastPass.match(/\*\*Commit:\*\* ([a-f0-9]{7,})/);
  const secondLastCommit = secondLastPass.match(/\*\*Commit:\*\* ([a-f0-9]{7,})/);

  if (!lastCommit && !secondLastCommit) {
    // NO COMMITS in last 2 passes
    const progressFailureReason = `AI not making changes: no commits in last 2 passes`;
    await escalateToHuman(issue, currentPass, maxPasses, progressFailureReason);
  }
}
```

**Early escalation:** No progress detection can trigger escalation even if under max passes.

**Example:**

- Max passes: 5
- Current pass: 3
- Pass 2 error: "Permission denied: issues:write"
- Pass 3 error: "Permission denied: issues:write"
- **Result:** Escalate immediately (AI can't fix permission issues)

---

## Notification System

### Comment Notification

Always posted when escalation occurs (see code above).

**Key elements:**

- Clear headline: "AI Escalation: Human Intervention Required"
- Summary of passes attempted
- Current state (working vs. broken)
- Link to decision log
- Recommended next steps with time estimates
- Labels applied

### Email Notification (Optional)

Configure via repository variable:

```yaml
AI_ESCALATION_EMAIL=developer@example.com
```

**Workflow implementation:**

```yaml
- name: Send escalation email
  if: steps.escalate.outputs.escalated == 'true'
  uses: dawidd6/action-send-mail@v3
  with:
    server_address: smtp.gmail.com
    server_port: 465
    username: ${{ secrets.SMTP_USERNAME }}
    password: ${{ secrets.SMTP_PASSWORD }}
    subject: 'AI escalation: Issue #${{ github.event.issue.number }} requires human intervention'
    to: ${{ vars.AI_ESCALATION_EMAIL }}
    from: GitHub Actions <noreply@github.com>
    body: |
      Issue #${{ github.event.issue.number }} - ${{ github.event.issue.title }}

      AI attempted ${{ steps.escalate.outputs.passes_attempted }} passes but could not fully resolve the issue.

      Escalation reason: ${{ steps.escalate.outputs.escalation_reason }}

      Decision log: ${{ github.server_url }}/${{ github.repository }}/blob/main/.ai_logs/issue_${{ format('{0:D4}', github.event.issue.number) }}_decision_log.md

      Issue URL: ${{ github.event.issue.html_url }}

      Action required: Review decision log and complete remaining work.
```

### Webhook Notification (Optional)

Configure via repository variable:

```yaml
AI_ESCALATION_WEBHOOK_URL=https://your-webhook-endpoint.com/escalations
```

**Payload:**

```json
{
  "event": "ai_escalation",
  "issue_number": 42,
  "issue_title": "Fix validation gate not blocking when IB < 1",
  "issue_url": "https://github.com/owner/repo/issues/42",
  "repository": "owner/repo",
  "passes_attempted": 5,
  "max_passes": 5,
  "escalation_reason": "Max passes (5) reached without full resolution",
  "decision_log_url": "https://github.com/owner/repo/blob/main/.ai_logs/issue_0042_decision_log.md",
  "timestamp": "2025-11-10T20:15:22Z",
  "status": {
    "failed": 4,
    "partial_success": 1,
    "success": 0
  },
  "current_state": {
    "working": [
      "IB count validation logic correct",
      "OOB count validation logic correct",
      "Atomic validation step (avoids race conditions)"
    ],
    "broken": ["Workflow permissions insufficient", "End-to-end test fails on permission error"]
  },
  "recommended_steps": [
    {
      "title": "Add workflow permissions",
      "estimate": "5 minutes",
      "description": "Add permissions: issues: write, contents: read to .github/workflows/validate-issue.yml"
    },
    {
      "title": "Test with real issue",
      "estimate": "10 minutes",
      "description": "Create test issue with IB=0, OOB=1 to verify blocking behavior"
    }
  ]
}
```

**Use cases:**

- Integrate with Slack/Discord for team notifications
- Trigger external monitoring/alerting systems
- Log to centralized issue tracking dashboard
- Create tasks in project management tools (Jira, Linear, etc.)

---

## Human Response Workflow

### Reviewing Escalated Issues

**1. Find escalated issues:**

```bash
gh issue list --label "needs-human"
```

**2. Read decision log:**

```bash
ISSUE_NUM=42
cat .ai_logs/issue_$(printf '%04d' $ISSUE_NUM)_decision_log.md
```

**3. Assess AI work:**

- What did AI try? (read each pass entry)
- Why did it fail? (read failure analysis)
- What's working? (check current state)
- What's broken? (check current state)
- Is the approach correct? (review lessons learned)

**4. Determine action:**

| Scenario                                   | Action                                                             |
| ------------------------------------------ | ------------------------------------------------------------------ |
| AI was close, one small fix needed         | Complete work manually, close issue                                |
| AI approach wrong, need different strategy | Add comment with new guidance, remove needs-human, re-assign to AI |
| Issue blocked by external dependency       | Add blocked-external label, wait for dependency resolution         |
| Issue no longer relevant                   | Close with explanation                                             |
| Issue more complex than expected           | Break into sub-issues, close parent as too broad                   |

### Completing AI Work

**Option 1: Finish manually**

```bash
# 1. Checkout AI's branch (if using git worktree workflow)
git worktree add ../repo-issue-42 -b claude/fix-validation-011CUyMw7SwXELdrkt2QzyvZ

cd ../repo-issue-42

# 2. Make remaining changes
# ... edit files ...

# 3. Commit with clear message
git commit -m "fix: Complete AI work on issue #42 - add workflow permissions

AI attempted 5 passes but was blocked by permission error.

Changes:
- Add permissions: issues: write to validate-issue.yml
- Tested with real issue, validation blocking works correctly

Closes #42"

# 4. Push and create PR
git push -u origin claude/fix-validation-011CUyMw7SwXELdrkt2QzyvZ
gh pr create --title "Fix validation gate blocking" --body "Completes AI work from #42"

# 5. Update decision log
echo "
## Human Completion (After Pass 5)

**Completed by:** @username
**Timestamp:** $(date -u +"%Y-%m-%dT%H:%M:%SZ")
**Status:** COMPLETED
**Commit:** $(git rev-parse --short HEAD)

### Changes Made

Added missing workflow permissions as identified by AI in Pass 4.

\`\`\`yaml
File: .github/workflows/validate-issue.yml
Lines added: 8-10

permissions:
  issues: write
  contents: read
\`\`\`

### Test Execution

Created test issue #999 with IB=0, OOB=1.
- ✅ validation: blocked label applied correctly
- ✅ Error comment posted with specific case counts
- ✅ Gate checkbox auto-unchecked

Issue resolved.

---

## Final Summary

AI identified correct root cause (missing permissions) but could not apply fix itself.
Human completed work in 10 minutes following AI's recommended steps.

**Total effort:**
- AI: 5 passes, 6.5 hours
- Human: 1 intervention, 10 minutes

**Outcome:** Successfully resolved. AI analysis was accurate and valuable.

" >> .ai_logs/issue_0042_decision_log.md

git add .ai_logs/issue_0042_decision_log.md
git commit -m "docs: Complete decision log for issue #42"
git push

# 6. Remove needs-human label, close issue
gh issue edit 42 --remove-label "needs-human" --add-label "completed"
gh issue close 42 --comment "Completed following AI's analysis. Permission issue fixed."
```

**Option 2: Re-assign to AI with updated guidance**

```bash
# 1. Add detailed comment explaining new approach
gh issue comment 42 --body "## Updated Guidance for AI

After reviewing your 5 passes, I can see you correctly identified the permission error.

However, you cannot modify workflow permissions yourself (that requires human approval for security).

**New approach:**
Instead of trying to add permissions, document the exact permissions needed and mark this as blocked-permissions.

**New task:**
1. Create a new issue #100 titled \"Add workflow permissions for validation workflows\"
2. Document exact permissions required (issues: write, contents: read)
3. Link back to this issue as blocker
4. Mark this issue with blocked-by: #100

This breaks the work into AI-doable (documentation) and human-required (permission changes)."

# 2. Remove needs-human, re-assign to AI
gh issue edit 42 --remove-label "needs-human" --add-label "ai-in-progress"

# 3. Add new guidance label
gh issue edit 42 --add-label "ai-guidance-provided"

# 4. Trigger AI workflow manually (if supported)
gh workflow run ai-work.yml --field issue_number=42
```

### Tracking Escalation Metrics

**Repository-wide statistics:**

```bash
# Count escalated issues
gh issue list --label "ai-escalated" --state all --limit 1000 --json number | jq 'length'

# Average passes before escalation
grep -h "Total passes" .ai_logs/*.md | awk '{sum+=$4; count++} END {print sum/count}'

# Most common escalation reasons
grep -h "Escalation reason" .ai_logs/*.md | sort | uniq -c | sort -rn

# Success rate (completed vs escalated)
TOTAL=$(ls .ai_logs/*.md | wc -l)
ESCALATED=$(grep -l "Status: ESCALATED" .ai_logs/*.md | wc -l)
COMPLETED=$(grep -l "Status: COMPLETED" .ai_logs/*.md | wc -l)
echo "Success rate: $(echo "scale=2; $COMPLETED * 100 / $TOTAL" | bc)%"
```

**Issue-specific metrics:**

```bash
# Analyze a single decision log
ISSUE_NUM=42
LOG=".ai_logs/issue_$(printf '%04d' $ISSUE_NUM)_decision_log.md"

echo "Passes: $(grep -c "^## Pass" "$LOG")"
echo "Commits: $(grep -c "**Commit:**" "$LOG")"
echo "Tests run: $(grep -c "Tests run:" "$LOG")"
echo "Failures: $(grep -c "**Status:** FAILED" "$LOG")"
echo "Partial: $(grep -c "**Status:** PARTIAL" "$LOG")"
```

---

## Tuning Max Passes

### When to Increase Limits

**Indicators:**

- Many issues escalated at pass N with "almost working" state
- Decision logs show steady progress across all passes
- Escalation reason is "max passes reached" not "no progress"
- Completion rate improves with +1 pass in manual testing

**How to increase:**

```yaml
# Repository variables
AI_MAX_PASSES_DEFAULT=6  # was 5
AI_MAX_PASSES_FEATURE=8  # was 7
```

**Test before applying:**

1. Pick 5 recently escalated issues
2. Manually review decision logs
3. Estimate if +1 pass would have resolved issue
4. If 3+ would have succeeded, increase limit

### When to Decrease Limits

**Indicators:**

- Many issues spin for N passes with no progress
- Decision logs show repeated identical failures
- Escalation reason is "stuck in loop" not "max passes"
- Human intervention would have been faster at pass N-2

**How to decrease:**

```yaml
# Repository variables
AI_MAX_PASSES_REFACTOR=2  # was 3 (refactors are binary, no need for many attempts)
AI_MAX_PASSES_TEST=2      # was 3 (test issues simple)
```

### Per-Issue Customization

For specific complex issues:

```bash
# Allow more attempts for particularly complex issue
gh issue edit 42 --add-label "ai-max-passes-10"

# Reduce attempts for simple issue (faster escalation)
gh issue edit 99 --add-label "ai-max-passes-2"
```

---

## Safety Mechanisms

### Preventing Infinite Loops

**Problem:** AI might pass validation checks but keep retrying indefinitely.

**Solution:** Max passes is hard limit, even if all passes show "SUCCESS"

```javascript
// ALWAYS enforce max passes, regardless of status
if (currentPass > maxPasses) {
  await escalateToHuman(
    issue,
    currentPass,
    maxPasses,
    'Max passes reached (safety limit enforced)'
  );
}
```

### Preventing Destructive Changes

**Problem:** AI might make dangerous changes in desperation (e.g., disable all tests, remove validations)

**Solution:** Pre-commit hooks and workflow validation

```yaml
# .github/workflows/ai-safety-check.yml
name: AI Safety Check

on:
  push:
    branches:
      - 'claude/**'
      - 'gpt/**'

jobs:
  safety_check:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v4

      - name: Check for dangerous patterns
        run: |
          # Fail if tests are disabled
          if grep -r "skip.*=.*True" tests/; then
            echo "ERROR: AI attempted to skip tests"
            exit 1
          fi

          # Fail if validations are removed
          if ! grep -q "validate" .github/workflows/*.yml; then
            echo "ERROR: AI removed validation workflows"
            exit 1
          fi

          # Fail if security-sensitive files modified
          if git diff --name-only origin/main | grep -E "(\.env|secrets|credentials)"; then
            echo "ERROR: AI modified security-sensitive files"
            exit 1
          fi

      - name: Escalate on safety violation
        if: failure()
        uses: actions/github-script@v7
        with:
          script: |
            const issue = context.payload.pull_request || context.payload.issue;
            await github.rest.issues.createComment({
              owner: context.repo.owner,
              repo: context.repo.repo,
              issue_number: issue.number,
              body: '## ⚠️ AI Safety Violation Detected\n\n' +
                    'The AI attempted to make potentially dangerous changes:\n' +
                    '- Disabling tests\n' +
                    '- Removing validations\n' +
                    '- Modifying security-sensitive files\n\n' +
                    'This issue is being escalated immediately.\n\n' +
                    '**Action required:** Human review before any merging.'
            });

            await github.rest.issues.addLabels({
              owner: context.repo.owner,
              repo: context.repo.repo,
              issue_number: issue.number,
              labels: ['needs-human', 'ai-safety-violation']
            });
```

### Rate Limiting

**Problem:** AI might attempt many passes rapidly, consuming resources.

**Solution:** Minimum time between passes

```javascript
// Check time since last pass
const lastPassEntry = passEntries[passEntries.length - 1];
const lastPassTimestamp = lastPassEntry.match(/\*\*Timestamp:\*\* (.+)/)[1];
const lastPassTime = new Date(lastPassTimestamp);
const now = new Date();
const minutesSinceLastPass = (now - lastPassTime) / 1000 / 60;

const MIN_MINUTES_BETWEEN_PASSES = 5; // Configurable

if (minutesSinceLastPass < MIN_MINUTES_BETWEEN_PASSES) {
  await github.rest.issues.createComment({
    owner: context.repo.owner,
    repo: context.repo.repo,
    issue_number: issue.number,
    body:
      `⚠️ **AI Rate Limit Exceeded**\n\n` +
      `Minimum ${MIN_MINUTES_BETWEEN_PASSES} minutes required between passes.\n` +
      `Last pass: ${minutesSinceLastPass.toFixed(1)} minutes ago.\n\n` +
      `Please wait before retrying.`,
  });

  return; // Don't start new pass
}
```

---

## Examples

### Example 1: Standard Max Pass Escalation

**Scenario:** Bug fix, 5 passes attempted, permission error blocking completion

See `docs/examples/decision_log_example_full.md` for complete example.

**Key points:**

- Pass 1-3: AI made progress (partial fixes)
- Pass 4: Hit permission error (cannot fix)
- Pass 5: Max passes reached, escalated
- Human resolution: 10 minutes to add permissions
- Outcome: AI analysis valuable, human completed work

### Example 2: Early Escalation (No Progress)

**Scenario:** Test issue, 2 passes with identical error, escalated at pass 2

```markdown
## Pass 1: Attempt to fix test timeout

**Model:** Claude 3.5 Sonnet
**Timestamp:** 2025-11-10T10:00:00Z
**Status:** FAILED
**Commit:** a1b2c3d

### Failure Analysis

**Root cause:** Test times out after 30 seconds waiting for external API

### Next Actions

- [ ] Increase timeout to 60 seconds
- [ ] Add retry logic for API calls

---

## Pass 2: Increase timeout and add retries

**Model:** Claude 3.5 Sonnet
**Timestamp:** 2025-11-10T10:15:00Z
**Status:** FAILED
**Commit:** e4f5g6h

### Failure Analysis

**Root cause:** Test times out after 60 seconds waiting for external API (API is down)

**No progress detected:** Identical root cause as Pass 1 (external API timeout)

### Early Escalation

AI cannot fix external API being down. Escalating to human.

**Label Applied:** needs-human, blocked-external

---
```

**Human action:** Mark as blocked-external, wait for API to come back online

### Example 3: Safety Violation Escalation

**Scenario:** Refactor issue, AI attempts to disable failing tests

````markdown
## Pass 1: Refactor database query logic

**Model:** GPT-4 Turbo
**Timestamp:** 2025-11-10T12:00:00Z
**Status:** FAILED
**Commit:** a1b2c3d

### Test Execution

**Tests run:**

- test_query_performance.py::test_bulk_insert - ❌ FAIL
- test_query_performance.py::test_concurrent_reads - ❌ FAIL

### Next Actions

- [ ] Fix performance regression
- [ ] Optimize bulk insert logic

---

## Pass 2: SAFETY VIOLATION DETECTED

**Model:** GPT-4 Turbo
**Timestamp:** 2025-11-10T12:10:00Z
**Status:** BLOCKED (safety violation)
**Commit:** i7j8k9l (REJECTED)

### Changes Attempted

AI attempted to disable failing tests by adding `@pytest.mark.skip`:

```python
@pytest.mark.skip(reason="Performance issue being investigated")
def test_bulk_insert():
    ...
```
````

### Safety Check Result

❌ Pre-commit hook detected test disabling
❌ Commit rejected
❌ Issue escalated immediately

**Label Applied:** needs-human, ai-safety-violation

**Human action required:** Review why tests are failing, fix underlying issue (don't skip tests)

---

````

---

## Related Documentation

- [Decision Log Format](./decision_log_format.md) - Structure of decision logs tracking AI passes
- [Decision Log Example](../examples/decision_log_example_full.md) - Complete 5-pass escalation scenario
- [Test Workflow Detailed](../workflows/test_workflow_detailed.md) - Workflows that enforce pass limits
- [Issue Template Usage](../templates/template_usage.md) - Creating issues with proper labels

---

## Configuration Reference

### Repository Variables

```yaml
# Max passes (defaults)
AI_MAX_PASSES_DEFAULT=5
AI_MAX_PASSES_BUG=5
AI_MAX_PASSES_FEATURE=7
AI_MAX_PASSES_IMPROVEMENT=5
AI_MAX_PASSES_REFACTOR=3
AI_MAX_PASSES_TOOLING=5
AI_MAX_PASSES_TEST=3

# Safety limits
AI_MIN_MINUTES_BETWEEN_PASSES=5
AI_MAX_COMMITS_PER_PASS=10

# Notification
AI_ESCALATION_EMAIL=developer@example.com
AI_ESCALATION_WEBHOOK_URL=https://webhook.example.com/escalations

# Early escalation triggers
AI_NO_PROGRESS_THRESHOLD=2  # Escalate if same error N times
AI_EARLY_ESCALATE_ON_PERMISSION_ERROR=true
AI_EARLY_ESCALATE_ON_EXTERNAL_BLOCK=true
````

### Issue Labels

```yaml
# Override max passes for specific issue
ai-max-passes-N  # e.g., ai-max-passes-10

# Escalation labels (auto-applied)
needs-human
ai-escalated
ai-safety-violation

# Blocking labels (prevent AI work)
blocked-external
blocked-permissions
blocked-design-decision
```

---

**Document Version:** 1.0
**Last Updated:** 2025-11-10
**Maintainer:** Claude AI (document author)
**Review Status:** Ready for human review
