# Pre-Commit Decision Gate Hook Specification

## Overview

A pre-commit hook that enforces atomic development workflow by requiring Claude (and human developers) to make intentional branching decisions before every commit. This prevents runaway automation, enforces atomic boundaries, and ensures clean git history.

## Problem Statement

Current state:

- ❌ Commits pile up on one branch (sequential dependencies)
- ❌ No checkpoint before committing
- ❌ Risk of runaway automation (100+ branches created)
- ❌ Lost atomic boundaries (work not properly isolated)
- ❌ Commit messages get garbled when squashed later

Required state:

- ✅ Every commit triggers decision checkpoint
- ✅ Explicit choice: new branch, continue, or escalate
- ✅ Built-in safeguards (max branches per session)
- ✅ Audit trail of all branching decisions
- ✅ No auto-override parameters (hard roadblock)

## Core Requirements

### 1. **Hard Roadblock Design**

The hook MUST:

- Block the commit completely (exit code 1)
- Require interactive user input (no silent defaults)
- NOT allow `--no-verify` bypass without warning
- Present decision tree before proceeding
- Log every decision for audit trail

### 2. **Decision Tree**

When triggered, present:

```
⚠️  ATOMIC COMMIT CHECKPOINT

You're about to commit. Choose how to proceed:

Current context:
  Branch:     main
  Files:      3 modified, 1 added
  Last commit: abc1234 "feat: add user authentication"

Options:

[a] Create new branch for atomic phase (RECOMMENDED)
    └─ Creates: claude/[phase-descriptor]-[session-id]
    └─ Isolates this work from other changes
    └─ Enables parallel PR reviews
    └─ Use when: Starting new atomic unit of work

[b] Continue on current branch
    └─ Commits to: main
    └─ Warning: Creates sequential dependency
    └─ Use when: Same atomic unit, incremental progress

[c] Create branch from specific commit
    └─ Advanced: Branch from custom base
    └─ Use when: Need to branch from earlier state

[h] Human decision needed
    └─ Flags for human review and decision
    └─ Blocks commit until human provides guidance
    └─ Use when: Uncertain about atomic boundaries

[x] Cancel commit
    └─ Aborts commit operation
    └─ Returns to editing state
    └─ Use when: Need to reconsider changes

Session limits:
  Branches created this session: 2/5
  Time in session: 45 minutes

Enter choice [a/b/c/h/x]:
```

### 3. **Safeguard Mechanisms**

#### Branch Limit Protection

- **Per-session limit**: Max 5 new branches per session (configurable)
- **Cooldown period**: Warn if >3 branches in <10 minutes
- **Session tracking**: Store in `.ai_logs/decision_gate_session.json`
- **Reset mechanism**: Session resets after 4 hours of inactivity

#### Validation Checks

- **Phase descriptor validation**: Require meaningful name (not "temp", "test", "wip")
- **Duplicate detection**: Warn if branch name already exists
- **Worktree integration**: Check if worktree already exists for phase
- **Issue linkage**: Prompt for issue number (optional but recommended)

#### Escalation Triggers

- **Rapid commit detection**: >5 commits in <5 minutes
- **Repeated cancellations**: >3 cancellations in one session
- **Branch limit approaching**: Warning at 4/5 branches
- **Human flag**: Automatically logged for review

### 4. **State Management**

#### Session State File: `.ai_logs/decision_gate_session.json`

```json
{
  "session_id": "011CUz...",
  "session_start": "2025-11-10T14:30:00Z",
  "last_activity": "2025-11-10T15:15:00Z",
  "branches_created": [
    {
      "branch": "claude/p0.2-phase1-abc123",
      "timestamp": "2025-11-10T14:35:00Z",
      "phase_descriptor": "p0.2-phase1",
      "issue_number": 42,
      "base_branch": "main"
    },
    {
      "branch": "claude/p1.1-contracts-def456",
      "timestamp": "2025-11-10T15:00:00Z",
      "phase_descriptor": "p1.1-contracts",
      "issue_number": 45,
      "base_branch": "main"
    }
  ],
  "commits_blocked": 0,
  "human_escalations": 0,
  "cancellations": 1
}
```

#### Decision Log File: `.ai_logs/decision_gate_log.jsonl`

```json
{"timestamp":"2025-11-10T14:35:22Z","session_id":"011CUz...","decision":"create_branch","branch":"claude/p0.2-phase1-abc123","phase":"p0.2-phase1","issue":42,"files_changed":3,"rationale":"Starting new atomic phase for decision logging infrastructure"}
{"timestamp":"2025-11-10T14:45:10Z","session_id":"011CUz...","decision":"continue","branch":"claude/p0.2-phase1-abc123","files_changed":2,"rationale":"Incremental progress on same atomic unit"}
{"timestamp":"2025-11-10T15:00:00Z","session_id":"011CUz...","decision":"create_branch","branch":"claude/p1.1-contracts-def456","phase":"p1.1-contracts","issue":45,"files_changed":5,"rationale":"New atomic unit: function contracts for sub-feature"}
{"timestamp":"2025-11-10T15:10:30Z","session_id":"011CUz...","decision":"human_escalation","reason":"Uncertain if changes belong to same atomic unit","files_changed":4}
```

### 5. **Integration with Existing Systems**

#### Pre-Commit Hook Chain

```
1. decision_gate_hook.mjs (NEW - runs first)
   └─ Blocks commit for decision
   └─ Exit 0: Proceed to next hook
   └─ Exit 1: Abort commit chain

2. pre_commit_format.mjs (EXISTING)
   └─ Formats staged files
   └─ Exit 0: Proceed to commit
   └─ Exit 1: Abort commit
```

#### hooks.json Configuration

```json
{
  "$schema": "https://cdn.jsdelivr.net/gh/anthropics/claude-code@main/hooks.schema.json",
  "hooks": {
    "pre_commit": {
      "command": "node .claude/hooks/decision_gate_hook.mjs && node .claude/hooks/pre_commit_format.mjs",
      "description": "Atomic decision gate + format check before commit",
      "enabled": true
    }
  }
}
```

#### Worktree Integration

- Check if current directory is a worktree
- Suggest phase descriptor based on worktree path
- Link to parent repository for session tracking

#### Issue Tracking Integration

- Prompt for issue number (optional)
- Validate issue exists via `gh issue view`
- Store issue linkage in decision log
- Future: Auto-update issue with commit reference

### 6. **Branch Creation Logic**

When user selects option [a]:

```javascript
// 1. Prompt for phase descriptor
const phaseDescriptor = await askQuestion(
  'Enter phase descriptor (e.g., p0.2-phase1, p1.1-contracts): ',
  {
    minLength: 3,
    maxLength: 50,
    pattern: /^[a-z0-9._-]+$/i,
    forbiddenWords: ['temp', 'test', 'wip', 'tmp', 'debug'],
  }
);

// 2. Validate not duplicate
const existingBranch = await gitAsync(
  `rev-parse --verify claude/${phaseDescriptor}-${sessionId}`,
  false
);
if (existingBranch) {
  print(
    '⚠️  Branch already exists. Choose different descriptor or continue on existing branch.',
    'yellow'
  );
  // Loop back to decision tree
}

// 3. Check session limits
if (sessionState.branches_created.length >= config.maxBranchesPerSession) {
  print('❌ Session branch limit reached (5/5)', 'red');
  print('Options:', 'yellow');
  print('  1. Continue on existing branch [b]', 'white');
  print('  2. Flag for human review [h]', 'white');
  print('  3. Cancel and restart session [x]', 'white');
  // Force to limited options
}

// 4. Optional: Prompt for issue number
const issueNumber = await askQuestion('Link to issue number (optional, press Enter to skip): ', {
  pattern: /^\d*$/,
  allowEmpty: true,
});

// 5. Validate issue exists
if (issueNumber) {
  const issueExists = await execAsync(`gh issue view ${issueNumber}`, false);
  if (!issueExists) {
    print('⚠️  Issue #${issueNumber} not found. Proceeding without issue link.', 'yellow');
  }
}

// 6. Create branch
const branchName = `claude/${phaseDescriptor}-${sessionId}`;
await gitAsync(`checkout -b ${branchName}`);

// 7. Update session state
sessionState.branches_created.push({
  branch: branchName,
  timestamp: new Date().toISOString(),
  phase_descriptor: phaseDescriptor,
  issue_number: issueNumber || null,
  base_branch: previousBranch,
});

// 8. Log decision
await logDecision({
  decision: 'create_branch',
  branch: branchName,
  phase: phaseDescriptor,
  issue: issueNumber,
  files_changed: stagedFiles.length,
  rationale: 'User-initiated atomic phase isolation',
});

// 9. Save session state
await saveSessionState(sessionState);

// 10. Exit 0 (allow commit to proceed)
print('✓ Created branch: ${branchName}', 'green');
print('  You can now commit on this isolated branch', 'white');
process.exit(0);
```

### 7. **Edge Case Handling**

#### Detached HEAD State

```
⚠️  DETACHED HEAD STATE DETECTED

You are not on any branch. This is unusual.

Options:
  [a] Create new branch from current HEAD
  [b] Return to main branch
  [x] Cancel commit

This state often occurs after:
  - git checkout <commit-hash>
  - git rebase operations
  - git bisect sessions

Choose carefully to avoid losing commits.
```

#### Rebase/Merge in Progress

```
⚠️  REBASE/MERGE IN PROGRESS

Git is in the middle of a rebase/merge operation.

Decision gate is temporarily disabled during conflict resolution.

Proceed with commit to continue rebase/merge.

Press Enter to continue...
```

#### Already on Feature Branch

```
✓ Already on feature branch: claude/p0.2-phase1-abc123

This branch was created earlier in this session.

Options:
  [b] Continue on this branch (recommended)
  [a] Create another branch (new atomic phase)
  [h] Human decision needed
  [x] Cancel commit
```

#### No Staged Files

```
⚠️  NO FILES STAGED

You attempted to commit with no staged changes.

This is likely an error.

Options:
  [s] Stage all modified files (git add .)
  [x] Cancel commit

Use 'git add <file>' to stage specific files.
```

#### Worktree Context

```
✓ Worktree detected: /project-worktrees/p0.2-phase1/

Current worktree is already isolated for atomic work.

Suggested phase: p0.2-phase1
Branch: claude/p0.2-phase1-abc123

[b] Continue on this worktree's branch (recommended)
[a] Create sub-phase branch
[x] Cancel commit
```

### 8. **Configuration Options**

#### `.claude/decision_gate_config.json`

```json
{
  "enabled": true,
  "maxBranchesPerSession": 5,
  "sessionTimeoutHours": 4,
  "rapidCommitThreshold": {
    "count": 5,
    "windowMinutes": 5
  },
  "cooldownWarning": {
    "branches": 3,
    "windowMinutes": 10
  },
  "branchNaming": {
    "prefix": "claude",
    "forbiddenWords": ["temp", "test", "wip", "tmp", "debug"],
    "pattern": "^[a-z0-9._-]+$"
  },
  "logging": {
    "enabled": true,
    "sessionLog": ".ai_logs/decision_gate_session.json",
    "decisionLog": ".ai_logs/decision_gate_log.jsonl",
    "auditLog": ".ai_logs/decision_gate_audit.jsonl"
  },
  "integration": {
    "checkWorktrees": true,
    "promptForIssue": true,
    "validateIssue": true,
    "ghCliRequired": false
  },
  "ui": {
    "colorOutput": true,
    "verboseMode": false,
    "showContext": true,
    "showLimits": true
  },
  "bypasses": {
    "allowNoVerify": false,
    "warnOnNoVerify": true,
    "exemptBranches": ["main", "master", "develop"]
  }
}
```

### 9. **Testing Strategy**

#### Unit Tests

- ✅ Session state management (create, update, reset)
- ✅ Branch name validation (pattern, duplicates, forbidden words)
- ✅ Limit enforcement (per-session, cooldown, rapid commits)
- ✅ Decision logging (format, file writes, integrity)
- ✅ Configuration loading (defaults, user overrides, validation)

#### Integration Tests

- ✅ Pre-commit hook chain (decision gate → formatter)
- ✅ Git command execution (branch creation, checkout, status)
- ✅ File system operations (read/write logs, state files)
- ✅ User input simulation (choice validation, edge cases)
- ✅ Session timeout and reset behavior

#### End-to-End Tests

- ✅ Complete commit workflow (decision → branch → commit)
- ✅ Multi-branch session (create 3 branches sequentially)
- ✅ Limit enforcement (attempt 6th branch, verify block)
- ✅ Human escalation path (flag, log, block)
- ✅ Worktree integration (detect, suggest, use existing)

#### Edge Case Tests

- ✅ Detached HEAD state handling
- ✅ Rebase/merge in progress bypass
- ✅ No staged files warning
- ✅ Already on feature branch continuation
- ✅ Rapid commit detection and warning
- ✅ Session timeout and reset after 4 hours
- ✅ Duplicate branch name handling
- ✅ Invalid phase descriptor rejection

### 10. **Example Interactions**

#### Scenario A: First Commit of Session (Recommended Path)

```
$ git commit -m "feat: add decision gate hook"

⚠️  ATOMIC COMMIT CHECKPOINT

Current context:
  Branch:     main
  Files:      2 modified (.claude/hooks/decision_gate_hook.mjs, docs/ai_work/decision_gate_hook_spec.md)
  Last commit: 0c6b6fc "docs: Complete comprehensive review of issue templates"

Options:
  [a] Create new branch for atomic phase (RECOMMENDED)
  [b] Continue on current branch
  [c] Create branch from specific commit
  [h] Human decision needed
  [x] Cancel commit

Session limits:
  Branches created this session: 0/5
  Time in session: 0 minutes

Enter choice [a/b/c/h/x]: a

Enter phase descriptor (e.g., p0.2-phase1, p1.1-contracts): p0.3-decision-gate

✓ Valid phase descriptor

Link to issue number (optional, press Enter to skip): 48

✓ Issue #48 found: "Implement pre-commit decision gate hook"

Creating branch: claude/p0.3-decision-gate-011CUz...

✓ Branch created successfully
✓ Decision logged to .ai_logs/decision_gate_log.jsonl
✓ Session state updated

You can now commit on this isolated branch.

Proceeding to format check...

[... pre_commit_format.mjs runs ...]

[main abc1234] feat: add decision gate hook
 2 files changed, 450 insertions(+)
```

#### Scenario B: Continuing on Existing Branch

```
$ git commit -m "test: add unit tests for session management"

⚠️  ATOMIC COMMIT CHECKPOINT

Current context:
  Branch:     claude/p0.3-decision-gate-011CUz
  Files:      1 added (tests/decision_gate/test_session_management.mjs)
  Last commit: abc1234 "feat: add decision gate hook"

✓ Already on feature branch: claude/p0.3-decision-gate-011CUz

This branch was created 15 minutes ago for phase: p0.3-decision-gate

Options:
  [b] Continue on this branch (RECOMMENDED)
  [a] Create new branch (different atomic phase)
  [h] Human decision needed
  [x] Cancel commit

Session limits:
  Branches created this session: 1/5
  Time in session: 15 minutes

Enter choice [a/b/h/x]: b

✓ Continuing on current branch
✓ Decision logged

Proceeding to format check...

[main def5678] test: add unit tests for session management
 1 file changed, 85 insertions(+)
```

#### Scenario C: Limit Approaching Warning

```
$ git commit -m "feat: add another feature"

⚠️  ATOMIC COMMIT CHECKPOINT

⚠️  WARNING: Approaching branch limit (4/5)

You have created 4 branches this session. After 1 more branch, you will need to:
  - Continue on existing branches, or
  - Flag for human review, or
  - End session and restart

Current context:
  Branch:     main
  Files:      3 modified
  Last commit: xyz9876 "feat: implement worktree detection"

Options:
  [a] Create new branch (1 remaining)
  [b] Continue on current branch
  [h] Human decision needed (RECOMMENDED if uncertain)
  [x] Cancel commit

Session limits:
  Branches created this session: 4/5 ⚠️
  Time in session: 58 minutes

Enter choice [a/b/h/x]:
```

#### Scenario D: Limit Reached

```
$ git commit -m "feat: yet another feature"

⚠️  ATOMIC COMMIT CHECKPOINT

❌ SESSION BRANCH LIMIT REACHED (5/5)

You have reached the maximum number of branches for this session.

This prevents runaway branch creation and enforces intentional workflow.

Options:
  [b] Continue on existing branch (choose from list)
  [h] Flag for human review (RECOMMENDED)
  [x] Cancel commit and review session

Available branches this session:
  1. claude/p0.3-decision-gate-011CUz
  2. claude/p1.1-contracts-011CUz
  3. claude/p1.2-tests-011CUz
  4. claude/p2.1-integration-011CUz
  5. claude/p2.2-docs-011CUz

Session info:
  Duration: 1 hour 15 minutes
  Total commits: 12
  Human escalations: 0

To reset session, wait 4 hours or manually delete:
  .ai_logs/decision_gate_session.json

Enter choice [b/h/x]:
```

#### Scenario E: Human Escalation

```
$ git commit -m "refactor: unclear if this belongs here"

⚠️  ATOMIC COMMIT CHECKPOINT

Current context:
  Branch:     claude/p0.3-decision-gate-011CUz
  Files:      5 modified (spanning multiple modules)
  Last commit: ghi3456 "feat: add decision gate hook"

Options:
  [a] Create new branch for atomic phase
  [b] Continue on current branch
  [c] Create branch from specific commit
  [h] Human decision needed (SELECT THIS IF UNCERTAIN)
  [x] Cancel commit

Enter choice [a/b/c/h/x]: h

Enter reason for human escalation (optional): Unsure if refactor should be on same branch or separate. Changes span multiple modules and may be too broad for single atomic unit.

✓ Human escalation flagged
✓ Decision logged with rationale
✓ Commit blocked

NEXT STEPS:
  1. Review changes: git diff --staged
  2. Consider splitting changes into smaller commits
  3. Consult with human about atomic boundaries
  4. Retry commit after clarification

Your changes are still staged and safe.

Use 'git reset HEAD' to unstage if needed.
```

## Implementation Phases

### Phase 1: Core Hook Infrastructure (P0.3.1)

- Session state management
- Basic decision tree (options a, b, x only)
- Branch creation logic
- Simple logging (decision log only)
- Configuration file support

### Phase 2: Safeguards & Limits (P0.3.2)

- Branch limit enforcement (per-session max)
- Cooldown period warnings
- Rapid commit detection
- Session timeout and reset
- Validation checks (phase descriptor, duplicates)

### Phase 3: Advanced Features (P0.3.3)

- Human escalation path (option h)
- Issue linkage and validation
- Worktree integration
- Advanced branch options (option c)
- Audit logging

### Phase 4: Edge Cases & Polish (P0.3.4)

- Detached HEAD handling
- Rebase/merge bypass
- No staged files warning
- Already on feature branch detection
- Comprehensive error handling

### Phase 5: Testing & Documentation (P0.3.5)

- Unit test suite
- Integration tests
- End-to-end tests
- User documentation
- Installation guide

## Success Metrics

### Functional Requirements

- ✅ Blocks all commits for decision checkpoint
- ✅ Enforces session branch limits (max 5)
- ✅ Logs all decisions with timestamps
- ✅ Creates branches with valid naming
- ✅ Integrates with existing pre-commit hooks
- ✅ Handles all edge cases gracefully
- ✅ Provides clear user guidance

### Quality Requirements

- ✅ Zero false negatives (never allows unintended commits)
- ✅ Zero data loss (staged changes always safe)
- ✅ 100% test coverage (all decision paths tested)
- ✅ Cross-platform support (Windows, Linux, macOS)
- ✅ Performance: <2 seconds for decision presentation

### Usability Requirements

- ✅ Clear, concise decision tree presentation
- ✅ Helpful context (current branch, files, limits)
- ✅ Easy escape hatch (cancel always available)
- ✅ Informative error messages
- ✅ Colorized output for readability

## Future Enhancements

### Phase 6+: Advanced Automation (Post-MVP)

- AI-powered phase descriptor suggestion (based on file changes)
- Automatic issue detection from commit message
- Integration with TODO.md for progress tracking
- Branch cleanup suggestions (merge/delete old branches)
- Session analytics and insights
- Team coordination features (shared session state)
- Slack/Discord notifications for human escalations

## Files to Create/Modify

### New Files

1. `.claude/hooks/decision_gate_hook.mjs` - Main hook implementation
2. `.claude/decision_gate_config.json` - Configuration file
3. `tests/decision_gate/test_session_management.mjs` - Unit tests for session state
4. `tests/decision_gate/test_branch_validation.mjs` - Unit tests for branch logic
5. `tests/decision_gate/test_limit_enforcement.mjs` - Unit tests for limits
6. `tests/decision_gate/test_decision_logging.mjs` - Unit tests for logging
7. `tests/decision_gate/test_integration.mjs` - Integration tests
8. `tests/decision_gate/test_edge_cases.mjs` - Edge case tests
9. `docs/ai_work/decision_gate_hook_spec.md` - This specification
10. `docs/ai_work/decision_gate_user_guide.md` - User-facing documentation
11. `claude_mods/hooks.json.decision_gate.example` - Example configuration

### Modified Files

1. `claude_mods/hooks.json.combined.example` - Add decision gate to chain
2. `README.md` - Add section on decision gate hook
3. `TODO.md` - Track implementation progress
4. `.gitignore` - Add `.ai_logs/decision_gate_session.json` (session state)
5. `package.json` - Add test scripts if needed

## Dependencies

### Required

- Node.js (already required)
- Git (already required)
- Existing pre-commit hook infrastructure

### Optional

- GitHub CLI (`gh`) - For issue validation
- Git worktree support - For worktree integration

### NPM Packages (Already Installed)

- None needed (use built-in Node.js modules only)

## Rollout Plan

1. **Create specification** (this document) ✅
2. **Review with human** - Validate approach
3. **Create atomic GitHub issues** - Break into P0.3.1 through P0.3.5
4. **Implement Phase 1** - Core infrastructure
5. **Test Phase 1** - Unit and integration tests
6. **Implement Phase 2** - Safeguards and limits
7. **Test Phase 2** - Comprehensive testing
8. **Implement Phase 3** - Advanced features
9. **Test Phase 3** - Edge cases and polish
10. **Documentation** - User guide and examples
11. **Deploy** - Enable in hooks.json
12. **Monitor** - Gather feedback and iterate

## Notes

- This hook is **intentionally intrusive** to enforce good practices
- The goal is **prevention**, not convenience
- Err on the side of **caution** (block when uncertain)
- **Audit trail** is critical for debugging and review
- **Hard roadblock** is a feature, not a bug
- Design for **Claude's workflow** but also useful for humans
