# Decision Log Format Specification

**Purpose:** Formal specification for AI decision logs tracking multi-pass work on issues

**Audience:** AI contributors, workflow maintainers, developers reviewing AI work

**Related Files:**

- `.github/workflows/decision_log_writer.yml` - Automated log generation
- `.github/workflows/validate-issue.yml` - Logs validation attempts
- `.github/workflows/enforce_test_gate.yml` - Logs gate enforcement
- `docs/examples/decision_log_example_full.md` - Complete 5-pass example

---

## Overview

Decision logs are structured markdown files tracking AI work attempts on GitHub issues. They record:

- What the AI tried to do
- What succeeded and what failed
- Why failures occurred
- What was learned for future attempts
- When human intervention is required

**Storage location:** `.ai_logs/issue_NNNN_decision_log.md`

**File naming:** Issue number zero-padded to 4 digits (e.g., `issue_0042_decision_log.md`)

---

## Format Specification

### File Header

```markdown
# Decision Log - Issue #<number>

**Issue:** #<number> - <title>
**Type:** <bug|feature|improvement|refactor|tooling>
**Severity:** <critical|high|medium|low> (if applicable)
**Assigned to:** <AI|Human|username>
**Max AI Passes:** <number> (default: 5)
**Current Pass:** <number>
**Status:** <IN_PROGRESS|COMPLETED|ESCALATED|BLOCKED>

**Problem Statement:**
<1-3 sentence description of what needs to be done>

**Initial Analysis:**
<AI's understanding of the problem before starting work>

---
```

**Required fields:**

- Issue number and title
- Type and severity
- Max AI passes (configurable, default 5)
- Current pass number
- Status (updated as work progresses)

**Optional fields:**

- Assigned to (defaults to AI)
- Initial analysis (recommended for complex issues)

### Pass Entry Format

Each pass (attempt) follows this structure:

````markdown
## Pass <number>: <Brief Description>

**Model:** <model-name>
**Timestamp:** <ISO-8601-timestamp>
**Status:** <SUCCESS|FAILED|PARTIAL_SUCCESS|BLOCKED>
**Commit:** <git-hash> (if changes made)
**Branch:** <branch-name> (if applicable)

### Changes Made

<Description of what was changed, with code blocks or file references>

```<language>
File: <path>
Lines changed: <range>

OLD:
<previous code>

NEW:
<new code>
```
````

### Test Execution

**Tests run:**

- <test-name>: <PASS|FAIL> (<details>)
- <test-name>: <PASS|FAIL> (<details>)

**Failure details:**

```
<full error output, stack traces, assertion failures>
```

### Failure Analysis

**Root cause:** <1-2 sentence explanation of why it failed>

**What was missed:**

- <specific oversight or misunderstanding>
- <missing context or incorrect assumption>

**Additional findings:**

- <related issues discovered>
- <technical debt uncovered>

### Next Actions

- [ ] <specific action to take in next pass>
- [ ] <specific action to take in next pass>

### Lessons Learned

<1-3 sentences capturing key insights for future AI work>

---

````

**Required for each pass:**
- Pass number and description
- Model used
- Timestamp (ISO-8601 UTC)
- Status (success/failed/partial/blocked)

**Conditional fields:**
- Commit hash (if changes committed)
- Branch name (if using git worktree workflow)
- Test execution (if tests run)
- Failure analysis (if status is FAILED or PARTIAL_SUCCESS)
- Next actions (if more passes expected)
- Lessons learned (mandatory for failed passes)

### Status Definitions

| Status | Meaning | Next Step |
|--------|---------|-----------|
| `SUCCESS` | All objectives met, tests pass | Mark issue complete |
| `FAILED` | Could not complete task, tests fail | Retry in next pass |
| `PARTIAL_SUCCESS` | Some objectives met, some failed | Continue in next pass |
| `BLOCKED` | Cannot proceed without human input | Escalate to human |

### Final Summary Section

Appears after all passes complete or max passes reached:

```markdown
## Summary Statistics

| Metric | Value |
|--------|-------|
| Total passes | <number> |
| Successful passes | <number> |
| Partial success | <number> |
| Failed passes | <number> |
| Models used | <list with counts> |
| Time spent | <total duration> |
| Commits made | <number> |
| Tests run | <breakdown by type> |
| Issues found | <number> (<list>) |
| Root cause | <final determination> |
| Escalation reason | <reason if escalated> |

---

## Lessons for Future AI Work

1. **<Category>:** <lesson learned>
2. **<Category>:** <lesson learned>
3. **<Category>:** <lesson learned>

---

**Decision Log Format Version:** <version>
**Created:** <ISO-8601-timestamp>
**Last Updated:** <ISO-8601-timestamp>
**Status:** <COMPLETED|ESCALATED|IN_PROGRESS>
````

**Required fields:**

- Total passes
- Pass breakdown (success/partial/failed)
- Models used
- Commits made
- Root cause (if determined)
- Status (COMPLETED, ESCALATED, or IN_PROGRESS)

**Recommended fields:**

- Time spent (for performance analysis)
- Tests run (for quality metrics)
- Lessons learned (for AI training/improvement)

---

## Pass Number Tracking

### Automatic Pass Calculation

Workflows calculate pass number by counting existing pass entries:

```javascript
// From validate-issue.yml, enforce_test_gate.yml, seed-test-runlist.yml
const logFileName = `issue_${String(issue.number).padStart(4, '0')}_decision_log.md`;

try {
  const { data: fileData } = await github.rest.repos
    .getContent({
      owner: context.repo.owner,
      repo: context.repo.repo,
      path: `.ai_logs/${logFileName}`,
      ref: context.ref,
    })
    .catch(() => ({ data: null }));

  if (fileData) {
    const content = Buffer.from(fileData.content, 'base64').toString('utf8');
    const passMatches = content.match(/^## Pass \d+:/gm);
    passNumber = passMatches ? passMatches.length + 1 : 1;
  } else {
    passNumber = 1; // No existing log, first pass
  }
} catch (e) {
  passNumber = 1; // Error reading log, assume first pass
}
```

**Logic:**

1. Check if decision log file exists at `.ai_logs/issue_NNNN_decision_log.md`
2. If exists, count lines matching `## Pass N:`
3. Next pass = count + 1
4. If file doesn't exist or error reading, assume pass 1

### Manual Pass Tracking

For AI work outside workflows:

1. Read existing decision log
2. Find last pass number: `grep "^## Pass" .ai_logs/issue_NNNN_decision_log.md | tail -1`
3. Extract number: `grep -oE 'Pass [0-9]+' | cut -d' ' -f2`
4. Increment by 1

**Example:**

```bash
ISSUE_NUM=42
LOG_FILE=".ai_logs/issue_$(printf '%04d' $ISSUE_NUM)_decision_log.md"

if [ -f "$LOG_FILE" ]; then
  LAST_PASS=$(grep "^## Pass" "$LOG_FILE" | tail -1 | grep -oE '[0-9]+' | head -1)
  NEXT_PASS=$((LAST_PASS + 1))
else
  NEXT_PASS=1
fi

echo "Starting Pass $NEXT_PASS"
```

---

## Workflow Integration

### Decision Log Writer Workflow

**File:** `.github/workflows/decision_log_writer.yml`

**Purpose:** Reusable workflow for appending pass entries to decision logs

**Inputs:**

```yaml
issue_number:
  description: 'GitHub issue number'
  required: true
  type: number

pass_number:
  description: 'Pass/attempt number (auto-calculated by calling workflow)'
  required: true
  type: number

status:
  description: 'Pass status: Success, Failed, Blocked, Attempted'
  required: true
  type: string

workflow_name:
  description: 'Name of the workflow that ran (e.g., "Validate Issue Format")'
  required: true
  type: string

trigger_event:
  description: 'Event that triggered the workflow (e.g., "issue_comment", "issues")'
  required: true
  type: string

validation_results_json:
  description: 'JSON string with validation/test results'
  required: false
  type: string

committer_name:
  description: 'Username who triggered the workflow'
  required: false
  type: string
```

**Usage in workflows:**

```yaml
jobs:
  validate:
    runs-on: ubuntu-latest
    outputs:
      validation_status: ${{ steps.validation.outputs.status }}
      validation_results: ${{ steps.validation.outputs.results }}
      pass_number: ${{ steps.validation.outputs.pass_number }}
      committer_name: ${{ steps.validation.outputs.committer }}
    steps:
      - name: Validate issue
        id: validation
        # ... validation logic ...

  log_decision:
    needs: validate
    if: always() # Run even if validation fails
    uses: ./.github/workflows/decision_log_writer.yml
    with:
      issue_number: ${{ github.event.issue.number }}
      pass_number: ${{ needs.validate.outputs.pass_number }}
      status: ${{ needs.validate.outputs.validation_status }}
      workflow_name: 'Validate Issue Format'
      trigger_event: ${{ github.event_name }}
      validation_results_json: ${{ needs.validate.outputs.validation_results }}
      committer_name: ${{ needs.validate.outputs.committer }}
```

### Validation Results JSON Format

Different workflows pass different result structures:

#### Validate Issue Format

```json
{
  "testId": "T-001",
  "errors": [
    "❌ Insufficient IB cases: found 0, need ≥1",
    "❌ Invalid Test ID format: \"TEST-1\" (expected T-XXX)"
  ],
  "warnings": ["⚠️ IB-01: Description is too short"],
  "passed": [
    "✅ Issue body is not empty",
    "✅ Section present: Test ID",
    "✅ Validation gate checkbox present"
  ],
  "hasErrors": true,
  "errorCount": 2,
  "warningCount": 1,
  "passedCount": 3
}
```

#### Enforce Test Gate

```json
{
  "ibCount": 2,
  "oobCount": 3,
  "ibCases": ["IB-01", "IB-02"],
  "oobCases": ["OOB-01", "OOB-02", "OOB-03"],
  "meetsRequirements": true,
  "gateChecked": true,
  "errorReason": null
}
```

**Failed example:**

```json
{
  "ibCount": 0,
  "oobCount": 1,
  "ibCases": [],
  "oobCases": ["OOB-01"],
  "meetsRequirements": false,
  "gateChecked": true,
  "errorReason": "IB: 0/1, OOB: 1/2"
}
```

#### Seed Test Runlist

```json
{
  "ibCount": 3,
  "oobCount": 4,
  "ibCases": ["IB-01", "IB-02", "IB-03"],
  "oobCases": ["OOB-01", "OOB-02", "OOB-03", "OOB-04"],
  "totalCases": 7,
  "order": ["OOB-01", "IB-01", "OOB-02", "OOB-03", "OOB-04", "IB-02", "IB-03"],
  "checklistExists": false,
  "seeded": true
}
```

**Manual command:**

```json
{
  "command": "overwrite",
  "ibCount": 3,
  "oobCount": 4,
  "ibCases": ["IB-01", "IB-02", "IB-03"],
  "oobCases": ["OOB-01", "OOB-02", "OOB-03", "OOB-04"],
  "totalCases": 7,
  "order": ["OOB-01", "IB-01", "OOB-02", "OOB-03", "OOB-04", "IB-02", "IB-03"]
}
```

---

## Decision Log Examples

### Example 1: Single Pass Success

````markdown
# Decision Log - Issue #42

**Issue:** #42 - Fix validation gate not blocking when IB < 1
**Type:** bug
**Severity:** high
**Assigned to:** AI
**Max AI Passes:** 5
**Current Pass:** 1
**Status:** COMPLETED

**Problem Statement:**
The validation workflow should block issues when they have fewer than 1 IB test case, but it's currently allowing them through.

---

## Pass 1: Fix IB minimum check and add label application

**Model:** Claude 3.5 Sonnet
**Timestamp:** 2025-11-10T14:23:15Z
**Status:** SUCCESS
**Commit:** a1b2c3d
**Branch:** claude/fix-ib-validation-011CUyMw7SwXELdrkt2QzyvZ

### Changes Made

Updated validation logic to properly enforce IB minimum and apply blocking label.

```yaml
File: .github/workflows/validate-issue.yml
Lines changed: 47-58

Added atomic validation step combining IB/OOB checks:
  - name: Validate test counts (atomic)
    run: |
      if [ $IB_COUNT -lt 1 ] || [ $OOB_COUNT -lt 2 ]; then
        echo "status=blocked" >> $GITHUB_OUTPUT
      else
        echo "status=passed" >> $GITHUB_OUTPUT
      fi

  - name: Apply validation labels
    if: steps.validate.outputs.status == 'blocked'
    run: gh issue edit ${{ github.event.issue.number }} --add-label "validation:blocked"
```
````

### Test Execution

**Tests run:**

- Unit test: `test_validation_gate.py::test_ib_minimum` - ✅ PASS
- Integration test: `test_workflow_blocking.py::test_insufficient_ib` - ✅ PASS
- Integration test: `test_workflow_blocking.py::test_insufficient_oob` - ✅ PASS
- End-to-end test: `test_full_workflow.py::test_blocking` - ✅ PASS

All tests passed on first attempt.

### Lessons Learned

Atomic decision making (single if statement for all conditions) prevents race conditions better than multiple independent checks.

---

## Summary Statistics

| Metric            | Value                            |
| ----------------- | -------------------------------- |
| Total passes      | 1                                |
| Successful passes | 1                                |
| Failed passes     | 0                                |
| Models used       | Claude 3.5 Sonnet (1)            |
| Time spent        | 12 minutes                       |
| Commits made      | 1                                |
| Tests run         | 4 unit/integration, 1 e2e        |
| Root cause        | IB minimum check not implemented |

---

**Decision Log Format Version:** 1.0
**Created:** 2025-11-10T14:10:00Z
**Last Updated:** 2025-11-10T14:23:15Z
**Status:** COMPLETED

```

### Example 2: Multi-Pass with Escalation

See `docs/examples/decision_log_example_full.md` for complete 5-pass scenario with failures, learning, and human escalation.

**Key characteristics:**
- Pass 1: Incomplete fix (logic change without label application)
- Pass 2: Partial success (fixed IB but missed OOB)
- Pass 3: Unexpected failure (race condition introduced)
- Pass 4: Integration failure (permission error)
- Pass 5: Max passes reached, escalated to human with `needs-human` label

---

## Best Practices

### For AI Contributors

**1. Write decision logs in real-time**
- Start log when beginning work on issue
- Update after each attempt (pass)
- Don't wait until completion to document

**2. Be specific in failure analysis**
- Identify exact line/file where failure occurred
- Explain root cause in technical detail
- List specific oversights (not vague "missed something")

**3. Include actionable next steps**
- Make next actions concrete and measurable
- Link to relevant documentation
- Estimate effort required (if possible)

**4. Extract genuine lessons**
- Focus on insights that generalize to other issues
- Avoid obvious statements ("tests are important")
- Connect lessons to specific failure modes

**5. Use proper timestamps**
- ISO-8601 format with UTC timezone
- Include timestamp for each pass
- Update "Last Updated" in file header

### For Workflow Developers

**1. Always call decision log writer**
- Use `if: always()` to log even on failure
- Pass complete validation results JSON
- Include committer name for audit trail

**2. Calculate pass number consistently**
- Use the standard counting logic (count `## Pass N:` lines)
- Handle missing file gracefully (default to pass 1)
- Don't hardcode pass numbers

**3. Use structured status values**
- Stick to: Success, Failed, Blocked, Attempted
- Document any new status values
- Map workflow-specific statuses to these standard values

**4. Include full error context**
- Pass entire error messages (don't truncate)
- Include relevant config values (IB_MIN, OOB_MIN)
- Preserve test case lists for debugging

### For Human Reviewers

**1. Read decision logs chronologically**
- Understand what AI tried first
- Follow the reasoning through failures
- Identify where AI got stuck

**2. Look for patterns in failures**
- Multiple passes with same error = AI stuck in loop
- Partial success then regression = race condition or side effect
- Immediate failure = missing context or permission

**3. Verify lessons learned are accurate**
- Do they match the actual failure mode?
- Are they actionable for future AI work?
- Should they be added to AI training/prompts?

**4. Check commit references**
- Verify commits mentioned in log exist
- Review actual changes vs. described changes
- Ensure all changes are in decision log

---

## File Management

### Storage Guidelines

**Location:** `.ai_logs/` directory at repository root

**Structure:**
```

.ai_logs/
├── issue_0001_decision_log.md
├── issue_0002_decision_log.md
├── issue_0042_decision_log.md
└── issue_0123_decision_log.md

````

**Naming convention:** `issue_NNNN_decision_log.md`
- Issue number zero-padded to 4 digits
- Underscore separators
- `.md` extension

### Version Control

**Should decision logs be committed?**

**Yes, commit decision logs when:**
- Work on issue is complete (success or escalation)
- Max passes reached
- Significant milestones (every 2-3 passes for long issues)

**No, don't commit after every pass:**
- Creates too many commits
- Pollutes git history
- Decision logs are audit trail, not code changes

**Recommended approach:**
```bash
# After completing issue work
git add .ai_logs/issue_NNNN_decision_log.md
git commit -m "docs: Add decision log for issue #NNNN

Final status: COMPLETED (or ESCALATED)
Total passes: N
Result: [brief outcome]"
````

### Retention Policy

**How long to keep decision logs?**

**Keep indefinitely:**

- Logs for escalated issues (needs-human)
- Logs with unusual failure patterns
- Logs that captured valuable lessons

**Can archive after 6 months:**

- Logs for completed issues with single-pass success
- Logs with routine/expected failures

**Never delete:**

- Logs for critical/high severity issues
- Logs documenting security-related work
- Logs referenced in postmortems or issue comments

---

## Metadata Schema (Optional)

For repositories using structured metadata extraction:

```yaml
---
decision_log_version: 1.0
issue_number: 42
issue_title: 'Fix validation gate not blocking when IB < 1'
issue_type: bug
severity: high
assigned_to: AI
max_passes: 5
total_passes: 5
successful_passes: 0
failed_passes: 4
partial_success: 1
status: ESCALATED
escalation_reason: 'Max passes reached without full resolution'
models_used:
  - name: GPT-4 Turbo
    passes: 1
  - name: Claude 3.5 Sonnet
    passes: 4
time_spent_minutes: 412
commits_made: 4
tests_run:
  unit: 15
  integration: 8
  e2e: 1
root_cause: 'Workflow permissions not declared'
created: 2025-11-08T14:23:15Z
last_updated: 2025-11-08T20:15:22Z
---
```

**Usage:**

- Extract metrics for AI performance analysis
- Generate reports on AI success rates
- Identify common failure patterns
- Track which models perform best on which tasks

**Tooling:**

```bash
# Extract all escalated issues
grep -l "status: ESCALATED" .ai_logs/*.md

# Count passes per issue
for log in .ai_logs/*.md; do
  echo "$log: $(grep -c "^## Pass" "$log") passes"
done

# Find issues with >3 passes
awk '/^total_passes:/ && $2 > 3 {print FILENAME}' .ai_logs/*.md
```

---

## Related Documentation

- [Decision Log Full Example](../examples/decision_log_example_full.md) - Complete 5-pass scenario
- [Max Pass Enforcement](./max_pass_enforcement.md) - When and how AI work is escalated
- [Test Workflow Detailed](../workflows/test_workflow_detailed.md) - Workflows that generate decision logs
- [Hierarchy Examples](../examples/hierarchy_examples.md) - Context for issue relationships

---

**Document Version:** 1.0
**Last Updated:** 2025-11-10
**Format Version:** 1.0
**Maintainer:** Claude AI (document author)
**Review Status:** Ready for human review
