# Issue Template Schemas - Design Document

**Created:** 2025-11-10
**Purpose:** Define schemas for Feature, Sub-Feature, Function, and Test-Suite templates

---

## 1. Feature Template Schema

**File:** `.github/ISSUE_TEMPLATE/feature.yml`
**Labels:** `type: feature` (or `type: bug`, `type: improvement`, `type: refactor`, `type: tooling`)
**Role Label:** NONE (parent-level issues don't get role labels)

### Fields:

1. **Feature Name** (input, required)
   - Short descriptive name
   - Used in title

2. **User Outcome** (textarea, required)
   - What user capability or business value does this deliver?
   - Focus on "who, what, why" not "how"

3. **Work Type** (dropdown, required)
   - Options: Feature, Bug Fix, Improvement, Refactor, Tooling
   - Auto-applies corresponding `type:` label

4. **Acceptance Criteria** (textarea, required)
   - List of AC, each will map to one Sub-Feature
   - Format: `- AC1: [description]`
   - Minimum 1 required

5. **Success Metrics** (textarea, required)
   - Measurable outcomes (test coverage %, performance targets, user metrics)
   - Must be objective and verifiable

6. **Dependencies** (textarea, optional)
   - Blocked by issues, required infrastructure, external dependencies
   - Format: `- Issue #XXX`, `- Requires API v2.0`

7. **Sub-Features** (textarea, optional - filled after creation)
   - Links to child Sub-Feature issues
   - Auto-generated section for tracking

8. **Estimated Effort** (dropdown, optional)
   - Options: XS (<1 day), S (1-3 days), M (1 week), L (2-4 weeks), XL (>1 month)

---

## 2. Sub-Feature Template Schema

**File:** `.github/ISSUE_TEMPLATE/sub-feature.yml`
**Labels:** `role: sub-feature`
**Work Type Label:** NONE (inherits from parent Feature)

### Fields:

1. **Sub-Feature Name** (input, required)
   - Short descriptive name
   - Used in title

2. **Parent Feature Issue URL** (input, required)
   - Link to parent Feature issue
   - Validation: Must be GitHub issue URL

3. **Acceptance Criterion from Parent** (textarea, required)
   - Which AC from parent Feature does this implement?
   - Copy exact AC text from parent

4. **Function Contracts Needed** (textarea, required)
   - List of functions required to implement this Sub-Feature
   - Format: `- FN: [function_name] - [brief purpose]`
   - Each will become a Function issue

5. **Test Coverage Requirements** (textarea, required)
   - Minimum test counts: IB ≥ 1, OOB ≥ 2 per function
   - Special coverage needs (e.g., security, performance)

6. **Dependencies** (textarea, optional)
   - Other Sub-Features, infrastructure, external APIs
   - Format: `- Issue #XXX`, `- Requires [resource]`

7. **Function Issues** (textarea, optional - filled after creation)
   - Links to child Function issues
   - Auto-generated section for tracking

8. **Ready Gate** (checkboxes, required)
   - Options:
     - `[ ] All Function contracts defined`
     - `[ ] All Test-Suites created`
     - `[ ] Test coverage requirements documented`

---

## 3. Function Template Schema

**File:** `.github/ISSUE_TEMPLATE/function.yml`
**Labels:** `type: function`
**Role Label:** NONE (function is a work type, not a role)

### Fields:

1. **Function Name** (input, required)
   - Exact function signature
   - Example: `process_buffer(samples[], count, flags)`

2. **Parent Sub-Feature Issue URL** (input, required)
   - Link to parent Sub-Feature issue
   - Validation: Must be GitHub issue URL

3. **Purpose** (textarea, required)
   - Single-sentence description of what this function does
   - Focus on the "why" not "how"

4. **Contract Definition** (textarea, required)
   - **Inputs:**
     - Parameter names, types, valid ranges
     - Example: `samples[]: int16_t array, count: uint32_t (1-1024), flags: uint8_t bitmask`
   - **Outputs:**
     - Return type, valid range, side effects
     - Example: `Returns: ErrorCode (SUCCESS=0, OVERFLOW=1, NULL_PTR=2)`
   - **Invariants:**
     - Conditions that must always be true
     - Example: `Input array never modified; thread-safe`
   - **Preconditions:**
     - Requirements before calling
     - Example: `samples != NULL; count > 0; flags valid per FLAG_MASK`
   - **Postconditions:**
     - Guarantees after completion
     - Example: `On SUCCESS, output buffer contains processed samples; on error, no state change`

5. **Test Suite Link** (input, required)
   - Link to associated Test-Suite issue
   - One function should have one primary test suite

6. **Implementation Notes** (textarea, optional)
   - Performance considerations, edge cases, algorithm choice
   - Not part of contract, but helpful for implementation

7. **Dependencies** (textarea, optional)
   - Other functions, libraries, system requirements

8. **Ready Gate** (checkboxes, required)
   - Options:
     - `[ ] Contract fully defined (inputs, outputs, invariants, pre/post)`
     - `[ ] Test-Suite issue created and linked`
     - `[ ] All edge cases documented`

---

## 4. Test-Suite Template Schema

**File:** `.github/ISSUE_TEMPLATE/test-suite.yml`
**Labels:** `role: test suite`
**Work Type Label:** NONE (test suite is a role, not work type)

### Fields:

1. **Test Suite Name** (input, required)
   - Descriptive name
   - Example: "process_buffer() Test Suite"

2. **Parent Function Issue URL** (input, required)
   - Link to parent Function issue
   - Validation: Must be GitHub issue URL

3. **Function Contract Summary** (textarea, required)
   - Copy of function contract from parent (inputs, outputs, invariants)
   - Ensures test suite writer understands what to test

4. **Test Cases** (textarea, required)
   - List of all IB/OOB test case issue links
   - Format: `- IB: #XXX - [test name]`, `- OOB: #YYY - [test name]`
   - Must show minimum coverage: IB ≥ 1, OOB ≥ 2

5. **Coverage Target** (textarea, required)
   - Minimum: IB ≥ 1, OOB ≥ 2
   - Actual target: (specify if higher)
   - Coverage areas: happy path, error handling, edge cases, boundaries

6. **Test Strategy** (textarea, required)
   - What testing approach? (unit, integration, property-based, mutation)
   - Test order/dependencies
   - Special considerations (timing, concurrency, resources)

7. **Dependencies** (textarea, optional)
   - Test fixtures, data sets, environment setup
   - Blocked by other issues

8. **Completion Gate** (checkboxes, required)
   - Options:
     - `[ ] All test cases created (IB ≥ 1, OOB ≥ 2)`
     - `[ ] All test cases validated (passed)`
     - `[ ] Coverage target met`
     - `[ ] Function contract verified`

---

## Label Application Rules

### Feature Template

- **Auto-apply:** `type: [feature|bug|improvement|refactor|tooling]` based on dropdown selection
- **Do NOT apply:** Any `role:` label
- **Why:** Feature is the top-level parent; work type is determined by user selection

### Sub-Feature Template

- **Auto-apply:** `role: sub-feature`
- **Do NOT apply:** Any `type:` label
- **Why:** Sub-Feature inherits work type from parent Feature

### Function Template

- **Auto-apply:** `type: function`
- **Do NOT apply:** Any `role:` label
- **Why:** Function is a work type (implementation unit), not a role in hierarchy

### Test-Suite Template

- **Auto-apply:** `role: test suite`
- **Do NOT apply:** Any `type:` label
- **Why:** Test-Suite is a role (organizer), not work type

---

## Field Type Guidelines

### When to use `input`:

- Short single-line text (names, URLs, IDs)
- Can use validation (required, pattern matching)

### When to use `textarea`:

- Multi-line text (descriptions, lists, code blocks)
- Supports markdown formatting
- Good for structured content

### When to use `dropdown`:

- Fixed set of options
- Auto-label application based on selection
- Reduces user error

### When to use `checkboxes`:

- Boolean flags or multiple selections
- Gates that require explicit confirmation
- Evidence checklists

---

## Title Format Conventions

- **Feature:** `FEATURE: <User Outcome Summary>`
- **Sub-Feature:** `SUB-FEATURE: <AC Summary> [Parent #XXX]`
- **Function:** `FUNCTION: <function_name()> [Parent #XXX]`
- **Test-Suite:** `TEST-SUITE: <function_name()> Coverage [Parent #XXX]`
- **Test:** `TEST: <short name> [T-xxx]` (existing format)

---

## Verification Checklist

For each template, verify:

- [ ] All required fields have `validations.required: true`
- [ ] Labels array matches label application rules
- [ ] Field IDs are unique and descriptive
- [ ] Placeholders provide clear examples
- [ ] Descriptions explain the "why" not just "what"
- [ ] Parent link fields use input type with URL validation
- [ ] YAML syntax is valid (yamllint clean)

---

**Status:** Design complete, ready for implementation (Phase 2A)
**Next Step:** Create actual `.yml` template files
