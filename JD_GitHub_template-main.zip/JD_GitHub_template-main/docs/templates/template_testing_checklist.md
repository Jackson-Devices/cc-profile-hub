# Template Testing Checklist

**Purpose:** Manual testing checklist for verifying all 4 new GitHub issue templates

**Date Created:** 2025-11-10
**Status:** Pending manual testing in GitHub UI

---

## Testing Overview

**What to test:**

1. All templates render correctly in GitHub UI
2. Labels auto-apply as expected
3. Required fields are enforced
4. Field placeholders and descriptions are clear
5. Parent linking fields accept GitHub URLs
6. Ready/completion gates display correctly

**How to test:**

- Create test issues using each template
- Verify all aspects work correctly
- Document any issues found
- Close test issues after verification

---

## Test 1: Feature Template

### Steps

1. **Navigate to** https://github.com/Jackson-Devices/JD_GitHub_template/issues/new/choose
2. **Select** "Feature" template
3. **Verify rendering:**
   - [ ] Template name displays: "Feature"
   - [ ] Description displays: "Top-level parent issue defining a user outcome with acceptance criteria."
   - [ ] All fields render in correct order

4. **Fill in test data:**
   - Feature Name: `Test Feature - Email Validation System`
   - User Outcome: `As a developer, I want to validate email addresses so that invalid emails are rejected early.`
   - Work Type: Select "Feature (new capability)"
   - Acceptance Criteria:
     ```
     - AC1: System validates email format per RFC 5322
     - AC2: System checks domain has valid MX records
     - AC3: System provides clear error messages for invalid emails
     ```
   - Success Metrics:
     ```
     - Test coverage ≥95% for validation logic
     - Performance: Validation completes in <50ms
     - Zero false positives on valid emails
     ```
   - Dependencies: (leave empty)
   - Sub-Features: (leave empty)
   - Estimated Effort: Select "S (1-3 days)"

5. **Verify required fields:**
   - [ ] Cannot submit without Feature Name
   - [ ] Cannot submit without User Outcome
   - [ ] Cannot submit without Work Type
   - [ ] Cannot submit without Acceptance Criteria
   - [ ] Cannot submit without Success Metrics

6. **Submit issue**

7. **Verify after creation:**
   - [ ] Issue title includes "FEATURE:"
   - [ ] Labels applied: `type:feature`
   - [ ] NO `role:` label applied
   - [ ] All fields rendered correctly in issue body
   - [ ] Ready gate checkboxes display

8. **Close test issue** with comment: "Test complete - template verified"

### Expected Labels

- `type:feature`

### Issues Found

- (Document any issues here)

---

## Test 2: Sub-Feature Template

### Steps

1. **Navigate to** https://github.com/Jackson-Devices/JD_GitHub_template/issues/new/choose
2. **Select** "Sub-Feature" template
3. **Verify rendering:**
   - [ ] Template name displays: "Sub-Feature"
   - [ ] Description displays: "Child of Feature, implements one acceptance criterion through function contracts."
   - [ ] All fields render in correct order

4. **Fill in test data:**
   - Sub-Feature Name: `Email Format Validation`
   - Parent Feature Issue URL: `https://github.com/Jackson-Devices/JD_GitHub_template/issues/[FEATURE_ISSUE_NUMBER]` (use issue from Test 1)
   - Acceptance Criterion from Parent: `AC1: System validates email format per RFC 5322`
   - Function Contracts Needed:
     ```
     - FN: validate_email_format(email) - Check RFC 5322 compliance
     - FN: normalize_email(email) - Lowercase and trim whitespace
     - FN: extract_domain(email) - Parse domain from email string
     ```
   - Test Coverage Requirements:

     ```
     Per-function minimum: IB ≥ 1, OOB ≥ 2

     Additional requirements:
     - Security: Test injection patterns in validate_email_format()
     - Performance: Validation completes in <10ms per function
     ```

   - Dependencies: (leave empty)
   - Function Issues: (leave empty)

5. **Verify required fields:**
   - [ ] Cannot submit without Sub-Feature Name
   - [ ] Cannot submit without Parent Feature URL
   - [ ] Cannot submit without Acceptance Criterion
   - [ ] Cannot submit without Function Contracts
   - [ ] Cannot submit without Test Coverage Requirements

6. **Submit issue**

7. **Verify after creation:**
   - [ ] Issue title includes "SUB-FEATURE:" and "[Parent #XXX]"
   - [ ] Labels applied: `role:sub-feature`
   - [ ] NO `type:` label applied
   - [ ] All fields rendered correctly
   - [ ] Ready gate checkboxes display (5 items)

8. **Close test issue** with comment: "Test complete - template verified"

### Expected Labels

- `role:sub-feature`

### Issues Found

- (Document any issues here)

---

## Test 3: Function Template

### Steps

1. **Navigate to** https://github.com/Jackson-Devices/JD_GitHub_template/issues/new/choose
2. **Select** "Function" template
3. **Verify rendering:**
   - [ ] Template name displays: "Function"
   - [ ] Description displays: "Implementation unit with formal contract..."
   - [ ] All fields render in correct order

4. **Fill in test data:**
   - Function Name: `validate_email_format(email: string): ValidationResult`
   - Parent Sub-Feature Issue URL: `https://github.com/Jackson-Devices/JD_GitHub_template/issues/[SUB_FEATURE_NUMBER]` (use issue from Test 2)
   - Purpose: `Validates email address format against RFC 5322 specification to ensure syntactic correctness.`
   - Contract: Inputs:
     ```
     - email: string
       - Format: Any UTF-8 string
       - Length: 0-254 characters
       - Constraints: None (validation handled internally)
     ```
   - Contract: Outputs:

     ```
     Returns: ValidationResult enum
     - VALID (0): Email matches RFC 5322
     - INVALID_LOCAL (1): Local part malformed
     - INVALID_DOMAIN (2): Domain part malformed
     - INVALID_FORMAT (3): Overall structure invalid

     Side effects: None (pure function)
     ```

   - Contract: Invariants:
     ```
     - Function never modifies input
     - Thread-safe (no shared state)
     - Deterministic (same input = same output)
     - No exceptions thrown
     ```
   - Contract: Preconditions:
     ```
     - email parameter is not null
     - email is valid UTF-8 string
     ```
   - Contract: Postconditions:
     ```
     - If VALID: email is syntactically correct per RFC 5322
     - If INVALID_*: specific error reason provided
     - No memory leaks
     ```
   - Test Suite Issue URL: `https://github.com/Jackson-Devices/JD_GitHub_template/issues/[TEST_SUITE_NUMBER]` (placeholder)
   - Implementation Notes: `Use regex for initial parse, then validate specific RFC 5322 rules.`
   - Dependencies: (leave empty)

5. **Verify required fields:**
   - [ ] Cannot submit without Function Name
   - [ ] Cannot submit without Parent Sub-Feature URL
   - [ ] Cannot submit without Purpose
   - [ ] Cannot submit without all 5 contract sections
   - [ ] Cannot submit without Test Suite Link

6. **Submit issue**

7. **Verify after creation:**
   - [ ] Issue title includes "FUNCTION:" and function name
   - [ ] Labels applied: `type:function`
   - [ ] NO `role:` label applied
   - [ ] All contract sections rendered clearly
   - [ ] Ready gate checkboxes display (5 items)

8. **Close test issue** with comment: "Test complete - template verified"

### Expected Labels

- `type:function`

### Issues Found

- (Document any issues here)

---

## Test 4: Test-Suite Template

### Steps

1. **Navigate to** https://github.com/Jackson-Devices/JD_GitHub_template/issues/new/choose
2. **Select** "Test Suite" template
3. **Verify rendering:**
   - [ ] Template name displays: "Test Suite"
   - [ ] Description displays: "Collection of test cases validating one function contract..."
   - [ ] All fields render in correct order

4. **Fill in test data:**
   - Test Suite Name: `validate_email_format() Test Suite`
   - Parent Function Issue URL: `https://github.com/Jackson-Devices/JD_GitHub_template/issues/[FUNCTION_NUMBER]` (use issue from Test 3)
   - Function Contract Summary: (copy contract from Function issue)
   - Test Cases:

     ```
     In-Bounds (valid inputs):
     - IB: #XXX - Valid simple email returns VALID
     - IB: #YYY - Valid email with subdomain returns VALID
     - IB: #ZZZ - Valid international email returns VALID

     Out-of-Bounds (edge/error cases):
     - OOB: #AAA - Missing @ symbol returns INVALID_FORMAT
     - OOB: #BBB - Multiple @ symbols returns INVALID_FORMAT
     - OOB: #CCC - Empty string returns INVALID_FORMAT
     - OOB: #DDD - Null input violates precondition
     ```

   - Coverage Target:

     ```
     Minimum: IB ≥ 1, OOB ≥ 2
     Actual: IB = 3, OOB = 4

     Coverage areas:
     - Happy path: Common email formats
     - Boundaries: Empty, max length
     - Error handling: Malformed inputs
     - Security: Injection attempts
     ```

   - Test Strategy:

     ```
     Test type: Unit tests (isolated function)

     Execution order:
     1. OOB-01 (boundary before valid)
     2. IB-01, IB-02, IB-03 (all valid cases)
     3. OOB-02 through OOB-04 (error cases)

     Dependencies: None (pure function, no external calls)

     Special considerations:
     - Use deterministic test data (no randomness)
     - Verify no memory leaks with valgrind
     ```

   - Dependencies: (leave empty)

5. **Verify required fields:**
   - [ ] Cannot submit without Test Suite Name
   - [ ] Cannot submit without Parent Function URL
   - [ ] Cannot submit without Function Contract Summary
   - [ ] Cannot submit without Test Cases
   - [ ] Cannot submit without Coverage Target
   - [ ] Cannot submit without Test Strategy

6. **Submit issue**

7. **Verify after creation:**
   - [ ] Issue title includes "TEST-SUITE:" and function name
   - [ ] Labels applied: `role:test suite`
   - [ ] NO `type:` label applied
   - [ ] All sections rendered correctly
   - [ ] Completion gate checkboxes display (5 items)

8. **Close test issue** with comment: "Test complete - template verified"

### Expected Labels

- `role:test suite`

### Issues Found

- (Document any issues here)

---

## Test 5: Verify Existing Test Template Still Works

### Steps

1. **Navigate to** https://github.com/Jackson-Devices/JD_GitHub_template/issues/new/choose
2. **Select** "Test" template (existing template)
3. **Verify rendering:**
   - [ ] Template still appears in list
   - [ ] Description unchanged
   - [ ] All existing fields render

4. **Fill in minimal test data** (abbreviated)

5. **Submit issue**

6. **Verify after creation:**
   - [ ] Labels applied: `type:test`, `validation:pending`
   - [ ] Existing functionality unchanged

7. **Close test issue**

### Expected Labels

- `type:test`
- `validation:pending`

### Issues Found

- (Document any issues here)

---

## Overall Verification

After completing all 5 template tests:

### Template List Verification

- [ ] All 5 templates appear in "New Issue" dropdown
- [ ] Templates display in logical order (hierarchy order preferred)
- [ ] Template names and descriptions are clear
- [ ] No duplicate or missing templates

### Label Verification Summary

| Template    | Expected Labels                                           | Actual Labels | Match? |
| ----------- | --------------------------------------------------------- | ------------- | ------ |
| Feature     | `type:feature` (or type:bug/improvement/refactor/tooling) |               | ☐      |
| Sub-Feature | `role:sub-feature`                                        |               | ☐      |
| Function    | `type:function`                                           |               | ☐      |
| Test-Suite  | `role:test suite`                                         |               | ☐      |
| Test        | `type:test`, `validation:pending`                         |               | ☐      |

### Cross-Linking Verification

- [ ] Parent URL fields accept GitHub issue URLs
- [ ] Links render as clickable in issue body
- [ ] Hierarchy is traceable (can click from Test → Suite → Function → Sub-Feature → Feature)

### User Experience

- [ ] Field placeholders provide clear examples
- [ ] Descriptions explain what each field is for
- [ ] Required fields are obvious
- [ ] Ready/completion gates are meaningful

---

## Issues Summary

### Critical Issues (Must Fix Before Release)

- (List any blocking issues here)

### Minor Issues (Nice to Have)

- (List any cosmetic or minor issues here)

### Observations

- (Note any UX improvements or suggestions here)

---

## Sign-Off

- [ ] All 5 templates tested
- [ ] All labels verified
- [ ] All issues documented
- [ ] Test issues closed
- [ ] Ready for production use

**Tested By:** [Name]
**Date:** [YYYY-MM-DD]
**Status:** ☐ PASS | ☐ FAIL (with issues)

---

**Last Updated:** 2025-11-10
**Related:** P0.2 Phase 3 - Template Framework Integration
