# Issue Template Usage Guide

**Purpose:** Guide for choosing the correct GitHub issue template for your work

---

## The 5-Level Atomic Hierarchy

Jackson-Devices uses a structured 5-level hierarchy for all work:

```
1. Feature (top-level parent)
     ↓
2. Sub-Feature (implements one acceptance criterion)
     ↓
3. Function (implementation unit with formal contract)
     ↓
4. Test-Suite (organizes IB/OOB tests for one function)
     ↓
5. Test-Case (individual IB or OOB test)
```

**Each level has its own template** that auto-applies the correct labels.

---

## Quick Decision Tree

```
What are you creating?

├─ A new user capability or business value?
│  └─ Use: FEATURE template
│     Labels: type:feature (or bug/improvement/refactor/tooling)
│
├─ Implementing ONE acceptance criterion from a Feature?
│  └─ Use: SUB-FEATURE template
│     Labels: role:sub-feature
│
├─ Defining a specific function with inputs/outputs/contract?
│  └─ Use: FUNCTION template
│     Labels: type:function
│
├─ Organizing tests for a function (IB/OOB coverage)?
│  └─ Use: TEST-SUITE template
│     Labels: role:test suite
│
└─ Writing ONE specific test case (IB-XX or OOB-XX)?
   └─ Use: TEST template
      Labels: type:test, validation:pending
```

---

## Template Descriptions

### 1. Feature Template

**When to use:**

- Starting a new user-facing capability
- Fixing a bug that affects users
- Improving an existing feature
- Refactoring internal structure
- Building internal tooling/infrastructure

**What it defines:**

- **User Outcome:** What capability or value this delivers
- **Work Type:** Feature, Bug Fix, Improvement, Refactor, or Tooling
- **Acceptance Criteria (AC):** List of ACs (each becomes one Sub-Feature)
- **Success Metrics:** Measurable, objective outcomes

**Labels applied:**

- `type:feature` OR `type:bug` OR `type:improvement` OR `type:refactor` OR `type:tooling` (based on dropdown selection)
- **NO role label** (Feature is top-level parent)

**Example:**

```
Feature: User Authentication System
Work Type: Feature
AC1: Users can register with email and password
AC2: Users can log in with valid credentials
AC3: Failed login attempts are rate-limited
```

---

### 2. Sub-Feature Template

**When to use:**

- Implementing ONE acceptance criterion from a parent Feature
- Breaking down a Feature into manageable work units

**What it defines:**

- **Parent Feature:** Link to parent issue
- **AC from Parent:** Exact text of which AC this implements
- **Function Contracts:** List of functions needed
- **Test Coverage:** Requirements (IB≥1, OOB≥2 per function)

**Labels applied:**

- `role:sub-feature`
- **NO type label** (inherits work type from parent Feature)

**Example:**

```
Sub-Feature: User Registration Flow
Parent: Issue #123 (User Authentication System)
AC: AC1: Users can register with email and password
Functions needed:
- validate_email(email)
- hash_password(password, salt)
- create_user_record(email, hash)
```

---

### 3. Function Template

**When to use:**

- Defining a specific function with formal contract
- Specifying exact inputs, outputs, and behavior

**What it defines:**

- **Function Signature:** Exact name and parameters
- **Contract Definition:**
  - **Inputs:** Parameters with types, ranges, constraints
  - **Outputs:** Return type, possible values, side effects
  - **Invariants:** Conditions always true
  - **Preconditions:** Requirements before calling
  - **Postconditions:** Guarantees after completion
- **Test Suite Link:** Associated Test-Suite issue

**Labels applied:**

- `type:function` (function is a work type, not a role)
- **NO role label**

**Example:**

```
Function: validate_email(email: string): ValidationResult
Inputs: email string (3-254 chars, RFC 5322 format)
Outputs: VALID (0), INVALID_FORMAT (1), INVALID_DOMAIN (2), ERROR (3)
Invariants: Thread-safe, deterministic, no exceptions
Preconditions: email not null, valid UTF-8
Postconditions: VALID = format correct + domain exists
```

---

### 4. Test-Suite Template

**When to use:**

- Organizing all tests for ONE function
- Defining test coverage strategy
- Tracking IB/OOB test requirements

**What it defines:**

- **Parent Function:** Link to function being tested
- **Function Contract Summary:** Copy from parent for test writers
- **Test Cases:** Links to all IB/OOB test issues
- **Coverage Target:** Minimum IB≥1, OOB≥2 (or higher)
- **Test Strategy:** Approach, execution order, dependencies

**Labels applied:**

- `role:test suite` (organizer role)
- **NO type label**

**Example:**

```
Test-Suite: validate_email() Coverage
Parent: Issue #456 (Function: validate_email)
Test Cases:
- IB: #501 - Valid Gmail address
- IB: #502 - Valid corporate domain
- OOB: #601 - Missing @ symbol
- OOB: #602 - Invalid domain (no MX)
- OOB: #603 - Empty string
Coverage: IB=2, OOB=3 (exceeds minimum IB≥1, OOB≥2)
```

---

### 5. Test Template (Existing)

**When to use:**

- Creating ONE specific test case
- Testing either valid input (In-Bounds) or edge/error case (Out-of-Bounds)

**What it defines:**

- **Test ID:** Stable identifier (T-001, T-002, etc.)
- **Parent Suite:** Link to Test-Suite issue
- **Purpose:** What behavior this test proves
- **IB Cases:** Valid inputs (IB-01, IB-02, ...)
- **OOB Cases:** Edge/error cases (OOB-01, OOB-02, ...)
- **Expected Behavior:** Pass criteria
- **Validation Method:** How to execute and verify

**Labels applied:**

- `type:test`
- `validation:pending` (until test passes)

**Example:**

```
Test: Valid Gmail address returns VALID [T-501]
Suite: Issue #789 (validate_email() Coverage)
Purpose: Verify common email format accepted
IB-01: test@gmail.com → returns VALID
Expected: Function returns VALID (0), no errors
Validation: Unit test, mock DNS, assert return == VALID
```

---

## Label Application Rules

### Work Type Labels (type:)

Applied ONLY to top-level parent (Feature) or implementation units (Function, Test):

| Template    | Label Applied                                                                           | Why                               |
| ----------- | --------------------------------------------------------------------------------------- | --------------------------------- |
| Feature     | `type:feature` OR `type:bug` OR `type:improvement` OR `type:refactor` OR `type:tooling` | User selects work type            |
| Sub-Feature | NONE                                                                                    | Inherits from parent Feature      |
| Function    | `type:function`                                                                         | Function is work type             |
| Test-Suite  | NONE                                                                                    | Test-Suite is organizer, not work |
| Test        | `type:test`                                                                             | Test is work type                 |

### Role Labels (role:)

Applied to organizational/hierarchical issues:

| Template    | Label Applied      | Why                              |
| ----------- | ------------------ | -------------------------------- |
| Feature     | NONE               | Top-level parent, no role needed |
| Sub-Feature | `role:sub-feature` | Organizes work for one AC        |
| Function    | NONE               | Function is work type, not role  |
| Test-Suite  | `role:test suite`  | Organizes tests for one function |
| Test        | NONE               | Test is work type, not role      |

**Key principle:** Work type labels (`type:`) describe WHAT you're doing. Role labels (`role:`) describe WHERE in the hierarchy.

---

## Workflow: Creating a New Feature

### Step 1: Create Feature Issue

1. Click "New Issue"
2. Choose **Feature** template
3. Fill in:
   - Feature name
   - User outcome (who benefits, what they can do, why)
   - Work type dropdown
   - Acceptance criteria (AC1, AC2, AC3, ...)
   - Success metrics (test coverage %, performance targets)
4. Submit → Auto-applies `type:*` label

### Step 2: Break Down into Sub-Features

For each acceptance criterion in the Feature:

1. Create **Sub-Feature** issue
2. Link to parent Feature
3. Copy exact AC text
4. List functions needed
5. Define test coverage requirements
6. Submit → Auto-applies `role:sub-feature`

### Step 3: Define Functions

For each function listed in Sub-Feature:

1. Create **Function** issue
2. Link to parent Sub-Feature
3. Define complete contract:
   - Inputs (parameters, types, ranges)
   - Outputs (return type, values)
   - Invariants (always true)
   - Preconditions (requirements before call)
   - Postconditions (guarantees after completion)
4. Submit → Auto-applies `type:function`

### Step 4: Create Test-Suites

For each function:

1. Create **Test-Suite** issue
2. Link to parent Function
3. Copy function contract
4. Plan test cases (minimum IB≥1, OOB≥2)
5. Define test strategy
6. Submit → Auto-applies `role:test suite`

### Step 5: Write Test Cases

For each test in the suite:

1. Create **Test** issue using existing test template
2. Link to parent Test-Suite
3. Define IB or OOB cases
4. Specify validation method
5. Submit → Auto-applies `type:test`, `validation:pending`

### Step 6: Execute and Validate

1. Implement functions (guided by contracts)
2. Run tests (execute validation methods)
3. Check validation gate on each test issue
4. When all tests pass → Test-Suite complete
5. When all Test-Suites pass → Function complete
6. When all Functions complete → Sub-Feature complete
7. When all Sub-Features complete → Feature complete

---

## Examples: Complete Hierarchy

### Example 1: Email Validation Feature

```
Feature #100: User Registration System (type:feature)
  ├─ Sub-Feature #200: Email Validation (role:sub-feature)
  │    ├─ Function #300: validate_email() (type:function)
  │    │    └─ Test-Suite #400: validate_email() Coverage (role:test suite)
  │    │         ├─ Test #501: Valid Gmail [T-501] (type:test)
  │    │         ├─ Test #502: Valid corporate [T-502] (type:test)
  │    │         ├─ Test #601: Missing @ [T-601] (type:test)
  │    │         └─ Test #602: Invalid domain [T-602] (type:test)
  │    │
  │    └─ Function #310: check_domain_mx() (type:function)
  │         └─ Test-Suite #410: check_domain_mx() Coverage (role:test suite)
  │              ├─ Test #511: Valid MX [T-511] (type:test)
  │              └─ Test #611: No MX records [T-611] (type:test)
  │
  └─ Sub-Feature #210: Password Hashing (role:sub-feature)
       └─ Function #320: hash_password() (type:function)
            └─ Test-Suite #420: hash_password() Coverage (role:test suite)
                 ├─ Test #521: Valid password [T-521] (type:test)
                 ├─ Test #621: Empty password [T-621] (type:test)
                 └─ Test #622: Null password [T-622] (type:test)
```

### Example 2: Bug Fix Hierarchy

```
Feature #150: Fix Login Timeout Bug (type:bug)
  └─ Sub-Feature #250: Session Management Fix (role:sub-feature)
       └─ Function #350: refresh_session_token() (type:function)
            └─ Test-Suite #450: refresh_session_token() Coverage (role:test suite)
                 ├─ Test #551: Valid token refresh [T-551] (type:test)
                 ├─ Test #651: Expired token [T-651] (type:test)
                 └─ Test #652: Invalid token [T-652] (type:test)
```

---

## Common Questions

### Q: Can I skip levels in the hierarchy?

**A:** No. The hierarchy must be followed:

- Every Sub-Feature must have a parent Feature
- Every Function must have a parent Sub-Feature
- Every Test-Suite must have a parent Function
- Every Test must have a parent Test-Suite

This ensures traceability from user outcome to individual test.

### Q: What if my feature is small (only one function)?

**A:** Still create all levels:

1. Feature (user outcome)
2. Sub-Feature (AC from Feature)
3. Function (contract)
4. Test-Suite (coverage plan)
5. Tests (IB/OOB cases)

The overhead is minimal, and it maintains consistency.

### Q: Can one Sub-Feature have multiple Functions?

**A:** Yes! A Sub-Feature can require multiple functions. Create separate Function issues for each, all linked to the same parent Sub-Feature.

### Q: Can one Function have multiple Test-Suites?

**A:** Typically no. One Function = One Test-Suite. However, if you have distinct test categories (unit tests, integration tests, performance tests), you could create separate suites.

### Q: How do I know if I need IB or OOB tests?

**A:** Every Test-Suite must have:

- **Minimum:** IB ≥ 1, OOB ≥ 2
- **IB (In-Bounds):** Valid inputs that should produce correct behavior
- **OOB (Out-of-Bounds):** Edge cases, invalid inputs, error conditions

### Q: What about refactoring work?

**A:** Use Feature template, select "Refactor" work type. Follow same hierarchy:

- Feature: Refactoring goal (e.g., "Improve performance of data processing")
- Sub-Features: Specific refactor areas
- Functions: Functions being refactored (with updated contracts)
- Test-Suites: Verify behavior unchanged (tests should still pass!)

### Q: What about infrastructure/tooling work?

**A:** Use Feature template, select "Tooling" work type. Follow same hierarchy:

- Feature: Tooling goal (e.g., "Add CI/CD pipeline")
- Sub-Features: Pipeline stages
- Functions: Scripts/tools being built
- Test-Suites: Verify tools work correctly

---

## Tips for Success

1. **Start at the top:** Always create Feature first, then break down
2. **One AC = One Sub-Feature:** Each acceptance criterion becomes exactly one Sub-Feature
3. **Write contracts first:** Define Function contracts BEFORE implementing
4. **Write tests first:** Create Test issues BEFORE writing function code (TDD)
5. **Link everything:** Always link children to parents for traceability
6. **Use ready gates:** Check all ready gate items before marking issue ready
7. **Minimum coverage:** Never skip the minimum IB≥1, OOB≥2 requirement

---

## Related Documentation

- **ATOMIC_TDD_FRAMEWORK.md** - Complete methodology and philosophy
- **LABEL_DESIGN_SPEC.md** - Full label taxonomy and usage rules
- **current_work_todo.md** - Example of atomic task breakdown
- **Template Schemas** - `docs/templates/template_schemas_design.md`

---

**Last Updated:** 2025-11-10
**Maintained by:** Jackson-Devices
