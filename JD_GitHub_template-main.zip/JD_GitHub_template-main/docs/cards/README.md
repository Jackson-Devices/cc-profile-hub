# Documentation Cards

Self-contained documentation cards optimized for token-efficient access by both humans and AI agents.

## Overview

Documentation cards provide focused, modular documentation snippets that can be combined into bundles for specific tasks. Each card is self-contained with validated metadata and token estimation.

## Directory Structure

```
docs/cards/
├── README.md              # This file
├── card-schema.json       # JSON Schema for validation
├── quick/                 # ~100 words - Quick references
├── task/                  # ~200 words - Implementation approaches
└── deep/                  # No limit - Deep dives
```

## Card Levels

### Quick (~100 words)

- **Purpose:** Rapid reference for concepts, terms, or quick lookups
- **Target tokens:** ~25-150 tokens
- **Use cases:** Label taxonomy, command syntax, quick definitions
- **Example:** `quick/label-taxonomy.md`

### Task (~200 words)

- **Purpose:** Implementation guidance and strategies
- **Target tokens:** ~150-500 tokens
- **Use cases:** Authentication strategies, workflow patterns, architecture decisions
- **Example:** `task/jwt-auth-strategy.md`

### Deep (no limit)

- **Purpose:** Comprehensive deep dives and philosophy
- **Target tokens:** 500+ tokens
- **Use cases:** Testing philosophy, security patterns, architecture deep dives
- **Example:** `deep/tdd-philosophy.md`

## Card Format

Each card is a Markdown file with YAML front-matter:

```markdown
---
id: card-identifier
title: 'Card Title'
topics:
  - topic1
  - topic2
audience: both
level: task
tokens_estimate: 287
since_commit: abc123f
last_verified_commit: abc123f
source_paths:
  - src/auth/jwt.js
  - src/middleware/auth.js
related_tasks:
  - user-authentication
version: 1.0.0
---

# Card Title

Card content goes here...
```

## Metadata Fields

### Required Fields

| Field                  | Type    | Description          | Validation                          |
| ---------------------- | ------- | -------------------- | ----------------------------------- |
| `id`                   | string  | Unique identifier    | kebab-case, unique across all cards |
| `title`                | string  | Human-readable title | 1-100 characters                    |
| `topics`               | array   | Tags for filtering   | At least 1 topic                    |
| `audience`             | enum    | Target audience      | `human`, `agent`, or `both`         |
| `level`                | enum    | Card complexity      | `quick`, `task`, or `deep`          |
| `tokens_estimate`      | integer | Token count estimate | Calculated via heuristic            |
| `since_commit`         | string  | Creation commit      | 7-40 character git hash             |
| `last_verified_commit` | string  | Last verification    | 7-40 character git hash             |
| `version`              | string  | Content version      | Semantic version (e.g., "1.0.0")    |

### Optional Fields

| Field           | Type  | Description                              |
| --------------- | ----- | ---------------------------------------- |
| `source_paths`  | array | Dependent file paths for drift detection |
| `related_tasks` | array | Task IDs from `tasks.map.yaml`           |

## Token Estimation

Token estimates use a simple heuristic:

```
tokens_estimate = CEILING(total_characters / 4)
```

**Includes:**

- YAML front-matter (~50-100 tokens overhead)
- All markdown content (including code blocks)
- Whitespace and formatting

**Validation:**

- Cards are validated to ensure estimates are within ±10% of actual
- Drift beyond this threshold triggers warnings

**Example calculation:**

```
Content: 1,148 characters
Front-matter overhead: ~75 tokens
Calculation: (1148 + 300) / 4 = 362 tokens
Rounded: 362 tokens
```

## Linking Conventions

### Card-to-Card Links

Use relative markdown links:

```markdown
See [JWT Strategy](../task/jwt-auth-strategy.md) for implementation details.
```

### Anchor Links

Link to specific sections:

```markdown
See [Token Handling](../deep/security-patterns.md#token-handling).
```

### Task References

Reference tasks from `tasks.map.yaml`:

```markdown
This card is used in task: `user-authentication`
```

### Issue References

Link to mirrored issues:

```markdown
Related to issue: [#42](../issues_mirror/042-add-jwt-authentication.md)
```

## Authoring Guide

### 1. Choose the Appropriate Level

- **Quick:** Can you explain this in ~100 words? Use quick/
- **Task:** Does this guide implementation? Use task/
- **Deep:** Is this a comprehensive deep dive? Use deep/

### 2. Create the Card File

File naming: `{level}/{id}.md`

```bash
# Example
touch docs/cards/task/jwt-auth-strategy.md
```

### 3. Add Front-Matter

Start with complete metadata:

```yaml
---
id: jwt-auth-strategy
title: 'JWT Authentication Strategy'
topics:
  - authentication
  - security
  - jwt
audience: both
level: task
tokens_estimate: 287
since_commit: abc123f
last_verified_commit: abc123f
source_paths:
  - src/auth/jwt.js
  - src/middleware/auth-check.js
related_tasks:
  - user-authentication
version: 1.0.0
---
```

### 4. Write Self-Contained Content

- **Assume no context:** Cards should be understandable standalone
- **Link liberally:** Cross-reference related cards
- **Be concise:** Stay within token budgets for level
- **Use code examples:** Show, don't just tell

### 5. Calculate Token Estimate

```bash
# Count characters in file
wc -c docs/cards/task/jwt-auth-strategy.md
# Divide by 4, round up
```

### 6. Get Current Commit Hash

```bash
git rev-parse --short HEAD
# Use this for since_commit and last_verified_commit
```

### 7. Validate

```bash
npm run validate:docs -- --card=docs/cards/task/jwt-auth-strategy.md
```

## Maintenance

### When to Update

Cards should be updated when:

1. **Source code changes:** Files in `source_paths` are modified
2. **Drift detected:** Automation flags card as potentially stale
3. **Content inaccurate:** Manual verification reveals issues
4. **Version bump needed:** Significant content changes

### Update Procedure

1. Edit card content
2. Recalculate `tokens_estimate`
3. Update `last_verified_commit` to current HEAD
4. Increment `version` following semver:
   - **Patch (1.0.1):** Typos, clarifications, no semantic changes
   - **Minor (1.1.0):** Content additions, new examples
   - **Major (2.0.0):** Breaking changes, complete rewrites
5. Apply `Docs: Ready` label to related issues

### Drift Detection

The system automatically monitors `source_paths`:

- Commit changes to monitored files trigger drift detection
- Related issues are labeled `Docs: Needed`
- PR comments list affected cards
- **Warn-only:** Never blocks merges

To resolve drift:

```bash
# 1. Review card
# 2. Update content if needed
# 3. Update last_verified_commit
git rev-parse --short HEAD
# 4. Update version
# 5. Commit
git add docs/cards/task/jwt-auth-strategy.md
git commit -m "docs: verify jwt-auth-strategy card (issue #42)"
```

## Best Practices

### ID Naming

- **Descriptive:** `jwt-auth-strategy` not `auth1`
- **Kebab-case:** `state-machine` not `stateMachine`
- **Unique:** Check existing cards before naming

### Topics

- Use consistent topic names
- Prefer existing topics over creating new ones
- Include 2-5 topics per card
- Common topics: `authentication`, `testing`, `workflow`, `architecture`

### Audience

- **human:** Documentation for developers (rich examples, context)
- **agent:** Optimized for AI (structured, token-conscious)
- **both:** Dual-optimized (most cards should use this)

### Source Paths

List all files the card's accuracy depends on:

```yaml
source_paths:
  - src/auth/jwt.js
  - src/middleware/auth-check.js
  - config/auth.config.js
```

### Related Tasks

Reference tasks that include this card:

```yaml
related_tasks:
  - user-authentication
  - api-security-hardening
```

## Validation Schema

Cards are validated against `card-schema.json`:

```bash
npm run validate:docs
```

**Checks performed:**

- Metadata schema compliance
- Token estimate accuracy (±10%)
- Link resolution (broken links)
- Unique IDs
- Near-duplicate detection

## Examples

See the example cards:

- `quick/label-taxonomy.md` - Quick reference example
- `task/testing-workflow.md` - Task guidance example
- `deep/tdd-philosophy.md` - Deep dive example

## Integration

Cards integrate with:

1. **Tasks Map (`tasks.map.yaml`):** Deterministic card selection for tasks
2. **Validation CLI:** Comprehensive validation checks
3. **Drift Detection:** Automated staleness monitoring
4. **Bundle Generator:** Precompiled card bundles for tasks
5. **Issue Mirroring:** Cross-references with GitHub issues

## Troubleshooting

### Validation Fails: "Token estimate drift"

Recalculate tokens:

```bash
# Get character count
wc -c docs/cards/task/your-card.md
# Divide by 4, round up
# Update tokens_estimate in front-matter
```

### Validation Fails: "Broken link"

Check that the target file exists:

```bash
ls -la docs/cards/deep/target-card.md
# Fix the path or create the target card
```

### Drift Detection False Positive

Update `last_verified_commit` if content is still accurate:

```bash
git rev-parse --short HEAD
# Update last_verified_commit in front-matter
```

## Contributing

1. Create card following authoring guide
2. Validate locally: `npm run validate:docs`
3. Add example cards to demonstrate usage
4. Update tasks map if applicable
5. Submit PR with `Docs: Ready` label

---

**Schema Version:** 1.0.0
**Last Updated:** 2025-11-11
**Related:** [Token-Efficient Docs Feature](../../FEATURE_token_efficient_docs_system.md)
