---
id: testing-workflow
title: 'Testing Workflow Strategy'
topics:
  - testing
  - workflow
  - tdd
audience: both
level: task
tokens_estimate: 287
since_commit: 52896df
last_verified_commit: 52896df
source_paths:
  - docs/TESTING_GUIDE.md
  - docs/TESTING_QUICK_REFERENCE.md
related_tasks: []
version: 1.0.0
---

# Testing Workflow Strategy

## Overview

This project follows a test-first development approach with multiple test types organized hierarchically.

## Test Hierarchy

1. **Unit Tests** - Test individual functions/classes in isolation
2. **Integration Tests** - Test component interactions
3. **System Tests** - Test complete workflows end-to-end

## Workflow

```bash
# 1. Write failing test first
npm test -- --watch test/unit/myfeature.test.js

# 2. Implement minimum code to pass
# 3. Refactor while keeping tests green
# 4. Run full suite before commit
npm test
```

## Best Practices

- **Arrange-Act-Assert** pattern for test structure
- **One assertion per test** for clarity
- **Descriptive test names** that explain intent
- **Mock external dependencies** in unit tests

## Test Organization

```
test/
├── unit/          # Fast, isolated unit tests
├── integration/   # Component integration tests
└── system/        # Full workflow tests
```

See [Testing Guide](../../TESTING_GUIDE.md) for comprehensive details.
