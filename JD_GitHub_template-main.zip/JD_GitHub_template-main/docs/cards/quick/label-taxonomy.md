---
id: label-taxonomy
title: 'Label Taxonomy Quick Reference'
topics:
  - labels
  - workflow
  - organization
audience: both
level: quick
tokens_estimate: 95
since_commit: 52896df
last_verified_commit: 52896df
source_paths:
  - LABEL_DESIGN_SPEC.md
related_tasks: []
version: 1.0.0
---

# Label Taxonomy Quick Reference

This project uses a structured label taxonomy with categories:

**Type:** Feature, Bug, Docs, Test
**Role:** Sub-Feature, Function, Task
**Workflow:** Backlog, In-Progress, Review, Done
**Difficulty:** XS, S, M, L, XL
**AI:** Autonomous, Supervised, Review

Labels follow the pattern: `Category: Value` (e.g., `Type: Feature`, `Workflow: In-Progress`).

See [LABEL_DESIGN_SPEC.md](../../LABEL_DESIGN_SPEC.md) for complete taxonomy.
