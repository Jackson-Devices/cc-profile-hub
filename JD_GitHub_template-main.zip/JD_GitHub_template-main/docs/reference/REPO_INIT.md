# Repository Initialization

Sets up consistent, brand-standard labels for Jackson-Devices workflow alignment.

NOTE WHETHER HUMAN OR AI

This is out of date dont use it.

## Human Instructions

### Step 1: Review Labels (Optional)

**Where:** Open `.github/settings.yml` in your editor
**Why:** Check if the default Jackson-Devices label taxonomy works for this specific repo
**What:** The file lists all labels that will exist. The workflow DELETES any labels not in this file.

Current label categories:

- Difficulty levels (trivial → complex)
- AI capability (autonomous → human-only)
- Workflow status (backlog → blocked)
- Work types (bug, feature, refactor, docs, etc.)
- Special flags (needs-human)

### Step 2: Preview Changes

**Where:** GitHub.com > Your Repo > Actions tab > "apply_repo_settings_labels"
**Why:** See exactly what will change before applying
**What to do:**

1. Click "Run workflow" button (top right)
2. Select branch: `main`
3. Select mode: `dry_run`
4. Click green "Run workflow" button
5. Wait for workflow to finish (refresh page)
6. Click on the workflow run to see what labels will be created/updated/deleted

### Step 3: Apply Changes

**Where:** Same place (Actions > apply_repo_settings_labels)
**Why:** Actually make the label changes
**What to do:**

1. Click "Run workflow" again
2. Select branch: `main`
3. Select mode: `apply`
4. Click green "Run workflow" button
5. Workflow runs preview first, then applies changes automatically (no approval needed)

### Step 4: Verify

**Where:** GitHub.com > Your Repo > Issues tab > Labels (in left sidebar)
**Why:** Confirm labels look correct
**What to check:**

- All Jackson-Devices brand labels exist with correct colors
- Old GitHub default labels (bug, documentation, etc.) are gone
- Colors and descriptions match expectations

### Step 5: Clean Up

**Where:** Your local git repo
**Why:** Remove this instruction file to keep repo clean
**What to do:**

```bash
git rm REPO_INIT.md
git commit -m "Remove init checklist"
git push
```

## No Manual Setup Required

You do NOT need to:

- Create GitHub Environments (removed - free plan doesn't support required reviewers)
- Set any secrets or variables (GITHUB_TOKEN is automatic)
- Configure deployment branches
- Add collaborators

The workflow handles everything once you trigger it.

## Troubleshooting

**"Guardrail violation"** - Repo owner or actor isn't "Jackson-Devices"

**Labels not changing** - Check Actions tab for error details

**Want to undo changes** - Edit `.github/settings.yml`, commit to main, workflow re-runs automatically
