rules:\
1.define problem/features 2.define success criteria 3.define constraints/limits 4.identify dependencies/risks 5.list edge cases first 6.each test = single atomic check for one sub-case 7.order tests: simple > simple-edge > complex > complex-edge 8.plan all tests before implementation 9.parent issue defines feature/bug; first child = test suite planning 10.test suite child issues = individual tests 11.test suite must be built & validated before coding 12.implement minimal solution only after test suite confirmed 13.re-run tests after every change 14.no scope increase without updating tests/constraints format\
before code AI must output: \
problem: constraints: success criteria: dependencies: risks: tests(simple>simple-edge>complex>complex-edge)\
agent guardrails:\
if problem/constraints/tests missing- stop & request.&#x20;

if scope drift → stop & respec&#x20;

test principles:&#x20;

narrow & isolated; one assert per behavior; fail fast; no silent tolerance; edge inputs first; synthetic and specific not just random&#x20;

hier: p=feature|bug|etc > c1=build_test_suite > c1.children=test(valid=required); c2..cn=sub_feature -> recurse(same rules); gate: code_start only after c1.validated=true
