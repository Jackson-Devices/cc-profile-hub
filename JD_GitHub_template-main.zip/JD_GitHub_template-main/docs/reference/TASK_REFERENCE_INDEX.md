# Task Reference Index

**Generated:** 2025-11-10
**Purpose:** Complete mapping of all tasks across TODO files - NO TASKS LOST

This document ensures every planned task is referenced and trackable. The main task list is `current_work_todo.md` (atomic P0-P4 plan), with detailed subtasks referenced from archived documents.

---

## Primary Task List

**File:** `current_work_todo.md`
**Status:** Active - Single source of truth for atomic task plan
**Structure:** P0 (Critical Foundation) → P1 (Core Infrastructure) → P2 (Testing) → P3 (Enhancements) → P4 (Future Research)

### Coverage Map

| Priority | Section                           | Tasks          | Status                  | Reference     |
| -------- | --------------------------------- | -------------- | ----------------------- | ------------- |
| P0.1     | Label Taxonomy                    | 6 tasks        | ✅ COMPLETED 2025-11-10 | Lines 23-64   |
| P0.2     | Issue Template Framework          | 16 tasks       | ⏳ NEXT                 | Lines 67-213  |
| P1.0     | Environment Setup                 | 4 tasks        | ⏳ PENDING              | Lines 222-257 |
| P1.1     | Documentation Refactoring         | 8 tasks        | ⏳ PENDING              | Lines 260-366 |
| P1.2     | Code Formatter Remaining Tasks    | 3 tasks        | ⏳ PENDING              | Lines 369-414 |
| P1.3     | Decision Logging Infrastructure   | 2 tasks        | ⏳ PENDING              | Lines 417-442 |
| P1.5     | Issue #26 Atomic Breakdown        | 5 tasks        | ⏳ PENDING              | Lines 445-501 |
| P2.1     | Unit Test Framework Setup         | 10 tasks       | ⏳ PENDING              | Lines 508-623 |
| P2.2     | Integration Tests                 | 4 agents       | ⏳ PENDING              | Lines 626-665 |
| P3.1     | Formatter Enhancements            | 3 agents       | ⏳ PENDING              | Lines 674-701 |
| P3.2     | Workflow Enhancements             | 6 tasks        | ⏳ PENDING              | Lines 704-758 |
| P3.3     | Issue Template AI Metadata Fields | 4 tasks        | ⏳ PENDING              | Lines 761-794 |
| P4.1-4.4 | Future Research                   | 4 placeholders | ⏳ DEFERRED             | Lines 801-816 |

---

## Detailed Task References

### Code Formatters (P1.2 Extended Details)

**Primary:** `current_work_todo.md` lines 369-414 (3 high-level tasks)
**Detailed Subtasks:** See `docs/archive/TODO_2025-11-10.md` lines 40-451

#### Formatter Steps 1-10 (TODO.md archived reference):

| Step    | Description                | Status              | Reference                                 |
| ------- | -------------------------- | ------------------- | ----------------------------------------- |
| Step 1  | Choose Formatter Stack     | ✅ COMPLETED        | `docs/archive/TODO_2025-11-10.md:54-85`   |
| Step 2  | Define House Style Rules   | ✅ COMPLETED        | `docs/archive/TODO_2025-11-10.md:87-133`  |
| Step 3  | Pre-Commit Formatting Hook | ✅ COMPLETED        | `docs/archive/TODO_2025-11-10.md:136-162` |
| Step 4  | GitHub Actions Integration | ✅ COMPLETED        | `docs/archive/TODO_2025-11-10.md:165-218` |
| Step 5  | Cloudflare Workers Support | ⏳ PENDING (Future) | `docs/archive/TODO_2025-11-10.md:221-246` |
| Step 6  | Formatter Diff & Review UI | ✅ COMPLETED        | `docs/archive/TODO_2025-11-10.md:249-309` |
| Step 7  | Documentation & Training   | ⏳ MAPS TO P1.2     | `docs/archive/TODO_2025-11-10.md:312-337` |
| Step 8  | Testing & Validation       | ⏳ MAPS TO P1.2     | `docs/archive/TODO_2025-11-10.md:340-374` |
| Step 9  | Incremental Rollout        | ⏳ MAPS TO P1.2     | `docs/archive/TODO_2025-11-10.md:377-422` |
| Step 10 | Future Enhancements        | ⏳ MAPS TO P3.1     | `docs/archive/TODO_2025-11-10.md:424-451` |

**Mapping:** P1.2 Task 1 (Documentation) = Step 7, Task 2 (Testing) = Step 8, Task 3 (Rollout) = Step 9

---

### Logging Infrastructure (P1.3 Extended Details)

**Primary:** `current_work_todo.md` lines 417-442 (GitHub Actions logging only)
**Detailed Design:** See `docs/archive/TODO_REVIEW_AND_LOGGING_PLAN_2025-11-10.md` lines 600-1035

#### Logging Tiers (TODO_REVIEW_AND_LOGGING_PLAN.md archived reference):

| Tier   | Description                             | Status         | Reference                                                         |
| ------ | --------------------------------------- | -------------- | ----------------------------------------------------------------- |
| Tier 1 | Client-Side Logging (Claude Code hooks) | ⏳ FUTURE      | `docs/archive/TODO_REVIEW_AND_LOGGING_PLAN_2025-11-10.md:616-719` |
| Tier 2 | GitHub Actions Logging                  | ✅ IMPLEMENTED | `docs/archive/TODO_REVIEW_AND_LOGGING_PLAN_2025-11-10.md:720-847` |
| Tier 3 | Cloudflare Workers Logging              | ⏳ FUTURE (P4) | `docs/archive/TODO_REVIEW_AND_LOGGING_PLAN_2025-11-10.md:848-950` |

**Mapping:** P1.3 covers Tier 2 verification only. Tier 1 and Tier 3 are P4 future work.

---

### Pre-Push Commit Squashing Hook

**Source:** `docs/archive/TODO_2025-11-10.md` lines 452-509
**Status:** ⏳ PENDING - Not yet mapped to P0-P4
**Recommendation:** Add as **P1.4** after P1.3, before P1.5

#### Tasks (High Priority):

1. Create `.claude/hooks/pre_push_squash.mjs` script
2. Detect commits ahead of remote branch
3. Interactive squash UI with commit selection
4. GPT-4/Claude API integration for commit message generation
5. Squash commit message quality validation
6. Add to `.claude/hooks.json.example`
7. Document in `.claude/README.md`
8. Test with multiple commit scenarios

**Estimated Time:** ~60 minutes
**Dependencies:** P1.0 complete (npm/node available)

---

### Documentation Refactoring (P1.1 Comparison)

**Primary:** `current_work_todo.md` lines 260-366
**Original:** `docs/archive/TODO_2025-11-10.md` lines 606-712
**Improved Breakdown:** `docs/archive/TODO_REVIEW_AND_LOGGING_PLAN_2025-11-10.md` lines 56-180

**Status:** ✅ Tasks are well-defined in current_work_todo.md (uses improved breakdown)

---

### Issue Template Enhancements (P0.2 & P3.3)

**P0.2 (Foundation Templates):** `current_work_todo.md` lines 67-213
**P3.3 (AI Metadata Fields):** `current_work_todo.md` lines 761-794
**Original Source:** `docs/archive/TODO_2025-11-10.md` lines 725-764

**Status:** ✅ Tasks are complete in current_work_todo.md

---

### Workflow Enhancements

**P3.2 (Max Pass Enforcement):** `current_work_todo.md` lines 704-758
**Original Source:** `docs/archive/TODO_2025-11-10.md` lines 765-815
**Extended Design:** `docs/archive/TODO_REVIEW_AND_LOGGING_PLAN_2025-11-10.md` lines 232-283

**Status:** ✅ Tasks are complete in current_work_todo.md

---

### Testing Infrastructure (P2.1 & P2.2)

**P2.1 (Unit Tests):** `current_work_todo.md` lines 508-623
**P2.2 (Integration Tests):** `current_work_todo.md` lines 626-665
**Original Source:** `docs/archive/TODO_2025-11-10.md` lines 865-890, 917-951
**Issue Reference:** Issue #26 (comprehensive testing infrastructure)

**Status:** ✅ Tasks are well-defined in current_work_todo.md

---

### Future Enhancements (P4)

**Primary:** `current_work_todo.md` lines 801-816 (placeholders only)
**Detailed Specifications:** See `docs/archive/TODO_2025-11-10.md`

| Enhancement                                       | Status            | Reference                                   |
| ------------------------------------------------- | ----------------- | ------------------------------------------- |
| Slack Integration                                 | ⏳ DEFERRED       | `docs/archive/TODO_2025-11-10.md:894-916`   |
| Testing Infrastructure (GitHub Actions Synthetic) | ⏳ RESEARCH PHASE | `docs/archive/TODO_2025-11-10.md:932-953`   |
| PlatformIO/LLVM Firmware Validation               | ⏳ RESEARCH PHASE | `docs/archive/TODO_2025-11-10.md:954-1075`  |
| Cloudflare Workers Offloading                     | ⏳ RESEARCH PHASE | `docs/archive/TODO_2025-11-10.md:1076-1178` |
| Hierarchy Flexibility                             | ⏳ FUTURE         | `docs/archive/TODO_2025-11-10.md:1179-1192` |
| Specialized GitHub Issue Agents                   | ⏳ DESIGN PHASE   | `docs/archive/TODO_2025-11-10.md:1193-1210` |

**Note:** P4 items should NOT be started until P0-P3 are complete.

---

## Completed Tasks Archive

**Primary Location:** `current_work_todo.md` (📜 COMPLETED TASKS ARCHIVE section, to be added)
**Historical Details:** `docs/archive/TODO_2025-11-10.md` lines 1220-1467

### Major Completed Work (from TODO.md):

| Session                    | Date       | Description                 | Lines                                       |
| -------------------------- | ---------- | --------------------------- | ------------------------------------------- |
| Label Taxonomy v1.3        | 2025-11-10 | P0.1 complete (atomic plan) | `current_work_todo.md:876-897`              |
| Formatter Diff & Review UI | 2025-11-09 | Step 6 complete             | `docs/archive/TODO_2025-11-10.md:249-309`   |
| Atomic TDD Framework       | 2025-11-10 | Documentation complete      | `even_more_todo.md` (entire file)           |
| Pre-Push Squashing Hook    | 2025-11-08 | Enhanced features           | `docs/archive/TODO_2025-11-10.md:1433-1467` |
| Workflow Improvements      | 2025-11-08 | Multiple sessions           | `docs/archive/TODO_2025-11-10.md:1249-1431` |
| Label Design Spec          | 2025-11-08 | apply_settings.mjs fixes    | `docs/archive/TODO_2025-11-10.md:1356-1407` |

---

## Reference Documents

### Active Reference Material (Not Archived)

| File                                              | Purpose                     | Keep/Archive          |
| ------------------------------------------------- | --------------------------- | --------------------- |
| `ATOMIC_TDD_FRAMEWORK.md` (was even_more_todo.md) | TDD framework specification | ✅ KEEP (reference)   |
| `LABEL_DESIGN_SPEC.md`                            | Label taxonomy (v1.3)       | ✅ KEEP (active spec) |
| `README.md`                                       | System overview             | ✅ KEEP (active docs) |
| `.github/WORKFLOW_BEHAVIOR.md`                    | Workflow documentation      | ✅ KEEP (active docs) |

### Archived Historical Documents

| File                              | Purpose                       | Archive Location                                          |
| --------------------------------- | ----------------------------- | --------------------------------------------------------- |
| `TODO.md`                         | Historical comprehensive TODO | `docs/archive/TODO_2025-11-10.md`                         |
| `TODO_REVIEW_AND_LOGGING_PLAN.md` | Logging design & audit        | `docs/archive/TODO_REVIEW_AND_LOGGING_PLAN_2025-11-10.md` |
| `todo_compatibility_analysis.md`  | Binary/corrupt file           | DELETE (corrupted)                                        |

---

## Task Status Legend

- ✅ **COMPLETED:** Task fully finished with timestamp and attribution
- ⏳ **PENDING:** Task defined, not yet started
- 🔄 **IN PROGRESS:** Task currently being worked on
- ❌ **SKIPPED:** Task intentionally not done with documented reason
- ⏸️ **DEFERRED:** Task postponed with condition for resumption

---

## How to Use This Index

1. **Finding Tasks:** Check `current_work_todo.md` first (P0-P4 atomic plan)
2. **Detailed Subtasks:** Use this index to find archived references for granular details
3. **Completed Work:** See both `current_work_todo.md` archive section and `docs/archive/TODO_2025-11-10.md:1220-1467`
4. **Missing Tasks:** If a task isn't in `current_work_todo.md` or this index, it doesn't exist (no tasks lost)
5. **Worktree Workflow:** See below for git worktree execution pattern (CRITICAL for AI work)

---

## Git Worktree Workflow for Atomic Tasks (REQUIRED FOR AI)

**CRITICAL:** This workflow prevents commit pileup and enables true parallel AI work.

### Core Principle

**Each atomic phase = One branch = One worktree = One PR = Clean merge**

### Why This Matters

When AI makes sequential commits on one branch, they pile up and get merged together (garbled descriptions, lost audit trail). With worktrees, each phase is isolated:

```
❌ OLD WAY (Single Branch):
Branch: claude/task-123
├─ Commit 1: Phase 1
├─ Commit 2: Phase 2A     } Merged together = garbled
├─ Commit 3: Phase 2B     } descriptions, no audit trail
└─ Commit 4: Phase 3      }

✅ NEW WAY (Worktrees):
Branch: claude/p0.2-phase1-[session]  → Commit 1 (merged independently)
Branch: claude/p0.2-phase2a-[session] → Commit 1 (merged independently)
Branch: claude/p0.2-phase2b-[session] → Commit 1 (merged independently)
Branch: claude/p0.2-phase3-[session]  → Commit 1 (merged independently)
```

### Execution Pattern for AI

**When starting a new phase:**

```bash
# 1. Return to main repository directory
cd /home/user/JD_GitHub_template

# 2. Fetch latest from main (get merged work)
git fetch origin main
git rebase origin/main  # or git pull if on main

# 3. Create worktree for new phase
SESSION_ID="011CUyMw7SwXELdrkt2QzyvZ"  # From context
PHASE_ID="p0.2-phase3"                  # Current phase identifier

git worktree add ../JD_GitHub_template-worktrees/${PHASE_ID} \
  -b claude/${PHASE_ID}-${SESSION_ID}

# 4. Change to worktree directory
cd ../JD_GitHub_template-worktrees/${PHASE_ID}

# 5. Verify clean state
git status
git log --oneline -3

# 6. Execute atomic tasks for this phase
# ... work happens here ...

# 7. Commit with comprehensive description (see template below)
git add .
git commit -m "$(cat <<'EOF'
<type>: <short summary> (P<priority>.<section> Phase <X>)

<Comprehensive description following audit-friendly format>
- What was created/changed
- Why it matters
- Key decisions
- Related tasks
- Next steps

Files: <list of changed files>
Related: <task references>
Next: <next phase>
EOF
)"

# 8. Push branch
git push -u origin claude/${PHASE_ID}-${SESSION_ID}

# 9. Human creates PR and merges when ready
# AI does NOT wait - moves to next independent phase

# 10. Clean up worktree after merge (human or AI)
cd /home/user/JD_GitHub_template
git worktree remove ../JD_GitHub_template-worktrees/${PHASE_ID}
git branch -d claude/${PHASE_ID}-${SESSION_ID}  # Local cleanup
```

### Decision Tree: Use Worktree or Not?

```
Start New Phase
      |
      v
Has upstream dependency on uncommitted work?
      |
      ├─ YES → Wait for dependency merge, then use worktree
      |
      └─ NO → Can start immediately
                |
                v
         Is this phase independently mergeable?
                |
                ├─ YES → USE WORKTREE (new branch)
                |         Examples:
                |         - Phase 1 (schemas) vs Phase 2A (implementations)
                |         - Phase 2B (verification) vs Phase 3 (integration)
                |         - Documentation vs testing
                |
                └─ NO → Stay on current branch
                          Examples:
                          - Single atomic task
                          - Sequential tasks building on each other
                          - Rapid iteration with immediate merge
```

### Worktree Directory Structure

```
/home/user/
  ├─ JD_GitHub_template/          # Main clone (read-only during worktree work)
  └─ JD_GitHub_template-worktrees/
       ├─ p0.2-phase1/             # Worktree for Phase 1
       ├─ p0.2-phase2a/            # Worktree for Phase 2A
       ├─ p0.2-phase2b/            # Worktree for Phase 2B
       └─ p0.2-phase3/             # Worktree for Phase 3
```

### Commit Message Template for Phases

```
<type>: <Short summary (50 chars)> (P<X>.<Y> Phase <Z>)

<Comprehensive multi-paragraph description>

**What was created/implemented:**
- Bullet list of deliverables
- Specific files and their purpose

**Why this matters:**
- Connection to overall goal
- Dependencies satisfied
- Value delivered

**Key design decisions:**
- Important choices made
- Rationale for approach
- Alternatives considered

**Verification performed:**
- Tests run
- Validation completed
- Quality checks passed

**Files:**
- path/to/file1.ext (purpose)
- path/to/file2.ext (purpose)

**Related:** P<X>.<Y> tasks A-B (current_work_todo.md:XXX-YYY)
**Next:** P<X>.<Y> Phase <Z+1> - <brief description>
**Task:** current_work_todo.md:XXX-YYY
```

### Benefits Recap

✅ **No commit pileup** - Each phase merges independently
✅ **Audit-friendly** - Comprehensive descriptions preserved
✅ **True parallelization** - Work on Phase 3 while Phase 1 awaits review
✅ **No garbled descriptions** - Each PR has one focused commit
✅ **Dependency-safe** - Atomic tasks with explicit upstream markers
✅ **Compounding engineering** - Each phase leaves reusable artifacts

---

## Quick Reference: Where Is Task X?

| Looking For...               | Check...                                                                     |
| ---------------------------- | ---------------------------------------------------------------------------- |
| Next atomic task to work on  | `current_work_todo.md` - Next section after completed work                   |
| Detailed formatter subtasks  | This index → Formatter Steps 1-10 → Archive reference                        |
| Logging infrastructure tiers | This index → Logging Tiers → Archive reference                               |
| Completed work history       | `current_work_todo.md` archive + `docs/archive/TODO_2025-11-10.md:1220-1467` |
| P0-P4 task definitions       | `current_work_todo.md` (atomic task list)                                    |
| Future research specs        | This index → Future Enhancements → Archive references                        |

---

**Last Updated:** 2025-11-10
**Maintainer:** Jackson-Devices (AI-assisted)
**Version:** 1.0
