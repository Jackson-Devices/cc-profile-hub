# Repository Variables Documentation

**Last Updated:** 2025-11-14
**Status:** Documented

---

## Overview

This document describes all GitHub Actions repository variables and secrets used in this repository. Repository variables provide centralized configuration management for workflows, allowing easy updates without modifying workflow files.

**Location:** GitHub → Settings → Secrets and variables → Actions → Variables tab

---

## Current Repository Variables

### Security & Access Control

#### `OWNER_ALLOWLIST`

- **Type:** String (comma-separated list)
- **Default:** `"Jackson-Devices"`
- **Used By:** `apply_settings.yml`
- **Purpose:** List of GitHub usernames allowed to trigger protected operations
- **Example:** `"Jackson-Devices,other-user"`
- **Security Level:** High - Controls who can modify repo settings

#### `ACTOR_ALLOWLIST`

- **Type:** String (comma-separated list)
- **Default:** `"Jackson-Devices"`
- **Used By:** `apply_settings.yml`
- **Purpose:** List of GitHub usernames authorized for specific actions
- **Example:** `"Jackson-Devices,bot-account"`
- **Security Level:** High - Controls workflow execution permissions

#### `ON_GUARD_ACTION`

- **Type:** String (enum)
- **Default:** `"fail"`
- **Options:** `"fail"`, `"warn"`, `"skip"`
- **Used By:** `apply_settings.yml`
- **Purpose:** Action to take when unauthorized access is detected
- **Security Level:** High - Defines security policy enforcement

---

### Label Management

#### `STRICT_LABEL_SYNC`

- **Type:** Boolean (string)
- **Default:** `"true"`
- **Options:** `"true"`, `"false"`
- **Used By:** `apply_settings.yml`
- **Purpose:** Enforce strict label synchronization (delete labels not in config)
- **Impact:** High - Can remove custom labels if set to `"true"`

---

### Test Validation Requirements

#### `IB_MIN_REQUIRED`

- **Type:** Integer (string)
- **Default:** `"1"`
- **Used By:**
  - `enforce_test_gate.yml`
  - `seed-test-runlist.yml`
  - `validate-issue.yml`
- **Purpose:** Minimum number of "In-Bounds" (IB) tests required for issue validation
- **Impact:** Medium - Blocks issues that don't meet minimum test requirements
- **Related:** See `docs/testing/` for test taxonomy

#### `OOB_MIN_REQUIRED`

- **Type:** Integer (string)
- **Default:** `"2"`
- **Used By:**
  - `enforce_test_gate.yml`
  - `seed-test-runlist.yml`
  - `validate-issue.yml`
- **Purpose:** Minimum number of "Out-of-Bounds" (OOB) tests required for issue validation
- **Impact:** Medium - Enforces edge case test coverage
- **Related:** See `docs/testing/` for test taxonomy

---

### Code Quality Gates

#### `AUTO_FIX_FORMAT`

- **Type:** Boolean (string)
- **Default:** `"true"`
- **Options:** `"true"`, `"false"`
- **Used By:** `format-gate.yml`
- **Purpose:** Automatically fix formatting issues using Prettier
- **Impact:** Medium - Auto-commits formatting fixes when enabled

#### `AUTO_FIX_ESLINT`

- **Type:** Boolean (string)
- **Default:** `"true"`
- **Options:** `"true"`, `"false"`
- **Used By:** `eslint-gate.yml`
- **Purpose:** Automatically fix ESLint violations when possible
- **Impact:** Medium - Auto-commits ESLint fixes when enabled

---

## Recommended Repository Variables (To Be Added)

These variables are recommended for future enhancement to centralize workflow configuration:

### Build & Runtime Configuration

#### `NODE_VERSION` ⭐ **Highly Recommended**

- **Type:** String
- **Proposed Default:** `"20"`
- **Proposed Usage:** All workflows using Node.js
- **Purpose:** Centralized Node.js version for all workflows
- **Benefits:**
  - Single source of truth for Node.js version
  - Easy to update across all 27 workflows
  - Prevents version drift
  - Reduces maintenance burden
- **Migration Path:**
  - Phase 1: Add variable with default `"20"`
  - Phase 2: Update `setup-node-deps` composite action to use variable
  - Phase 3: Migrate workflows to use composite action
- **Impact:** High - Affects all Node.js workflows (23+ workflows)

#### `NPM_CACHE_ENABLED`

- **Type:** Boolean (string)
- **Proposed Default:** `"true"`
- **Proposed Usage:** All workflows installing npm packages
- **Purpose:** Global toggle for npm caching
- **Benefits:**
  - Faster CI builds (2-3 minutes saved per workflow)
  - Easy to disable globally for debugging
  - Reduces npm registry load
- **Impact:** Medium - Affects build performance

#### `NPM_INSTALL_METHOD`

- **Type:** String (enum)
- **Proposed Default:** `"ci"`
- **Options:** `"ci"`, `"install"`, `"specific"`
- **Proposed Usage:** Workflows using `setup-node-deps` composite action
- **Purpose:** Default npm installation method for workflows
- **Benefits:**
  - Consistent installation method across workflows
  - Easy to switch between `npm ci` and `npm install`

---

### Validation & Quality

#### `ENABLE_DEPENDENCY_VALIDATION`

- **Type:** Boolean (string)
- **Proposed Default:** `"true"`
- **Proposed Usage:** Pre-commit hooks, CI validation
- **Purpose:** Run dependency conflict checks before workflow execution
- **Benefits:**
  - Catches dependency conflicts early
  - Prevents CI failures due to peer dependency issues
- **Related:** `.github/scripts/validation/check-dependencies.mjs`

#### `ENABLE_PERMISSION_VALIDATION`

- **Type:** Boolean (string)
- **Proposed Default:** `"true"`
- **Proposed Usage:** Pre-commit hooks, CI validation
- **Purpose:** Validate workflow permissions follow least-privilege principle
- **Benefits:**
  - Security best practices enforcement
  - Catches overly-permissive workflows
- **Related:** `.github/scripts/validation/check-permissions.mjs`

#### `VERBOSE_LOGGING`

- **Type:** Boolean (string)
- **Proposed Default:** `"false"`
- **Proposed Usage:** All workflows (optional)
- **Purpose:** Enable detailed debug logging across workflows
- **Benefits:**
  - Easy debugging without modifying workflow files
  - Can be toggled on-demand for troubleshooting

---

## Variable Usage Patterns

### Pattern 1: Boolean Flags

```yaml
# In workflow file
- name: Check if auto-fix is enabled
  if: ${{ vars.AUTO_FIX_FORMAT == 'true' }}
  run: npm run format
```

**Note:** GitHub Actions variables are always strings. Use `== 'true'` for boolean checks.

### Pattern 2: Numeric Values

```yaml
# In workflow file
env:
  MIN_TESTS: ${{ vars.IB_MIN_REQUIRED }}

- run: |
    if [ "$MIN_TESTS" -lt 1 ]; then
      echo "Error: Minimum tests must be >= 1"
      exit 1
    fi
```

### Pattern 3: Default Values (Fallback)

```yaml
# In workflow file
env:
  NODE_VERSION: ${{ vars.NODE_VERSION || '20' }}

- uses: actions/setup-node@v4
  with:
    node-version: ${{ env.NODE_VERSION }}
```

### Pattern 4: Using in Composite Actions

```yaml
# In composite action (.github/actions/*/action.yml)
inputs:
  node-version:
    description: 'Node.js version'
    required: false
    default: ${{ vars.NODE_VERSION || '20' }}
```

**⚠️ Limitation:** Repository variables are NOT available in composite action default values. Use workflow-level environment variables instead.

**Workaround:**

```yaml
# In workflow file
- uses: ./.github/actions/setup-node-deps
  with:
    node-version: ${{ vars.NODE_VERSION || '20' }}
```

---

## Security Considerations

### Variable vs. Secret

**Use Variables for:**

- ✅ Non-sensitive configuration (Node.js version, feature flags)
- ✅ Public information (usernames, allowlists)
- ✅ Build configuration (cache settings, timeout values)

**Use Secrets for:**

- 🔒 API tokens and keys
- 🔒 Passwords and credentials
- 🔒 SSH keys
- 🔒 Webhook secrets

### Access Control

- **Repository variables** are visible to all workflow runs (including forks in PRs from public forks)
- **Repository secrets** are protected and only available to trusted workflows

### Best Practices

1. **Never store sensitive data in variables** - Use secrets instead
2. **Document all variables** - Add them to this file when created
3. **Use descriptive names** - `NODE_VERSION` not `NV`
4. **Provide defaults** - Always have fallback values in workflows
5. **Version control this file** - Track changes to variable definitions
6. **Review regularly** - Remove unused variables

---

## Variable Change Management

### Adding a New Variable

1. **Define the variable** in this document with:
   - Name, type, default, purpose
   - Used by (which workflows)
   - Impact level (High/Medium/Low)

2. **Create the variable** in GitHub:
   - Go to Settings → Secrets and variables → Actions → Variables
   - Click "New repository variable"
   - Set name and value

3. **Update workflows** to use the variable

4. **Test** the change in a non-critical workflow first

5. **Commit** the updated documentation

### Updating an Existing Variable

1. **Document the change** - Update this file with new default/behavior
2. **Update the variable value** in GitHub Settings
3. **Test** workflows that use the variable
4. **Monitor** for any failures after change

### Removing a Variable

1. **Verify** no workflows use the variable (search codebase)
2. **Remove** from GitHub Settings
3. **Update** this documentation
4. **Remove references** from workflow files

---

## Validation Tools

This repository includes automated validation scripts to check workflow configuration:

### Dependency Validation

```bash
# Check all workflows for dependency conflicts
node .github/scripts/validation/check-dependencies.mjs --all

# Check specific workflow
node .github/scripts/validation/check-dependencies.mjs .github/workflows/orchestrator.yml
```

**What it checks:**

- Peer dependency conflicts (e.g., @octokit package versions)
- Unused dependencies in workflows
- Node.js version consistency
- Package.json compatibility

### Permission Validation

```bash
# Check all workflows for permission issues
node .github/scripts/validation/check-permissions.mjs --all

# Check specific workflow
node .github/scripts/validation/check-permissions.mjs .github/workflows/orchestrator.yml
```

**What it checks:**

- Missing required permissions
- Overly-permissive workflows (least-privilege violations)
- Dangerous permission combinations
- Workflow-level vs. job-level permissions

### Adding to CI

```yaml
# Example: Add validation to PR workflow
- name: Validate workflow configuration
  run: |
    npm run validate:dependencies
    npm run validate:permissions
```

---

## Current Variable Summary

| Variable            | Type    | Default             | Used By            | Impact |
| ------------------- | ------- | ------------------- | ------------------ | ------ |
| `OWNER_ALLOWLIST`   | String  | `"Jackson-Devices"` | apply_settings.yml | High   |
| `ACTOR_ALLOWLIST`   | String  | `"Jackson-Devices"` | apply_settings.yml | High   |
| `ON_GUARD_ACTION`   | Enum    | `"fail"`            | apply_settings.yml | High   |
| `STRICT_LABEL_SYNC` | Boolean | `"true"`            | apply_settings.yml | High   |
| `IB_MIN_REQUIRED`   | Integer | `"1"`               | 3 workflows        | Medium |
| `OOB_MIN_REQUIRED`  | Integer | `"2"`               | 3 workflows        | Medium |
| `AUTO_FIX_FORMAT`   | Boolean | `"true"`            | format-gate.yml    | Medium |
| `AUTO_FIX_ESLINT`   | Boolean | `"true"`            | eslint-gate.yml    | Medium |

**Total Variables:** 8

---

## Related Documentation

- **Centralized Dependencies:** `docs/workflows/CENTRALIZED_DEPENDENCIES.md`
- **Testing Strategy:** `TESTING_STRATEGY_DECISION_LOG.md`
- **Workflow Orchestration:** `.github/workflow-orchestration.yml`
- **Composite Actions:** `.github/actions/*/README.md`

---

## Change Log

| Date       | Change                                            | Updated By  |
| ---------- | ------------------------------------------------- | ----------- |
| 2025-11-14 | Initial documentation of all repository variables | Claude Code |
| 2025-11-14 | Added recommended variables (NODE_VERSION, etc.)  | Claude Code |
| 2025-11-14 | Added validation tools section                    | Claude Code |

---

## Questions?

For questions about repository variables:

1. Check this documentation first
2. Review workflow files that use the variable
3. Check the related documentation links above
4. Open an issue with the `question` label
