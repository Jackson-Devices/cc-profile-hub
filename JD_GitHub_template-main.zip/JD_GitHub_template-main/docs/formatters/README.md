# Code Formatters & House Style Enforcement

## Overview

This repository uses **Prettier** as the primary code formatter to ensure consistent code style across all file types. Automated formatting prevents common errors (especially in YAML and Markdown) that can break GitHub Actions workflows.

## Why Code Formatting?

**Problem:** AI-generated code often introduces formatting errors that break workflows:

- Malformed YAML in GitHub Actions (see commit `6369e47`)
- Inconsistent indentation breaking workflow parsing
- Mixed quote styles and line length issues
- Markdown formatting inconsistencies

**Solution:** Automated formatting with house style rules that:

- ✅ Auto-formats code before committing (prevents broken code from reaching repo)
- ✅ Enforces consistent style rules across all languages
- ✅ Integrates with pre-commit hooks for seamless workflow
- ✅ Provides clear diff review before accepting changes

## Supported Languages

| Language      | Formatter | Configuration      | House Style                         |
| ------------- | --------- | ------------------ | ----------------------------------- |
| YAML          | Prettier  | `.prettierrc.json` | 2 spaces, 100 char line width       |
| Markdown      | Prettier  | `.prettierrc.json` | 100 char width, preserve prose      |
| JSON          | Prettier  | `.prettierrc.json` | 2 spaces, no trailing commas        |
| JavaScript/TS | Prettier  | `.prettierrc.json` | 2 spaces, semicolons, single quotes |
| CSS/HTML      | Prettier  | `.prettierrc.json` | 2 spaces, 100 char width            |
| EditorConfig  | All       | `.editorconfig`    | Cross-editor consistency            |

## Installation

### Prerequisites

- Node.js 18+ (already required for GitHub Actions scripts)
- npm (comes with Node.js)

### Install Dependencies

```bash
npm install
```

This installs:

- `prettier` - Main code formatter
- `prettier-plugin-sh` - Shell script formatting support

## Usage

### Format All Files

```bash
npm run format
```

This formats all files in the repository according to house style rules.

### Check Formatting (No Changes)

```bash
npm run format:check
```

This checks if files are formatted correctly without modifying them. Useful for CI/CD pipelines.

### Format Staged Files Only

```bash
npm run format:staged
```

Formats only files currently staged for commit (useful for pre-commit workflows).

### Manual Formatting

Format specific files or directories:

```bash
npx prettier --write path/to/file.yml
npx prettier --write .github/workflows/*.yml
npx prettier --write "**/*.md"
```

## Pre-Commit Hook Integration

This repository includes a **pre-commit formatting hook** that automatically formats staged files before each commit.

### How It Works

1. You stage files: `git add file.yml`
2. You attempt commit: `git commit -m "message"`
3. Hook runs Prettier on staged files automatically
4. If formatting changes are needed:
   - Hook shows diff of changes
   - **Automatically applies formatting** (in automated environments)
   - Stages the formatted files
   - Commit proceeds with formatted code

### Hook Location

- **Hook script:** `.claude/hooks/pre_commit_format.mjs`
- **Hook config:** `.claude/hooks.json` (user-specific, gitignored)

### Disable Hook Temporarily

If you need to bypass the formatting hook for a single commit:

```bash
git commit --no-verify -m "message"
```

**Note:** Only use `--no-verify` when absolutely necessary. Unformatted code may break workflows!

## House Style Rules

### YAML Files (`.yml`, `.yaml`)

```yaml
# Indentation: 2 spaces (GitHub Actions standard)
name: My Workflow
on:
  push:
    branches:
      - main
# Line width: 100 characters (prevents line wrapping issues)
# Quote style: Double quotes (YAML standard)
# Trailing commas: None (YAML doesn't support)
# Array style: Dash style for multiline
```

### Markdown Files (`.md`)

```markdown
# Line width: 100 characters (readability)

# Emphasis: Asterisks for italic/bold

This is _italic_ and **bold** text.

# List indentation: 2 spaces

- Item 1
  - Sub-item A
  - Sub-item B

# Code fences: Triple backticks with language

\`\`\`yaml
key: value
\`\`\`

# Heading style: ATX style (# Heading)
```

### JSON Files (`.json`)

```json
{
  "indentation": 2,
  "trailingCommas": "never",
  "quoteStyle": "double",
  "lineWidth": 100
}
```

### JavaScript/TypeScript (`.js`, `.mjs`, `.ts`)

```javascript
// Indentation: 2 spaces
// Semicolons: Always
// Quote style: Single quotes (except JSX)
// Trailing commas: ES5 (objects/arrays)
// Arrow function parentheses: Always

const myFunction = (param) => {
  return param + 1;
};
```

## Configuration Files

### `.prettierrc.json`

Primary Prettier configuration. Defines formatting rules for all languages.

**Key settings:**

- `printWidth: 100` - Maximum line length
- `tabWidth: 2` - Indentation size
- `useTabs: false` - Use spaces, not tabs
- `semi: true` - Semicolons in JavaScript
- `singleQuote: true` - Single quotes in JavaScript
- `trailingComma: 'es5'` - Trailing commas in JS objects/arrays

### `.prettierignore`

Files and directories to exclude from formatting:

- `node_modules/` - Dependencies
- `package-lock.json` - Lock files (don't format)
- `.ai_logs/` - AI logs directory
- `dist/`, `build/`, `coverage/` - Build outputs

### `.editorconfig`

Cross-editor configuration for consistent coding styles. Works with VS Code, IntelliJ, Vim, etc.

**Key settings:**

- `charset = utf-8` - UTF-8 encoding
- `end_of_line = lf` - Unix-style line endings
- `insert_final_newline = true` - Newline at end of file
- `trim_trailing_whitespace = true` - Remove trailing spaces
- `indent_style = space` - Use spaces (not tabs)
- `indent_size = 2` - 2 spaces per indent level

## Troubleshooting

### Prettier Not Found

```bash
npm install
```

Make sure dependencies are installed.

### Formatting Errors in CI

If GitHub Actions fails with formatting errors:

1. Run locally: `npm run format:check`
2. Fix issues: `npm run format`
3. Commit formatted files: `git add . && git commit -m "fix: apply formatting"`

### Pre-Commit Hook Not Running

1. Check hook exists: `ls -la .claude/hooks/pre_commit_format.mjs`
2. Check hook is executable: `chmod +x .claude/hooks/pre_commit_format.mjs`
3. Check Claude Code hooks config: `.claude/hooks.json`

### Conflicting Formatting Rules

If your editor has different formatting rules:

1. Install EditorConfig plugin for your editor
2. Disable conflicting formatters (e.g., Beautify, ESLint auto-fix)
3. Use Prettier extension for your editor
4. Configure editor to format on save with Prettier

## GitHub Actions Integration

**Status:** ✅ **Implemented**

Reusable workflows available for formatting automation:

- ✅ **format-check.yml** - Validate formatting without modifying files
- ✅ **format-apply.yml** - Apply formatting and optionally commit changes
- ✅ Integrated with workflow validation pipelines
- ✅ Support for auto-commit and pull request checks

See [GitHub Actions Integration Guide](./INTEGRATION.md) for detailed usage and patterns.

## Related Documentation

- [House Style Rationale](./HOUSE_STYLE.md) - Why these rules?
- [GitHub Actions Integration](./INTEGRATION.md) - CI/CD setup and integration patterns
- [Troubleshooting Guide](./TROUBLESHOOTING.md) - Common issues and solutions
- [Rollout Plan](./ROLLOUT_PLAN.md) - Phased adoption strategy

## Version

- **Prettier:** 3.6.2+
- **Configuration Version:** 1.0.0
- **Last Updated:** 2025-11-10

## Resources

- [Prettier Documentation](https://prettier.io/docs/en/)
- [EditorConfig Documentation](https://editorconfig.org/)
- [Prettier Playground](https://prettier.io/playground/) - Test formatting rules
