# Code Formatter Rollout Plan

**Version:** 1.0.0
**Created:** 2025-11-10
**Status:** Phase 1 (Local Development Only)

---

## Executive Summary

This document outlines the 5-phase rollout plan for code formatting infrastructure in the Jackson-Devices GitHub Template repository. The formatter uses **Prettier** to enforce consistent code style and prevent formatting errors (especially in YAML/Markdown) that can break GitHub Actions workflows.

**Current Status:** Phase 1 complete - formatter tools installed and working locally.

**Goal:** Gradually introduce automated formatting across development workflow, from optional local use to mandatory enforcement at commit time.

---

## Rollout Philosophy

### Gradual Adoption

The rollout follows a **progressive enforcement model**:

1. **Phase 1-2:** Developers become familiar with formatter (no enforcement)
2. **Phase 3-4:** GitHub Actions provide automated checks and fixes (CI/CD layer)
3. **Phase 5:** Mandatory local enforcement prevents unformatted code from entering repo

### Why Gradual?

- **Reduces friction:** Developers adapt to new workflow incrementally
- **Builds confidence:** Each phase validates formatter behavior before tightening enforcement
- **Enables rollback:** Easy to revert to previous phase if issues arise
- **Collects feedback:** Time to identify edge cases and refine rules

---

## Phase Overview

| Phase | Status      | Enforcement Level | Timeline | Key Milestone                           |
| ----- | ----------- | ----------------- | -------- | --------------------------------------- |
| 1     | ✅ Complete | None              | Complete | Local tools installed, docs written     |
| 2     | ⏳ Pending  | Opt-in            | Week 1   | Pre-commit hook available (optional)    |
| 3     | ⏳ Pending  | Advisory          | Week 2   | GitHub Actions check (report only)      |
| 4     | ⏳ Pending  | Auto-fix          | Week 3   | GitHub Actions auto-format on push      |
| 5     | ⏳ Pending  | Mandatory         | Week 4+  | Pre-commit hook mandatory (blocks push) |

---

## Phase 1: Local Development Only ✅

**Status:** COMPLETE (2025-11-09)

### Description

Formatter tools installed and documented. Developers can manually run formatting commands, but nothing is automated or enforced.

### What Was Delivered

#### Tools Installed

- ✅ Prettier (v3.6.2+) with prettier-plugin-sh
- ✅ Configuration files (.prettierrc.json, .prettierignore, .editorconfig)
- ✅ npm scripts (`format`, `format:check`, `format:staged`)

#### Documentation

- ✅ `docs/formatters/README.md` - Usage guide
- ✅ `docs/formatters/HOUSE_STYLE.md` - Style rationale
- ✅ `docs/formatters/ROLLOUT_PLAN.md` (this document)

#### Testing Infrastructure

- ✅ Formatter testing suite (`npm run test:formatters`)
- ✅ Sample broken files with expected outputs
- ✅ Test script validates formatter behavior

#### GitHub Actions (Reusable Workflows)

- ✅ `.github/workflows/format-check.yml` - Check formatting
- ✅ `.github/workflows/format-apply.yml` - Apply formatting

### How to Use (Phase 1)

```bash
# Check formatting (no changes)
npm run format:check

# Format all files
npm run format

# Format only staged files
npm run format:staged

# Test formatters
npm run test:formatters
```

### Success Criteria

- [x] Prettier installed and configured
- [x] Documentation complete and accessible
- [x] Manual formatting commands work correctly
- [x] Test suite passes (100% success rate)
- [x] Reusable GitHub Actions workflows created

### Rollback

N/A - No enforcement to roll back.

---

## Phase 2: Optional Pre-Commit Hook

**Status:** PENDING
**Target:** Week 1 after Phase 1 completion
**Enforcement:** Opt-in (voluntary)

### Description

Pre-commit hook available for developers who want automatic formatting before commits. Hook is **optional** - developers must manually enable it.

### Implementation Tasks

#### 1. Update Hook Configuration

**File:** `.claude/hooks.json.formatter.example`

Ensure pre-commit hook configuration is documented and ready for opt-in:

```json
{
  "pre_commit_format": {
    "enabled": true,
    "script": ".claude/hooks/pre_commit_format.mjs",
    "description": "Auto-format staged files before commit"
  }
}
```

#### 2. Document Opt-In Process

**File:** `docs/formatters/README.md` (add section)

````markdown
## Enabling Pre-Commit Hook (Optional)

To automatically format files before each commit:

1. Copy hook configuration:
   ```bash
   cp .claude/hooks.json.formatter.example .claude/hooks.json
   ```
````

2. Commit as usual - hook runs automatically:

   ```bash
   git add file.yml
   git commit -m "message"
   # Hook runs, formats file, includes in commit
   ```

3. To disable temporarily:
   ```bash
   git commit --no-verify -m "message"
   ```

````

#### 3. Communication

**Action:** Announce to team (Slack/email/issue):

> **Formatter Phase 2: Optional Pre-Commit Hook Available**
>
> The code formatter pre-commit hook is now available for opt-in use. This hook automatically formats your staged files before each commit.
>
> **To enable:** See `docs/formatters/README.md` for instructions.
>
> **Feedback welcome:** If you encounter issues, please report them in issue #[TBD].
>
> This is **optional** - no requirement to enable yet. We'll collect feedback over the next week.

### Success Criteria

- [ ] Hook configuration documented and tested
- [ ] At least 2-3 team members opt-in and test
- [ ] No major issues reported during 1-week trial
- [ ] Feedback collected and addressed
- [ ] Hook works correctly with formatter test suite

### Metrics to Track

- Number of developers who opted in
- Number of commits formatted by hook
- Issues/bugs reported
- Developer satisfaction feedback

### Rollback Procedure

If major issues arise:

1. **Announce rollback** (Slack/email)
2. **Instruct opt-in users to disable:**
   ```bash
   # Remove hook config
   rm .claude/hooks.json
   # Or disable in config
   # "enabled": false
````

3. **Document issues** in GitHub issue for future resolution
4. **Fix and retry** after addressing root cause

**Rollback Impact:** LOW - only affects developers who opted in.

---

## Phase 3: GitHub Actions Format Check (Report Only)

**Status:** PENDING
**Target:** Week 2 (after Phase 2 success)
**Enforcement:** Advisory (report issues, don't block)

### Description

GitHub Actions automatically check formatting on all PRs and push to main. **Violations are reported but don't block merges.** This phase collects data on formatting issues in the wild.

### Implementation Tasks

#### 1. Create Format Check Workflow

**File:** `.github/workflows/format-check-pr.yml` (new)

```yaml
name: Format Check (PR)

on:
  pull_request:
    types: [opened, synchronize, reopened]
  push:
    branches:
      - main

jobs:
  format-check:
    name: Check Code Formatting
    uses: ./.github/workflows/format-check.yml
    with:
      files: '.'
      fail_on_error: false # Phase 3: Report only, don't block

  report:
    name: Post Format Check Results
    runs-on: ubuntu-latest
    needs: format-check
    if: needs.format-check.outputs.has_issues == 'true'

    steps:
      - name: Comment on PR
        if: github.event_name == 'pull_request'
        uses: actions/github-script@v7
        with:
          script: |
            github.rest.issues.createComment({
              issue_number: context.issue.number,
              owner: context.repo.owner,
              repo: context.repo.repo,
              body: `## ⚠️ Formatting Issues Detected

            This PR has **${{ needs.format-check.outputs.formatted_count }}** file(s) that need formatting.

            **To fix locally:**
            \`\`\`bash
            npm run format
            git add -A
            git commit -m "style: apply code formatting"
            git push
            \`\`\`

            **Note:** This is a **warning only** (Phase 3 rollout). Formatting will be enforced in future phases.

            See [Formatter Documentation](../blob/main/docs/formatters/README.md) for details.
            `
            });
```

#### 2. Communication

**Action:** Announce Phase 3 start:

> **Formatter Phase 3: PR Format Checks Active**
>
> GitHub Actions now check code formatting on all PRs. If formatting issues are found:
>
> - ⚠️ Warning comment posted on PR
> - ✅ PR can still be merged (not blocked)
>
> **Action required:** Run `npm run format` before pushing to avoid warnings.
>
> **Timeline:** Phase 3 runs for 1 week to collect data. Phase 4 (auto-fix) starts [DATE].

#### 3. Monitor and Analyze

Track metrics during Phase 3:

- **PRs with formatting issues:** X out of Y PRs (Z%)
- **Most common violations:** YAML indentation, markdown line length, etc.
- **Time to fix:** How long does it take developers to format after warning?
- **False positives:** Any incorrectly flagged files?

### Success Criteria

- [ ] Format check workflow runs on all PRs
- [ ] Warnings posted correctly when issues found
- [ ] No false positives (or very few, documented)
- [ ] Developers respond to warnings and format code
- [ ] Format check doesn't significantly slow CI (<1 min added)
- [ ] Test suite continues to pass (`npm run test:formatters`)

### Metrics to Track

| Metric                     | Target    | Actual |
| -------------------------- | --------- | ------ |
| PRs with format issues     | < 30%     | \_\_   |
| Avg time to fix after warn | < 10 min  | \_\_   |
| False positive rate        | < 5%      | \_\_   |
| Developer complaints       | 0-2 minor | \_\_   |
| CI time overhead           | < 1 min   | \_\_   |

### Rollback Procedure

If Phase 3 causes issues:

1. **Disable workflow:**

   ```yaml
   # Add to .github/workflows/format-check-pr.yml
   on:
     workflow_dispatch: # Manual only, remove automatic triggers
   ```

2. **Announce rollback:**

   > Phase 3 format checks temporarily disabled due to [REASON]. Investigating issue.

3. **Fix and redeploy** after addressing root cause.

**Rollback Impact:** LOW - only affects CI warnings, no merge blocking.

---

## Phase 4: GitHub Actions Auto-Fix

**Status:** PENDING
**Target:** Week 3 (after Phase 3 success)
**Enforcement:** Automatic correction (CI auto-formats and commits)

### Description

GitHub Actions **automatically format and commit fixes** when formatting issues are detected. Developers don't need to manually fix - CI does it for them.

### Implementation Tasks

#### 1. Update Format Check Workflow

**File:** `.github/workflows/format-check-pr.yml` (modify)

Change from "report only" to "auto-fix":

```yaml
jobs:
  format-check:
    name: Check Code Formatting
    uses: ./.github/workflows/format-check.yml
    with:
      files: '.'
      fail_on_error: false # Still don't block, but auto-fix instead

  auto-fix:
    name: Auto-Format Code
    runs-on: ubuntu-latest
    needs: format-check
    if: needs.format-check.outputs.has_issues == 'true'
    permissions:
      contents: write # Need write permission to push

    steps:
      - name: Checkout PR branch
        uses: actions/checkout@v4
        with:
          ref: ${{ github.head_ref }} # PR branch
          token: ${{ secrets.GITHUB_TOKEN }}

      - name: Apply formatting
        uses: ./.github/workflows/format-apply.yml
        with:
          files: '.'
          auto_commit: true
          commit_message: 'style: auto-apply code formatting [skip ci]'
          committer_name: 'github-actions[bot]'
          committer_email: 'github-actions[bot]@users.noreply.github.com'

      - name: Comment on PR
        if: success()
        uses: actions/github-script@v7
        with:
          script: |
            github.rest.issues.createComment({
              issue_number: context.issue.number,
              owner: context.repo.owner,
              repo: context.repo.repo,
              body: `## ✅ Formatting Auto-Applied

            Code formatting has been automatically applied to this PR.

            **Changes committed:** \`${{ needs.auto-fix.outputs.commit_sha }}\`

            Please \`git pull\` before making additional commits.
            `
            });
```

#### 2. Handle Edge Cases

**Important considerations:**

- **Avoid infinite loops:** Use `[skip ci]` in commit message to prevent re-triggering
- **Concurrent commits:** What if developer pushes while CI is formatting?
  - Solution: Use git rebase or merge strategy
- **Protected branches:** Ensure `github-actions[bot]` has push permission

#### 3. Communication

**Action:** Announce Phase 4 start:

> **Formatter Phase 4: Auto-Fix Active**
>
> GitHub Actions now **automatically format your code** when formatting issues are detected.
>
> **What this means:**
>
> - Push unformatted code → CI formats it automatically
> - Auto-formatted commit appears in your PR
> - Run `git pull` before your next commit
>
> **Why this is great:**
>
> - No more manual formatting chores
> - Consistent code style without effort
>
> **Timeline:** Phase 4 runs for 1 week. Phase 5 (mandatory local hook) starts [DATE].

#### 4. Monitor Auto-Fix Behavior

Track metrics during Phase 4:

- **Auto-fixes applied:** X commits out of Y PRs
- **Conflicts after auto-fix:** Any git conflicts caused by formatting commits?
- **Developer confusion:** Any reports of unexpected auto-formatted commits?

### Success Criteria

- [ ] Auto-fix workflow applies formatting correctly
- [ ] No infinite CI loops
- [ ] No git conflicts caused by auto-formatting
- [ ] Developers adapt to "pull after push" workflow
- [ ] Auto-fix doesn't break any PRs
- [ ] Test suite continues to pass

### Metrics to Track

| Metric                      | Target    | Actual |
| --------------------------- | --------- | ------ |
| Auto-fixes applied          | Track     | \_\_   |
| Git conflicts from auto-fix | 0         | \_\_   |
| CI infinite loops           | 0         | \_\_   |
| Developer complaints        | 0-2 minor | \_\_   |

### Rollback Procedure

If Phase 4 causes issues:

1. **Disable auto-fix** (revert to Phase 3 - report only):

   ```yaml
   # Remove auto-fix job from format-check-pr.yml
   # Keep format-check job with fail_on_error: false
   ```

2. **Announce rollback:**

   > Phase 4 auto-fix temporarily disabled due to [REASON]. Reverted to Phase 3 (warnings only).

3. **Fix and redeploy** after addressing root cause.

**Rollback Impact:** MEDIUM - developers may have auto-formatted commits in their PRs, but no major disruption.

---

## Phase 5: Mandatory Pre-Commit Hook

**Status:** PENDING
**Target:** Week 4+ (after Phase 4 success)
**Enforcement:** Mandatory (blocks commits with unformatted code)

### Description

Pre-commit hook becomes **mandatory** for all developers. Unformatted code cannot be committed locally. This is the final phase - full enforcement.

### Implementation Tasks

#### 1. Update Repository Configuration

**File:** `.claude/hooks.json` (committed to repo)

Previously, `.claude/hooks.json` was gitignored (user-specific). In Phase 5, we commit a **default hooks config** to enforce formatting:

```json
{
  "hooks": {
    "pre_commit_format": {
      "enabled": true,
      "script": ".claude/hooks/pre_commit_format.mjs",
      "description": "Auto-format staged files before commit (MANDATORY)"
    }
  }
}
```

**Alternative approach:** Use `package.json` scripts with git hooks (e.g., `husky`, `lint-staged`).

#### 2. Add Bypass Instructions

**File:** `docs/formatters/README.md` (update)

````markdown
## Pre-Commit Hook (Mandatory)

As of [DATE], the pre-commit formatting hook is **mandatory** for all commits.

### How It Works

1. You stage files: `git add file.yml`
2. You attempt commit: `git commit -m "message"`
3. **Hook runs automatically** - formats staged files
4. Commit proceeds with formatted code

### Emergency Bypass

**Only use in exceptional circumstances:**

```bash
git commit --no-verify -m "emergency: bypass formatting"
```
````

**Warning:** Unformatted code may fail CI checks. Only bypass if:

- Formatting breaks your code (report bug immediately)
- Emergency hotfix required (format in follow-up commit)

````

#### 3. Communication

**Action:** Announce Phase 5 (final phase):

> **Formatter Phase 5: Mandatory Enforcement Starting [DATE]**
>
> As of [DATE], the pre-commit formatting hook is **mandatory** for all developers.
>
> **What changes:**
> - All commits automatically formatted before committing
> - `--no-verify` required to bypass (discouraged)
>
> **Why mandatory?**
> - Phases 2-4 demonstrated formatter stability
> - Formatting errors no longer escape to CI
> - Consistent code style guaranteed
>
> **Need help?** See `docs/formatters/README.md` or ask in [CHANNEL].
>
> Thank you for your patience during the rollout!

#### 4. Enforcement Period

**First 2 weeks:**

- Monitor for issues (bypasses, complaints, bugs)
- Provide quick support for any problems
- Collect feedback on edge cases

**After 2 weeks:**

- Review rollout success
- Document lessons learned
- Update formatter rules if needed

### Success Criteria

- [ ] Pre-commit hook enabled for all developers
- [ ] No unformatted code reaches GitHub
- [ ] Minimal use of `--no-verify` bypass
- [ ] No major complaints or workflow disruptions
- [ ] Test suite continues to pass
- [ ] CI format checks pass 100% of time (redundant but validates)

### Metrics to Track

| Metric                        | Target         | Actual |
| ----------------------------- | -------------- | ------ |
| Commits bypassing hook        | < 5%           | \_\_   |
| PRs failing CI format check   | 0% (all pass)  | \_\_   |
| Developer complaints          | 0-1 minor      | \_\_   |
| Formatting bugs reported      | 0              | \_\_   |

### Rollback Procedure

If Phase 5 causes major issues:

1. **Revert to Phase 4** (auto-fix in CI):
   ```bash
   # Remove mandatory hook config
   git rm .claude/hooks.json  # If committed
   # Or update to:
   # "enabled": false
````

2. **Announce rollback:**

   > Phase 5 mandatory enforcement temporarily disabled due to [REASON]. Reverted to Phase 4 (CI auto-fix).

3. **Fix and redeploy** after addressing root cause.

**Rollback Impact:** MEDIUM-HIGH - affects all developers, but Phase 4 (CI auto-fix) still enforces formatting.

---

## General Rollback Procedures

### Quick Rollback (Emergency)

If a **critical issue** arises (formatter breaks code, CI loops, etc.):

1. **Disable immediately:**

   ```bash
   # Disable GitHub Actions workflow
   git mv .github/workflows/format-check-pr.yml .github/workflows/format-check-pr.yml.disabled
   git commit -m "fix: disable formatter workflow (emergency)"
   git push
   ```

2. **Announce to team:**

   > **ALERT:** Formatter temporarily disabled due to [CRITICAL ISSUE]. Investigating.

3. **Investigate and fix:**
   - Reproduce issue locally
   - Check test suite: `npm run test:formatters`
   - Review recent formatter config changes
   - Fix bug and test thoroughly

4. **Re-enable and monitor:**
   ```bash
   git mv .github/workflows/format-check-pr.yml.disabled .github/workflows/format-check-pr.yml
   git commit -m "fix: re-enable formatter after [ISSUE] fix"
   git push
   ```

### Permanent Rollback (Phase Failure)

If a phase **fails success criteria** and cannot be fixed quickly:

1. **Revert to previous phase** (see phase-specific rollback procedures)
2. **Document failure:**
   - What went wrong?
   - Why did it happen?
   - What needs to change before retrying?
3. **Communicate plan:**
   - Timeline for fix
   - New target date for phase retry
4. **Fix underlying issue** before proceeding

### Rollback Decision Matrix

| Severity | Impact | Action             | Approval Needed |
| -------- | ------ | ------------------ | --------------- |
| Critical | High   | Emergency rollback | None (urgent)   |
| Major    | Medium | Phase rollback     | Team lead       |
| Minor    | Low    | Bug fix, no rollb. | None            |

---

## Success Metrics Summary

### Phase-Level Metrics

| Phase | Key Metric             | Target         |
| ----- | ---------------------- | -------------- |
| 1     | Test suite pass rate   | 100%           |
| 2     | Opt-in users           | 2-3 developers |
| 3     | PRs with format issues | < 30%          |
| 4     | Auto-fix conflicts     | 0              |
| 5     | Commits bypassing hook | < 5%           |

### Overall Rollout Success

**Criteria for declaring rollout complete:**

- [ ] Phase 5 running for 2+ weeks without major issues
- [ ] Zero unformatted commits reaching main branch
- [ ] Developer satisfaction: No major complaints
- [ ] Test suite passing consistently (100%)
- [ ] CI format checks redundant (pass 100% due to pre-commit hook)
- [ ] Documentation complete and accurate

---

## Communication Plan

### Announcement Channels

- **Primary:** GitHub issue #[TBD] - "Formatter Rollout Tracker"
- **Secondary:** Slack #dev-announcements (if available)
- **Documentation:** Update `docs/formatters/README.md` at each phase

### Communication Schedule

| Event            | Timing         | Audience   | Message                     |
| ---------------- | -------------- | ---------- | --------------------------- |
| Phase 1 complete | 2025-11-10     | Team       | Tools available, docs ready |
| Phase 2 start    | Week 1 (Day 1) | Developers | Opt-in hook available       |
| Phase 2 summary  | Week 1 (Day 7) | Team       | Feedback summary, metrics   |
| Phase 3 start    | Week 2 (Day 1) | Developers | CI checks active            |
| Phase 3 summary  | Week 2 (Day 7) | Team       | Issue rate, trends          |
| Phase 4 start    | Week 3 (Day 1) | Developers | Auto-fix enabled            |
| Phase 4 summary  | Week 3 (Day 7) | Team       | Auto-fix success rate       |
| Phase 5 start    | Week 4 (Day 1) | Developers | Mandatory enforcement       |
| Rollout complete | Week 6 (Day 1) | Team       | Final summary, lessons      |

---

## Timeline Visualization

```
Week 1         Week 2         Week 3         Week 4         Week 5+
├──────────────┼──────────────┼──────────────┼──────────────┼──────────>
│              │              │              │              │
Phase 1 ✅     Phase 2        Phase 3        Phase 4        Phase 5
(complete)     Opt-in hook    CI checks      CI auto-fix    Mandatory
               │              (report only)  │              │
               │              │              │              │
               └─ Feedback ───┴─ Metrics ────┴─ Monitor ────┴─ Enforce
```

---

## Edge Cases and Known Issues

### Edge Case 1: Merge Conflicts with Formatted Code

**Scenario:** Developer has unformatted code locally, pulls formatted code from remote, encounters conflicts.

**Solution:**

1. Format local code first: `npm run format`
2. Commit: `git add -A && git commit -m "style: format before merge"`
3. Pull: `git pull origin main`
4. Resolve any remaining conflicts (should be minimal)

### Edge Case 2: Large Diffs from Initial Formatting

**Scenario:** First time formatting entire repo creates massive diff (100+ files changed).

**Solution:**

- Format repo in **one dedicated commit** before starting rollout:
  ```bash
  npm run format
  git add -A
  git commit -m "style: initial codebase formatting"
  git push
  ```
- Announce to team: "Big formatting commit coming, pull latest main."

### Edge Case 3: Files That Should Not Be Formatted

**Scenario:** Generated files, vendored code, or special formats need to skip formatting.

**Solution:**

- Add to `.prettierignore`:

  ```
  # Generated files
  dist/
  build/
  coverage/

  # Vendored code
  vendor/
  third-party/

  # Special formats
  some-special-file.md
  ```

### Edge Case 4: Formatter Breaks Valid Code

**Scenario:** Prettier incorrectly formats valid syntax, breaking functionality.

**Solution:**

1. Use `<!-- prettier-ignore -->` or `// prettier-ignore`:

   ```yaml
   # prettier-ignore
   special_syntax: |
     This block won't be reformatted
   ```

2. Report bug to formatter team (Prettier or plugin)
3. Update house style rules if needed

---

## Lessons Learned (Post-Rollout)

_This section will be updated after rollout completes._

### What Went Well

- TBD

### What Could Be Improved

- TBD

### Recommendations for Future Rollouts

- TBD

---

## References

### Related Documentation

- [Formatter README](./README.md) - Installation and usage
- [House Style Rationale](./HOUSE_STYLE.md) - Why these rules?
- [GitHub Actions Workflows](../../.github/workflows/README.md) - CI/CD integration

### External Resources

- [Prettier Documentation](https://prettier.io/docs/en/)
- [Prettier Ignore Syntax](https://prettier.io/docs/en/ignore.html)
- [Git Hooks Documentation](https://git-scm.com/docs/githooks)

---

## Document History

| Version | Date       | Changes                            | Author      |
| ------- | ---------- | ---------------------------------- | ----------- |
| 1.0.0   | 2025-11-10 | Initial rollout plan with 5 phases | AI (Claude) |

---

**Questions or feedback?** Open an issue or contact the infrastructure team.
