# House Style Rationale

## Purpose

This document explains **why** we chose specific formatting rules for each language. Understanding the rationale helps contributors make informed decisions and exceptions when needed.

## General Principles

### Consistency Over Preference

Individual preferences vary, but **consistency across the codebase** is more valuable than any single style choice. The formatter enforces consistency automatically.

### Readability First

All formatting rules prioritize **human readability** over:

- Minimizing file size (we're not optimizing for bandwidth)
- Maximizing information density (we're not golfing)
- Following trends (we prioritize stability over fashion)

### Error Prevention

Many rules are designed to **prevent common errors**, especially in YAML and Markdown where subtle formatting issues break GitHub Actions workflows.

## Language-Specific Rationale

### YAML (`.yml`, `.yaml`)

#### Indentation: 2 Spaces

**Why:** GitHub Actions standard. Most YAML examples in documentation use 2 spaces.

**Benefit:** Consistency with ecosystem examples makes copying/adapting code easier.

**Tradeoff:** Less visual hierarchy than 4 spaces, but YAML nesting rarely goes deep enough to matter.

#### Line Width: 100 Characters

**Why:** Balances readability with screen real estate.

- ✅ Readable on laptop screens without horizontal scrolling
- ✅ Fits in side-by-side diff views
- ✅ Allows meaningful variable names without forced line breaks

**Alternatives considered:**

- 80 chars: Too restrictive for modern screens, forces awkward breaks
- 120 chars: Too wide for side-by-side diffs in GitHub UI

#### Quote Style: Double Quotes (YAML default)

**Why:** YAML parsers handle double quotes more consistently than single quotes.

**Benefit:** Prevents escaping issues with special characters and interpolation.

**Example:**

```yaml
# Good - Prettier enforces this
description: 'This is a test'

# Also valid - double quotes when needed
description: "Value with 'quotes' inside"
```

#### Array Style: Dash Style for Multiline

**Why:** Clearer visual structure for nested arrays.

**Example:**

```yaml
# Good - Prettier enforces this
steps:
  - name: Checkout
    uses: actions/checkout@v3
  - name: Run tests
    run: npm test

# Bad - Bracket style harder to read when multiline
steps: [{ name: 'Checkout', uses: 'actions/checkout@v3' }, { name: 'Run tests', run: 'npm test' }]
```

---

### Markdown (`.md`)

#### Line Width: 100 Characters

**Why:** Same rationale as YAML. Balances readability with screen space.

**Benefit:** Prevents awkward mid-sentence line breaks that hurt readability.

**Note:** `proseWrap: "preserve"` means Prettier won't reflow existing paragraphs, only enforces width for new content.

#### Emphasis: Asterisks (`*` for italic, `**` for bold)

**Why:** More common in Markdown ecosystem than underscores.

**Benefit:** Consistency with most Markdown guides and editors.

**Example:**

```markdown
This is _italic_ and **bold** text.
```

#### List Indentation: 2 Spaces

**Why:** Matches YAML indentation for consistency across file types.

**Benefit:** Easier to copy lists between Markdown docs and YAML configs.

#### Code Fence: Triple Backticks with Language Tag

**Why:** Enables syntax highlighting in GitHub and most Markdown renderers.

**Example:**

````markdown
```yaml
key: value
```
````

**Benefit:** Improves readability and catches syntax errors in code examples.

#### Heading Style: ATX (`# Heading`)

**Why:** More widely supported than Setext style (underlined headings).

**Benefit:** Clearer hierarchy, works in all Markdown flavors.

---

### JSON (`.json`)

#### Indentation: 2 Spaces

**Why:** Consistency with YAML and JavaScript.

#### Line Width: 100 Characters

**Why:** Same rationale as YAML/Markdown.

#### Trailing Commas: Never

**Why:** JSON spec forbids trailing commas. Removing them prevents parse errors.

**Example:**

```json
{
  "key1": "value1",
  "key2": "value2"
}
```

**Not:**

```json
{
  "key1": "value1",
  "key2": "value2" // ❌ Parse error in strict JSON
}
```

---

### JavaScript/TypeScript (`.js`, `.mjs`, `.ts`)

#### Indentation: 2 Spaces

**Why:** Consistency with YAML/JSON/Markdown.

**Benefit:** Switching between file types doesn't require mental context switch.

#### Semicolons: Always

**Why:** Prevents ASI (Automatic Semicolon Insertion) bugs.

**Benefit:** Explicit is better than implicit. Makes code intent clear.

**Example:**

```javascript
// Good - Prettier enforces this
const x = 5;
console.log(x);

// Bad - ASI can cause bugs
const x = 5;
console.log(x)[(1, 2, 3)].forEach(console.log); // Bug: tries to index console.log
```

#### Quote Style: Single Quotes

**Why:** Less visual noise than double quotes. Easier to type.

**Benefit:** Consistency across JavaScript ecosystem (most popular style).

**Exception:** Double quotes in JSON, template literals when needed.

#### Trailing Commas: ES5 (objects/arrays)

**Why:** Makes diffs cleaner when adding new items.

**Example:**

```javascript
const obj = {
  key1: 'value1',
  key2: 'value2', // ✅ Trailing comma - adding key3 only changes 1 line in diff
};
```

**Without trailing comma:**

```diff
  const obj = {
    key1: "value1",
-   key2: "value2"
+   key2: "value2",  // 2 lines changed in diff
+   key3: "value3"
  };
```

#### Arrow Function Parentheses: Always

**Why:** Consistency - adding a second parameter doesn't change line formatting.

**Example:**

```javascript
// Good - Prettier enforces this
const double = (x) => x * 2;

// Adding a parameter doesn't change formatting
const add = (x, y) => x + y;
```

---

## EditorConfig Rules

### UTF-8 Encoding

**Why:** Unicode support for international characters, emojis, special symbols.

**Benefit:** Prevents encoding issues when files are edited on different systems.

### LF Line Endings (Unix-style)

**Why:** GitHub uses LF. Windows contributors can use `.gitattributes` to auto-convert.

**Benefit:** Prevents noisy diffs caused by CRLF vs LF differences.

### Insert Final Newline

**Why:** POSIX standard. Many tools expect files to end with newline.

**Benefit:** Prevents "No newline at end of file" warnings in diffs.

### Trim Trailing Whitespace

**Why:** Trailing whitespace serves no purpose and creates noise in diffs.

**Exception:** Markdown files preserve trailing spaces for hard line breaks (`  \n`).

---

## Why These Rules Prevent Errors

### Problem: Malformed YAML in GitHub Actions

**Example from commit `6369e47`:**

```yaml
# AI-generated code with formatting errors
name: Workflow
on:
  push:
    branches:
      - main # ❌ Wrong indentation breaks workflow
```

**Solution:** Prettier enforces correct indentation automatically.

### Problem: Mixed Quote Styles

**Example:**

```yaml
# Mixed quotes break YAML parsing in edge cases
key1: 'single quotes'
key2: 'double quotes with asterisk: *' # ❌ Unescaped asterisk breaks parser
```

**Solution:** Prettier normalizes quote styles and escapes special characters.

### Problem: Inconsistent Line Endings

**Example:**

```
file1.yml: LF endings
file2.yml: CRLF endings
git diff: shows entire file as changed
```

**Solution:** EditorConfig + Prettier enforce LF endings universally.

---

## Exceptions & Overrides

### When to Override Formatting

1. **Generated Files:** Lock files (`package-lock.json`) should not be formatted
2. **Binary Files:** Images, PDFs, etc. (automatically excluded)
3. **Third-Party Code:** Vendored dependencies with different style
4. **Special Markdown:** Tables, ASCII art, intentional formatting

### How to Override

#### Per-File Override

Add `<!-- prettier-ignore -->` before the section to skip:

```markdown
<!-- prettier-ignore -->
| This | Table | Won't |
|------|-------|-------|
| Be   | Reformatted | ! |
```

#### Per-Directory Override

Add to `.prettierignore`:

```
vendor/
third-party/
```

---

## Tooling Integration

### VS Code

Install [Prettier Extension](https://marketplace.visualstudio.com/items?itemName=esbenp.prettier-vscode)

```json
// .vscode/settings.json
{
  "editor.defaultFormatter": "esbenp.prettier-vscode",
  "editor.formatOnSave": true
}
```

### JetBrains (IntelliJ, WebStorm)

Settings → Languages & Frameworks → Prettier

- ✅ Enable "On save"
- ✅ Enable "On code reformat"

### Vim/Neovim

Install [vim-prettier](https://github.com/prettier/vim-prettier)

```vim
" Auto-format on save
let g:prettier#autoformat = 1
```

---

## Future Enhancements

### Planned Languages

- **Rust:** `rustfmt` when Rust code added
- **Python:** `Black` when Python code added
- **C/C++:** `clang-format` when firmware code added
- **SQL:** SQL formatter when database migrations added

### Planned Integrations

- **GitHub Actions:** Auto-format before workflow execution
- **Pull Request Checks:** Block PRs with unformatted code
- **IDE Integration:** Auto-format in Cloudflare Workers editor

---

## Version History

- **1.0.0 (2025-11-09):** Initial house style rules for YAML, Markdown, JSON, JavaScript

## Related Documentation

- [Formatter README](./README.md) - Setup and usage
- [GitHub Actions Integration](./INTEGRATION.md) - CI/CD setup and integration patterns
- [Troubleshooting Guide](./TROUBLESHOOTING.md) - Common issues and solutions
- [Rollout Plan](./ROLLOUT_PLAN.md) - Phased adoption strategy
