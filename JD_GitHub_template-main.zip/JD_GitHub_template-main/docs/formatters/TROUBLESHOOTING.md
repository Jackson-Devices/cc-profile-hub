# Code Formatter Troubleshooting Guide

## Overview

This guide covers common issues when using Prettier code formatting in this repository, including local development, pre-commit hooks, and GitHub Actions integration.

---

## Table of Contents

1. [Installation Issues](#installation-issues)
2. [Local Formatting Issues](#local-formatting-issues)
3. [Pre-Commit Hook Issues](#pre-commit-hook-issues)
4. [GitHub Actions Issues](#github-actions-issues)
5. [Configuration Issues](#configuration-issues)
6. [Editor Integration Issues](#editor-integration-issues)
7. [Performance Issues](#performance-issues)
8. [Platform-Specific Issues](#platform-specific-issues)

---

## Installation Issues

### Issue: `npm install` fails with "EACCES: permission denied"

**Symptoms:**

```bash
npm ERR! code EACCES
npm ERR! syscall mkdir
npm ERR! path /usr/local/lib/node_modules/prettier
```

**Cause:** Insufficient permissions to install global packages.

**Solution:**

1. **Option A:** Install locally (recommended):

```bash
npm install --save-dev prettier prettier-plugin-sh
```

2. **Option B:** Fix npm permissions:

```bash
mkdir ~/.npm-global
npm config set prefix '~/.npm-global'
export PATH=~/.npm-global/bin:$PATH
```

3. **Option C:** Use sudo (not recommended):

```bash
sudo npm install -g prettier
```

---

### Issue: "prettier: command not found"

**Symptoms:**

```bash
$ npm run format
npm ERR! prettier: command not found
```

**Cause:** Prettier not installed or not in PATH.

**Solution:**

1. Install dependencies:

```bash
npm install
```

2. Verify installation:

```bash
npx prettier --version
```

3. If still failing, check `package.json`:

```json
{
  "devDependencies": {
    "prettier": "^3.6.2",
    "prettier-plugin-sh": "^0.14.0"
  }
}
```

---

### Issue: "Module not found: prettier-plugin-sh"

**Symptoms:**

```bash
[error] Cannot find module 'prettier-plugin-sh'
```

**Cause:** Missing shell script formatting plugin.

**Solution:**

```bash
npm install --save-dev prettier-plugin-sh
```

---

## Local Formatting Issues

### Issue: Format check passes locally but fails in CI

**Symptoms:**

- Local: `npm run format:check` passes
- CI: GitHub Actions format check fails

**Cause:** Inconsistent Prettier versions or configurations.

**Solution:**

1. Check Node.js version:

```bash
# Local
node --version

# CI (check .github/workflows/format-check.yml)
# Should use Node.js 18+
```

2. Use `npm ci` instead of `npm install`:

```bash
# Installs exact versions from package-lock.json
npm ci
```

3. Ensure `.prettierrc.json` is committed:

```bash
git add .prettierrc.json .prettierignore
git commit -m "chore: add Prettier config"
```

4. Clear npm cache:

```bash
npm cache clean --force
rm -rf node_modules package-lock.json
npm install
```

---

### Issue: Prettier formats differently than expected

**Symptoms:**

- Files are reformatted in unexpected ways
- Line breaks appear in wrong places

**Cause:** Conflicting configuration or editor settings.

**Solution:**

1. Check for multiple config files:

```bash
# Only one should exist
ls -la .prettierrc* .editorconfig
```

2. Verify `.prettierrc.json` settings:

```json
{
  "printWidth": 100,
  "tabWidth": 2,
  "useTabs": false,
  "semi": true,
  "singleQuote": true
}
```

3. Disable conflicting editor formatters:

- VS Code: Disable Beautify, ESLint auto-fix
- IntelliJ: Disable built-in JavaScript formatter

---

### Issue: Some files are not formatted

**Symptoms:**

```bash
$ npm run format
# Some files unchanged
```

**Cause:** Files excluded in `.prettierignore`.

**Solution:**

1. Check `.prettierignore`:

```bash
cat .prettierignore
```

2. Common exclusions:

```
node_modules/
package-lock.json
.ai_logs/
dist/
build/
coverage/
*.min.js
```

3. Force format specific file:

```bash
npx prettier --write path/to/file.js --ignore-path /dev/null
```

---

### Issue: YAML formatting breaks GitHub Actions workflow

**Symptoms:**

- Workflow file formatted
- GitHub Actions fails with "Invalid workflow file"

**Cause:** Prettier changed semantically significant whitespace in YAML.

**Solution:**

1. **Check for tab characters** (YAML forbids tabs):

```bash
grep -P '\t' .github/workflows/*.yml
```

2. **Verify indentation** (2 spaces for YAML):

```yaml
# ✅ Correct
name: My Workflow
on:
  push:
    branches:
      - main

# ❌ Wrong (4 spaces)
name: My Workflow
on:
    push:
        branches:
            - main
```

3. **Validate YAML syntax**:

```bash
npm install -g yaml-validator
yaml-validator .github/workflows/*.yml
```

---

## Pre-Commit Hook Issues

### Issue: Pre-commit hook not running

**Symptoms:**

- Commit completes without formatting
- No format output shown

**Cause:** Hook not configured or disabled.

**Solution:**

1. Check hook exists:

```bash
ls -la .claude/hooks/pre_commit_format.mjs
```

2. Check hook is executable:

```bash
chmod +x .claude/hooks/pre_commit_format.mjs
```

3. Check Claude Code hooks config:

```bash
cat .claude/hooks.json
```

Should contain:

```json
{
  "hooks": {
    "pre_commit": ".claude/hooks/pre_commit_format.mjs"
  }
}
```

4. Verify hook is not bypassed:

```bash
# Don't use --no-verify unless necessary
git commit -m "message" # ✅ Runs hooks
git commit --no-verify -m "message" # ❌ Skips hooks
```

---

### Issue: Hook fails with "Permission denied"

**Symptoms:**

```bash
/bin/sh: .claude/hooks/pre_commit_format.mjs: Permission denied
```

**Cause:** Hook script not executable.

**Solution:**

```bash
chmod +x .claude/hooks/pre_commit_format.mjs
git add .claude/hooks/pre_commit_format.mjs
git commit -m "fix: make pre-commit hook executable"
```

---

### Issue: Hook formats files but commit fails

**Symptoms:**

- Hook runs and shows formatting diff
- Commit aborts with error

**Cause:** Hook exits with non-zero status.

**Solution:**

1. Check hook exit code:

```javascript
// .claude/hooks/pre_commit_format.mjs
// Must exit with 0 for success
process.exit(0);
```

2. Review hook logs:

```bash
cat .ai_logs/formatter_log.jsonl
```

3. Run hook manually:

```bash
node .claude/hooks/pre_commit_format.mjs
echo $? # Should be 0
```

---

### Issue: Hook takes too long (>10 seconds)

**Symptoms:**

- Hook runs but is very slow
- Timeout errors

**Cause:** Formatting too many files.

**Solution:**

1. **Use staged files only** (not entire repo):

```bash
# ✅ Good
npm run format:staged

# ❌ Bad
npm run format
```

2. **Exclude large files** in `.prettierignore`:

```
**/*.min.js
**/*.bundle.js
node_modules/
```

3. **Use Prettier cache** (Prettier 3.0+):

```bash
npx prettier --write --cache src/**/*.js
```

---

## GitHub Actions Issues

### Issue: Workflow fails with "prettier: command not found"

**Symptoms:**

```yaml
Run npx prettier --check .
/bin/sh: prettier: command not found
Error: Process completed with exit code 127.
```

**Cause:** Dependencies not installed in workflow.

**Solution:**

Add installation step before formatting:

```yaml
steps:
  - uses: actions/checkout@v4

  - uses: actions/setup-node@v4
    with:
      node-version: '18'

  - name: Install dependencies
    run: npm install # ✅ Add this

  - name: Check formatting
    run: npm run format:check
```

---

### Issue: Auto-commit fails with "nothing to commit"

**Symptoms:**

```yaml
Run git commit -m "style: apply formatting"
On branch main
nothing to commit, working tree clean
Error: Process completed with exit code 1.
```

**Cause:** Files were already formatted (this is expected).

**Solution:**

Use conditional commit:

```yaml
- name: Check for changes
  id: changes
  run: |
    if git diff --quiet; then
      echo "has_changes=false" >> $GITHUB_OUTPUT
    else
      echo "has_changes=true" >> $GITHUB_OUTPUT
    fi

- name: Commit changes
  if: steps.changes.outputs.has_changes == 'true'
  run: |
    git config user.name "github-actions[bot]"
    git config user.email "github-actions[bot]@users.noreply.github.com"
    git add -A
    git commit -m "style: apply formatting"
```

---

### Issue: Format workflow conflicts with other commits

**Symptoms:**

- Format workflow pushes commit
- Subsequent workflow fails with "out of date"

**Cause:** Race condition between workflows.

**Solution:**

1. Use workflow concurrency control:

```yaml
concurrency:
  group: format-${{ github.ref }}
  cancel-in-progress: false # Wait, don't cancel
```

2. Pull before formatting:

```yaml
- name: Pull latest
  run: git pull --rebase origin ${{ github.ref_name }}

- name: Format files
  run: npm run format
```

---

### Issue: Workflow timeout after 5 minutes

**Symptoms:**

```yaml
Error: The operation was canceled.
```

**Cause:** Formatting takes too long or hangs.

**Solution:**

1. Increase timeout:

```yaml
jobs:
  format:
    timeout-minutes: 10 # Increase from 5
```

2. Format fewer files:

```yaml
- name: Format only changed files
  run: |
    CHANGED_FILES=$(git diff --name-only HEAD~1)
    npx prettier --write $CHANGED_FILES
```

3. Add progress output:

```yaml
- name: Format with progress
  run: |
    npx prettier --write --log-level debug .
```

---

## Configuration Issues

### Issue: Conflicting .editorconfig and .prettierrc.json

**Symptoms:**

- Files formatted differently by editor vs CLI
- Indentation inconsistencies

**Cause:** EditorConfig and Prettier have different settings.

**Solution:**

1. Align settings:

**`.editorconfig`:**

```ini
[*]
indent_style = space
indent_size = 2
end_of_line = lf
insert_final_newline = true
```

**`.prettierrc.json`:**

```json
{
  "tabWidth": 2,
  "useTabs": false,
  "endOfLine": "lf"
}
```

2. Prettier overrides EditorConfig:

```json
{
  "editorconfig": true
}
```

---

### Issue: Custom .prettierrc.json not recognized

**Symptoms:**

- Prettier uses default settings
- Custom rules ignored

**Cause:** Config file in wrong location or invalid JSON.

**Solution:**

1. Check file location:

```bash
# Must be in repository root
ls -la .prettierrc.json
```

2. Validate JSON:

```bash
cat .prettierrc.json | jq .
```

3. Use explicit config:

```bash
npx prettier --config .prettierrc.json --write .
```

---

## Editor Integration Issues

### Issue: VS Code formats on save but uses wrong rules

**Symptoms:**

- File formatted on save
- Different from `npm run format`

**Cause:** VS Code using different formatter or settings.

**Solution:**

1. Install Prettier extension:

- Extension ID: `esbenp.prettier-vscode`

2. Configure VS Code (`.vscode/settings.json`):

```json
{
  "editor.defaultFormatter": "esbenp.prettier-vscode",
  "editor.formatOnSave": true,
  "prettier.requireConfig": true
}
```

3. Disable conflicting formatters:

```json
{
  "beautify.enable": false,
  "javascript.format.enable": false
}
```

---

### Issue: IntelliJ/WebStorm formats differently

**Symptoms:**

- IDE reformats code differently than Prettier

**Cause:** IntelliJ using built-in formatter instead of Prettier.

**Solution:**

1. Install Prettier plugin:

- Settings → Plugins → Search "Prettier"

2. Configure Prettier:

- Settings → Languages & Frameworks → JavaScript → Prettier
- ✅ Enable "On save"
- ✅ Enable "On code reformat"
- Set Node interpreter path
- Set Prettier package path

3. Disable conflicting formatters:

- Settings → Editor → Code Style → JavaScript
- Scheme: Default (disable custom schemes)

---

## Performance Issues

### Issue: Formatting takes >30 seconds

**Symptoms:**

- `npm run format` is very slow
- Hook causes long commit delays

**Cause:** Formatting too many files or large files.

**Solution:**

1. **Exclude unnecessary files** in `.prettierignore`:

```
node_modules/
dist/
build/
coverage/
**/*.min.js
**/*.map
```

2. **Use Prettier cache** (v3.0+):

```bash
# Creates .prettierrc.cache
npx prettier --write --cache .
```

3. **Format staged files only**:

```bash
npm run format:staged
```

4. **Parallelize formatting** (large repos):

```bash
# Format file types in parallel
npx prettier --write "**/*.js" &
npx prettier --write "**/*.yml" &
wait
```

---

## Platform-Specific Issues

### Issue: Line endings changed on Windows (CRLF → LF)

**Symptoms:**

- Git shows entire file as changed
- Only line endings different

**Cause:** `.gitattributes` forcing LF endings.

**Solution:**

1. **Expected behavior** (LF is correct):

```bash
# .gitattributes
* text=auto eol=lf
```

2. Configure Git to handle line endings:

```bash
# Windows only
git config --global core.autocrlf true
```

3. Re-normalize repository:

```bash
git add --renormalize .
git commit -m "chore: normalize line endings"
```

---

### Issue: Shell scripts not formatted on Windows

**Symptoms:**

- `.sh` files ignored by Prettier

**Cause:** `prettier-plugin-sh` requires bash/sh parser.

**Solution:**

1. Install WSL (Windows Subsystem for Linux):

```bash
wsl --install
```

2. Format in WSL:

```bash
wsl npx prettier --write scripts/*.sh
```

3. Or use Git Bash:

```bash
# From Git Bash terminal
npx prettier --write scripts/*.sh
```

---

### Issue: Permission errors on macOS/Linux

**Symptoms:**

```bash
EACCES: permission denied, open '/path/to/file'
```

**Cause:** File ownership or permissions issue.

**Solution:**

1. Check file permissions:

```bash
ls -la file.js
```

2. Fix ownership:

```bash
sudo chown $USER:$USER file.js
```

3. Fix permissions:

```bash
chmod 644 file.js
```

---

## Debugging Tips

### Enable Debug Output

```bash
# Verbose logging
npx prettier --write --log-level debug .

# Show files being checked
npx prettier --check --list-different .

# Dry run (show what would change)
npx prettier --check .
```

### Check Prettier Version Mismatch

```bash
# Local version
npx prettier --version

# Global version
prettier --version

# Package.json version
cat package.json | grep prettier
```

### Manually Test Formatting

```bash
# Format single file
npx prettier --write test.js

# Show formatted output (don't write)
npx prettier test.js

# Check if file needs formatting
npx prettier --check test.js
echo $? # 0 = formatted, 1 = needs formatting
```

### Review Hook Logs

```bash
# View formatter operation logs
cat .ai_logs/formatter_log.jsonl | jq .

# Filter by timestamp
cat .ai_logs/formatter_log.jsonl | jq 'select(.timestamp > "2025-11-10")'
```

---

## Common Error Messages

### "Cannot find module 'prettier'"

**Solution:** `npm install`

### "No parser could be inferred for file"

**Solution:** Add file extension to Prettier config or use explicit parser:

```bash
npx prettier --write --parser yaml file.yml
```

### "Require stack: /path/to/prettier"

**Solution:** Corrupted node_modules, run:

```bash
rm -rf node_modules package-lock.json
npm install
```

### "[error] Error: ENOENT: no such file or directory"

**Solution:** File path doesn't exist. Check glob pattern:

```bash
# Wrong
npx prettier --write "src/**/*.js"

# Right (quote pattern)
npx prettier --write 'src/**/*.js'
```

---

## Getting Help

If you're still stuck after trying these solutions:

1. **Check Prettier docs:** https://prettier.io/docs/en/
2. **Check Node.js version:** `node --version` (require 18+)
3. **Check npm version:** `npm --version` (require 9+)
4. **Review formatter logs:** `.ai_logs/formatter_log.jsonl`
5. **Check GitHub Actions logs:** View workflow run details
6. **Create minimal reproduction:** Isolate issue in simple test case

---

## Related Documentation

- [Formatter README](./README.md) - Setup and usage
- [House Style Rationale](./HOUSE_STYLE.md) - Why these rules?
- [GitHub Actions Integration](./INTEGRATION.md) - CI/CD setup
- [Rollout Plan](./ROLLOUT_PLAN.md) - Phased adoption strategy

---

## Version

- **Last Updated:** 2025-11-10
- **Author:** AI (Claude)
- **Prettier Version:** 3.6.2+
