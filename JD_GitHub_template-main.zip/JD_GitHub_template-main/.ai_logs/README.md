# AI Logs Directory

This directory contains session logs from Claude Code comprehensive logging hooks.

## What's Logged

Each Claude Code session creates a new JSON Lines (`.jsonl`) file with detailed activity tracking:

- **Messages**: Full prompts and responses
- **Tool Usage**: Every Read, Write, Edit, Bash, Grep, etc. with parameters and results
- **Token Tracking**: Comprehensive token usage per message, per tool, cumulative
- **Performance**: Tool execution time, session duration, performance warnings
- **Thinking**: Extended thinking process (if enabled in Claude Code)
- **Stream Chunks**: Real-time response streaming (verbose mode only)

## Privacy & Security

**⚠️ IMPORTANT**: These log files are **automatically excluded from git** via `.gitignore`.

### Why Logs Are Gitignored

1. **Sensitive Data**: May contain file paths, environment variables, code snippets
2. **Size**: Can grow large quickly (10MB+ per session)
3. **Privacy**: Contains your full conversation with Claude
4. **Secrets**: Despite automatic redaction, safer to keep local

### Secret Redaction

The logging hook automatically redacts:
- API keys and tokens (GitHub, AWS, etc.)
- SSH private keys
- JWT tokens
- Environment variables with sensitive names
- UUIDs that might be tokens

**But**: Redaction isn't perfect. Keep logs local for safety.

## File Format

Logs use **JSON Lines** format (`.jsonl`):
- One JSON object per line
- Easy to stream and process
- Tools like `jq`, `grep`, and custom scripts work well

Example:
```jsonl
{"sessionId":"sess_123","timestamp":"2025-11-08T14:30:00.000Z","event":"beforeMessage","messageId":1}
{"sessionId":"sess_123","timestamp":"2025-11-08T14:30:01.000Z","event":"afterMessage","messageId":1,"data":{"tokens":{"prompt":1234,"completion":567,"total":1801}}}
```

## Analyzing Logs

Use the `analyze_logs.mjs` script in `claude_mods/`:

```bash
# Analyze latest session (summary)
node claude_mods/analyze_logs.mjs

# Comprehensive token analysis
node claude_mods/analyze_logs.mjs --tokens

# Tool usage analysis
node claude_mods/analyze_logs.mjs --tools

# Performance analysis
node claude_mods/analyze_logs.mjs --performance

# Everything
node claude_mods/analyze_logs.mjs --all

# Analyze specific session
node claude_mods/analyze_logs.mjs .ai_logs/session_2025-11-08_14-30-00.jsonl
```

## Configuration

Configure logging behavior in `~/.claude/logging_config.json`:

- **Verbosity**: `minimal`, `normal`, `verbose`
- **Privacy**: Enable/disable secret redaction, path redaction
- **Token Tracking**: Per-tool, per-message, cumulative, cost estimation
- **Performance**: Duration tracking, memory tracking, slow tool warnings

See `claude_mods/LOGGING_GUIDE.md` for full configuration options.

## Log Rotation

The logging hook automatically:
- Creates new log file per session
- Rotates when file reaches 10MB
- Keeps last 10 session files
- Deletes older files automatically

## Disk Space

Typical log sizes:
- **Minimal verbosity**: ~100KB per hour
- **Normal verbosity**: ~1-2MB per hour
- **Verbose verbosity**: ~5-10MB per hour (includes thinking and streaming)

Monitor disk usage:
```bash
du -sh .ai_logs
```

## Manual Cleanup

To delete old logs:
```bash
# Delete logs older than 7 days
find .ai_logs -name "session_*.jsonl" -mtime +7 -delete

# Delete all logs (keep .gitignore)
rm .ai_logs/session_*.jsonl
```

## Troubleshooting

**No logs appearing?**
1. Check `~/.claude/hooks.json` is configured correctly
2. Verify logging hook script has execute permissions
3. Check for errors in Claude Code output

**Logs too large?**
1. Reduce verbosity in `~/.claude/logging_config.json`
2. Disable `onStreamChunk` and `onThinking` hooks
3. Enable log rotation (should be automatic)

**Privacy concerns?**
1. Review `.gitignore` to ensure logs excluded
2. Increase redaction sensitivity in config
3. Delete logs after analysis: `rm .ai_logs/session_*.jsonl`

## See Also

- `claude_mods/LOGGING_INSTALLATION.md` - Installation guide
- `claude_mods/LOGGING_GUIDE.md` - Usage and analysis guide
- `claude_mods/logging_hook.mjs` - Hook implementation
- `claude_mods/analyze_logs.mjs` - Analysis tool
